# Version

Product Version: `0.40.1`

Phase: 02 — CR Platform Extensions  
Step: 10/v1.5 — D-06 suffix-policy decision closure

Status: **0.40.1 USER VALIDATED / CLOSED; D-06 RESOLVED**.

0.40.1 CSV reporting enhancement accepted after fresh workstation quality-gate and controlled live Cimatron CSV validation; product/runtime version remains `0.40.1` and this closure adds governance/documentation only.

CR-04 v1.5 decision D-06 is now **RESOLVED** by explicit user approval: suffix details are not separately maintained or checked. Production comparison remains the full normalized native `TMPL::Material` value versus the full normalized Design Order `Remark`; no suffix stripping, mapping, or suffix-specific rule is introduced. This is documentation/governance only and does not change runtime version `0.40.1`.

## Current status (authoritative)

## 0.40.1 validation closure

- User workstation `quality-gate-20261007-112824.txt` began at `2026-10-07T11:28:24.2736432+05:30` and completed at `2026-10-07T11:29:27.4562435+05:30`: Release x64 PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, Infrastructure, governed coverage, and Local Quality Gate PASS; ExitCode 0.
- Controlled live export `Cimatron-Result-Report-20261007-113508.csv` validated the approved 13-column CSV contract, preserved occurrence-path traversal grouping, normalized statuses, summary reconciliation, and `Overall Status = ACTION REQUIRED`.
- Live detail summary: Total 131; PASS 3; FAIL 0; WARNING 110; NOT FOUND 4; SKIPPED 13; INFO 1. Correlation ID: `76ce74d49e7b47be9848b814b24a6eb8`.
- Confirmed PASS rows: Cavity block / Cavity / `P-20-2311`; Core block / Core / `P-20-2311`; core fix insert-01 / Core Insert / `P-20-2311`.
- User manually confirmed: **Assembly remains unmodified after validation: YES**. Exact chat receipt timestamp was not independently captured and is not invented.
- Raw quality-gate capture and raw exported client Result Report CSV remain external evidence and are intentionally excluded from the cumulative package.
- Status: **0.40.1 USER VALIDATED / CLOSED**.

## 0.40.1 implementation state

- User workstation `quality-gate-20261007-111615.txt` completed with all governed suites and coverage/local gate PASS and exit code 0, but the Release x64 build emitted one CA1859 analyzer warning in `SteelGradeDesignOrderEvaluation.cs(270,63)`. Project acceptance requires 0 warnings / 0 errors, so 0.40.0 is not accepted.
- Approved corrective changes only the private `CollectContexts` return type from `IReadOnlyList<FindingComponentContext>` to concrete `List<FindingComponentContext>`, matching the actual returned object and clearing CA1859 without changing behavior.
- The protected SHA-256 for `SteelGradeDesignOrderEvaluation.cs` in Architecture tests is aligned to the approved source change.
- Domain assembly/file version advances to `0.40.1.0`; Application and Plugin remain `0.40.0.0` because their binaries/source are unchanged by this corrective.
- CSV schema, ordering, status mapping, summary behavior, CR-04 validation semantics, Cimatron read/traversal/highlight behavior, configuration, thresholds, workbook/model handling, and mutation behavior remain unchanged.
- Fresh user workstation quality-gate evidence is required.

## 0.40.0 implementation state

- User approved retaining CSV output instead of introducing XLSX. The CSV remains the only Result Report export format.
- CR-04 findings now carry optional structured component-reporting context: Component Title, Occurrence Path, Instance ID, normalized native Part Type, native Part Material, and traversal occurrence order.
- `STEEL_GRADE_MATCH` / mismatch and other occurrence-specific Form findings retain this context through Domain evaluation and the Application/UI projection.
- CSV component rows are expanded from finding context and ordered by the existing Cimatron traversal occurrence order; non-component/global findings follow after component rows. No alphabetical sorting is introduced.
- CSV columns are: `ComponentTitle,OccurrencePath,InstanceId,PartType,MoldPartMaterial,ValidationStatus,FindingCode,Feature,Requirement,Message,Measured,Limit,CorrelationId`.
- Export status is normalized to `PASS`, `FAIL`, `WARNING`, `NOT FOUND`, `SKIPPED`, or `INFO`. The summary at the end records each count plus `Overall Status`, which is `ACTION REQUIRED` when FAIL/WARNING/NOT FOUND is nonzero, otherwise `PASS`.
- Existing CSV escaping, UTF-8 BOM output, unfiltered export behavior, Result Report UI filtering, selection restore/highlighting, CR-04 comparison rules, Design Order parsing, Cimatron traversal, Cimatron read APIs, configuration, thresholds, workbook/model handling, and mutation behavior are unchanged.
- Domain, Application, and Plugin assembly/file versions advance to `0.40.0.0`.
- Agent has performed source/diff/hash/package preparation only. Per project governance, build/tests/coverage/analyzers/SonarQube/Cimatron validation remain user-run and are not claimed.


## 0.39.9 closure evidence

- Workstation quality gate `quality-gate-20261007-004937.txt` (capture timestamp `2026-10-07T00:49:37.5423893+05:30`) accepted 0.39.9: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure suites PASS; governed coverage and local quality gate PASS; exit code 0.
- Controlled live Form rerun `Cimatron-Result-Report-20261007-005224.csv` confirmed the 0.39.9 corrective target: `CAD_PART_PROPERTY_READ_ERROR=0`, `CAD_SYNTHETIC_ROOT_SKIPPED=7`, `CAD_NON_PART_SKIPPED=6`, and three preserved `STEEL_GRADE_MATCH` findings for Cavity, Core, and CoreInsert at `P-20-2311`. Correlation ID: `e53384f0f4ed4eb1aeac1967804a89cf`.
- User manually confirmed after the live run: **Assembly remains unmodified = YES**. Exact chat receipt timestamp was not independently captured and is not invented.
- Remaining failed findings are model-data gaps for CavityInsert, MovingCore, AngularLifter, and MouldBase; they are not failures of the synthetic-root corrective.
- Raw client Design Order and raw Result Report CSV remain external evidence and are not included in the cumulative package.
- No production, test, configuration, threshold, workbook, or model behavior changes are made by this closure package. Product/runtime version remains `0.39.9`.


User workstation `quality-gate-20261007-003106.txt` accepted 0.39.8: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure suites PASS; governed coverage PASS; local quality gate PASS; exit code 0.

Controlled live Form rerun `Cimatron-Result-Report-20261007-003425.csv` confirmed the 0.39.7 non-Part skip for six real `cmAssembly` occurrences and preserved Cavity/Core/CoreInsert matches, but seven `CAD_PART_PROPERTY_READ_ERROR` findings remained. Read-only traversal evidence `api-capability-cr04-slice2a-20261007-004150.txt` proved those seven are Cimatron synthetic `cmPart` Root occurrences with exact `ModelPid = \\5\Root.elt`, one for the active/top assembly and one under each affected nested assembly. Full traversal/D-15 identity participation remains mandatory and unchanged.

Version 0.39.9 changes only Form-mode eligibility: after the existing exact `cmPart` model-type check and before native Part-property reading, exact synthetic `\\5\Root.elt` PIDs are skipped with `[CAD_SYNTHETIC_ROOT_SKIPPED]` Info. A focused Application regression proves the synthetic root does not invoke the Part-property reader. Genuine real-Part read failures and all traversal/highlight identity behavior remain unchanged.

User workstation `quality-gate-20261007-002443.txt` validated the 0.39.7 Release x64 build itself at 0 warnings / 0 errors but stopped at Architecture Tests. Root cause was the CR-04 v1.5 protected-file SHA-256 guard still carrying the pre-0.39.7 hash for `CimatronAssemblyBodyAttributeReader.cs` even though the user had explicitly approved that file's 0.39.7 `ModelType` evidence change. Version 0.39.8 aligns only that architecture-test protected hash to the verified 0.39.7 file hash `7fede8fcd63d4bbad4213110cc561c5b78f2b41d1cc57d64623398c283106368`. No production source or CR-04 behavior changes.

User workstation `quality-gate-20261006-233537.txt` accepted 0.39.6: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure suites PASS; Domain 99.74%, Application 91.87%, DesignChecks 100%, and Infrastructure 81% all met governed thresholds; local quality gate PASS; exit code 0.

Controlled production Form run `Cimatron-Result-Report-20261007-000856.csv` then proved end-to-end native Part Type / Part Material comparison for Cavity, Core, and CoreInsert at `P-20-2311`, but also produced seven `CAD_PART_PROPERTY_READ_ERROR` findings with `Value does not fall within the expected range` on higher-level/nested assembly occurrences. Source inspection confirmed the full highlighter-equivalent traversal deliberately retains every occurrence before nested descent, while Form orchestration sent every unsuppressed occurrence PID to the Part-specific PDM reader without checking the occurrence model type.

Version 0.39.7 carries each traversal occurrence's existing Cimatron `model.Type.ToString()` value into `AssemblyBodyAttributeOccurrence`. Form mode preserves the complete traversal but skips non-`cmPart` occurrences before native Part-property reads and emits auditable `[CAD_NON_PART_SKIPPED]` Info findings. Genuine `cmPart` property-read failures remain Errors. No ModelTitle classification fallback, DO semantics, Part Type/Material mapping, traversal filtering, threshold, config, workbook, or mutation behavior changes.

User workstation `quality-gate-20261006-232537.txt` rejected 0.39.5 before coverage collection: Release x64 build PASS, Architecture PASS, Domain PASS, then Application Tests FAIL; build also emitted one CA1859 warning at `SteelGradeDesignOrderValidation.cs(323,46)` for the concrete exclusion-parser return type. Static review identified the first new failing assertion: `MissingNestedBodyReferenceSkipsMappingAndHighlight` expected aggregate `Passed`, but production `FindingAggregation` correctly elevates its two `Skipped` findings over `Passed`.

Version 0.39.6 is the approved narrow corrective: change that test's aggregate expectation to `Skipped`, change private `ParseExclusionPatterns` return type from `IReadOnlyList<string>` to `string[]` to clear CA1859, and align only the changed DesignChecks assembly version. No CR-04 runtime behavior, parsing behavior, threshold, configuration, Program.cs, or other production source changes.

User workstation `quality-gate-20261006-221138.txt` validated the 0.39.4 build and all governed suites but failed the DesignChecks coverage gate at 93.45% against 95%. Coverage XML analysis showed the private pre-0.39 Form `TryParseCategoryPatterns` routine had zero callers after the 0.39.0 `TMPL::Part_Type` migration, while the exclusion parser retained an impossible blank-entry rejection after `SplitList` had already removed empty entries.

Version 0.39.5 removes only that orphaned private method, simplifies exclusion parsing without changing its observable behavior, adds meaningful coverage/regression tests for the existing public/internal seams, and advances the changed DesignChecks assembly version. `ComponentCategoryPatterns` remains present and unchanged; retirement of that parameter surface is an explicit follow-up decision, not part of 0.39.5.

User workstation `quality-gate-20261006-215037.txt` validated the 0.39.3 architecture correction: Release x64 build PASS with 0 warnings / 0 errors and Architecture, Domain, Application, Cimatron Integration, and Infrastructure test suites all PASS. Coverage collection then failed only because `CimatronCustomization.DesignChecks` measured 92.14% against the governed 95% minimum; Domain 99.74%, Application 91.87%, and Infrastructure 81% remained above their thresholds.

Version 0.39.4 is the approved coverage-only corrective. It adds DesignChecks feature tests for null execution/application-result guards plus missing required Table/Form configuration branches. No production `src/**` behavior is changed.

User workstation `quality-gate-20261006-214154.txt` validated the 0.39.2 warning cleanup at build time: Release x64 build PASS with 0 warnings / 0 errors, then Architecture Tests FAIL and the quality gate exited 1. Direct ArchitectureTests execution reproduced `CR-04 v1.5 native Part Type/Part Material Form orchestration lost a required contract.`

Version 0.39.3 applies the approved narrow Architecture source-contract corrective only: the guard now checks the actual `CAD_PART_TYPE_MISSING` and `CAD_PART_TYPE_UNSUPPORTED` code literals used by the Form orchestration instead of requiring bracketed display-form literals that are assembled dynamically at runtime. No production CR-04 behavior changes.

User workstation `quality-gate-20261006-212934.txt` validated the 0.39.1 CS1628 fix at compile time: Release x64 build PASS with 0 errors, but emitted one CA1859 warning in `PartTypeCategoryResolverTests.cs`. The gate then stopped at Architecture Tests with `CR-04 v1.5 Form reader lost a required read-only or fail-closed source contract.` Direct ArchitectureTests execution reproduced that exact failure.

Version 0.39.2 applies the approved narrow architecture-contract corrective only: the source guard now checks the actual Form-reader identifiers `selectedFamily` and `rawRemark`, which already implement the selected-family and raw-Remark contract; the resolver test helper returns its concrete array type to clear CA1859. No production CR-04 behavior changes.

User workstation `quality-gate-20261006-211923.txt` rejected 0.39.0 during Release x64 compilation. `PartTypeCategoryResolver.cs(27,21)` failed with `CS1628` because the `out` parameter `normalizedPartType` was captured inside the LINQ lambda. The build exited 1 before governed tests/coverage could run.

Version 0.39.1 applies the approved narrow compile corrective only: normalize Part Type into a local variable, assign that local to the `out` parameter, and use the local variable inside the LINQ predicate. Existing resolver tests already cover trim/collapse/case behavior, so no test behavior or production rule changes are introduced.

User workstation `quality-gate-20261006-194848.txt` validated 0.38.6: Release x64 build PASS with 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, exit code 0.

Controlled live diagnostic `cr04-part-property-discovery-diagnostic-20261006-195235.txt` proved the read-only PDM document-attribute route and identified `TMPL::Part_Type`; `Core block` returned `Core`. The later controlled diagnostic `cr04-part-property-discovery-diagnostic-20261006-200430.txt` correlated the user-set Cimatron Part Material value `P-20-2311` to `TMPL::Material=P-20-2311` while preserving `TMPL::Part_Type=Core`. Both diagnostics reported `ModificationStateChanged=False`; the later run read all 8 target occurrences successfully.

Version 0.39.0 promotes those verified native properties into CR-04 Form-mode production behavior:

- `TMPL::Part_Type` is the authoritative Cimatron component-category source;
- `TMPL::Material` is the authoritative Cimatron actual steel-grade/material source;
- the Sridevi Design Order selected material-family `X` columns plus the row `Remark` define the expected material requirement;
- Part Type and Design-Order category-label matching trim/collapse whitespace and compare case-insensitively;
- Part Material and Remark trim leading/trailing whitespace before approved steel-grade normalization/comparison;
- raw Cimatron property and Design-Order Remark values remain available in typed results for evidence/reporting;
- no `X` plus blank Remark creates no material requirement;
- multiple `X`, `X` with blank Remark, Remark without `X`, or a non-`X` nonblank marker fails closed as a Design-Order input error;
- Form mode no longer uses ModelTitle category patterns or BOM Standard Number correlation;
- Table mode and its existing BOM material route remain supported and unchanged;
- the legacy custom `STEEL_GRADE` body attribute remains diagnostic/history only.

The AI agent does not run workstation build/tests/coverage or Cimatron validation. User must run the full quality gate and then controlled live CR-04 validation.
