# CR-04 Slice 3 — In-Process Plugin Wrong-Type Smoke Implementation Handoff 0.27.6

## Status

- Phase 02, Step 10/3, CR-04 Slice 3.
- Version: `0.27.6`.
- Context: **AMBER**.
- Implementation: complete within approved scope.
- Workstation quality gate: **AWAITING USER EXECUTION**.
- Live in-process smoke: **AWAITING USER EXECUTION**.
- No PASS is claimed by the agent.

## Approved scope implemented

A developer-only, one-shot, read-only Plugin smoke now executes inside the already-running Cimatron process. It uses `CimServicesAPI.CimApplicationProvider().GetApplication()` from the Plugin/class context and calls the unchanged production `CimatronAssemblyBodyAttributeReader`.

The smoke is gated by a 30-minute, versioned request file that is atomically consumed. Without a valid request, normal Plugin behavior is unchanged.

Hard-coded developer known-answer controls are intentionally limited to the smoke diagnostic:

- Assembly: `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`
- Part occurrence model: `KA-PART-1-CR04-WRONG-TYPE`
- Body entity: `4`
- Attribute: `CR04_WRONG_TYPE_CONTROL`

The smoke records target occurrence path/InstanceId, body count, `Present`, `Absent`, `ReadError`, saved-document modified state, file timestamp/length before and after, `NoMutation`, and final `Result`.

Accepted result remains:

```text
Present=0
ReadError>=1
NoMutation=PASS
Result=FAIL_SAFE_READ_ERROR_OBSERVED
```

Any `Present>0` is a hard stop. Wrong active model, missing target occurrence/body, traversal ReadError, mutation evidence change, evidence-write failure, or unexpected runtime behavior also stops safely.

## Files added

- `src/CimatronCustomization.Plugin/Diagnostics/Cr04Slice3WrongTypeInProcessSmokeRequest.cs`
- `src/CimatronCustomization.Plugin/Diagnostics/Cr04Slice3WrongTypeInProcessSmoke.cs`
- `tools/Request-Cr04Slice3WrongTypeInProcessSmoke.ps1`
- `docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.4.md`
- this handoff

## Files modified

- `src/CimatronCustomization.Plugin/CimatronCommandExecution.cs`
- `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj`
- `src/CimatronCustomization.Plugin/Properties/AssemblyInfo.cs`
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256`

## Explicitly unchanged

No change was made to:

- `CimatronAssemblyBodyAttributeReader`
- CR-04 business semantics
- production traversal
- wrong-type classification
- `FeatureComposition`
- production config
- BOM route
- D-09(b)
- D-15(b)
- Assist Part handling
- highlighter
- client cleanup/package behavior

## Workstation validation procedure

First clear the obsolete external-smoke environment variables in the PowerShell session used for validation:

```powershell
Remove-Item Env:CIMATRON_DEV_ENABLE_CR04_SLICE3_WRONG_TYPE_SMOKE -ErrorAction SilentlyContinue
Remove-Item Env:CIMATRON_DEV_CR04_WRONG_TYPE_MODEL_TITLE -ErrorAction SilentlyContinue
```

Then run the governed quality gate from the repository root:

```powershell
Get-ChildItem -Path . -Recurse | Unblock-File
& ".\tools\Invoke-QualityGate.ps1"
```

Required before live validation:

- Release x64 PASS
- 0 warnings / 0 errors
- all governed test suites PASS
- coverage gate PASS
- local quality gate PASS
- exit code 0

Do not proceed to live smoke if the quality gate is not clean.

## Live in-process smoke procedure

After the clean quality gate:

1. Start Cimatron normally.
2. Open only the saved disposable Assembly `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`.
3. From repository root, run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Request-Cr04Slice3WrongTypeInProcessSmoke.ps1"
```

4. Within 30 minutes, click the existing **Cimatron Customization** command once.
5. The normal launcher is bypassed for that one request and the smoke runs inside the current Cimatron process.
6. Send the generated `artifacts\diagnostics\cr04-slice3-in-process-smoke-*.txt` evidence plus confirm manually that the disposable Assembly remains unmodified.

Expected accepted evidence:

```text
ExecutionContext=IN_PROCESS_PLUGIN
ActiveAssemblyTitle=KA-ASM-1-CR04-WRONG-TYPE-SMOKE
Present=0
ReadError=1 or greater
NoMutation=PASS
Result=FAIL_SAFE_READ_ERROR_OBSERVED
```

If the request must be cancelled before clicking the Plugin command:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Request-Cr04Slice3WrongTypeInProcessSmoke.ps1" -Cancel
```

## Validation boundary

The agent environment does not contain the Windows/.NET Framework/Cimatron workstation toolchain. The agent therefore did not execute the governed Release build, tests, coverage, deploy, or live Cimatron smoke and claims no PASS.

Console-capture output files are not included in this cumulative handoff package.
