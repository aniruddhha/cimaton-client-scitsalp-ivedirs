# Phase 02 / Step 10 / CR-04 v1.5 — Part Property Discovery Diagnostic — 0.38.5

## Status

**IMPLEMENTED / AWAITING USER QUALITY GATE AND CONTROLLED LIVE DIAGNOSTIC.**

## Entering evidence

- Baseline package: `phase-02-step-10-cr04-v1.5-part-material-api-reflection-investigation-0.38.4.zip`.
- User-supplied 0.38.4 quality gate `quality-gate-20261006-180956.txt`: Release x64 PASS, 0 warnings / 0 errors; all governed suites PASS; coverage collection/gate PASS; local gate PASS; exit 0.
- User-supplied reflection evidence `part-material-api-reflection-20261006-181315.txt`: `RuntimeCalls: NONE`; Classification B; no typed native Part Material getter; installed `IApplication.GetPdm()` and `IPdm.RetriveDocAttribute(string, out object, string)` candidate route present; `IDocAttribute.Name` / `Value` readable; native Part Material identity still NOT VERIFIED.

## Client direction carried forward

The client subsequently confirmed that CR-04 component type should come from Cimatron **Part Type**, not Details/Description. Supported business component types remain Cavity, Core, Cavity Insert, Core Insert, Moving Core, Angular Lifter, Pressure Pad, Wear Pad, and Mould Base.

User Cimatron UI evidence shows BOM `Type` returning `Modeler`; therefore BOM `Type` is not treated as Cimatron Part Type and is not promoted into CR-04 category mapping.

## 0.38.5 scope

Developer-only, one-shot, read-only in-process discovery of the exact document attributes corresponding to:

- Part Type;
- Part Material;
- Remark.

No production CR-04 behavior is changed.

The diagnostic:

1. reuses `CimatronAssemblyBodyAttributeReader` only to obtain the approved occurrences and existing `ModelPid` values;
2. gets the PDM manager through `IApplication.GetPdm()`;
3. calls `IPdm.RetriveDocAttribute(ModelPid, out object, "")`;
4. enumerates returned `IDocAttribute.Name` / `Value` pairs;
5. records value runtime type and sanitized textual value;
6. does not guess, assign, or hard-code Part Type / Part Material / Remark attribute names;
7. records active-document `IsModified()` before and after and fails if the state changes.

Approved target ModelTitles:

- `Cavity block`
- `Core block`
- `main insert`
- `Insert#2`
- `Main Core insert`
- `core fix insert-01`
- `Slider-01`
- `Lifter-01`

## Files added

- `src/CimatronCustomization.Plugin/Diagnostics/Cr04PartPropertyDiscoveryDiagnostic.cs`
- `src/CimatronCustomization.Plugin/Diagnostics/Cr04PartPropertyDiscoveryDiagnosticRequest.cs`
- `tools/Request-Cr04PartPropertyDiscoveryDiagnostic.ps1`
- `docs/history/session-handoffs/phase-02-step-10-cr04-v1.5-part-property-discovery-diagnostic-0.38.5.md`

## Existing files modified

- `src/CimatronCustomization.Plugin/CimatronCommandExecution.cs`
- `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj`
- `src/CimatronCustomization.Plugin/Properties/AssemblyInfo.cs`
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/platform/CIMATRON-2026-API-CAPABILITY-VERIFICATION.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256`

## Explicitly unchanged production behavior

- `VerifySteelGradeAgainstDesignOrder.cs`;
- `SteelGradeCategoryResolver.cs`;
- `CimatronBomMaterialTableReader.cs`;
- `IBomMaterialTableReader.cs`;
- Design Order Form reader/profile and comparison logic;
- Domain steel-grade evaluation;
- production configuration/category mappings;
- client workbook and Cimatron models;
- legacy `STEEL_GRADE` body attribute remains diagnostic/history only and is not a production fallback.

## Read-only guard

The Architecture test requires the PDM read route, evidence markers, exact target set, versioned one-shot request and no-mutation evidence. The diagnostic source is prohibited from containing document/link attribute update calls, Save/SaveAs, MakeDirty, attribute attachment/factory use, model/document/entity creation/deletion/rename/open write paths, or write access mode.

## User validation required

### 1. Full quality gate

Run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Required: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage collection/gate PASS, local quality gate PASS, exit 0.

### 2. Controlled live field discovery

Use only the approved CR-04 test-copy Assembly. If practical, keep a known visible value in the target Part properties before running (for example `Core block` Part Type = `Core`; use existing known Part Material/Remark values rather than modifying an accepted baseline).

Create the one-shot request:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Request-Cr04PartPropertyDiscoveryDiagnostic.ps1"
```

Keep the test-copy Assembly active in Cimatron and click **Cimatron Customization** exactly once within 30 minutes.

Return the generated:

`artifacts\diagnostics\cr04-part-property-discovery-diagnostic-*.txt`

Do not run another diagnostic or change production CR-04 logic until this evidence is reviewed.

## Expected evidence interpretation

The evidence starts with:

- `PartTypeAttributeIdentity=NOT VERIFIED`
- `PartMaterialAttributeIdentity=NOT VERIFIED`
- `RemarkAttributeIdentity=NOT VERIFIED`

Only values actually correlated with known Cimatron UI properties may be promoted. No attribute name may be inferred from spelling alone.

## Packaging exclusions

Raw quality-gate output, reflection evidence/captures, live diagnostic evidence, console captures, coverage artifacts, client workbook, and Cimatron models remain outside the cumulative ZIP.
