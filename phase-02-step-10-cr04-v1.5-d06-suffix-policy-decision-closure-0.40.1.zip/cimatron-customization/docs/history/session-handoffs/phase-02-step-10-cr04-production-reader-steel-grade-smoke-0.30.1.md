# Phase 02 Step 10 — CR-04 Production-Reader STEEL_GRADE Smoke — 0.30.1 Handoff

## Purpose

Version `0.30.1` adds only a controlled, developer-only, one-shot, strictly read-only in-process smoke for the actual production `CimatronAssemblyBodyAttributeReader` against the already-saved disposable positive anchor.

This cumulative handoff now records the completed user workstation quality gate and the controlled live Cimatron production-reader smoke. Raw evidence files remain outside the ZIP; only governed summaries are retained here.

## Accepted baseline entering this change

- Package/version: `0.30.0`.
- User workstation gate: `quality-gate-20261005-221151.txt` accepted — Release x64 PASS, 0 warnings / 0 errors, governed suites PASS, coverage/local gate PASS, exit code 0.
- Disposable Part: `KA-PART-1-CR04-WRONG-TYPE`.
- Controlled body/entity: `4`.
- Positive anchor: exact requested-name string lookup `STEEL_GRADE`, returned `cmAttString`, exact value `P-20-2311`.
- Separate read-only Assembly verification: `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`, occurrence `root/10:14`, body `4`, one exact string match, `NoMutation.Result: PASS`.
- Returned attribute `Name` being blank remains an accepted observed Cimatron API behavior; acceptance is exact requested-name lookup plus returned string type/value.
- Same-name non-string control behavior remains evidence for exact string-only lookup; no alternate-type probing/fallback is permitted.
- D-02 remains **VERIFIED for the current implementation direction**. This 0.30.1 smoke does not re-resolve or broaden D-02.
- D-04 remains provisionally model-name based.
- D-09 remains runtime file browse/select.
- Production DO `4075 P DO.XLSX` / `QR/DG/02 REV 04` remains the authoritative client-specific reference direction for pending CR-04 v1.5 work.

## Approved amendments carried into implementation

1. Baseline checksum verification was performed before editing: all `408/408` `CHECKSUMS.sha256` entries matched the uploaded 0.30.0 package, verification exit code 0.
2. Positive anchor is the saved `STEEL_GRADE=P-20-2311` body-4 evidence, not the earlier wrong-type control.
3. The new smoke records **every** body observation returned by the production reader. Pre-run statuses/values for non-target bodies are not invented. The controlled target has exact known-answer requirements; any reader `ReadError` anywhere in the returned body observations is a hard-stop diagnostic failure.
4. No-mutation evidence covers both active Assembly and saved disposable Part file. The Part path is explicitly supplied by the requester rather than guessed from Cimatron PID/path behavior.
5. Existing `ArchitectureBoundaryTests.Program.cs` remains unchanged. The new source-contract guard is registered through `ArchitectureBoundaryTests.RunAll()`, increasing registered guard methods from 17 to 18; console output remains aggregate `ARCHITECTURE TESTS: PASS/FAIL`.
6. New positive-smoke source guards use exact forbidden tokens `.Save(`, `.Attach(`, `SetAttribute(`, `GetAttributes(`, `GetEntityById(` and `cmAttInteger`. The existing wrong-type smoke is not subjected to the positive-smoke `cmAttInteger` textual ban because it intentionally describes that wrong-type control.
7. This smoke proves only the actual production reader's in-process path on the controlled model. D-02 remains VERIFIED for the current direction; client-specific v1.5 naming/template treatment remains pending.
8. In `ReadNamedAttributes("STEEL_GRADE", null)`, `null` means no body-attribute component-key lookup. That matches current production CR-04 because `ComponentKeySource` is `ModelTitle`, not `BodyAttribute`.

## New files

- `src/CimatronCustomization.CimatronIntegration/Cr04SteelGradeSmokeProbe.cs`
  - owns the real production `CimatronAssemblyBodyAttributeReader`;
  - calls exact `ReadNamedAttributes("STEEL_GRADE", null)`;
  - requires exactly one target `KA-PART-1-CR04-WRONG-TYPE` occurrence;
  - requires exactly one body/entity `4` target observation;
  - requires `Present` and exact `P-20-2311`;
  - records every body observation;
  - hard-stops if any body observation is `ReadError`;
  - exposes primitive evidence only to Plugin.

- `src/CimatronCustomization.Plugin/Diagnostics/Cr04SteelGradeInProcessSmokeRequest.cs`
  - distinct request file `cr04-steel-grade-in-process-smoke.request`;
  - request version `0.30.1`;
  - atomic one-shot consume;
  - 30-minute expiry;
  - requires absolute evidence path and existing absolute disposable Part path;
  - deletes consumed request file.

- `src/CimatronCustomization.Plugin/Diagnostics/Cr04SteelGradeInProcessSmoke.cs`
  - requires active document type `cmAssembly`;
  - requires exact Assembly title `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`;
  - requires the explicitly supplied Part filename to identify `KA-PART-1-CR04-WRONG-TYPE`;
  - captures Assembly path / `IsModified()` / file timestamp / length before and after;
  - captures Part file timestamp / length before and after;
  - calls only the new Integration probe;
  - returns success only as `PRODUCTION_READER_STEEL_GRADE_OBSERVED` with both no-mutation comparisons passing.

- `tools/Request-Cr04SteelGradeInProcessSmoke.ps1`
  - does not launch Cimatron;
  - requires `-PartFilePath` for the saved disposable Part;
  - creates the distinct one-shot request;
  - supports `-Cancel`;
  - writes raw live evidence only under `artifacts/diagnostics/`.

## Existing files intentionally modified

- `src/CimatronCustomization.CimatronIntegration/CimatronCustomization.CimatronIntegration.csproj`
  - explicitly compiles `Cr04SteelGradeSmokeProbe.cs` in the old-style project.
- `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj`
  - explicitly compiles the new request/smoke classes.
- `src/CimatronCustomization.Plugin/CimatronCommandExecution.cs`
  - adds one explicit developer-diagnostic interception after the existing wrong-type smoke and before normal launcher behavior.
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`
  - registers one new guard via `RunAll()` and enforces exact positive-smoke source/runtime boundaries.
- `VERSION.md`, `IMPLEMENTATION-HISTORY.md`, `CHANGELOG.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, this handoff and `CHECKSUMS.sha256`
  - governance, traceability, timestamping and package integrity only.

No other source/test/tool/project/config file is intentionally changed.

## Explicitly unchanged / out of scope

- `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs`
- Domain comparison/business logic
- Design Order processing
- highlighter
- production configuration
- existing wrong-type smoke semantics
- baseline `KA-PART-1` and `KA-ASM-1`
- Cimatron models/files themselves
- CR-04 v1.4 requirement/spec content

## User quality-gate sequence (completed)

From the repository root on the Cimatron workstation:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Required criteria, all satisfied by `quality-gate-20261005-225434.txt`:

- Release x64 build PASS;
- **0 warnings / 0 errors**;
- Architecture tests PASS;
- Domain tests PASS;
- Application tests PASS;
- CimatronIntegration tests PASS;
- Infrastructure tests PASS;
- coverage gate PASS;
- local quality gate PASS;
- overall exit code `0`.

The Architecture runner still reports aggregate PASS/FAIL. The governed source now contains 18 registered `RunAll()` guards versus 17 in 0.30.0.

## Controlled live-validation sequence (completed)

1. Ensure the saved disposable Part `KA-PART-1-CR04-WRONG-TYPE` exists and note its absolute file path.
2. Open **only** saved disposable Assembly `KA-ASM-1-CR04-WRONG-TYPE-SMOKE` in Cimatron.
3. From the repository root create the one-shot request, replacing the placeholder with the real saved Part file path:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Request-Cr04SteelGradeInProcessSmoke.ps1" -PartFilePath "C:\ABSOLUTE\PATH\KA-PART-1-CR04-WRONG-TYPE.<actual-extension>"
```

4. Click **Cimatron Customization once** within 30 minutes.
5. Supply the generated `artifacts\diagnostics\cr04-steel-grade-production-reader-smoke-*.txt` evidence to the agent for review.
6. Manually confirm after the smoke that the disposable Assembly remains unmodified.

Expected controlled success evidence includes:

- `ExecutionContext=IN_PROCESS_PLUGIN`
- `Scope=CONTROLLED_MODEL_PRODUCTION_READER_PATH_ONLY`
- exact active Assembly title
- body-observation evidence for every reader-returned body
- target occurrence count `1`
- target body observation count `1`
- target body/entity `4` status `Present`
- target value `P-20-2311`
- `ReadErrorCount=0`
- `AssemblyNoMutation=PASS`
- `PartFileNoMutation=PASS`
- `Result=PRODUCTION_READER_STEEL_GRADE_OBSERVED`

Any mismatch is a diagnostic hard stop and must not be interpreted as a CR-04 business-rule failure.

## Evidence/package policy

Raw quality-gate, console and runtime evidence files must remain outside cumulative ZIPs. Only governed summaries are added after user validation.

## Validation closure

- First workstation gate attempt: `quality-gate-20261005-225325.txt`, timestamp `2026-10-05T22:53:25.5534189+05:30`, stopped safely because `CimatronE.exe` was running; exit code `1`. No build/implementation failure was inferred.
- Accepted workstation gate: `quality-gate-20261005-225434.txt`, started `2026-10-05T22:54:34.5587120+05:30`, completed `2026-10-05T22:55:14.1644215+05:30`; Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage collection/gate PASS, local quality gate PASS, exit code `0`.
- Accepted live smoke: `cr04-steel-grade-production-reader-smoke-20261005-230201.txt`, runtime timestamp `2026-10-05T17:32:45.7390447+00:00` (`2026-10-05T23:02:45.7390447+05:30` local).
- Live observations: 14 total body observations; exact target `root/0:14`, instance `14`, model `KA-PART-1-CR04-WRONG-TYPE`, entity `4`, `Status=Present`, `Value=P-20-2311`; entity `5` on the same occurrence and all other returned observations were `Absent`; `ReadErrorCount=0`.
- No mutation: Assembly before/after path-present/modified/timestamp/length evidence is identical with `Modified=False`; `AssemblyNoMutation=PASS`. Disposable Part file timestamp and length are identical before/after; `PartFileNoMutation=PASS`.
- Final runtime result: `PRODUCTION_READER_STEEL_GRADE_OBSERVED`.
- Evidence header reports `PluginVersion=0.29.0`; this narrow slice did not advance Plugin assembly metadata, while package/governance version is `0.30.1`. This is recorded as traceability, not stale-deployment evidence.
- User approved closure after evidence review. Exact chat approval timestamp was not independently captured and is not invented.
- D-02 remains VERIFIED for the current implementation direction; this smoke provides additional controlled production-reader-path evidence only. CR-04 v1.5 client-specific naming/template work remains pending.

The agent did not execute the workstation gate or Cimatron. The user supplied all validation evidence. Raw evidence files are excluded from this cumulative ZIP.

## Context health

**GREEN**.
