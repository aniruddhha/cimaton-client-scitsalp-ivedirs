# Phase 02 / Step 10 — CR-04 v1.5 0.39.5 quality-gate corrective — 0.39.6

## Entering evidence
`quality-gate-20261006-232537.txt` on 0.39.5: Release x64 PASS; Architecture PASS; Domain PASS; Application FAIL; gate exited before coverage. Build emitted CA1859 at `SteelGradeDesignOrderValidation.cs(323,46)`.

## 0.39.6 changes
- `Step08BInProcessConfirmationTests.cs`: `MissingNestedBodyReferenceSkipsMappingAndHighlight` aggregate expected status corrected from `Passed` to `Skipped`; U7/U12 skipped assertions unchanged.
- `SteelGradeDesignOrderValidation.cs`: private `ParseExclusionPatterns` return type changed from `IReadOnlyList<string>` to `string[]`; method body and `SplitList` behavior unchanged.
- DesignChecks assembly/file version advanced to `0.39.6.0`.
- Governance/version/timesheet/checksum updated.

## Static review
The other nine tests added in 0.39.5 were re-reviewed for analogous status-expectation mistakes. No additional correction was identified and no other test was changed.

## Scope preserved
No CR-04 runtime behavior change; no coverage threshold change; no Program.cs/config/spec/category-pattern retirement; no other production source edit.

## Required user validation
Run the full workstation quality gate:

`powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"`

Do not accept 0.39.6 until that gate passes.
