> **SUPERSEDED by 0.26.3 request-file opt-in corrective.** Retained for historical evidence only.

# Phase 02 — CR-04 Slice 2A Package 2 Top-Level Highlight — 0.26.0

Status: IMPLEMENTED / AWAITING USER QUALITY GATE AND ONE LIVE RUN.

This is an overlay package and must not replace the full repository. Baseline was composed in the approved six-ZIP order before edits.

## Gate semantics
The diagnostic finding can be Passed only for runtime D-15(a)-safe target selection and exactly-one known-attribute-body resolution. It does not confirm viewport highlighting. Package 2 closes only after user visual evidence confirms the intended top-level KA-PART-1 body, no other occurrence, restoration, and unmodified assembly.

## Runtime selection
Full highlighter-equivalent traversal, including suppressed/excluded/zero-body occurrences and depth rule. Unsuppressed top-level KA-PART-1 candidates only. Globally unique InstanceId only. Lowest unique runtime ID selected. Historical IDs are never constants/configuration. No safe candidate => Error/no reference.

## Reference contract
Reference format matches Step 08B: `entity|<instanceId>|<base64(model PID)>|<entityId>`. The highlighter reads `instanceId`, decoded expected PID and `entityId`; `FindInstance` locates the occurrence, it compares `ownerInstance.Model.PID` to the expected PID, `FindOccurrenceEntity` locates the exact entity ID within that occurrence, and `GetAssemblyEntity` maps it into active Assembly context. The Package 2 reader populates the selected runtime InstanceId, selected occurrence `Model.PID`, and selected known-answer body `ID`.

## Opt-in timing
`FeatureComposition.CreateRegistry()` reads the environment variable each time a new launcher is created. If a launcher is already open, the command restores it and does not rebuild the registry. The governed run therefore starts Cimatron from the PowerShell session after setting the variable and opens a fresh launcher.

## Client-package blocker
Diagnostic registration, all eight diagnostic source files, the request script and the two diagnostic test files MUST be removed under a separately approved change before any client package is built.

## Stop rule
One live run only. Stop on first failure. No retry/corrective without approval.
