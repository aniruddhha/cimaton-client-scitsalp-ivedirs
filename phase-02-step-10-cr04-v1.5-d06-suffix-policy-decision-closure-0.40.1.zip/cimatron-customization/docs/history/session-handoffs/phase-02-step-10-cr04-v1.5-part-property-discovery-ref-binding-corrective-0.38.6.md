# Phase 02 / Step 10 / CR-04 v1.5 — Part Property Discovery Ref-Binding Corrective — 0.38.6

## Status

**IMPLEMENTED / AWAITING USER QUALITY GATE.**

## Entering failure evidence

User-supplied `quality-gate-20261006-193513.txt` failed during Release x64 Plugin compilation with:

`Cr04PartPropertyDiscoveryDiagnostic.cs(125,74): error CS1620: Argument 2 must be passed with the 'ref' keyword`

Overall quality-gate exit code: `1`. Tests, coverage, and controlled Cimatron Part-property discovery were therefore not accepted for 0.38.5.

## Root cause

The installed Cimatron 2026 Interop reflection inventory described `RetriveDocAttribute` parameter 2 as output metadata, but the actual C# compile-time imported signature requires a `ref` call-site argument. Version 0.38.5 used `out`, so the Plugin did not compile.

## 0.38.6 approved corrective

- Initialize `object rawAttributes = null`.
- Call `pdm.RetriveDocAttribute(occurrence.ModelPid, ref rawAttributes, string.Empty)`.
- Update the Architecture guard to require that exact initialized `ref` binding.
- Advance diagnostic evidence version and Plugin assembly/file version to 0.38.6.
- Preserve the existing one-shot request schema at 0.38.5 because the request contract did not change.

## Explicitly unchanged

- production CR-04 category mapping and ModelTitle/BOM behavior;
- Design Order parsing/comparison;
- Domain steel-grade evaluation;
- production configuration;
- client workbook and Cimatron models;
- request-file structure, 30-minute expiry, atomic consume behavior;
- read-only/no-save/no-update/no-create/no-delete diagnostic safety boundary;
- Part Type / Part Material / Remark identities remain NOT VERIFIED.

## User validation required

Do not run the live Cimatron diagnostic yet. First run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Required: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage collection/gate PASS, local quality gate PASS, exit 0.

Only after that evidence is reviewed should the existing one-shot Part property discovery request be executed.

## Packaging exclusions

Raw quality-gate output, console captures, coverage artifacts, live diagnostic evidence, client workbook, and Cimatron models remain outside the cumulative ZIP.
