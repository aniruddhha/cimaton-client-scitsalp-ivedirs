# Session Handoff — CR-04 v1.5 Target-Component Read Diagnostic — 0.37.0

## Status

AWAITING USER WORKSTATION QUALITY GATE — 0.37.0 architecture corrective.

## Baseline

Cumulative 0.36.0 Result Report CSV export corrective, validated by user-supplied `quality-gate-20261006-141026.txt`: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gate PASS, exit 0.

## Approved purpose

Diagnose the controlled live CR-04 target failures without modifying the already prepared test-copy Cimatron model or Design Order workbook.

## Added diagnostic

1. Run `tools\Request-Cr04TargetComponentReadDiagnostic.ps1` while Cimatron is closed or open; the script only arms a one-shot request and does not launch Cimatron.
2. Keep the updated CR-04 test-copy Assembly active.
3. Click `Cimatron Customization` once within 30 minutes.
4. The in-process diagnostic reuses `CimatronAssemblyBodyAttributeReader` and `SteelGradeCategoryResolver` and writes `artifacts\diagnostics\cr04-target-component-read-diagnostic-<timestamp>.txt`.
5. Return that evidence file to the agent for analysis.

Evidence columns:

`OccurrencePath | InstanceId | ModelTitle | ModelPID | BodyEntityId | STEEL_GRADE status | STEEL_GRADE value | Category resolution`

## Safety boundaries

- Read-only diagnostic only.
- No helper/model mutation and no save/save-as.
- No attribute attach/create/set.
- No selection mutation.
- No Design Order workbook mutation.
- No new Cimatron API route.
- Production CR-04 reader/category/business logic/config are unchanged.
- Eight CR-04 v1.5 protected files remain byte-identical.

## Required next evidence

First run the full workstation quality gate with Cimatron closed. Do not claim PASS until the user supplies a clean gate. Only after that gate should the live diagnostic be armed and executed.

## 0.37.0 corrective history

`quality-gate-20261006-150312.txt` first exposed CS0012 plus CA1861. The first corrective resolved compilation, but user-supplied `quality-gate-20261006-151118.txt` then showed Release x64 build success with one CA1859 warning followed by Architecture tests FAIL, exit `1`. The cause was the direct Plugin-to-Domain project reference introduced by that first corrective, which conflicts with the established thin-Plugin architecture guard.

The approved architecture-preserving corrective now:

- removes the direct `CimatronCustomization.Domain` reference from `CimatronCustomization.Plugin.csproj`;
- keeps production reader/category resolver reuse through the existing Application/CimatronIntegration-facing types;
- stops dereferencing the Domain-backed `BodyReference` property;
- retains the `BodyEntityId` output column but writes `UNAVAILABLE_AT_PLUGIN_BOUNDARY`;
- changes `SplitList` to return `string[]` to remove CA1859.

No production CR-04 behavior, configuration, API route, model/workbook mutation, or save behavior changes. Do **not** arm or run the diagnostic until a fresh full workstation quality gate is clean.
