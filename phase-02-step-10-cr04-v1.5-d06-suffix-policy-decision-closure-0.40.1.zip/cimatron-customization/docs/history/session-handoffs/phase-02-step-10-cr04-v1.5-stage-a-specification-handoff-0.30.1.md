# Phase 02 Step 10 — CR-04 v1.5 Stage A Specification Handoff — 0.30.1

## Project
Cimatron Customization Platform

## Phase / Step
Phase 02 — CR Platform Extensions  
Step 10/v1.5 Stage A — Production Design-Order form profiling and specification reconciliation

## Version
Runtime/product baseline remains `0.30.1`. This is a documentation-only cumulative handoff; no runtime version change is introduced.

## Context Status
GREEN

## Approval
User explicitly approved the reviewed v1.5 draft. Exact approval timestamp was not independently captured and is intentionally not invented. Agent work for the approved documentation update began at `2026-10-05T23:30:58+05:30`.

## Approved Scope
- verify Stage A facts against externally supplied production workbook;
- add CR-04 implementation specification v1.5 as Proposal;
- reconcile specification against accepted 0.30.1 platform state;
- update governance/history/time tracking/checksums;
- documentation only.

## Client Data Boundary
The production Design Order `4075_P_DO.XLSX` is external client data. It was inspected as Stage A evidence only and is deliberately absent from this repository/package. Do not add it to future cumulative ZIPs.

## Stage A Verified Facts
- Client form branding: Sridevi Tool Engineers Pvt. Ltd.; workbook field `Customer Name=M&M-MATE` is not used by CR-04.
- `Sheet1` contains the form; `Sheet2` and `Sheet3` are empty.
- Print area: `A1:R39`.
- `A39` normalizes by whitespace collapse to `QR/DG/02 REV 04 03/12/2021`.
- `O5=ST4075 P`.
- Grade block rows 18–26 uses label anchors in A and grade anchors in I.
- Production labels/grades match the approved Stage A table, including workbook spelling `Pressuer Pad` and trailing-space `Core `.
- X marks: C=P-20, D=AL, E=CK-45, F=BE-CU, G=Hardened, H=Nitrided.
- Validation ranges: `I18:L23->$CC$14:$CC$26`, `I24:L24->$CB$29:$CB$31`, `I25:L26->$CC$32:$CC$39`.
- Template defect: `CC27=1.2343/H-11` and `CB28=EN-353` are outside the applied validation ranges.

## Specification Result
Added:
`docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`

The file supersedes v1.4 as the approved Proposal/design direction while retaining the historical v1.4 file unchanged. Feature ID remains `STEEL-GRADE-DESIGN-ORDER-VALIDATION`.

Key v1.5 direction:
- body-attribute steel grade;
- `STEEL_GRADE` / `cmAttString` current direction pending client attribute-name confirmation;
- new `DesignOrderFormat=Form` client profile; Table remains supported;
- configured ModelTitle patterns with optional category-attribute precedence;
- Strict comparison plus closed vocabulary;
- `CompareGradeTokenOnly=false` provisional;
- runtime file picker as implemented;
- normalized Form-label matching;
- D-15(a) retained, D-15(b) deferred;
- mapped blank grade -> `DO_GRADE_MISSING`, unmapped blank category -> no finding;
- Assist Parts excluded.

## Existing Comparison Compatibility
The existing Domain evaluation groups CAD evidence by normalized component key and can therefore accept a category key shared by multiple CAD components and one DO category entry without changing Domain code, provided the future upstream Form/category layer resolves mapping, blank grades and vocabulary first.

A customer requirement for independent per-occurrence match/mismatch findings would require a separately approved Domain semantic change. It is not included in this proposal.

## Protected Byte-Identical Files
The v1.5 spec records the current 0.30.1 hashes for the protected generic tabular reader/orchestration, production body-attribute reader, Domain comparison/normalizer and highlight-safety/highlighter files. The future implementation plan must enforce them through an Architecture guard. Any need to modify one is a stop condition requiring a revised plan and explicit approval.

## Open Client Inputs
1. production ModelTitle naming patterns;
2. final production steel-grade attribute name;
3. suffix meaning/use (`Doosan`, `PCK`, `HH`, `TSHH`);
4. client confirmation of blank-grade semantics;
5. correction/disposition of the two validation-range template-defect values.

## Files Added
- `docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`
- this handoff

## Existing Files Modified
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256` (regenerated after documentation update)

## Protected / Unchanged
- all `src/**`;
- all `tests/**`;
- all `tools/**`;
- solution/project files;
- production config;
- all Cimatron models;
- v1.4 historical spec;
- production workbook is not included.

## Validation
Documentation-only update. Agent did not build, execute tests/coverage/analyzers/SonarQube, launch Cimatron, or run runtime validation. No new runtime PASS is claimed. The latest runtime evidence remains the accepted 0.30.1 workstation gate and production-reader smoke.

## Exact Next Step
Prepare a narrow exact file-by-file implementation plan for the approved v1.5 Form reader/category mapping/configuration/test slice, identify every new/modified file and protected-hash guard, and wait for explicit user approval before any source/config/test edit.
