# CR-04 Slice 3 — In-Process Smoke Planning Session Handoff 0.27.5

## Purpose

This is a documentation/governance-only session handoff. It does **not** implement the proposed in-process plugin smoke. The repository code baseline remains `0.27.5`.

## Governing state

- Phase: 02 — CR Platform Extensions
- Step: 10/3 — CR-04 Slice 3 Cimatron Adapter
- Current code version: `0.27.5`
- Context: **AMBER**
- Slice 2 / Slice 2A: **CLOSED / USER VALIDATED**
- Slice 3 production adapter: implemented, but final live production-adapter wrong-type smoke is **NOT YET VALIDATED**.
- Production adapter itself has **not** failed. Both failed runs below were smoke-harness execution-route failures before valid adapter acceptance evidence was obtained.

## Accepted evidence carried forward

### 0.27.4 helper / wrong-type control

The controlled disposable Part is:

`KA-PART-1-CR04-WRONG-TYPE`

Controlled attribute on body entity 4:

- Name: `CR04_WRONG_TYPE_CONTROL`
- Stored type: `cmAttInteger`
- Value: `2738`

Accepted helper rerun evidence at `2026-10-05T12:57:02.5871775+05:30`:

- `ToolVersion: 0.27.4`
- `ReadBack.Type: cmAttInteger`
- `ReadBack.Value: 2738`
- `PostSetupCmAttStringQuery.Status: READ_ERROR`
- HRESULT `0x80004005`
- `Result: WRONG_TYPE_CONTROL_ATTACHED_AND_READ_BACK`

This proves the genuine wrong-type control exists and the production-shaped `cmAttString` query fails safe rather than returning a conforming-looking string.

### Disposable Assembly

A disposable Assembly containing the wrong-type Part has been prepared for the Slice 3 smoke. Do not use or mutate baseline `KA-ASM-1` for this smoke.

Suggested/used smoke Assembly title:

`KA-ASM-1-CR04-WRONG-TYPE-SMOKE`

## Workstation quality gates

### 0.27.4

`quality-gate-20261005-122845.txt` accepted clean:

- Release x64 build PASS
- 0 warnings / 0 errors
- Architecture tests PASS
- Domain tests PASS
- Application tests PASS
- Cimatron Integration tests PASS
- Infrastructure tests PASS
- Coverage gate PASS
- Local quality gate PASS
- Exit code 0

### 0.27.5

`quality-gate-20261005-132327.txt` accepted clean:

- Release x64 build PASS
- 0 warnings / 0 errors
- Architecture tests PASS
- Domain tests PASS
- Application tests PASS
- Cimatron Integration tests PASS
- Infrastructure tests PASS
- Domain coverage 99.74% (minimum 90%)
- Application coverage 94.88% (minimum 90%)
- DesignChecks coverage 98.34% (minimum 95%)
- Infrastructure coverage 88.24% (minimum 80%)
- CimatronIntegration coverage 2.24% measured / no threshold
- Coverage gate PASS
- Local quality gate PASS
- Completed `2026-10-05T13:24:26.6154143+05:30`
- Exit code 0

## Two invalid live smoke attempts

### Attempt 1 — 0.27.4 external EXE / AppAccess route

The required disposable Assembly was already open in Cimatron. The user ran the environment-gated CimatronIntegrationTests executable.

Observed behavior: a **new Cimatron instance launched**.

Inspection isolated the unwanted launch to the smoke harness no-mutation pre-check in `MutationObservation.Capture()` using:

`interop.CimAppAccess.AppAccess().GetApplication()`

The smoke was marked **INVALID**. No adapter PASS/FAIL was claimed.

### Attempt 2 — 0.27.5 external EXE / CimApplicationProvider route

0.27.5 changed only the test/smoke harness to use:

`interop.CimServicesAPI.CimApplicationProvider().GetApplication()`

The user reran the external CimatronIntegrationTests executable after a clean 0.27.5 quality gate.

Observed failure before adapter validation:

- `COMException 0x80040154`
- `REGDB_E_CLASSNOTREG`
- CLSID `{30CEFEEC-375A-40F5-9804-E9D24C4C56FF}`
- failure at `Cr04TraversalSafetyTests.MutationObservation.Capture()` line 240

This smoke was also **INVALID**. No adapter PASS/FAIL was claimed.

## Authoritative Cimatron API clarification

Authoritative Cimatron API documentation `general/startingcsharpapp.md` was checked after the 0.27.5 failure.

It states:

- For an **EXE Project**, use `interop.CimAppAccess.AppAccess` to obtain the running active Cimatron application. If no application is running, `CimUtilityApp` may create a new one.
- For a **Class Project**, use `interop.CimServicesAPI.CimApplicationProvider` to obtain the current application.

Therefore the 0.27.5 standalone EXE use of `CimApplicationProvider` is not the documented execution model. The external EXE route remains unsuitable for this governed smoke on the user's workstation because the documented `AppAccess` route unexpectedly launched a second instance during the first attempt.

## Recommended next direction — NOT YET IMPLEMENTED

Plan a **developer-only in-process plugin smoke path** that executes inside the already-running Cimatron process/application context.

High-level intent:

1. User opens the disposable smoke Assembly in Cimatron.
2. A developer-only, one-shot plugin command/request executes inside that same Cimatron instance.
3. It calls the real production `CimatronAssemblyBodyAttributeReader` against the active Assembly.
4. It records the same governed smoke evidence without any external COM attach/activation path.
5. It remains read-only and proves no model mutation.

Expected accepted wrong-type outcome remains:

- target occurrence found
- target body observed
- `Present=0`
- `ReadError>=1` (expected for the integer control when queried as `cmAttString`)
- `NoMutation=PASS`
- `Result=FAIL_SAFE_READ_ERROR_OBSERVED`

Hard stop remains:

- any `Present > 0` / conforming-looking string for the genuine wrong-type attribute
- wrong active model/context
- target occurrence/body missing
- mutation detected
- unexpected API/runtime behavior

## Mandatory next-session process

Before implementation, the next agent must:

1. Read all of `AGENTS.md`.
2. Read the governing CR-04 v1.4 specification and relevant Slice 3 handoffs/history.
3. Inspect the current Plugin entry/registration/application-context pattern and the production adapter.
4. Verify any uncertain Cimatron plugin/application-context API behavior against the authoritative `cimatron-api` source.
5. Prepare an exact implementation plan for the developer-only in-process smoke.
6. List every file to create/modify and why.
7. Preserve the one-shot / fail-closed / read-only / no-mutation requirements.
8. Keep the smoke developer-only and removable; do not silently convert it into client-facing behavior.
9. Do not change CR-04 business semantics, traversal, wrong-type classification, FeatureComposition, production configuration, BOM route, D-09(b), D-15(b), Assist Part handling, highlighter, or client packaging cleanup unless separately approved.
10. Obtain explicit user approval before editing files.

## Environment-gated external smoke

Do **not** rerun the current standalone external smoke command again until the execution route is deliberately redesigned and approved.

If environment variables from the failed run remain set, they may be cleared with:

```powershell
Remove-Item Env:CIMATRON_DEV_ENABLE_CR04_SLICE3_WRONG_TYPE_SMOKE -ErrorAction SilentlyContinue
Remove-Item Env:CIMATRON_DEV_CR04_WRONG_TYPE_MODEL_TITLE -ErrorAction SilentlyContinue
```

## Version / packaging decision

This handoff does not change source/test/tool runtime behavior, so the code/product baseline remains `0.27.5`. A new PATCH version should be assigned only when the approved in-process smoke implementation changes repository behavior/files under the project's versioning rules.

## Agent validation statement

The AI agent did not build, run tests/coverage, deploy, or execute Cimatron. Workstation quality-gate and live-smoke observations above are user-supplied evidence.
