# Phase 02 Step 11 — CR-04 Slice 2 Application Handoff — 0.25.0

## Project

Cimatron 2026 customization platform.

## Phase / Step / Version

- Phase: 02 — CR Platform Extensions
- Step: 11 — CR-04 Slice 2 Application Use Case + Ports
- Version: 0.25.0
- Context at preparation: GREEN
- Status: IMPLEMENTATION PREPARED / AWAITING USER QUALITY GATE

## Approval and timing

- User explicitly approved the revised Slice 2 plan and exact file scope.
- Exact approval timestamp was not independently captured and is intentionally left blank in the authoritative time ledger.
- Agent work start: `2026-10-04T19:56:11+05:30`.
- Agent submission timestamp is recorded in `docs/time-tracking/PROJECT-TIMESHEET.csv` when this package is finalized.

## Entering Slice 2A evidence

### Effective inherited suppression

Source: user-supplied `api-capability-cr04-slice2a-20261004-193644.txt` from 2026-10-04.

Observed API rows:

- `CR04_Suppressed_SubAssembly`, path `root/1:14`, `suppressed=0`.
- nested `CR04_Suppressed_Child_Part`, path `root/1:14/1:5`, `suppressed=1`.
- `NoMutation.Result: PASS`.

The user separately observed in Cimatron UI that suppressing or unsuppressing the parent automatically affects the child. Classification for CR-04: **LIVE OBSERVED / VERIFIED FOR EFFECTIVE CHILD SUPPRESSION**. Do not reinterpret the API output as proof that the parent occurrence itself reports `IsSuppressed=true`; it did not in this run.

### Assist Part

**NOT AVAILABLE / NOT VERIFIED.**

UI investigation checked Mold Design, Assembly, Component Operations, component/sub-assembly right-click menus, Component Properties, Add Component, Add from Catalog and command search. No verified Assist Part creation/classification command or property was found. `CR04_Assist_Part_Control` is a normal part only. Do not infer Assist Part state from naming, folder placement, suppression or normal component operations.

Authoritative API documentation confirms `IAssInstance::SubInstances[int iIncludeSuppressed, int iIncludeAssist]` has an Assist-inclusion argument, so Assist Part is a real Cimatron concept; its creation/classification workflow remains unresolved.

### Remaining Slice 2A gates

- top-level CR-04 highlight confirmation;
- D-15(b) placement-specific mapping;
- genuine stored-as-non-string wrong-type attribute control;
- collision-frequency measurement on a customer-like assembly;
- genuine Assist Part enumeration/identity evidence.

Slice 3 remains blocked.

## Approved Slice 2 decisions

- D-01 = A, body-level named attribute only.
- D-09 = (a), configured absolute path only.
- D-10 = first-error, accepted for CR-04.
- D-11 = existing strict/no-trim header behavior; protected tabular files unchanged.
- D-18 = N/A because BOM is not selected.
- D-15(a) = unsafe references omitted based on full highlighter-scope `InstanceId` uniqueness; business status preserved; explanatory message added in Application.
- Missing-name null is provisionally treated as absent; UnsupportedType is never produced by Slice 2.
- D-04 is not defaulted silently. `ComponentKeySource` is explicit in the request. BOM Standard Number is unavailable in this D-01=A increment.

## Files added

Application:

- `src/CimatronCustomization.Application/AttributeObservationStatus.cs`
- `src/CimatronCustomization.Application/BodyAttributeObservation.cs`
- `src/CimatronCustomization.Application/AssemblyBodyAttributeOccurrence.cs`
- `src/CimatronCustomization.Application/AssemblyBodyAttributeSnapshot.cs`
- `src/CimatronCustomization.Application/IAssemblyBodyAttributeReader.cs`
- `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrderRequest.cs`
- `src/CimatronCustomization.Application/DesignOrderInputPathResolver.cs`
- `src/CimatronCustomization.Application/SteelGradeOccurrenceHighlightSafety.cs`
- `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrder.cs`

Application tests:

- `tests/CimatronCustomization.Application.Tests/DesignOrderInputPathResolverTests.cs`
- `tests/CimatronCustomization.Application.Tests/SteelGradeOccurrenceHighlightSafetyTests.cs`
- `tests/CimatronCustomization.Application.Tests/VerifySteelGradeAgainstDesignOrderTests.cs`

Documentation:

- this handoff.

## Existing files modified and reason

- `src/CimatronCustomization.Application/CimatronCustomization.Application.csproj` — explicit Compile entries for approved new Application files.
- `src/CimatronCustomization.Application/Properties/AssemblyInfo.cs` — C-01 production Application metadata bump to `0.25.0.0`.
- `tests/CimatronCustomization.Application.Tests/CimatronCustomization.Application.Tests.csproj` — explicit Compile entries for new test fixtures.
- `tests/CimatronCustomization.Application.Tests/Program.cs` — register new fixtures in the existing custom console test runner.
- `VERSION.md` — current version/step/status/decisions.
- `CHANGELOG.md` — 0.25.0 change record.
- `IMPLEMENTATION-HISTORY.md` — governed implementation/evidence record.
- `docs/time-tracking/PROJECT-TIMESHEET.csv` — mandatory engineering timing/submission ledger.
- `CHECKSUMS.sha256` — regenerated package file manifest.

`tests/CimatronCustomization.Application.Tests/Properties/AssemblyInfo.cs` is not changed: prior production-layer increments do not bump the custom test executable metadata, and no requirement was found to change that convention.

## Functional design

1. Validate D-09(a) absolute DO path. Token paths are rejected/deferred.
2. Read configured DO columns through existing `ReadMappedTabularData`.
3. Component key is transport-required; steel grade is transport-optional. The configured steel-grade header itself is still required.
4. Run Slice 1 Domain input validation before CAD access; stop on Domain Error.
5. Request complete assembly/body snapshot from `IAssemblyBodyAttributeReader`.
6. Keep all highlighter-scope occurrences in the snapshot for D-15 uniqueness; exclude only effective-suppressed occurrences from business evidence.
7. Create Domain CAD evidence with `attributeTypeUnsupported=false` only.
8. Run closed Slice 1 Domain evaluation.
9. Filter unsafe finding references in Application with `SteelGradeOccurrenceHighlightSafety`; preserve business status and append `[HIGHLIGHT_UNAVAILABLE]` where a reference is removed.

## ST06-DF-06

A new Application-level regression test proves that an unexpected programming exception at the tabular orchestration boundary is not rewritten by the Slice 2 use case into `TABULAR_FILE_READ_ERROR`.

This does **not** close ST06-DF-06 globally. `ExcelTabularDataReader` is protected and unchanged; its existing format-exception classification remains a separate platform-hardening decision.

## Validation status

No build/test/coverage/static-analysis/Cimatron execution was performed by the agent.

User must run:

```powershell
& ".\tools\Invoke-QualityGate.ps1"
```

Required result before any corrective/next step:

- Release x64 build PASS;
- 0 warnings / 0 errors;
- Architecture tests PASS;
- Domain tests PASS;
- Application tests PASS;
- Cimatron Integration tests PASS;
- Infrastructure tests PASS;
- coverage gate PASS;
- local quality gate PASS;
- exit code 0.

Application coverage target remains >= 90% for the approved Slice 2 work. No new Cimatron live run is required for this Application-only increment.

## Packaging rule

Per the user's explicit CR-04 packaging instruction, this delivery excludes console captures, API diagnostic `.txt` files, `artifacts/**`, `bin/`, `obj/`, coverage outputs and unrelated historical runtime evidence. Validated conclusions are recorded in governed documentation instead.

## Exact next step

User runs the full quality gate and supplies the complete output file/text. Do not start Slice 3 or any corrective until that evidence is reviewed.
