# CR-04 Slice 3 — Smoke Existing-Session Attach Corrective 0.27.5

## Scope

Narrow approved corrective only: make the development-only Slice 3 production-adapter smoke attach through the same Cimatron application-provider route used by the production adapter instead of launching a second Cimatron instance from the test no-mutation pre-check.

## User evidence carried forward

- `quality-gate-20261005-122845.txt`: Release x64 PASS; 0 warnings / 0 errors; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests PASS; coverage/local gates PASS; exit code 0.
- Controlled helper rerun timestamp `2026-10-05T12:57:02.5871775+05:30`: `ToolVersion: 0.27.4`, `ReadBack.Type: cmAttInteger`, `ReadBack.Value: 2738`, `PostSetupCmAttStringQuery.Status: READ_ERROR`, HRESULT `0x80004005`, result `WRONG_TYPE_CONTROL_ATTACHED_AND_READ_BACK`.
- First adapter smoke attempt: invalid because the test no-mutation capture launched a second Cimatron instance while the required disposable assembly was already open. No smoke PASS is claimed.

## Corrective

- `tests/CimatronCustomization.CimatronIntegrationTests/Cr04TraversalSafetyTests.cs`: replace `interop.CimAppAccess.AppAccess().GetApplication()` in `MutationObservation.Capture()` with `interop.CimServicesAPI.CimApplicationProvider().GetApplication()`.
- `tests/CimatronCustomization.CimatronIntegrationTests/CimatronCustomization.CimatronIntegrationTests.csproj`: switch the test-only direct interop reference from `interop.CimAppAccess` to `interop.CimServicesAPI`.
- Governance/version/history/time/checksum/package records updated.

## Explicit non-changes

No production `src/**` code, CR-04 production adapter behavior, traversal, wrong-type classification, highlighter, Application, DesignChecks, configuration, installer, or Cimatron model behavior is changed.

## Validation status

**AWAITING USER WORKSTATION QUALITY GATE / RE-RUN LIVE ADAPTER SMOKE.**

The agent did not build, execute tests/coverage, deploy, or run Cimatron. After a clean gate, keep the already-prepared disposable assembly active and rerun the environment-gated production-adapter smoke. The smoke must attach to the existing Cimatron session; any new Cimatron launch is a STOP condition.
