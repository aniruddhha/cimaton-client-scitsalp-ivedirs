# Phase 02 / Step 10 — CR-04 v1.5 Session Handoff after 0.39.4

## Project
Cimatron 2026 Customization — CR-04 Steel Grade / Design Order Validation v1.5

## Current version
`0.39.4`

## Context status
AMBER — move to a new ChatGPT session before further implementation.

## Authoritative cumulative baseline
`phase-02-step-10-cr04-v1.5-designchecks-coverage-corrective-0.39.4.zip`

The 0.39.4 package is the current authoritative implementation baseline. This handoff package adds documentation only and does not change production/test behavior beyond that baseline.

## Current requirement direction
For CR-04 Form mode:

1. Cimatron native **Part Type** is the authoritative component-category source.
   - Verified PDM document attribute: `TMPL::Part_Type`.
2. Cimatron native **Part Material** is the authoritative actual material/steel-grade source.
   - Verified PDM document attribute: `TMPL::Material`.
3. Design Order expected material comes from:
   - exactly one selected material-family column marked `X`; and
   - the row `Remark`, which carries the exact expected grade/specification.
4. `Remark` exists only in the Design Order; it is not a Cimatron property.
5. Form-mode category matching trims/collapses whitespace and compares approved category labels case-insensitively.
6. Material/Remark values trim leading/trailing whitespace before the existing approved steel-grade normalization/comparison.
7. Raw source values remain available for evidence/reporting.
8. No `X` plus blank Remark means no material requirement/no finding.
9. Invalid DO combinations fail closed: multiple X markers; X with blank Remark; Remark without X; non-X nonblank marker.
10. Form mode must not fall back to ModelTitle category patterns, BOM Standard Number correlation, BOM Type, Description, or the historical custom `STEEL_GRADE` body attribute.
11. Table mode remains unchanged and retains its existing route.
12. All CR-04 validation remains read-only.

## Verified Cimatron API/runtime facts
The read-only PDM route is runtime-proven:

`occurrence.ModelPid -> IApplication.GetPdm() -> IPdm.RetriveDocAttribute(ModelPid, ref object attrs, "") -> IDocAttribute.Name / Value`

Verified native attributes:
- `TMPL::Part_Type`
- `TMPL::Material`

Controlled live evidence on `Core block` showed:
- `TMPL::Part_Type = Core`
- `TMPL::Material = P-20-2311`
- `ModificationStateChanged=False`

Do not reopen BOM Type or Description as Part Type sources. Do not reintroduce the custom `STEEL_GRADE` attribute as a production fallback.

## Approved category mapping
Cimatron Part Type -> Design Order category row:

- `Cavity` -> `Cavity`
- `Core` -> `Core`
- `Cavity Insert` -> `Cavity Insert`
- `Core Insert` -> `Core Insert`
- `Moving Core` -> `Moving Core`
- `Angular Lifter` -> `Angular Lifter`
- `Pressure Pad` -> workbook row `Pressuer Pad` (client-template typo retained)
- `Wear Pad` -> `Wear Pad`
- `Mould Base` -> `Mould Base`

## 0.39.x implementation sequence and workstation feedback

### 0.39.0 — Native Part Type / Part Material production integration
Implemented the approved production Form-mode redesign around `TMPL::Part_Type`, `TMPL::Material`, and DO X + Remark semantics.

User workstation gate `quality-gate-20261006-211923.txt` failed at compile time:
- `PartTypeCategoryResolver.cs(27,21)`
- `CS1628`: `out` parameter captured inside a LINQ/lambda.

### 0.39.1 — CS1628 corrective
Reworked resolver normalization through a local variable before assigning the `out` parameter.

User workstation gate `quality-gate-20261006-212934.txt`:
- Release x64 build PASS;
- 1 warning / 0 errors;
- Architecture Tests FAIL.

Direct ArchitectureTests run reported:
`CR-04 v1.5 Form reader lost a required read-only or fail-closed source contract.`

### 0.39.2 — Form-reader architecture-contract corrective
Aligned the architecture source guard with the actual existing Form-reader identifiers `selectedFamily` and `rawRemark`; also removed the CA1859 test warning.

User workstation gate `quality-gate-20261006-214154.txt`:
- Release x64 build PASS;
- 0 warnings / 0 errors;
- Architecture Tests FAIL.

Direct ArchitectureTests run reported:
`CR-04 v1.5 native Part Type/Part Material Form orchestration lost a required contract.`

### 0.39.3 — Part-Type orchestration architecture-contract corrective
Aligned architecture source checks with the actual unbracketed code literals `CAD_PART_TYPE_MISSING` and `CAD_PART_TYPE_UNSUPPORTED`; production orchestration remained unchanged.

User workstation gate `quality-gate-20261006-215037.txt`:
- Release x64 build PASS;
- 0 warnings / 0 errors;
- Architecture PASS;
- Domain PASS;
- Application PASS;
- Cimatron Integration PASS;
- Infrastructure PASS;
- coverage collection PASS;
- Domain 99.74% >= 90%;
- Application 91.87% >= 90%;
- Infrastructure 81% >= 80%;
- Cimatron Integration 1.95% measured/no threshold;
- **DesignChecks 92.14% < required 95%**, therefore overall gate FAIL / exit 1.

### 0.39.4 — DesignChecks coverage-only corrective
Approved and implemented as a test-only slice.

Changed test behavior only in:
`tests/CimatronCustomization.Application.Tests/SteelGradeDesignOrderValidationFeatureTests.cs`

Added coverage for existing fail-closed/null configuration branches through the public feature surface. No `src/**` production file changed from 0.39.3.

0.39.4 has **not yet received a user workstation quality-gate result** in this session. Do not claim 0.39.4 PASS until the user supplies that evidence.

## Latest quality status
Authoritative accepted workstation state entering 0.39.4:
- build and all governed test suites PASS;
- 0 warnings / 0 errors;
- only DesignChecks coverage was below threshold at 92.14% versus 95%.

0.39.4 is awaiting the user's full quality gate.

## Exact next step
The new session must first analyze the user's 0.39.4 quality-gate result if supplied.

If it is fully clean:
- do not immediately implement more code;
- record/close the 0.39.4 quality gate under separately approved documentation/governance scope if required;
- then prepare the smallest controlled live Cimatron validation plan for the new native Part Type / Part Material production Form flow;
- wait for explicit approval before any additional file modification or live-validation helper change.

If the 0.39.4 quality gate fails:
- identify the exact failing gate;
- propose one narrow corrective slice only;
- list exact files and reasons;
- wait for explicit approval before editing.

## Files to read first in the new session
1. `AGENTS.md` — read completely.
2. `VERSION.md`.
3. `docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`.
4. `IMPLEMENTATION-HISTORY.md`.
5. `CHANGELOG.md`.
6. `docs/time-tracking/PROJECT-TIMESHEET.csv`.
7. This handoff file.
8. `docs/history/session-handoffs/phase-02-step-10-cr04-v1.5-designchecks-coverage-corrective-0.39.4.md`.
9. Relevant 0.39.x production/test files before proposing any change.

## Governance reminders
- Follow `AGENTS.md` strictly.
- Never implement before presenting exact scope/files/risks/tests and receiving explicit approval.
- Break non-trivial changes into small governed slices.
- Existing files outside approved scope must remain byte-identical.
- User runs build/tests/coverage/Cimatron; agent does not claim execution.
- Maintain `PROJECT-TIMESHEET.csv`; never invent timestamps.
- Keep user feedback/wait time separate from agent active-work time.
- Cumulative ZIP only; root exactly `cimatron-customization/`.
- Include `CHECKSUMS.sha256` and package SHA-256.
- Exclude raw console captures, coverage artifacts, client workbook/models, and runtime evidence unless explicitly approved.
