# Phase 02 / Step 10 / CR-04 v1.5 — Part Material Correlation Diagnostic — 0.38.3

## Status

Diagnostic implementation prepared. **Awaiting user workstation quality gate.**

## Entering evidence

- `quality-gate-20261006-162607.txt`: 0.38.2 Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0. Raw evidence is not packaged.
- Controlled 0.38.2 live CR-04 Result Report: prior `TABULAR_HEADERS_CHANGED` blocker is gone and native Part Material evaluation is reached. `CoreInsert` matches, while Cavity/Core and several other categories expose correlation/evaluation discrepancies. Raw CSV is not packaged.
- User-supplied Cimatron UI evidence shows `Cavity block` native Part Material = `P-20-2311`; therefore the Cavity missing-grade result is treated as a correlation problem until diagnostic evidence proves otherwise.

## Diagnostic

- Adds a one-shot, 30-minute, read-only Plugin diagnostic.
- Reuses `CimatronAssemblyBodyAttributeReader`, `CimatronBomMaterialTableReader`, `ExcelTabularDataReader`, and `SteelGradeCategoryResolver`.
- Targets only the approved ModelTitles: `Cavity block`, `Core block`, `main insert`, `Insert#2`, `Main Core insert`, `core fix insert-01`, `Slider-01`, `Lifter-01`.
- Captures occurrence path, InstanceId, occurrence `ModelTitle`, exact production BOM `Standard Number`, BOM `Material`, resolved category, and correlation result.
- Also captures the complete BOM `Standard Number` / `Material` snapshot so any non-exact naming divergence can be diagnosed without changing production matching logic.

## Boundaries

No production CR-04 comparison logic, category mapping, Design Order handling, vocabulary, model/workbook mutation, save path, dependency, Cimatron API route, or `STEEL_GRADE` fallback is changed. The eight v1.5 protected files remain byte-identical.

## Validation

Agent performed static/source/XML/hash/package checks only and did not execute MSBuild, tests, coverage, analyzers, SonarQube, or Cimatron. User must run the workstation quality gate before the controlled live diagnostic.

After workstation QG passes, run:

`powershell.exe -ExecutionPolicy Bypass -File ".\tools\Request-Cr04PartMaterialCorrelationDiagnostic.ps1"`

Keep the updated CR-04 test-copy Assembly active and click **Cimatron Customization** once within 30 minutes. Send back the generated `cr04-part-material-correlation-diagnostic-*.txt` evidence file.
