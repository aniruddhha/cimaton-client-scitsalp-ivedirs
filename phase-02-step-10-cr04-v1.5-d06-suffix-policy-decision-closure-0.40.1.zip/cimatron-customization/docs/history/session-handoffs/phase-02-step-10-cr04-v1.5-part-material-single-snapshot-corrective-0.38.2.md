# Phase 02 / Step 10 / CR-04 v1.5 — Part Material Single-Snapshot BOM Read Corrective — 0.38.2

## Status

Corrective implementation prepared. **Awaiting user workstation quality gate.**

## Entering evidence

- `quality-gate-20261006-161418.txt`: 0.38.1 Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0. Raw evidence is not packaged.
- Controlled 0.38.1 live CR-04 CSV: one `CAD_PART_MATERIAL_READ_ERROR` with `TABULAR_HEADERS_CHANGED`; material comparison was not reached. Raw CSV is not packaged.

## Corrective

- Removed the CR-04 Part Material adapter's independent `ExpectedBomHeaders` contract.
- The adapter still performs exactly one Cimatron `IBOM.Export(... cmNoFiltering ...)` to a governed temporary directory.
- It then parses that exact exported CSV once via `ITabularDataReader.Read(source)`.
- Required fields are resolved by name from the same snapshot: `Standard Number -> ModelTitle`, `Material -> Part Material`.
- Missing required columns/values continue to fail closed through existing tabular-reader results.
- Architecture and CimatronIntegration source guards protect the one-read path and prohibit reintroducing `ExpectedBomHeaders`.

## Boundaries

No new Cimatron API, dependency, category mapping, Design Order behavior, model/workbook mutation, save path, or `STEEL_GRADE` fallback. Native Part Material remains the sole production steel-grade source. The eight v1.5 protected files remain byte-identical.

## Validation

Agent performed static/source/project/hash/package checks only and did not execute MSBuild, tests, coverage, analyzers, SonarQube, or Cimatron. User must run the workstation quality gate before repeating controlled live validation.
