# Phase 02 — Step 09 — CR-04 Slice 1 Domain Rules — 0.23.0

## Project
Cimatron 2026 customization platform.

## Phase / Step
- Phase: 02 — CR Platform Extensions
- Step: 09 — CR-04 Slice 1 Domain Rules
- Version: 0.23.0
- Context: GREEN
- Status: **IMPLEMENTATION PREPARED / AWAITING USER EXECUTION**
- Latest prior approved package: `phase-02-step-08b-closure-0.22.2.zip`

## Approved scope

Pure Domain implementation only for CR-04 Steel Grade Design-Order Validation. No Application orchestration, Cimatron adapters, config, registration, Plugin behavior, or highlighter changes.

Approved provisional decisions:
- D-08: DO-only -> Failed; grade-bearing CAD-only -> Warning; CAD-only without grade -> not reported.
- D-14: 0 distinct CAD values -> missing; 1 -> usable; >1 -> ambiguous Failed; duplicate normalized DO key -> Error.
- D-16: blank DO grade -> `DO_GRADE_MISSING` Error pending customer confirmation.

## Files added

### Production Domain
- `SteelGradeRepresentation.cs`
- `SteelGradeComparisonPolicy.cs`
- `SteelGradeNormalizer.cs`
- `NormalizedSteelGrade.cs`
- `ComponentKeyNormalizer.cs`
- `DesignOrderSteelGradeEntry.cs`
- `CadComponentSteelGradeEvidence.cs`
- `SteelGradeDesignOrderEvaluation.cs`

### Tests
- `SteelGradeNormalizerTests.cs`
- `ComponentKeyNormalizerTests.cs`
- `SteelGradeDesignOrderEvaluationTests.cs`

## Existing files modified

- Domain `.csproj`
- Domain.Tests `.csproj`
- Domain.Tests `Program.cs`
- Domain `Properties/AssemblyInfo.cs`
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256`

## Implementation notes

- Comparison remains text-based; there is no floating-point grade comparison.
- D-05 Strict and WerkstoffCanonical are policy choices supported by the Domain model.
- D-06 token-only comparison is a policy flag.
- Entity references supplied to Domain are treated as already safety-filtered; Slice 1 does not resolve Cimatron occurrence identity.
- An explicit evidence flag can represent `STEEL_GRADE_ATTRIBUTE_TYPE_UNSUPPORTED`, but no Cimatron runtime mapping to that state is assumed; Slice 2A decides whether that state is actually observable.
- Option C body-attribute/BOM disagreement is represented as pure Domain behavior without selecting D-01.

## Step 08B C-02 note

Implementation history now records the evidence-backed correlation prefixes for the distinct Result Report and later Highlight interactions and makes the CR-04 rule explicit: every future execution/highlight correlation must be recorded.

## User-run validation required

Run the repository quality gate from the real workstation. The expected status before execution is **AWAITING USER EXECUTION**; no PASS is claimed by this package.

In addition to the ordinary gate, inspect generated Cobertura coverage for the new CR-04 Domain classes. Required Slice 1 evidence is:
- new CR-04 Domain rules: >=95% line coverage;
- new CR-04 Domain rules: >=90% branch coverage.

The existing overall Domain 90% coverage gate alone is not sufficient proof of these Slice 1 targets.

## Not part of this slice

- exact production `FindInstance()`-scope traversal;
- self-instance component exclusion/runtime pattern;
- D-15 collision safety and collision-frequency measurement;
- Cimatron missing-name / wrong-type attribute semantics;
- assist-part behavior;
- top-level/suppressed-parent runtime confirmation;
- Application ports/use case;
- Cimatron adapters;
- feature/config registration.

These remain later Slice 2/2A+ work according to the approved CR-04 specification.

## Exact next action

User runs the governed quality gate for 0.23.0 and returns the complete console capture plus class-level Cobertura evidence for the new CR-04 Domain classes. Do not begin Slice 2 or Slice 2A implementation until this feedback has been reviewed and the next scope is separately approved.
