# Phase 02 / Step 10/3 — CR-04 Slice 3 Architecture-Boundary Corrective Handoff — 0.27.8

## Status

**AWAITING USER WORKSTATION QUALITY GATE.** Do not run the live in-process Cimatron smoke until the full governed gate is clean.

## Trigger / evidence entering this corrective

The user workstation 0.27.7 gate built Release x64 successfully with 0 warnings / 0 errors, but then failed architecture tests and exited 1. The standalone architecture test reported that Plugin references were invalid: expected Application, Automations, CimatronIntegration, DesignChecks, Infrastructure; actual also included Domain. Therefore 0.27.7 is superseded and is not an acceptable architecture baseline.

## Approved corrective implemented

1. Removed the direct `CimatronCustomization.Plugin -> CimatronCustomization.Domain` project reference added in 0.27.7.
2. Added developer-only `Cr04WrongTypeSmokeProbe` in CimatronIntegration. It calls the unchanged production `CimatronAssemblyBodyAttributeReader`, resolves the controlled target/body and counts Present/Absent/ReadError inside CimatronIntegration, then returns only primitive evidence to Plugin.
3. Plugin smoke still owns the in-process application/document check, exact disposable Assembly title gate, before/after no-mutation snapshot, final hard-stop/acceptance result, evidence file and UI result.
4. Updated only the smoke-specific architecture guard to enforce the new boundary. The core project-reference rule still forbids Plugin→Domain and was not weakened.
5. Plugin and CimatronIntegration assembly/file versions are `0.27.8.0`.

## Protected behavior unchanged

- `CimatronAssemblyBodyAttributeReader` source and semantics.
- CR-04 business semantics, occurrence traversal, wrong-type fail-safe rule and acceptance criteria.
- FeatureComposition/config, BOM route, D-09(b), D-15(b), Assist Part handling, highlighter and client cleanup.
- One-shot request protocol remains version `0.27.6`; this protocol did not change.

## Required next workstation action

Run from repository root:

```powershell
& ".\tools\Invoke-QualityGate.ps1"
```

Required before live smoke: Release x64 PASS, 0 warnings, 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0. Send the full capture back for review.

## If the quality gate is clean

Only then proceed to the already-approved in-process smoke against saved disposable Assembly `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`. Accepted live evidence remains:

- `Present=0`
- `ReadError>=1`
- `NoMutation=PASS`
- `Result=FAIL_SAFE_READ_ERROR_OBSERVED`

Any `Present>0` remains a hard stop.

## AI execution boundary

The agent did not run the Windows/.NET Framework quality gate, tests/coverage, deploy or Cimatron. No PASS is claimed for 0.27.8.

## Package

- ZIP: `phase-02-step-10-cr04-slice-3-architecture-boundary-corrective-0.27.8.zip`
- ZIP SHA-256: calculated after final packaging and reported at delivery (not embedded to avoid self-referential package hashing).
- Agent active work: `2026-10-05T14:26:40+05:30` to `2026-10-05T14:31:02+05:30` (waiting time excluded).
