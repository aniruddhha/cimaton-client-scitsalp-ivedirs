# Phase 02 Step 10 — CR-04 v1.5 Native Part Properties Production Integration — 0.39.0

## Project

Cimatron 2026 customization platform.

## Phase / Step / Version

- Phase: 02 — CR Platform Extensions
- Step: 10 / CR-04 v1.5 — Native Part Type / Part Material production integration
- Version: 0.39.0
- Context at preparation: GREEN
- Status: IMPLEMENTATION PREPARED / AWAITING USER QUALITY GATE

## Approval and timing

- User explicitly approved the exact 0.39.0 production plan and the later clarification requiring trim/space handling and all previously agreed fail-closed checks.
- Exact approval receipt timestamp was not independently captured and is intentionally left blank in the authoritative time ledger.
- Agent active-work start: `2026-10-06T20:26:28+05:30`.
- Agent submission timestamp is recorded in `docs/time-tracking/PROJECT-TIMESHEET.csv` when the cumulative package is finalized.

## Entering validated evidence

The 0.38.6 workstation gate supplied by the user (`quality-gate-20261006-194848.txt`) passed:

- Release x64 build;
- 0 warnings / 0 errors;
- Architecture, Domain, Application, CimatronIntegration and Infrastructure suites;
- coverage collection/gate;
- local quality gate;
- exit code 0.

Controlled read-only runtime diagnostics then established the production property identities:

- `TMPL::Part_Type` is File Properties **Part Type**; controlled `Core block` evidence returned `Core`;
- `TMPL::Material` is File Properties **Part Material**; after the user set `Core block` Part Material to `P-20-2311`, the API returned `P-20-2311`;
- the later diagnostic read all 8 controlled target occurrences and reported `ModificationStateChanged=False`;
- DO `Remark` is a Design Order field only, not a Cimatron Part property.

Raw workstation/runtime evidence remains external to the cumulative ZIP.

## Approved production rule

Form mode now follows this chain:

`Assembly occurrence ModelPid -> GetPdm() -> RetriveDocAttribute(..., ref object, "") -> TMPL::Part_Type / TMPL::Material`

Then:

1. normalized native Part Type selects the approved Design Order category;
2. native Part Material is the actual CAD material value;
3. the Design Order row must contain exactly one selected material-family `X` and a nonblank `Remark` to define a requirement;
4. trimmed `Remark` is the exact expected grade/specification supplied to the existing steel-grade normalization/comparison policy.

Approved Cimatron Part Type mappings:

- `Cavity` -> `Cavity`;
- `Core` -> `Core`;
- `Cavity Insert` -> `CavityInsert`;
- `Core Insert` -> `CoreInsert`;
- `Moving Core` -> `MovingCore`;
- `Angular Lifter` -> `AngularLifter`;
- `Pressure Pad` -> logical `PressurePad`, workbook production label `Pressuer Pad`;
- `Wear Pad` -> `WearPad`;
- `Mould Base` -> `MouldBase`.

Material-family selector columns in the approved Sridevi profile are C:H: `P-20`, `AL`, `CK-45`, `BE-CU`, `Hardened`, `Nitrided`. Remark is column I.

## Normalization and fail-closed rules

- leading/trailing whitespace is trimmed for values participating in matching/comparison;
- whitespace-only values are blank;
- Part Type and Design Order category labels collapse repeated internal whitespace and compare case-insensitively;
- Part Material and Remark retain punctuation and use only the already approved steel-grade normalization/comparison policy after trim;
- raw native Part Type / Part Material and raw DO Remark remain available in typed results for evidence/reporting;
- exactly one case-insensitive trimmed `X` + nonblank Remark = requirement;
- no X + blank/whitespace-only Remark = no requirement / no steel-grade finding for that category;
- multiple X = input Error;
- X + blank Remark = input Error;
- nonblank Remark + no X = input Error;
- any nonblank selector marker other than X = input Error;
- blank Part Type = controlled Warning, no fallback;
- unsupported Part Type = controlled Warning, no fallback;
- required mapped component with blank Part Material = controlled Error;
- unknown CAD material / unknown DO Remark vocabulary retain controlled Warning behavior.

There is no Form fallback to Description/Details, BOM `Type`, ModelTitle category patterns, BOM Standard Number correlation, or historical `STEEL_GRADE`.

## New files

- `src/CimatronCustomization.Application/IPartDocumentPropertyReader.cs`
- `src/CimatronCustomization.Application/PartDocumentPropertyResult.cs`
- `src/CimatronCustomization.Application/DesignOrderFormMaterialFamilyDefinition.cs`
- `src/CimatronCustomization.Application/PartTypeCategoryResolver.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronPartDocumentPropertyReader.cs`
- `tests/CimatronCustomization.Application.Tests/PartTypeCategoryResolverTests.cs`
- this handoff.

## Existing files modified

Production/application/configuration:

- `src/CimatronCustomization.Application/CimatronCustomization.Application.csproj`
- `src/CimatronCustomization.Application/DesignOrderFormCategoryDefinition.cs`
- `src/CimatronCustomization.Application/DesignOrderFormCategoryRecord.cs`
- `src/CimatronCustomization.Application/DesignOrderFormProfile.cs`
- `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrder.cs`
- `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrderRequest.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronCustomization.CimatronIntegration.csproj`
- `src/CimatronCustomization.DesignChecks/SteelGradeDesignOrderValidation.cs`
- `src/CimatronCustomization.Infrastructure/ExcelDesignOrderFormReader.cs`
- `src/CimatronCustomization.Infrastructure/SrideviQrDg02Rev04Profile.cs`
- `src/CimatronCustomization.Plugin/FeatureComposition.cs`
- `src/CimatronCustomization.Plugin/Properties/AssemblyInfo.cs`
- `config/CimatronCustomization.config.xml`

Tests/guards:

- `tests/CimatronCustomization.Application.Tests/CimatronCustomization.Application.Tests.csproj`
- `tests/CimatronCustomization.Application.Tests/Program.cs`
- `tests/CimatronCustomization.Application.Tests/SteelGradeDesignOrderValidationFeatureTests.cs`
- `tests/CimatronCustomization.Application.Tests/VerifySteelGradeAgainstDesignOrderTests.cs`
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`
- `tests/CimatronCustomization.Infrastructure.Tests/ExcelDesignOrderFormReaderTests.cs`

Governance/documentation:

- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`
- `docs/platform/CIMATRON-2026-API-CAPABILITY-VERIFICATION.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256`

## Protected byte-identical files

Static comparison against the authoritative 0.38.6 baseline confirms these remain byte-for-byte identical:

- `src/CimatronCustomization.Infrastructure/ExcelTabularDataReader.cs`
- `src/CimatronCustomization.Application/ReadMappedTabularData.cs`
- `src/CimatronCustomization.Application/TabularMappingEngine.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs`
- `src/CimatronCustomization.Domain/SteelGradeDesignOrderEvaluation.cs`
- `src/CimatronCustomization.Domain/SteelGradeNormalizer.cs`
- `src/CimatronCustomization.Application/SteelGradeOccurrenceHighlightSafety.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityHighlighter.cs`
- `tests/CimatronCustomization.ArchitectureTests/Program.cs`

## Compatibility and historical diagnostics

- Table mode remains on the existing BOM material route and is intentionally unchanged.
- The 0.38.x ModelTitle/BOM-correlation and `STEEL_GRADE` diagnostics remain historical/developer evidence; they are not production sources in 0.39.0.
- Production configuration no longer carries `ComponentCategoryPatterns`; therefore superseded diagnostics that expected that historical production configuration are not part of 0.39.0 validation.

## Validation state

The agent did **not** execute build, tests, coverage, analyzers, SonarQube, or Cimatron runtime validation.

The user must first run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Required result before live validation:

- Release x64 build PASS;
- 0 warnings / 0 errors;
- Architecture PASS;
- Domain PASS;
- Application PASS;
- CimatronIntegration PASS;
- Infrastructure PASS;
- coverage gate PASS;
- local quality gate PASS;
- exit code 0.

Only after that evidence is reviewed should controlled live 0.39.0 Form validation begin.

## Packaging

The cumulative package excludes `artifacts/**`, console captures, coverage output, `bin/`, `obj/`, client Design Order workbooks, and Cimatron model files. `CHECKSUMS.sha256` is regenerated from the final package content.
