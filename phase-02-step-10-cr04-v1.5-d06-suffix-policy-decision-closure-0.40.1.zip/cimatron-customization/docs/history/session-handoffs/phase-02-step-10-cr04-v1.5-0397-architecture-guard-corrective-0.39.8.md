# Phase 02 / Step 10 / CR-04 v1.5 — 0.39.7 Architecture-Guard Corrective — 0.39.8

## Entering evidence

- `quality-gate-20261007-002443.txt`: Release x64 build PASS with 0 warnings / 0 errors; Architecture Tests FAIL; gate exits before later suites/coverage.
- The 0.39.7 production change to `CimatronAssemblyBodyAttributeReader.cs` was explicitly approved and packaged, but the CR-04 v1.5 protected-file hash map in `ArchitectureBoundaryTests.cs` still carried the pre-0.39.7 SHA-256 for that file.

## 0.39.8 corrective

- Update only the protected SHA-256 entry for `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs`.
- Old guard hash: `6335016dbc2edc1aa27272a195e290cd43bcf2f25ec79ce197051900090032df`.
- Verified 0.39.7 file hash: `7fede8fcd63d4bbad4213110cc561c5b78f2b41d1cc57d64623398c283106368`.
- No production `src/**` change.
- No CR-04 behavior, threshold, configuration, traversal, native Part Type/Part Material, or other architecture-guard change.

## User acceptance sequence

Run the full workstation quality gate:

`powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"`

If the gate passes, continue with the already-approved controlled live 0.39.7/0.39.8 Form rerun using the same test-copy assembly and external client DO. Expected live behavior remains: Cavity/Core/CoreInsert matches stay intact; former non-Part PDM errors appear as `CAD_NON_PART_SKIPPED` Info; genuine Part read failures remain Errors; assembly remains unmodified.

## Validation state

Agent performed static source/hash/package checks only. Full workstation quality gate and subsequent Cimatron rerun remain user-run acceptance steps.
