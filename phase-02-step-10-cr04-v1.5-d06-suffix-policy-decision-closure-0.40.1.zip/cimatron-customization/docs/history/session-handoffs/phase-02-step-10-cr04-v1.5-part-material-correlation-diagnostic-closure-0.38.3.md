# Phase 02 / Step 10 / CR-04 v1.5 — Part Material Correlation Diagnostic Closure — 0.38.3

## Status

**0.38.3 workstation quality gate PASS. Controlled live read-only correlation diagnostic COMPLETED. Current BOM correlation route is insufficient for six of eight approved targets.**

## Entering validation evidence

### Workstation quality gate

User supplied `quality-gate-20261006-164624.txt` (raw evidence intentionally excluded from the cumulative ZIP):

- Release x64 build: PASS
- Warnings: 0
- Errors: 0
- Architecture tests: PASS
- Domain tests: PASS
- Application tests: PASS
- CimatronIntegration tests: PASS
- Infrastructure tests: PASS
- Coverage collection: PASS
- Coverage gate: PASS
- Local quality gate: PASS
- Exit code: 0
- Gate capture started: `2026-10-06T16:46:24.2836871+05:30`
- Gate completed: `2026-10-06T16:47:28.0677016+05:30`

Coverage reported by the supplied gate:

- Domain: 99.74%
- Application: 92.33%
- DesignChecks: 95.95%
- Infrastructure: 82.27%
- CimatronIntegration: 1.98% measured, with no threshold introduced

### Controlled live diagnostic

User supplied `cr04-part-material-correlation-diagnostic-20261006-165650.txt` (raw runtime evidence intentionally excluded from the cumulative ZIP).

Evidence facts:

- `ExecutionContext=IN_PROCESS_PLUGIN`
- `ReadOnlyDiagnostic=true`
- `OccurrenceReader=CimatronAssemblyBodyAttributeReader`
- `PartMaterialReader=CimatronBomMaterialTableReader`
- Production correlation under test: case-insensitive `ModelTitle` ↔ BOM `Standard Number`
- Target occurrences: 8
- BOM rows captured: 6
- Result: `READ_ONLY_CORRELATION_DIAGNOSTIC_COMPLETED`

Exact matches:

- `Lifter-01` → BOM Standard Number `Lifter-01` → Material `P20`
- `core fix insert-01` → BOM Standard Number `core fix insert-01` → Material `P-20-2311`

No exact BOM Standard Number match:

- `Cavity block`
- `Core block`
- `Main Core insert`
- `main insert`
- `Insert#2`
- `Slider-01`

## Conclusion

The diagnostic confirms that exact BOM `Standard Number` correlation cannot reliably provide native Part Material for the approved target set. Only two of eight target occurrences correlate through the current route.

This is a **correlation limitation**, not evidence that the six unmatched Parts lack native Part Material. User-provided Cimatron UI evidence separately shows `Cavity block` native `Part Material = P-20-2311`.

Therefore the next engineering investigation must target a **direct Part-level Cimatron API read of the native Part Material property**, rather than attempting to repair production behavior by guessing non-exact BOM-name matching rules.

## Production rule retained

- Authoritative CR-04 Steel Grade source: native Cimatron `Part Material`.
- Compare native Part Material against the Design Order Steel Grade.
- Validation remains read-only.
- Do not silently fall back to the legacy custom `STEEL_GRADE` body attribute.
- Blank/unreadable native Part Material must remain an explicit validation/read-error outcome, not be masked by fallback data.

## Package scope

This closure package changes documentation/governance/checksums only. It does **not** change:

- production source code;
- production configuration;
- category mapping;
- Design Order reader/orchestration;
- steel-grade vocabulary or normalization;
- Cimatron API route;
- model/workbook data;
- dependencies;
- diagnostic implementation.

Raw quality-gate, Cimatron runtime evidence, console captures, production client workbook, and Cimatron models are excluded from the cumulative ZIP.

## Next step

Start a new session from this cumulative package. Before editing anything:

1. read `AGENTS.md` completely;
2. read the CR-04 v1.5 specification and latest `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`;
3. inspect the current `CimatronBomMaterialTableReader` and relevant verified Cimatron API capability documentation;
4. investigate the smallest read-only route for direct Part-level native Part Material access;
5. list every proposed file change and test/validation boundary;
6. wait for explicit user approval before implementation.

Do not invent Cimatron APIs and do not broaden correlation rules as a substitute for verifying the native Part-level API.
