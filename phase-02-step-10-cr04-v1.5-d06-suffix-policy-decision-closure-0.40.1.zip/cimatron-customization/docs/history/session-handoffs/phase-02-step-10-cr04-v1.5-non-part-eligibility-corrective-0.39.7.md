# Phase 02 / Step 10 / CR-04 v1.5 — Non-Part Form Eligibility Corrective — 0.39.7

## Entering evidence

- `quality-gate-20261006-233537.txt`: 0.39.6 full workstation quality gate PASS, 0 warnings / 0 errors, all governed suites and coverage/local gates PASS, DesignChecks 100%, exit 0.
- `Cimatron-Result-Report-20261007-000856.csv`: controlled production Form run proves Cavity, Core, and CoreInsert native Part Type + native Part Material matching at `P-20-2311`; seven non-Part/higher-level occurrences produced identical Part-PDM range errors. Client/model CSV evidence remains external and is not packaged.

## Root cause

The approved assembly reader intentionally retains the complete highlighter-equivalent occurrence traversal. Form-mode orchestration did not distinguish occurrence model type before invoking the Part-specific PDM property reader, so assembly/non-Part PIDs could reach `IPartDocumentPropertyReader`.

## 0.39.7 corrective

- Preserve every traversal occurrence and existing recursive/suppression/body behavior.
- Carry `IModel.Type.ToString()` into `AssemblyBodyAttributeOccurrence.ModelType`.
- In Form mode, after configured exclusion handling, invoke the native Part-property reader only when `ModelType == "cmPart"` using ordinal comparison.
- Emit `[CAD_NON_PART_SKIPPED]` / `Info` for non-Part occurrences.
- Preserve genuine Part property-read failures as Errors.
- No ModelTitle fallback or DO/config/threshold/mutation change.

## User acceptance sequence

1. Run full workstation quality gate:
   `powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"`
2. If PASS, restart Cimatron so 0.39.7 assemblies are loaded.
3. Open the same CR-04 test-copy assembly used for the successful 0.39.6 run.
4. Run **Steel Grade Design-Order Validation** against the same external client DO.
5. Export Result Report CSV outside the repository.
6. Expected: Cavity/Core/CoreInsert `STEEL_GRADE_MATCH` evidence remains; former non-Part PDM read errors become `CAD_NON_PART_SKIPPED` Info findings; genuine Part failures, if any, remain Errors.
7. Confirm the assembly remains unmodified.

## Validation state

Agent performed static/source/package checks only. Workstation quality gate and Cimatron live rerun are user-run and are required before closure.
