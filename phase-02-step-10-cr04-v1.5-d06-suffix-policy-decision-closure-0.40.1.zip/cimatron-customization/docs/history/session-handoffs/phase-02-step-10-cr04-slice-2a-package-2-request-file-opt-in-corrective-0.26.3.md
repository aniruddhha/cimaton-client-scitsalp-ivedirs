# Phase 02 — CR-04 Slice 2A Package 2 Request-File Opt-In Corrective — 0.26.3

## Status
- Project: Cimatron 2026 Customization
- Phase: 02 — CR Platform Extensions
- Step: 10/2A — CR-04 Slice 2A Package 2 Top-Level Highlight Diagnostic
- Version: 0.26.3
- Context: GREEN
- Package 2 workstation quality gate entering evidence: PASS / USER VALIDATED from `quality-gate-20261005-001015.txt`.
- 0.26.3 quality gate: NOT RUN by the AI agent; user execution required.
- Live diagnostic: NEVER RUN. The single governed live run remains unused.
- Slice 3: BLOCKED.

## Governing plan
`docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md` was restored from Package 1 and verified byte-identical with SHA-256:
`6b6d3f9ca1c2c56bbce45a3b438e37b8a5baba25d4de917a37c5ae6ce7b9d320`.

Approved dispositions remain unchanged: D-15(b) DEFERRED; D-15(a) mandatory; first-match fallback prohibited; collision-frequency MOVED TO SLICE 5; D-17 Assist Parts EXCLUDED-PROVISIONAL with top-level assist exclusion UNVERIFIED; wrong-type semantics FAIL-SAFE RULE with genuine control deferred to Slice 3 adapter smoke.

## User-supplied startup evidence recorded
- Application Error 1000 at `2026-10-05 00:19:29` and `00:20:26 +05:30`: `CimatronE.exe` version `2026.201.2064.662`, `ucrtbase.dll` `10.0.26100.9444`, exception `0xc0000409`, offset `0x00000000000a527e`.
- WER 1001 BEX64 followed at `00:19:42` and `00:20:34`; P9 `0000000000000007`.
- No .NET Runtime event was observed between 00:18 and 00:22. Newest WER contained 484 modules and none matching `CimatronCustomization*`; CLR modules were loaded.
- WER archives on `2026-09-24 14:02:47`, `14:03:32`, `14:04:16` and `2026-10-05 00:19:42`, `00:20:34` share signature hash `7219b3c5d95cc49671cc40693829127e67932033_70c7052e`.
- Before the normal control, the historical diagnostic variable was empty at Process/User/Machine scope; session was not elevated; no CimatronE process existed.
- Normal shortcut start failed before PC restart without a recorded crash event. After restart, normal shortcut start succeeded with 0.26.2 deployed. Feature Launcher showed exactly five normal features; the CR-04 diagnostic was absent; no feature was run. Start/exit times were not captured.
- Conclusion: transient workstation/Cimatron fault cleared by restart; root cause not established. Package 2 code and the historical environment-variable opt-in are not implicated. The live diagnostic has never run; the single governed live run is unused.

## 0.26.3 corrective implemented
- Replaced the retired environment-variable gate with one-shot `TopLevelHighlightDiagnosticRequest.TryConsume()` registration.
- Added request class and explicit old-style Plugin project Compile entry.
- Added `tools/Request-TopLevelHighlightDiagnostic.ps1`; creates/cancels a two-line UTF-8-no-BOM request; never launches Cimatron and never sets environment variables.
- Request is accepted only for `Version=0.26.3` and an `O`-format `RequestedUtc` 0–30 minutes old; invalid/stale request returns false with one warning; consumed request is deleted in `finally`.
- Reader now has one outer exception boundary after argument checks; any exception becomes Error `[TOPLEVEL_HIGHLIGHT_API_ERROR]` with no reference.
- Before-snapshot is captured immediately after active-document acquisition.
- Assembly title uses `(assembly as IModel).Title`, `OrdinalIgnoreCase`, and reports the observed title on mismatch.
- No-mutation is tri-state: `NotEvaluated`, `Unchanged`, `Changed`; Changed becomes `[TOPLEVEL_HIGHLIGHT_MUTATION_DETECTED]` with no reference.
- Feature target-ready contract is exactly `Passed + reference + Unchanged`; otherwise Error `[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR]` with no reference. Evidence prints `PASS`, `CHANGED`, or `NOT_EVALUATED`.
- Existing feature test file adds the three approved contract cases.
- Architecture guards enforce exact whitespace-insensitive TryConsume registration, retired env-var absence from `src/`/`tools/`, request-filename isolation, prohibited reader APIs/known-answer literals, explicit Plugin Compile entry, and the unchanged protected highlighter hash.
- Plugin, CimatronIntegration, Application and DesignChecks assembly/file versions are `0.26.3.0` only.

## A5 — reference-format source citation
The Package 2 diagnostic creates `entity|<instanceId>|<base64(model PID)>|<entityId>` in `src/CimatronCustomization.CimatronIntegration/CimatronTopLevelHighlightDiagnosticReader.cs` lines **197–200**. Step 08B's occurrence reader creates the same four-part layout in `src/CimatronCustomization.CimatronIntegration/CimatronOccurrenceEntityAttributeReader.cs` lines **168–175**. Step 08B passes that `NestedBodyReference` through assembly mapping and then into the Result Report finding in `src/CimatronCustomization.DesignChecks/Step08BInProcessConfirmationFeature.cs` lines **116–148**. The production highlighter parses four pipe-separated parts and decodes the PID at `src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityHighlighter.cs` lines **73–93**, then resolves the occurrence, validates PID and maps the occurrence entity into active Assembly context at lines **145–165**. The protected highlighter SHA-256 remains `c048b330f856da970b9f66fa0c196509b1b61d163861dba6bfdd5112095ffaf9`.

## Client-packaging blocker
Before any client package, remove under separately approved scope: Package 2 registration, all **8 diagnostic source files** (the existing seven plus `TopLevelHighlightDiagnosticRequest.cs`), `tools/Request-TopLevelHighlightDiagnostic.ps1`, and the **2 diagnostic test files**. This diagnostic must not ship to a client.

## Changed-file table — substantive 0.26.2 → 0.26.3 files
| File | 0.26.2 SHA-256 | 0.26.3 SHA-256 |
|---|---|---|
| `CHANGELOG.md` | `1a54cf4f763d92d5b86baca9d58a82411520b64e915693e012229ec164949cfe` | `942287a7ae97c434ea9e069ca5fa163d82afd4ec311ec467440f6129584be24c` |
| `IMPLEMENTATION-HISTORY.md` | `b29c39862fce2665b33a8f42f3e6de1694a22ce8a30d3ffddce8039f256c2b3b` | `932651e141ab578cc60574ec75f603f7871fd9a8bc56a07f938013542dc5b05e` |
| `VERSION.md` | `a21284c502a31fe5e1d2f110e5c0add2b13b66418312981453ce4828d9fb516d` | `82237fd1b29ec3725c8af12c63938a198d49bc918ca894ec83aec997391c9c2f` |
| `docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md` | `NEW` | `6b6d3f9ca1c2c56bbce45a3b438e37b8a5baba25d4de917a37c5ae6ce7b9d320` |
| `docs/history/session-handoffs/NEW-SESSION-PROMPT-CR04-0.25.0.txt` | `b5ffa301b2e9ef69ae31a20e14bd67d3790ad1aacd061475cf531444d2ef95fb` | `92d2b1f4b9caf9bbb03ac47cefe67144f3f830d6bf88c46e1d7203830218f629` |
| `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-designchecks-coverage-corrective-0.26.2.md` | `b6ea8d94906dbebe71cf1aec63c312c43121400c3568bd26d12186fb08518c9f` | `ac6525c7913ad288229284aa30e39e304168b4342cd792786dfa7068ab541d9e` |
| `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-live-startup-crash-new-session-prompt-0.26.2.txt` | `962f42c371f1361e86febdbd492b99eb761f84f32371d4d6bf7bb2a29d5af0cc` | `7ec7320d206bb1cb0cf0fbbff25f0340ea69df23e62d08c642e590fa40aedb8d` |
| `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-live-startup-crash-session-handoff-0.26.2.md` | `fd3f99560b5bfb657790cde5d46da4fbe915204ae528755584c19518d76a0d70` | `8813663b17925e023dcf22ecf12af6e64230662281e1d1ce1bba58fedf3dbf00` |
| `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-quality-gate-corrective-0.26.1.md` | `9866c84668a82e08777d51ff319f2197ecb8b1481faa589fe6548ab704ff60b8` | `a71903a13e3829571f21e00e3cd5cc3f6524a217e74fe37b4bad0372cfd3f8b1` |
| `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-top-level-highlight-0.26.0.md` | `34a9b59a355f18191459991440421d7b0f8f15ed5f8416293e3b3affc94c15c8` | `d8033b463e8c5b06b2ff08e38de456388870abaa7cb14d7e49dacd42af84fb29` |
| `docs/history/session-handoffs/phase-02-step-11-cr04-post-slice-2-session-handoff-0.25.0.md` | `ba57aec118e318627f06f26a729027bd2e0d8bd3a36d46f8f7ad9855be074b16` | `efa95f3ed7386f42854abac84653f8ebe3542dc62d62ebfdd14d6677d66bebb6` |
| `docs/time-tracking/PROJECT-TIMESHEET.csv` | `d9f4970d49f3cbfa25fce48617e6f959d99ca4085908834935e25631207c7dcc` | `f6c7174494fd52a3c17c330c1c8a289acd015f1e4e27a677bb9e676f1a57e6fe` |
| `src/CimatronCustomization.Application/Properties/AssemblyInfo.cs` | `800f37635c6512699f001d063caf24ac70122a917ae3c5685feb2e73843bccaa` | `b7260d36e0ec7a17a66f0d4b8734227d9829e8a44c9069c8a3d5cf117dc03afc` |
| `src/CimatronCustomization.Application/TopLevelHighlightDiagnosticResult.cs` | `18d07c1e9b5fb49b1ffdcd25ce39c219669cc7b253b8e84c0c7a41a9b6a9898a` | `4f4d8af81795390df797170d1be3f256267da2c5b9e8a570402cbf921ae47b1c` |
| `src/CimatronCustomization.CimatronIntegration/CimatronTopLevelHighlightDiagnosticReader.cs` | `6762b8d626b9a20389a7bd2a75b3eccab14163dffa3ca67d754d4363b7985fc4` | `93977a0a2a660d5e0c7cd296e3faaf3368c1a06c201451913b7ea3e00b869ebc` |
| `src/CimatronCustomization.CimatronIntegration/Properties/AssemblyInfo.cs` | `95806e62727d5a408123955686e3bfd106b7d4ab0f2cb664027c59a5539bffab` | `556e6267373a27ca26e60bf5f9c13b76f5e5c5ef25ee36209d8090f59df8befc` |
| `src/CimatronCustomization.DesignChecks/Properties/AssemblyInfo.cs` | `cc4699dc298f75b5881abf164c86ab10176885f7751d23ab7ffb1ad8f55462f0` | `d1ea00b2beb4ae87e5cbc82ff6d8f9d4e17477258ff100b7e4c0564c5b819ef7` |
| `src/CimatronCustomization.DesignChecks/TopLevelHighlightDiagnosticFeature.cs` | `e9a3511f6e2adfd46790f603ebfe56b708483b4c6319f793623980b5582eb165` | `7938623c48d722aa3b8d9843a5e8a6f2d6e443838745180074e5b7885bee0225` |
| `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj` | `681844623befa65f1c2b28daa492ff4f289c8c229313fec0e9998d9f91204694` | `7912e7e278189c5d70df1894b901d441827db63922516996eb1ebcf9076cebea` |
| `src/CimatronCustomization.Plugin/Diagnostics/TopLevelHighlightDiagnosticRequest.cs` | `NEW` | `88e40f9221b2bd8db5cb8ae69ac1cf765c9ea9ea410e11553673b2b02a44ab2f` |
| `src/CimatronCustomization.Plugin/FeatureComposition.cs` | `77117ed6cc39f491d640a2f7343da0595fb3a47dd9c655bb17187803968af5b5` | `dfd12ba5d608f48970d520b1ddb1043be9d83ca21641c58e5622bc7ad2c893b4` |
| `src/CimatronCustomization.Plugin/Properties/AssemblyInfo.cs` | `88c4546bd2cac1c7e7191bc618f46c155a532ef40a80868b3924fd906d16ece9` | `2f64e29c0eeb925ed5657ef622d8c034de765223c823e058ed8d5d84d423763b` |
| `tests/CimatronCustomization.Application.Tests/TopLevelHighlightDiagnosticFeatureTests.cs` | `18525dbb03109b70ee7e6a6dedef19ce9e15cd810bf203e47d04b03d3fbc1af3` | `fc7179e554ecafb2fc25f1bb2ccc9147ce1fb5f3c97f9013a57e4f3da8b73a59` |
| `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs` | `f6d2f3c70d414e9062c729961c6c5f0d91de32f999a0d96b213e277828342f4d` | `9f59e744488df8a46d6185765d076bd27b324d06dc2fb121ff12fb703bd6292a` |
| `tools/Request-TopLevelHighlightDiagnostic.ps1` | `NEW` | `62c8c86301eb4827e6a9c484fe899e6bba74c8eaa4fb61021bac3365e8ae1fdb` |

The new 0.26.3 handoff, new-session prompt and `CHECKSUMS.sha256` are package-generation outputs; their final hashes are recorded in `CHECKSUMS.sha256` to avoid a self-referential handoff hash.

## PRE-APPLY hash check
Run from the full workstation repository root **before** applying 0.26.3:

```powershell
$expected = @{
  "CHANGELOG.md" = "1a54cf4f763d92d5b86baca9d58a82411520b64e915693e012229ec164949cfe"
  "IMPLEMENTATION-HISTORY.md" = "b29c39862fce2665b33a8f42f3e6de1694a22ce8a30d3ffddce8039f256c2b3b"
  "VERSION.md" = "a21284c502a31fe5e1d2f110e5c0add2b13b66418312981453ce4828d9fb516d"
  "docs/history/session-handoffs/NEW-SESSION-PROMPT-CR04-0.25.0.txt" = "b5ffa301b2e9ef69ae31a20e14bd67d3790ad1aacd061475cf531444d2ef95fb"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-designchecks-coverage-corrective-0.26.2.md" = "b6ea8d94906dbebe71cf1aec63c312c43121400c3568bd26d12186fb08518c9f"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-live-startup-crash-new-session-prompt-0.26.2.txt" = "962f42c371f1361e86febdbd492b99eb761f84f32371d4d6bf7bb2a29d5af0cc"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-live-startup-crash-session-handoff-0.26.2.md" = "fd3f99560b5bfb657790cde5d46da4fbe915204ae528755584c19518d76a0d70"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-quality-gate-corrective-0.26.1.md" = "9866c84668a82e08777d51ff319f2197ecb8b1481faa589fe6548ab704ff60b8"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-top-level-highlight-0.26.0.md" = "34a9b59a355f18191459991440421d7b0f8f15ed5f8416293e3b3affc94c15c8"
  "docs/history/session-handoffs/phase-02-step-11-cr04-post-slice-2-session-handoff-0.25.0.md" = "ba57aec118e318627f06f26a729027bd2e0d8bd3a36d46f8f7ad9855be074b16"
  "docs/time-tracking/PROJECT-TIMESHEET.csv" = "d9f4970d49f3cbfa25fce48617e6f959d99ca4085908834935e25631207c7dcc"
  "src/CimatronCustomization.Application/Properties/AssemblyInfo.cs" = "800f37635c6512699f001d063caf24ac70122a917ae3c5685feb2e73843bccaa"
  "src/CimatronCustomization.Application/TopLevelHighlightDiagnosticResult.cs" = "18d07c1e9b5fb49b1ffdcd25ce39c219669cc7b253b8e84c0c7a41a9b6a9898a"
  "src/CimatronCustomization.CimatronIntegration/CimatronTopLevelHighlightDiagnosticReader.cs" = "6762b8d626b9a20389a7bd2a75b3eccab14163dffa3ca67d754d4363b7985fc4"
  "src/CimatronCustomization.CimatronIntegration/Properties/AssemblyInfo.cs" = "95806e62727d5a408123955686e3bfd106b7d4ab0f2cb664027c59a5539bffab"
  "src/CimatronCustomization.DesignChecks/Properties/AssemblyInfo.cs" = "cc4699dc298f75b5881abf164c86ab10176885f7751d23ab7ffb1ad8f55462f0"
  "src/CimatronCustomization.DesignChecks/TopLevelHighlightDiagnosticFeature.cs" = "e9a3511f6e2adfd46790f603ebfe56b708483b4c6319f793623980b5582eb165"
  "src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj" = "681844623befa65f1c2b28daa492ff4f289c8c229313fec0e9998d9f91204694"
  "src/CimatronCustomization.Plugin/FeatureComposition.cs" = "77117ed6cc39f491d640a2f7343da0595fb3a47dd9c655bb17187803968af5b5"
  "src/CimatronCustomization.Plugin/Properties/AssemblyInfo.cs" = "88c4546bd2cac1c7e7191bc618f46c155a532ef40a80868b3924fd906d16ece9"
  "tests/CimatronCustomization.Application.Tests/TopLevelHighlightDiagnosticFeatureTests.cs" = "18525dbb03109b70ee7e6a6dedef19ce9e15cd810bf203e47d04b03d3fbc1af3"
  "tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs" = "f6d2f3c70d414e9062c729961c6c5f0d91de32f999a0d96b213e277828342f4d"
}
$expected.GetEnumerator() | ForEach-Object {
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.Key).Hash.ToLowerInvariant()
  if ($actual -ne $_.Value) { throw "PRE-APPLY hash mismatch: $($_.Key) actual=$actual expected=$($_.Value)" }
}
if (Test-Path -LiteralPath "docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md") { throw "PRE-APPLY expected absent: docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md" }
if (Test-Path -LiteralPath "src/CimatronCustomization.Plugin/Diagnostics/TopLevelHighlightDiagnosticRequest.cs") { throw "PRE-APPLY expected absent: src/CimatronCustomization.Plugin/Diagnostics/TopLevelHighlightDiagnosticRequest.cs" }
if (Test-Path -LiteralPath "tools/Request-TopLevelHighlightDiagnostic.ps1") { throw "PRE-APPLY expected absent: tools/Request-TopLevelHighlightDiagnostic.ps1" }
```

The restored governing plan is an approved prerequisite and must separately hash to `6b6d3f9ca1c2c56bbce45a3b438e37b8a5baba25d4de917a37c5ae6ce7b9d320`.

## POST-APPLY hash check
Run after applying 0.26.3:

```powershell
$expected = @{
  "CHANGELOG.md" = "942287a7ae97c434ea9e069ca5fa163d82afd4ec311ec467440f6129584be24c"
  "IMPLEMENTATION-HISTORY.md" = "932651e141ab578cc60574ec75f603f7871fd9a8bc56a07f938013542dc5b05e"
  "VERSION.md" = "82237fd1b29ec3725c8af12c63938a198d49bc918ca894ec83aec997391c9c2f"
  "docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md" = "6b6d3f9ca1c2c56bbce45a3b438e37b8a5baba25d4de917a37c5ae6ce7b9d320"
  "docs/history/session-handoffs/NEW-SESSION-PROMPT-CR04-0.25.0.txt" = "92d2b1f4b9caf9bbb03ac47cefe67144f3f830d6bf88c46e1d7203830218f629"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-designchecks-coverage-corrective-0.26.2.md" = "ac6525c7913ad288229284aa30e39e304168b4342cd792786dfa7068ab541d9e"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-live-startup-crash-new-session-prompt-0.26.2.txt" = "7ec7320d206bb1cb0cf0fbbff25f0340ea69df23e62d08c642e590fa40aedb8d"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-live-startup-crash-session-handoff-0.26.2.md" = "8813663b17925e023dcf22ecf12af6e64230662281e1d1ce1bba58fedf3dbf00"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-quality-gate-corrective-0.26.1.md" = "a71903a13e3829571f21e00e3cd5cc3f6524a217e74fe37b4bad0372cfd3f8b1"
  "docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-top-level-highlight-0.26.0.md" = "d8033b463e8c5b06b2ff08e38de456388870abaa7cb14d7e49dacd42af84fb29"
  "docs/history/session-handoffs/phase-02-step-11-cr04-post-slice-2-session-handoff-0.25.0.md" = "efa95f3ed7386f42854abac84653f8ebe3542dc62d62ebfdd14d6677d66bebb6"
  "docs/time-tracking/PROJECT-TIMESHEET.csv" = "f6c7174494fd52a3c17c330c1c8a289acd015f1e4e27a677bb9e676f1a57e6fe"
  "src/CimatronCustomization.Application/Properties/AssemblyInfo.cs" = "b7260d36e0ec7a17a66f0d4b8734227d9829e8a44c9069c8a3d5cf117dc03afc"
  "src/CimatronCustomization.Application/TopLevelHighlightDiagnosticResult.cs" = "4f4d8af81795390df797170d1be3f256267da2c5b9e8a570402cbf921ae47b1c"
  "src/CimatronCustomization.CimatronIntegration/CimatronTopLevelHighlightDiagnosticReader.cs" = "93977a0a2a660d5e0c7cd296e3faaf3368c1a06c201451913b7ea3e00b869ebc"
  "src/CimatronCustomization.CimatronIntegration/Properties/AssemblyInfo.cs" = "556e6267373a27ca26e60bf5f9c13b76f5e5c5ef25ee36209d8090f59df8befc"
  "src/CimatronCustomization.DesignChecks/Properties/AssemblyInfo.cs" = "d1ea00b2beb4ae87e5cbc82ff6d8f9d4e17477258ff100b7e4c0564c5b819ef7"
  "src/CimatronCustomization.DesignChecks/TopLevelHighlightDiagnosticFeature.cs" = "7938623c48d722aa3b8d9843a5e8a6f2d6e443838745180074e5b7885bee0225"
  "src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj" = "7912e7e278189c5d70df1894b901d441827db63922516996eb1ebcf9076cebea"
  "src/CimatronCustomization.Plugin/Diagnostics/TopLevelHighlightDiagnosticRequest.cs" = "88e40f9221b2bd8db5cb8ae69ac1cf765c9ea9ea410e11553673b2b02a44ab2f"
  "src/CimatronCustomization.Plugin/FeatureComposition.cs" = "dfd12ba5d608f48970d520b1ddb1043be9d83ca21641c58e5622bc7ad2c893b4"
  "src/CimatronCustomization.Plugin/Properties/AssemblyInfo.cs" = "2f64e29c0eeb925ed5657ef622d8c034de765223c823e058ed8d5d84d423763b"
  "tests/CimatronCustomization.Application.Tests/TopLevelHighlightDiagnosticFeatureTests.cs" = "fc7179e554ecafb2fc25f1bb2ccc9147ce1fb5f3c97f9013a57e4f3da8b73a59"
  "tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs" = "9f59e744488df8a46d6185765d076bd27b324d06dc2fb121ff12fb703bd6292a"
  "tools/Request-TopLevelHighlightDiagnostic.ps1" = "62c8c86301eb4827e6a9c484fe899e6bba74c8eaa4fb61021bac3365e8ae1fdb"
}
$expected.GetEnumerator() | ForEach-Object {
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.Key).Hash.ToLowerInvariant()
  if ($actual -ne $_.Value) { throw "POST-APPLY hash mismatch: $($_.Key) actual=$actual expected=$($_.Value)" }
}
Write-Host "POST-APPLY 0.26.3 substantive-file hashes MATCH."
```

Then validate the complete package against `CHECKSUMS.sha256`.

## User-run sequence
1. Run the governed quality gate and provide the full captured result. Stop if any build, analyzer, test, coverage or local quality gate fails.
2. Confirm the deployed Plugin, Application, CimatronIntegration and DesignChecks DLL file versions are each `0.26.3.0`.
3. Run `tools/Request-TopLevelHighlightDiagnostic.ps1`. It creates the one-shot request only; it does not launch Cimatron.
4. Within 30 minutes, start Cimatron using the **normal shortcut**, not PowerShell.
5. Open the existing `KA-ASM-1`.
6. Click **Cimatron Customization** once and confirm the CR-04 Slice 2A Top-Level Highlight Diagnostic is listed.
7. Run the diagnostic once. **The single governed live run starts only when the diagnostic itself is run.**
8. In Result Report, confirm `[TOPLEVEL_HIGHLIGHT_TARGET_READY]`, then select that finding and click **Highlight**.
9. Visually confirm only the intended top-level `KA-PART-1` body highlights.
10. Close the highlight/report path and confirm highlight is restored and there is no save prompt / assembly modification indication.
11. Confirm the one-shot request file is gone.

If Cimatron fails to start after the request is created: run `tools/Request-TopLevelHighlightDiagnostic.ps1 -Cancel` and **STOP**. That startup failure is **not** a diagnostic run. Do not retry without new approval.

No live-gate PASS may be claimed without the actual user viewport evidence above.

## Validation / execution boundary
The AI agent did **not** build, run unit/architecture tests, collect coverage, execute the quality gate, deploy DLLs, run the request script, or launch Cimatron. All such execution remains user-controlled.

## Supersession
The historical Package 2 handoffs for 0.26.0, 0.26.1 and 0.26.2, including the live-startup-crash handoff, are marked **SUPERSEDED by 0.26.3** and retained only for evidence/history.

## Exact next step
Apply this full 0.26.3 package to the workstation repository, run the PRE/POST hash checks, and execute the governed quality gate; do not create the live diagnostic request until the quality gate is clean.

────────────────────────────────────────
PROJECT STATUS
Phase        : 02 — CR Platform Extensions
Step         : 10/2A — CR-04 Slice 2A Package 2 Top-Level Highlight Diagnostic
Version      : 0.26.3
Context      : GREEN
Scope        : Approved request-file opt-in corrective
Approval     : APPROVED
Changes      : COMPLETED
User Validation: AWAITING USER EXECUTION
Last Feedback: User supplied startup/WER control evidence and approved the 0.26.3 corrective plus one Plugin Compile entry
Next Action  : Run the workstation 0.26.3 quality gate after hash verification
────────────────────────────────────────
