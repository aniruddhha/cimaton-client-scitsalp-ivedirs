# Phase 02 — CR-04 Slice 3 Cimatron Adapter — 0.27.0

Date: 2026-10-05  
Product version: 0.27.0  
Status: IMPLEMENTED / AWAITING USER WORKSTATION QUALITY GATE + CONTROLLED LIVE WRONG-TYPE ADAPTER SMOKE  
Context health: GREEN

## Governance

`AGENTS.md` controls. The user explicitly approved the Slice 3 implementation plan before source changes. Exact approval timestamp seconds were not independently captured and are not invented. The AI agent did not build, test, run coverage, deploy, execute the setup helper, or run Cimatron.

## Implemented production scope

New production file:

- `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs`

The adapter implements the existing `IAssemblyBodyAttributeReader` contract and returns the complete highlighter-equivalent occurrence traversal. It uses `GetInstances()`, `get_SubInstances(1, 0)`, depth stop 16, `GetAllEntities()`, `cmBody`, and exact named `GetAttribute(cmAttString, name)`. Suppressed/zero-body/non-business occurrences remain in the snapshot. Effective suppression is propagated but not used to filter traversal output.

The adapter emits the existing current-session entity reference shape and contains no D-15 first-match/business logic. Application continues to own D-15 full-scope InstanceId uniqueness and business filtering.

## Wrong-type fail-safe rule

Production mapping is intentionally narrow:

- null exact string lookup -> provisional `Absent`;
- exact `cmAttString` return with readable value -> `Present`;
- unexpected return type, unreadable value/conversion failure, or exception -> `ReadError`;
- no production `cmAttInteger` probe;
- no `UnsupportedType`.

A conforming-looking value from a genuine non-string stored control remains the hard-stop risk.

## Controlled genuine wrong-type fixture support

`KnownAnswerModelSetup` now supports `--cr04-wrong-type-control`, but only for:

- active Part context;
- disposable model title `KA-PART-1-CR04-WRONG-TYPE`;
- body entity `4`;
- attribute `CR04_WRONG_TYPE_CONTROL`;
- value `2738`;
- stored type `cmAttInteger`.

Overwrite is prohibited. Autosave remains disabled. Manual save is required only on the disposable fixture after successful read-back.

## Opt-in adapter smoke

The existing CimatronIntegration test executable performs the live smoke only when:

`CIMATRON_DEV_ENABLE_CR04_SLICE3_WRONG_TYPE_SMOKE=1`

and
`CIMATRON_DEV_CR04_WRONG_TYPE_MODEL_TITLE=KA-PART-1-CR04-WRONG-TYPE`

It invokes the real `CimatronAssemblyBodyAttributeReader`, inspects controlled body entity 4, and records `Present` / `Absent` / `ReadError` counts plus active-document no-mutation evidence.

Hard stop: any controlled observation reported as `Present` means a genuine `cmAttInteger` attribute queried as `cmAttString` is indistinguishable from conforming string evidence. Stop Slice 3 acceptance and return to the user for a design decision.

## Files changed

Production:
- NEW `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs`
- MODIFIED `src/CimatronCustomization.CimatronIntegration/CimatronCustomization.CimatronIntegration.csproj`
- MODIFIED `src/CimatronCustomization.CimatronIntegration/Properties/AssemblyInfo.cs`

Tests / architecture:
- MODIFIED `tests/CimatronCustomization.CimatronIntegrationTests/Cr04TraversalSafetyTests.cs`
- MODIFIED `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`

Development-only setup:
- MODIFIED `tools/CimatronCustomization.KnownAnswerModelSetup/Program.cs`
- MODIFIED `tools/CimatronCustomization.KnownAnswerModelSetup/Properties/AssemblyInfo.cs`

Governance:
- MODIFIED `VERSION.md`
- MODIFIED `CHANGELOG.md`
- MODIFIED `IMPLEMENTATION-HISTORY.md`
- MODIFIED `docs/time-tracking/PROJECT-TIMESHEET.csv`
- MODIFIED `CHECKSUMS.sha256`
- NEW this handoff file.

## Preserved decisions / exclusions

- D-15(a) full traversal uniqueness remains mandatory.
- D-15(b) remains DEFERRED.
- collision-frequency remains MOVED TO SLICE 5.
- D-17 remains EXCLUDED-PROVISIONAL.
- first-match fallback remains prohibited.
- Package-2 temporary diagnostic cleanup remains separately approved-only and blocking before client packaging.
- no FeatureComposition/config/DesignChecks CR-04 feature/BOM/D-09(b)/customer real-sample work is included.

## Required user validation order

1. Run workstation quality gate from repository root:
   `powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"`
2. Stop if Release x64 is not PASS, warnings/errors are not `0 / 0`, any governed test/coverage/local gate fails, or exit code is not `0`.
3. Only after a clean gate, prepare the disposable wrong-type Part/Assembly control and run the setup helper.
4. Run the opt-in real-adapter smoke with the controlled Assembly active.
5. Stop immediately if the smoke prints/throws the conforming-looking `Present` hard stop, or if no-mutation fails. No corrective/retry is authorized without new approval.

## Current acceptance state

No `0.27.0` quality-gate PASS or live-smoke PASS is claimed. Await user workstation evidence.
