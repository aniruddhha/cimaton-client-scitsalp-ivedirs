# Phase 02 / Step 10 / CR-04 v1.5 — Part Material BOM-Header Corrective — 0.38.1

## Status

Corrective implementation prepared. **Awaiting user workstation quality gate.**

## Entering evidence

- `quality-gate-20261006-160141.txt`: 0.38.0 Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0. Raw evidence is not packaged.
- First 0.38.0 live CR-04 CSV: one `CAD_PART_MATERIAL_READ_ERROR` with `TABULAR_HEADERS_CHANGED`; material comparison was not reached. Raw CSV is not packaged.

## Root cause

`CimatronBomMaterialTableReader` supplied only `Standard Number` and `Material` as `expectedHeaders`. `ExcelTabularDataReader.Read(..., expectedHeaders)` compares the complete actual header array to that list, including count and order. The already verified Cimatron BOM CSV contract has seven columns, so the two-entry list deterministically failed the stability check.

## Corrective

- `CimatronBomMaterialTableReader.ExpectedBomHeaders` now uses the verified full BOM sequence: `No.`, `Qty.`, `Standard Number`, `Sub Category`, `Category`, `Visible Part Size`, `Material`.
- Logical mappings remain only `Standard Number -> ModelTitle` and `Material -> Part Material`.
- Architecture and CimatronIntegration source-contract guards now protect the complete header contract.
- Production assemblies / feature version aligned to `0.38.1`.

## Boundaries

No new Cimatron API, dependency, category mapping, Design Order behavior, model/workbook mutation, save path, or `STEEL_GRADE` fallback. Native Part Material remains the sole production steel-grade source.

## Validation

Agent performed static/source/project/hash/package checks only and did not execute MSBuild, tests, coverage, analyzers, SonarQube, or Cimatron. User must run the workstation quality gate before repeating controlled live validation.
