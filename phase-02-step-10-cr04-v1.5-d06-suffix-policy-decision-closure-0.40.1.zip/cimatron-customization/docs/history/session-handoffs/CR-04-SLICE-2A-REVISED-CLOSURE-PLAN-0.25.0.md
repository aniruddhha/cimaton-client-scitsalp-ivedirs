# CR-04 Slice 2A Closure — Revised Plan (supersedes the earlier five-gate plan)

Approval: Approved — this exact text. The agent must not alter this line.
Record the approval with its actual timestamp; if the timestamp is not captured, state that it was not
captured rather than inventing one.
Each package still requires its exact file list to be presented and explicitly approved before
implementation (AGENTS.md §18/§33).
Baseline: 0.25.0 (Slice 2 CLOSED / USER VALIDATED). Slice 1/Slice 2 production code is unchanged by this plan.

## Principle
A Slice 2A gate blocks Slice 3 only if its outcome changes Slice 3 adapter code or correctness.
Gates that do not are dispositioned in writing now, with no further probing.

## Package 1 — Disposition record (documentation/governance only)

No src/**, tools/**, tests, config or model changes. The CR-04 v1.4 spec file is not edited; record
explicitly that these dispositions deliberately supersede the v1.4 §8.3 / §17 Slice 2A pre-adapter list
for the items below.

1. D-15(b) placement-specific mapping: DEFERRED.
   The production highlighter resolves references by InstanceId depth-first first-match, so no
   placement-specific mapping can flow through it without a protected platform change. D-15(a),
   implemented in 0.25.0, prevents unintended highlight. D-15(b) may return only as a separately approved
   platform increment. First-match fallback remains prohibited.

2. Collision-frequency measurement: MOVED to Slice 5 closure evidence.
   Under spec §6.2, collisions only remove highlight references and never change business status, so the
   measurement cannot change adapter code. Measure on the customer real-sample run, counts only (traversed
   occurrences, colliding InstanceIds, affected body-bearing occurrences, findings losing highlight; no
   titles/paths). Acceptability threshold to be decided with the customer (spec §19 item 9).
   KA-ASM-1 reference evidence (not a substitute for the customer measurement): 13 traversed occurrences,
   repeated IDs 3/5/6, 6 participating occurrences, 1 of 3 known-attribute occurrences unsafe (33.33%).

3. D-17 Assist Parts: EXCLUDED — PROVISIONAL pending customer answer (spec §19 item 12).
   Nested traversal keeps get_SubInstances(1, 0). Known limitation: official docs expose no assist
   filter/property for top-level IAssemblyModel.GetInstances(); top-level assist exclusion is UNVERIFIED.
   No genuine Assist Part fixture exists; the UI investigation is not repeated.
   CR04_Assist_Part_Control remains a normal part, not evidence.

4. Wrong-type attribute semantics: FAIL-SAFE ADAPTER RULE; evidence moves to Slice 3 adapter smoke.
   Conforming return = exactly the shape observed on the U13-verified present-string route
   (IAssInstance.GetAllEntities() → cmBody → GetAttribute(cmAttString, name)). The Slice 3 plan must state
   that shape from the U13/0.24.x evidence before any code is written.
   - null → absent (PROVISIONAL until the Slice 3 smoke).
   - Any return not matching the conforming shape, an unreadable value, a conversion failure, or an
     exception → API/runtime Error; never Absent, never Matched, never UnsupportedType.
   - Slice 2 behavior unchanged: attributeTypeUnsupported is never produced.
   Known residual risk (not covered by this rule): 0.24.2 showed a cmAttInteger query returning non-null on
   string-stored attributes, so a genuine non-string attribute queried as cmAttString might return a value
   indistinguishable from a conforming string. The Slice 3 smoke must test exactly this with a genuine
   same-name non-string control on a controlled model copy, created via the existing
   tools/CimatronCustomization.KnownAnswerModelSetup route (separately approved setup step). If it returns
   a conforming-looking value, adapter acceptance stops for a user decision; it is not silently accepted.

Remaining Slice 2A gate after Package 1: top-level highlight only.

## Package 2 — Top-level highlight diagnostic (one quality gate, one live run)

Plan first; present the exact file list for approval. The full repository is required; do not plan files
from the minimal 0.25.0 overlay (it does not contain the highlighter source).

Hard stops, answered from source/evidence before proposing files:
- Does CimatronViewportEntityHighlighter already resolve a top-level (non-nested) reference? If not, STOP
  and report. Do not modify the highlighter in this package.
- From the 0.24.4 KA-ASM-1 evidence: which top-level KA-PART-1 occurrence has an InstanceId unique across
  the full highlighter-equivalent traversal? Only a D-15(a)-safe occurrence may be targeted. If none is
  unique, STOP and report.

Scope:
- Minimal in-process, opt-in gated diagnostic that emits one top-level body reference on a finding through
  the normal Result Report → Highlight path. Fixture: existing KA-ASM-1 (no model change).
- Protected and unchanged: CimatronViewportEntityHighlighter.cs, Step08BInProcessConfirmationFeature.cs,
  other 08B adapters, all 0.25.0 CR-04 Application/Domain code.
- Diagnostic entry excluded/removed before any client packaging; record this explicitly.
- No other investigation in this package.

Acceptance (single live run; stop on first failure, no retries without new approval):
- clean quality gate (0 warnings / 0 errors, exit 0) before the live run;
- intended top-level KA-PART-1 body highlights, and no other occurrence highlights;
- highlight restores after closing;
- programmatic no-mutation PASS;
- correlation ID recorded.
On PASS: Slice 2A CLOSED; Slice 3 adapter planning may be requested.
On FAIL: report evidence only; no corrective without approval.

---

Approval record: approval date `2026-10-04`; exact approval timestamp was not captured and is intentionally not invented.
