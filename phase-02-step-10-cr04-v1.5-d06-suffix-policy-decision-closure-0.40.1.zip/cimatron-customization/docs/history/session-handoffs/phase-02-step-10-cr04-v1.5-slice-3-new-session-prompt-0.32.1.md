# New-session prompt — continue CR-04 v1.5 from Slice 2 closure 0.32.1

Continue CR-04 v1.5 controlled implementation from the cumulative **0.32.1 Slice 2 closure** package I provide in this new chat.

Treat that ZIP as the authoritative baseline and extract it exactly to `cimatron-customization/`. Follow `AGENTS.md` strictly. Read the full `AGENTS.md`, `docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`, `IMPLEMENTATION-HISTORY.md`, `CHANGELOG.md`, `VERSION.md`, and `docs/history/session-handoffs/phase-02-step-10-cr04-v1.5-slice-2-closure-0.32.1.md` before planning or editing.

Current status:
- Slice 1 Form reader/profile is CLOSED / USER VALIDATED.
- Slice 2 category mapping + Form/Table orchestration is CLOSED / USER VALIDATED.
- Accepted 0.32.1 workstation gate: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage/local quality gate PASS, exit 0.
- Do not include the raw quality-gate file in the cumulative ZIP.
- Eight v1.5 protected files must remain byte-identical unless a separately approved scope change explicitly says otherwise.

Next planned work is **Slice 3 — feature/config/composition wiring**. Before any source/config edit, inspect the actual 0.32.1 code and present the exact implementation plan, including every new file, every existing file proposed for modification, why each is necessary, risks, tests, architecture guards, quality-gate steps, Cimatron validation, and package/version/documentation handling. Then STOP and wait for my explicit approval.

Expected Slice 3 direction from the approved v1.5 plan:
- update `SteelGradeDesignOrderValidation.cs` for Form/profile/category mapping parameters;
- update `FeatureComposition.cs` to inject the Form reader/profile alongside the Table reader;
- update production config only with approved values;
- keep feature ID `STEEL-GRADE-DESIGN-ORDER-VALIDATION`;
- BodyAttribute source only; Strict representation; `CompareGradeTokenOnly=false`;
- preserve the existing `.xlsx/.xls` runtime picker; no CSV;
- no dependency upgrades;
- no new Cimatron API use unless independently verified and separately approved if scope changes.

Critical: **do not invent real client ModelTitle category patterns or other unresolved production values.** The production ModelTitle naming/category patterns are still unresolved. Current controlled D-02 direction is body/entity string attribute `STEEL_GRADE` / `cmAttString`, but final client naming confirmation remains a production-closure input. Suffix semantics, blank-grade business meaning, and the template validation-range defect also remain unresolved client inputs. If Slice 3 cannot be implemented safely without one of those values, STOP and ask rather than inserting fake/default production data.

Maintain documentation and authoritative CSV timestamps. Keep agent active-work time separate from user wait/feedback time. Never invent approval/evidence timestamps. Deliver only a cumulative ZIP when an approved implementation or handoff is ready.
