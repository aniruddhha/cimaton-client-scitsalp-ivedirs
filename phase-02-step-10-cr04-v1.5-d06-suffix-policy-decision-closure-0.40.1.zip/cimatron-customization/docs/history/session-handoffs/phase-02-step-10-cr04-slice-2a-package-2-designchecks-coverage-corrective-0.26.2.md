> **SUPERSEDED by 0.26.3 request-file opt-in corrective.** Retained for historical evidence only.

# Phase 02 — CR-04 Slice 2A Package 2 DesignChecks Coverage Corrective — 0.26.2

## Entering evidence

User workstation 0.26.1 quality gate:

- Release x64 build: PASS
- warnings / errors: 0 / 0
- Architecture, Domain, Application, Cimatron Integration, Infrastructure tests: PASS
- coverage collection: PASS
- DesignChecks: 92.48%
- governed DesignChecks minimum: 95%
- result: QUALITY GATE FAILED; live Cimatron diagnostic not authorized

The supplied merged Cobertura report showed the Package 2 `TopLevelHighlightDiagnosticFeature` definition initializer and constructor null guard were not exercised by its focused test fixture.

## Approved corrective scope

Only `TopLevelHighlightDiagnosticFeatureTests` behavior is extended:

1. access/validate the governed `Definition` metadata so the static feature definition is executed;
2. verify null-reader construction throws `ArgumentNullException`.

Required PATCH/version/governance/checksum records advance to 0.26.2. No production runtime logic is changed.

## Runtime rules unchanged

- D-15(b): DEFERRED; D-15(a) mandatory; no first-match fallback.
- collision-frequency: Slice 5.
- D-17 Assist Parts: EXCLUDED-PROVISIONAL.
- wrong-type semantics: FAIL-SAFE RULE; genuine control deferred to Slice 3 adapter smoke.
- Package 2 runtime target is selected dynamically from the production-highlighter-equivalent scope; no historical InstanceId is hard-coded.
- `[TOPLEVEL_HIGHLIGHT_TARGET_READY]` does not confirm visual highlight.
- Slice 3 remains BLOCKED.
- Before any client package, remove the diagnostic registration, all eight diagnostic source files, the request script and the two diagnostic test files under separate approval.

## Exact next step

Keep Cimatron closed and run:

```powershell
powershell -ExecutionPolicy Bypass -File ".\tools\Invoke-And-Capture.ps1" -Task quality-gate
```

Expected capture location:

```text
artifacts\console-captures\quality-gate-YYYYMMDD-HHMMSS.txt
```

Require Release x64 PASS, all governed suites PASS, all coverage gates PASS, 0 warnings / 0 errors, local quality gate PASS, exit code 0. STOP on any failure. Only after user validation of that clean capture may exactly one governed live top-level-highlight run be performed.
