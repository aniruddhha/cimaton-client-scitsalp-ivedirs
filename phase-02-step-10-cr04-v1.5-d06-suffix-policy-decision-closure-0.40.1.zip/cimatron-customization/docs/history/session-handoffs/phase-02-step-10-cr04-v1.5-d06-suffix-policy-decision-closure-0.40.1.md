# Phase 02 / Step 10 / CR-04 v1.5 — D-06 Suffix-Policy Decision Closure

## Status

- Product/runtime version: `0.40.1`.
- Change type: documentation/governance only.
- Runtime/source/test/config behavior changes: **none**.
- D-06 status: **RESOLVED**.

## Approved decision

CR-04 does not separately maintain, interpret, strip, map, or validate material suffix details. Production validation compares the full normalized Cimatron native Part Material value (`TMPL::Material`) with the full normalized Design Order `Remark` value for the mapped row.

Suffix text such as `Doosan`, `PCK`, `HH`, or `TSHH`, when present, remains part of the material string under the existing approved normalization/comparison policy. No suffix-specific lookup table, mapping, or client-maintained rule is required.

`CompareGradeTokenOnly = false` remains unchanged.

## Implementation impact

No runtime corrective is required. The current production direction already performs full-value comparison. This closure therefore changes only governed documentation and traceability records.

## Governance effect

- `CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`: D-06 changed from PROVISIONAL to RESOLVED.
- `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, and `PROJECT-TIMESHEET.csv`: decision/traceability aligned.
- Product/runtime version remains `0.40.1`.

## Next state

D-06 is no longer a production-closure blocker. The next separately controlled activity is the formal CR-04 v1.5 / Phase 02 Step 10 closure review.
