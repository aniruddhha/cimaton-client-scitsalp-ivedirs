# Phase 02 — CR-04 Post-Slice-2 Session Handoff — Package 2 / 0.26.0

## Project
Cimatron 2026 Customization

## Current step
Step 11 Slice 2 is CLOSED / USER VALIDATED. Current work is Slice 2A Package 2 top-level-highlight validation. Package 2 is implemented; awaiting user workstation quality gate and then one governed live run.

## Version
0.26.0

## Context status
Slice 3 is blocked until the Package 2 top-level-highlight gate passes or is separately re-dispositioned with user approval.

## Latest package
`phase-02-step-10-cr04-slice-2a-package-2-top-level-highlight-0.26.0.zip` — overlay package; must not replace the full repository. Predecessors: Package 1A, Package 1, post-Slice-2 handoff, Slice 2 closure, Slice 2 implementation overlay and 0.24.4 full package.

## Governing plan and dispositions
Governing plan: `docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md`.

- D-15(b): **DEFERRED**. D-15(a) remains; first-match fallback prohibited.
- Collision-frequency: **MOVED TO SLICE 5**.
- D-17 Assist Parts: **EXCLUDED-PROVISIONAL** pending customer answer; top-level Assist Part exclusion remains UNVERIFIED. `CR04_Assist_Part_Control` is a normal part, not Assist Part evidence.
- Wrong-type semantics: **FAIL-SAFE RULE**; genuine same-name non-string evidence moves to Slice 3 adapter smoke.

## Package 2 implementation
- Protected highlighter was inspected and supports top-level occurrence references through `FindInstance` depth 0 over `assembly.GetInstances()`, then PID check, `FindOccurrenceEntity`, and `GetAssemblyEntity`.
- Runtime target selection never uses historical InstanceIds. It traverses the full highlighter-equivalent scope; candidates are unsuppressed depth-0 `KA-PART-1`; only globally unique IDs survive; lowest unique runtime ID is selected.
- The selected occurrence must have exactly one body with `STEP07_B1_TEST_ATTRIBUTE = KNOWN_ANSWER_07C3` through `cmAttString`.
- Success emits one `[TOPLEVEL_HIGHLIGHT_TARGET_READY]` Passed finding with one current-session reference and an explicit statement that Highlight is NOT confirmed by the finding. All fail-closed conditions are Error with no reference.
- Registration is opt-in only when `CIMATRON_DEV_ENABLE_CR04_SLICE2A_TOPLEVEL_HIGHLIGHT_DIAGNOSTIC` equals exactly `1`. The gate is evaluated when a new launcher registry is created.

## Quality-gate evidence carried forward
The accepted 0.25.0 workstation gate `quality-gate-20261004-203340.txt` passed Release x64, all governed suites, coverage gates, 0 warnings / 0 errors and exit code 0. Package 2 changes require a new clean workstation quality gate before any live run.

## Packaging/recovery incident carried forward
The earlier minimal 0.25.0 overlay temporarily left the workstation without quality-gate scripts until the full repository was restored. This was a packaging/recovery incident, not a Slice 2 code/test failure. Package 2 is also an overlay and must not replace/delete the full repository.

## Suppression nuance carried forward
The closure-model run showed the nested child as suppressed while the parent row reported `suppressed=0`; the user observed effective child suppression in the UI. Do not make a stronger parent-flag claim. No self-instance heuristic may be reintroduced.

## Client-packaging blocker
**BLOCKING:** diagnostic registration, all eight Package 2 diagnostic source files, the request script and the two diagnostic test files MUST be removed under a separately approved change before any client package is built.

## Package 1 / 1A validation
Package 1 and Package 1A are ACCEPTED / USER VALIDATED. Exact acceptance timestamps were not captured; no timestamp is invented.

## User-run instructions
1. Apply this overlay only after comparing the baseline SHA-256 list supplied with delivery.
2. Cimatron closed: run `& ".\tools\Invoke-QualityGate.ps1"`. Require Release x64 PASS, all governed suites PASS, coverage gates PASS, 0 warnings / 0 errors, exit 0. Send the capture. STOP on failure.
3. Only after the user sends a clean gate, in the same PowerShell session:
   `$env:CIMATRON_DEV_ENABLE_CR04_SLICE2A_TOPLEVEL_HIGHLIGHT_DIAGNOSTIC = "1"`
   `& "<CIMATRON_EXE_PATH>"`
4. Open existing KA-ASM-1 and run only `CR-04 Slice 2A Top-Level Highlight Diagnostic`.
5. Result Report: record finding message and correlation ID; screenshot.
6. Click Highlight. Confirm intended top-level KA-PART-1 body and no other occurrence; screenshot.
7. Close highlight. Confirm restoration and explicitly confirm assembly unmodified; screenshot. Programmatic no-mutation and user confirmation are both required.
8. Close Cimatron; then:
   `Remove-Item Env:CIMATRON_DEV_ENABLE_CR04_SLICE2A_TOPLEVEL_HIGHLIGHT_DIAGNOSTIC -ErrorAction SilentlyContinue`
   `[Environment]::GetEnvironmentVariable("CIMATRON_DEV_ENABLE_CR04_SLICE2A_TOPLEVEL_HIGHLIGHT_DIAGNOSTIC", "User")`
   `[Environment]::GetEnvironmentVariable("CIMATRON_DEV_ENABLE_CR04_SLICE2A_TOPLEVEL_HIGHLIGHT_DIAGNOSTIC", "Machine")`
   Both persistent-scope queries must be empty/null.

Stop rule: exactly one live run; stop on first failure; no retry or corrective without approval.

## Exact next step
Run the new workstation quality gate with Cimatron closed and send the capture. Do not perform the live run until the user has supplied a clean Package 2 quality-gate result.
