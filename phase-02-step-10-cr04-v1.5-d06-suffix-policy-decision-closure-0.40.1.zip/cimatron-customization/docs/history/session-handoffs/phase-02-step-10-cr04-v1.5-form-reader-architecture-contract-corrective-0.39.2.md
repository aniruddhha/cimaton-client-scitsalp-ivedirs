# Phase 02 Step 10 — CR-04 v1.5 Form-Reader Architecture Contract Corrective — 0.39.2

## Status

- Phase: 02 — CR Platform Extensions
- Step: 10 / CR-04 v1.5
- Version: 0.39.2
- Status: CORRECTIVE IMPLEMENTED / AWAITING USER QUALITY GATE
- Context: GREEN

## Entering user evidence

User supplied `quality-gate-20261006-212934.txt` for 0.39.1. Release x64 build passed with 0 errors, with one CA1859 warning in `PartTypeCategoryResolverTests.cs`; the quality gate then stopped at Architecture Tests. Direct execution of the ArchitectureTests binary reproduced: `CR-04 v1.5 Form reader lost a required read-only or fail-closed source contract.`

## Root cause

The Architecture source guard for `ExcelDesignOrderFormReader.cs` required literal identifiers `SelectedMaterialFamily` and `RawRemark`. The reader's approved implementation already uses `selectedFamily` and `rawRemark` locals and passes them to `DesignOrderFormCategoryRecord`, whose typed properties are `SelectedMaterialFamily` and `RawRemark`. Therefore production behavior was present; the source-token guard was mismatched to the implementation identifiers.

## Approved corrective

1. Change only the two Architecture guard tokens from `SelectedMaterialFamily` / `RawRemark` to `selectedFamily` / `rawRemark`.
2. Preserve every other required read-only/fail-closed token and every forbidden write/generic-reader token.
3. Change the `PartTypeCategoryResolverTests.Categories()` helper return type to `DesignOrderFormCategoryDefinition[]` to clear CA1859.
4. No production source behavior change.

## Explicitly unchanged

- `ExcelDesignOrderFormReader.cs` production implementation;
- `TMPL::Part_Type` and `TMPL::Material`;
- Design Order X + Remark rules;
- trim/space/case normalization;
- steel-grade comparison semantics;
- Table mode;
- Cimatron PDM adapter/API route;
- configuration;
- model/workbook mutation behavior.

## Required user validation

Run only:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Return the generated `quality-gate-*.txt`. Do not begin controlled live Cimatron validation until the 0.39.2 gate is reviewed and passes.
