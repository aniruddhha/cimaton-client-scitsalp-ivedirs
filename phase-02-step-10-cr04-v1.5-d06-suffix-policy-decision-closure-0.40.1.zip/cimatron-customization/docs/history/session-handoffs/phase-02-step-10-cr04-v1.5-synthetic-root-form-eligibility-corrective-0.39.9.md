# Phase 02 / Step 10 / CR-04 v1.5 — Synthetic Root.elt Form Eligibility Corrective — 0.39.9

## Entering accepted evidence

- `quality-gate-20261007-003106.txt`: 0.39.8 full workstation quality gate PASS, Release x64 0 warnings / 0 errors, all governed suites/coverage/local gate PASS, exit 0.
- `Cimatron-Result-Report-20261007-003425.csv`: Cavity/Core/CoreInsert matches preserved; six real `cmAssembly` occurrences correctly skipped; seven Part-property read errors remained.
- `api-capability-cr04-slice2a-20261007-004150.txt`: exactly seven remaining error candidates are synthetic `cmPart` traversal occurrences with exact `ModelPid = \\5\Root.elt`. The full traversal identity rule explicitly remains no self-instance filtering.

## Approved 0.39.9 change

- Preserve full traversal and D-15/highlight identity behavior unchanged.
- Preserve existing non-`cmPart` Form skip behavior.
- Before native Part-property reading, skip exact synthetic `ModelPid = \\5\Root.elt` and emit `[CAD_SYNTHETIC_ROOT_SKIPPED]` Info.
- Preserve genuine real-`cmPart` property-read failures as Errors.
- Add focused Application regression proving synthetic Root.elt causes zero Part-reader calls.
- No Cimatron Integration source change, ModelTitle heuristic, threshold/config/DO/Table/workbook/model mutation change.

## User acceptance sequence

1. Extract this cumulative ZIP exactly to `cimatron-customization/`.
2. Run `powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"`.
3. If PASS, restart Cimatron so the new Application assembly is loaded.
4. Open the same disposable/test-copy mold assembly used for the 0.39.8 live run; do not save changes.
5. Run `Steel Grade Design-Order Validation` against the same external client DO and export the Result Report CSV.
6. Expected: Cavity/Core/CoreInsert matches remain; the former seven `CAD_PART_PROPERTY_READ_ERROR` rows become `CAD_SYNTHETIC_ROOT_SKIPPED` Info; genuine unrelated real-Part failures, if any, remain Errors.
7. Confirm assembly remains unmodified.

## Validation state

Agent performed static source/diff/hash/package checks only. Full workstation quality gate and live Cimatron acceptance remain user-run.
