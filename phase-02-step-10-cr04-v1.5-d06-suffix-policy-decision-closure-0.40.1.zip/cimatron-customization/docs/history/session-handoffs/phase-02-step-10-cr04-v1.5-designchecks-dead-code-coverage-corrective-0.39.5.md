# Phase 02 / Step 10 — CR-04 v1.5 DesignChecks dead-code / coverage corrective — 0.39.5

## Scope

Approved narrow Option A corrective following `quality-gate-20261006-221138.txt` and the supplied 0.39.4 coverage XML evidence.

## Mandatory pre-check

PASS. Repo-wide `src/`, `tests/`, `tools/` search found zero callers or reflection access to private `TryParseCategoryPatterns`. The single test-side textual match is an Architecture forbidden-token guard that verifies the legacy call is absent.

## Production change

- `SteelGradeDesignOrderValidation.cs`: remove orphaned private `TryParseCategoryPatterns` only.
- Keep the `ComponentCategoryPatterns` parameter surface unchanged.
- Preserve exclusion semantics while removing the impossible post-`SplitList` blank-entry rejection and impossible caller failure path.
- `SplitList`, `RemoveEmptyEntries`, trim and `Length > 0` filtering remain unchanged.
- DesignChecks assembly/file version aligned to `0.39.5.0` because that production assembly changed.

## Tests

Existing test classes only; every new method is registered in the class `RunAll()`. `Program.cs` is unchanged. No reflection access to private members is used.

- `SteelGradeDesignOrderValidationFeatureTests`: `PublicConstructorAcceptsConfiguredUseCase`; `ExclusionListIgnoresEmptyEntries`.
- `Step08BInProcessConfirmationTests`: `UnavailableOccurrenceReadReturnsSourceStatusImmediately`; `MissingNestedBodyReferenceSkipsMappingAndHighlight`; `UnavailableAssemblyMappingSkipsNestedHighlight`; `UnexpectedMappedEntityTypeFailsAndDoesNotExposeHighlightReference`; `BomMaterialMismatchFailsLockedMaterialCheck`; `NoMutationFailureFailsFoundationConfirmation`.
- `TopLevelHighlightDiagnosticFeatureTests`: `NullExecutionContextIsRejected`; `NullDiagnosticIdCollectionsFormatAsEmpty`.

`TopLevelHighlightDiagnosticResult` normalizes null candidate/repeated ID collections to empty arrays before DesignChecks receives them. Therefore the null-ID test validates the public normalization/result behavior; it does not artificially force the private `FormatIds(null)` branch.

## Projected DesignChecks coverage

0.39.4 XML baseline: `571 / 611 = 93.453%`.

Projected 0.39.5 denominator changes:

- remove 26 coverable lines from orphaned `TryParseCategoryPatterns`;
- replace the old 12-coverable-line exclusion parser with an expected 3-coverable-line equivalent parser: denominator `-9`;
- simplify the impossible Form caller failure path: expected denominator `-2`.

Projected denominator: `611 - 26 - 9 - 2 = 574`.

Projected covered lines after structural cleanup and the approved reachable tests: `573`.

Projected line coverage: `573 / 574 = 99.826%`.

This is a projection only. The user workstation coverage XML is authoritative.

Application remains 91.87% vs 90% minimum (+1.87 percentage points) and Infrastructure remains 81.45% vs 80% minimum (+1.45 percentage points) based on the entering gate. The DesignChecks-focused corrective changes neither source denominator.

## Open follow-up

Retirement of the now-obsolete `ComponentCategoryPatterns` parameter definition/validation/configuration surface remains a separately approved future decision. It is not part of 0.39.5.

## Validation required

Run the full workstation quality gate from the repository root:

`powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"`

Return the generated `quality-gate-*.txt`. Do not accept 0.39.5 until the full gate passes.
