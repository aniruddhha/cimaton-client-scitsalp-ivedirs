# Phase 02 Step 10 — CR-04 v1.5 Slice 4 Category-Contract Handoff — 0.34.0

## Status

**IMPLEMENTED / AWAITING USER WORKSTATION QUALITY GATE.** Context health: GREEN.

This package does not claim build/test/analyzer/Cimatron PASS. The agent did not execute those activities.

## Baseline and approval

- Baseline: cumulative `0.33.0` Slice 3 closure package.
- Slice 1 / Slice 2 / Slice 3: CLOSED / USER VALIDATED.
- Accepted prior gate: `quality-gate-20261006-011609.txt`, Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0. Raw evidence is intentionally excluded.
- User explicitly approved the exact Slice 4 plan. Exact approval timestamp is not independently captured and is not invented.
- Agent active-work start observed at `2026-10-06T01:39:04+05:30`.

## Approved category contract

The Form profile category keys are authoritative:

- `Cavity` — Cavity
- `Core` — Core
- `CavityInsert` — Cavity Insert
- `CoreInsert` — Core Insert
- `MovingCore` — Moving Core
- `AngularLifter` — Angular Lifter
- `PressurePad` — profile label remains `Pressuer Pad` as already defined by the approved production profile
- `WearPad` — Wear Pad
- `MouldBase` — Mould Base

This Slice does not change the profile or its source-workbook spelling. It only validates configured mapping keys against the composed profile.

## ModelTitle rule

`ModelTitle` is deployment-configured opaque string/pattern data.

- no client naming convention is inferred;
- exact arbitrary strings are valid mappings;
- existing `*`/`?` wildcard matching remains available only when deliberately configured;
- unknown category keys fail closed;
- unresolved or ambiguous mapping behavior remains fail-safe in the existing Application resolver.

## Implementation

### `SteelGradeDesignOrderValidation.cs`

Form `ComponentCategoryPatterns` parsing now receives the composed `DesignOrderFormProfile`. Each `CategoryKey` must exactly match one of `formProfile.Categories[].CategoryKey` using ordinal comparison. Unknown keys produce a `CR04_CONFIGURATION_ERROR` before the Application validation delegate runs.

Feature ID remains `STEEL-GRADE-DESIGN-ORDER-VALIDATION`. BodyAttribute-only steel-grade source, Strict production representation, `CompareGradeTokenOnly=false`, Table/Form separation, and runtime Design Order path behavior are unchanged.

### Tests

`SteelGradeDesignOrderValidationFeatureTests` now proves:

- all nine approved category keys are accepted;
- arbitrary opaque ModelTitle strings are preserved through request construction;
- an unknown category key fails before the Application use case executes;
- existing malformed/missing mapping guards remain.

The test class was already registered; `Program.cs` is unchanged.

### Architecture guards

Slice 4 guard requires:

- all nine approved Sridevi profile category key/label contracts;
- profile-driven category-key validation in the feature;
- production config contains no invented `ComponentCategoryPatterns`;
- runtime picker stays `.xlsx/.xls` and no CSV is introduced.

The existing eight-file SHA-256 protected guard remains unchanged and authoritative.

## Production configuration

`config/CimatronCustomization.config.xml` is unchanged.

No real production ModelTitle strings were supplied, therefore no category mapping is inserted. Form execution still intentionally fails closed until deployment-specific `ComponentCategoryPatterns` are configured with real values.

## Protected / unchanged scope

No dependency upgrades, project-reference changes, client workbook, Cimatron model changes, new Cimatron API use, runtime-picker changes, or protected-file changes are included.

The eight v1.5 protected files must remain byte-identical to their accepted hashes.

## Required workstation validation

With Cimatron closed, run from repository root:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Acceptance required before Slice 4 closure:

- Release x64 build PASS;
- 0 warnings / 0 errors;
- Architecture PASS;
- Domain PASS;
- Application PASS;
- CimatronIntegration PASS;
- Infrastructure PASS;
- coverage gate PASS;
- local quality gate PASS;
- exit code 0.

Supply the generated quality-gate `.txt` externally. Do not add raw quality-gate evidence to the cumulative ZIP.

## Still-open production inputs

- real deployment ModelTitle strings/patterns for the approved categories;
- final client confirmation of `STEEL_GRADE` / `cmAttString` naming;
- suffix semantics;
- blank-grade business meaning;
- production template validation-range defect disposition.
