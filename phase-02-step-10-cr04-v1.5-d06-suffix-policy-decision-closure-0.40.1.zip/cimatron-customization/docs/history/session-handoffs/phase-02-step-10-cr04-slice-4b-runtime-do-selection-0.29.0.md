# Session Handoff — Phase 02 Step 10/4 — CR-04 Slice 4B Runtime Design-Order Selection — 0.29.0

## Project
Cimatron 2026 customization platform.

## Context Status
GREEN — implementation prepared; user workstation quality gate required before any live Cimatron validation.

## Current Phase / Step
- Phase: `02 — CR Platform Extensions`
- Step: `10/4 — CR-04 Slice 4B Runtime Design-Order Selection`
- Product/package version: `0.29.0`
- Application assembly metadata: `0.29.0.0`
- DesignChecks assembly metadata: `0.29.0.0`
- Plugin assembly metadata: `0.29.0.0`

## Entering Accepted Evidence
User workstation `quality-gate-20261005-171737.txt` for 0.28.1 is accepted as clean:
- Release x64 PASS;
- 0 warnings / 0 errors;
- Architecture, Domain, Application, CimatronIntegration and Infrastructure tests PASS;
- coverage/local quality gates PASS;
- exit code 0.

This validates the 0.28.1 public-API boundary corrective. Plugin still has no direct Domain reference.

## Approved Decisions Implemented
### D-09
Resolved to option **(c) launcher file dialog**.

For CR-04:
1. user starts the feature from the normal Feature Launcher;
2. Plugin opens an Excel file picker;
3. selected `.xlsx` / `.xls` path is carried only as per-run `FeatureRunInputs[DesignOrderPath]`;
4. no Design Order path is persisted in production config;
5. Cancel returns before correlation/checklist execution, so no CR-04 validation is run.

### D-03 — controlled Design Order supplied by user
External controlled-test workbook: `KA-ASM-1-CR04-WRONG-TYPE-SMOKE_DO(1).xlsx`.

Verified layout:
- worksheet: `Input Sheet`;
- header row: `1`;
- component key header: `Component`;
- steel-grade header: `Steel Grade`;
- workbook note: `Component` equals the Cimatron model title;
- workbook note: select the workbook through the CR-04 browse dialog at runtime.

The workbook itself is **not embedded** in the cumulative source ZIP.

## Production Configuration State
`config/CimatronCustomization.config.xml` now records only approved values needed from the supplied DO / already-approved decisions:
- `DesignOrderWorksheetName = Input Sheet`
- `DesignOrderHeaderRow = 1`
- `DesignOrderComponentKeyHeader = Component`
- `DesignOrderSteelGradeHeader = Steel Grade`
- `SteelGradeSource = BodyAttribute` (approved D-01 Option A)
- `ComponentKeySource = ModelTitle` (supported by the supplied DO)

No `DesignOrderPath` or `DesignOrderPathPattern` is stored.

## Still Unresolved — Important
The project does **not** invent these remaining customer/user values:
- **D-02:** `SteelGradeAttributeName`
- **D-05:** `SteelGradeRepresentation`
- **D-06:** `CompareGradeTokenOnly`

Therefore 0.29.0 is not yet a complete executable production CR-04 parameter set. After the quality gate passes, resolve these values before a full business-validation live Cimatron run.

The existing known-answer `STEP07_B1_TEST_ATTRIBUTE = KNOWN_ANSWER_07C3` is body-string capability evidence, not proof that the body contains steel grade `1.2738`; do not silently use it as D-02.

## Code Changes
- `ExecuteFeatureChecklist` carries optional `FeatureRunInputs` through the existing execution context while preserving the old overload.
- `SteelGradeDesignOrderValidation` obtains `DesignOrderPath` from per-run inputs rather than XML rule parameters.
- `FeatureLauncherWindow` owns the runtime Excel browse/select/cancel flow.
- focused Application/DesignChecks tests and architecture guards cover run-input propagation, missing runtime path, browse/cancel contract, D-03 config values, and prohibition of persisted path/path-pattern configuration.

## Explicitly Not Changed
- CR-04 Domain business rules;
- `VerifySteelGradeAgainstDesignOrder` semantics;
- `CimatronAssemblyBodyAttributeReader` traversal/read behavior;
- Result Report/highlighter;
- BOM route;
- D-09(b);
- D-15(b);
- Assist Part handling;
- wrong-type smoke behavior;
- CR-04 v1.4 requirement text;
- any Cimatron model.

## Validation State
- Agent build/tests/coverage/analyzers: NOT EXECUTED by policy.
- User workstation quality gate for 0.29.0: AWAITING USER EXECUTION.
- Live Cimatron business validation: BLOCKED until clean 0.29.0 quality gate **and** D-02/D-05/D-06 are resolved.

## Exact Next Action
From the repository root run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Return the complete generated quality-gate capture. Do not perform the live CR-04 business-validation run if any build warning/error, test failure, architecture failure, or coverage/local-gate failure occurs.
