# Phase 02 — Step 10 — CR-04 Slice 2A Session Handoff — 0.24.1

## Project
Cimatron 2026 customization platform.

## Phase / Step
- Phase: 02 — CR Platform Extensions
- Step: 10 — CR-04 Slice 2A Capability Investigation
- Version: 0.24.1
- Context Status: **AMBER — start a new ChatGPT session before further implementation**
- Current Status: **QUALITY GATE PASS / AWAITING LIVE CIMATRON VALIDATION**

## Latest Approved Package
`phase-02-step-10-cr04-slice-2a-session-handoff-0.24.1.zip`

The package is cumulative and extracts to exactly `cimatron-customization/`.

## Requirement
CR-04 verifies that the steel/material grade specified for a component in the customer Design Order Excel matches the steel/material-grade evidence available from the corresponding Cimatron CAD component. Future production flow: read DO -> find CAD component -> read grade/material evidence -> normalize/compare -> report PASS/FAIL -> provide safe highlight reference.

## Approved Scope
Slice 2A is a **read-only runtime capability investigation** before Slice 3. It verifies:

1. exact production-highlighter-equivalent occurrence traversal;
2. self-instance observation and exclusion basis;
3. `InstanceId` collision frequency/impact under D-15;
4. body attribute present/missing/wrong-type semantics;
5. `GetAllEntities()` behavior;
6. zero/one/multiple known-grade body evidence;
7. no-mutation evidence.

No CR-04 business workflow or production adapter is approved yet.

## Completed Work

### Slice 1 — CLOSED / USER VALIDATED
0.23.1 is closed. User evidence confirmed:
- Release x64 build PASS;
- 0 warnings / 0 errors;
- governed test suites PASS;
- local coverage gate PASS;
- all new CR-04 production Domain classes meet the approved >=95% line / >=90% branch class-level Cobertura target.

### Slice 2A implementation
0.24.0 introduced:
- `--verify-cr04-capabilities` in `ApiCapabilityVerification`;
- exact highlighter-equivalent traversal contract;
- self-instance PID-based observation;
- `InstanceId` collision evidence;
- read-only known/missing/wrong-type body attribute observations;
- no-mutation capture;
- deterministic fake-tree traversal/collision tests.

### 0.24.1 corrective
0.24.0 workstation quality gate passed functionally but reported 3 `CA1859` test warnings. 0.24.1 changed only the three test collection types/signatures and governance metadata. No production or verifier behavior changed.

### Clean workstation evidence
Authoritative capture:
`artifacts/console-captures/quality-gate-20261003-000106.txt`

Result:
- Build succeeded;
- 0 warnings / 0 errors;
- Release x64 build PASS;
- Architecture tests PASS;
- Domain tests PASS;
- Application tests PASS;
- Cimatron Integration tests PASS;
- Infrastructure tests PASS;
- coverage gate PASS;
- local quality gate PASS;
- exit code 0.

Agent did not execute these checks; this is user workstation evidence.

## Pending Work
Live Slice 2A Cimatron validation is still mandatory. Slice 2A is **not closed** and Slice 3 must not start until runtime evidence is reviewed.

## Existing Model Decision
A brand-new `KA-ASM-CR04` is **not mandatory for the first live run**.

The verifier accepts `--model-title TITLE` and verifies the active model against that supplied title. It requires at least one `cmBody` that returns the supplied known `cmAttString` value.

Start with existing known-answer model:
- Model: `KA-ASM-1`
- Known attribute: `STEP07_B1_TEST_ATTRIBUTE`
- Known value: `KNOWN_ANSWER_07C3`

These were previously verified in Step 07C-3 / Step 08B.

Create/use a dedicated `KA-ASM-CR04` only if existing known-answer models cannot supply a controlled blank-string case, useful collision observation, or another required edge case.

## Important Decisions

- **D-15:** highlight safety is based on `InstanceId` uniqueness across the exact production highlighter search scope. Current instance ID is checked first; descend only when `get_SubInstances(1,0)` is non-empty and occurrence model type is `cmAssembly`; maximum depth 16.
- Self-instances remain inside D-15 collision/safety traversal but are excluded from future CR-04 business evaluation using containing-model identity/PID, never title or hard-coded ID.
- Natural live collisions are observed rather than artificially forced; deterministic collision behavior is covered by fake-tree tests.
- **D-16:** blank Design Order grade -> Error (provisional customer-policy decision already implemented in Slice 1).
- **D-08:** DO component missing in CAD -> Failed; CAD component carrying grade but absent in DO -> Warning.
- **D-14:** zero CAD grade values -> missing; one distinct value -> usable; multiple distinct values -> ambiguous/Failed.
- **D-05/D-06:** grade representation/token behavior remains configurable, not a customer default.
- **D-09(b):** self-instance/active-assembly identification uses model identity/PID, not title/fixed ID.

## Cimatron API Findings Relevant to Slice 2A
- `IAssemblyModel.GetInstances()` is present in authoritative Cimatron SDK documentation.
- `IAssInstance.GetAllEntities()` remains installed-Interop/governed runtime evidence rather than an authoritative SDK-documented method.
- Existing production `CimatronViewportEntityHighlighter` remains unchanged.
- Cross-component `MinDistancePos` limitation from earlier verification remains unrelated to CR-04 Slice 2A.

## Exact Next Step

1. Open Cimatron normally.
2. Open existing `KA-ASM-1` Assembly.
3. From the repository root in PowerShell run:

```powershell
.\tools\CimatronCustomization.ApiCapabilityVerification\bin\x64\Release\CimatronCustomization.ApiCapabilityVerification.exe `
  --verify-cr04-capabilities `
  --expect Assembly `
  --model-title "KA-ASM-1" `
  --known-attribute-name "STEP07_B1_TEST_ATTRIBUTE" `
  --known-attribute-value "KNOWN_ANSWER_07C3"
```

4. Send the generated `api-capability-cr04-slice2a-*.txt` evidence file to the new ChatGPT session.
5. Do **not** create a new model yet unless the live result shows an existing-model coverage gap.

## Expected Live Evidence
Review the generated diagnostic for:
- total occurrences;
- self-instance count and IDs;
- whether self ID 3 repeats (observation only; never hard-code);
- repeated `InstanceId` collision rows;
- collision impact on occurrences carrying known-grade evidence;
- known-string present/value behavior;
- missing-name behavior;
- wrong-type lookup behavior;
- `GetAllEntities()` null/read-error behavior;
- zero/one/multiple exact-known-value body evidence;
- `NoMutation.Result: PASS`.

If the existing model has no controlled blank-string case, record that as **not observed**, not PASS. Add a dedicated model/control only through a new approved plan if required.

## Known Issues / Limitations
- Slice 2A live evidence has not yet been run/reviewed.
- A dedicated blank-string control may not exist in `KA-ASM-1`.
- Natural `InstanceId` collision may not occur; absence in one model is an observation, not proof that collisions cannot occur.
- `GetAllEntities()` remains runtime evidence only.
- Slice 3 remains blocked.

## Files Added in This Handoff Refresh
- `artifacts/console-captures/quality-gate-20261003-000106.txt`
- `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-session-handoff-0.24.1.md`

## Files Modified in This Handoff Refresh
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256`

No `src/**`, test source, verifier source, Plugin, configuration, or model file is modified by this handoff refresh.

## Files To Read First In New Session
1. `AGENTS.md`
2. `VERSION.md`
3. `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-session-handoff-0.24.1.md`
4. `tools/CimatronCustomization.ApiCapabilityVerification/Cr04CapabilityVerification.cs`
5. `tests/CimatronCustomization.CimatronIntegrationTests/Cr04TraversalSafetyTests.cs`
6. `artifacts/console-captures/quality-gate-20261003-000106.txt`
7. CR-04 implementation specification v1.4 if available in the session/workspace.

## New-Session Prompt

Use this prompt after uploading/extracting the handoff ZIP:

> Continue the Cimatron 2026 customization project from `phase-02-step-10-cr04-slice-2a-session-handoff-0.24.1.zip`. Read `AGENTS.md`, `VERSION.md`, and `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-session-handoff-0.24.1.md` first. CR-04 Slice 1 is closed/user validated. Slice 2A 0.24.1 has a clean user workstation quality gate (0 warnings / 0 errors, all governed gates PASS) but live Cimatron validation is still pending. Do not start Slice 3. First guide me through the read-only live Slice 2A run on existing `KA-ASM-1` using `STEP07_B1_TEST_ATTRIBUTE=KNOWN_ANSWER_07C3`, then analyze the generated diagnostic evidence. Follow AGENTS.md approval and evidence rules strictly and keep responses concise.
