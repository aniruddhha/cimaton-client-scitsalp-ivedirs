# Phase 02 / Step 10 / CR-04 v1.5 — 0.40.0 Result Report CSV Enhancement

## Status

- Product/runtime version: `0.40.0`.
- Entering baseline: `0.39.9 USER VALIDATED / CLOSED`.
- Current state: **AWAITING USER QUALITY GATE**.
- Export format: **CSV only**. No XLSX/Open XML or Office dependency was added.

## User-approved reporting contract

The Result Report CSV must preserve the current Cimatron assembly-tree traversal sequence rather than alphabetically sorting components. It must expose the component title so the engineer can locate the object in the assembly. Dedicated DO Category and DO Material columns are not required because Part Type is the classification used by CR-04 and DO material remains available in the existing diagnostic message when relevant.

Primary component/report columns are:

`ComponentTitle,OccurrencePath,InstanceId,PartType,MoldPartMaterial,ValidationStatus,FindingCode`

Existing traceability columns remain after those fields:

`Feature,Requirement,Message,Measured,Limit,CorrelationId`

## Implemented behavior

- Findings may carry optional immutable component-report metadata: Component Title, Occurrence Path, Instance ID, traversal occurrence order, normalized Part Type, and Part Material.
- Form-mode occurrence findings populate this metadata without changing their existing business statuses/messages.
- Steel-grade comparison findings preserve all matching occurrence contexts. A many-to-one category PASS therefore exports one row per actual assembly component occurrence.
- The CSV exporter orders component rows by captured traversal occurrence order. Global/non-component findings follow the component rows.
- Finding Code is extracted from the existing leading `[CODE]` message contract.
- Export status mapping:
  - `Passed` / `Succeeded` -> `PASS`
  - `Failed` / `Error` / `Unsupported` -> `FAIL`
  - `Warning` -> `WARNING`
  - `DO_COMPONENT_NOT_FOUND` -> `NOT FOUND`
  - `CAD_NON_PART_SKIPPED`, `CAD_SYNTHETIC_ROOT_SKIPPED`, `CAD_COMPONENT_EXCLUDED`, existing `Skipped` / `NotApplicable` -> `SKIPPED`
  - remaining informational findings -> `INFO`
- Summary appended at end: Total, PASS, FAIL, WARNING, NOT FOUND, SKIPPED, INFO, Overall Status.
- Overall Status is `ACTION REQUIRED` if any FAIL, WARNING, or NOT FOUND row exists; otherwise `PASS`.

## Safety / compatibility boundaries

Unchanged:

- CR-04 native Part Type and Part Material production sources.
- Design Order Form parsing and X/Remark semantics.
- Steel-grade normalization/comparison rules.
- Full Cimatron traversal and D-15/highlight identity behavior.
- Native Part-property read route.
- Result Report UI filtering and viewport selection restoration.
- CSV UTF-8 BOM and CSV escaping behavior.
- Configuration, thresholds, client workbook/model, and read-only/no-mutation behavior.

No client Design Order or raw client Result Report CSV is included in this package.

## Regression protection added/updated

- Application tests assert structured context on a many-to-one Form PASS, blank-Part-Type warning, and non-Part skip.
- Architecture source guards require the new CSV schema, structured-context expansion, traversal-order sort, normalized status mapping, summary, and retained CSV-only input/output boundaries.
- Approved protected hashes were aligned only for the reporting-context propagation changes in `SteelGradeDesignOrderEvaluation.cs` and `SteelGradeOccurrenceHighlightSafety.cs`.

## Time tracking

- Exact user approval receipt timestamp: not independently captured; intentionally left blank.
- Agent work start: `2026-10-07T11:06:05+05:30`.
- Agent package submission/finalization timestamp recorded in ledger: `2026-10-07T11:12:58+05:30`.
- Active agent time: `6.88` minutes.
- User feedback wait time is not counted as active work.

## Required user validation

Run the normal full workstation quality gate from the extracted package root:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Do not run live Cimatron acceptance until the full quality gate passes with the governed suites/coverage and 0 warnings / 0 errors.

After a PASS, run the normal CR-04 Form validation on the controlled test-copy assembly and export the Result Report CSV. Confirm:

1. component rows follow the Cimatron assembly-tree traversal sequence;
2. PASS rows for configured components show Component Title, path, Instance ID, Part Type, and Mold Part Material;
3. `CAD_NON_PART_SKIPPED` / `CAD_SYNTHETIC_ROOT_SKIPPED` rows show `SKIPPED`;
4. missing/unresolved category rows show `NOT FOUND` where applicable;
5. the summary is present at the end with the correct overall status;
6. assembly remains unmodified after the run.

## Next acceptance state

0.40.0 must remain **AWAITING USER QUALITY GATE** until the user supplies authoritative workstation evidence. No PASS or live-validation claim is made by the agent.
