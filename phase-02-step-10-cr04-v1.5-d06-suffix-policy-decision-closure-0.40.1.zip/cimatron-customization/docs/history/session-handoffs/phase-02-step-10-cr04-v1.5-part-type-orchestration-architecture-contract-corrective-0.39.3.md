# Phase 02 Step 10 — CR-04 v1.5 Native Part Type Orchestration Architecture Contract Corrective — 0.39.3

## Status

- Phase: 02 — CR Platform Extensions
- Step: 10 / CR-04 v1.5
- Version: 0.39.3
- Status: CORRECTIVE IMPLEMENTED / AWAITING USER QUALITY GATE
- Context: GREEN

## Entering user evidence

User supplied `quality-gate-20261006-214154.txt` for 0.39.2. Release x64 build passed with 0 warnings / 0 errors, then the quality gate stopped at Architecture Tests and exited 1. Direct execution of the ArchitectureTests binary reproduced: `CR-04 v1.5 native Part Type/Part Material Form orchestration lost a required contract.`

## Root cause

The Architecture source guard required literal strings `[CAD_PART_TYPE_MISSING]` and `[CAD_PART_TYPE_UNSUPPORTED]` inside the Form orchestration. Production uses the actual code literals `CAD_PART_TYPE_MISSING` and `CAD_PART_TYPE_UNSUPPORTED`, then formats the user-facing finding with `$"[{code}] ..."`. Therefore the runtime/business contract is present but the source-token guard was requiring a representation that does not literally appear in source.

## Approved corrective

1. Change only the two Architecture required tokens from `[CAD_PART_TYPE_MISSING]` / `[CAD_PART_TYPE_UNSUPPORTED]` to `CAD_PART_TYPE_MISSING` / `CAD_PART_TYPE_UNSUPPORTED`.
2. Preserve every other native Part Type/Part Material Form-orchestration guard and forbidden legacy-path assertion.
3. No production source or behavior change.

## Explicitly unchanged

- `VerifySteelGradeAgainstDesignOrder.cs` production behavior;
- `TMPL::Part_Type` and `TMPL::Material`;
- Part Type to Design Order category mapping;
- Design Order selected-family X + Remark semantics;
- trim/space/case normalization;
- Form reader and PDM adapter;
- Table mode;
- configuration;
- Cimatron models/client workbook;
- read-only/no-mutation guarantees.

## Required user validation

Run only:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Return the generated `quality-gate-*.txt`. Do not begin controlled live Cimatron validation until the 0.39.3 gate is reviewed and passes.
