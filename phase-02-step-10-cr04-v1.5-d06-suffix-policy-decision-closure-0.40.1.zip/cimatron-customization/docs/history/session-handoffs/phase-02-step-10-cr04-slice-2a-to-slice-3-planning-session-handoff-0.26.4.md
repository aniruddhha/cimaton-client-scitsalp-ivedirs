# Phase 02 — CR-04 Slice 2A to Slice 3 Planning — Session Handoff — 0.26.4

Date: 2026-10-05
Product version: 0.26.4
Context status: AMBER — start a new ChatGPT session before beginning Slice 3 planning/implementation work.
Current product state: CR-04 Slice 2 CLOSED / USER VALIDATED; Slice 2A Package 2 CLOSED / USER VALIDATED.

## Governing instruction

`AGENTS.md` is controlling and must be read in full before any planning or implementation. The new session must not infer approval from this handoff. Slice 3 implementation is **NOT APPROVED** by this package. First prepare a precise Slice 3 execution plan, exact file list, risks, tests, workstation quality gate, and Cimatron validation plan, then wait for explicit user approval.

## Latest approved package

Authoritative predecessor package:

`phase-02-step-10-cr04-slice-2a-package-2-highlight-restore-closure-0.26.4.zip`

That package is the user-validated 0.26.4 closure baseline. This handoff package is cumulative and changes documentation/governance/checksums only; it does not change production/runtime/test behavior.

## Completed work carried forward

### Slice 2

Slice 2 Application work is CLOSED / USER VALIDATED. Existing Application/Domain behavior must not be reopened without an explicit new defect or approved requirement change.

### Slice 2A / Package 2

Slice 2A Package 2 is CLOSED / USER VALIDATED on 0.26.4.

Accepted workstation/runtime evidence carried forward:

- Release x64 quality gate PASS.
- 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS.
- Coverage collection/gate PASS; local quality gate PASS; exit code 0.
- Approved fixture: `Model\KA-ASM-1-Step07C4-U16-single-part-corrected\CR11_BASELINE\KA-ASM-1.elt`.
- `[TOPLEVEL_HIGHLIGHT_TARGET_READY]`: seen.
- Intended top-level `KA-PART-1` highlighted: YES / PASS.
- Unrelated occurrence highlighted: NO / PASS.
- Highlight restored/cleared after Result Report close: YES / PASS.
- Assembly remained unmodified: YES / PASS.
- User closure approval receipt recorded in the prior closure package at `2026-10-05T03:14:41+05:30`.

The 0.26.4 corrective fixed only the temporary-selection lifecycle. The verified CR-04 target-resolution/traversal behavior must remain protected unless a separately approved defect requires change.

## Decisions that must NOT be reopened in Slice 3 planning

- D-15(a): full unfiltered traversal `InstanceId` uniqueness remains mandatory; first-match fallback is prohibited.
- D-15(b): DEFERRED.
- Collision-frequency measurement: MOVED TO SLICE 5.
- D-17 Assist Parts: EXCLUDED-PROVISIONAL; genuine Assist Part evidence remains unavailable/unverified.
- Wrong-type attribute semantics: FAIL-SAFE RULE.
- Read-only CR-04 validation must remain read-only.
- API/runtime/read errors must not be reported as business-rule failures.

## What Slice 3 planning is expected to cover

The governing revised Slice 2A closure plan permits Slice 3 adapter planning now that Package 2 has passed. The new session must determine the exact production scope from the current repository and the CR-04 v1.4 requirement/specification before proposing implementation.

The known mandatory Slice 3 concern carried forward is the **production Cimatron adapter boundary for CR-04 body-attribute reading**, including the genuine same-name non-string/wrong-type smoke that was deliberately moved out of Slice 2A.

The approved fail-safe rule to preserve in the plan is:

- read the requested body attribute through the verified Cimatron body-attribute path;
- valid string value → usable input;
- null/missing → provisionally absent, consistent with the existing approved behavior;
- COM/API/read failure → fail closed as a technical/read error;
- do not silently infer type safety;
- the Slice 3 smoke must use a genuine stored-as-non-string attribute with the same requested name;
- if querying that genuine wrong-type control as `cmAttString` produces a normal-looking conforming string, STOP adapter acceptance and ask the user for a design decision rather than silently accepting it.

Do not assume this paragraph is the complete Slice 3 file scope. The new session must inspect the repository and relevant specification and produce the exact plan first.

## Existing code areas to inspect first for Slice 3 planning

At minimum inspect, without editing:

- `src/CimatronCustomization.Application/IAssemblyBodyAttributeReader.cs`
- `src/CimatronCustomization.Application/AssemblyBodyAttributeSnapshot.cs`
- `src/CimatronCustomization.Application/AssemblyBodyAttributeOccurrence.cs`
- `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrder.cs`
- `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrderRequest.cs`
- `src/CimatronCustomization.Application/SteelGradeOccurrenceHighlightSafety.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronOccurrenceEntityAttributeReader.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityHighlighter.cs`
- existing CimatronIntegration/Application/Architecture test coverage relevant to CR-04;
- Step 07/08 verified API evidence and current CR-04 handoffs/history.

Do not modify any of these until the user approves the Slice 3 plan and exact existing-file list.

## Client-package blocker carried forward

Before any client package is produced, the developer-only Package 2 diagnostic registration, all eight diagnostic source files, `tools/Request-TopLevelHighlightDiagnostic.ps1`, and the two diagnostic test files must be removed under **separately approved scope**.

This cleanup is not automatically part of Slice 3 and must not be performed unless the user explicitly approves it.

## Known limitations / pending items

- Genuine same-name stored-as-non-string attribute behavior is not yet live-verified; this is a Slice 3 adapter smoke item.
- D-15(b) remains deferred.
- Collision-frequency evidence remains deferred to Slice 5.
- Genuine Assist Part identification/exclusion remains provisional/unverified.
- No Slice 3 exact file list is approved yet.

## Exact next step in the new session

1. Read `AGENTS.md` completely.
2. Read `VERSION.md`, `IMPLEMENTATION-HISTORY.md`, `CHANGELOG.md`, and this handoff.
3. Read `docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md`.
4. Read the CR-04 v1.4 requirement/specification. If it is not present in the ZIP/current chat, request it rather than guessing.
5. Inspect the current Application and CimatronIntegration boundaries relevant to `IAssemblyBodyAttributeReader` and the already-verified Step 07/08 APIs.
6. Prepare a concise **Slice 3 implementation plan only** containing:
   - intended capability;
   - exact new files, if any;
   - exact existing files proposed for modification;
   - justification for every existing-file change;
   - assumptions and API facts that still require verification;
   - TDD/regression tests;
   - architecture guards;
   - workstation quality-gate steps;
   - genuine wrong-type Cimatron smoke procedure and stop criteria;
   - documentation/version/package impacts;
   - estimated active engineering time.
7. Wait for explicit user approval before changing any file.

## Files to read first

Priority order:

1. `AGENTS.md`
2. `VERSION.md`
3. `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-to-slice-3-planning-session-handoff-0.26.4.md`
4. `docs/history/session-handoffs/phase-02-step-10-cr04-slice-2a-package-2-highlight-restore-closure-0.26.4.md`
5. `docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md`
6. `IMPLEMENTATION-HISTORY.md`
7. `CHANGELOG.md`
8. relevant CR-04 v1.4 specification/source material
9. the Application/CimatronIntegration source and tests listed above.

## Agent execution note

No build, tests, coverage, deployment, request script, or Cimatron execution was performed by the agent for this handoff. No production/runtime/test logic was changed.
