# Phase 02 / Step 10 / CR-04 v1.5 — Native Part Material Production Source — 0.38.0

## Status

Implementation prepared. **Awaiting user workstation quality gate.** No build, test, coverage, analyzer, SonarQube, or Cimatron execution was performed by the AI agent for 0.38.0.

## Approved production rule

The client-confirmed Cimatron native **Part Material** property is the authoritative Steel Grade source for CR-04. The historical custom `STEEL_GRADE` body attribute is no longer a production source of truth and remains only as historical/API diagnostic evidence. There is no production fallback to `STEEL_GRADE`.

## Entering validated evidence

- User-supplied `quality-gate-20261006-152016.txt` validated the 0.37.0 entering baseline: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0.
- User-run read-only diagnostic `cr04-target-component-read-diagnostic-20261006-152500.txt` completed with 130 occurrences / 883 bodies. It confirmed approved category mappings while showing the legacy `STEEL_GRADE` body attribute as absent or no-body on target components.
- User supplied Cimatron UI evidence for `Cavity block` showing native `Part Material = P-20-2311`, matching the client discussion.

## 0.38.0 implementation

- Added an Application port and immutable result/row types for native Part Material table reading.
- Added `CimatronBomMaterialTableReader`, using only the already verified in-process route: `IAssemblyModel.GetBomManager()` -> `IBOM.Export(..., cmNoFiltering, ...)` -> temporary BOM CSV.
- Correlation contract: BOM `Standard Number` -> occurrence `ModelTitle`; BOM `Material` -> CR-04 observed Steel Grade.
- Assembly traversal remains authoritative for occurrence/category/suppression/highlight context.
- Zero-body occurrences may still obtain Steel Grade from Part Material; an explicit Application test was added for this case.
- Blank native Part Material reaches the existing controlled missing-grade behavior. BOM/Part Material read failure returns `CAD_PART_MATERIAL_READ_ERROR`.
- Legacy steel-grade body-attribute read errors are ignored for production grade evaluation. The protected body-attribute reader remains unchanged for historical/API diagnostics and traversal compatibility.
- Production configuration now uses `SteelGradeSource=PartMaterial` and contains no production `SteelGradeAttributeName` entry.
- CR-04 v1.5 specification, architecture guards, Application tests, CimatronIntegration static contract tests, versioning, changelog, history, and governance were updated.
- Changed production assemblies were aligned to `0.38.0.0` per repository version governance.

## Safety and scope boundaries

- No model modification or save.
- No Design Order workbook modification.
- No new external dependency.
- No new/speculative Cimatron API route.
- No fallback to custom `STEEL_GRADE`.
- Client Design Order workbook is not included in the package.
- Raw workstation quality-gate/diagnostic evidence is not included in the package.
- The eight protected CR-04 v1.5 files remain byte-identical to their authoritative hashes.

## Validation prepared, not executed by agent

Static/package checks only were performed: XML parsing, source structure checks, approved-scope diff review, protected-file SHA-256 verification, forbidden artifact/client-data checks, checksum-manifest regeneration, and ZIP integrity verification. Fresh user workstation evidence is mandatory before any PASS claim.

## User workstation next step

With Cimatron completely closed, run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

If the full gate passes, run CR-04 on the updated test-copy Assembly and export the Result Report CSV. The live acceptance focus is that native Part Material values such as `Cavity block -> P-20-2311` are read and compared to the Design Order without requiring `STEEL_GRADE` body attributes.

## Timing

- User approval: `2026-10-06T15:39+05:30` (session metadata provided minute precision; seconds intentionally not invented).
- Agent work start: `2026-10-06T15:39+05:30` (minute precision).
- Agent submission/package preparation observation: `2026-10-06T15:58:28+05:30`.
- Agent active work: approximately 19 minutes, rounded to available start-time precision.
- User feedback wait during implementation: not applicable / not recorded as agent work.
- Rework: `0.00` minutes for this 0.38.0 implementation cycle.
