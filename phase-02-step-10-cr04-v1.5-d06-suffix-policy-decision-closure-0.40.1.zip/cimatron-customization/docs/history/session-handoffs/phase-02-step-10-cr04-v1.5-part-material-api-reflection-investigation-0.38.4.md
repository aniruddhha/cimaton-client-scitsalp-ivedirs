# Phase 02 / Step 10 / CR-04 v1.5 — Part Material API Reflection Investigation — 0.38.4

## Status

**IMPLEMENTED / AWAITING USER QUALITY GATE AND REFLECTION EXECUTION.**

## Entering authoritative state

- Baseline package: `phase-02-step-10-cr04-v1.5-part-material-correlation-diagnostic-closure-0.38.3.zip`.
- 0.38.3 workstation quality gate: PASS; Release x64 0 warnings / 0 errors; all governed suites and coverage/local gate PASS; exit 0.
- 0.38.3 controlled read-only correlation diagnostic: 8 approved targets, 6 BOM rows; exact `ModelTitle` ↔ BOM `Standard Number` correlation succeeded only for `Lifter-01 -> P20` and `core fix insert-01 -> P-20-2311`.
- Six approved target ModelTitles had no exact BOM Standard Number match: `Cavity block`, `Core block`, `Main Core insert`, `main insert`, `Insert#2`, `Slider-01`.
- User Cimatron UI evidence separately proves `Cavity block` native Part Material = `P-20-2311`; therefore unmatched BOM correlation must not be treated as absent Part Material.

## Production rule retained

- Native Cimatron `Part Material` is the authoritative Steel Grade source.
- Validation is read-only against the Design Order Steel Grade.
- Custom `STEEL_GRADE` body attribute is diagnostic/history only and is not a production fallback.
- Blank/unreadable native Part Material remains an explicit missing/read-error result.

## Approved 0.38.4 scope

Developer-only reflection investigation of installed Cimatron 2026 Interop. No production `src/` modification.

Two candidate routes are inventoried:

1. typed material-related members on relevant application/document/model/instance interfaces and inherited interfaces;
2. PDM/document-attribute retrieval through installed `IPdm`, `IDocAttribute`, `DocAttribute`, with exact installed signatures for `RetriveDocAttribute`, `RetriveLinkAttribute`, `GetRelatedDocuments`, `GetDocumentByPath`, and `TitleOfPid`.

A global secondary inventory records every public installed-Interop member whose name contains `material` case-insensitively.

## Important interpretation boundary

Official Cimatron documentation proves that `IPartDocument.Description` maps to document attribute `CN_DESCRIPTION` and that `IPdm.RetriveDocAttribute` retrieves document attributes by path/persistent ID. It does **not** prove that native Part Material is itself a document attribute. Therefore:

- the PDM route is a candidate transport mechanism only;
- `Native Part Material attribute identity: NOT VERIFIED` must remain explicit;
- a reflection Classification B means only `CANDIDATE READ ROUTE FOUND — RUNTIME VALIDATION REQUIRED`.

Historical U17 statements remain unchanged and continue to describe retained 07A evidence.

## Files added

- `tools/CimatronCustomization.ApiCapabilityVerification/PartMaterialApiReflectionInvestigation.cs`
- `docs/history/session-handoffs/phase-02-step-10-cr04-v1.5-part-material-api-reflection-investigation-0.38.4.md`

## Existing files modified

- `tools/CimatronCustomization.ApiCapabilityVerification/Program.cs`
- `tools/CimatronCustomization.ApiCapabilityVerification/CimatronCustomization.ApiCapabilityVerification.csproj`
- `tools/Invoke-ApiCapabilityVerification.ps1`
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/platform/CIMATRON-2026-API-CAPABILITY-VERIFICATION.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256`

`tests/CimatronCustomization.ArchitectureTests/Program.cs` remains byte-identical.

## Reflection safety contract

The new investigation:

- loads installed `interop.*.dll` via `Assembly.ReflectionOnlyLoadFrom`;
- records metadata/signatures only;
- never calls `GetApplication`, `GetActiveDoc`, `GetPdm`, `RetriveDocAttribute`, or another reflected/runtime method;
- does not use reflection invocation or COM activation;
- does not open, save, mutate, or attach to a Cimatron document/model.

## User validation required

### 1. Full quality gate

Run the existing full project quality gate. Required result:

- Release x64 PASS;
- 0 warnings / 0 errors;
- Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS;
- coverage collection/gate PASS;
- local quality gate PASS;
- exit 0.

### 2. Installed-Interop reflection investigation

Run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-ApiCapabilityVerification.ps1" -Mode part-material-reflect
```

Return the generated `part-material-api-reflection-*.txt` evidence for review.

## Outcome interpretation

- **A — NO CANDIDATE DIRECT PART MATERIAL READ ROUTE FOUND:** no credible typed getter and no usable installed `RetriveDocAttribute`-style route.
- **B — CANDIDATE READ ROUTE FOUND — RUNTIME VALIDATION REQUIRED:** a plausible typed getter or usable installed `RetriveDocAttribute` signature is present. This does not prove Part Material attribute identity.

Do not implement or plan the runtime read diagnostic until the reflection evidence is reviewed and the user separately approves the next scope.

## Packaging exclusions

Raw quality-gate output, reflection evidence/captures, console captures, coverage artifacts, client Design Order workbook, and Cimatron models remain outside the cumulative ZIP unless explicitly approved.
