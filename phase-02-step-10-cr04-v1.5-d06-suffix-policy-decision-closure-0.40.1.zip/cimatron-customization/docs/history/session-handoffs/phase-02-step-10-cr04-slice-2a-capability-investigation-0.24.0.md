# Phase 02 Step 10 Handoff — CR-04 Slice 2A Capability Investigation — 0.24.0

## Status

IMPLEMENTATION PREPARED / AWAITING USER QUALITY GATE AND CIMATRON VALIDATION.

## Baseline

- Previous package: `phase-02-step-09-cr04-domain-rules-corrective-0.23.1.zip`.
- Slice 1 is CLOSED / USER VALIDATED from supplied clean 0.23.1 build/test/coverage evidence.
- Current package version: 0.24.0.

## Approved scope

Read-only runtime investigation only. No CR-04 adapter/business workflow and no production highlighter changes.

## Added

- `tools/CimatronCustomization.ApiCapabilityVerification/Cr04CapabilityVerification.cs`
- `tests/CimatronCustomization.CimatronIntegrationTests/Cr04TraversalSafetyTests.cs`

## Modified existing files

- `tools/CimatronCustomization.ApiCapabilityVerification/Program.cs` — register CLI mode and usage; ToolVersion 0.24.0.
- `tools/CimatronCustomization.ApiCapabilityVerification/CimatronCustomization.ApiCapabilityVerification.csproj` — compile new verifier.
- `tools/CimatronCustomization.ApiCapabilityVerification/Properties/AssemblyInfo.cs` — changed development assembly → 0.24.0.0.
- `tests/CimatronCustomization.CimatronIntegrationTests/Program.cs` — execute new test fixture.
- `tests/CimatronCustomization.CimatronIntegrationTests/CimatronCustomization.CimatronIntegrationTests.csproj` — compile new test file.
- `tests/CimatronCustomization.CimatronIntegrationTests/Properties/AssemblyInfo.cs` — changed test assembly → 0.24.0.0.
- governance/version/history/time/checksum docs required by AGENTS.md.

## Runtime evidence produced

- exact highlighter-equivalent occurrence traversal;
- self-instance PID observations and ID distribution;
- suppressed occurrence participation;
- repeated InstanceId rows;
- collision impact count/percentage for known-grade occurrences;
- body count and known/missing/wrong-type attribute observations;
- `GetAllEntities()` null/read-error observations;
- zero/one/multiple exact-known-value body evidence;
- no-mutation before/after evidence.

## User execution order

1. Run the governed quality gate.
2. If clean, open the prepared `KA-ASM-CR04` Assembly in Cimatron and do not edit it during the diagnostic.
3. Run the verifier command from the repository root with the exact CR-04 attribute name/value used in the prepared model.
4. Return the quality-gate capture and `artifacts/diagnostics/api-capability-cr04-slice2a-*.txt`.

## Stop rule

Do not approve Slice 3 until the runtime evidence resolves D-15/self-instance and missing/wrong-type attribute semantics. Unexpected behavior is investigation required, not a business failure.
