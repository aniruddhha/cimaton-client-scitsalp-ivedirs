# Phase 02 — CR-04 Slice 2A Package 2 — Temporary-Highlight Restoration Corrective Handoff — 0.26.4

Date: 2026-10-05
Product version: 0.26.4
Status: SUPERSEDED BY 0.26.4 USER-VALIDATED CLOSURE HANDOFF
Context health: GREEN

## Governing instruction

`AGENTS.md` is controlling. The AI agent prepared source/tests/documentation/package only and did not execute the build, governed tests, coverage, deployment, request script, or Cimatron validation.

## Entering evidence

- Clean workstation quality gate for 0.26.3: USER VALIDATED before this corrective.
- First governed live run: invalid fixture; not acceptance evidence.
- User-approved replacement run fixture: `Model\KA-ASM-1-Step07C4-U16-single-part-corrected\CR11_BASELINE\KA-ASM-1.elt`.
- Replacement correlation ID: `e9a94f01c46c4dadb0e323d0ef18f3a9`.
- Result Report: Passed.
- `[TOPLEVEL_HIGHLIGHT_TARGET_READY]`: present.
- Intended top-level `KA-PART-1` viewport highlight: visually confirmed.
- No unrelated occurrence highlighted: PASS.
- Programmatic no-mutation: PASS.
- Assembly remained unmodified: YES.
- Highlight restored/cleared after Result Report close: NO.

Package 2 therefore remained OPEN.

## Root cause

`FindingReportWindow` called `IViewportEntityHighlighter.Highlight(...)`, but report close/dispose did not request restoration. `CimatronViewportEntityHighlighter` assigned the temporary entity list to `ISelection.Selection` and retained no previous selection. The failure was therefore a missing temporary-highlight lifecycle contract, not a target-resolution/traversal failure.

## Approved 0.26.4 corrective

- Add `RestoreSelection()` to `IViewportEntityHighlighter`.
- Capture the original selection only immediately before the first temporary highlight assignment.
- Preserve that capture across subsequent highlights while the same Result Report is open.
- Restore the captured selection through the existing verified `ISelection.Selection` boundary when the Result Report closes.
- Restore an originally empty selection using an explicit empty `CimEntityList`.
- Keep the already verified target-resolution logic unchanged: depth limit, `get_SubInstances(1,0)` condition, occurrence entity lookup, and `GetAssemblyEntity` mapping remain intact.
- Replace the historical byte-identical highlighter hash pin with narrow semantic regression guards for traversal/highlight/restore behavior.
- Align the governed request class, diagnostic feature traceability version, and request script to 0.26.4.

## Protected-file justification

`src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityHighlighter.cs` was protected in Package 2. The user explicitly approved its modification after the read-only investigation demonstrated that the adapter had no way to retain/restore the pre-highlight selection. The 0.26.4 change is limited to temporary selection lifecycle support; entity resolution and CR-04 traversal are not intentionally changed.

## User validation sequence

### Gate 1 — workstation quality gate

From the repository root, with Cimatron closed:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-And-Capture.ps1" -Task quality-gate
```

Required acceptance before any live run:

- Release x64 build PASS;
- 0 warnings / 0 errors;
- all governed test suites PASS;
- coverage gate PASS;
- local quality gate PASS;
- exit code 0.

STOP and provide the captured `.txt` output if any item fails. Do not run the live diagnostic after a failed gate.

### Gate 2 — live validation

Only after Gate 1 is accepted. The exact live steps will be confirmed from the clean-gate evidence before execution. The acceptance requirement remains: correct top-level target highlight, no unrelated highlight, programmatic no-mutation PASS, assembly unchanged, and highlight restored/cleared after Result Report close.

## Explicit non-claims

- No 0.26.4 build/test/coverage PASS is claimed by the agent.
- No 0.26.4 Cimatron PASS is claimed.
- Package 2 is not closed.
- Slice 3 remains blocked.
- D-15(b), collision-frequency, D-17 and wrong-type dispositions are unchanged.
- Client-package removal of the developer-only Package 2 diagnostic remains BLOCKING and separately governed.


## Closure supersession

This corrective-preparation handoff is retained as historical evidence. It is superseded by `phase-02-step-10-cr04-slice-2a-package-2-highlight-restore-closure-0.26.4.md`, which records the clean user-workstation quality gate, successful governed live restoration validation, and explicit user closure approval received at `2026-10-05T03:14:41+05:30`.
