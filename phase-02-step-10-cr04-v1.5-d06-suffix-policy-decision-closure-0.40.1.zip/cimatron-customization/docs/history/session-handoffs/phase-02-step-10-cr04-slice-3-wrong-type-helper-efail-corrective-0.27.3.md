# Phase 02 / Step 10 — CR-04 Slice 3 Wrong-Type Helper E_FAIL Corrective — 0.27.3

## Trigger

User workstation quality gate for `0.27.2` (`quality-gate-20261005-112440.txt`) is accepted: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, exit code 0.

The approved controlled wrong-type setup then produced:

- `ReadBack.Type: cmAttInteger`
- `ReadBack.Value: 2738`
- deliberate production-shaped `cmAttString` query: COM `E_FAIL`

The integer readback proves the genuine wrong-type fixture exists. The `E_FAIL` supports the approved FAIL-SAFE RULE as `ReadError`; the hard-stop condition was not triggered because no conforming-looking string was returned.

## Corrective scope

Only the development-only `KnownAnswerModelSetup` post-setup observation path changes. `AppendStringQueryObservation` catches `COMException` around the deliberate `GetAttribute(cmAttString, name)` call and records:

- `PostSetupCmAttStringQuery.Status: READ_ERROR`
- exception type
- HRESULT
- message

Normal evidence-file/result completion then proceeds. No production adapter/runtime logic changes. `CimatronCustomization.KnownAnswerModelSetup` metadata advances to `0.27.3.0`; CimatronIntegration production metadata remains `0.27.2.0`.

## Validation sequence

1. User reruns `Invoke-QualityGate.ps1`; require Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0.
2. With the existing disposable `KA-PART-1-CR04-WRONG-TYPE` still containing the control, rerun the same `--cr04-wrong-type-control` helper command. It must detect the existing matching integer without overwrite, record `READ_ERROR` for the string query, write its evidence file, and exit successfully.
3. Only after review, proceed to the environment-gated production-adapter live smoke.

## Stop rules

- If the rerun reports a conflicting existing type/value, STOP.
- If the production-shaped string query returns a conforming-looking `Present` value, STOP for user decision.
- If the quality gate is not clean, do not run live smoke.
- No model autosave is performed by the helper.

## AI execution boundary

The agent did not run build/tests/coverage, deploy, execute the helper, save the model, or launch Cimatron. User workstation evidence remains authoritative.
