# Phase 02 Step 10 — CR-04 v1.5 Slice 5 Client Test Mapping Handoff — 0.35.0

## Status

**IMPLEMENTATION PREPARED / AWAITING USER QUALITY GATE.** Context health: GREEN.

## Approved controlled mapping

- `Cavity block` -> Cavity -> `P-20-2311`
- `Core block` -> Core -> `P-20-2311`
- `main insert` / `Insert*` -> Cavity Insert -> `P-20-2311`
- `Main Core insert` / `core fix insert-01` -> Core Insert -> `P-20-2311`
- `Slider-01` -> Moving Core -> `P-20-2311`
- `Lifter-01` -> Angular Lifter -> `P-20-2311`
- mold-base plates/components -> Mould Base -> `CK-45` (business expectation only; no machine-readable ModelTitle pattern approved)

No Pressure Pad or Wear Pad ModelTitle mapping is approved. No unresolved mapping is invented.

## D-02

Resolved as body/entity `STEEL_GRADE` / `cmAttString`, with no BOM fallback and no alternate-type probing.

## Safety boundary

Do not modify the original client Design Order or baseline Cimatron models. Controlled CR-04 validation must use copies only. Any deliberate steel-grade setup or mismatch mutation is restricted to disposable test copies.

## Implementation

- production config now carries only the explicitly approved test `ComponentCategoryPatterns`;
- focused feature test locks exact mapping parsing and preserves unresolved Mould Base status;
- Architecture guards require the exact approved mapping and prohibit invented Mould Base/Pressure Pad/Wear Pad patterns;
- runtime picker remains `.xlsx/.xls`; no CSV;
- no dependency/project/Cimatron API change;
- eight v1.5 protected files remain byte-identical.

## Required workstation validation

With Cimatron closed, run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\tools\Invoke-QualityGate.ps1"
```

Required: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage/local quality gate PASS, exit 0.

After a clean gate, controlled live CR-04 validation may proceed only on copied client DO/reference models. Raw quality-gate/runtime evidence stays outside cumulative ZIPs.

## Known documentation boundary

The existing production feature traceability string in `SteelGradeDesignOrderValidation.cs` still contains pre-Slice-5 wording that D-02 naming is pending. Slice 5 explicitly approved no source-code change beyond config, so that historical traceability text is not altered here. Runtime configuration and this authoritative spec/history record D-02 as resolved. Any cleanup of that source metadata requires a separately approved source change.
