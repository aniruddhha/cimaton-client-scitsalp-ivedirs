# Implementation Specification — CR-04 Steel Grade Verification Against Design Order

| Field | Value |
|---|---|
| Spec ID | IS-CR-04 |
| Spec version | **1.5 — Approved implementation direction** |
| Supersedes | `CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.4.md` |
| Requirement | CR-04 — Steel grade verification against Design Order (DO) |
| Feature ID | `STEEL-GRADE-DESIGN-ORDER-VALIDATION` |
| Feature kind | `Validation` (read-only) |
| Client | **Sridevi Tool Engineers Pvt. Ltd.** |
| Production DO basis | `4075_P_DO.XLSX`, form/template identity `QR/DG/02 REV 04`, dated `03/12/2021` |
| Platform baseline | `cimatron-customization` **0.38.2 workstation-validated; 0.38.3 read-only Part Material correlation diagnostic pending workstation validation** |
| Status | **APPROVED / IMPLEMENTED IN 0.38.0; 0.38.2 live Part Material read path reached evaluation; 0.38.3 read-only correlation diagnostic prepared — awaiting workstation quality gate and controlled live diagnostic** |

> **Client-data rule:** the production workbook is client data. It is an external reference input and must not be added to the repository, cumulative handoff ZIPs, test fixtures, source control, or distributable package.

---

## 1. Purpose

CR-04 verifies that the steel grade carried by each relevant Cimatron mold component agrees with the steel grade prescribed by the client's Design Order.

The feature remains read-only. It must not modify the active Cimatron Assembly, any referenced Part, attributes, geometry, workbook, or any other customer data.

### 0.38.2 live-validation corrective

The first 0.38.0 live run and the controlled 0.38.1 live rerun both reached the native Part Material adapter but stopped with `TABULAR_HEADERS_CHANGED` before steel-grade comparison. 0.38.1 attempted to lock the full seven-column BOM header sequence, but live evidence proves that an independent expected-header snapshot is not a safe production contract for this Cimatron BOM export.

The 0.38.2 corrective therefore uses a **single exported BOM snapshot and a single tabular read**. `CimatronBomMaterialTableReader` calls `IBOM.Export(..., cmNoFiltering, ...)` once, identifies the one generated CSV, and calls `ITabularDataReader.Read(source)` once without a separate `expectedHeaders` argument. The same read resolves only the required named fields: `Standard Number` for occurrence correlation and `Material` for native Part Material evidence. Missing required columns still fails closed through the shared tabular reader. This is a reader-consistency correction only; the approved Part Material source and all CR-04 business rules remain unchanged.

The authoritative production-form direction for v1.5 is the Sridevi Tool Engineers Design Order form identified by:

- form/template marker: `QR/DG/02 REV 04`;
- production reference workbook: `4075_P_DO.XLSX`;
- mould number in the reference workbook: `ST4075 P`.

The workbook field `Customer Name = M&M-MATE` identifies Sridevi Tool Engineers' customer for this Design Order. It is not a CR-04 identity key and is not used in matching or validation.

---

## 2. Production DO profile — verified Stage A facts

### 2.1 Workbook structure

The profiled production workbook contains:

- `Sheet1` — populated Design Order form;
- `Sheet2` — empty;
- `Sheet3` — empty;
- `Sheet1` print area — `A1:R39`.

The Form profile uses `Sheet1`.

### 2.2 Template guard

`Sheet1!A39` contains the form identity text:

`QR/DG/02                                REV  04       03/12/2021`

For template comparison:

1. trim leading/trailing whitespace;
2. collapse every internal run of whitespace to one ASCII space;
3. compare with ordinal, case-sensitive semantics.

The normalized expected value is:

`QR/DG/02 REV 04 03/12/2021`

A missing, duplicated, or non-matching template guard is an Error. The reader must not silently fall back to another worksheet or another form profile.

### 2.3 Mould number

`Sheet1!O5 = ST4075 P`.

CR-04 shall read and report this value as workbook metadata. Because no reliable Cimatron mould/document identity source is presently approved for CR-04, no identity comparison is performed.

Emit an informational finding:

`[MOULD_NUMBER_CHECK_NOT_PERFORMED] Design-Order mould number 'ST4075 P' was read, but no approved Cimatron mould-identity source is available for comparison.`

This is not a failure and must not change the CR-04 business result.

### 2.4 Steel-grade block

The production grade block is rows 18–26. Labels are read from the merge anchor in column `A` (`A:B` merged). Grade values are read from the merge anchor in column `I` (`I:L` merged).

| Row | Production form label | Reference grade |
|---:|---|---|
| 18 | `Cavity` | `P-20-2311` |
| 19 | `Core ` | `P-20-2311` |
| 20 | `Cavity Insert` | blank |
| 21 | `Core Insert` | blank |
| 22 | `Moving Core` | `P-20-2311` |
| 23 | `Angular Lifter` | `P-20-2311` |
| 24 | `Pressuer Pad` | blank |
| 25 | `Wear Pad` | blank |
| 26 | `Mould Base` | `CK-45` |

`Core ` includes a trailing space in the workbook. Label matching therefore uses the D-11 normalization rule in §7.

`Pressuer Pad` is the spelling present in the production template. The Form profile shall treat it as the production label for this template revision and shall not silently rewrite the workbook.

### 2.5 Material-selection X columns

The material-selection columns are:

| Column | Meaning |
|---|---|
| C | P-20 |
| D | AL |
| E | CK-45 |
| F | BE-CU |
| G | Hardened |
| H | Nitrided |

The reference workbook has X marks consistent with the populated grades: P-20 for Cavity, Core, Moving Core, and Angular Lifter; CK-45 for Mould Base.

For the approved production rule, the material-family X columns and the row `Remark` are interpreted together:

- exactly one `X` plus a nonblank `Remark` defines a material requirement;
- no `X` plus blank `Remark` defines no material requirement and produces no CR-04 steel-grade finding for that category;
- more than one `X`, `X` with blank `Remark`, or nonblank `Remark` without an `X` is a fail-closed Design-Order input Error;
- a nonblank selection marker other than `X` (case-insensitive after trim) is an Error.

The selected family is metadata describing the requirement. The normalized `Remark` is the exact grade/specification compared with Cimatron Part Material. No family-prefix inference is invented.

### 2.6 Closed grade vocabulary

The production template's list validation defines the permitted grade vocabulary for the grade block:

- `I18:L23` → `$CC$14:$CC$26`
- `I24:L24` → `$CB$29:$CB$31`
- `I25:L26` → `$CC$32:$CC$39`

The Form profile shall use the vocabulary associated with the applicable form row/category. Empty cells in the source list do not create valid grade values.

The profiled values include, as applicable:

- `P-20-2738`
- `P-20-2311`
- `P-20-2711`
- `P-20-2738 Doosan`
- `P-20-2311 Doosan`
- `P-20-2711 Doosan`
- `P-20-2738 PCK`
- `P-20-2311 PCK`
- `P-20-2711 PCK`
- `GEST-80`
- `P-20-2738 HH`
- `P-20-2738 TSHH`
- `S55C Doosan`
- `EN-31`
- `CK-45`

### 2.7 Confirmed template defect

Two values are present near the source lists but fall outside the validation ranges used by the grade cells:

- `1.2343/H-11` at `CC27`;
- `EN-353` at `CB28`.

This is a **template defect / client clarification item**. v1.5 must record it and must not silently expand the closed vocabulary to include these values. If either value appears in production data before the client confirms the intended validation range, CR-04 treats it under D-05 as an unknown value and reports Warning.

---

## 3. Platform state at 0.30.1

The v1.4 platform description is superseded by the following accepted state.

### 3.1 Slice 3 — Cimatron production adapter — CLOSED

Reference:

`docs/history/session-handoffs/phase-02-step-10-cr04-slice-3-post-closure-session-handoff-0.27.10.md`

Accepted scope includes:

- production `CimatronAssemblyBodyAttributeReader`;
- full approved occurrence traversal;
- body filtering;
- exact `GetAttribute(cmAttString, configuredName)` lookup;
- no alternate-type probing;
- fail-safe `ReadError` behavior;
- read-only operation;
- wrong-type in-process smoke closure.

The later 0.30.1 positive smoke additionally proves the actual production reader in-process against saved controlled evidence:

`docs/history/session-handoffs/phase-02-step-10-cr04-production-reader-steel-grade-smoke-closure-0.30.1.md`

### 3.2 Slice 4A — feature wiring — CLOSED for wiring scope

References:

- `docs/history/session-handoffs/phase-02-step-10-cr04-slice-4a-implementation-handoff-0.28.0.md`
- corrective history at platform `0.28.1` in `IMPLEMENTATION-HISTORY.md`.

Accepted scope includes:

- `SteelGradeDesignOrderValidation`;
- `FeatureComposition` registration;
- preserved Plugin → Domain boundary;
- workstation quality-gate closure after the public-API corrective.

This closure is limited to feature wiring and architecture. It is not the final end-to-end production-form business validation.

### 3.3 Slice 4B — runtime Design Order selection — CLOSED for runtime-selection scope

Reference:

`docs/history/session-handoffs/phase-02-step-10-cr04-slice-4b-runtime-do-selection-0.29.0.md`

The 0.29.1 corrective subsequently restored a zero-warning workstation quality gate.

Accepted behavior:

- the Plugin owns the file browse/select dialog;
- selection is passed as per-run `FeatureRunInputs[DesignOrderPath]`;
- cancel exits before CR-04 checklist execution;
- no production workbook path is persisted in config/model/registry/filesystem by this flow.

The final production-form reader/profile and full CR-04 business validation remain pending under v1.5.

---

## 4. Decision register

### D-01 — CAD component category and steel-grade sources

**Decision: RESOLVED — native Cimatron Part Type and Part Material through PDM document attributes.**

Controlled Cimatron 2026 runtime evidence verified:

- File Properties **Part Type** -> document attribute `TMPL::Part_Type`;
- File Properties **Part Material** -> document attribute `TMPL::Material`.

Production Form-mode route:

`occurrence ModelPid -> IApplication.GetPdm() -> IPdm.RetriveDocAttribute(..., ref object, "") -> IDocAttribute.Name/Value`

Rules:

- `TMPL::Part_Type` is the authoritative component-category source for Form mode;
- `TMPL::Material` is the authoritative actual material/steel-grade source for Form mode;
- no Form-mode fallback to ModelTitle patterns, Description/Details, BOM `Type`, BOM Standard Number correlation, or custom `STEEL_GRADE`;
- Table mode retains its existing BOM material route for backward compatibility;
- the read is strictly read-only.

### D-02 — historical `STEEL_GRADE` body attribute

**Decision: SUPERSEDED FOR PRODUCTION — retained only as historical/API diagnostic evidence.**

The earlier controlled `STEEL_GRADE` / `cmAttString` fixture remains valid evidence that the body-attribute API route can read a known string attribute. It is no longer the CR-04 production source of truth and must not be required by production configuration or used as a fallback when Part Material is blank/unreadable.

Production contract:

- Form category source: native `TMPL::Part_Type`;
- Form material source: native `TMPL::Material`;
- transport/read route: verified PDM document-attribute read by occurrence `ModelPid`;
- Table mode BOM route remains supported independently;
- custom `STEEL_GRADE`: diagnostic/history only;
- no fallback to `STEEL_GRADE`;
- no model mutation or save.

### D-03 — Design Order layout / reader

**Decision: RESOLVED FOR v1.5 DESIGN.**

Introduce:

`DesignOrderFormat = Form`

and a client Form profile for the Sridevi `QR/DG/02 REV 04` layout described in §2.

Requirements:

- add a new Form-specific Design Order reader;
- keep the existing Table path supported;
- do not retrofit Form logic into the generic Step-06 tabular reader;
- the existing `ExcelTabularDataReader.cs` must remain byte-identical;
- `DesignOrderFormat = Table` continues to use the existing tabular pipeline.

The production file is external client data and is never committed as a fixture.

### D-04 — Cimatron component → DO category

**Decision: RESOLVED — native Part Type.**

Form mode maps the normalized value of `TMPL::Part_Type` directly to the approved logical category vocabulary. ModelTitle is not a category source.

Approved profile mapping:

| Cimatron Part Type | Logical DO category | Production Form label |
|---|---|---|
| `Cavity` | Cavity | `Cavity` |
| `Core` | Core | `Core` |
| `Cavity Insert` | CavityInsert | `Cavity Insert` |
| `Core Insert` | CoreInsert | `Core Insert` |
| `Moving Core` | MovingCore | `Moving Core` |
| `Angular Lifter` | AngularLifter | `Angular Lifter` |
| `Pressure Pad` | PressurePad | `Pressuer Pad` |
| `Wear Pad` | WearPad | `Wear Pad` |
| `Mould Base` | MouldBase | `Mould Base` |

Part Type normalization before matching:

1. trim leading/trailing whitespace;
2. collapse internal whitespace runs to one ASCII space;
3. compare case-insensitively.

Blank Part Type and unsupported Part Type produce controlled findings and do not fall back to ModelTitle. Explicit configured exclusions may still use ModelTitle patterns only to exclude known non-CR-04 components; exclusions are not a category classification mechanism.

### D-05 — comparison and grade vocabulary

**Decision: RESOLVED — Strict comparison plus closed-vocabulary validation.**

Comparison policy:

- `SteelGradeRepresentation = Strict`;
- the Design-Order expected grade is the trimmed `Remark` for a row with exactly one selected material-family `X`;
- Cimatron actual grade is the trimmed `TMPL::Material` value;
- existing approved steel-grade normalization remains responsible for comparison semantics; no new punctuation/suffix equivalence is invented;
- both Design Order Remark values and Cimatron native Part Material values are checked against the applicable closed vocabulary before comparison.

Unknown vocabulary value:

- produce Warning;
- do not treat the unknown value as a valid match merely because the same unknown string appears on both sides;
- the affected mapped category/component is not counted as successfully validated.

The validation vocabulary comes from the approved client Form profile derived from the production template's data validation ranges. The known template-defect values in §2.7 are not silently admitted.

### D-06 — grade suffix handling

**Decision: RESOLVED — no separate suffix semantics or maintenance.**

`CompareGradeTokenOnly = false`

Production validation compares the full normalized Cimatron native Part Material value (`TMPL::Material`) with the full normalized Design Order `Remark` value for the mapped row.

Suffix text such as `Doosan`, `PCK`, `HH`, or `TSHH` is not extracted, stripped, mapped, maintained, or validated as a separate field or rule. CR-04 does not assign independent business meaning to such suffix text. If suffix text is present, it remains part of the material string being compared under the existing approved normalization/comparison policy.

No additional client suffix-maintenance table or suffix-specific production logic is required.

### D-09 — runtime file selection

**Decision: RESOLVED — runtime file picker, as implemented.**

Current Plugin filter:

`Excel workbooks (*.xlsx;*.xls)|*.xlsx;*.xls`

Behavior:

- `.xlsx` is accepted;
- `.xls` is accepted by the picker;
- cancel performs no CR-04 run;
- the selected path is passed only for the current execution.

For v1.5 Form mode, both `.xlsx` and `.xls` must enter the Form reader through the same logical profile. The Form reader must parse either format read-only using the approved Excel-reading dependency/strategy. If the selected file cannot expose the required `Sheet1`, anchors, or template guard, it returns a Form read/template Error; it must not fall back to Table mode.

`Table` mode remains supported by the unchanged generic tabular reader.

### D-11 — Form label matching

**Decision: RESOLVED; legacy tabular-header question is not applicable to Form mode.**

For Form profile labels:

1. read the configured anchor cell;
2. trim leading/trailing whitespace;
3. collapse internal whitespace runs to one ASCII space;
4. compare using case-sensitive ordinal semantics.

The Form profile expects exactly one instance of each required production label/anchor definition.

- label not found → Error;
- label found more than once → Error.

This rule intentionally makes `Core ` equivalent to expected profile label `Core` after whitespace normalization.

Table mode retains its existing generic tabular behavior unchanged.

### D-15 — highlight identity

**Decision: unchanged.**

D-15(a) remains accepted: a highlight reference is emitted only when occurrence identity is safe under the approved highlighter-equivalent uniqueness rules.

D-15(b) placement-specific enhancement remains deferred and is not part of v1.5 implementation.

### D-16 — Design Order material-selection / Remark validity

**Decision: RESOLVED FOR v1.5.**

For each Form category row:

- exactly one selected-family `X` + nonblank `Remark` -> valid material requirement;
- no selected-family `X` + blank `Remark` -> no material requirement; no steel-grade finding is generated for that category;
- multiple `X` -> Error;
- `X` + blank `Remark` -> Error;
- nonblank `Remark` + no `X` -> Error;
- nonblank marker other than `X` -> Error.

Whitespace-only values are treated as blank after trim. Raw Remark remains available separately for evidence/reporting.

### D-17 — Assist Parts

**Decision: RESOLVED — excluded.**

Assist Parts are outside CR-04 validation scope. They are not used to satisfy a DO category and do not produce steel-grade match/mismatch findings.

---

## 5. Form-reader contract

### 5.1 New Form reader

The Form reader is a CR-04-specific reader/profile path, separate from the generic Step-06 Table reader.

Input:

- runtime-selected Excel path;
- `DesignOrderFormat`;
- client Form profile.

Output shall include at minimum:

- normalized template identity;
- mould number;
- category records containing:
  - stable category key;
  - production label;
  - source row;
  - selected material family, including explicit no-selection;
  - raw Remark and trimmed comparison Remark (`SteelGrade` compatibility field);
  - applicable closed vocabulary;
- structured read/template errors.

The reader must not return a partially trusted result when the template guard fails.

### 5.2 Read-only file access

The workbook must be opened:

- `FileMode.Open`;
- `FileAccess.Read`;
- `FileShare.ReadWrite`.

No workbook save/write API is permitted.

### 5.3 Profile identity

Initial client profile:

`Sridevi_QR-DG-02_REV04`

Minimum profile constants:

- worksheet: `Sheet1`;
- template guard cell: `A39`;
- normalized guard: `QR/DG/02 REV 04 03/12/2021`;
- mould-number cell: `O5`;
- grade block: rows 18–26;
- label anchor column: `A`;
- grade anchor column: `I`;
- current category labels from §2.4;
- validation-vocabulary source mapping from §2.6.

These are template-profile values, not generic reader hard-coding.

---

## 6. Component/category mapping contract

### 6.1 Stable category keys

The client profile defines stable logical category keys separately from the displayed template labels.

Example keys:

- `Cavity`
- `Core`
- `CavityInsert`
- `CoreInsert`
- `MovingCore`
- `AngularLifter`
- `PressurePad`
- `WearPad`
- `MouldBase`

The profile may map logical key `PressurePad` to production label `Pressuer Pad` without rewriting the customer workbook.

### 6.2 Native Part Type mapping

Category assignment uses only `TMPL::Part_Type` through the verified PDM document-attribute route. The profile owns the mapping from Cimatron Part Type text to stable logical category key and production Form label.

Part Type text is trimmed, internal whitespace is collapsed, and matching is case-insensitive. A blank or unsupported Part Type produces a controlled finding and is not silently remapped.

### 6.3 Native Part Material

For a mapped category with a valid Design-Order material requirement, actual CAD grade is read from `TMPL::Material`. Leading/trailing whitespace is trimmed before vocabulary validation/comparison. Blank material produces Error; unknown material outside the applicable closed vocabulary produces Warning and is excluded from successful comparison.

### 6.4 Exclusions

Explicit exclusion patterns remain optional for known non-CR-04 occurrences such as Assist Parts. Exclusion matching may inspect ModelTitle only to exclude an occurrence; it must never assign a Design-Order category.

---

## 7. Comparison pipeline and compatibility with existing Domain evaluation

Current core comparison:

`src/CimatronCustomization.Domain/SteelGradeDesignOrderEvaluation.cs`

Current evidence model:

`src/CimatronCustomization.Domain/CadComponentSteelGradeEvidence.cs`

The Domain evaluation is key-agnostic: it groups all CAD evidence by normalized `ComponentKey` and matches it to one `DesignOrderSteelGradeEntry` with the same normalized key.

Therefore the existing Domain comparison **can accept category-keyed, many-CAD-components-to-one-DO-category input unchanged**, provided the new upstream orchestration performs all of the following first:

1. reads `TMPL::Part_Type` and `TMPL::Material` for each non-suppressed occurrence by `ModelPid`;
2. resolves normalized Part Type to zero or one stable category key;
3. emits Info/Warning/Error for exclusions, blank/unsupported Part Type, Part-property read failures, and blank required Part Material, removing invalid cases from successful comparison;
4. resolves D-16 X/Remark validity in the Form reader before calling Domain evaluation;
5. applies D-05 closed-vocabulary checks and removes unknown-value cases from successful comparison;
6. emits one valid nonblank `DesignOrderSteelGradeEntry` per category key using the trimmed Remark as expected grade;
7. passes all valid mapped CAD evidence for that category using `TMPL::Material` and the category key as `CadComponentSteelGradeEvidence.ComponentKey`.

The existing Domain grouping then supports multiple component evidence objects for one category. If mapped components in the same category carry more than one distinct valid Part Material grade, the current byte-protected Domain logic returns the legacy finding code `STEEL_GRADE_ATTRIBUTE_AMBIGUOUS`. The code name is retained for backward compatibility; the production evidence is Part Material.

### 7.1 Finding granularity consequence

Keeping the Domain comparison byte-identical means the grade match/mismatch result is category-grouped, with entity references collected from all mapped components in that category.

If the customer requires a separate independent match/mismatch finding for every individual occurrence while still using one DO category row, `SteelGradeDesignOrderEvaluation.cs` would need a separately approved semantic change. That is not assumed by this v1.5 proposal.

---

## 8. Protected byte-identical files for the implementation slice

The future v1.5 implementation plan shall enforce the following 0.30.1 files as byte-identical unless a separately approved corrective plan explicitly removes one from this list:

| File | 0.30.1 SHA-256 |
|---|---|
| `src/CimatronCustomization.Infrastructure/ExcelTabularDataReader.cs` | `9858864342f8a5f1424aeb990b0710a063659681566cfb4c0701cd0b957df0ce` |
| `src/CimatronCustomization.Application/ReadMappedTabularData.cs` | `12e04641d9d75d2a13a3a490662f7af41a709e469503eaade660282d07d8aad1` |
| `src/CimatronCustomization.Application/TabularMappingEngine.cs` | `2e0f41a7c6c6e9490063775466dad83e3cddfbc671bcb3713d5ba96b4650ca16` |
| `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs` | `6335016dbc2edc1aa27272a195e290cd43bcf2f25ec79ce197051900090032df` |
| `src/CimatronCustomization.Domain/SteelGradeDesignOrderEvaluation.cs` | `d3b900a68ed7013f259dbdab1ef1ff3ead2ee50042c5eb6c8d3ee3464bc6c349` |
| `src/CimatronCustomization.Domain/SteelGradeNormalizer.cs` | `e04ea719beb39ada1909c038a86b64d4864119ccbcd75f3d747cf486cd7c7ca9` |
| `src/CimatronCustomization.Application/SteelGradeOccurrenceHighlightSafety.cs` | `80726afd3459e2860818d7813df62e4e377cca5955ecaf613b195974c91e6963` |
| `src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityHighlighter.cs` | `aea16a6ee05e3bc873dc5785784bfebd5a564548a7c66c03fa7e457247eb9711` |

A new Architecture guard shall compute these source hashes at test runtime and fail if any protected file differs.

The Architecture guard itself is registered through:

`tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs -> RunAll()`

The existing Architecture `Program.cs` remains the runner entry point.

---

## 9. 0.39.0 implemented production integration

The user approved this production integration after runtime verification of `TMPL::Part_Type` and `TMPL::Material`. Version 0.39.0 implements the Form-mode native Part-property route while preserving Table mode and protected Domain/generic tabular files.

### 9.1 New production files in 0.39.0

- `src/CimatronCustomization.Application/IPartDocumentPropertyReader.cs` — read-only application port keyed by Part `ModelPid`;
- `src/CimatronCustomization.Application/PartDocumentPropertyResult.cs` — raw Part Type / Part Material result plus controlled read errors;
- `src/CimatronCustomization.Application/DesignOrderFormMaterialFamilyDefinition.cs` — Form X-column family metadata;
- `src/CimatronCustomization.Application/PartTypeCategoryResolver.cs` — trim/collapse/case-insensitive approved Part Type mapping;
- `src/CimatronCustomization.CimatronIntegration/CimatronPartDocumentPropertyReader.cs` — production PDM document-attribute adapter using `TMPL::Part_Type` and `TMPL::Material`.

### 9.2 Existing production files changed in 0.39.0

- `VerifySteelGradeAgainstDesignOrder.cs` — Form mode now reads native Part properties and no longer uses ModelTitle category mapping or BOM material correlation; Table mode remains unchanged.
- `VerifySteelGradeAgainstDesignOrderRequest.cs` — Form request carries profile and optional exclusions; production category-pattern dependency removed.
- `DesignOrderFormProfile.cs`, `DesignOrderFormCategoryDefinition.cs`, `DesignOrderFormCategoryRecord.cs` — Part Type mappings, material-family metadata, selected family, raw Remark and normalized comparison Remark.
- `ExcelDesignOrderFormReader.cs` — X/Remark validity checks and explicit trim/blank handling.
- `SrideviQrDg02Rev04Profile.cs` — approved nine Part Type mappings plus columns C:H families.
- `SteelGradeDesignOrderValidation.cs` — Form `ComponentCategorySource=PartType`; no Form pattern requirement.
- `FeatureComposition.cs` — composes `CimatronPartDocumentPropertyReader`.
- `config/CimatronCustomization.config.xml` — removes `ComponentCategoryPatterns` and selects `PartType`.
- old-style project files/tests/governance/checksums updated as required.

### 9.3 Protected files

The byte-identical list in §8 remains the formal protected set and must remain unchanged.

---

## 10. Tests and fixture

### 10.1 Anonymized Form fixture

A new test fixture is a planned deliverable.

Requirements:

- reproduces the production Form structure needed by CR-04;
- uses `Sheet1`, empty `Sheet2`/`Sheet3`, template guard cell, mould-number anchor, grade block, merged anchors, and validation-list structure needed by the Form reader;
- uses anonymized/non-client names, numbers, and grades where practical;
- contains no production workbook images, logos, personnel names, customer names, project names, or other client data;
- is generated/maintained as test data, not copied from `4075_P_DO.XLSX`.

### 10.2 Required tests

At minimum:

**Infrastructure/Form reader**
- correct profile/template guard;
- whitespace-normalized A39 guard;
- wrong guard;
- missing worksheet;
- required label missing;
- duplicate label;
- trailing-space `Core ` handling;
- `Pressuer Pad` profile label;
- blank grade preservation;
- grade/vocabulary extraction;
- `.xlsx` read;
- `.xls` read or an explicit supported-format contract test;
- workbook opened read-only / no write path;
- file sharing compatible with `FileShare.ReadWrite`.

**Application**
- Table mode still routes through the existing Table pipeline;
- Form mode reads native Part Type / Part Material by ModelPid;
- ModelTitle text does not determine Form category;
- Part Type trim/collapse/case normalization;
- blank Part Type -> controlled Warning;
- unsupported Part Type -> controlled Warning;
- optional explicit exclusion -> Info without native-property read;
- blank required Part Material -> Error;
- unknown CAD Part Material -> Warning;
- unknown DO Remark grade -> Warning;
- category-keyed many-to-one Domain input;
- no X + blank Remark -> no grade requirement/finding;
- strict full-value suffix comparison;
- mould-number Info emitted as not performed.

**Infrastructure/Form reader** additionally covers:
- exactly one trimmed/case-insensitive X + trimmed nonblank Remark -> valid requirement;
- no X + whitespace-only Remark -> no requirement;
- multiple X -> Error;
- X + blank Remark -> Error;
- Remark + no X -> Error;
- nonblank marker other than X -> Error;
- raw Remark preserved separately from trimmed comparison value.

**DesignChecks/config**
- Feature ID unchanged;
- `DesignOrderFormat` accepted values;
- runtime path remains run input, not persisted path;
- `SteelGradeSource=PartMaterial`;
- Form requires `ComponentCategorySource=PartType`;
- Form does not require `ComponentCategoryPatterns`;
- `CompareGradeTokenOnly=false`.

**Architecture**
- byte-identical protected-file hashes;
- new Form reader does not modify generic Table reader;
- no workbook or Cimatron model write/save/update API;
- Form native property adapter remains on verified `GetPdm()` / `RetriveDocAttribute(..., ref object, "")` route and exact `TMPL::Part_Type` / `TMPL::Material` names;
- Table-mode BOM route remains available;
- production config contains `SteelGradeSource=PartMaterial`, `ComponentCategorySource=PartType`, no `STEEL_GRADE`, and no `ComponentCategoryPatterns`;
- new test classes are registered in their test runners;
- client production workbook is absent from repository/package.

### 10.3 Test-runner registration

This repository uses explicit `RunAll()` registration, not automatic test discovery.

Every new test class must be manually registered in the applicable runner:

- `tests/CimatronCustomization.Infrastructure.Tests/Program.cs`
- `tests/CimatronCustomization.Application.Tests/Program.cs`
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs -> RunAll()`

If Domain tests are added despite the protected-Domain design, they must also be registered in:

- `tests/CimatronCustomization.Domain.Tests/Program.cs`

A test source file present in a project but not reachable from the relevant `Program.cs` / `RunAll()` chain is not accepted as executed coverage.

---

## 11. No-mutation requirements

CR-04 is read-only.

Final live-validation evidence shall demonstrate before/after equality for both the active Assembly and every controlled Part file used for validation.

Required evidence for **Assembly and Part**:

- `IsModified` unchanged and `false` where the API exposes the document;
- file `LastWriteTimeUtc` unchanged;
- file length unchanged.

For the Design Order workbook:

- open with `FileAccess.Read`;
- open with `FileShare.ReadWrite`;
- workbook timestamp and length must remain unchanged during final live validation;
- no save/write APIs.

### 11.1 0.30.1 evidence boundary

The accepted 0.30.1 production-reader smoke already proves:

- Assembly `IsModified=False` before/after;
- Assembly timestamp and length unchanged;
- disposable Part timestamp and length unchanged.

That smoke did **not** independently capture a Part-document `IsModified` value. v1.5 final end-to-end validation therefore must not claim that specific Part `IsModified` evidence from 0.30.1; it must capture it in the final validation if an approved read-only API route is available, or explicitly record the limitation and obtain user/manual no-mutation confirmation.

---

## 12. Runtime result rules

| Condition | Result |
|---|---|
| Template guard missing/mismatch | Error |
| Required Form label missing/duplicated | Error |
| Invalid nonblank material-selection marker | Error |
| More than one X on a category row | Error |
| X selected but Remark blank | Error |
| Remark nonblank but no X selected | Error |
| No X and blank Remark | No steel-grade requirement / no finding for that category |
| Exclusion-list component | Info |
| Blank Part Type | Warning; not validated |
| Unsupported Part Type | Warning; not validated |
| Native Part-property read failure | Error / fail-safe |
| Mapped component has blank Part Material where DO requirement exists | Error |
| Unknown DO Remark vocabulary | Warning; affected category not successfully validated |
| Unknown Cimatron Part Material vocabulary | Warning; affected component/category not successfully validated |
| Valid known grades match | Passed |
| Valid known grades differ | Failed |
| Multiple distinct valid Part Material grades within one mapped category | Failed — existing legacy code `STEEL_GRADE_ATTRIBUTE_AMBIGUOUS` |
| Mould-number comparison unavailable | Info — `MOULD_NUMBER_CHECK_NOT_PERFORMED` |
| Unsafe highlight identity | business status unchanged; omit unsafe reference per D-15(a) |

---

## 13. Production configuration direction

The approved v1.5 production configuration is:

- `DesignOrderFormat = Form`;
- `DesignOrderProfile = Sridevi_QR-DG-02_REV04`;
- `SteelGradeSource = PartMaterial`;
- no production `SteelGradeAttributeName`; `STEEL_GRADE` is historical/API diagnostic evidence only;
- `ComponentCategorySource = PartType`;
- no production `ComponentCategoryPatterns`;
- optional explicit exclusion list only;
- `SteelGradeRepresentation = Strict`;
- `CompareGradeTokenOnly = false` — suffix semantics remain provisional under D-06.

The existing Table configuration parameters remain supported for `DesignOrderFormat = Table`.

---

## 14. Open client inputs before production closure

The former ModelTitle naming-pattern questions are closed by the client-approved Part Type rule. Remaining client clarification is limited to business meaning of suffixes such as `Doosan`, `PCK`, `HH`, and `TSHH` under D-06, plus any future template revision that changes the approved X/Remark layout or closed vocabulary.

---

## 15. Stage A discrepancy record

The production workbook review found no discrepancy in the structural facts supplied for:

- sheet population;
- print area;
- A39 template marker;
- mould number;
- grade-block rows/labels/grades;
- X-mark column meanings;
- validation ranges;
- the two out-of-range source-list values.

Two boundaries are recorded:

1. the workbook itself proves that the form is branded Sridevi Tool Engineers Pvt. Ltd. and that `Customer Name` is `M&M-MATE`; the statement that the CR requirement set and the workbook came from the same client is a project-governance/source fact, not something the workbook alone can independently prove;
2. the uploaded attachment filename may differ from the canonical documentation name `4075_P_DO.XLSX`; v1.5 uses the canonical reference name and identifies the workbook by its verified form content/template guard rather than by the chat-upload filename.

---

## 16. Approval and implementation status

The user explicitly approved the exact 0.39.0 production implementation plan, including the later clarification that all CR-04 matching fields must be trimmed/blank-normalized and category labels must compare case-insensitively after whitespace normalization. Implementation is therefore authorized and is no longer at the proposal-only gate.

The approved implementation boundary is:

1. Form mode uses native `TMPL::Part_Type` for component category and native `TMPL::Material` for actual Part Material;
2. the Design Order selected-family `X` columns plus trimmed `Remark` define the material requirement;
3. no X + blank/whitespace-only Remark means no requirement and no steel-grade finding for that category;
4. invalid marker, multiple X values, X with blank Remark, or Remark without X fail closed as Design Order input errors;
5. Part Type/category labels trim leading/trailing whitespace, collapse internal whitespace, and compare case-insensitively;
6. Part Material and Remark trim leading/trailing whitespace before the existing approved steel-grade normalization/comparison policy;
7. raw native Part values and raw DO Remark remain available for evidence/reporting;
8. Form mode does not fall back to ModelTitle, Description/Details, BOM Type, BOM Standard Number correlation, or historical `STEEL_GRADE`;
9. Table mode and the protected files in §8 remain unchanged.

Any need to modify a protected file in §8 remains a hard stop requiring a revised plan and fresh approval.

---

## 17. Final validation sequence — pending user execution

After the 0.39.0 cumulative package is produced:

1. verify protected-file hashes and cumulative-package checksums;
2. user runs the Release x64 workstation quality gate;
3. require:
   - 0 warnings / 0 errors;
   - Architecture PASS;
   - Domain PASS;
   - Application PASS;
   - CimatronIntegration PASS;
   - Infrastructure PASS;
   - coverage gate PASS;
   - local quality gate PASS;
   - exit code 0;
4. only after that gate passes, open a controlled customer-like/disposable Cimatron Assembly;
5. runtime-select an external Form workbook;
6. validate at minimum: native Part Type mapping, exact Part Material/Remark match, mismatch, blank Part Type, unsupported Part Type, blank required Part Material, unknown vocabulary, no-X+blank-Remark no-requirement behavior, and explicit exclusion behavior;
7. validate DO input controls for invalid marker, multiple X, X+blank Remark, and Remark-without-X;
8. verify Result Report/highlight safety;
9. verify Assembly/Part/workbook no-mutation evidence;
10. record user manual no-mutation confirmation where required;
11. update governed documentation/timestamps only from observed evidence;
12. exclude raw runtime/console/client workbook from the cumulative ZIP.


### 0.38.3 controlled correlation diagnostic

After 0.38.2 workstation QG passed, the controlled live Result Report no longer returned `TABULAR_HEADERS_CHANGED` and reached native Part Material evaluation. `CoreInsert` matched, while Cavity/Core and several mapped categories exposed missing/not-found outcomes. Separate user-supplied Cimatron UI evidence shows `Cavity block` Part Material `P-20-2311`, so production logic is not changed before correlation evidence is captured.

The 0.38.3 diagnostic is developer-only, one-shot, 30-minute, and read-only. For `Cavity block`, `Core block`, `main insert`, `Insert#2`, `Main Core insert`, `core fix insert-01`, `Slider-01`, and `Lifter-01`, it records occurrence `ModelTitle`, BOM `Standard Number`, BOM `Material`, resolved category, and exact production correlation result. It also records the complete BOM Standard Number/Material snapshot. It reuses the approved production occurrence reader, BOM Part Material reader, and category resolver; it does not modify production comparison logic, category mapping, Design Order handling, vocabulary, model/workbook state, dependencies, or the verified Cimatron API route.
