## 2026-10-07 — 0.40.1 CR-04 v1.5 D-06 suffix-policy decision closure

- User explicitly resolved D-06: CR-04 does not separately maintain, interpret, strip, map, or validate material suffix details such as `Doosan`, `PCK`, `HH`, or `TSHH`.
- Production comparison remains the full normalized native Cimatron `TMPL::Material` value against the full normalized Design Order `Remark` value for the mapped row.
- `CompareGradeTokenOnly = false` remains unchanged; no suffix-specific configuration, vocabulary mapping, or additional client maintenance surface is introduced.
- Documentation/governance only; no production source, tests, configuration, Cimatron API path, workbook/model handling, or runtime behavior changes. Product/runtime version remains `0.40.1`.
- D-06 is no longer a blocker to the subsequent formal CR-04 v1.5 / Step 10 closure review.

## 2026-10-07 — 0.40.1 Result Report CSV validation closure

- Fresh user workstation `quality-gate-20261007-112824.txt` accepted the 0.40.1 warning corrective: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gate PASS, ExitCode 0.
- Controlled live `Cimatron-Result-Report-20261007-113508.csv` validated the approved 13-column CSV contract, occurrence-path traversal grouping, normalized status mapping, exact summary reconciliation (Total 131; PASS 3; FAIL 0; WARNING 110; NOT FOUND 4; SKIPPED 13; INFO 1), and `Overall Status = ACTION REQUIRED`.
- Cavity, Core, and Core Insert live matches remained `P-20-2311`; correlation ID `76ce74d49e7b47be9848b814b24a6eb8`.
- User manually confirmed the assembly remained unmodified after validation: YES.
- Documentation/governance closure only; no runtime, test, CSV, CR-04, Cimatron API, configuration, workbook, or model behavior change. Raw quality-gate capture and raw exported client CSV are excluded from the cumulative package.
- Status: **0.40.1 USER VALIDATED / CLOSED**.

## 0.40.1 — 2026-10-07 — Result Report CSV CA1859 warning corrective


## 2026-10-07 — 0.40.1 Session Handoff Refresh

- Documentation/governance-only handoff refresh; product/runtime version remains `0.40.1`.
- Added current 0.40.1 session handoff and new-session prompt carrying the authoritative CSV reporting contract, 0.40.0 quality-gate evidence, 0.40.1 warning corrective, and exact next acceptance action.
- No production source, test behavior, CSV behavior, Cimatron API path, configuration, threshold, workbook, model, or validation-rule change.
- 0.40.1 remains **AWAITING USER QUALITY GATE**.

- Records `quality-gate-20261007-111615.txt`: Release x64 build succeeded; Architecture, Domain, Application, Cimatron Integration, and Infrastructure suites PASS; governed coverage/local quality gate PASS; exit code 0; but one CA1859 warning remained in `SteelGradeDesignOrderEvaluation.cs(270,63)`.
- Changes only private `CollectContexts` return type from `IReadOnlyList<FindingComponentContext>` to `List<FindingComponentContext>`; returned data, ordering, deduplication, and CR-04 behavior are unchanged.
- Aligns the Architecture protected SHA-256 for the approved Domain source change.
- Domain assembly/file version advances to `0.40.1.0`. No CSV schema/order/status/summary change and no Cimatron/DO/validation behavior change.
- Full workstation quality gate must be rerun and must report 0 warnings / 0 errors before acceptance.

## 0.40.0 — 2026-10-07 — Result Report CSV component traceability and summary enhancement

- Keeps CSV as the sole Result Report export format; no XLSX/Open XML dependency or Office requirement is added.
- Adds optional structured finding context for Component Title, Occurrence Path, Instance ID, Part Type, Part Material, and occurrence order.
- CR-04 Form occurrence findings and steel-grade comparison findings preserve that reporting metadata without changing business-rule results.
- Export expands multi-occurrence findings to one row per component and orders component rows by the existing Cimatron traversal occurrence order, not alphabetically; global/non-component findings follow.
- CSV schema now begins with `ComponentTitle,OccurrencePath,InstanceId,PartType,MoldPartMaterial,ValidationStatus,FindingCode` and retains Feature/Requirement/Message/Measured/Limit/CorrelationId traceability columns.
- Normalizes export status to `PASS`, `FAIL`, `WARNING`, `NOT FOUND`, `SKIPPED`, and `INFO`; appends a summary including Overall Status (`PASS` or `ACTION REQUIRED`).
- Adds Application regression assertions for many-to-one PASS context propagation, missing-Part-Type context, and non-Part skipped context; aligns Architecture guards with the approved CSV schema/order/summary contract and approved protected-file hashes.
- Domain, Application, and Plugin assembly/file versions advance to `0.40.0.0`. No CR-04 validation rule, DO interpretation, Cimatron API read path, traversal/highlight identity, configuration, threshold, workbook/model, or mutation behavior changes.
- Full workstation quality gate is required before 0.40.0 acceptance.

## 0.39.9 — 2026-10-07 — CR-04 synthetic Root.elt Form eligibility corrective

- Records 0.39.8 workstation quality gate `quality-gate-20261007-003106.txt` as PASS: Release x64 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0.
- Records controlled live rerun `Cimatron-Result-Report-20261007-003425.csv`: six real `cmAssembly` occurrences are correctly `CAD_NON_PART_SKIPPED`, Cavity/Core/CoreInsert matching remains intact, but seven Part-property read errors remain.
- Read-only traversal evidence `api-capability-cr04-slice2a-20261007-004150.txt` proves all seven remaining errors are synthetic `cmPart` occurrences with exact `ModelPid = \\5\Root.elt`; full traversal/D-15 identity participation remains unchanged.
- Form orchestration now skips that exact synthetic Root PID before native Part-property reading and emits `[CAD_SYNTHETIC_ROOT_SKIPPED]` Info.
- Adds focused Application regression proving `cmPart + \\5\Root.elt` does not invoke the Part-property reader; existing non-Part skip and genuine real-Part read-error behavior remain unchanged.
- Application assembly/file version advances to `0.39.9.0`. No Cimatron traversal adapter, D-15, highlight, DO rule, Part Type/Material mapping, Table mode, threshold, config, workbook, or model mutation change.
- Workstation `quality-gate-20261007-004937.txt` subsequently accepted 0.39.9: Release x64 0 warnings / 0 errors, all governed suites PASS, governed coverage/local gate PASS, exit 0.
- Controlled live Form rerun `Cimatron-Result-Report-20261007-005224.csv` closed the corrective target: `CAD_PART_PROPERTY_READ_ERROR=0`, `CAD_SYNTHETIC_ROOT_SKIPPED=7`, `CAD_NON_PART_SKIPPED=6`, and Cavity/Core/CoreInsert `STEEL_GRADE_MATCH` preserved at `P-20-2311`; correlation ID `e53384f0f4ed4eb1aeac1967804a89cf`.
- User manually confirmed the assembly remained unmodified after the validation run. The raw client DO and Result Report CSV are not packaged. 0.39.9 is **USER VALIDATED / CLOSED**.

## 0.39.8 — 2026-10-07 — 0.39.7 architecture-guard alignment corrective

- Records user workstation `quality-gate-20261007-002443.txt`: Release x64 build PASS with 0 warnings / 0 errors, then Architecture Tests FAIL; gate exits before Domain/Application/coverage execution.
- Root cause: the CR-04 v1.5 protected-file hash map in `ArchitectureBoundaryTests.cs` still referenced the pre-0.39.7 SHA-256 for the explicitly approved `CimatronAssemblyBodyAttributeReader.cs` change.
- Aligns only that protected hash to verified SHA-256 `7fede8fcd63d4bbad4213110cc561c5b78f2b41d1cc57d64623398c283106368`.
- No production `src/**` file, CR-04 rule, traversal behavior, native Part Type/Part Material behavior, configuration, threshold, or other architecture guard changes.
- Full workstation quality gate remains required before 0.39.8 acceptance.

## 0.39.7 — 2026-10-07 — CR-04 Form non-Part eligibility corrective

- Entering quality evidence: user workstation `quality-gate-20261006-233537.txt` accepted 0.39.6 with Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, DesignChecks 100%, coverage/local gate PASS, exit 0.
- Entering live evidence: `Cimatron-Result-Report-20261007-000856.csv` proves Cavity, Core, and CoreInsert native Part Type/Part Material comparisons at `P-20-2311`, while seven higher-level/nested assembly occurrences produced `CAD_PART_PROPERTY_READ_ERROR` from the Part-specific PDM reader.
- `AssemblyBodyAttributeOccurrence` now carries occurrence `ModelType`; the production assembly reader populates it from the already-used Cimatron `IModel.Type`. Full highlighter-equivalent traversal remains unchanged.
- CR-04 Form orchestration now calls the native Part-property reader only for `cmPart` occurrences. Non-Parts emit `[CAD_NON_PART_SKIPPED]` Info and remain visible in traversal evidence; genuine Part reader failures remain Error findings.
- Added focused Application tests for non-Part skip/no-read and genuine Part read-error preservation, plus Cimatron Integration source-contract protection that model type is retained without traversal filtering.
- Application and CimatronIntegration assembly/file versions aligned to `0.39.7.0`. No threshold/config/DO rule/ModelTitle fallback/mutation change.
- Full workstation quality gate and controlled live rerun remain user-run acceptance steps.

## 0.39.6 — 2026-10-06 — 0.39.5 Application-test / CA1859 corrective

- Records user workstation `quality-gate-20261006-232537.txt`: Release x64 build PASS, Architecture PASS, Domain PASS, then Application Tests FAIL; quality gate exits 1 before coverage collection.
- Corrects `MissingNestedBodyReferenceSkipsMappingAndHighlight` aggregate expectation from `Passed` to `Skipped`, matching existing `FindingAggregation` severity where `Skipped` outranks `Passed`; the U7/U12 per-finding `Skipped` assertions remain unchanged.
- Clears the new CA1859 warning by changing private `ParseExclusionPatterns` return type from `IReadOnlyList<string>` to concrete `string[]`; body and parsing behavior remain unchanged.
- Static re-review of the other nine 0.39.5-added tests found no analogous aggregate-status expectation mismatch; they are unchanged.
- No `Test-CoverageGate.ps1`, CR-04 behavior, config, Program.cs, category-pattern surface, or other production source changes.
- Full workstation quality gate remains required before acceptance.

## 0.39.5 — 2026-10-06 — CR-04 v1.5 DesignChecks dead-code / coverage corrective

- Entering user evidence `quality-gate-20261006-221138.txt`: Release x64 PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration and Infrastructure suites PASS; coverage collection PASS; DesignChecks 93.45% below the governed 95% minimum.
- Mandatory pre-check found zero callers of private `TryParseCategoryPatterns`; the only test-side textual occurrence is an Architecture forbidden-token guard that ensures Form wiring does not call it.
- Removes the orphaned private `TryParseCategoryPatterns` method left behind by the 0.39.0 `TMPL::Part_Type` Form migration. `ComponentCategoryPatterns` parameter definition/validation/configuration surface remains byte-identical in behavior and is not retired in this version.
- Simplifies Form exclusion parsing by removing an impossible blank-entry rejection after `SplitList` has already applied `RemoveEmptyEntries`, trim, and `Length > 0`; separator-only entries continue to be ignored.
- Adds approved business/result tests in `SteelGradeDesignOrderValidationFeatureTests`, `Step08BInProcessConfirmationTests`, and `TopLevelHighlightDiagnosticFeatureTests`; every new method is registered in its existing `RunAll()` and `Program.cs` is unchanged.
- No coverage threshold, CR-04 native Part Type/Part Material rule, DO X/Remark rule, Table behavior, config, diagnostic, model/workbook, or other production source is changed.
- `ComponentCategoryPatterns` parameter retirement remains an open follow-up decision.
- Full workstation quality gate is required; agent-side workstation build/Cimatron validation is not claimed.

## 0.39.4 — 2026-10-06 — CR-04 v1.5 DesignChecks coverage corrective

- Entering user workstation evidence `quality-gate-20261006-215037.txt`: Release x64 PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure suites PASS; coverage collection completed but the gate failed because `CimatronCustomization.DesignChecks` measured 92.14% against the required 95% minimum.
- Added test-only coverage in `SteelGradeDesignOrderValidationFeatureTests.cs` for null execution context, null application findings, missing required Table worksheet/header/component/grade/key-source parameters, and missing Form profile/category-source parameters.
- No production source, runtime rule, native Part Type/Part Material behavior, DO X/Remark semantics, normalization, Table/Form orchestration, Cimatron API adapter, configuration, dependency, model, or workbook behavior changed.
- Agent performed static/source/diff/hash/package preparation only and did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Full workstation quality gate must be rerun.

## 0.39.3 — 2026-10-06 — CR-04 native Part Type orchestration architecture contract corrective

- Records user workstation `quality-gate-20261006-214154.txt`: Release x64 build PASS with 0 warnings / 0 errors, then Architecture Tests FAIL; overall gate exit code 1.
- Records direct ArchitectureTests reproduction: `CR-04 v1.5 native Part Type/Part Material Form orchestration lost a required contract.`
- Aligns only the Architecture source guard with the actual production code literals `CAD_PART_TYPE_MISSING` and `CAD_PART_TYPE_UNSUPPORTED`; the bracketed display form is produced dynamically by `$"[{code}] ..."` at runtime.
- No production Form orchestration, Part Type mapping, Part Material reading, DO X/Remark rule, trim/normalization, Form reader, Cimatron adapter, Table mode, configuration, model/workbook, or mutation behavior change.
- Agent performs source/diff/hash/package checks only; fresh user workstation quality-gate evidence is required.

## 0.39.2 — 2026-10-06 — CR-04 Form-reader architecture contract corrective

- Records user workstation `quality-gate-20261006-212934.txt`: Release x64 build PASS with 0 errors, one CA1859 warning in `PartTypeCategoryResolverTests.cs`, then Architecture Tests FAIL with `CR-04 v1.5 Form reader lost a required read-only or fail-closed source contract.`
- Records direct ArchitectureTests reproduction of the same source-contract failure.
- Aligns the Architecture Form-reader source guard with the actual approved local identifiers `selectedFamily` and `rawRemark`; the reader already carries those values into `DesignOrderFormCategoryRecord.SelectedMaterialFamily` / `RawRemark`.
- Changes the resolver test helper return type from `IReadOnlyList<DesignOrderFormCategoryDefinition>` to the concrete `DesignOrderFormCategoryDefinition[]` to clear CA1859 without changing test behavior.
- No production Form-reader, native Part Type/Material source, DO X/Remark rule, normalization policy, Table mode, Cimatron API adapter, configuration, model/workbook, or mutation behavior change.
- Agent performs source/diff/hash/package checks only; fresh user workstation quality-gate evidence is required.

## 0.39.1 — 2026-10-06 — CR-04 Part Type resolver compile corrective

- Records user workstation `quality-gate-20261006-211923.txt` as **FAIL**: Release x64 compilation stopped in `PartTypeCategoryResolver.cs(27,21)` with `CS1628`; overall exit code was 1.
- Applies the smallest approved corrective: normalize `rawPartType` into a local `normalized` variable, copy it to the `normalizedPartType` out parameter, and use only the local variable inside the LINQ predicate.
- Existing resolver tests already govern whitespace trimming/collapse, case-insensitive mapping, blank input, unknown input, and Pressure Pad mapping; no test behavior change was necessary.
- No change to `TMPL::Part_Type`, `TMPL::Material`, DO X/Remark rules, normalization policy, Table mode, Cimatron API adapter, model/workbook behavior, or read-only guarantees.
- Agent performed source/diff/hash/package checks only and did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Fresh user workstation quality-gate evidence is required.

## 0.39.0 — 2026-10-06 — CR-04 native Part Type / Part Material production integration

- Promotes runtime-verified `TMPL::Part_Type` to the Form-mode component category source and `TMPL::Material` to the Form-mode actual material source through read-only `GetPdm()` / `RetriveDocAttribute(..., ref object, "")`.
- Removes Form-mode production dependency on ModelTitle category patterns and BOM Standard Number material correlation; Table mode BOM behavior remains unchanged.
- Updates the Sridevi Form profile with explicit Cimatron Part Type mappings and six material-family X columns: P-20, AL, CK-45, BE-CU, Hardened, Nitrided.
- Interprets exactly one X plus nonblank Remark as the material requirement; no X plus blank Remark means no requirement; invalid/multiple selections fail closed.
- Adds explicit trim/collapse/case rules for Part Type and Design-Order category labels, plus trim/blank handling for Part Material, X markers, and Remark while preserving raw property/Remark values in typed results.
- Adds native Part-property Application/CimatronIntegration contracts/adapters, Part Type resolver, material-family profile model, tests, architecture guards, specification/API documentation, governance, checksums and cumulative handoff.
- Legacy `STEEL_GRADE` remains diagnostic/history only. No model/workbook mutation behavior is introduced.
- Agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron; full user workstation quality gate is required.

## 0.38.6 — 2026-10-06 — CR-04 Part property diagnostic Interop ref-binding corrective

- Records user workstation `quality-gate-20261006-193513.txt` as **FAIL**: Plugin compilation stopped at `Cr04PartPropertyDiscoveryDiagnostic.cs(125,74)` with `CS1620`, requiring argument 2 of `RetriveDocAttribute` to be passed with `ref`; overall exit code was 1.
- Applies the smallest approved corrective: initialize `object rawAttributes = null` and call `IPdm.RetriveDocAttribute(occurrence.ModelPid, ref rawAttributes, string.Empty)`.
- Updates the Architecture source guard to require the exact `ref` binding and initialized variable so the compile-time contract cannot silently regress to the failed `out` form.
- Advances the diagnostic evidence version and changed Plugin assembly/file version to `0.38.6` / `0.38.6.0`. The one-shot request schema stays at `0.38.5` because its file format/expiry/consume contract is unchanged.
- No production CR-04 logic/configuration/DO/domain/model/workbook behavior changes; the diagnostic remains read-only and Part Type / Part Material / Remark identities remain `NOT VERIFIED`.
- Agent performed source/hash/package checks only. Fresh user workstation quality-gate evidence is required before the live diagnostic may run.

## 0.38.5 — 2026-10-06 — CR-04 Part property document-attribute discovery diagnostic

- Records the clean user-supplied 0.38.4 quality gate (`quality-gate-20261006-180956.txt`): Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0.
- Records the 0.38.4 reflection result (`part-material-api-reflection-20261006-181315.txt`): Classification B, no typed native Part Material getter, and a usable installed PDM/document-attribute read route through `IApplication.GetPdm()` / `IPdm.RetriveDocAttribute(string, out object, string)`.
- Carries the client's revised CR-04 direction: component type is to come from Cimatron **Part Type**, not Details/Description; user UI evidence shows BOM `Type=Modeler`, so BOM `Type` is not promoted as the component-category source.
- Adds a one-shot 30-minute in-process read-only diagnostic for the eight approved CR-04 target Parts. It reuses existing occurrence `ModelPid` evidence and enumerates all returned `IDocAttribute.Name` / `Value` pairs through `RetriveDocAttribute`.
- The diagnostic explicitly keeps `PartTypeAttributeIdentity`, `PartMaterialAttributeIdentity`, and `RemarkAttributeIdentity` as `NOT VERIFIED` until user runtime evidence is reviewed; no attribute-name guessing is allowed.
- Adds before/after active-document `IsModified()` evidence and fails safely if the modification state changes.
- Adds an Architecture source guard that requires the approved read route/targets/evidence contract and forbids update/save/create/delete/mutation APIs in the diagnostic.
- Bumps the changed Plugin assembly to `0.38.5.0`; no other production assembly is changed.
- No production CR-04 category/source/comparison/configuration behavior changes in this diagnostic package. Raw quality-gate/reflection/live evidence, coverage output, client workbook, and Cimatron models remain excluded.

## 2026-10-06 — Version 0.38.4 — Part Material Installed-Interop Reflection Investigation

- **Change ID:** PH02-ST10-CR04-V15-PART-MATERIAL-API-REFLECTION-INVESTIGATION.
- **Change type:** DEVELOPER DIAGNOSTIC / ARCHITECTURE TEST / DOCUMENTATION / GOVERNANCE.
- **Entering evidence:** 0.38.3 workstation quality gate PASS and controlled read-only correlation diagnostic completed; exact BOM Standard Number correlation covered only 2 of 8 approved targets, so BOM correlation is not accepted as the general native Part Material route.
- **Candidate route 1:** reflection-only inventory of typed material-related getters/methods on `IApplication`, `ICimDocument`, `IPartDocument`, `IAssemblyDocument`, `IModel`, `IMdlrModel`, `IAssInstance`, `IAssemblyModel` and inherited interfaces.
- **Candidate route 2:** reflection-only inventory of `IPdm`, `IDocAttribute`, `DocAttribute`, and exact installed signatures for `RetriveDocAttribute`, `RetriveLinkAttribute`, `GetRelatedDocuments`, `GetDocumentByPath`, and `TitleOfPid`.
- **Global inventory:** records every public installed-Interop member whose name contains `material` case-insensitively.
- **Safety:** uses `Assembly.ReflectionOnlyLoadFrom` only; does not call `GetApplication`, `GetActiveDoc`, `GetPdm`, reflected members, COM activation, or any Cimatron mutation API.
- **Important limitation:** document attributes are a candidate transport mechanism only. Native Part Material is not asserted to be a document attribute; `Native Part Material attribute identity: NOT VERIFIED` remains explicit until separate live evidence.
- **Historical U17:** existing `NOT AVAILABLE FROM RETAINED 07A EVIDENCE` records remain intact. 0.38.4 adds a new reinvestigation status only.
- **Production boundary:** no production `src/` change, production config/category/DO/Domain change, model/workbook change, dependency change, or production Cimatron API-route change.
- **Validation:** user must run the full workstation quality gate, then `Invoke-ApiCapabilityVerification.ps1 -Mode part-material-reflect`, and return the generated evidence. No Classification A/B is accepted before that evidence is supplied.

## 2026-10-06 — Version 0.38.3 — Part Material Correlation Diagnostic Closure

- **Change ID:** PH02-ST10-CR04-V15-PART-MATERIAL-CORRELATION-DIAGNOSTIC-CLOSURE.
- **Change type:** VALIDATION CLOSURE / DOCUMENTATION / GOVERNANCE.
- **Workstation validation:** user-supplied `quality-gate-20261006-164624.txt` passed Release x64 with 0 warnings / 0 errors; Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS; coverage collection/gate PASS; local quality gate PASS; exit 0.
- **Live diagnostic:** user-supplied `cr04-part-material-correlation-diagnostic-20261006-165650.txt` completed read-only in-process with 8 targets and 6 BOM rows. Exact `ModelTitle` ↔ BOM `Standard Number` matching succeeded only for `Lifter-01 -> P20` and `core fix insert-01 -> P-20-2311`; the other six approved targets returned `NO_EXACT_BOM_STANDARD_NUMBER_MATCH`.
- **Conclusion:** current BOM correlation is insufficient as the general production route for native Part Material. This does not prove missing Part Material on unmatched Parts; user UI evidence already shows `Cavity block` Part Material = `P-20-2311`.
- **Production rule preserved:** native Cimatron Part Material remains authoritative; validation is read-only; no fallback to custom `STEEL_GRADE`.
- **Next step:** plan-only investigation of a direct Part-level native Part Material API read. No production source/config/runtime/API change is authorized by this closure.
- **Packaging:** raw QG/runtime evidence and client data remain external; cumulative package updates only governance/handoff/checksums.

## 0.38.2 — 2026-10-06 — CR-04 Part Material single-snapshot BOM read corrective

- Records workstation validation of 0.38.1: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0 (`quality-gate-20261006-161418.txt`; raw evidence excluded from package).
- Records the subsequent 0.38.1 live CR-04 result: `CAD_PART_MATERIAL_READ_ERROR / TABULAR_HEADERS_CHANGED` still occurred before any material comparison.
- Withdraws the 0.38.1 hard-coded full-header assumption. The production Part Material adapter now exports the BOM once and parses that same CSV through one `ITabularDataReader.Read(source)` call.
- Required columns remain name-resolved from that single snapshot: `Standard Number` -> `ModelTitle`; `Material` -> native Part Material.
- Removes the CR-04 adapter's second `ExpectedBomHeaders` contract, so harmless BOM column additions/order changes cannot be misreported as a discovery/read stability failure. Missing required `Standard Number` or `Material` still fails closed through the existing tabular column validation.
- Strengthens Architecture/CimatronIntegration source-contract tests to require the one-read snapshot path and forbid reintroduction of `ExpectedBomHeaders`.
- Bumps aligned production assemblies / feature version to `0.38.2.0` / `0.38.2`.
- No production source/category/DO/model/workbook/dependency/Cimatron-API change; no `STEEL_GRADE` fallback. Agent performed static/package checks only; workstation quality gate and controlled live rerun remain user-run.

## 0.38.1 — 2026-10-06 — CR-04 Part Material BOM-header corrective

- Records workstation validation of 0.38.0: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0 (`quality-gate-20261006-160141.txt`; raw evidence excluded from package).
- Records first 0.38.0 live result: `CAD_PART_MATERIAL_READ_ERROR` / `TABULAR_HEADERS_CHANGED` before any steel-grade comparison.
- Root cause: `CimatronBomMaterialTableReader` supplied a two-item expected-header list even though `ExcelTabularDataReader.Read(..., expectedHeaders)` compares the complete CSV header row exactly.
- Corrects the production Part Material adapter to validate the already verified seven-column BOM header contract: `No.`, `Qty.`, `Standard Number`, `Sub Category`, `Category`, `Visible Part Size`, `Material`.
- CR-04 still maps only `Standard Number` to `ModelTitle` and `Material` to native Part Material evidence; no category, DO, model, API-route, or fallback behavior changes.
- Strengthens architecture and CimatronIntegration source-contract tests for the complete BOM header contract.
- Bumps aligned production assemblies / feature version to `0.38.1.0` / `0.38.1`.
- Agent performed static checks only; workstation quality gate and controlled live rerun remain user-run.

## 0.38.0 — 2026-10-06 — CR-04 native Part Material production source

- Replaces the production CR-04 steel-grade source `BodyAttribute/STEEL_GRADE` with Cimatron native **Part Material**, per client discussion and user-approved Cimatron evidence.
- Adds a read-only `IBomMaterialTableReader` Application port/result model and `CimatronBomMaterialTableReader` adapter using the already verified `GetBomManager()` / `IBOM.Export(..., cmNoFiltering, ...)` BOM route.
- Correlates BOM `Standard Number` to occurrence `ModelTitle` and supplies BOM `Material` values to the existing byte-protected Domain comparison as BOM material evidence.
- Keeps assembly traversal for category, suppression and highlight identity; the legacy body steel-grade read is no longer used as production evidence.
- Removes `SteelGradeAttributeName=STEEL_GRADE` from production config and requires `SteelGradeSource=PartMaterial`; no fallback to the custom attribute is permitted.
- Adds/updates Application, CimatronIntegration contract and Architecture tests for Part Material, blank material, read failure, no body-attribute dependency, read-only behavior and explicit old-style project compile entries.
- Updates the v1.5 implementation specification D-01/D-02 and acceptance/result/configuration rules.
- Bumps changed production assemblies to `0.38.0.0`.
- No client Design Order workbook or raw quality-gate evidence is packaged. The agent did not execute workstation build/tests/Cimatron; fresh user quality-gate evidence is required.

## 0.37.0 — 2026-10-06 — CR-04 target-component diagnostic architecture corrective

- Recorded user-supplied `quality-gate-20261006-151118.txt`: Release x64 build succeeded with 0 errors but one CA1859 warning; Architecture tests then failed and the gate exited `1`.
- Root cause: the previous compile corrective added a direct `CimatronCustomization.Plugin` → `CimatronCustomization.Domain` project reference, which violates the established thin-Plugin/inward-dependency architecture guard.
- Removed that direct Domain reference; no architecture exception is introduced.
- The diagnostic no longer dereferences the Domain-backed `BodyReference` property. `BodyEntityId` remains in the evidence schema but is explicitly written as `UNAVAILABLE_AT_PLUGIN_BOUNDARY`.
- Changed `SplitList` to return `string[]`, removing CA1859 without changing parsing behavior.
- Production CR-04 reader/category resolver/config/model/workbook/API behavior remains unchanged; fresh workstation QG is required before live diagnostic execution.

## 0.37.0 — 2026-10-06 — CR-04 target-component diagnostic compile corrective

- Recorded user-supplied `quality-gate-20261006-150312.txt`: Release x64 build failed with CS0012 because the new Plugin diagnostic consumed `ModelEntityReference` without a direct Plugin-to-Domain project reference; the build also emitted CA1861 for an inline separator array; gate exit code `1`.
- Added only the existing `CimatronCustomization.Domain` project reference to `CimatronCustomization.Plugin.csproj`.
- Replaced the diagnostic's inline `new[] { ';' }` separator allocation with one `static readonly char[]` to remove CA1861.
- No production CR-04 behavior, configuration, model/workbook mutation, save path, Cimatron API route, category mapping, or diagnostic evidence contract changed.
- Eight CR-04 v1.5 protected files remain byte-identical. Fresh workstation quality-gate evidence is required before the read-only diagnostic may run.

## 0.37.0 — 2026-10-06 — CR-04 target-component read-only diagnostic

- Added a one-shot 30-minute developer diagnostic request and in-process Plugin diagnostic for the controlled CR-04 live test-copy Assembly.
- Reuses the existing production `CimatronAssemblyBodyAttributeReader`; no new Cimatron API path is introduced.
- Reuses `SteelGradeCategoryResolver` against the deployed CR-04 category configuration and approved Sridevi Form category vocabulary.
- Evidence records `OccurrencePath`, `InstanceId`, `ModelTitle`, `ModelPID`, body entity id, `STEEL_GRADE` status/value, and category resolution for every occurrence/body observed by the production reader.
- The diagnostic is read-only: no attribute creation/attach, model save/save-as, selection mutation, entity creation/deletion, workbook mutation, or production business-rule change.
- Added architecture guards for explicit one-shot wiring, request expiry/versioning, production-reader/category-resolution reuse, and forbidden mutation tokens.
- Eight CR-04 v1.5 protected files remain byte-identical.
- Agent performed static/package checks only; workstation quality gate and live Cimatron diagnostic remain user-run.

## 0.36.0 — 2026-10-06 — Result Report CSV export workstation validation

- User supplied `quality-gate-20261006-141026.txt`; Release x64 PASS with 0 warnings / 0 errors.
- Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS; coverage collection/gate PASS; local quality gate PASS; exit code 0.
- Gate completed `2026-10-06T14:11:21.8465591+05:30`.
- The CSV export corrective is therefore accepted as the validated baseline for the 0.37.0 diagnostic work. Raw gate evidence remains outside the cumulative ZIP.

## 0.36.0 — 2026-10-06 — Result Report CSV export

- Corrective after user-supplied `quality-gate-20261006-140052.txt`: Release x64 build passed with 0 warnings / 0 errors, but Architecture tests failed and the gate exited 1 before later suites/coverage.
- Root cause was an existing architecture guard that searched concatenated project text for any `PackageReference` plus any `Csv` token; the new source filename `ResultReportCsvExporter.cs` therefore produced a false-positive CSV-dependency failure.
- Narrowed that guard to inspect only actual `<PackageReference Include="...">` names for `Csv`; production CSV export behavior, Design Order input, dependencies, protected files, and Cimatron behavior are unchanged.
- A fresh workstation quality gate is required; no PASS is claimed for 0.36.0 yet.
- Added `Export Results` to the Result Report window.
- Export writes the complete unfiltered report, regardless of the active status filter.
- CSV columns: Feature, Requirement, Status, Message, Measured, Limit, CorrelationId.
- Appends Total/Passed/Succeeded/Failed/Warning/Error/NotApplicable/Skipped/Unsupported summary rows.
- Uses UTF-8 with BOM and quote escaping for commas, quotes and line breaks; no external CSV/Excel dependency was added.
- Preserves existing highlight selection restoration on report close.
- CSV is output/reporting only; Design Order input remains `.xlsx`/`.xls` and CSV input remains unsupported.
- No CR-04 business logic, category mapping, DO reader, Cimatron model access, config, client workbook or protected-file change.
- Agent did not execute workstation build/tests/coverage/analyzers/SonarQube/Cimatron; user quality gate is required.

## 0.35.0 — 2026-10-06 — CR-04 v1.5 Slice 5 closure

- Closed Slice 5 after user-supplied workstation gate `quality-gate-20261006-124558.txt`.
- Gate capture `2026-10-06T12:45:58.0537119+05:30`; completed `2026-10-06T12:46:59.7108075+05:30`.
- Release x64 PASS; 0 warnings / 0 errors; Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS; coverage/local quality gate PASS; exit 0.
- User explicitly approved closure. Raw quality-gate evidence remains outside the cumulative ZIP.
- No source/config/test/runtime behavior changed during closure; all eight v1.5 protected files remain byte-identical.
- Original client DO and baseline Cimatron models remain protected; next live validation must use test copies only.

## 0.35.0 — 2026-10-06 — CR-04 v1.5 Slice 5 approved client test mapping

- Adds the explicitly approved client-DO/reference-model `ComponentCategoryPatterns` used only for controlled CR-04 validation: `Cavity block`, `Core block`, `main insert`, `Insert*`, `Main Core insert`, `core fix insert-01`, `Slider-01`, and `Lifter-01` mapped to the approved six Form categories.
- Records expected DO grades of `P-20-2311` for Cavity/Core/Cavity Insert/Core Insert/Moving Core/Angular Lifter and the approved Mould Base expectation `CK-45`. No machine-readable `MouldBase=` pattern is invented; Pressure Pad/Wear Pad mappings remain absent.
- Resolves D-02 as body/entity `STEEL_GRADE` / `cmAttString`, with no BOM fallback and no alternate-type probing.
- Adds focused feature/architecture protection for the exact approved test mapping and for continued absence of invented unresolved category mappings.
- Establishes the validation safety constraint that the original client DO and baseline Cimatron models must not be modified; controlled validation uses test copies only.
- No new Cimatron API, dependency, project-reference, CSV, protected-file, or runtime-picker change. Agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron; workstation quality gate is required.

## 0.34.0 — 2026-10-06 — CR-04 v1.5 Slice 4 category-mapping contract hardening

- **Closure:** user-supplied `quality-gate-20261006-093924.txt` is accepted: Release x64 PASS, **0 warnings / 0 errors**, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage collection/gate PASS, local quality gate PASS, exit code `0`. Capture `2026-10-06T09:39:24.5934880+05:30`; completed `2026-10-06T09:40:20.8062496+05:30`.
- User explicitly approved Slice 4 closure. Raw quality-gate evidence remains outside the cumulative ZIP. Slice 4 is **CLOSED / USER VALIDATED**; unresolved real deployment ModelTitle strings/patterns remain production inputs and are not invented.
- Hardens `SteelGradeDesignOrderValidation` so every Form `ComponentCategoryPatterns` category key must exactly match a category key in the composed approved Form profile. Unknown keys fail closed as `CR04_CONFIGURATION_ERROR` before the Application use case runs.
- Treats configured ModelTitle values as opaque strings/patterns. Exact strings are valid; existing deliberate `*`/`?` wildcard capability remains unchanged. No client naming convention, prefix, suffix, or placeholder ModelTitle is inferred.
- Fixes the approved Sridevi category vocabulary at the existing nine profile keys: `Cavity`, `Core`, `CavityInsert`, `CoreInsert`, `MovingCore`, `AngularLifter`, `PressurePad`, `WearPad`, `MouldBase`. Display labels remain those already defined by the approved profile.
- Extends registered feature tests for all nine approved category keys, arbitrary opaque ModelTitle strings, and fail-closed unknown category keys.
- Adds an Architecture guard for the nine profile category contracts, profile-driven category-key validation, unchanged `.xlsx/.xls` picker/no CSV, and continued absence of production `ComponentCategoryPatterns`.
- Production config is intentionally unchanged: no real ModelTitle strings were supplied, so no mapping is invented. Eight v1.5 protected files remain byte-identical; no dependency/project/Cimatron-API change.
- Agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Full user workstation quality gate is required before closure.

## 0.33.0 — 2026-10-06 — CR-04 v1.5 Slice 3 closure

- Closes the Slice 3 feature/config/composition wiring scope on user-supplied workstation evidence `quality-gate-20261006-011609.txt`.
- Accepted gate capture timestamp: `2026-10-06T01:16:09.5079086+05:30`; completed `2026-10-06T01:17:07.9087928+05:30`.
- Release x64 build PASS with **0 warnings / 0 errors**; Architecture/Domain/Application/CimatronIntegration/Infrastructure suites PASS; coverage collection/gate PASS; local quality gate PASS; exit code `0`.
- Accepted coverage: Domain 99.74%, Application 92.95%, DesignChecks 95.42%, Infrastructure 82.27%; CimatronIntegration 2.08% measured with no threshold introduced.
- User explicitly approved closure after evidence review. Exact chat approval seconds are not independently captured and are not invented.
- Slice 3 wiring is **CLOSED / USER VALIDATED**. Live Form business validation remains blocked by unresolved real production `ComponentCategoryPatterns`; no placeholder mapping is introduced.
- Closure is documentation/governance/checksum/package only. No source, test logic, config, dependency, model, Cimatron API, protected-file, runtime-picker, or production behavior change is made.
- Raw quality-gate evidence and the production client workbook remain excluded from the cumulative ZIP.

## 0.33.0 — 2026-10-06 — CR-04 v1.5 Slice 3 feature/config/composition wiring

- Implements the explicitly approved Slice 3 scope on cumulative 0.32.1.
- `SteelGradeDesignOrderValidation` now accepts explicit `DesignOrderFormat=Table|Form`; keeps legacy Table request construction and adds Form/profile/category-mapping request construction without changing the Slice 2 application orchestration.
- Form mode validates the composed profile id, fixed `ComponentCategorySource=ModelTitleWithOptionalAttributeOverride`, optional category body-attribute override name, semicolon-separated `CategoryKey=ModelTitlePattern` mappings, optional exclusion patterns, BodyAttribute steel-grade source, and existing comparison policy.
- `FeatureComposition` now injects `ExcelDesignOrderFormReader` and `SrideviQrDg02Rev04Profile.Create()` alongside the existing Table reader into `VerifySteelGradeAgainstDesignOrder`; no new Cimatron API path is introduced.
- Production configuration switches from provisional Table layout values to known v1.5 values only: `DesignOrderFormat=Form`, `DesignOrderProfile=Sridevi_QR-DG-02_REV04`, `SteelGradeSource=BodyAttribute`, `SteelGradeAttributeName=STEEL_GRADE`, `ComponentCategorySource=ModelTitleWithOptionalAttributeOverride`, `SteelGradeRepresentation=Strict`, `CompareGradeTokenOnly=false`.
- Actual production `ComponentCategoryPatterns` are intentionally absent because client ModelTitle naming remains unresolved. Form execution therefore fails closed until approved real mappings are configured; no placeholders/default patterns are shipped.
- Focused feature tests cover preserved Table construction, Form construction, profile/category-source/pattern validation, optional category attribute/exclusions, and invalid formats. Architecture guards require Form composition, preserve `.xlsx/.xls` with no CSV, reject persisted Design Order paths/obsolete Table config, prohibit unresolved production category patterns, and retain protected-file hashes.
- Eight v1.5 protected files remain byte-identical to 0.32.1. No dependency upgrades, project-reference changes, production client workbook, raw quality evidence, or new Cimatron API use.
- Agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Status is **AWAITING USER WORKSTATION QUALITY GATE**.

## 0.31.1 — 2026-10-06 — CR-04 v1.5 Slice 1 Closure

- Closes the Slice 1 two-warning corrective on user-supplied workstation evidence `quality-gate-20261006-001103.txt`.
- Accepted gate: Release x64 PASS, **0 warnings / 0 errors**, Architecture/Domain/Application/CimatronIntegration/Infrastructure suites PASS, coverage collection/gate PASS, local quality gate PASS, exit code 0.
- Accepted coverage: Domain 99.74%, Application 95.25%, DesignChecks 98.32%, Infrastructure 82.27%, CimatronIntegration 2.08% measured/no threshold.
- Slice 1 Form reader/profile/anonymized fixture/test registration is therefore CLOSED / USER VALIDATED.
- This closure changes documentation/governance/checksums/package only; no production source, test logic, config, dependency, model, Form behavior, Table path, Domain comparison, Cimatron adapter or highlighter behavior is changed.
- Raw workstation evidence and the production client workbook remain excluded from the cumulative ZIP.

## 0.30.1 — 2026-10-05 — CR-04 v1.5 Stage A Production-DO Specification (documentation only)

- Adds `docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`, superseding v1.4 as the approved proposal/specification direction while keeping feature ID `STEEL-GRADE-DESIGN-ORDER-VALIDATION`.
- Stage A verified the externally supplied Sridevi production Design Order form facts: `Sheet1`, empty `Sheet2`/`Sheet3`, print area `A1:R39`, normalized `A39` guard `QR/DG/02 REV 04 03/12/2021`, mould number `ST4075 P`, rows 18–26 grade block, X-mark columns, and validation-list ranges.
- Records the client-template defect that `CC27 = 1.2343/H-11` and `CB28 = EN-353` lie outside the validation ranges applied to the production grade cells.
- Reconciles v1.5 against platform 0.30.1 and records Slice 3, 4A and 4B as closed for their accepted scopes.
- Resolves/specifies D-01, D-03, D-04, D-05, D-09, D-11, D-16 and D-17 for the v1.5 design; preserves D-02 current direction pending client attribute-name confirmation and D-06 as provisional pending suffix-use confirmation; preserves D-15(a) and keeps D-15(b) deferred.
- Specifies a new Form reader/client profile while requiring the generic Table reader path to remain supported and a formal list of existing source files to remain byte-identical during the future implementation slice.
- Confirms the existing Domain comparison can consume category-keyed, many-CAD-components-to-one-DO-category input unchanged, subject to new upstream mapping/blank/vocabulary handling.
- Defines planned anonymized Form fixture, explicit test-runner registration, no-mutation requirements, workbook `FileShare.ReadWrite`, mould-number Info behavior, and the future implementation approval gate.
- The production workbook remains external client data and is not included in the repository or cumulative ZIP.
- Documentation-only step: no `src/**`, tests, tools, projects, config, Cimatron models, runtime behavior, or production assembly metadata changed; no build/test/Cimatron PASS is claimed for this documentation-only update.

## 0.30.1 — 2026-10-05 — CR-04 Production-Reader Positive STEEL_GRADE Smoke

- Adds a developer-only one-shot in-process smoke that exercises the unchanged production `CimatronAssemblyBodyAttributeReader` through exact `ReadNamedAttributes("STEEL_GRADE", null)` against disposable `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`.
- Requires the controlled `KA-PART-1-CR04-WRONG-TYPE` body/entity `4` observation to be `Present` with exact value `P-20-2311`; records every returned body observation and hard-stops on any reader `ReadError`.
- Adds Assembly no-mutation evidence (`IsModified`, saved path timestamp/length) and explicit saved Part-file timestamp/length before/after.
- Adds a distinct versioned 30-minute one-shot request and PowerShell requester. The requester requires the absolute saved disposable Part path and does not launch Cimatron.
- Adds one Architecture source-contract guard via existing `RunAll()`, increasing registered guard methods from 17 to 18 without changing `Program.cs` aggregate output.
- Keeps the existing wrong-type smoke unchanged; positive-smoke exact source guards prohibit `.Save(`, `.Attach(`, `SetAttribute(`, `GetAttributes(`, `GetEntityById(` and `cmAttInteger`.
- D-02 remains VERIFIED for the current implementation direction; this smoke is additional production-reader-path evidence only. Pending CR-04 v1.5 client-specific naming/template work is unchanged.
- No Domain comparison, Design Order processing, highlighter, baseline-model, production-config or production-reader implementation change.
- Validation closure: user workstation `quality-gate-20261005-225434.txt` passed Release x64 with **0 warnings / 0 errors**, all governed suites PASS, coverage/local quality gates PASS, exit code 0. Controlled live evidence `cr04-steel-grade-production-reader-smoke-20261005-230201.txt` observed 14 total body observations, exactly one target occurrence/body-4 positive `STEEL_GRADE=P-20-2311`, `ReadErrorCount=0`, `AssemblyNoMutation=PASS`, `PartFileNoMutation=PASS`, and `PRODUCTION_READER_STEEL_GRADE_OBSERVED`. User approved closure. Raw evidence files are excluded from the cumulative ZIP.

# Changelog

## 0.30.0 — 2026-10-05 — CR-04 D-02 Controlled Steel-Grade Attribute Setup Helper

- Records user workstation `quality-gate-20261005-184300.txt` for 0.29.1: Release x64 PASS, **0 warnings / 0 errors**, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local quality gate PASS, exit code 0.
- Adds a tightly restricted `--steel-grade-control` mode to the existing development-only `CimatronCustomization.KnownAnswerModelSetup` helper.
- The mode is hard-bound to disposable Part `KA-PART-1-CR04-WRONG-TYPE`, body/entity `4`, `cmAttString`, attribute name `STEEL_GRADE`, and value `P-20-2311`.
- Mutation still requires explicit `--apply`. Existing same-name/same-type/same-value state reports `ALREADY_PRESENT` without mutation; same-name conflicting type/value stops and overwrite remains prohibited.
- Uses the already-proven setter path `IApplication.GetAttributeFactory()` → `Create(cmAttString, name)` → set `Value` → `IAttributeSink.Attach(attribute)`, followed by immediate exact named `cmAttString` read-back.
- Autosave remains disabled. On successful mutation, the user must manually save only the disposable Part and stop before the separate production-reader validation.
- Adds an architecture guard for the exact disposable model/entity/name/value/string-type contract and for the no-autosave rule.
- Advances only the development helper assembly/file metadata to `0.30.0.0`; no `src/**`, solution/project/config, production CR-04 behavior, production adapter/highlighter, or Design Order processing changes.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE AND CONTROLLED CIMATRON HELPER EXECUTION**. Agent claims no build/test/runtime PASS for 0.30.0.

## 0.29.1 — 2026-10-05 — CR-04 Slice 4B CA1861 Test-Warning Corrective

- Records user workstation `quality-gate-20261005-183432.txt` for 0.29.0: Release x64 build completed; Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS; coverage/local quality gates PASS; exit code 0; but build summary contained **1 warning / 0 errors**.
- The sole warning is CA1861 in `tests/CimatronCustomization.Application.Tests/FeatureLauncherApplicationTests.cs`, caused by the repeated inline `new[] { "ONE" }` argument in the new per-run-input propagation test.
- Corrects only that test by introducing a class-level `static readonly string[] OneSelection` fixture and passing it to the checklist call. Test intent and runtime behavior are unchanged.
- No `src/**`, project/solution, configuration, production assembly metadata, CR-04 business logic, runtime Design Order browse/select flow, Cimatron adapter/highlighter, or model behavior changes.
- Product/package version advances to `0.29.1` for cumulative traceability; production Application/DesignChecks/Plugin assembly/file metadata remain `0.29.0.0`.
- Validation status: **AWAITING RE-RUN USER WORKSTATION QUALITY GATE WITH 0 WARNINGS / 0 ERRORS**. Live Cimatron validation remains blocked until that clean gate and the separately unresolved D-02/D-05/D-06 decisions are resolved.

## 0.29.0 — 2026-10-05 — CR-04 Slice 4B Runtime Design-Order Selection

- Records the user workstation `quality-gate-20261005-171737.txt` for 0.28.1: Release x64 PASS, **0 warnings / 0 errors**, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local quality gate PASS, exit code 0.
- Resolves D-09 production operation to **(c) launcher file dialog**: the user browses/selects the Design Order Excel workbook for each CR-04 run; the selected path is carried only as `FeatureRunInputs` and is not persisted in production configuration.
- `FeatureLauncherWindow` opens a single-file Excel picker (`.xlsx`/`.xls`) when CR-04 is selected. Cancel returns before creating an execution correlation or running the checklist, so no CR-04 validation occurs.
- `ExecuteFeatureChecklist` gains a backward-compatible overload that carries optional per-run inputs into the existing `FeatureExecutionContext`.
- `SteelGradeDesignOrderValidation` removes `DesignOrderPath` from rule parameters and requires the runtime `DesignOrderPath` input before calling the existing application use case.
- Wires the approved controlled-test D-03 workbook layout into production config: worksheet `Input Sheet`, header row `1`, component header `Component`, steel-grade header `Steel Grade`; also records the already-approved D-01 `BodyAttribute` source and workbook-backed D-04 `ModelTitle` component key.
- Does **not** invent unresolved D-02 steel-grade attribute name or D-05/D-06 comparison policy values; those remain absent from config and block a full business-validation live run until separately approved.
- Adds focused Application/DesignChecks tests and architecture guards for runtime input propagation, browse/cancel behavior, approved D-03 config, and prohibition of persisted `DesignOrderPath` / `DesignOrderPathPattern`.
- Advances Application, DesignChecks and Plugin assembly/file metadata to `0.29.0.0`.
- No Domain business-rule change, production Cimatron adapter/highlighter change, BOM route, D-09(b), D-15(b), Assist Part change, or model mutation is introduced.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**. Live CR-04 business validation remains blocked until the gate is clean and D-02/D-05/D-06 are resolved.

## 0.28.1 — 2026-10-05 — CR-04 Slice 4A Public-API Boundary Corrective

- Records user workstation `quality-gate-20261005-164722.txt`: quality-tool restore PASS, then Release x64 compilation FAILED with CS0012 in `Plugin/FeatureComposition.cs`; gate exit code 1.
- Root cause: the public `SteelGradeDesignOrderValidation` test-seam constructor exposed `Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>>`, and `Finding` is defined in Domain. Plugin constructor resolution therefore required the forbidden direct Plugin→Domain reference.
- Keeps the production `VerifySteelGradeAgainstDesignOrder` constructor public, makes only the Domain-backed delegate test seam internal, and grants `InternalsVisibleTo` solely to `CimatronCustomization.Application.Tests`.
- Strengthens the Slice-4 architecture guard so a public Domain-backed delegate constructor is forbidden and the internal test seam is required.
- Updates focused feature tests for both the public production constructor null guard and the internal delegate seam.
- Advances DesignChecks assembly/file metadata to `0.28.1.0`; Plugin source/project references and Plugin assembly metadata are unchanged.
- No CR-04 business logic, production adapter, traversal, highlighter, tabular behavior, config values, Domain/Application semantics, D-09(b), BOM route, D-15(b), Assist Part handling, or live-smoke behavior changes.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**. Live Cimatron validation remains blocked until a clean gate.

## 0.28.0 — 2026-10-05 — CR-04 Slice 4A Feature Wiring

- Adds `SteelGradeDesignOrderValidation`, a read-only Assembly-only CR-04 feature wrapper with explicit rule-parameter definitions and no customer defaults.
- Registers CR-04 through `FeatureComposition` using the existing `VerifySteelGradeAgainstDesignOrder` application use case, `ExcelTabularDataReader`, `CimatronAssemblyBodyAttributeReader`, and D-09(a) `DesignOrderInputPathResolver`.
- Preserves the architecture boundary: Plugin still does not directly reference Domain.
- Adds focused feature tests for metadata, approved Option-A request construction, invalid enum/cross-field handling, finding aggregation, and Part-context `NotApplicable`.
- Adds an architecture guard for Slice 4 wiring and for the deliberate absence of a CR-04 production config block before D-03/D-09 customer values are approved.
- Advances Plugin and DesignChecks assembly/file metadata to `0.28.0.0`.
- Leaves `config/CimatronCustomization.config.xml` unchanged: no placeholder D-03/D-09 values are allowed.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE AND LIVE CIMATRON VALIDATION**. Agent claims no build/test/runtime PASS for 0.28.0.

## 0.27.10 — 2026-10-05 — CR-04 Post-Closure New-Session Handoff

- Adds the authoritative post-closure session handoff and paste-ready new-session prompt after the user-validated CR-04 Slice 3 wrong-type in-process smoke.
- Carries forward the accepted 0.27.10 workstation quality gate: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gate PASS and exit code 0.
- Carries forward the accepted live smoke: `Present=0`, `Absent=0`, `ReadError=1`, `NoMutation=PASS`, `FAIL_SAFE_READ_ERROR_OBSERVED`, plus user manual confirmation that the assembly remained unmodified.
- Records the current architecture boundary: Plugin must not directly reference Domain; the developer-only smoke path is Plugin -> CimatronIntegration probe -> unchanged production adapter.
- Next session must determine the next unresolved CR-04 item from the governing requirement/history/version files, present a file-by-file plan, and wait for explicit user approval before implementation.
- Documentation/governance/checksum/package-only handoff. No `src/**`, tests, tools, project/solution, configuration, requirement text or runtime behavior changes.

## 0.27.10 — 2026-10-05 — CR-04 Slice 3 Wrong-Type In-Process Smoke Closure

- Records user workstation `quality-gate-20261005-152644.txt`: Release x64 build PASS, **0 warnings / 0 errors**, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS and exit code 0.
- Records the governed one-shot in-process Plugin smoke on disposable `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`: target occurrence count 1, body-4 observations 1, `Present=0`, `Absent=0`, `ReadError=1`, `NoMutation=PASS`, `Result=FAIL_SAFE_READ_ERROR_OBSERVED`.
- Programmatic before/after evidence showed the document remained unmodified and the model file timestamp/length stayed identical; the user separately confirmed `Assembly remains unmodified after the smoke: YES`.
- This runtime evidence satisfies the wrong-type fail-safe/no-mutation objective for the real production `CimatronAssemblyBodyAttributeReader` inside the Cimatron Plugin process.
- `PluginVersion=0.27.8` in the smoke evidence is expected: 0.27.9/0.27.10 changed CimatronIntegration only; Plugin binary metadata was intentionally unchanged. Product/package baseline remains `0.27.10`.
- Documentation/governance/checksum/package closure only. No `src/**`, tests, tools, configuration, CR-04 semantics, traversal, highlighter, BOM, D-09(b), D-15(b), Assist Part handling, or client-cleanup behavior changes.

## 0.27.10 — 2026-10-05 — CR-04 Slice 3 CA1822 Warning Corrective

- Records user workstation `quality-gate-20261005-151856.txt`: Release x64 build PASS, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local quality gates PASS and exit code 0, but one CA1822 analyzer warning remained.
- Exact warning: `Cr04WrongTypeSmokeProbe.Read` did not access instance data and could be static. Project policy requires a 0-warning quality gate before live validation.
- Resolves only that warning by storing the already-used `CimatronAssemblyBodyAttributeReader` as a private readonly probe field and invoking it from `Read(...)`; inputs, outputs, adapter call, wrong-type status/count semantics and fail-safe acceptance criteria are unchanged.
- Advances only CimatronIntegration assembly/file metadata to `0.27.10.0`; Plugin remains `0.27.8.0`.
- No production `CimatronAssemblyBodyAttributeReader`, Plugin, architecture-test, traversal, CR-04 business-rule, FeatureComposition/config, BOM, D-09(b), D-15(b), Assist Part, highlighter or client-cleanup change.
- Agent did not execute the Windows/.NET Framework quality gate or Cimatron. Status remains AWAITING USER QUALITY GATE / LIVE IN-PROCESS SMOKE.

## 0.27.9 — 2026-10-05 — CR-04 Slice 3 Compile Corrective

- Records user workstation `quality-gate-20261005-143341.txt`: Release x64 compilation failed and the captured gate exited 1.
- Exact compiler defect: CS0102 in `Cr04WrongTypeSmokeProbeResult` because the type contained both the `ReadError` integer property and a static factory method named `ReadError`.
- Renames only the static failure factory to `Failure` and updates its three internal call sites. The public `ReadError` count property and all smoke result semantics are unchanged.
- Advances only CimatronIntegration assembly/file metadata to `0.27.9.0`; Plugin remains `0.27.8.0` because no Plugin source changed.
- No production `CimatronAssemblyBodyAttributeReader`, CR-04 business/traversal/wrong-type behavior, architecture rule/test, FeatureComposition/config, BOM, D-09(b), D-15(b), Assist Part, highlighter or client-cleanup change.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**; live Cimatron smoke remains blocked until a clean gate.

## 0.27.8 — 2026-10-05 — CR-04 Slice 3 Architecture-Boundary Corrective

- Records user workstation `quality-gate-20261005-141153.txt`: Release x64 build succeeded with **0 warnings / 0 errors**, then architecture tests failed and the gate exited 1 because `CimatronCustomization.Plugin` directly referenced `CimatronCustomization.Domain`.
- Records the standalone architecture-test output identifying the exact mismatch: expected Plugin references exclude Domain; actual references included `CimatronCustomization.Domain`.
- Removes the direct Plugin→Domain ProjectReference introduced in 0.27.7; the core architecture dependency guard remains unchanged.
- Adds developer-only `Cr04WrongTypeSmokeProbe` in CimatronIntegration. It calls the unchanged real `CimatronAssemblyBodyAttributeReader`, interprets Domain-backed body observations inside the approved outer layer, and returns only primitive occurrence/count/status evidence to Plugin.
- Adjusts only the CR-04 in-process-smoke-specific architecture guard so it verifies Plugin→Integration→Domain layering, real production-adapter use, exact wrong-type status counting, one-shot request behavior, and read-only/no-alternate-type constraints. It does **not** weaken the general Plugin→Domain prohibition.
- Advances Plugin and CimatronIntegration assembly/file metadata to `0.27.8.0`. Production adapter code and all CR-04 business/traversal/wrong-type semantics remain unchanged.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**; live Cimatron smoke remains blocked until a clean gate.

## 0.27.7 — 2026-10-05 — CR-04 Slice 3 Plugin Domain-Reference Build Corrective

- Records user workstation `quality-gate-20261005-140642.txt`: Release x64 compilation failed before tests with three CS0012 errors in `Cr04Slice3WrongTypeInProcessSmoke.cs`; gate exit code 1.
- Adds the missing direct `CimatronCustomization.Domain` ProjectReference to the Plugin project because the smoke consumes `ModelEntityReference` exposed by the production adapter result.
- Advances Plugin assembly/file metadata to `0.27.7.0`. No smoke logic, production adapter, CR-04 semantics, traversal, wrong-type rule, FeatureComposition/config, BOM, D-09(b), D-15(b), Assist Part handling, highlighter, or cleanup behavior changes.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**. Live smoke remains blocked until a clean gate.


## 0.27.6 — 2026-10-05 — CR-04 Slice 3 In-Process Plugin Wrong-Type Smoke

- Implements the explicitly approved developer-only one-shot smoke in the existing Plugin command path; the normal launcher is bypassed only when a valid 30-minute request file is atomically consumed.
- Uses the authoritative class/in-process `CimServicesAPI.CimApplicationProvider` application context and calls the unchanged real production `CimatronAssemblyBodyAttributeReader`.
- Fails closed unless active Assembly title is exactly `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`; targets occurrence `KA-PART-1-CR04-WRONG-TYPE`, body entity `4`, attribute `CR04_WRONG_TYPE_CONTROL`.
- Records target occurrence/body, `Present`/`Absent`/`ReadError`, and saved-document/file no-mutation evidence. `Present>0` is a hard stop. Accepted live outcome is exactly `Present=0`, `ReadError>=1`, `NoMutation=PASS`, `Result=FAIL_SAFE_READ_ERROR_OBSERVED`.
- Adds architecture guards prohibiting alternate-type probing, model mutation, `CimAppAccess`, `FeatureComposition` registration, `GetEntityById`, and non-one-shot request behavior in this smoke.
- Adds `tools/Request-Cr04Slice3WrongTypeInProcessSmoke.ps1`; it creates/cancels the request and never launches Cimatron.
- Adds the governing CR-04 v1.4 specification to `docs/requirements/` so this cumulative ZIP is self-contained.
- Bumps Plugin assembly/file metadata to `0.27.6.0`; production CimatronIntegration adapter source/semantics are unchanged.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE + LIVE IN-PROCESS SMOKE**; agent claims no PASS.

## 0.27.5 — 2026-10-05 — CR-04 Slice 3 Smoke Existing-Session Attach Corrective

- Records the clean user workstation `quality-gate-20261005-122845.txt` for 0.27.4: Release x64 PASS, **0 warnings / 0 errors**, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the version-consistent controlled helper rerun at `2026-10-05T12:57:02.5871775+05:30`: `ToolVersion: 0.27.4`, genuine `cmAttInteger=2738`, production-shaped `cmAttString` query `READ_ERROR`, HRESULT `0x80004005`, result `WRONG_TYPE_CONTROL_ATTACHED_AND_READ_BACK`.
- Records the invalid first production-adapter smoke attempt: the smoke's no-mutation capture called `interop.CimAppAccess.AppAccess().GetApplication()` and launched a second Cimatron instance rather than attaching to the already-open disposable assembly. No smoke PASS is claimed.
- Corrects only `CimatronCustomization.CimatronIntegrationTests`: `MutationObservation.Capture()` now uses the same existing-session provider route as production (`interop.CimServicesAPI.CimApplicationProvider().GetApplication()`), and the test project direct interop reference changes from `interop.CimAppAccess` to `interop.CimServicesAPI`.
- No production `src/**` code, CR-04 traversal, attribute classification, highlighter, Application, DesignChecks, configuration, or model behavior changes.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**, then re-run the controlled production-adapter smoke against the already-prepared disposable assembly.

## 0.27.4 — 2026-10-05 — CR-04 Slice 3 Helper Evidence Version-Stamp Corrective

- Records the clean user workstation `quality-gate-20261005-121959.txt` for 0.27.3: Release x64 PASS, **0 warnings / 0 errors**, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the successful controlled helper rerun at `2026-10-05T12:23:23.7867285+05:30`: `ReadBack.Type: cmAttInteger`, `ReadBack.Value: 2738`, `PostSetupCmAttStringQuery.Status: READ_ERROR`, HRESULT `0x80004005`, and `Result: WRONG_TYPE_CONTROL_ATTACHED_AND_READ_BACK`.
- Corrects the development-only `KnownAnswerModelSetup` evidence display constant from stale `ToolVersion: 0.27.0` to `0.27.4` and aligns that helper assembly/file metadata to `0.27.4.0`.
- No production adapter, traversal, attribute-classification, highlighter, Application, DesignChecks, configuration, or Cimatron runtime behavior changes.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**, then one controlled helper rerun for version-consistent evidence, then the already-approved production-adapter live smoke.

## 0.27.3 — 2026-10-05 — CR-04 Slice 3 Wrong-Type Helper E_FAIL Evidence Corrective

- Records the clean user workstation `quality-gate-20261005-112440.txt` for 0.27.2: Release x64 PASS, **0 warnings / 0 errors**, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the controlled user Cimatron setup observation: genuine `CR04_WRONG_TYPE_CONTROL` read back as `cmAttInteger`, value `2738`; the deliberate `cmAttString` query then threw COM `E_FAIL`. This supports the approved wrong-type FAIL-SAFE RULE as `ReadError` and did not trigger the conforming-string hard stop.
- Corrects only the development-only `KnownAnswerModelSetup` observation path so `COMException` from that deliberate post-setup `cmAttString` query is recorded as `PostSetupCmAttStringQuery.Status: READ_ERROR`, with HRESULT/message, instead of escaping as `KNOWN-ANSWER SETUP FAILED`.
- Bumps only `CimatronCustomization.KnownAnswerModelSetup` assembly/file metadata to `0.27.3.0`. Production adapter/runtime code is unchanged; CimatronIntegration production metadata remains `0.27.2.0`.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE**, then controlled rerun against the already-created wrong-type control, then production-adapter live smoke.

## 0.27.2 — 2026-10-05 — CR-04 Slice 3 CA1859 Warning Corrective

- Records the user workstation `quality-gate-20261005-111916.txt`: Release x64 PASS; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests PASS; coverage/local quality gates PASS; exit code 0; but build summary contained **1 warning / 0 errors**.
- Corrects the sole warning, CA1859 in `CimatronAssemblyBodyAttributeReader.ReadBodies`, by changing that private helper return type from `IReadOnlyList<BodyAttributeObservation>` to concrete `List<BodyAttributeObservation>`. Runtime behavior and public contracts are unchanged.
- Bumps `CimatronCustomization.CimatronIntegration` assembly/file metadata to `0.27.2.0` because production source changed, satisfying C-01 version discipline.
- No highlighter, Application contract, configuration, BOM, D-09(b), D-15(b), Assist Part, or feature-registration changes.
- Validation status: **AWAITING RE-RUN USER WORKSTATION QUALITY GATE WITH 0 WARNINGS / 0 ERRORS**. Live wrong-type smoke remains blocked until that clean gate.

## 0.27.1 — 2026-10-05 — CR-04 Slice 3 Test-Project Reference Corrective

- Corrects the first user workstation 0.27.0 quality-gate failure: `CimatronCustomization.CimatronIntegrationTests` directly uses Domain type `ModelEntityReference` but lacked a direct `CimatronCustomization.Domain` project reference, producing CS0012 and build exit code 1.
- Adds only the missing Domain `ProjectReference` to the CimatronIntegrationTests project; production Slice 3 runtime code, highlighter, Application contracts, configuration, and Cimatron behavior are unchanged.
- Records the failed gate evidence and advances the package/governance version to `0.27.1`; production assembly metadata remains `0.27.0.0` because no production assembly changed in this corrective.
- Validation status: **AWAITING RE-RUN USER WORKSTATION QUALITY GATE**. Live wrong-type smoke remains blocked until a clean gate.

## 0.27.0 — 2026-10-05 — CR-04 Slice 3 Production Cimatron Body-Attribute Adapter

- Adds production read-only `CimatronAssemblyBodyAttributeReader` implementing the existing Slice-2 `IAssemblyBodyAttributeReader` contract.
- Preserves the production-highlighter-equivalent occurrence scope: top-level `GetInstances()`, current-occurrence-before-descent semantics, `get_SubInstances(1, 0)`, assembly-only descent, and depth stop `16`.
- Returns all traversed occurrences, including suppressed and zero-body occurrences, so Application continues to own D-15 full-scope InstanceId uniqueness and business filtering.
- Propagates inherited suppression as parent-effective OR direct `IAssInstance.IsSuppressed` without removing suppressed occurrences from the snapshot.
- Reads occurrence bodies only through the previously verified `IAssInstance.GetAllEntities()` route and keeps `cmBody` entities only.
- Reads configured values only through exact named `GetAttribute(cmAttString, name)`. Production code does not enumerate returned names, probe `cmAttInteger`, use `GetEntityById` for occurrence bodies, or mutate models.
- Implements the approved wrong-type FAIL-SAFE RULE: null => provisional `Absent`; unexpected returned type, unreadable/conversion failure, or exception => `ReadError`; no `UnsupportedType` state is introduced.
- Adds CimatronIntegration source/architecture guards for traversal, read-only boundaries, no alternate-type probing, highlighter-compatible references, and inherited suppression.
- Extends the development-only `KnownAnswerModelSetup` with explicit `--cr04-wrong-type-control`, restricted to disposable `KA-PART-1-CR04-WRONG-TYPE`, body `4`, `CR04_WRONG_TYPE_CONTROL=2738`, stored/read back as `cmAttInteger`; overwrite remains prohibited and autosave remains disabled.
- Adds an opt-in CimatronIntegration live smoke controlled by `CIMATRON_DEV_ENABLE_CR04_SLICE3_WRONG_TYPE_SMOKE=1`; it calls the real production adapter, checks active-document no-mutation evidence, and hard-stops if the genuine non-string control is reported as conforming `Present` string evidence.
- Bumps CimatronIntegration and KnownAnswerModelSetup assembly/file metadata to `0.27.0.0`.
- Does not register CR-04 in `FeatureComposition`, change production configuration, implement BOM/D-09(b)/D-15(b), re-open Assist Parts, modify the highlighter, or remove Package-2 diagnostics.
- Validation status: **AWAITING USER WORKSTATION QUALITY GATE + CONTROLLED LIVE WRONG-TYPE ADAPTER SMOKE**. Agent did not execute build/tests/coverage/setup/Cimatron and claims no PASS.

## 0.25.0 — 2026-10-04 — CR-04 Slice 2 Application Use Case + Ports

- Implements the approved Slice 2 Application boundary only; Slice 3 Cimatron adapters remain blocked.
- Adds `IAssemblyBodyAttributeReader` plus full-traversal snapshot/occurrence/body observation types. The port contract explicitly forbids pre-filtering suppressed, zero-body, non-CR-04 or otherwise business-irrelevant occurrences because Application owns D-15 safety.
- Adds `VerifySteelGradeAgainstDesignOrder` and an explicit request/options type for Design-Order mapping, body attribute names, component-key source and comparison policy.
- Fixes this increment to D-01 Option A (body attribute only), D-09(a) absolute path only, D-10 first-error, D-11 existing strict/no-trim behavior, and no BOM/D-09(b) implementation.
- Adds `DesignOrderInputPathResolver` for absolute configured paths only; assembly-folder/title tokens are deliberately rejected/deferred.
- Keeps Design-Order steel grade transport-optional so blank grade reaches Domain D-16 handling; separately enforces presence of the configured steel-grade header.
- Implements D-15(a) after Domain evaluation by removing only unsafe references based on `InstanceId` uniqueness across the complete snapshot, preserving the finding status and adding an explanatory highlight-unavailable message.
- Keeps attribute-type semantics provisional: missing observations can become absent evidence, but Slice 2 never sets `attributeTypeUnsupported = true`.
- Adds Application tests for path strategy, tabular stop behavior, blank-grade Domain handling, CAD read failures/exceptions, D-15 full-scope filtering, provisional absent semantics and the Application-level ST06-DF-06 guard that programming defects are not remapped to `TABULAR_FILE_READ_ERROR`.
- ST06-DF-06 is **not claimed closed**: the protected Step 06 `ExcelTabularDataReader` exception-classification implementation is unchanged in this increment.
- Records 2026-10-04 inherited-suppression evidence as LIVE OBSERVED / VERIFIED FOR EFFECTIVE CHILD SUPPRESSION, with the exact API nuance that the child reported `suppressed=1` while the parent occurrence row reported `suppressed=0`. Assist Part remains NOT AVAILABLE / NOT VERIFIED.
- Advances `CimatronCustomization.Application` metadata to `0.25.0.0`. Test assembly metadata remains unchanged, consistent with prior project versioning practice.
- Agent did not build, execute tests/coverage/static analysis or run Cimatron.
- User workstation quality gate `quality-gate-20261004-203340.txt` completed at `2026-10-04T20:34:09.4951348+05:30`: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, Application coverage 94.63%, coverage gate PASS, local quality gate PASS, exit code 0.
- Records the pre-gate minimal-package repository recovery as a packaging/recovery incident only; it is not treated as a Slice 2 code failure.
- User approved closure after reviewing the clean quality-gate evidence. Slice 2 status: **CLOSED / USER VALIDATED**. Slice 3 remains blocked by the carried Slice 2A runtime gates.

## 0.24.5 — 2026-10-04 — CR-04 Slice 2A Session Handoff

- Recorded the user-supplied clean 0.24.4 quality gate: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gate PASS, exit code 0.
- Recorded the controlled 0.24.4 `KA-ASM-1` live verifier result: approved D-15 full-traversal identity rule active, known/missing/wrong-type attribute observations consistent, real ID collisions retained, and no-mutation PASS.
- Recorded that no self-instance/PID/title/ID/root-name heuristic is part of CR-04.
- Added the new-session handoff and exact next-session Slice 2A closure-review step.
- Applied the user packaging instruction: generated `artifacts/**` console/runtime outputs and raw historical console/verifier `.txt` evidence files are excluded from the progressive ZIP; validated results are summarized in governed documentation instead.
- Documentation/governance/package cleanup only; no production `src/**`, verifier runtime, test behavior, configuration, installer or Cimatron model behavior changed.

## 0.24.4 — 2026-10-04 — CR-04 Slice 2A D-15 Occurrence-Identity Corrective

- Records clean user workstation 0.24.3 quality gate: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gates PASS, exit code 0.
- Records controlled 0.24.3 live `KA-ASM-1` diagnostic with `NoMutation.Result: PASS`.
- Resolves the diagnostic design error introduced in Slice 2A: the approved CR-04 v1.4 D-15 rule does not require a special self-instance classifier.
- Removes PID-equality self classification, self-only summary/skip behavior, `GetRootInstance`/`AssRootInstance`/`AssParentInstance` root-relation diagnostics, and all self-based filtering from CR-04 capability evaluation.
- Keeps every occurrence in the exact highlighter-equivalent traversal for D-15 `InstanceId` uniqueness, including suppressed/excluded/zero-body occurrences.
- Reads occurrence bodies for every traversed occurrence; zero-body synthetic/internal rows naturally contribute no grade evidence and require no guessed exclusion rule.
- Calculates otherwise-valid/unsafe known-attribute occurrence counts without a self-instance exclusion.
- Adds regression/source-contract protection that forbids self/root/PID heuristics in the CR-04 verifier while preserving exact highlighter traversal, MTA dispatch, suppressed collision scope and depth behavior.
- Corrects stale development verifier display version from `0.24.2` to `0.24.4`; advances verifier and CimatronIntegrationTests metadata to `0.24.4.0`.
- No production `src/**`, Plugin, highlighter, CR-04 business rule, Cimatron model, configuration, installer, or mutation behavior changes.
- Validation: **AWAITING USER 0.24.4 CLEAN QUALITY GATE + ONE CONTROLLED LIVE KA-ASM-1 RERUN**. Agent did not build/test/run Cimatron.

## 0.24.3 — 2026-10-04 — CR-04 Slice 2A Self-Instance Root/Relation Diagnostic

- Records clean user workstation 0.24.2 quality gate: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gates PASS, exit code 0.
- Records successful 0.24.2 live `KA-ASM-1` CR-04 capability run and `NoMutation.Result: PASS`.
- Records live findings: repeated `InstanceId` values `3`, `5`, `6`; three exact known `cmAttString` occurrences; missing-name lookups returned null; wrong-type `cmAttInteger` lookup returned attributes on all three known-value bodies.
- Records blocker: PID-equality self-instance rule returned zero self-instances and is not accepted for production.
- Adds read-only `IAssemblyModel.GetRootInstance()` evidence per containing Assembly plus root model ID/title/PID/type observations.
- Adds per-occurrence `AssRootInstance` and `AssParentInstance` ID evidence where readable, plus explicit comparison with the containing root object/ID. Root parent access is intentionally `ROOT/N/A`.
- Keeps the existing PID-based self flag only as a provisional comparison signal; no new production self-instance rule is promoted.
- Adds CimatronIntegration source-contract regression protection for the diagnostic-only root/relationship evidence.
- Advances development verifier and CimatronIntegrationTests metadata to `0.24.3.0`.
- No production `src/**`, Plugin, CR-04 business rule, Cimatron model, configuration, installer, or mutation behavior changes.
- Validation: **AWAITING USER 0.24.3 CLEAN QUALITY GATE + ONE CONTROLLED LIVE KA-ASM-1 RERUN**. Agent did not build/test/run Cimatron.

## 0.24.2 — 2026-10-04 — CR-04 Slice 2A MTA Attach Corrective

- Records first live `KA-ASM-1` CR-04 verifier attempt: `IAppAccess.GetApplication()` failed before model inspection with COM `0x80040154` (`Class not registered`).
- Records controlled attach evidence in the same normal user session: `ZoomCommandDiscovery.exe --attach-only --apartment=MTA` returned `ATTACH ONLY: PASS (MTA)`.
- Keeps the verifier process entry point `[STAThread]` so older validated diagnostic modes are not globally changed.
- Routes only `--verify-cr04-capabilities` through a dedicated MTA worker, waits for completion, and rethrows worker exceptions to the existing top-level error boundary.
- Adds CimatronIntegration source-contract coverage for the CR-04-only MTA dispatch and exception propagation.
- Advances development verifier and CimatronIntegrationTests metadata to `0.24.2.0`.
- No production `src/**`, Plugin, CR-04 business-rule/traversal semantics, Cimatron model, or mutation behavior changes.
- Validation: **AWAITING USER 0.24.2 CLEAN QUALITY GATE + CONTROLLED LIVE RETRY**. Agent did not build/test/run Cimatron.

## 0.24.1 — 2026-10-04 — Session Handoff Refresh

- Recorded user workstation `quality-gate-20261003-000106.txt`: Release x64 PASS, 0 warnings / 0 errors, governed suites PASS, coverage/local quality gate PASS, exit code 0.
- Updated current state to **QUALITY GATE PASS / AWAITING LIVE SLICE 2A CIMATRON VALIDATION**.
- Clarified that the first live Slice 2A run may use existing `KA-ASM-1` with `STEP07_B1_TEST_ATTRIBUTE=KNOWN_ANSWER_07C3`; a dedicated `KA-ASM-CR04` model is only required if additional controlled cases cannot be observed on existing known-answer models.
- Added new-session handoff. No source, test, verifier, Plugin, or runtime behavior changed.

## 0.23.1 — 2026-10-02 — Phase 02 Step 09 CR-04 Slice 1 Warning/Coverage Corrective

- Records user 0.23.0 evidence: local quality gate PASS / exit 0, but 26 analyzer warnings; Domain overall coverage 98.94%.
- Records class-level coverage miss for `CadComponentSteelGradeEvidence`: 91.67% line / 85.71% branch against the approved >=95% / >=90% target.
- Removes the Slice 1 CA1859, CA1861 and CA1806 warning causes with the smallest production/test-only corrections.
- Adds focused tests for null optional collections, original-key fallback, null reference collection handling and null-reference rejection in `CadComponentSteelGradeEvidence`.
- No CR-04 business rule, Cimatron API, configuration, Plugin, tabular, highlighter or adapter behavior changes.
- Validation: **AWAITING USER CLEAN QUALITY GATE + UPDATED COBERTURA**. Agent did not execute build/tests/coverage.

## 0.22.2 — 2026-10-02 — Step 08B Closure / User Validation

- Records clean user workstation quality gate `quality-gate-20261002-131500.txt`: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local gates PASS, exit code 0.
- Records the successful governed 0.22.1 live `KA-ASM-1` rerun: U8 occurrence structure PASS; U13 nested body resolution and exact named attribute PASS; U7 `GetAssemblyEntity` mapping PASS; U15 `cmNoFiltering` BOM export/readback PASS with exactly one target `Standard Number=KA-PART-1` row and `Material=1.2738`; programmatic no-mutation PASS; Step08B temp cleanup PASS.
- Records production Result Report Highlight validation for U12: user clicked `Highlight` on the nested-reference finding, visually confirmed the intended nested `KA-PART-1` body highlighted, then confirmed highlight restoration after closing and that `KA-ASM-1` remained unmodified.
- Promotes U7, U8, U12 and U13 to **IN-PROCESS VERIFIED** for the approved Assembly-context scope.
- Promotes U15 to **IN-PROCESS VERIFIED for the approved `cmNoFiltering` material-read scope only**. `cmVisibleOnly` visibility-filter semantics are not newly promoted by this step and remain governed by their existing Step 07 evidence / later Step 08 needs.
- Retains `IAssInstance.GetAllEntities()` classification as installed-Interop + governed runtime evidence only because no authoritative SDK documentation-index entry was found.
- Retains the earlier 0.22.0 U15 `READ_ERROR` and the 0.22.1 target-row corrective for audit traceability.
- Documentation/evidence closure only: no production `src/**`, Plugin behavior, configuration, installer, model, CR-04 logic, or production assembly metadata changed from 0.22.1.
- DF-05 remains active: the developer-visible Step 08B diagnostic must be gated/removed before D5 client packaging.
- Status: **STEP 08B CLOSED / USER VALIDATED**.

## 0.22.1 — 2026-10-02 — Step 08B U15 Target-Row Material Corrective

- User workstation `quality-gate-20261002-124744.txt` is retained as clean 0.22.0 evidence: Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gate PASS, exit code 0.
- First governed 0.22.0 live Step 08B run stopped on U15 as required: U8/U13/U7 PASS; U12 nested highlight reference was prepared but no Highlight action was executed; U15 returned `READ_ERROR TABULAR_REQUIRED_VALUE_MISSING` at a non-target BOM row; no-mutation and temporary-run-directory cleanup PASS.
- Root cause is in `CimatronBomMaterialExporter`: the existing validated `ITabularDataReader` was configured with `Material` required for every BOM row, so an unrelated row with blank Material blocked lookup of `Standard Number=KA-PART-1`.
- Corrected only U15 readback semantics: `Standard Number` remains required; `Material` is optional while parsing unrelated rows; after locating a target `KA-PART-1` row, Material is mandatory for that target row and missing/blank target Material becomes explicit `READ_ERROR`.
- Preserved `IBOM.Export(... cmNoFiltering ...)`, locked Step 07 BOM header, existing `ITabularDataReader`, governed `%TEMP%\CimatronCustomization\Step08B\<timestamp>\` cleanup, programmatic no-mutation guards, and all U8/U13/U7/U12 logic.
- Added focused Application-result coverage for the target-row missing-material error path and strengthened architecture guards so the adapter cannot regress to globally-required Material semantics.
- Added the supplied clean quality-gate capture and first-run live Result Report screenshot to cumulative evidence.
- No CR-04 business logic, alternate API/filter/path, unrelated refactor, or new Cimatron behavior was introduced. Production `AssemblyInfo.cs` metadata remains `0.22.0.0` because it was outside the specifically approved 0.22.1 corrective file list.
- Agent did not build/test/run Cimatron. Validation: **AWAITING USER CLEAN QUALITY GATE, THEN SEPARATELY GOVERNED LIVE RERUN**.

## 0.22.0 — 2026-10-02 — Step 08B Component Property / Assembly Context In-Process Confirmation

- Adds capability-named Application ports/results for nested occurrence attribute read, assembly-entity mapping, and governed BOM material export/readback.
- Adds CimatronIntegration adapters for U8/U13, U7, and U15 using the approved known-answer routes. `IAssInstance.GetAllEntities()` is explicitly treated as installed-Interop/runtime-evidence only; no official SDK index entry was found.
- Extends the production viewport highlighter so a nested occurrence reference can be resolved, mapped with `IAssemblyModel.GetAssemblyEntity`, and highlighted through the existing verified `ISelection.Selection` path.
- Adds the Assembly-only `Step 08B Component Property / Assembly Context Confirmation` foundation feature. The feature carries the nested U12 reference to the normal Result Report; it shows no UI and performs no pause itself.
- Locks U8 known answers to 3 total `KA-PART-1` occurrences, 2 top-level via model lookup, and 1 nested via recursive `SubInstances`; IDs remain runtime evidence only.
- Locks U13 to nested body ID 4 / `cmBody` and exact named `cmAttString` value `KNOWN_ANSWER_07C3`; returned `IAttribute.Name` is not a match condition.
- Locks U15 to `cmNoFiltering`, the Step 07 CSV header contract (`Standard Number` + `Material` included), and `KA-PART-1` material `1.2738`, parsed through the existing `ITabularDataReader`.
- BOM export is constrained to `%TEMP%\CimatronCustomization\Step08B\<timestamp>\`; cleanup failure is Warning, and `GetBomManager`/export COM failures become `READ_ERROR` feature evidence rather than crashes.
- Adds programmatic no-mutation evidence (document modified-state + model file timestamp/length + model-folder listing around BOM export).
- Adds Application fake-port tests, custom test-runner registration, and architecture guards preventing regression to the failed U13 `GetEntityById` route / returned-name equality gate and guarding the nested production highlight/BOM boundaries.
- Registers the diagnostic in the existing Plugin composition root using the validated `ExcelTabularDataReader`.
- Aligns Application, CimatronIntegration, DesignChecks and Plugin assembly/file metadata to `0.22.0.0`.
- DF-05 remains explicit: this developer-visible foundation diagnostic must be gated/removed before D5 client packaging.
- No CR-04 business logic, customer configuration, installer change, or model-writing behavior is introduced.
- Agent did not build/test/run Cimatron; validation is awaiting the user workstation quality gate and the single governed live run.

## 0.21.4 — 2026-10-01 — Step 08A U1 In-Process Confirmation Closure

- Records clean user workstation quality gate `quality-gate-20261001-023742.txt`: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records final controlled live Plugin validation against `KA-PART-1`: Volume, Center, Surface Area and no-mutation all PASS against the locked Step 07 known answer.
- Promotes U1 from Step-07-only VERIFIED / Step-08A open to **IN-PROCESS VERIFIED** for the approved Part-context scope.
- Retains both the earlier zero-value diagnostic observation and the later successful governed rerun; no unsupported explanation is invented and no runtime correction is introduced in this closure package.
- Updates capability register, implementation history, session handoff, time ledger, retained evidence, version and checksums only.
- Step 08A is **CLOSED / USER VALIDATED**. Step 08B is not started.
- No production source, Plugin runtime behavior, configuration, installer, CR/SA behavior, or model data changed in 0.21.4.

# Changelog

## 0.21.3 — Phase 02 Step 08A Quality-Gate CA1861 Corrective

- Records user workstation quality gate `quality-gate-20261001-023056.txt`: Release x64 build PASS, governed tests PASS, coverage gate PASS, local quality gate PASS and exit code 0, but **1 warning / 0 errors**.
- The warning is Roslyn analyzer `CA1861` in `U1InProcessGeometryConfirmationTests.DiagnosticEvidenceIsSurfacedAsWarning`, caused by an inline constant string-array argument.
- Corrects only that test fixture by moving the sample diagnostic evidence to a reusable `static readonly string[]`.
- Does not change `CimatronBodyGeometryMetricsReader`, U1 validation logic, Plugin behavior, known-answer values, CR/SA logic, configuration, installer or model state.
- Production assembly/file versions remain `0.21.2.0`; this corrective does not touch production assembly metadata.
- Live Cimatron diagnostic execution remains blocked until the user supplies a clean 0-warning quality gate.
- Agent did not execute build/tests/Cimatron.


## 0.21.2 — Phase 02 Step 08A U1 In-Process Path Diagnostic

- Records clean user workstation quality gate `quality-gate-20261001-015904.txt`: Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gates PASS, exit code 0.
- Records the first controlled live Plugin result: U1 volume, center, and surface-area comparisons failed; no-mutation evidence passed. Step 08A remains open and U1 is not IN-PROCESS VERIFIED.
- Adds read-only side-by-side diagnostic evidence in `CimatronBodyGeometryMetricsReader`: current `GetEntityById` path versus the exact Step 07 entity-type enumeration/list-construction path.
- Surfaces three diagnostic Warning rows in the existing Result Report: context/entity resolution, current-path raw values, and Step-07-equivalent enumeration/raw values.
- Does **not** switch production behavior to the alternate path and does not change the locked U1 known-answer values.
- Adds a focused Application test proving diagnostic evidence is surfaced without being mistaken for a pass.
- Aligns the four Step 08A production assembly metadata files to `0.21.2.0`; metadata only.
- Carries the clean quality-gate capture and live-failure screenshot as package evidence.
- No CR/SA implementation, configuration, installer, or model mutation. Agent did not execute build/tests/Cimatron.

## 0.21.1 — Phase 02 Step 08A Quality-Gate Warning Corrective

- Records user workstation quality gate `quality-gate-20261001-015133.txt`: Release x64 build PASS, governed tests PASS, coverage gate PASS, local quality gate PASS, exit code 0, but **1 warning / 0 errors**.
- The single warning is Roslyn analyzer `CA1806` in `U1InProcessGeometryConfirmationTests.ConstructorAndContextGuards`, caused by intentionally constructing the feature only to assert the null-reader guard.
- Corrects only that test expression by retaining the constructed value with `GC.KeepAlive`; no Application, CimatronIntegration, DesignChecks, Plugin, CR/SA, configuration, installer, or Cimatron runtime behavior changes.
- Carries the supplied quality-gate capture into `artifacts/console-captures/` and updates Step 08A history/handoff/time records.
- U1 remains **NOT IN-PROCESS VERIFIED** until the user supplies a clean 0-warning quality gate and controlled live Plugin evidence.
- Agent did not execute build/tests/Cimatron.

## 0.21.0 — Phase 02 Step 08A U1 In-Process Confirmation Foundation

- Closed the approved Step 07D register gate using user-supplied workstation quality-gate evidence (`quality-gate-20261001-013106.txt`) and explicit whitelist approval.
- Added `IBodyGeometryMetricsReader` and `BodyGeometryMetricsSnapshot` to the Application boundary.
- Added read-only `CimatronBodyGeometryMetricsReader` using the already Step-07-verified Cimatron 2026 U1 path: `IMdlrModel.GetGeomServicesObj` plus `IGeomServices.BodiesVolume`, `BodiesCenter`, and `BodiesSurfArea`.
- Added `U1InProcessGeometryConfirmationFeature`, restricted to saved `KA-PART-1` body ID `4` and the locked Step 07 B1 known-answer values.
- Added explicit no-mutation verification using document modified-state plus saved-file timestamp/length before and after the U1 read.
- Registered the foundation diagnostic in the existing Plugin composition root.
- Added fake-port Application tests for matching values, mismatch behavior, unsupported input, no-mutation failure, and guard clauses.
- Under separately approved metadata-only scope, aligned Application, CimatronIntegration, DesignChecks, and Plugin AssemblyVersion/AssemblyFileVersion to `0.21.0.0`.
- No CR/SA business rule was implemented. No other Step 08 capability was promoted.
- Agent did not execute build/tests/Cimatron; status remains awaiting user quality gate and live in-process validation.

## 0.20.26 — 2026-09-30 — Step 07C-4 BOM Read-Error Corrective

- Records user workstation 0.20.25 quality-gate PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records the corrected-model live evidence proving `ICimEntity.Show` is a body/entity visibility signal: the hidden body returned `Show.GET=0`, while visible bodies and hidden occurrence `Known_Pocket_Body` returned `Show.GET=1`.
- Records `GetBomManager()` COM `E_FAIL` on the corrected model, which prevented re-confirming the `cmVisibleOnly` occurrence route.
- Changes only the development verifier so `GetBomManager()` is observed with `TryObserve`; a read error is recorded and the run continues to semantics-neutral status plus no-mutation evidence instead of aborting.
- Adds an architecture source-contract guard for the non-fatal BOM-read path.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer, or model behavior changed.
- Validation: **AWAITING USER 0.20.26 QUALITY GATE + CONTROLLED LIVE RETRY**. No 0.20.26 PASS claimed.

## 0.20.25 — 2026-09-30 — Step 07C-4 U16 Hidden-State Verification Preparation

- Starts the explicitly approved Step 07C-4 U16 verification using the finalized copy model `KA-ASM-1-U16-HiddenBody-Control`.
- Keeps `ICimEntity.Show` getter-only and records retained 07A getter evidence in the live diagnostic output.
- Changes the development-only hidden-state verifier to enumerate occurrence-reached bodies through `IAssInstance.GetAllEntities()`, record occurrence title/suppression/body IDs, and read assembly-context `Show.GET` without assigning semantics.
- Adds explicit BOM membership evidence for `cmNoFiltering` and `cmVisibleOnly`, including complete data rows and exact row-set differences so the hidden-occurrence candidate can be classified from one run.
- Retains the single-run stopping rule and no-mutation evidence.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer, or model behavior changed.
- Validation: **AWAITING USER 0.20.25 QUALITY GATE + ONE GOVERNED 07C-4 LIVE RUN**. No PASS claimed.

## 0.20.24 — 2026-09-30 — Step 07C-3 Closure / User Validation

- Records user workstation 0.20.23 quality-gate PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records final governed live evidence `api-capability-component-properties-20260930-133403.txt`.
- Promotes U13 body/entity attribute read path to VERIFIED on both Part-model and assembly-context entities.
- Promotes U15 BOM export/material evidence to VERIFIED for both `cmNoFiltering` and `cmVisibleOnly`; visibility-row differences remain uninterpreted and reserved for 07C-4.
- Retains U14 as NOT AVAILABLE and U17 as NOT AVAILABLE FROM RETAINED 07A EVIDENCE; U16 remains reserved for 07C-4.
- Records model file and model-folder no-mutation evidence as UNCHANGED.
- Documentation/evidence/session-handoff only; no production, verifier runtime, test, configuration, setup-helper, or model behavior changed.
- Step 07C-3 status: **CLOSED / USER VALIDATED**.

## 0.20.23 — 2026-09-30 — Step 07C-3 Occurrence-Entity / Named-Attribute Corrective

- Records user-validated 0.20.22 quality gate PASS (`quality-gate-20260930-130837.txt`): Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gates PASS, exit code 0.
- Records successful controlled setup: `KA-PART-1` body entity `4` = `cmBody`; `STEP07_B1_TEST_ATTRIBUTE` read back as `cmAttString` / `KNOWN_ANSWER_07C3`; result `ATTACHED_AND_READ_BACK`; manual save required.
- Records the first governed 07C-3 verifier stop: `instance.Model.GetEntityById(4, partModel)` raised COM `0x80040207` before U13/BOM evidence.
- Records follow-up read-only assembly evidence proving all loaded `KA-PART-1` occurrences expose body entity `4` through `IAssInstance.GetAllEntities()`.
- Corrects the development-only verifier to resolve exact body ID/type through `IAssInstance.GetAllEntities()` and removes the failed model `GetEntityById` route from this path.
- Keeps `GetAttributes()` enumeration for evidence, then performs exact `GetAttribute(cmAttString, requestedName)` confirmation; matching requires non-null, exact type and exact value, while returned `IAttribute.Name` is evidence only.
- Adds architecture source guards against regression to the failed entity route or returned-name equality gate.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer, setup-helper, or customer-model behavior changed.
- Validation: **AWAITING USER 0.20.23 QUALITY GATE + ONE GOVERNED LIVE RERUN**. No PASS claimed for 0.20.23.

## 0.20.22 — 2026-09-30 — Step 07C-3 Known-Answer Attribute Name-Observation Corrective

- Records the completed 0.20.21 workstation quality gate as PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the controlled 0.20.21 setup evidence: exact named `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` returned non-null; `ReadBack.Type = cmAttString`; `ReadBack.Value = KNOWN_ANSWER_07C3`; returned `ReadBack.Name` was blank.
- Corrects only the post-lookup validation rule: returned `IAttribute.Name` remains logged but is no longer required to equal the requested lookup name.
- Non-null/type/value checks remain fail-closed. Exact model/entity/name/value restrictions, no-overwrite behavior, `Attach()`, exact named lookup, and no Save/SaveAs/Close remain unchanged.
- Existing read-only `CimatronCustomization.ApiCapabilityVerification` remains unchanged; U13 remains NOT VERIFIED until the saved attribute is later read by the governed 07C-3 verifier.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer or customer model behavior changed.
- Validation: **AWAITING USER 0.20.22 QUALITY GATE + CONTROLLED SETUP RERUN**. No PASS claimed for 0.20.22.

## 0.20.21 — 2026-09-30 — Step 07C-3 Known-Answer Attribute Read-Back Diagnostic Corrective

- Records the completed 0.20.20 workstation quality gate as PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the first controlled 0.20.20 setup run failure after `Attach()`: exact `GetAttribute(cmAttString, name)` returned an attribute object, but the subsequent name/type/value comparison failed.
- Corrects diagnostic observability only: actual `ReadBack.Name`, `ReadBack.Type`, and `ReadBack.Value` are now printed to the console before the fail-closed comparison.
- The helper still fails on mismatch, does not overwrite, does not auto-save, and does not try alternate mutation/read-back APIs.
- Existing read-only `CimatronCustomization.ApiCapabilityVerification` remains unchanged; U13 remains NOT VERIFIED.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer or customer model behavior changed.
- Validation: **AWAITING USER 0.20.21 QUALITY GATE + CONTROLLED SETUP RERUN**. No PASS claimed for 0.20.21.

## 0.20.20 — 2026-09-30 — Step 07C-3 Known-Answer Body Attribute Setup Helper

- Records the user-returned 0.20.19 workstation quality gate `quality-gate-20260930-120311.txt` as PASS: Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Adds separate developer-only `CimatronCustomization.KnownAnswerModelSetup`; the existing `CimatronCustomization.ApiCapabilityVerification` remains read-only and unchanged.
- Setup helper is fail-closed to active Part `KA-PART-1`, B1 body entity ID `4`, and `cmAttString` diagnostic attribute `STEP07_B1_TEST_ATTRIBUTE = KNOWN_ANSWER_07C3`.
- Existing same name/type/value returns `ALREADY_PRESENT`; same name with another type/value fails without overwrite.
- New attribute creation uses `IApplication.GetAttributeFactory()`, `IAttributeFactory.Create(cmAttString, name)`, `IAttribute.Value`, `IAttributeSink.Attach()`, then exact `GetAttribute(cmAttString, name)` read-back.
- Helper never calls `Save`, `SaveAs` or `Close`; it reports `MODEL MUTATED IN MEMORY - MANUAL SAVE REQUIRED`.
- U13 remains NOT VERIFIED until the later governed read-only 07C-3 verification reads the saved body attribute. U16/07C-4 remains out of scope.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer or customer model behavior changed.
- Validation: **AWAITING USER 0.20.20 QUALITY GATE + CONTROLLED SETUP RUN**. No PASS claimed for 0.20.20.

## 0.20.19 — 2026-09-30 — Step 07C-3 Verifier Compile Corrective

- Records failed workstation quality gates `quality-gate-20260930-115502.txt` and `quality-gate-20260930-115729.txt`; no PASS is claimed.
- The second capture identifies two `CS1061` errors in `ComponentPropertySourceVerification.cs` because `AttributeObservation` is an enum and the evidence lines referenced a nonexistent `.Status` member.
- Corrected only those two evidence expressions to render the enum value directly. No U13/U15 logic, Cimatron API call, filter, model input, BOM handling, or no-mutation behavior changed.
- Aligns development-verifier ToolVersion and assembly/file version to `0.20.19`.
- The same workstation capture also reports access-denied deployment/copy errors under the Cimatron `Program` folder. This corrective does not change deployment permissions or production code.
- No production `src/**`, Plugin behavior, CR/SA behavior, configuration, installer or model data changed.
- Validation: **AWAITING USER 0.20.19 QUALITY GATE**. Only after PASS may the already-approved single 07C-3 live run proceed.

## 0.20.17 — 2026-09-30

## 0.20.18 — 2026-09-30 — Step 07C-3 Component Property / BOM Verification Preparation

- Hardened the existing development-only `--verify-component-properties` mode under the user-approved 07C-3 scope.
- Requires explicit `--known-attribute-name`, `--known-attribute-value`, and `--known-material`; no customer naming/value assumptions are hard-coded.
- Guards the target entity as `cmBody`, records known body-attribute matching on both Part and assembly-context entities, and keeps U14 getter invocation prohibited.
- BOM evidence now records known-answer model rows, material-column candidates, and known material values while keeping 07C-4 visibility interpretation explicitly out of scope.
- Added model-folder before/after listing evidence in addition to existing model file `IsModified`/timestamp/size evidence.
- Added U17 as the model/Part material-getter evidence item; classified `NOT AVAILABLE FROM RETAINED 07A EVIDENCE` with no new reflection run. Existing U16 remains unchanged for 07C-4.
- No production `src/**`, Plugin, configuration, CR/SA behavior or customer model change.
- Validation: **AWAITING USER QUALITY GATE + ONE LIVE 07C-3 RUN**. No PASS is claimed.

### Step 07C-2 — Architecture-guard alignment corrective
- Records workstation quality gate `quality-gate-20260930-033343.txt`: Release x64 build PASS with 0 warnings / 0 errors, then architecture tests FAIL, overall exit code 1.
- Aligns the Step 07 architecture source guard with the approved empty-selection-safe restore implementation.
- Guard now requires prior-selection capture, temporary highlight assignment, `RestoreSelection(context, previousSelection)`, explicit empty-list fallback, and final restore assignment.
- No verifier runtime behavior, production `src/**`, Plugin, CR/SA, configuration or model-data change.
- U7-U12 remain NOT VERIFIED pending a clean 0.20.17 quality gate and the single approved live run.

## 0.20.16 — 2026-09-30

### Step 07C-2 — Assembly Context verifier compile corrective
- Records failed workstation quality gate `quality-gate-20260930-032936.txt`: verifier compilation failed with CS0411 at `AssemblyContextVerification.cs(214,21)` and `(218,21)`; overall gate exit code 1.
- Fixes only those two development-diagnostic observations by specifying `TryObserve<object>` for transformation matrix/vector reads.
- Aligns verifier ToolVersion and assembly/file version to `0.20.16`.
- Carries forward completed 07C-2A manual known answers: `KA-PART-1`, body ID `4`, top-level B1 gap `25.000 mm`, UCS `UCS10_1`, UI assembly extents unavailable.
- Earlier 0.20.13 live evidence is troubleshooting-only and does not promote U7-U12.
- No production `src/**`, Plugin, CR/SA, configuration or model-data change.
- Validation: awaiting user 0.20.16 quality gate; only after PASS, one governed live assembly-context run.

## 0.20.15 — 2026-09-30

### Step 07C-2 — Assembly Context verification preparation
- Redefines 07C-2A as user-recorded, Cimatron UI/Measure sourced known answers; expected transforms/states/gap/bounding-box values are not derived from the APIs under test.
- Corrects the development-only `--verify-assembly-context` mode so suppressed/lock reads are guarded, matching occurrence transformations are recorded, reverse lookup is explicitly compared, and `--ucs-id` can drive `GetAssemblyBoundingBox`.
- Cross-component `MinDistancePos` now evaluates every matching occurrence pair and records occurrence IDs/depths plus both closest points instead of silently choosing the first two matches.
- Temporary highlight now pauses for user observation and restores the prior selection even when it was originally empty.
- Retains read-only/no-mutation evidence and leaves U7-U12 unpromoted pending user quality-gate + one live KA-ASM-1 run.
- No production `src/**`, Plugin, CR/SA, configuration or model-data change.

## 0.20.14 — 2026-09-30

### Step 07C-1 — Geometry Services closure
- Records user workstation 0.20.13 quality-gate PASS: Release x64 build PASS, 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the final live evidence `api-capability-geometry-20260930-010854.txt` and closes 07C-1 per the user-approved stop rule.
- `GetPiercingPoints` is VERIFIED for the known-answer face-90 semantics: corrected direction/base-position order, bounded-face miss returns `null`, pointing-away ray returns `null`, and direction `(-2,0,0)` returns the same intersection as `(-1,0,0)`.
- Reconfirms `GetEntityPointDistance`, rotated-UCS face-list `GetBoundingBoxByUCS`, and no-mutation `UNCHANGED`.
- Records remaining limitations: `SurfacesArea` is NOT AVAILABLE; body-list `GetBoundingBoxByUCS` remains unresolved/unsupported for consumer use and U2 remains PARTIALLY VERIFIED.
- Documentation/governance only; no production `src/**`, Plugin, CR/SA logic, configuration, model data, tests, or diagnostic runtime behavior changed.
- 07C-1 is CLOSED. 07C-2 is unblocked by closure but NOT STARTED and requires separate explicit approval.

## 0.20.13 — 2026-09-30

### Step 07C-1R5 — Final geometry semantics run preparation
- Corrected development-diagnostic `GetPiercingPoints` argument mapping to the installed signature `iDirection, iBasePositin, iEntList`.
- Added exact input evidence and the fourth `(-2,0,0)` direction-length case to the single final 07C-1 batch.
- User workstation quality gate subsequently passed and the final live geometry run was completed in 0.20.13.
- No production `src/**`, Plugin, CR/SA logic, configuration, or model-data change.

## 0.20.12 — 2026-09-30

### Step 07C-1R4 — Piercing return-shape inspection
- Records user-supplied 0.20.11 quality-gate PASS: Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records live evidence `api-capability-geometry-20260930-004342.txt`: all three face-90 `GetPiercingPoints` calls reached Cimatron but post-call numeric conversion failed because the returned array contains at least one non-numeric top-level item.
- Replaces that conversion only in the development diagnostic with raw return-shape evidence: overall runtime type/value, array type/rank/length, and each top-level item type/value.
- Aligns diagnostic ToolVersion and assembly/file metadata to `0.20.12`.
- Does not change the Cimatron call, face target, approved rays, production `src/**`, Plugin behavior, CR/SA logic, model data, or 07C-2.
- Validation: **AWAITING USER 0.20.12 QUALITY GATE + SAME THREE-RAY PIERCING RERUN**. Agent did not build/test/run Cimatron.

## 0.20.11 — 2026-09-30

### Step 07C-1R3 — Piercing-array compile corrective
- Records user-supplied 0.20.10 quality-gate failure: CS0411 at `GeometryServicesVerification.cs(131,25)` because the compiler could not infer `T` for `VerificationRuntimeContext.TryObserve<T>`.
- Adds only the explicit generic type `double[]` to that existing diagnostic observation call.
- Does not change the COM-array conversion logic, Cimatron call, face/ray inputs, production `src/**`, Plugin behavior, CR/SA logic, model data, or 07C-2.
- Validation: **AWAITING USER 0.20.11 PACKAGE QUALITY GATE + THREE-RAY PIERCING RERUN**. Agent did not build/test/run Cimatron.

## 0.20.10 — 2026-09-30

### Step 07C-1R3 — Piercing-array conversion corrective
- Implements only the user-approved 07C-1R3 diagnostic corrective after the final 0.20.9 live run returned `object[]` from `GetPiercingPoints` and the diagnostic attempted a direct `double[]` cast.
- Converts the returned one-dimensional numeric COM array safely to `double[]` before evidence formatting; no Cimatron geometry call, target, ray, or model behavior is changed.
- Removes the stale evidence-version literal by sourcing live evidence `ToolVersion` from the diagnostic's single `Program.ToolVersion` constant. Assembly/file version is aligned to `0.20.10`.
- Carries forward user evidence: UCS `251` behaves as the +30° Z UCS, UCS `249` as the 90° UCS candidate; `GetEntityPointDistance` returned `10` and `14.142135623730951` mm with bounded-face closest points; no-mutation evidence remained `UNCHANGED`.
- Production `src/**`, Plugin behavior, CR/SA logic, known-answer model data, and 07C-2 remain unchanged.
- Validation: **AWAITING USER 0.20.10 QUALITY GATE + THREE-RAY PIERCING RERUN**. Agent did not build/test/run Cimatron.

## 0.20.9 — 2026-09-29

### Step 07C-1R2 — Final Geometry Services resolution preparation
- Implements only the user-approved 07C-1R2 diagnostic preparation; production `src/**`, Plugin behavior, CR/SA logic, and 07C-2 remain unchanged.
- Extends the existing `--verify-geometry` mode to accept repeated ray pairs and repeated point inputs, allowing all three approved piercing cases and both approved entity-point-distance cases in one controlled invocation.
- When `--face-id` is supplied, `GetPiercingPoints` now targets the guarded face list (face 90 in the known-answer run) rather than the body list, which is necessary to test bounded-face and ray-vs-line semantics.
- Aligns absent `IGeomServices.SurfacesArea` runtime evidence with the established `NOT_AVAILABLE` classification.
- Records the workstation-only requirement to create `KA_UCS_30Z` at the same origin as UCS 2, rotated +30° about Z, and discover its actual entity ID before the final run.
- Validation: **AWAITING USER 0.20.9 QUALITY GATE + ROTATED-UCS DISCOVERY + FINAL LIVE GEOMETRY EVIDENCE**. Agent did not build/test/run Cimatron.

## 0.20.7 — 2026-09-29

### Step 07C-1R — Quality-gate build corrective
- Records user-supplied 0.20.6 quality-gate failure: CS1061 at `GeometryServicesVerification.cs(141,82)` because installed `CimBaseAPI.IFace` has no `Area` member; Release x64 build exited `1`.
- Removes only the invalid compile-time `IFace.Area()` call.
- Retains the existing conditional/reflected `IGeomServices.SurfacesArea` path for face-area evidence; absent/failing installed API is recorded as blocked/raw evidence rather than guessed.
- No production `src/**`, Plugin behavior, CR/SA logic, or 07C-2/3/4 work changed.
- Validation: **AWAITING USER 0.20.7 QUALITY GATE**. Agent did not build/test/run Cimatron.

## 0.20.6 — 2026-09-29

### Step 07C-1R — Remaining Geometry Services evidence resolution
- Carries forward user workstation 0.20.5 quality-gate PASS and live geometry evidence: body metrics, 25 mm minimum distance, convex edge 89, concave edge 95, and unchanged no-mutation evidence.
- Extends the existing `--verify-geometry` mode only; no new probe mode is added.
- Adds `--face-id` with a `cmFace` guard, face area evidence, face-only bounding boxes, and B1-face-list bounding boxes.
- Adds `--reference-ucs-id` so one geometry run can compare the same face/B1 faces under the rotated user UCS and a separately evidence-mapped main/reference UCS.
- `SurfacesArea` is invoked only if the installed `IGeomServices` Interop contract actually exposes that member; otherwise evidence records `BLOCKED` and records the installed-contract outcome explicitly.
- Adds explicit `NOT_TESTED` evidence for `GetPiercingPoints` and `GetEntityPointDistance` when their known-answer input arguments are absent.
- Preserves no-mutation evidence. The `[1,1,1,0,0,0]` body bounding-box observation remains unclassified pending face-list comparison.
- No production `src/**`, Plugin behavior, CR/SA logic, or 07C-2/3/4 work changed.
- Validation: **AWAITING USER 0.20.6 QUALITY GATE + LIVE 07C-1R EVIDENCE**.

## 0.20.5 — 2026-09-29

### Step 07C-1D — Geometry verification execution checkpoint
- Records user-run 0.20.4 quality gate PASS and the completed evidence-backed KA-PART-1 mapping: B1=4, B2=5, test face=90, convex edge=89, concave edge=95, KA_UCS_90Z=2, and 25 mm body-pair minimum distance.
- Adds the exact first `--verify-geometry` commands using only evidence-backed IDs.
- Leaves ray/through-hole/test-point values unresolved rather than guessing.
- Aligns development diagnostic version labels to 0.20.5; Geometry Services logic and production `src/**` are unchanged.
- 07C-2/3/4 remain blocked.
- Validation: **AWAITING USER 0.20.5 QUALITY GATE + LIVE GEOMETRY EVIDENCE**.

## 0.20.3 — 2026-09-29

### Step 07C-1A — Geometry known-answer target discovery
- Adds development-only `--discover-geometry-targets --expect Part` to establish actual KA-PART-1 body/face/edge/UCS identifiers before 07C-1 verification.
- Records per-body volume/centre/surface area, active-UCS bounding boxes, exact two-body minimum distance, face IDs, edge IDs/convexity, active/runtime-discoverable UCS candidates, and no-mutation evidence.
- Does not infer B1/B2/test-face/edge/UCS roles and does not hard-code or guess IDs.
- No production `src/**`, Plugin behavior, configuration or CR/SA logic changed. 07C-2/3/4 remain unexecuted.
- Validation: **AWAITING USER QUALITY GATE AND LIVE DISCOVERY EXECUTION**.

## 0.18.0 — 2026-09-28

### Step 06C1 — Mapping Contracts & Configuration
- Records Step 06B closure from user-supplied quality-gate and in-process Cimatron probe evidence.
- Adds `TabularFieldMappingDefinition` for logical field name, one-or-more configured source header candidates/aliases, approved `Text`/`Decimal` type, and required/optional metadata.
- Adds `TabularMappingDefinition` as a named, consumer-neutral mapping profile.
- Rejects blank/duplicate logical fields and ambiguous header candidates case-insensitively at configuration construction time.
- Adds focused Application contract tests for aliases, uniqueness and metadata preservation.
- No workbook-header matching engine, row-validation engine, CR-04/CR-22 business logic, Infrastructure reader behavior, dependency version, or Cimatron model/plugin behavior changed.
- Validation status: **AWAITING USER QUALITY GATE**.

## 0.17.5 — 2026-09-28

- Records user-run 0.17.4 full quality gate PASS: Release x64 build, all required test suites, coverage gate/local quality gate, exit code 0.
- Replaces the environment-variable child-process trigger with a one-shot `%TEMP%\CimatronCustomization\step06b-tabular-probe.request` file.
- `Start-Step06BTabularProbe.ps1` now prepares the request and evidence path only; it no longer launches `CimatronE.exe`.
- The operator starts Cimatron normally, and the Plugin consumes the fresh 0.17.5 request on the first command click. Normal Feature Launcher behavior is unchanged when no request exists.
- No architecture-rule, production-reader, dependency-version, CR-04/CR-22, or model-behavior change.
- Cimatron in-process compatibility remains NOT VERIFIED pending user-run 0.17.5 live evidence.

## 0.17.4 — 2026-09-28

- Corrected the Step 06B diagnostic probe packaging after the user-run 0.17.3 quality gate exposed the existing Plugin thin-boundary architecture rule.
- Moved `TabularReaderRuntimeProbe.cs` from the Plugin project top level to `Plugin/Diagnostics/`; no probe logic or production reader logic changed.
- Preserved the five approved top-level Plugin production source files exactly as required by `ArchitectureBoundaryTests`.
- Cimatron in-process compatibility remains NOT VERIFIED until the 0.17.4 quality gate passes and the opt-in live probe is executed.

## 0.17.3 — 2026-09-28

### Added
- Opt-in `TabularReaderRuntimeProbe` inside the existing Cimatron plugin process.
- `tools/Start-Step06BTabularProbe.ps1` for controlled launch with the known-answer BIFF8 fixture and evidence path.

### Evidence / scope
- User-run 0.17.2 quality gate: PASS, including all required suites, coverage gate, local quality gate, exit code 0.
- User-run filesystem preflight found `ExcelDataReader.dll` 3.9.0.0 and `System.ValueTuple.dll` in the Cimatron Program directory.
- Runtime compatibility remains NOT VERIFIED until the live in-process probe passes.
- Production reader logic, dependency versions, CR business logic, and normal plugin behavior are unchanged.

## 0.17.2 — 2026-09-28

### Fixed
- Replaced the synthetic BIFF2 legacy-XLS test generator with a deterministic static BIFF8/CDF `.xls` fixture containing named worksheet `Input`.
- The fixture preserves the same known-answer headers/data used by the `.xlsx` and CSV tests and is copied to the Infrastructure test output directory.
- Production `ExcelTabularDataReader` behavior is unchanged.

### Validation evidence
- User-run 0.17.1 Release x64 build succeeded; Infrastructure test executable then failed only at `ReadsLegacyBiff2Workbook` because the BIFF2 fixture could not satisfy named-sheet selection.
- 0.17.2 validation: **AWAITING USER EXECUTION**.

### Scope control
- No runtime dependency, production reader, supported-format, mapping, safety-limit, Cimatron API, or CR business-rule change.

## 0.17.1 — 2026-09-28

### Fixed
- Added the missing .NET Framework `System.Data` reference required by ExcelDataReader's `IDataReader` / `IDataRecord` API surface.
- Changed the private `ResolveColumns` header parameter to the concrete `string[]` produced by `ReadHeaders`, resolving the reported CA1859 warning without suppression.

### Validation evidence
- User-supplied 0.17.0 quality-gate capture: restore PASS; Release x64 build FAIL with 25 cascading Infrastructure compiler errors rooted in missing `System.Data`, plus one CA1859 warning.
- 0.17.1 validation: AWAITING USER EXECUTION.

### Scope control
- No change to ExcelDataReader 3.9.0 / System.ValueTuple 4.5.0 selection, tabular contracts, supported formats, row/file limits, Cimatron APIs, or business rules.

# Changelog

## 0.17.0 — 2026-09-28

### Step 06B — Tabular reader Infrastructure
- Records user-approved closure of 06A after a clean workstation quality gate.
- Adds approved pinned runtime dependencies ExcelDataReader 3.9.0 and System.ValueTuple 4.5.0; no Excel COM automation and no DataSet extension package.
- Adds `ExcelTabularDataReader` for `.xlsx`, `.xls`, and `.csv`, preserving configuration-driven worksheet/header/column mapping.
- Adds shared-read access, 25 MiB / 100,000-row safety limits, stable actionable errors and all-or-nothing results.
- Adds Infrastructure reader tests including generated XLSX and legacy BIFF2 XLS fixtures plus CSV and negative cases.
- Adds `Test-TabularDependencyPreflight.ps1` and documents client-package/runtime binding impact.
- Cimatron in-process compatibility is NOT VERIFIED and must not be treated as PASS until user-supplied live evidence exists.
- Validation: **AWAITING USER EXECUTION**.

## 0.16.0 — 2026-09-28

### Step 06A — Tabular input requirement and Application contract
- Establishes WP8 consumers as CR-04 (steel grade vs DO Input Sheet) and CR-22 (finger-pin diameter vs slider-weight table).
- Adds `ITabularDataReader` and dependency-neutral Application models for configuration-driven worksheet/header/column mapping and typed tabular rows.
- Adds all-or-nothing `TabularReadResult`; errors require an actionable code and message and never contain a partial table.
- Limits 06A value types to `Text` and `Decimal`; workbook-specific behavior remains intentionally undecided until Step 06B/customer evidence.
- Adds requirement-derived temporary CSV fixtures under `tests/TestData/Step06/`; these are not customer layouts.
- Adds Application contract tests and registers them in the existing test harness.
- No Excel/NuGet dependency, Infrastructure reader, CR-04/CR-22 rule logic, or Cimatron runtime behavior is added.
- Validation: **AWAITING USER EXECUTION**. The AI agent did not run build/tests/coverage/Cimatron.

## 0.15.36 — 2026-09-27

### Step 05C2-B closure with documented hidden-state exception
- Records user validation of 0.15.35: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.
- Records the approved final `--probe-occurrence-interfaces` runtime evidence: 528 unique Interop COM IIDs queried once per known-answer occurrence with immediate pointer release; visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B` exposed identical interface sets; no-mutation evidence remained `UNCHANGED`.
- Records the single supported interface missed by the prior visibility-name search as `IEntityQuery`. Its reflection-only members are `CreateFilter`, `GetFilter`, `Select`, and `SetFilter`; no hidden/visibility getter exists and no newly discovered member was invoked.
- Applies the pre-approved stopping rule: end reflection-based hidden-state discovery. FR-021 is recorded as `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance`.
- Closes Step 05C2-B with the documented FR-021 hidden-state exception. Any suppressed-only initial shipping decision remains an explicit client/product scope decision.
- Corrects only the development-diagnostic version label/banner from stale 0.15.34 to 0.15.36; no COM probing logic, production `src/`, Assembly Pick, or production Zoom-to-result behavior changes.


### 0.15.35 Step 05C2-B — Diagnostic CA1859 warning-only correction
- Records user-run 0.15.34 quality-gate result: Release x64 build PASS; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0; three CA1859 analyzer warnings in `OccurrenceComInterfaceInventory.cs`.
- Changes only the flagged diagnostic collection property declarations: `Aliases` and `ReflectedMembers` from `IList<T>` to `List<T>`, and `Support` from `IDictionary<Guid,T>` to `Dictionary<Guid,T>`.
- No runtime logic, COM probing semantics, member invocation, stop rule, production `src/`, Assembly Pick, or production Zoom-to-result change.
- Validation status: **AWAITING USER EXECUTION**.

## 0.15.34 — 2026-09-27

### Step 05C2-B final occurrence COM-interface diagnostic
- Records user validation of 0.15.33: full quality gate PASS with Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.
- Records the 0.15.33 reflection-only result: no genuinely new occurrence-level visibility getter was found. The five occurrence-context getter entries reduce to `IgnoreInShowOperations` aliases already shown non-discriminating plus the closed `_IAssInstance.get_Show_()` route; visibility attributes remain metadata only.
- Adds development-only `--probe-occurrence-interfaces`. It enumerates COM interface IIDs from installed `interop.Cim*.dll` files, deduplicates runtime probes by IID, queries each IID once per known-answer occurrence with `Marshal.QueryInterface`, and immediately releases every successful interface pointer.
- Targets exactly visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`; captures `IProvideClassInfo` / `IDispatch.GetTypeInfo` class evidence where supported; emits an interface × object matrix.
- Any supported interface missed by the previous visibility-name search is reflected for member access classification only. No newly discovered member is invoked.
- Expected outcome is explicitly identical interface sets. Stop rule is explicit: if no new supported interface/member path results, end reflection-based hidden-state discovery, record FR-021 as `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance`, and propose closing 05C2-B with that documented exception.
- Suppressed-only initial shipping, if necessary, is explicitly a client/product scope decision and is not decided by the diagnostic.
- Production `src/`, Assembly Pick, production Zoom-to-result, and model/view/selection mutation behavior remain unchanged.
- Validation: awaiting user-run full quality gate; after PASS run `--probe-occurrence-interfaces` on the approved known-answer copy.

## 0.15.33 — 2026-09-27

### Step 05C2-B architecture guard evidence-marker correction
- Recorded the user-run 0.15.32 quality-gate result: Release x64 build PASS with 0 warnings / 0 errors, followed by Architecture Tests FAIL and overall exit code 1.
- Root cause is a static architecture contract mismatch: `InteropReflectionInventory.cs` omitted four explicit legacy `_IAssInstance` cast-evidence marker strings required by `ZoomDiscoveryToolMustRemainReadOnlyAndDevelopmentOnly`.
- Restored only `CurrentCastTarget`, `CurrentCastMechanism`, `CurrentCastExceptionType`, and `CurrentCastHRESULT` output markers. These document the already-closed historical cast route and do not reopen or invoke `_IAssInstance.get_Show_()`.
- No production `src/`, Assembly Pick, production Zoom-to-result, or live diagnostic semantics changed.
- Validation: awaiting user-run full quality gate.



## 0.15.32 — 2026-09-27

### Step 05C2-B diagnostic-only visibility reflection narrowing
- Recorded user validation of the 0.15.30 full quality gate: Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage/local quality gates PASS; exit code 0.
- Recorded the 0.15.30 live known-answer result: visible `Block_A`, suppressed `Block_B`, and hidden-not-suppressed `Known_Pocket_Body` all returned `IgnoreInShowOperations=0` with occurrence `cmAttVisibility` and `cmAttBlankLevel` absent, so those candidates are non-discriminating for FR-021.
- Kept `_IAssInstance.get_Show_()` closed based on the user-validated 0.15.29 `InvalidCastException / 0x80004002 (E_NOINTERFACE)` evidence.
- Extended only `InteropReflectionInventory` to identify read-only visibility/display getter metadata on occurrence/component-context interfaces. No newly discovered member is invoked.
- Production `src/`, Assembly Pick, production Zoom-to-result, tests, and mutating Cimatron behavior remain unchanged.
- Validation: awaiting user-run full quality gate, then `--reflect-visibility-api`.


## 0.15.31 — 2026-09-27

### Documentation / handoff
- Added a current Step 05C2-B new-session checkpoint and continuation prompt to `docs/history/session-handoffs/phase-02-step-05c2-handoff.md`.
- Captures that 0.15.29 is quality-gate validated, `_IAssInstance` / `Show_` is closed by live `E_NOINTERFACE` evidence, and 0.15.30 compatible-`IAssInstance` candidate comparison is still awaiting workstation validation.
- No source, tests, runtime behavior, Cimatron API behavior, or production behavior changed.

## 0.15.30 — Step 05C2-B compatible IAssInstance visibility-candidate comparison

- Records user validation of 0.15.29: full quality gate PASS with Release x64 build 0 warnings / 0 errors, all required test suites PASS, coverage/local quality gates PASS, and exit code 0.
- Records the live 0.15.29 known-answer diagnostic: 9 occurrences / 18 entity inspections / no limits / no mutation; explicit `_IAssInstance` compatibility failed for every occurrence with `InvalidCastException` / `0x80004002 (E_NOINTERFACE)`, closing the `Show_` route for the runtime objects supplied by Cimatron.
- Replaces the failed `_IAssInstance.get_Show_()` experiment with read-only signals available on the already-compatible `IAssInstance`: getter-only `IgnoreInShowOperations` plus occurrence-level `GetAttribute(cmAttVisibility, string.Empty)` and `GetAttribute(cmAttBlankLevel, string.Empty)`.
- Candidate reads record raw present/absent/value/error evidence independently for each occurrence; no visibility semantics are assigned in advance and per-candidate read failures do not abort the remaining comparison.
- No setter, Show/Hide mutation, component open/load/activation, production `src/`, Assembly Pick, or production Zoom-to-result change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.29 — Step 05C2-B architecture assertion correction

- Records user-run 0.15.28 quality-gate evidence: Release x64 build PASS with 0 warnings / 0 errors; Architecture Tests FAIL; overall exit code 1.
- Direct ArchitectureTests execution identified the stale guard literal `HiddenStateDetection: UNRESOLVED`.
- Updates only that guard to require the approved runtime-probe state `HiddenStateDetection: RUNTIME PROBE PENDING`.
- No diagnostic runtime behavior, Cimatron API usage, production `src/`, Assembly Pick, or production Zoom-to-result change.

## 0.15.28 — Step 05C2-B getter-only occurrence visibility runtime probe

- Records user validation of 0.15.27: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage/local quality gates PASS; reflection diagnostic exit code 0.
- Reflection evidence proves exactly one installed `interop.CimMdlrAPI._IAssInstance` copy (GUID `4C8A5941-F526-11D5-B89D-006008719C4A`) and classifies `get_Show_()` as a read-only getter candidate while `set_Show_()` is mutating.
- Replaces the prior silent `as` cast with an explicit `_IAssInstance` compatibility cast that records exact exception type and HRESULT on failure.
- Calls only the getter when compatibility succeeds; the setter remains prohibited/not called. Returned values are evidence only until compared against known visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`.
- Keeps `cmAttVisibility` / `cmAttBlankLevel` as body/entity candidates only; no occurrence semantics are claimed.
- Production `src/`, Assembly Pick and production Zoom-to-result remain unchanged.

## 0.15.27
- Corrects the 0.15.26 development-only visibility reflection diagnostic compile failure (`CS0136`) by renaming the conflicting local variable to `guidValue`.
- No reflection behavior, Cimatron API usage, or production `src/` changes.
- User must rerun the quality gate elevated because the prior non-elevated run also hit Program Files deployment access-denied errors.

## 0.15.26 — 2026-09-27

### Step 05C2-B — Hidden occurrence-state reflection discovery
- Records successful user validation of 0.15.25: clean local quality gate, diagnostic exit code 0, 9 occurrences, 0 revisits, both `Block_A` placements at distinct occurrence paths/known offsets, suppressed `Block_B`, real `MbPocket=1`, and no mutation.
- Adds reflection-only `--reflect-visibility-api` for the remaining CR-11 FR-021 hidden-but-not-suppressed occurrence dependency.
- Searches `Show`, `Visible`, `Visibility`, `Hidden`, `Hide`, `Blank`, `Display`, and `State`; inventories every installed `_IAssInstance` copy and classifies matching members as getter/setter/accessor/method without invoking them.
- Records current cast target `interop.CimMdlrAPI._IAssInstance` and the exact observed failure semantics: the C# `as` cast returned null, so no exception/HRESULT exists in current evidence.
- Inventories `cmAttVisibility` / `cmAttBlankLevel` as body/entity visibility candidates only; occurrence semantics remain unproven.
- Discovery only: no newly discovered member invocation, no new live Cimatron API call, and no production `src/` change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.25 — 2026-09-27

### Step 05C2-B — Repeated-occurrence identity / definition-cycle correction
- Records the user-validated known-answer Assembly: real Mold Pocket `MbPocket(cmAttInteger)=1`, suppressed `Block_B`, nested transforms, no-mutation evidence `UNCHANGED`, and diagnostic exit code 0.
- Fixes the known-answer defect where Cimatron showed `Block_A(2)` but the diagnostic emitted only one placement and counted one revisit because positive `InstanceId` was treated as globally unique.
- Makes the full occurrence path, including sibling ordinal, the diagnostic occurrence identity; `InstanceId` is evidence only.
- Replaces global ID deduplication with ancestry-only Assembly definition cycle protection keyed by already-approved `IModel.PID`; missing PID relies on the existing depth/occurrence limits and is recorded as a limitation.
- Records that recursive self-assembly cycle protection is not exercised by live Cimatron validation.
- Keeps hidden-state detection unresolved and separate. No new Cimatron API and no production `src/` change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.24 — 2026-09-27

### Step 05C2-B — Separate occurrence/entity budgets and evidence completeness
- Records user validation of 0.15.23: clean quality gate and successful real-mold read-only traversal with 80 occurrences, 490 body checks, nested recursion, suppression detection, unchanged file evidence, and `MbCooling=1` through occurrence `root:-1/8/137`.
- Replaces the shared 2000-item guard with independent 2000-occurrence and 2000-entity-inspection budgets. Entity-budget exhaustion no longer terminates occurrence recursion.
- Adds explicit per-occurrence entity-inspection status so skipped/partial inspection cannot be misread as absence of `MbPocket`/`MbCooling`.
- Adds read-only `--assembly-entities --occurrence-only` and total-runtime evidence.
- Records open acceptance items: `MbPocket` via occurrence unproven; hidden-state detection unresolved (CR-11 FR-021); known-answer small-assembly validation still required.
- No new Cimatron API and no production `src/` change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.23 — 2026-09-26

### Step 05C2-B — Root parent runtime correction
- Records the user-run 0.15.22 quality gate as clean: Release x64 PASS, 0 warnings / 0 errors, required tests PASS, coverage/local quality gates PASS, exit code 0.
- Records the first 0.15.22 controlled Assembly runtime: attach, active Assembly resolution, model/root acquisition and root ID read succeeded; root ID was `-1`; `IAssInstance.get_AssParentInstance` on that root returned COM `E_FAIL` (`0x80004005`).
- Root pseudo-instance traversal now skips `get_AssParentInstance` and records `ParentId` as `ROOT/N/A`; non-root parent traversal remains unchanged.
- Full occurrence path remains the cycle/revisit fallback whenever an occurrence ID is non-positive.
- Architecture guard now protects the root-parent special case. No new Cimatron API, production `src/`, traversal limits, watchdog, or no-mutation behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.22 — 2026-09-26

### Step 05C2-B — Checkpoint guard correction and analyzer cleanup
- Corrected the Step 05C2 architecture guard so it validates the approved 0.15.21 controlled traversal calls and the common `RunApiCall` BEGIN/call/END checkpoint ordering instead of requiring removed exploratory `GetInstances` / `Select` / `GetFaces` checkpoint text.
- Retained the existing runtime `RunApiCall` checkpoint behavior; no Cimatron API or traversal semantics were added or changed.
- Corrected two CA1834 analyzer warnings in `AssemblyEntityInventory.FormatObject` by using `StringBuilder.Append(char)` for comma and closing-bracket characters.
- Production `src/` remains unchanged.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.21 — 2026-09-26

- Implements Step 05C2-B controlled read-only Assembly occurrence/entity diagnostics from the user-approved installed-Interop allow-list.
- Removes the diagnostic's older exploratory `GetInstances/CreateFilter/SetFilter/Select/GetFaces` traversal path.
- Adds per-Cimatron-call 15-second watchdog/exit code 7, depth/item/revisit guards, exception type + HRESULT evidence, occurrence parent/root/suppression/show/transform evidence, occurrence-reached body enumeration, and `MbPocket` / `MbCooling` read-only `cmAttInteger` checks.
- Adds before/after active-document modified-state and file timestamp/length evidence; changed/unverifiable no-mutation evidence returns exit code 8.
- Architecture tests enforce the approved allow-list and prohibit component open/load/activation, save/suppress/set/attribute mutation and transformation mutation calls in the diagnostic.
- No production `src/`, Assembly Pick, Highlight, or production Zoom-to-result behavior changes.
- Validation status: **AWAITING USER EXECUTION**.

## 0.15.20 — 2026-09-26

- Corrects the single CA1859 warning reported by the user-run 0.15.19 quality gate in the development-only Assembly API reflection inventory.
- Changes `EnumerateDeclaredMembers(Type)` from `IEnumerable<MemberInfo>` to `MemberInfo[]`, matching `Type.GetMembers(...)`; no reflection logic or runtime Cimatron behavior changes.
- Advances diagnostic/version stamps to 0.15.20.
- No production `src/`, Assembly Pick, Assembly traversal, Highlight, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**; require 0 warnings / 0 errors before the reflection inventory run.

## 0.15.19 — 2026-09-26

- Adds Step 05C2-A development-only `--reflect-assembly-api` to inventory the installed Cimatron 2026 Interop assembly surface before any new Assembly traversal call is approved.
- Uses `Assembly.ReflectionOnlyLoadFrom` only; no Cimatron process attach, document access, traversal, selection, command execution, load/activate/save, or model mutation is performed by this mode.
- Scans inherited/base COM interfaces with `GetInterfaces()` and records exact method/property/member signatures and declaring interfaces for Assembly/instance/occurrence/component/model/body/face/entity/transform/attribute/visibility/suppression/document/modified-state candidates.
- Adds architecture protection requiring the new inventory to remain reflection-only and base-interface-aware.
- Records user validation of 0.15.18: quality gate PASS with 0 warnings / 0 errors; non-admin MTA attach PASS / exit 0; deliberate elevation mismatch failed fast with exit 6.
- No production `src/`, Assembly Pick, Assembly traversal, Highlight, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.18 — 2026-09-26

- Hardens the Step 05C2 development-only attach diagnostic after workstation evidence isolated the `GetApplication()` timeout to a privilege mismatch: CimatronE was non-elevated while the failing discovery runs were launched from Administrator PowerShell.
- Records user validation: 0.15.17 quality gate PASS, corrected `trace-selftest` task PASS, elevated STA/MTA attach-only runs TIMEOUT/5, non-elevated `Cr11RuntimeProbe` PASS on active `cmAssembly`, and non-elevated Discovery MTA attach-only PASS/0.
- Replaces broad process-name matching with exact `CimatronE.exe` inventory and records PID, Windows Session ID and elevation. A confirmed Cimatron/tool elevation mismatch now fails fast before `GetApplication()` with exit code `6`.
- Corrects COM reflection evidence by scanning inherited interfaces (`GetInterfaces()`) for the parameterless `GetApplication()` method.
- No production `src/`, Assembly Pick, Highlight, Assembly traversal, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.17 — 2026-09-26

- Adds development-only `--attach-only --apartment=STA|MTA` to isolate the confirmed `AppAccess.GetApplication()` hang without entering Assembly traversal.
- Runs the attach on a background worker explicitly configured to STA or MTA; the controller records a 30-second timeout and returns exit code `5` without force-aborting the COM call.
- Records the parameterless `GetApplication()` reflection signature, Cimatron process count/PID/Windows Session ID, and run-precondition evidence/reminders.
- Records user validation of 0.15.16: full local quality gate PASS, trace self-test PASS, and `assembly-entities` heartbeat proving the process stayed alive while blocked after `AppAccess` creation and before `GetApplication()` returned.
- Corrects the missed 0.15.16 condition by adding `trace-selftest` to `Invoke-And-Capture.ps1`; architecture coverage now guards the named task and attach-only diagnostic boundary.
- No production `src/`, Assembly Pick, Highlight, Assembly traversal, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.16 — 2026-09-26

- Adds development-only durable startup/dispatch tracing for Step 05C2 under `%LOCALAPPDATA%\CimatronCustomization\diagnostics\`, using timestamp+PID filenames and write-through/flush/close for every record.
- Adds `--trace-selftest` with no Cimatron API calls, startup environment evidence (PID, command line, elevation, apartment state), and a background heartbeat recording the last persisted checkpoint.
- Mirrors existing `assembly-entities` checkpoints to the durable file before console output.
- Preserves the existing `[STAThread]` configuration; no apartment-state behavior is changed.
- Adds architecture enforcement for diagnostic isolation and durable-trace requirements.
- No new Cimatron API calls; no production `src/`, Assembly Pick, Highlight, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.15 — 2026-09-26

### Step 05C2 — Session handoff package
- Adds the canonical Step 05C2 session handoff under `docs/history/session-handoffs/phase-02-step-05c2-handoff.md`.
- Captures approved scope, completed work, current validation evidence, unresolved Assembly diagnostic hang, 0.15.14 checkpoint plan, exact next steps, and required read order for a new session.
- No production source, diagnostic runtime behavior, or Cimatron behavior changed.
- Validation: **DOCUMENTATION-ONLY / AWAITING USER EXECUTION**.

## 0.15.14 — 2026-09-26

### Step 05C2 — Assembly entity diagnostic checkpoints
- Records user-supplied 0.15.13 local quality-gate PASS with 0 warnings / 0 errors and successful console-capture output.
- Records that the first `assembly-entities` runtime probe produced no diagnostic output and had to be stopped manually; the exact blocking API call is therefore not yet identified.
- Adds timestamped, immediately flushed checkpoints before/after the read-only Assembly inventory COM calls so the next capture identifies the last completed call.
- Adds an architecture guard for the checkpoint instrumentation.
- No production source or Cimatron production behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.13 — 2026-09-26

### Step 05C2 — PowerShell 5.1 console capture compatibility fix
- User-run 0.15.12 helper failed with `Parameter set cannot be resolved using the specified named parameters` before the child task executed.
- Replaced `Tee-Object -LiteralPath ... -Append` with explicit per-line console output plus `Add-Content`, compatible with Windows PowerShell 5.1.
- Preserves named tasks, stdout/stderr capture, live console display, timestamped files and child exit-code propagation.
- No production code or Cimatron runtime behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.12 — 2026-09-26

### Step 05C2 — Named-task console capture fix
- Replaces the 0.15.11 `-Name` + mandatory `-Command` script-block interface with a `-Task` interface compatible with `powershell -ExecutionPolicy Bypass -File`.
- Adds fixed tasks `quality-gate` and `assembly-entities`, while preserving live console display, timestamped text capture, stderr/stdout capture and exit-code propagation.
- No production code or Cimatron runtime behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.11 — 2026-09-26

### Step 05C2 — Console capture helper
- Adds developer-only `tools/Invoke-And-Capture.ps1` to tee long console output into timestamped text files under `artifacts/console-captures/` while still displaying it in PowerShell.
- Captures stdout/error streams, records the supplied command and execution context, preserves the command exit code, and prints the final capture path for easy upload to the agent.
- No production code, Cimatron runtime behavior, Zoom diagnostic behavior, Pick, Highlight, or model/view logic changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.10 — 2026-09-26

### Step 05C2 — Read-only Assembly entity discovery
- Records user-supplied 0.15.9 quality-gate PASS with 0 warnings / 0 errors and the live Part `&Display,Zoom Selection` visual PASS.
- Adds development-only `--assembly-entities` to enumerate candidate Body/Face entity IDs from Part instances in the active Assembly, together with instance path/ID and model PID/title.
- Uses only the already-established read-only assembly/model inspection path (`GetInstances`, entity query/filter/select, `IBody.GetFaces`).
- Executes no native Cimatron command and does not alter selection, Pick, model geometry, or viewport state.
- Production Assembly Pick remains unsupported and unchanged.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.8 — 2026-09-26

## 0.15.9 — 2026-09-26

### Step 05C2 — Controlled native Zoom Selection validation
- Records user-supplied 0.15.8 quality-gate PASS with 0 warnings / 0 errors and successful Part/Assembly command inventory evidence.
- Adds a development-only validation mode that temporarily selects one explicit active-model entity and executes only the discovered `&Display,Zoom Selection` command.
- Restores the prior selection after the command returns and writes a diagnostic evidence file.
- Adds architecture guards limiting the diagnostic to the exact approved command and keeping the tool outside production dependencies.
- No production Zoom-to-result behavior is implemented.
- Validation: **AWAITING USER EXECUTION**.


### Step 05C1 — Microsoft.CSharp binder dependency correction
- User-run 0.15.7 Release x64 build failed with `CS0656` because the standalone ZoomCommandDiscovery project did not reference `Microsoft.CSharp`.
- Added `<Reference Include="Microsoft.CSharp" />` to `CimatronCustomization.ZoomCommandDiscovery.csproj`.
- No production code or diagnostic behavior changed; the tool remains read-only and development-only.
- Validation: **PASS** from user-supplied 0.15.8 local quality-gate output (0 warnings / 0 errors; all reported tests/coverage gates PASS).

## 0.15.7 — 2026-09-26

### Step 05C1 — Dedicated read-only Zoom/View discovery tool
- Replaced the 0.15.6 test-executable discovery hook with a dedicated x64 tool under `tools/CimatronCustomization.ZoomCommandDiscovery`.
- Embedded the official-style Cimatron side-by-side manifest and configured Release/Debug x64 output to the Cimatron 2026 Program folder for standalone dependency resolution.
- Added reflection-only installed-Interop inventory for `Zoom`, `Fit`, `View`, `Frame`, and `Camera` interface members.
- Added full read-only `GetCommandsNames()` dumps with Part/Assembly context headers and filtered console candidates.
- Defined exit codes 0/1/2/3/4 and evidence output under `artifacts/diagnostics`.
- Added architecture guards proving no production project references the tool and preventing command execution or selection/view/model mutation in the diagnostic.
- Removed obsolete zoom-discovery/filter sources from the CimatronIntegration test project.
- Repository review does not support the suggested `Microsoft.NET.Test.Sdk` generated-entry-point root cause for 0.15.6; exact silent-invocation mechanism remains unproven without workstation `obj/` artifacts.
- No production Plugin/Application/CimatronIntegration/Domain/DesignChecks behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.6 — 2026-09-26

### Step 05C1 — Analyzer warning cleanup
- User-run 0.15.5 Release build/tests/coverage/local quality gate passed, but the build emitted two `CA1861` warnings in `ZoomCommandCandidateFilterTests.cs`.
- Replaced the two inline constant command arrays with `static readonly` test fixtures.
- No production code or native command-discovery behavior changed.
- Workstation validation for 0.15.6 remains **AWAITING USER EXECUTION**.

## 0.15.5 — 2026-09-26

### Step 05C1 — Native Zoom Command Discovery
- Added a development-only `--discover-zoom-commands` mode to the CimatronIntegration test executable.
- Discovery uses documented PoolCommands inventory APIs and does not execute candidate commands.
- Added candidate-filter regression tests and Step 05C1 API-discovery documentation.
- No production runtime behavior changed.
- Workstation build/test/runtime evidence remains **AWAITING USER EXECUTION**.

# Changelog

## 0.15.4 — CLOSED / VERIFIED — 2026-09-26

### Step 05B2 closure
- User-run Release x64 build: **PASS**, **0 warnings / 0 errors**.
- Architecture, Domain, Application, CimatronIntegration and Infrastructure tests: **PASS**.
- Coverage collection/gate and local quality gate: **PASS**.
- Coverage: Domain **100%**; Application **95.75%**; DesignChecks **100%**; Infrastructure **98.48%**; CimatronIntegration **4.57% measured** (no Step 05B2 threshold).
- Live same-document idle Pick: **PASS**; no false `SOURCE_DOCUMENT_CLOSED`.
- Live second request while Pick active: **PASS** with `Busy / PICK_ALREADY_ACTIVE`.
- Live Esc cancellation after Busy: **PASS** with `Cancelled / ESC`.
- Repeat Pick after Esc and normal entity selection: **PASS**.
- Live real source-document close: **PASS** with `Cancelled / SOURCE_DOCUMENT_CLOSED`; launcher restored safely and no crash observed.
- Normal document-switch cancellation remains previously live-verified and its path was preserved by 0.15.4.
- Exactly-once/no-duplicate behavior was explicitly live-verified in 0.15.3 and unchanged in 0.15.4; the final 0.15.4 close-dialog dismissal was not separately reported.
- A 0.15.4 `ViewportPickCompleted` log line was not separately supplied in chat and is recorded as an evidence limitation rather than inferred.
- Step 05B2 — Production Pick Integration is formally **CLOSED / VERIFIED** by user approval.
- Added closure/new-session handoff `docs/history/session-handoffs/phase-02-step-05b2-to-step-05c-session-handoff-0.15.4.md`.

## 0.15.4 — 2026-09-26

### Fixed
- Replaced the 0.15.3 source-document watchdog's managed COM-wrapper token comparison with stable source Part model-PID/document-type comparison on the captured Cimatron STA/UI context.
- Prevents false `SOURCE_DOCUMENT_CLOSED` cancellation when repeated `GetActiveDoc()` calls represent the same still-open Part through a different managed COM wrapper.
- Preserves the four-probe confirmation window so a normal active-document switch can complete first through the already verified `OnToolPoped` path; exactly-once completion and late-callback suppression are unchanged.

### Tests
- Added regression coverage showing the same source model PID remains current across wrapper-identity changes and does not accumulate source-loss observations.
- Added negative lifecycle-identity coverage for a different active Part model and no active model.

### Validation
- User-run 0.15.3 local quality gate: PASS with 0 warnings / 0 errors; all listed test projects, coverage collection/gate, and local quality gate PASS.
- 0.15.3 live close-document result: intended `Cancelled / SOURCE_DOCUMENT_CLOSED` appeared once and no duplicate popup followed, but subsequent Pick starts exposed the false-cancellation regression fixed here.
- This implementation was subsequently user-validated and Step 05B2 closure is recorded in the closure section above.

## 0.15.3 — 2026-09-26

### Fixed
- Added source-document lifecycle monitoring for an active production Part Pick. If the source token remains non-current for four consecutive 250 ms UI-thread probes and the normal Cimatron tool-pop path has not already completed the request, the Pick completes as `Cancelled` with reason `SOURCE_DOCUMENT_CLOSED`.
- Added an exactly-once `TryComplete` session gate so lifecycle completion releases the strong PickTool reference and any late COM completion is ignored instead of reaching the caller twice.
- Source-document-close completion does not call `PopTool` against a document that has already disappeared; it completes the managed PickTool directly and preserves the existing result/log callback path.

### Tests
- Added pure lifecycle-state regression coverage for first/duplicate completion, persistent source-document mismatch confirmation, and reset when the source becomes current again.

### Scope / validation
- No Application contract/outcome change. No Plugin UI change. No Step 05A Highlight change. Assembly/occurrence Pick, NC Pick, multi-select and Zoom remain deferred.
- Previous 0.15.2 user evidence remains historical only. Version 0.15.3 is **AWAITING USER EXECUTION** for Release x64 build, all tests, coverage/local quality gate, and live Cimatron validation.

## 0.15.2 — 2026-09-26

### Added
- Application-owned production Pick contract: `IViewportEntityPicker`, `ViewportPickRequest`, `ViewportPickResult`, `ViewportPickOutcome`, `ViewportEntityType`, and `ViewportDocumentIdentity`.
- Exact Pick outcomes: `Picked`, `Cancelled`, `Unsupported`, `Failed`, `Busy`, `StaleResult`.
- Assembly-ready result shape with source-document token, entity type and optional occurrence path while 0.15.2 runtime support remains Part-only.
- Session document identity registry and current-document stale-result validation.
- Caller-initiated cancellation through `CancellationToken`, marshalled to the captured Cimatron UI synchronization context.
- Cimatron entity-type filter mapping for Body, Face and Edge using the verified `cmFilterEntityType` / `FilterType.Add(...)` boundary.
- Pure CimatronIntegration lifecycle/token tests and Application contract tests.
- CimatronIntegration coverage collection/reporting with no silent production-member exclusions.

### Changed
- Replaced the diagnostic `CimatronPartPickSpike` / `CimatronDiagnosticPickTool` Release path with `CimatronViewportEntityPicker` / `CimatronViewportPickTool`.
- Feature Launcher action is now `Pick Entity (Part)` and consumes only the Application Pick port.
- Preserved the verified modeless launcher, owned TopMost result dialog, foreground recovery and explicit focus-return behavior from 0.15.1.
- A second Pick request returns `Busy` without cancelling the first.
- Entity IDs are explicitly scoped to the source document token and current Cimatron session; stale results are rejected before reuse.

### Scope / deferred
- Part single-select only in 0.15.2. Assembly/sub-assembly/component occurrence Pick, NC Pick and multi-select remain deferred.
- Occurrence path is intentionally empty for Part results.
- Zoom remains Unsupported and is tracked for CR-11 FR-014. Multi-select remains deferred for CR-11 FR-003/FR-004.
- Step 05A Highlight behavior is unchanged.
- Cimatron exit during an active Pick is a live case only if safe; if not exercised it must be recorded as `NOT TESTED`, never PASS.

### Coverage policy
- No coverage exclusions were added.
- `CimatronCustomization.CimatronIntegration` is now included in coverage collection and printed as a measured informational package. No new percentage threshold was approved for the API adapter in this increment.

### Validation
- First user-run local quality gate: Release x64 build **PASS**; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests **PASS**; coverage collection/gate and local quality gate **PASS**; **0 errors / 7 warnings**.
- The seven warnings were confined to `ViewportPickContractTests.cs`: six `CA1806` warnings from intentionally constructed exception-test objects and one `CA1861` warning from a constant occurrence-path array argument.
- Warning-only correction consumes the constructed instances through the test helper and reuses a `static readonly` occurrence-path fixture. No production behavior changed.
- Warning-corrected package user re-execution: Release x64 **PASS**, **0 warnings / 0 errors**; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests **PASS**; coverage collection/gate and local quality gate **PASS**.
- Measured coverage: Domain **100%**; Application **95.75%**; DesignChecks **100%**; Infrastructure **98.48%**; CimatronIntegration **3.44% measured** (no threshold introduced in Step 05B2).

### Live validation in progress
- Normal Part Pick: **PASS**; production result returned entity ID, entity type, source-document token/metadata, reason code and correlation id.
- Esc cancellation: **PASS**.
- Repeat Pick immediately after Esc: **PASS**.
- Active-document switch during Pick: **PASS** with controlled `Cancelled` / `CIMATRON_TOOL_POPPED`.
- `Busy` live case: **NOT TESTED THROUGH CURRENT UI** because the launcher is intentionally hidden while Pick is active; automated state coverage remains the evidence for this path.
- Active source-document close during Pick: **FAIL / INCOMPLETE**. The document closes but no result dialog is produced and no corresponding `ViewportPickCompleted` log entry was observed.
- Step 05B2 remains OPEN. A document-close lifecycle correction is proposed but requires explicit approval before production code changes.
- Added session handoff `docs/history/session-handoffs/phase-02-step-05b2-document-close-defect-session-handoff-0.15.2.md`.


## 0.15.1 — CLOSED / VERIFIED — 2026-09-26

### Closure
- Step 05B1 — Part-only Pick Spike is formally **CLOSED / VERIFIED** from user-supplied workstation and live Cimatron evidence.
- Final user-run Release x64 build: **PASS**, **0 warnings / 0 errors**.
- Architecture, Domain, Application and Infrastructure tests: **PASS**.
- Coverage collection, coverage gate and local quality gate: **PASS**.
- Coverage: Domain **100%**; Application **95.41%**; DesignChecks **100%**; Infrastructure **98.48%**.
- Live Part pick success: **PASS**.
- Live Esc cancellation and tool cleanup: **PASS**.
- Dedicated Pick result-dialog reachability across window toggles: **PASS**.
- Feature Launcher foreground restoration after returning to Cimatron: **PASS**.
- Post-result focus return to Cimatron/Feature Launcher: **PASS**.
- Active-document switching during Pick: **PASS**.
- Direct managed-object PickTool activation without COM registration: **PASS**.

### Deferred / next increment
- 0.15.1 remains a diagnostic/foundation Part-only spike; it does not promote Pick into the production Result Report flow.
- Persistent post-pick highlight is deferred.
- Assembly/NC Pick remain Unsupported.
- Zoom remains Unsupported.
- Step 05B2 will plan the proper Application-owned Pick contract/result model and UI integration using only the live-verified 0.15.1 behavior. Implementation requires separate explicit approval.


## 0.15.1

### Added
- Part-only diagnostic PickTool spike using the installed Cimatron 2026 `IToolContainer.PushPickTool` contract.
- `CIMATRON-2026-PICK-TOOL-VERIFICATION.md` recording the exact installed Interop signatures supplied from the workstation before implementation.
- `Pick Spike (Part)` launcher action with a **strongly retained modeless Feature Launcher**. The launcher can hide during the asynchronous Cimatron pick without terminating its window lifetime and is restored on completion/cancellation.
- Bounded event tracing and current-session picked entity-ID diagnostics.
- Architecture guard allowing exactly one `[ComVisible(true)]` class in CimatronIntegration with a fixed GUID while the assembly remains `ComVisible(false)`.

### Scope / limitations
- No COM registration, RegAsm, registry change, installer change, or CLSID activation is introduced; live validation must prove whether direct managed-object handoff is accepted by Cimatron.
- Pick is intentionally limited to active Part documents and a face filter. Assembly/NC Pick remain Unsupported.
- Result Report Pick integration is deferred to 0.15.2 after the spike establishes real runtime behavior.
- Zoom remains Unsupported. Step 05A Highlight code is unchanged.
- Entity IDs are session-only diagnostics and are not persisted.

### Validation
- User-supplied local quality gate before the lifecycle correction: **PASS** — Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS.
- First live Pick spike proved direct managed-object handoff works **without COM registration**: `OnToolPushed`, `PickToolHelperAvailable`, and `OnToolPoped` were observed.
- Live defect found: hiding the modal `ShowDialog()` launcher ended the dialog lifetime and triggered owner-shutdown cancellation before entity/keyboard callbacks could complete.
- Corrected 0.15.1 uses a strongly retained modeless launcher and architecture protection against returning to `launcher.ShowDialog()`.
- User re-validation after that lifecycle correction: local quality gate **PASS** with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS. Live Part pick **PASS** — completion popup reported current-session entity ID 48 and restored the launcher.
- Live Esc cancellation path PASS after the first popup correction, but a second window-toggle test showed the standard MessageBox can still become unreachable behind another window.
- Replaced the Step 05B1 completion/cancellation MessageBox with a dedicated owned nested `PickSpikeResultDialog` inside `FeatureLauncherWindow.cs` that remains TopMost while open and has its own OK action; no new top-level Plugin source file is introduced.
- Picked selection clearing when the diagnostic tool ends remains expected spike behavior; persistent highlight is deferred to 0.15.2 integration.
- User re-validation of the architecture-compliant dedicated result-dialog package: **PASS** — Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate and local quality gate PASS. Live Esc cancellation dialog remained reachable and behaved correctly.
- Follow-up live observation isolated a separate modeless-launcher z-order issue: after switching away from Cimatron and back, the Feature Launcher itself could stay behind. Pressing Esc without first starting Pick produced no Pick result, ruling out Esc-alone duplicate Pick activation.
- Corrected launcher foreground lifecycle: show the modeless launcher owned by the Cimatron main window and monitor only transitions where the Cimatron process regains foreground; restore/activate the launcher once on that transition only when it is visible, enabled, and no Pick is active. The launcher is not permanently TopMost.
- User live validation confirmed the launcher-foreground correction works when switching away from Cimatron and back, and active-document switching during Pick behaved as expected. A package-specific local quality-gate transcript was not supplied for that correction.
- Follow-up live defect: after cancelling Pick with Esc and closing the dedicated result dialog, Cimatron could fall behind another application.
- Corrected focus return after the Pick result dialog closes: explicitly foreground the captured Cimatron main window, then restore/activate the owned Feature Launcher. Existing PickTool/Interop behavior, the dedicated result dialog, and the external-window foreground monitor are unchanged.
- User live re-validation confirmed the focus-return behavior works: after `Pick Spike (Part)` -> Esc -> closing the result dialog, Cimatron remains foreground and the Feature Launcher is restored.
- User reran the full local quality gate for the focus-return package: Release x64 build PASS; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate/local quality gate PASS. The build reported one analyzer warning, `CA1806`, because `GetWindowThreadProcessId`'s return value was ignored.
- Warning-only correction: `IsCurrentProcessForeground()` now checks the `GetWindowThreadProcessId` return value and fails closed when it returns 0. Runtime foreground behavior is otherwise unchanged. Architecture source-contract coverage protects the checked-return-value pattern.
- **WARNING-ONLY CORRECTION NOT VERIFIED / AWAITING USER RE-EXECUTION.**


## 0.15.0 — 2026-09-25

### Added
- Step 05A viewport highlight Application port/result model.
- CimatronIntegration highlight adapter using verified `ISelection.Selection` behavior.
- Result Report **Highlight** action for findings carrying current-session entity references.
- Disabled **Zoom — Unsupported** and **Pick — Unsupported** actions to make the current boundary explicit.
- Focused Application and Architecture tests plus Cimatron API verification documentation.

### Scope / limitations
- Active-model entity highlighting only. Nested assembly-instance highlighting is not yet verified and returns controlled Unsupported.
- Zoom/display transformation and interactive PickTool integration are not implemented in 0.15.0.
- No model mutation/write API and no customer CR/SA business logic.

### Validation
- User-supplied local quality gate: **PASS**.
- Release x64 build: **PASS** with **0 warnings / 0 errors**.
- Architecture, Domain, Application and Infrastructure tests: **PASS**.
- Coverage gate: **PASS** — Domain 100%, Application 95.41%, DesignChecks 100%, Infrastructure 98.48%.
- Live standalone Part Highlight: **PASS** — the corresponding finding geometry was visibly highlighted in orange in the Cimatron viewport with no error.
- Live mold assembly nested-instance Highlight: controlled **Unsupported** as designed; no unverified nested-instance selection was attempted.
- **Zoom — Unsupported** and **Pick — Unsupported** remained disabled as designed.
- Step 05A — Viewport Highlight: **CLOSED / VERIFIED** from user-supplied workstation and live Cimatron evidence.
- Next increment: Step 05B planning for the remaining viewport interaction scope; implementation requires explicit approval.


## 0.14.11 — 2026-09-25

### Fixed
- Confirmed live correlation `bc56bfd20991494288ea499ee9d9ccd1` loaded application version 0.14.10 and failed in `CimatronModelInspectionAdapter.ReadColor()` at the second `IAttributeSink.GetAttributes()` call.
- Centralized every `GetAttributes()` call in `CimatronModelInspectionAdapter` through `TryGetRawAttributes()`.
- `ReadColor()` now converts the same entity-specific `ArgumentException` into controlled `Unsupported` with a `Color inspection:` prefix, while unexpected exception types continue to propagate.
- Strengthened the architecture/source-contract test so exactly one `GetAttributes()` call is allowed and it must be inside the guarded helper; the helper is also protected against broad `Exception`/`COMException` catches.

### Validation
- User-supplied validation completed for 0.14.11.
- Release x64 build: PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Coverage gate: PASS — Domain 100%, Application 95.31%, DesignChecks 100%, Infrastructure 98.48%.
- Problematic Part live probe: Total 5 / Passed 2 / Unsupported 3 / Error 0.
- Representative mold assembly live probe: Total 7 / Passed 6 / Unsupported 1 / Error 0; 130 components.
- Representative Part regression: Total 5 / Passed 2 / Unsupported 3 / Error 0.
- Runtime log correlation `bfd082fc3d04457bbdd7de9f67c0380c` confirmed `applicationVersion` 0.14.11 with empty exception type/message.
- Step 04 — Cimatron Model Access Ports: CLOSED.
- Next planned step: Step 05 — `viewport-highlight-zoom-picks` (`0.15.0`).

## 0.14.10 — 2026-09-25

### Fixed
- Live stack trace proved that a specific Part/entity fails at `IAttributeSink.GetAttributes()` with `System.ArgumentException`.
- `ReadAttributes()` now reports that entity-specific runtime rejection as controlled `Unsupported` instead of failing the entire Model Inspection Probe.
- Unexpected exception types remain errors and continue through full stack/detail logging.
- Added focused source-contract coverage for this compatibility branch.

### Validation
- Version 0.14.10 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun the previously failing Part and confirm topology/surface findings remain available while attributes become `Unsupported` instead of overall `Error`.

## 0.14.9 — 2026-09-25

### Fixed
- Corrected the 0.14.8 Infrastructure test-harness compile failure.
- Added the missing `WritesExceptionStackTraceAndDetail()` test method and its throw helper.
- Production logging behavior is unchanged from 0.14.8.

### Validation
- Version 0.14.9 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.14.8 — 2026-09-25

### Changed
- Extended JSONL error logging with full exception stack trace and `Exception.ToString()` detail.
- Added focused Infrastructure coverage for persisted exception diagnostics.
- Logging-only diagnostic patch; no Cimatron API or feature execution behavior changed.

### Validation
- Version 0.14.8 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun the failing single-Part Model Inspection Probe once and query the new correlation ID in the JSONL log.

## 0.14.7 — 2026-09-25

### Changed
- Added precise stage diagnostics around `GetApplication()`, `GetActiveDoc()`, and active-document type access in the topology reader.
- No runtime compatibility behavior is guessed in this patch; it only identifies the remaining pre-topology failure boundary.
- No write APIs or customer CR/SA logic changes.

### Validation
- Version 0.14.7 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun only the failing single-Part Model Inspection Probe and capture the complete stage-labelled message.

## 0.14.6 — 2026-09-25

### Changed
- Added exact diagnostic labels around the Part-entry/model/reference operations that remained outside 0.14.5 topology instrumentation.
- Instrumented model-container access, model retrieval, assembly-instance model/ID reads, model PID, body/face entity IDs, and entity-reference creation.
- No behavior fix is guessed in this version; the purpose is to identify the exact live COM operation that raises the range exception.

### Validation
- Version 0.14.6 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun the failing single-Part Model Inspection Probe and report the full stage-labelled message.

## 0.14.5 — 2026-09-25

### Fixed
- Removed dynamic dispatch from assembly enumeration and now call `IAssemblyModel.GetInstances()` through the typed interop interface.
- Consume the returned instance array as `object[]` and cast each element defensively to `IAssInstance`.
- Added precise topology-stage exception context so live COM failures identify the failing read operation instead of only returning a generic range/interop message.

### Live evidence addressed
- 0.14.4 representative assembly run: `System.__ComObject` did not expose `GetInstances` through dynamic dispatch.
- Separate smaller/single-assembly topology run: `Value does not fall within the expected range.`

### Validation
- Version 0.14.5 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, repeat both live Model Inspection Probe scenarios.

## 0.14.4 — 2026-09-25

### Fixed
- Corrected live Cimatron COM-array marshaling for `IAssemblyModel.GetInstances()`.
- Replaced the three direct `IAssInstance[]` assumptions with one defensive runtime-normalization path that accepts the actual COM `object[]`/`Array` representation and casts entries individually to `IAssInstance`.
- Applies consistently to assembly structure traversal, topology part-instance collection and instance lookup.
- No analyzer suppression, model mutation, Cimatron write API or customer business logic was introduced.

### User-supplied validation from 0.14.3
- Build: PASS with 0 warnings and 0 errors.
- Release x64, Architecture, Domain, Application and Infrastructure tests: PASS.
- Coverage: Domain 100%, Application 95.31%, DesignChecks 100%, Infrastructure 98.45%.
- Coverage gate and local quality gate: PASS.
- Live Model Inspection Probe: runtime Error due to `object[]` -> `IAssInstance[]` conversion; this package addresses that observed defect.

### Validation
- Version 0.14.4 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`, then repeat the Model Inspection Probe on the same Assembly.

## 0.14.3 — 2026-09-25

### Fixed
- Removed the complete 36-warning analyzer baseline reported by the 0.14.2 workstation build.
- Fixed `CA1806`, `CA1822`, `CA1825`, `CA1852`, `CA1859`, and `CA1861` at source; no analyzer suppression was added.
- Production edits are mechanical/behavior-preserving and do not alter Cimatron API calls or customer feature logic.
- Test edits preserve existing assertions and coverage intent.

### User-supplied validation from 0.14.2
- Release x64 build: PASS.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Domain coverage: 100%.
- Application coverage: 95.31%.
- DesignChecks coverage: 100%.
- Infrastructure coverage: 98.45%.
- Coverage gate and local quality gate: PASS.
- Build warnings: 36 total; user requested that all be fixed.

### Validation
- Version 0.14.3 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- Target warning count: 0.

## 0.14.2 — 2026-09-25

### Fixed
- Removed the five analyzer warnings introduced by Step 04 without changing runtime behavior:
  - one `CA1826` in `ModelInspectionProbeFeature`;
  - two `CA1859` warnings in `ModelInspectionProbeFeature`;
  - two `CA1859` warnings in `CimatronModelInspectionAdapter`.

### User-supplied validation from 0.14.1
- Release x64 build: PASS.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Domain coverage: 100%.
- Application coverage: 95.31%.
- DesignChecks coverage: 100%.
- Infrastructure coverage: 98.45%.
- Coverage gate and local quality gate: PASS.
- Build warnings: 40 total; five were newly introduced by Step 04 and are the sole target of this patch.

### Validation
- Version 0.14.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- Expected warning count: return to the established 35-warning baseline if no environment-dependent analyzer difference appears.

## 0.14.1 — 2026-09-25

### Fixed
- Added focused coverage tests for `ModelInspectionProbeFeature` after the 0.14.0 workstation gate reported DesignChecks at 73.15% against the required 95%.
- Covered the untested probe guards and supported/unsupported read-result branches without changing production behavior.
- Avoided new analyzer-warning patterns in the corrective test additions where practical.

### User-supplied validation from 0.14.0
- Release x64 build: PASS.
- Architecture tests: PASS.
- Domain tests: PASS.
- Application tests: PASS.
- Infrastructure tests: PASS.
- Domain coverage: 100%.
- Application coverage: 95.31%.
- DesignChecks coverage: 73.15% (minimum 95%) — FAIL.
- Infrastructure coverage: 98.45%.
- Build warnings: 40 versus the prior 35-warning baseline.

### Validation
- Version 0.14.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`; the rerun is authoritative for both DesignChecks coverage and warning count.

## 0.14.0 — 2026-09-25

### Added
- Phase 02 Step 04 — read-only Cimatron model-access ports (WP5).
- `IAssemblyStructureReader`, `IEntityAttributeReader`, `IEntityColorReader`, and `IBodyTopologyReader` Application boundaries.
- Presentation-neutral snapshots for assembly components, attributes, colors, bodies and faces.
- `CimatronModelInspectionAdapter` using verified Cimatron 2026 read/query APIs.
- `FOUNDATION-MODEL-INSPECTION-PROBE` in DesignChecks.
- `docs/platform/CIMATRON-2026-MODEL-ACCESS-VERIFICATION.md`.
- Focused Application/fake-port tests for the new contracts and probe orchestration.

### Changed
- CimatronIntegration adds verified `interop.CimBaseAPI` and `interop.CimMdlrAPI` references.
- CimatronIntegration explicitly references Domain because the Application read-port contracts use Domain-owned `ModelEntityReference`, `Point3`, and `Direction3`; architecture tests encode this approved inward dependency.
- Feature composition registers the model-inspection foundation probe.

### API verification
- U1: verified for recursive `IAssemblyModel.GetInstances()`, instance model/id/color/suppression, `get_Transformation(1)` and transformation matrix.
- U2: entity attributes verified through `IAttributeSink.GetAttributes()`; instance/component attributes remain `Unsupported`.
- U3: assembly instance color and explicit entity `cmAttColor` verified.
- U4: body filtering + 2026 `IBody.GetFaces()`/`IFace`, `IGeom3DSurface.SurfType`, `Area()` and `NormalFromPoint()` verified. General bounding box remains `Unsupported`.
- No unverified API signature is guessed.

### Previous-step user validation
- Step 03 / 0.13.2: Release x64 and all local test suites PASS.
- Coverage: Domain 100%, Application 94.76%, Infrastructure 98.45%; coverage/local quality gate PASS.
- Live launcher, single-feature result report and two-feature `Run Selected` checklist PASS.

### Scope controls
- Read-only only; no save/move/recolor/attribute-write/procedure creation API.
- No customer CR/SA business rules or specialized analyzers.
- D5 client-shipping policy for foundation probes remains separate from this progressive development package.

### Validation
- Version 0.14.0 agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1`, then run Model Inspection Probe on a representative Part/Assembly in Cimatron 2026.0 SP2P1.

## 0.13.2 — 2026-09-25

### Fixed
- Fixed the Step 03 launcher checked-vs-selected UX mismatch found during live Cimatron validation.
- Checking or unchecking an actual feature node now also selects that node, so `Run Feature` can operate on the feature the user just interacted with.
- `Run Selected` remains based on checked applicable features; checklist behavior is unchanged.

### User-supplied validation from 0.13.1
- Release x64 build: PASS.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Domain coverage: 100%; Application coverage: 94.76%; Infrastructure coverage: 98.45%.
- Coverage gate and local quality gate: PASS.
- Build warnings: 35, matching the established warning baseline.
- Live Cimatron launcher: opens and groups features correctly; Assembly applicability correctly disables Active Part Readiness.
- Live UX defect: checking `Rule Parameter Probe` did not set `TreeView.SelectedNode`, so `Run Feature` displayed `Select a feature first.`

### Validation
- Version 0.13.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1` and then continue Step 03 live launcher/report validation.

## 0.13.1 — 2026-09-25

### Fixed
- Updated the architecture test's explicit Plugin top-level source allow-list for the two Step 03 UI files already approved by the Step 03 architecture plan: `FeatureLauncherWindow.cs` and `FindingReportWindow.cs`.
- Cleaned only Step-03-introduced analyzer warnings in `FeatureLauncherApplicationTests.cs` without changing production behavior.

### User-supplied validation from 0.13.0
- Release x64 build: PASS; 0 errors.
- Architecture tests: FAIL because the pre-Step-03 source allow-list did not include the newly approved launcher/report UI files.
- Build emitted 51 analyzer warnings; legacy warnings remain out of scope, while Step-03-introduced warnings in the new launcher Application test file are corrected here.

### Validation
- Version 0.13.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.13.0 — 2026-09-25

### Previous-step validation closeout
- Step 02 / 0.12.0 user validation: Release x64, Architecture/Domain/Application/Infrastructure tests, coverage gate and local quality gate PASS.
- Coverage: Domain 100%, Application 93.71%, Infrastructure 98.45%.
- Live Cimatron: schema 2 and `ProbeLength = 25 mm` probe PASS in Assembly context.

### Added
- Feature Launcher window grouped by feature kind and functional group.
- Current-context feature availability with disabled/unavailable features and reasons.
- Single-feature execution and sequential selected-feature checklist execution under one correlation ID.
- Result Report window with sortable finding columns, status filter and summary counts.
- Application use cases/projections: `ListAvailableFeatures`, `FeatureAvailability`, `ExecuteFeatureChecklist`, `FeatureChecklistReport`, and `FeatureFindingView`.
- Startup diagnostics access from the launcher.

### Boundaries
- No viewport highlighting, zoom, picks, model-reading ports, or customer CR/SA logic.
- No background-thread Cimatron COM access; all Step 03 execution stays on the command/UI thread. U10 remains explicitly UNVERIFIED beyond that conservative rule.

### Validation
- Agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1` and the Step 03 live Cimatron checklist.

## 0.12.0 — 2026-09-25

### Added
- Phase 02 Step 02 — versioned rule-parameter configuration (WP4).
- Schema-2 per-feature parameter configuration and in-memory schema-1 migration.
- `RuleParameterDefinition`, typed values/set, `IRuleParameterProvider`, XML provider, and foundation `RuleParameterProbeFeature`.
- Validation for required parameters, supported types, numeric ranges and `#RRGGBB` color-code representation.
- Focused Application and Infrastructure tests for the new parameter pipeline.

### Changed
- Common execution pipeline now resolves validated rule parameters before parameterized features run.
- Shipped config is schema 2 while retaining existing logging settings.
- Plugin registers/runs the internal parameter probe under the same correlation id as the readiness validation until the launcher arrives in Step 03.

### Scope controls
- No customer CR/SA business rule or customer parameter value added.
- No new Cimatron API/Interop usage.
- Parameter editing is file-only; UI editing remains deferred.

### Validation
- Agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1` and live Cimatron validation.

## 0.11.3 — 2026-09-25

### Fixed
- Fixed the Step 01 coverage pipeline so Domain tests contribute to Domain coverage.
- `Invoke-Coverage.ps1` now collects:
  - `domain.coverage.xml` from `CimatronCustomization.Domain.Tests.exe`;
  - `application.coverage.xml` from `CimatronCustomization.Application.Tests.exe`;
  - `infrastructure.coverage.xml` from `CimatronCustomization.Infrastructure.Tests.exe`;
  and merges all three into `coverage.cobertura.xml`.
- No production behavior changed.

### Root cause confirmed from 0.11.2
- Domain tests were included in the Domain test project and invoked by its `Program.Main`.
- The quality gate separately reported `DOMAIN TESTS: PASS`.
- The coverage script collected only Application and Infrastructure test executables, so the newly added Domain tests were never instrumented.
- This explains why Domain coverage remained exactly 55.56% after 0.11.2.

### Validation
- Version 0.11.3 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- Expected coverage output now includes a `domain.coverage.xml` collection before the merge.

## 0.11.2 — 2026-09-25

### Fixed
- Added focused Domain coverage tests for the Step 01 result model introduced in 0.11.0.
- Covered constructor guards, value accessors, collection enumeration, empty/null aggregation paths, and every canonical result-severity branch.
- No production behavior or Cimatron API usage changed.

### User-supplied validation from 0.11.1
- Release x64 build: PASS.
- Architecture tests: PASS.
- Domain tests: PASS.
- Application tests: PASS.
- Infrastructure tests: PASS.
- Coverage collection: PASS.
- Application coverage: 92.65% (minimum 90%).
- Infrastructure coverage: 100% (minimum 80%).
- Domain coverage: 55.56% (minimum 90%) — quality gate FAIL.

### Validation
- Version 0.11.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.11.1 — 2026-09-25

### Fixed
- Corrected the user-reported Step 01 Release x64 build failure `CS0012` in `CimatronCommandExecution`.
- Kept the approved architecture boundary intact: Plugin still has no direct reference to `CimatronCustomization.Domain`.
- Added `FeatureExecutionReport.StatusText` as an Application-owned presentation value; Plugin now displays that instead of directly consuming the Domain-owned `ResultStatus`.
- Added a focused Application regression assertion for the status-text boundary.

### User-supplied validation from 0.11.0
- Release x64 build: FAIL with 1 error (`CS0012`) because Plugin accessed `FeatureExecutionReport.Status`, whose type is defined in Domain.
- Existing analyzer warnings, including the known Plugin `CA1852` warning, remain outside this corrective patch.

### Validation
- Version 0.11.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.11.0 — 2026-09-25

### Added
- Canonical enum-based feature execution status, including approved Automation-only `Succeeded`.
- Feature execution context/run inputs, enriched feature metadata, findings/value types, document-context applicability, and platform guide.
- Dedicated Plugin `FeatureComposition` for explicit registry composition.

### Changed
- Feature outcomes/reports no longer use free-text status strings.
- Validation wrong-document context is stopped by the common pipeline as `NotApplicable`; missing application/document is `Error`.
- Execution logs now carry feature requirement ids and finding-count summaries.
- Plugin architecture now permits composition-only references to DesignChecks and Automations while preserving their isolation from CimatronIntegration/Interop and from each other.

### Previous-step validation closeout
- Version 0.10.0 user evidence: Release x64 build PASS; Architecture, Domain, Application and Infrastructure tests PASS; Domain 95.24%, Application 96.23%, Infrastructure 100%; coverage gate PASS; local quality gate PASS.
- Live Cimatron 2026.0 SP2P1 Step 10 execution PASS with active Part, startup diagnostics, registry-backed Active Part Readiness `Passed`, and no visible runtime regression.

### Validation
- Version 0.11.0 agent execution status: NOT VERIFIED. User must run the local quality gate and live Cimatron regression.

## 0.10.0 — 2026-09-17

### Added
- Common Application execution pipeline for registry-backed Validation and Automation features.
- Standardized `FeatureExecutionReport` with feature metadata, status/message, duration, and retained exception context for execution errors.
- Focused Application regression coverage for success, Failed, Warning, Error, unknown feature, exception-to-Error behavior, timing/report metadata, logging/correlation metadata, and both feature categories.

### Changed
- Plugin now delegates registry-backed feature execution and operational logging to Application instead of executing/logging the readiness feature directly.
- `FeatureRegistry` exposes registered-feature resolution for the executor while retaining existing discovery/execution behavior.

### Previous-step validation
- Version 0.9.4 user evidence: Release x64 build PASS; Architecture, Domain, Application, and Infrastructure tests PASS; Domain 95.24%, Application 100%, Infrastructure 100%; coverage gate PASS; local quality gate PASS.
- Live Cimatron startup diagnostics PASS and structured JSON-lines runtime logging PASS.

### Validation
- Version 0.10.0 agent execution status: NOT VERIFIED. User must run the local quality gate and live Cimatron regression.

## 0.9.4 — 2026-09-17

### Fixed
- Prevented rolled-log filename collisions when multiple log rolls occur within the same millisecond.
- Added a rapid-roll regression check while retaining the bounded-file retention assertion.

### Validation
- 0.9.3 user evidence: Release x64 build PASS; Architecture PASS; Domain PASS; Application PASS; Infrastructure FAIL on duplicate rolled filename.
- 0.9.4 requires user quality-gate execution.

## 0.9.3 — 2026-09-17

### Fixed
- Corrected malformed XML C# string literals in `StartupConfigurationTests.cs` that caused the 0.9.2 Infrastructure test project to fail compilation.
- Reviewed the Step 09 source/test files for the same string-literal/escaping defect class; no additional malformed literals were found in the inspected Step 09 files.

### Validation
- Version 0.9.2 user validation: FAIL with 16 compile errors in `StartupConfigurationTests.cs`.
- Version 0.9.3 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.9.2 — 2026-09-17

### Fixed
- Added the missing .NET Framework `System.Xml` assembly reference to `CimatronCustomization.Infrastructure`, required by `XmlStartupConfigurationProvider` / `System.Xml.Linq`.

### Validation
- Version 0.9.1 user validation: FAIL with `CS0012` because `XmlReader` could not be resolved.
- Version 0.9.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.9.1 — 2026-09-17

### Fixed
- Corrected malformed C# string literals in `RollingJsonFileLogger` JSON serialization/escaping code that caused the 0.9.0 Release x64 build to fail.
- Corrected the focused Infrastructure logger test string literals and added a regression assertion for escaped quote, backslash, and newline content.

### User-supplied validation from 0.9.0
- Release x64 build: FAIL with 22 compile errors in `RollingJsonFileLogger.cs`; known CA1822/CA1825 warnings were unrelated.

### Validation
- Version 0.9.1 agent execution status: NOT VERIFIED. User must rerun the local quality gate, then live Cimatron validation.

## 0.9.0 — 2026-09-17

### Added
- Versioned XML startup configuration, bounded rolling structured logging, Application startup diagnostics, and Cimatron runtime-version/context diagnostics.
- Infrastructure test harness and governed Infrastructure coverage.

### Changed
- Plugin composition root now references Infrastructure only to compose approved logging/configuration adapters.
- Existing registry-backed Active Part readiness execution remains the representative feature after startup diagnostics.

### Validation
- Agent execution status: NOT VERIFIED. User must run the local quality gate and live Cimatron validation.

## 0.8.0 — 2026-09-17

### Added
- Explicit Application-layer `FeatureRegistry` using composition-root registration; no reflection or assembly scanning.
- `IApplicationFeature`, `FeatureDefinition`, `FeatureKind`, and `FeatureExecutionOutcome` application contracts for scalable Validation/Automation registration.
- `ActivePartReadinessFeature` as the first registry-backed internal foundation feature.
- Focused Application registry tests covering registration, discovery, duplicate ids, invalid registrations, metadata, lookup, and execution.

### Changed
- Plugin composition root now registers and executes the existing Active Part readiness feature through `FeatureRegistry` rather than invoking the use case directly.
- Product and assembly version metadata advanced to 0.8.0.

### Previous-step validation
- Version 0.7.0 Release x64 build, Architecture tests, Domain tests, Application tests, coverage gate, and local quality gate: PASS based on user-supplied evidence.
- Domain coverage: 95.24%; Application coverage: 100%.
- In-process Cimatron Active Part readiness runtime: PASS with status `Passed`.

### Validation
- Version 0.8.0 agent execution status: NOT VERIFIED.
- User must rerun the Release x64 local quality gate and then validate the registry-backed command in real Cimatron with an active Part.

## 0.7.0 — 2026-09-17

### Added
- Internal foundation `ActivePartReadinessValidation` vertical slice in Domain; this is not a customer CR/SA feature.
- Standard Domain `ResultStatus` states and structured Active Part readiness result.
- Application `CheckActivePartReadiness` orchestration and Plugin-safe outcome DTO.
- Dedicated Domain test executable and local quality-gate execution.
- Application tests covering Error, NotApplicable, Unsupported, and Passed readiness paths.

### Changed
- Plugin command now exercises the first complete read-only vertical slice instead of displaying the raw session diagnostic.
- Product and assembly version metadata advanced to 0.7.0.

### Validation
- Agent execution status: NOT VERIFIED.
- User must run the Release x64 local quality gate and then validate the command in real Cimatron with an active Part.

## 0.6.1 — 2026-09-17

### Fixed
- Corrected `ReadCurrentCimatronSessionTests` to use `CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)` instead of an unavailable four-argument constructor.
- Assigned the constructor-under-test to a local variable in the null-dependency test to remove the test-only `CA1806` analyzer warning.

### User-supplied validation from 0.6.0
- Release x64 build reached Application.Tests and failed with `CS1729` because the test attempted to call a non-existent four-argument `CimatronSessionSnapshot` constructor.
- `CA1806` was also reported in the null-dependency test.

### Validation
- Version 0.6.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`, then execute the registered command inside Cimatron with an active Part.


## 0.6.0 — 2026-09-17

### Added
- Added `ReadCurrentCimatronSession` as the Application-layer use case for current-session orchestration.
- Added focused Application tests proving the use case delegates exactly once to `ICimatronSession` and rejects a null dependency.

### Changed
- `CimatronCommandExecution` now composes `CimatronSessionAdapter` with the Application use case instead of directly invoking the session port.
- Product/test assembly version metadata advanced to 0.6.0.0.

### Previous-step validation
- Version 0.5.5 local quality gate: PASS.
- Version 0.5.5 in-process Cimatron session diagnostic: PASS with an active Part.

### Validation
- Version 0.6.0 agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1` and then execute the registered command inside Cimatron.
## 0.5.5 — 2026-09-17

### Changed
- Wired the validated Cimatron Plugin command to the production `CimatronSessionAdapter` for in-process session validation.
- Plugin now acts as the composition root and references both Application and CimatronIntegration.
- Updated ArchitectureTests to permit the approved Plugin → CimatronIntegration composition-root dependency while retaining other Plugin boundary guards.

### User-supplied validation from 0.5.4
- Release x64 build: PASS.
- Architecture tests: PASS.
- Application tests: PASS.
- Application coverage: 100%.
- Coverage gate and local quality gate: PASS.
- Optional standalone diagnostic EXE: FAIL at runtime with `REGDB_E_CLASSNOTREG`; it is no longer the mandatory Step 05 production-path validation.

### Validation
- Version 0.5.5 agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1`, then execute the registered Plugin command inside Cimatron with an active Part.

## 0.5.4 — 2026-09-17

### Fixed
- Added the missing .NET Framework `Microsoft.CSharp` assembly reference to `CimatronCustomization.CimatronIntegrationTests` so the approved dynamic COM/Interop conversion in the optional diagnostic EXE can compile.
- No production `CimatronSessionAdapter` logic or Plugin behavior changed.

### User-supplied validation from 0.5.3
- Release x64 build reached the diagnostic project and failed with `CS0656: Missing compiler required member Microsoft.CSharp.RuntimeBinder.Binder.Convert`.

### Validation
- Version 0.5.4 agent execution status: NOT VERIFIED.
- User must rerun the local quality gate, then run the external diagnostic with Cimatron open and an active Part.

## 0.5.3 — 2026-09-17

### Fixed
- Corrected the optional external Cimatron session diagnostic to use the official EXE-project access path: `interop.CimAppAccess.AppAccess.GetApplication()`.
- Added explicit diagnostic-project references to `interop.CimAppAccess.dll` and `interop.CimatronE.dll` through the configurable `CimatronProgramDir` property.
- Removed the diagnostic EXE dependency on the production `CimatronCustomization.CimatronIntegration` project.
- Production `CimatronSessionAdapter` remains unchanged on the official Class-project `CimApplicationProvider.GetApplication()` path.

### User-supplied validation from 0.5.2
- Local quality gate: PASS.
- External diagnostic failed with `REGDB_E_CLASSNOTREG` when the Class-project provider path was invoked from the EXE process.

### Validation
- Version 0.5.3 agent execution status: NOT VERIFIED.
- User must rerun the local quality gate, then run the external diagnostic with Cimatron open and an active Part.

## 0.5.2 — 2026-09-17

### Fixed
- Added the missing .NET Framework `Microsoft.CSharp` assembly reference to `CimatronCustomization.CimatronIntegration` so the approved `dynamic` Interop conversion can compile.
- No session-adapter logic or Plugin behavior changed.

### User-supplied validation from 0.5.1
- Interop reference-path correction progressed the Release x64 build past unresolved Cimatron assemblies.
- Build then failed with `CS0656: Missing compiler required member Microsoft.CSharp.RuntimeBinder.Binder.Convert`.

### Validation
- Version 0.5.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.


## 0.5.1 — 2026-09-17

### Fixed
- Corrected `CimatronCustomization.CimatronIntegration` Interop reference resolution by defining a configurable `CimatronProgramDir` defaulting to the verified Cimatron 2026 Program directory.
- Updated `interop.CimatronE.dll` and `interop.CimServicesAPI.dll` HintPaths to resolve through `$(CimatronProgramDir)`.

### User-supplied validation from 0.5.0
- Release x64 build reached CimatronIntegration and failed because both Interop assemblies could not be resolved from project-relative HintPaths.
- The resulting `interop` namespace compiler errors were downstream of the unresolved references.

### Validation
- Version 0.5.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1` and then run the live Cimatron session diagnostic.

## 0.5.0 — 2026-09-17

- Added the Application-layer `ICimatronSession` port and immutable `CimatronSessionSnapshot`.
- Added `CimatronSessionAdapter` in CimatronIntegration using the official `CimApplicationProvider.GetApplication()` and `IApplication.GetActiveDoc()` plugin/class-project access path.
- Added focused Application tests and a user-run live Cimatron session diagnostic executable.
- Extended the local quality gate to execute Application tests and collect governed Application coverage.
- No CR/SA business logic added; validated Plugin command source remains unchanged.

## 0.4.1 — 2026-09-17

### Fixed
- Corrected `Test-CoverageGate.ps1` so generated C# files under `bin/` and `obj/` are excluded when deciding whether a governed project contains substantive production source.
- Preserved exclusion of `Properties/AssemblyInfo.cs`.

### User-supplied validation from 0.4.0
- Release x64 build: PASS with 0 errors and one non-blocking `CA1852` warning in the existing plugin execution class.
- ArchitectureTests: PASS.
- `dotnet-coverage` and `dotnet-sonarscanner` restore: PASS.
- Coverage collection/report generation: PASS.
- Coverage gate: FAIL because generated Domain files were incorrectly classified as substantive source; this patch addresses that root cause only.

### Validation
- Version 0.4.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1` and provide the resulting output.

## 0.4.0 — 2026-09-17

### Added
- Root `.editorconfig` and centrally enabled Roslyn/.NET analyzer configuration.
- Pinned `Microsoft.CodeAnalysis.NetAnalyzers` 10.0.401 development dependency.
- Local tool manifest pinning `dotnet-coverage` 18.11.0 and `dotnet-sonarscanner` 11.3.0.
- Release-build, architecture-test, coverage, coverage-gate, SonarQube and local quality-gate PowerShell scripts.
- Coverage settings and baseline quality-tooling documentation.
- Development dependency/license inventory.

### Previous-step validation
- Version 0.3.1 Release x64 ArchitectureTests: PASS based on user-supplied output `ARCHITECTURE TESTS: PASS`.

### Validation
- Version 0.4.0 agent execution status: NOT VERIFIED.
- User must execute the quality tooling on the real workstation and provide results.
- SonarQube remains AWAITING USER EXECUTION until an approved server/project/token are available.

## 0.3.1 — 2026-09-17

### Fixed
- Added the missing .NET Framework `System.Xml` assembly reference required by the ArchitectureTests project when using `System.Xml.Linq`.

### Validation
- Root cause identified from user-supplied build output: `XmlReader` could not be resolved because `System.Xml` was not referenced.
- Version 0.3.1 Release x64 ArchitectureTests: PASS based on user-supplied output `ARCHITECTURE TESTS: PASS`.

## 0.3.0 — 2026-09-17

### Added
- Executable `CimatronCustomization.ArchitectureTests` project under `tests/`.
- Automated checks for approved project-reference direction and Hexagonal boundaries.
- Guards preventing direct Cimatron dependencies in Domain, Application, DesignChecks, Automations, and Infrastructure.
- Guards preserving DesignChecks/Automations separation and the thin Plugin boundary.

### Changed
- Solution includes the ArchitectureTests project.
- Product assembly version metadata advanced to 0.3.0.0; production behavior is otherwise unchanged.

### Previous-step validation
- Version 0.2.0 Release x64 solution rebuild: PASS based on user-supplied evidence (7 succeeded, 0 failed, 0 skipped).
- Version 0.2.0 Cimatron command regression: PASS based on user-supplied runtime feedback.

### Validation
- Version 0.3.0 agent execution status: NOT VERIFIED.
- User must run Release x64 rebuild and execute the ArchitectureTests harness.

## 0.18.1 — 2026-09-28

### Added
- Consumer-neutral `TabularMappingEngine` in Application.
- Deterministic header-resolution result/error contracts.
- Deterministic mapped-row validation result/error contracts.
- Header resolution across configured primary/alias names, case-insensitively.
- Fail-closed validation for missing required headers, ambiguous alias matches, duplicate physical headers, missing required logical values, and logical value-type mismatches.
- Focused Application tests for header resolution and mapped-row validation.

### Security / privacy
- Mapping errors identify logical fields and source row numbers where needed, but do not echo customer cell values.

### Previous-step validation
- User-supplied 0.18.0 quality gate: Release x64 PASS; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; Application coverage 95.89%; Infrastructure coverage 91.02%; coverage/local quality gates PASS; exit code 0.

### Scope control
- No ExcelDataReader/Infrastructure reader behavior change.
- No Plugin/Cimatron behavior change.
- No CR-04 steel-grade comparison or CR-22 finger-pin lookup/business rules.
- Reader orchestration/integration is deferred to Step 06D.

### Validation
- 0.18.1 agent execution status: NOT VERIFIED.
- User must run the standard captured quality gate and provide the resulting evidence.

## 0.18.1 — 2026-09-28 — Session Handoff Documentation Refresh

### Session handoff/documentation checkpoint
- Expanded the 0.18.1 Step 06C2 handoff to the full `AGENTS.md` handoff schema: approved checkpoint, scope, completed/pending work, files added/modified, approved existing-file changes, tests/gate status, known issues/limitations, decisions, API findings, exact next action, read-first list, and continuation prompt.
- No production behavior or 06C2 implementation logic changed by this documentation checkpoint.
- 0.18.1 remains AWAITING USER QUALITY GATE; the handoff does not convert the candidate to an approved checkpoint.

## 0.18.2 — 2026-09-28 — Pre-06C3 Analyzer Warning Cleanup

### User-supplied evidence entering change
- 0.18.1 captured quality gate: Release x64 build PASS; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage gate PASS; local quality gate PASS; exit code 0.
- Build completed with 20 analyzer warnings: 2 `CA1822` findings in `TabularMappingEngine` and 18 `CA1861` findings in `TabularMappingEngineTests` / `TabularMappingContractTests`.
- Step 06C2 was explicitly approved/closed by the user after review of that evidence.

### Changed
- Preserved the intentional instance-service API of `TabularMappingEngine` and added narrow, documented `CA1822` suppressions to `ResolveHeaders` and `ValidateRows`; no method behavior changed.
- Replaced repeated constant string-array arguments in the focused Application mapping tests with named `static readonly` fixtures, addressing the 18 `CA1861` findings without disabling the analyzer rule globally.
- Advanced the Application assembly/product checkpoint to `0.18.2` and added a dedicated warning-cleanup session handoff.

### Scope control
- No mapping semantics, result/error codes, customer-value disclosure policy, Infrastructure reader behavior, Plugin/Cimatron behavior, CR-04/CR-22 business logic, dependency version, or architecture rule changed.
- This is not Step 06C3 implementation.

### Validation
- AI agent did not build, run tests, or execute Cimatron, per `AGENTS.md`.
- 0.18.2 is **AWAITING USER QUALITY GATE**. Expected acceptance condition: the standard captured gate passes and the prior 20 analyzer warnings are absent.

## 0.18.3 — 2026-09-28 — Step 06C3 Integration Verification

### Previous checkpoint validation
- User-supplied 0.18.2 captured quality gate: Release x64 build PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration and Infrastructure tests: PASS.
- Coverage gate: PASS.
- Local quality gate: PASS.
- Exit code: 0.
- The user explicitly approved proceeding to Step 06C3 after review of this evidence.

### Added
- `TabularMappingIntegrationTests` in the Application test project.
- Integration-style verification that resolved 06C1/06C2 mapping columns can populate the existing `TabularSourceDefinition` contract and that resulting `TabularTable` rows validate through `TabularMappingEngine`.
- Verification that optional mappings remain omitted without invalidating consumer-neutral rows.
- Verification that ambiguous header resolution fails before a downstream reader source can be constructed.
- Verification that invalid mapped rows fail closed, preserve source-row error context, expose no consumer rows, and do not leak customer values in error messages.

### Scope control
- No production source behavior changed.
- No `ExcelTabularDataReader` orchestration added; that remains Step 06D.
- No CR-04 / CR-22 business logic added.
- No Plugin/Cimatron behavior changed.
- No dependency or architecture-boundary change.

### Validation
- AI agent did not build, run tests, or execute Cimatron, per `AGENTS.md`.
- 0.18.3 is AWAITING USER QUALITY GATE.

## 0.18.3 — 2026-09-28 — Step 06C Validation Closure / Documentation Refresh

### Validation / approval
- User-supplied `quality-gate-20260928-151541.txt` confirmed Release x64 build PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS.
- Application coverage 96.35%, DesignChecks 100%, Infrastructure 91.84%; CimatronIntegration 4.57% measured with no Step 05B2 threshold.
- Coverage gate PASS; local quality gate PASS; exit code 0.
- User explicitly approved Step 06C closure after review of the evidence.

### Documentation closure
- Step 06C3 is now VALIDATED / APPROVED.
- Step 06C overall is now CLOSED / APPROVED.
- Added `docs/history/session-handoffs/phase-02-step-06c-to-step-06d-session-handoff-0.18.3.md`.
- Updated `VERSION.md` and appended the authoritative post-validation closure record to the 06C3 handoff.
- No production source, test behavior, project registration, dependency, or Cimatron behavior changed in this documentation-only refresh.
- Step 06D is the next eligible step but remains NOT STARTED pending plan/scope approval under `AGENTS.md`.


## 0.18.3 — 2026-09-28 — AGENTS CSV Time-Ledger Policy Migration

### Documentation / governance
- Replaced `AGENTS.md` with the user-supplied revision that makes `docs/time-tracking/PROJECT-TIMESHEET.csv` the single authoritative engineering-time ledger.
- Migrated the measured `TT-BOOTSTRAP-001` record from the previous Markdown timesheets into the CSV ledger without inventing unavailable timestamps.
- Removed `docs/time-tracking/PROJECT-TIMESHEET.md` and `docs/time-tracking/phase-02-timesheet.md` because the new policy explicitly forbids duplicate phase-wise Markdown timesheets.
- Added the current AGENTS/CSV migration submission cycle to the CSV with user-feedback/closure fields left empty until actual feedback is received.
- No production source, tests, project files, dependency versions, or Cimatron behavior changed.

## 0.18.3 — 2026-09-28 — CSV Time-Ledger Migration Validation Closure

### Validation
- User-supplied `quality-gate-20260928-154231.txt` confirmed Release x64 build PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS.
- Coverage gate PASS; local quality gate PASS; exit code 0.
- Closed `TT-CSV-MIGRATION-001` in `docs/time-tracking/PROJECT-TIMESHEET.csv` with the observed feedback timestamp, feedback-wait duration and closure timing.
- No production source, tests, project files, dependency versions, or Cimatron behavior changed.

## 0.19.0 — 2026-09-28 — Step 06D Reader Orchestration

- Added Application header-discovery contracts while preserving `TabularSourceDefinition` mapping invariants.
- Added two-pass source consistency protection: the row-reading pass rejects a header row that differs from the snapshot used for mapping with `TABULAR_HEADERS_CHANGED`.
- Applied existing reader file-format and maximum-file-size controls to header discovery.
- Added consumer-neutral `ReadMappedTabularData` orchestration for discovery → mapping → read → validation.
- Combined orchestration result uses the canonical Step 01 `ResultStatus` enum; no new success/failure status model is introduced.
- Added focused Application orchestration tests and Infrastructure discovery/header-change tests.
- Updated the real Cimatron in-process tabular probe to call `ReadMappedTabularData` and added `Start-Step06DTabularProbe.ps1`.
- Updated Step 06 platform documentation and session handoff; updated the authoritative CSV time ledger.
- No CR-04/CR-22 logic, customer layout assumptions, Plugin UI change, Cimatron model modification, or dependency upgrade.
- Status: AWAITING USER QUALITY GATE AND LIVE CIMATRON PROBE.


## 0.19.1 — 2026-09-28 — Step 06D Quality-Gate Corrective Patch

- User quality-gate evidence for 0.19.0 reported 4 analyzer warnings and `APPLICATION TESTS: FAIL` / exit code 1.
- Corrected `ReadMappedTabularData` analyzer findings (`CA1826`) without behavior change.
- Corrected new Application test analyzer findings (`CA1861`, `CA1825`).
- Fixed the validation-stage test fixture so it no longer violates `TabularTable` construction invariants before orchestration validation executes.
- No reader/orchestration/probe architecture change and no CR/customer-specific behavior added.
- Status: AWAITING USER QUALITY GATE.

- **0.19.1 validation update:** User workstation quality gate confirmed the Step 06D corrective patch with 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, and exit code 0. Live Step 06D Cimatron probe remains pending.


### 0.19.1 — Step 06D live validation closure

- User live Cimatron probe executed inside `CimatronE` and returned `ProbeResult: PASS`.
- `ReadMappedTabularData` completed with stage `Completed`, one row, and expected known-answer values from `LegacyInput.xls`.
- Runtime evidence confirms `ExcelDataReader` 3.9.0.0 loaded from the Cimatron Program directory.
- Step 06D is validated. No production/source/test behavior changed by this closure update.
- Step 06 now has all planned WP8 implementation evidence; only explicit Step 06 closure approval remains.

## 0.19.1 — 2026-09-28 — Step 06 Overall Closure

- User explicitly approved Step 06 overall closure after the 0.19.1 clean quality gate and successful live in-process Cimatron mapped-tabular probe.
- Step 06 is now **CLOSED / APPROVED** against the WP8 definition of done: reader, configuration mapping, controlled failure modes, dependency/runtime approval, orchestration, and live probe evidence are complete.
- Added the Step 06 closure session handoff.
- No production/source/test behavior changed by this closure documentation update.
- The next implementation step must be identified from the governing Phase 02 roadmap/requirements and separately planned/approved; Step 06 must not grow another architecture sub-step.


### 0.19.1 — Step 06 final closure validation

- User workstation closure-package quality gate passed with 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, and exit code 0.
- Step 06 overall is now VALIDATED / CLOSED.
- Documentation/time-ledger/checksum update only; no production/source/test behavior change.


## 0.19.1 — 2026-09-28 — Step 06E Documentation Alignment / Deferred-Findings Register

- Corrected traceability so the already-completed real-workstation sample-file validation and formal closure are explicitly classified as **06E — Live Validation & Closure**.
- Added `docs/platform/STEP-06-DEFERRED-FINDINGS.md` with six non-blocking findings and mandatory carry-forward ownership to CR-04, CR-22, D5/client packaging, or generic release hardening.
- Preserved historical evidence filenames (including the `step06d-...` probe) without rewriting evidence.
- No source, test, project, dependency, or runtime behavior changed.


### 0.19.1 — Step 06E documentation-alignment validation

- User workstation quality gate `quality-gate-20260928-164128.txt` passed with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration, and Infrastructure test suites PASS.
- Coverage gate and local quality gate PASS; exit code 0.
- 06E documentation alignment is VALIDATED / CLOSED.
- Deferred findings remain open carry-forward obligations; no source/test/runtime behavior changed.


## 0.20.0 — Phase 02 Step 07 — Cimatron API Capability Verification

- Added development-only `CimatronCustomization.ApiCapabilityVerification` x64/.NET Framework 4.8 diagnostic project.
- Added 07A installed-Interop reflection-only inventory for the Step 07 target interfaces/enums; this path performs no Cimatron runtime attach.
- Added 07C-1 geometry, 07C-2 assembly-context, 07C-3 component-property/BOM, and approved 07C-4 hidden-state candidate probes.
- Added before/after model-file and `IsModified` no-mutation evidence to every live mode; any `CHANGED_OR_UNVERIFIED` result is a failed run.
- BOM export is restricted to a newly created `%TEMP%\CimatronCustomization\Step07\<timestamp>\` folder.
- Added architecture guards enforcing the development-only boundary, reflection-only 07A path, prohibited mutation tokens, temporary selection restoration, and temp-only BOM output.
- Added `STEP-07-KNOWN-ANSWER-MODELS.md`, the initial API capability verification register, Step 07 handoff, PowerShell capture helper, time-ledger entry, and regenerated checksums.
- Production `src/**`, `config/**`, existing ZoomCommandDiscovery sources, and unrelated tests are intentionally unchanged.
- Validation: **AWAITING USER EXECUTION**. No build/test/Cimatron PASS is claimed by the agent.


## 0.20.1 — 2026-09-29 — Step 07 Quality-Gate Corrective Patch

- User workstation quality gate `quality-gate-20260929-141352.txt` failed during the Release x64 build with 0 warnings / 12 errors, all in the new Step 07 development-only verification project.
- Added the missing `Microsoft.CSharp` framework reference required by installed COM interop conversions.
- Corrected installed-Interop variant/object return handling for geometry array results and assembly bounding-box results.
- Corrected `get_SubInstances(1, 0)` observation typing.
- Corrected `GetEntityPointDistance` to the installed signature with `out IPointData`.
- No production source/configuration/Plugin behavior, existing ZoomCommandDiscovery source, CR/SA behavior, or Step 06 deferred finding changed.
- Validation: **AWAITING USER QUALITY GATE**. No PASS is claimed.


## 0.20.1 — 2026-09-29 — Step 07 Quality-Gate Validation

- User workstation quality gate `quality-gate-20260929-142529.txt` passed with Release x64 build PASS, 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration, and Infrastructure test suites PASS.
- Coverage gate and local quality gate PASS; exit code 0.
- This validates the 0.20.1 compile corrective only; Step 07 capability evidence still required 07A/07C execution.

## 0.20.2 — 2026-09-29 — Step 07 Reflection-Only Enum Corrective

- First user-run 07A on 0.20.1 failed with `InvalidOperationException: Code execution is prohibited in an assembly loaded as ReflectionOnly.`
- Root cause: enum inventory called `Enum.GetNames` / `Enum.Parse` on enum `Type` objects loaded by `ReflectionOnlyLoadFrom`.
- Replaced enum parsing/execution with metadata-only public static field enumeration and `FieldInfo.GetRawConstantValue()`.
- No Cimatron runtime attach, production source/configuration/Plugin behavior, existing ZoomCommandDiscovery source, CR/SA behavior, or Step 06 deferred finding changed.
- Validation: **AWAITING USER QUALITY GATE**. No PASS is claimed for 0.20.2.


## 2026-09-29 — Step 07 Session Handoff — 0.20.2

- User workstation quality gate `quality-gate-20260929-143207.txt`: PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- User-run 07A reflection inventory `api-capability-reflection-20260929-143432.txt`: COMPLETE; footer confirms `RuntimeCalls: NONE`.
- Verification register updated with evidence-backed installed signatures. Runtime capability statuses remain pending 07C, except the instance-attribute getter is recorded `NOT AVAILABLE` because 07A shows `IAssInstance.Attribute` is SET-ONLY.
- KA-PART-1 preparation observed with two bodies, through-hole, `KA_UCS_90Z`, and part/model material `1.2738`; body-level custom attribute is not claimed.
- User explicitly stated that KA-ASM-1 is ready for continuation. Final ids/transforms/lock/gap values remain to be recorded before runtime comparison.
- No production or Step 07 tool code change. Documentation/time-ledger/handoff/checksum update only.
- Next session starts with 07C-1 preparation/execution against KA-PART-1; do not jump to 07C-2/3/4.

## 0.20.4 — 2026-09-29 — Step 07C-1C Current Selection ID Inspection

- Added development-only `--inspect-current-selection --expect Part` to read the user's existing Cimatron selection without changing it.
- Records selected entity count, actual entity IDs/types, and read-only edge convexity at parameter `0.5` for selected edges.
- Preserves Step 07 before/after no-mutation evidence; the new mode contains no selection assignment.
- Carried forward user workstation 0.20.3 evidence: clean quality gate, successful geometry target discovery, `KA_UCS_90Z` mapped to active UCS entity ID 2 after explicit activation, B1/B2 visual mapping, and 25 mm body-pair distance.
- The visually chosen test face still has no recorded entity ID; 0.20.4 exists to capture it without guessing. Convex/concave target edge IDs remain pending.
- No production `src/**`, Plugin/configuration, CR/SA behavior, or 07C-2/3/4 change.
- Validation: **AWAITING USER QUALITY GATE + LIVE SELECTION INSPECTION**. Agent did not run build/tests/Cimatron.


## 0.20.8 — 2026-09-29 — Step 07C-1R Session Handoff / Evidence Alignment

- Documentation-only handoff; no production, diagnostic, test, config, or model behavior changed.
- Records user workstation 0.20.7 quality-gate PASS (`quality-gate-20260929-190027.txt`).
- Records live discovery `api-capability-geometry-known-answer-discovery-20260929-190407.txt` and live geometry evidence `api-capability-geometry-20260929-191114.txt`.
- Reclassifies `IGeomServices.SurfacesArea` as **NOT AVAILABLE** in installed Cimatron 2026 SP2P1 Interop; it is not BLOCKED because the member is absent.
- Records UCS 249 only as a second/reference UCS candidate. UCS 2 and 249 have parallel axes in the observed evidence, so rotated-axis `GetBoundingBoxByUCS` semantics remain unverified.
- Records final known-answer inputs proposed for `GetEntityPointDistance` and `GetPiercingPoints`; those APIs remain NOT TESTED until the controlled final 07C-1 run.
- Carries forward a proposed 30° Z-rotated UCS check for 07C-1R2; no such model/tool change is implemented in this handoff.
- 07C-1 remains OPEN; 07C-2 remains BLOCKED pending explicit user closure approval.


## 0.20.13 — 2026-09-30 — Step 07C-1R5 Final Geometry Semantics Run Preparation

- Re-analysed existing 07A reflection evidence before requesting any additional live run. Installed signature is `GetPiercingPoints(iDirection, iBasePositin, iEntList)`.
- Identified the diagnostic argument-order defect: 0.20.12 passed `(origin, direction, targets)` instead of `(direction, basePosition, targets)`.
- Confirmed the 0.20.12 returned points lie exactly on the lines implied by the swapped calls; the intended “miss” and “pointing away” cases therefore cannot answer ray-vs-infinite-line semantics.
- Corrected only the development diagnostic mapping and added explicit evidence of direction/base-position inputs.
- Final live batch is fixed at four piercing cases, two entity-point-distance cases, the UCS 251/reference 2 rotated-UCS check, and no-mutation evidence.
- Per user instruction, that next live geometry run is the final 07C-1 runtime experiment. Any remaining uncertainty is to be documented as a limitation and 07C-1 then closes.
- No production `src/**`, Plugin, CR/SA behavior, configuration, or model data changed.
- Validation: **AWAITING USER QUALITY GATE + FINAL LIVE RUN**. Agent did not build/test/run Cimatron.

## 0.20.14 — 2026-09-30 — 07C-1 Closure Session Handoff

- Added a new-session handoff recording the approved 07C-1 closure and final evidence state.
- Recorded that 07C-2 is unblocked but not started and still requires explicit scope approval.
- Updated the authoritative project time ledger and checksum manifest.
- No production/runtime/test/model behavior change.


## 0.20.17 — 2026-09-30 — 07C-2 Closure / Session Handoff

- Recorded workstation quality-gate PASS for 0.20.17 and the single approved live assembly-context run.
- Promoted U7/U8/U9/U10/U12 from pending to evidence-backed VERIFIED; U11 to PARTIALLY VERIFIED because UI assembly extents were unavailable for independent numeric comparison.
- Recorded user confirmation that all three highlighted bodies were correct, final selection was empty, no unsaved-change indicator remained, and 07C-2 closure was approved.
- Recorded direct cross-occurrence `MinDistancePos` as an assembly-placement limitation: all three pairs returned 0 despite distinct occurrence transforms and the independent 25.000 mm top-level B1 gap.
- Added final 07C-2 evidence files and a new-session closure handoff.
- Documentation/evidence only; no production, verifier runtime, test, configuration or model behavior changed.


## 0.20.27 — Phase 02 / Step 07C-4 Closure

- Closed Step 07C-4 after user workstation validation of the corrected U16 known-answer model.
- Archived final 0.20.26 quality evidence and controlled live evidence, plus the earlier governed blocked/diagnostic attempts needed for traceability.
- Promoted U16 to VERIFIED for the approved scope: `ICimEntity.Show` is body/entity visibility only; `cmVisibleOnly` BOM membership distinguishes the known hidden assembly occurrence.
- CR-11 FR-021 hidden-component detection is therefore supported by the read-only BOM filter route, subject to Step 08 in-process confirmation before production use.
- Final model no-mutation evidence: UNCHANGED.
- Documentation, capability register, history, session handoff, time ledger, evidence retention, version, and checksums only.
- No production `src/**`, Plugin, configuration, installer, CR/SA behavior, diagnostic runtime code, or model behavior changes.

## 0.20.28 — 2026-10-01 — Step 07D Verification Register and Promotion Recommendations

- Finalizes the Step 07 evidence register as the formal Step 08 eligibility gate.
- Defines the rule that only final-status `VERIFIED` capabilities may enter Step 08 in-process confirmation or later production-port / first-CR-slice consideration.
- Whitelists U1, U3, U4, U5, U6, U7, U8, U9, U10, U12, U13, U15 and U16 for Step 08 in-process confirmation.
- Excludes U2 and U11 because they remain `PARTIALLY VERIFIED` and excludes U14/U17 because no evidence-backed readable API is available for the required use.
- Retains the exact U16 semantic split: `ICimEntity.Show` for body/entity visibility; `cmVisibleOnly` BOM membership for hidden occurrence detection.
- Carries `ST06-DF-01` through `ST06-DF-06` forward unchanged as `DEFERRED`.
- Documentation/governance only; no production source, Plugin, configuration, installer, diagnostic runtime, test, CR/SA, or model behavior changed.
- Status: **IMPLEMENTATION PREPARED / AWAITING USER REVIEW**. Step 08 is not started.

## 0.23.0 — 2026-10-02 — CR-04 Slice 1 Domain Rules

- Added pure Domain models and normalization/evaluation logic for CR-04 Steel Grade Design-Order Validation.
- Added strict text and Werkstoff-canonical grade handling, whitespace/token normalization, DO numeric-ambiguity protection, duplicate-key detection, missing/ambiguous CAD-grade handling, coverage findings, and Option C source-disagreement support.
- Recorded provisional Slice 1 decisions: D-08 coverage behavior, D-14 multi-body/duplicate-key behavior, and D-16 blank DO grade as `DO_GRADE_MISSING` Error pending customer confirmation.
- Added CR-04 Domain tests and registered all three new fixtures in the repository's custom `Domain.Tests/Program.cs` runner so they execute under the governed test command.
- Bumped only `CimatronCustomization.Domain` production assembly metadata to `0.23.0.0`; other production assemblies remain unchanged.
- Added Step 08B C-02 traceability note to implementation history without modifying the closed 08B handoff.
- No Cimatron COM/Interop adapter, tabular reader, configuration, feature registration, Plugin behavior, highlighter, or client runtime behavior changed.
- Validation: **AWAITING USER EXECUTION**. Agent did not run build/tests/coverage/static analysis/Cimatron.

## 0.24.0 — 2026-10-02 — CR-04 Slice 2A Capability Investigation

### Added
- Development-only `Cr04CapabilityVerification` and `--verify-cr04-capabilities` mode.
- Highlighter-equivalent occurrence-scope evidence, self-instance PID identification, D-15 `InstanceId` collision measurement, body attribute semantic observations, and no-mutation evidence.
- `Cr04TraversalSafetyTests` covering production `FindInstance()` source contract, fake-tree traversal equivalence, self-instance collision scope, suppressed collisions, and depth 16.

### Changed
- Registered the new verifier source and CimatronIntegration test fixture in their explicit project/test runners.
- Development verifier and CimatronIntegrationTests metadata advanced to 0.24.0.0.
- Recorded CR-04 Slice 1 / 0.23.1 as user validated from supplied clean build/test/coverage evidence.

### Unchanged
- No production `src/**` behavior changed.
- `CimatronViewportEntityHighlighter` remains unchanged.
- No CR-04 business orchestration/adapter is introduced.
- No model mutation/setup is performed by this diagnostic.

## 0.24.1 — 2026-10-02 — CR-04 Slice 2A Analyzer Warning Corrective

### Corrected
- Removed the three user-observed `CA1859` warnings in `Cr04TraversalSafetyTests.cs` by using concrete `List<T>` return/property types where the test implementation already constructs and owns `List<T>` instances.
- Advanced only the changed CimatronIntegrationTests assembly metadata to `0.24.1.0`.

### Unchanged
- No verifier behavior changed.
- No production `src/**` file changed.
- No traversal, self-instance, collision, attribute, no-mutation, Cimatron API, or CR-04 business semantics changed.

### Validation
- Entering 0.24.0 workstation evidence: Release x64 build PASS, all governed suites PASS, coverage/local quality gates PASS, exit code 0, but 3 analyzer warnings / 0 errors.
- 0.24.1 status: **CORRECTIVE PREPARED / AWAITING USER CLEAN QUALITY GATE**. Agent did not build/test/run coverage or Cimatron.

## 0.25.0 — 2026-10-04 — Post-Slice-2 Session Handoff

### Documentation
- Added a governed new-session handoff after CR-04 Slice 2 closure.
- Added a ready-to-paste new-session prompt.
- Carried forward the five unresolved Slice 2A gates and the rule that Slice 3 remains blocked.
- Preserved the user-validated 0.25.0 quality-gate result and the packaging/recovery incident classification.

### Runtime / Production
- No production source, test behavior, configuration, Cimatron model, adapter, highlighter, or runtime behavior changed.

## 0.25.0 — 2026-10-04 — CR-04 Slice 2A Revised Closure Plan / Package 1 Dispositions

- Documentation/governance only; no `src/**`, `tools/**`, tests, config, Cimatron model, or CR-04 v1.4 specification change.
- Added the user-approved revised Slice 2A closure plan verbatim in `docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md`; approval date is 2026-10-04 and the exact approval timestamp was not captured.
- Records that the earlier five-gate plan is superseded and that these dispositions deliberately supersede the v1.4 §8.3 / §17 Slice 2A pre-adapter list for the named items.
- D-15(b) placement-specific mapping: **DEFERRED**.
- Collision-frequency measurement: **MOVED TO SLICE 5** closure evidence.
- D-17 Assist Parts: **EXCLUDED-PROVISIONAL** pending customer answer.
- Wrong-type attribute semantics: **FAIL-SAFE RULE** with genuine non-string evidence moved to Slice 3 adapter smoke and a mandatory stop for user decision if the wrong-type control returns a conforming-looking value.
- Slice 2A remains **OPEN — one gate remaining: top-level highlight (Package 2)**.
- Package 2 retains two hard stops: existing top-level highlighter support must be proven from full-repository source, and the selected top-level KA-PART-1 occurrence must have an `InstanceId` unique across the full highlighter-equivalent traversal.

## 0.25.0 — 2026-10-04 — CR-04 Slice 2A Package 1A Handoff Consistency Corrective

### Corrected
- Replaced `NEW-SESSION-PROMPT-CR04-0.25.0.txt` so a new session starts from the governed revised plan and plans only Package 2.
- Rewrote the post-Slice-2 handoff into one consistent current-state document with exactly one `Exact next step`.
- Added an authoritative current-status section to `VERSION.md` and marked historical five-gate statements as superseded.
- Preserved Package 1's four dispositions and the verbatim governing plan unchanged.

### Version / Runtime
- Product version deliberately remains `0.25.0`; this is documentation/governance-only corrective work.
- No product, `src/**`, tool, test, config, Cimatron model, CR-04 v1.4 spec, or runtime behavior changed.
- Package is an overlay and must not replace the full repository.


## 0.26.1 — CR-04 Slice 2A Package 2 quality-gate corrective

- Corrected two Package 2 Cimatron API member usages discovered by the first user workstation Release build: `ICimDocument.Title` is used for the active document title and `ICimDocument.GetPath()` for the document path.
- Replaced repeated inline test array arguments with `static readonly` arrays to address the four reported CA1861 diagnostics without changing test coverage or behavior.
- Preserved the existing developer-only opt-in diagnostic semantics, runtime target-selection rules, one-live-run stop rule, Slice 3 block, and blocking client-packaging removal obligation.
- Quality-gate status: **AWAITING USER EXECUTION**. No PASS is claimed.
- Captured execution must use `tools/Invoke-And-Capture.ps1 -Task quality-gate`; output is written to `artifacts/console-captures/quality-gate-<timestamp>.txt`.

## 0.26.0 — CR-04 Slice 2A Package 2 top-level highlight diagnostic

- Added opt-in top-level highlight diagnostic with runtime D-15(a)-safe target selection.
- Added pure selector and feature tests, plus architecture guards for gating, read-only behavior and the protected highlighter SHA-256.
- Preserved `CimatronViewportEntityHighlighter.cs`, Step 08B adapters/features, CR-04 0.25.0 Application/Domain code, models and v1.4 specification unchanged.
- Recorded Package 1 / 1A user validation.
- BLOCKING: remove the diagnostic registration, all eight diagnostic source files, the request script and the two diagnostic test files under a separately approved change before any client package is built.
- Package 2 remains awaiting user quality gate and one governed live highlight run.


## 0.26.2 — CR-04 Slice 2A Package 2 DesignChecks coverage corrective

### Corrected
- Added focused test coverage for `TopLevelHighlightDiagnosticFeature.Definition`, executing the diagnostic's static `FeatureDefinition` initialization.
- Added focused constructor-guard coverage verifying null reader rejection.
- Advanced required Package 2 PATCH metadata to `0.26.2`.

### Unchanged
- No production diagnostic runtime semantics changed.
- No Cimatron API, traversal, D-15 selection, highlight reference, registration gate, or no-mutation behavior changed.
- Slice 3 remains blocked and the one-live-run stop rule remains in force.

### Validation
- Entering 0.26.1 workstation evidence: Release x64 build PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage collection PASS; DesignChecks measured `92.48%` against required `95%`, so the quality gate failed.
- 0.26.2 status: **CORRECTIVE PREPARED / AWAITING USER CLEAN CAPTURED QUALITY GATE**. Agent did not build/test/run coverage or Cimatron.


## 0.26.2 — 2026-10-05 — Session handoff / quality-gate closure / startup investigation state

### Documentation
- Recorded user-validated Package 2 workstation quality gate PASS from `quality-gate-20261005-001015.txt` (00:10:15–00:10:56 +05:30).
- Recorded DesignChecks coverage recovery to 98.33% and local quality-gate exit code 0.
- Recorded two pre-Feature-Launcher Cimatron startup crashes with diagnostic environment variable enabled at 00:19:29 and 00:20:26 +05:30 (`ucrtbase.dll`, `0xc0000409`).
- Preserved the user's clarification that the first launch was unexpected/uncertain and the second was a deliberate confirmation attempt, not two governed diagnostic executions.
- Added AMBER new-session handoff and ready-to-paste new-session prompt.

### Runtime
- No production/runtime/test logic changed.
- Live top-level-highlight diagnostic remains NOT EXECUTED / NOT VALIDATED.
- Slice 3 remains BLOCKED.

## 0.26.3 — 2026-10-05 — CR-04 Slice 2A Package 2 request-file opt-in corrective

### CA1806 test-only corrective after workstation quality-gate feedback
- User-supplied capture `quality-gate-20261005-015308.txt` completed with Release x64 build PASS, all governed test suites PASS, coverage/local quality gates PASS and exit code 0, but the Release build contained one CA1806 warning in `TopLevelHighlightDiagnosticFeatureTests.cs`; therefore the governed 0-warning acceptance condition was not met.
- After explicit user approval, the warning-producing null-reader constructor assertion now consumes the intentionally created instance with `GC.KeepAlive(...)`. No production source, runtime behavior, project file, assembly version, diagnostic registration, request-file behavior, or live-run state changed.
- Status remains **AWAITING USER QUALITY GATE**. The single governed Cimatron live run remains unused and is not authorized until a clean captured gate shows 0 warnings / 0 errors and exit code 0.

### Corrected
- Restored `docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md` byte-identically from Package 1; SHA-256 `6b6d3f9ca1c2c56bbce45a3b438e37b8a5baba25d4de917a37c5ae6ce7b9d320`.
- Replaced the Package 2 environment-variable gate with a one-shot request-file gate so Cimatron can be started through the normal shortcut. `TopLevelHighlightDiagnosticRequest.TryConsume()` atomically moves the request before reading, accepts only `Version=0.26.3` and an `O`-format `RequestedUtc` 0–30 minutes old, and deletes the consumed file in `finally`; invalid/stale requests fail closed with one warning that the diagnostic is not registered.
- Added `tools/Request-TopLevelHighlightDiagnostic.ps1`; it creates or cancels the two-line request using UTF-8 without BOM, never launches Cimatron, and does not set environment variables.
- Corrected the diagnostic reader contract: one outer exception boundary after argument validation; before-snapshot immediately after active-document acquisition; assembly title from `(assembly as IModel).Title`, compared `OrdinalIgnoreCase`, with observed title in mismatch evidence; every exception returns `[TOPLEVEL_HIGHLIGHT_API_ERROR]` with no reference.
- Replaced the boolean no-mutation flag with `TopLevelHighlightNoMutationState { NotEvaluated, Unchanged, Changed }`; mutation change produces `[TOPLEVEL_HIGHLIGHT_MUTATION_DETECTED]` with no reference.
- Tightened the feature contract: Passed is promoted only for `Status=Passed`, non-null reference, and `Unchanged`; every other shape returns `[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR]` with no reference. Evidence renders `ProgrammaticNoMutation=PASS/CHANGED/NOT_EVALUATED`.
- Added the three approved feature-contract tests and strengthened architecture guards for the request-file gate, retired environment-variable absence, request-filename isolation, reader API/known-answer restrictions, explicit Plugin Compile entry, and the existing highlighter SHA-256 pin.
- Advanced Plugin, CimatronIntegration, Application and DesignChecks assembly/file versions to `0.26.3.0` only.

### User-supplied startup evidence recorded
- Application Error 1000 at `2026-10-05 00:19:29` and `00:20:26 +05:30`: `CimatronE.exe` `2026.201.2064.662`, `ucrtbase.dll` `10.0.26100.9444`, exception `0xc0000409`, offset `0x00000000000a527e`; WER BEX64 events followed at `00:19:42` and `00:20:34` with P9 `0000000000000007`.
- No .NET Runtime event was observed in the stated `00:18:00–00:22:00` window. The newest `Report.wer` listed 484 modules and none matching `CimatronCustomization*`; CLR modules were loaded, and the last modules were Windows network-provider/DNS components.
- Archived Cimatron crash folders dated `2026-09-24 14:02:47`, `14:03:32`, `14:04:16` and `2026-10-05 00:19:42`, `00:20:34` share signature hash `7219b3c5d95cc49671cc40693829127e67932033_70c7052e`, proving the same crash signature predates Package 2.
- Before the normal control, the diagnostic variable was empty at Process/User/Machine scope, the session was not elevated and no `CimatronE` process was running. A normal shortcut start failed before restart with no crash event; after PC restart, normal shortcut start succeeded with 0.26.2 deployed. Feature Launcher showed exactly five normal features and no CR-04 diagnostic; no feature was run. Start/exit times were not captured.
- Recorded conclusion: transient workstation/Cimatron fault cleared by restart; root cause not established. Package 2 code and the historical environment-variable opt-in are not implicated. The live diagnostic has never run and the single governed live run remains unused.

### Packaging / validation
- Client packaging remains BLOCKED until the diagnostic registration, all eight diagnostic source files (existing seven plus `TopLevelHighlightDiagnosticRequest.cs`), `tools/Request-TopLevelHighlightDiagnostic.ps1`, and the two diagnostic test files are removed under separately approved scope.
- The prior 0.26.0/0.26.1/0.26.2 Package 2 handoffs are marked SUPERSEDED and retained only as history.
- AI agent did not build, execute tests/coverage, deploy, run the request script, or launch Cimatron. User quality gate and the single governed live run remain pending.


## 0.26.4 — 2026-10-05 — CR-04 Slice 2A Package 2 temporary-highlight restoration corrective

- Records the approved replacement 0.26.3 live run on `Model\KA-ASM-1-Step07C4-U16-single-part-corrected\CR11_BASELINE\KA-ASM-1.elt`, correlation `e9a94f01c46c4dadb0e323d0ef18f3a9`: Result Report Passed, `[TOPLEVEL_HIGHLIGHT_TARGET_READY]`, intended top-level `KA-PART-1` highlight visually confirmed, no unrelated occurrence highlighted, programmatic no-mutation PASS, assembly unmodified, but highlight restoration after Result Report close = NO. Package 2 therefore remained OPEN.
- Root cause: Result Report invoked `IViewportEntityHighlighter.Highlight(...)` but close/dispose did not invoke restoration; the highlighter replaced `ISelection.Selection` without retaining/restoring the previous selection.
- Adds `RestoreSelection()` to the Application highlighter port. The Cimatron adapter captures the pre-highlight selection only before the first temporary highlight assignment, keeps the approved traversal/entity mapping unchanged, and restores the captured selection (or an explicit empty list for an originally empty selection).
- Result Report restores the temporary highlight in `OnFormClosed`, covering button close, window close, and disposal-driven form closure without swallowing restore exceptions.
- Replaces the Package 2 byte-hash pin on `CimatronViewportEntityHighlighter.cs` with narrow architecture guards that preserve the verified traversal/mapping/highlight boundary while allowing the explicitly approved restore lifecycle. CimatronIntegration source-contract tests also guard selection capture/restore and Result Report close wiring.
- Aligns the one-shot diagnostic request, diagnostic feature traceability version, and request script to `0.26.4`; advances Plugin, CimatronIntegration, Application and DesignChecks assembly/file versions to `0.26.4.0`.
- User workstation quality gate `quality-gate-20261005-025934.txt`: Release x64 PASS, `0` warnings / `0` errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage collection/gate PASS, local quality gate PASS, exit code `0`; capture ran `2026-10-05T02:59:34.0925662+05:30` to `2026-10-05T03:00:32.5420808+05:30`.
- Governed live validation on the approved fixture confirmed `[TOPLEVEL_HIGHLIGHT_TARGET_READY]`, intended top-level `KA-PART-1` highlighted, no unrelated occurrence highlighted, highlight restored/cleared after Result Report close = YES, and assembly remained unmodified = YES.
- User closure approval receipt recorded at `2026-10-05T03:14:41+05:30`. Package 2 corrective acceptance is satisfied: **CLOSED / USER VALIDATED**.
- Agent did not execute build/tests/coverage/Cimatron; all validation PASS statements are user-supplied workstation/runtime evidence.

## 0.26.4 — 2026-10-05 — Slice 2A to Slice 3 Planning Session Handoff

- Adds a cumulative new-session handoff and ready-to-paste prompt after user-validated Slice 2A Package 2 closure.
- Records that Slice 3 adapter planning may now be requested, but Slice 3 implementation is not approved by this handoff.
- Carries forward the approved dispositions unchanged: D-15(b) DEFERRED; collision-frequency MOVED TO SLICE 5; D-17 EXCLUDED-PROVISIONAL; wrong-type semantics FAIL-SAFE RULE.
- Makes the genuine same-name stored-as-non-string/wrong-type smoke an explicit mandatory Slice 3 planning/acceptance concern.
- Carries forward the separate blocking client-package diagnostic-removal obligation without authorizing that cleanup.
- Documentation/governance/checksum/package-only handoff; no source, tests, runtime behavior, configuration, model, or installer behavior changed.


## 0.27.5 — 2026-10-05 — Slice 3 in-process smoke planning session handoff

### Documentation / governance
- Recorded clean user workstation `0.27.5` quality-gate evidence: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gates PASS, exit code 0.
- Recorded the `0.27.5` standalone smoke failure as **INVALID SMOKE HARNESS EVIDENCE**: `CimApplicationProvider` activation from the test EXE failed with `REGDB_E_CLASSNOTREG (0x80040154)` before production-adapter acceptance evidence was obtained.
- Recorded the authoritative Cimatron API clarification that EXE projects use `CimAppAccess.AppAccess`, while class/in-process projects use `CimServicesAPI.CimApplicationProvider`.
- Added an AMBER session handoff and ready-to-paste new-session prompt directing the next session to plan a developer-only in-process plugin smoke and obtain explicit approval before implementation.

### Unchanged
- Product/code version remains `0.27.5`; no source, test, tool, runtime, configuration, model, installer, or production adapter behavior changed in this handoff package.
- No adapter PASS/FAIL is claimed from either invalid external smoke attempt.


## 0.30.0 — 2026-10-05 — D-02 controlled steel-grade evidence validated / session handoff

- Accepted user workstation `quality-gate-20261005-221151.txt`: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Recorded two safe failed helper attempts while the active document was still `cmAssembly`; both stopped before mutation.
- Recorded successful controlled helper execution at `2026-10-05T22:20:13.7867815+05:30` on standalone disposable `KA-PART-1-CR04-WRONG-TYPE`, entity/body `4`: attached `STEEL_GRADE=P-20-2311` as `cmAttString`, exact string value read back, `MutationPerformed: YES`, autosave disabled.
- User confirmed the disposable Part was manually saved. Exact chat receipt timestamp is not independently captured and is not invented.
- Accepted separate read-only capability evidence timestamped `2026-10-05T22:24:44.8894448+05:30`: exact `cmAttString` lookup found `P-20-2311` on occurrence `root/10:14`, body `4`; exactly one exact known-value occurrence; no string read errors; `NoMutation.Result: PASS`; assembly file timestamp and size unchanged.
- Recorded Cimatron API observation that returned attribute `Name` is blank even though exact named lookup succeeds.
- Recorded diagnostic wrong-type observation on the same body: exact same name queried as `cmAttInteger` returned value `144`. Production CR-04 must therefore continue exact `cmAttString` lookup only and must not probe/fallback to alternate types.
- D-02 body-level string evidence is now VERIFIED for the current direction: configured attribute name `STEEL_GRADE`, type `cmAttString`.
- Next governed step is a narrow read-only in-process smoke extension for the actual production `CimatronAssemblyBodyAttributeReader`; current smoke remains hard-coded to the earlier wrong-type control.
- Added cumulative post-validation session handoff and next-session prompt. Raw workstation/runtime evidence remains excluded from the ZIP. No production `src/**`, test/tool logic, project/config, or requirement-specification changes were made for this documentation-only handoff.


## 0.31.0 — 2026-10-05 — CR-04 v1.5 Slice 1 Design-Order Form reader

- Added Application contracts for Form/Table format selection and typed read-only Form profile/category results.
- Added read-only `ExcelDesignOrderFormReader` with `.xlsx`/`.xls` support, exact worksheet selection, whitespace-normalized ordinal template guard, anchored label/grade reading, configured vocabulary-range reading, and fail-closed Form-specific errors.
- Added `SrideviQrDg02Rev04Profile` defining the approved `QR/DG/02 REV 04` production layout without embedding the client workbook.
- Added anonymized CR-04 Form fixture and explicit Infrastructure runner registration for Form-reader tests.
- Added Architecture protection for the eight approved byte-identical 0.30.1 files, Form read-only tokens, Form/Table separation, test registration, anonymized fixture presence, and production `4075*.xlsx` absence.
- Generic Table reader/orchestration, production Cimatron attribute reader, Domain comparison/normalizer, highlight safety/highlighter, DesignChecks, Plugin composition/config and Cimatron models are unchanged.
- Agent did not execute build/tests/coverage/Cimatron. Workstation quality gate is required before Slice 2.


## 0.31.1 — 2026-10-06 — CR-04 v1.5 Slice 1 warning corrective

- Fixes the two analyzer warnings reported by the user-supplied 0.31.0 workstation gate without changing behavior.
- Changes private `ExcelDesignOrderFormReader.ReadRows(...)` to return its concrete `List<object[]>` result (CA1859).
- Reuses a `static readonly` expected-grade array in `ExcelDesignOrderFormReaderTests` (CA1861).
- No production feature semantics, Form profile, Table path, Domain logic, Cimatron adapter, configuration, dependency or fixture changes.
- Full workstation quality gate must be rerun; Slice 2 remains blocked until a clean 0-warning / 0-error result is reviewed.

## 0.32.0 — 2026-10-06 — CR-04 v1.5 Slice 2 category mapping + Form/Table orchestration

- Adds a distinct Domain `ResultStatus.Info` under the separately approved Slice 2 scope amendment; informational findings do not escalate a Passed validation aggregate.
- Adds Application category-pattern/configuration/resolution services with optional category-attribute precedence, configured ModelTitle pattern mapping, exclusions, unmapped/ambiguous fail-safe outcomes, and case-sensitive `*`/`?` ModelTitle glob matching.
- Adds closed-vocabulary validation for both Design-Order and Cimatron steel-grade values under the approved comparison policy.
- Extends `VerifySteelGradeAgainstDesignOrderRequest` with Form-mode profile/category configuration while preserving the existing Table constructor/path.
- Extends `VerifySteelGradeAgainstDesignOrder` with Form orchestration: D-04 mapping, D-05 vocabulary warnings, D-16 blank-grade behavior, category-keyed many-to-one Domain input, exclusion Info, and mould-number-not-performed Info.
- Adds/extends Domain, Application, and Architecture tests with explicit runner registration.
- Preserves the eight approved v1.5 protected files byte-identically; no Plugin/config/Cimatron model/client-workbook changes.
- Agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Full user workstation quality gate is required before closure.


## 0.32.1 — 2026-10-06 — CR-04 v1.5 Slice 2 warning corrective

- Records user-supplied `quality-gate-20261006-004117.txt`: Release x64 PASS, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage/local gate PASS, exit code 0, but **11 warnings / 0 errors**; zero-warning Slice 2 closure therefore remained blocked.
- Corrects CA1859 in `VerifySteelGradeAgainstDesignOrder.cs` by returning the already materialized `ModelEntityReference[]` from private `CollectReferences(...)`; no public contract or business-rule behavior changes.
- Corrects the ten CA1861 warnings in Slice 2 Application tests by replacing only the flagged constant array arguments with `static readonly` test data.
- No category-resolution semantics, Form/Table orchestration, vocabulary policy, D-16 behavior, Domain evaluator, Plugin/config/Cimatron model, client workbook, dependencies, or protected files changed.
- Agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. A fresh full user workstation quality gate with 0 warnings / 0 errors is required before Slice 2 closure.


## 0.32.1 — 2026-10-06 — CR-04 v1.5 Slice 2 closure

- Closes Slice 2 on user-supplied workstation evidence `quality-gate-20261006-004944.txt`.
- Accepted gate: Release x64 PASS, **0 warnings / 0 errors**, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage collection/gate PASS, local quality gate PASS, exit code 0.
- Accepted coverage: Domain 99.74%, Application 92.95%, DesignChecks 98.32%, Infrastructure 82.27%, CimatronIntegration 2.08% measured/no threshold.
- Slice 2 category mapping, Form/Table orchestration, vocabulary handling, D-16 behavior and Info semantics are therefore CLOSED / USER VALIDATED.
- This closure changes documentation/governance/checksums/package only; no production source, tests, config, dependencies, models, category behavior, Form/Table routing, Domain evaluator, Cimatron adapter or highlighter behavior is changed.
- Raw workstation evidence and the production client workbook remain excluded from the cumulative ZIP.
- Next controlled step is Slice 3 feature/config/composition wiring after a fresh exact-scope review/approval; unresolved client-specific production mappings remain blockers to final CR-04 production closure.

## 0.38.3 — CR-04 Part Material correlation diagnostic

- Added a developer-controlled, one-shot, 30-minute, read-only in-process diagnostic for the approved CR-04 target components.
- Reuses `CimatronAssemblyBodyAttributeReader`, `CimatronBomMaterialTableReader`, `ExcelTabularDataReader`, and `SteelGradeCategoryResolver`; no new Cimatron API route is introduced.
- Captures target occurrence `ModelTitle`, BOM `Standard Number`, BOM `Material`, resolved category, and the exact production case-insensitive correlation result.
- Captures the complete BOM `Standard Number` / `Material` snapshot to diagnose non-exact correlation without changing production matching behavior.
- Added an architecture guard enforcing one-shot expiry, explicit Plugin wiring, production-reader reuse, and read-only behavior.
- Production CR-04 logic/config/category mapping/DO parsing/material vocabulary/model/workbook/dependencies remain unchanged.
- Version advanced to 0.38.3 for the diagnostic package. Workstation quality gate and live Cimatron diagnostic remain user-run gates.
