[CmdletBinding()]
param(
    [switch]$Cancel
)

$ErrorActionPreference = 'Stop'
$requestDirectory = Join-Path ([System.IO.Path]::GetTempPath()) 'CimatronCustomization'
$requestPath = Join-Path $requestDirectory 'cr04-slice3-wrong-type-in-process-smoke.request'

if ($Cancel) {
    if (Test-Path -LiteralPath $requestPath) {
        Remove-Item -LiteralPath $requestPath -Force
        Write-Host 'Cancelled CR-04 Slice 3 wrong-type in-process smoke request.'
    }
    else {
        Write-Host 'No CR-04 Slice 3 wrong-type in-process smoke request exists.'
    }
    return
}

$repositoryRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$evidenceDirectory = Join-Path $repositoryRoot 'artifacts\diagnostics'
[System.IO.Directory]::CreateDirectory($requestDirectory) | Out-Null
[System.IO.Directory]::CreateDirectory($evidenceDirectory) | Out-Null
$timestamp = [DateTimeOffset]::Now.ToString('yyyyMMdd-HHmmss', [System.Globalization.CultureInfo]::InvariantCulture)
$evidencePath = Join-Path $evidenceDirectory ("cr04-slice3-in-process-smoke-$timestamp.txt")

$lines = @(
    'Version=0.27.6'
    ('RequestedUtc=' + [DateTimeOffset]::UtcNow.ToString('O', [System.Globalization.CultureInfo]::InvariantCulture))
    ('EvidenceFile=' + $evidencePath)
)
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($requestPath, $lines, $utf8NoBom)

Write-Host 'Created one-shot CR-04 Slice 3 wrong-type in-process smoke request.'
Write-Host 'Open only KA-ASM-1-CR04-WRONG-TYPE-SMOKE, then click Cimatron Customization once within 30 minutes.'
Write-Host 'This script does not launch Cimatron.'
Write-Host ("Evidence will be written to: $evidencePath")
