using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("CimatronCustomization.KnownAnswerModelSetup")]
[assembly: AssemblyDescription("Development-only controlled setup helper for disposable Cimatron known-answer models")]
[assembly: AssemblyCompany("flux10x AI Systems")]
[assembly: AssemblyProduct("CimatronCustomization.KnownAnswerModelSetup")]
[assembly: ComVisible(false)]
[assembly: Guid("7fd41319-cf31-4a96-a2e2-8f27cfb53f08")]
[assembly: AssemblyVersion("0.30.0.0")]
[assembly: AssemblyFileVersion("0.30.0.0")]
