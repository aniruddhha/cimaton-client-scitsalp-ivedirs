using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace CimatronCustomization.KnownAnswerModelSetup
{
    internal static class Program
    {
        internal const string ToolVersion = "0.30.0";
        private const string RequiredAttributeName = "STEP07_B1_TEST_ATTRIBUTE";
        private const string RequiredAttributeValue = "KNOWN_ANSWER_07C3";
        private const string WrongTypeModelTitle = "KA-PART-1-CR04-WRONG-TYPE";
        private const string WrongTypeAttributeName = "CR04_WRONG_TYPE_CONTROL";
        private const string WrongTypeAttributeValue = "2738";
        private const string SteelGradeModelTitle = "KA-PART-1-CR04-WRONG-TYPE";
        private const string SteelGradeAttributeName = "STEEL_GRADE";
        private const string SteelGradeAttributeValue = "P-20-2311";

        private static int Main(string[] args)
        {
            try
            {
                Arguments parsed = Arguments.Parse(args);
                if (!parsed.Apply)
                    throw new ArgumentException("Mutation is disabled unless --apply is supplied explicitly.");
                if (!string.Equals(parsed.ExpectedContext, "Part", StringComparison.OrdinalIgnoreCase))
                    throw new ArgumentException("Known-answer setup requires --expect Part.");
                if (parsed.EntityId != 4)
                    throw new ArgumentException("Known-answer setup is restricted to --entity-id 4.");
                if (parsed.WrongTypeControl && parsed.SteelGradeControl)
                    throw new ArgumentException("Choose exactly one CR-04 controlled setup mode; --cr04-wrong-type-control and --steel-grade-control cannot be combined.");

                if (parsed.WrongTypeControl)
                {
                    ValidateWrongTypeControlArguments(parsed);
                    return ApplyWrongTypeControl(parsed);
                }

                if (parsed.SteelGradeControl)
                {
                    ValidateSteelGradeControlArguments(parsed);
                    return ApplySteelGradeControl(parsed);
                }

                ValidateLegacyArguments(parsed);
                return ApplyStringKnownAnswer(parsed);
            }
            catch (Exception ex)
            {
                Exception raw = Unwrap(ex);
                Console.Error.WriteLine("KNOWN-ANSWER SETUP FAILED: " + raw.GetType().FullName + ": " + raw.Message);
                return 1;
            }
        }

        private static void ValidateLegacyArguments(Arguments parsed)
        {
            if (!string.Equals(parsed.ModelTitle, "KA-PART-1", StringComparison.Ordinal))
                throw new ArgumentException("Known-answer setup is restricted to --model-title KA-PART-1.");
            if (!string.Equals(parsed.AttributeName, RequiredAttributeName, StringComparison.Ordinal))
                throw new ArgumentException("Known-answer setup requires --attribute-name " + RequiredAttributeName + ".");
            if (!string.Equals(parsed.AttributeValue, RequiredAttributeValue, StringComparison.Ordinal))
                throw new ArgumentException("Known-answer setup requires --attribute-value " + RequiredAttributeValue + ".");
        }

        private static void ValidateWrongTypeControlArguments(Arguments parsed)
        {
            if (!string.Equals(parsed.ModelTitle, WrongTypeModelTitle, StringComparison.Ordinal))
                throw new ArgumentException("CR-04 wrong-type setup is restricted to disposable --model-title " + WrongTypeModelTitle + ".");
            if (!string.Equals(parsed.AttributeName, WrongTypeAttributeName, StringComparison.Ordinal))
                throw new ArgumentException("CR-04 wrong-type setup requires --attribute-name " + WrongTypeAttributeName + ".");
            if (!string.Equals(parsed.AttributeValue, WrongTypeAttributeValue, StringComparison.Ordinal))
                throw new ArgumentException("CR-04 wrong-type setup requires --attribute-value " + WrongTypeAttributeValue + ".");
        }

        private static void ValidateSteelGradeControlArguments(Arguments parsed)
        {
            if (!string.Equals(parsed.ModelTitle, SteelGradeModelTitle, StringComparison.Ordinal))
                throw new ArgumentException("CR-04 steel-grade setup is restricted to disposable --model-title " + SteelGradeModelTitle + ".");
            if (!string.Equals(parsed.AttributeName, SteelGradeAttributeName, StringComparison.Ordinal))
                throw new ArgumentException("CR-04 steel-grade setup requires --attribute-name " + SteelGradeAttributeName + ".");
            if (!string.Equals(parsed.AttributeValue, SteelGradeAttributeValue, StringComparison.Ordinal))
                throw new ArgumentException("CR-04 steel-grade setup requires --attribute-value " + SteelGradeAttributeValue + ".");
        }

        private static int ApplyStringKnownAnswer(Arguments args)
        {
            return ApplyAttribute(
                args,
                interop.CimBaseAPI.AttributeEnumType.cmAttString,
                args.AttributeValue,
                "CIMATRON STEP 07 KNOWN-ANSWER MODEL SETUP",
                "cmAttString",
                "ATTACHED_AND_READ_BACK",
                "DO NOT CONTINUE TO 07C-3 UNTIL KA-PART-1 IS SAVED AND KA-ASM-1 IS REOPENED/RELOADED.");
        }

        private static int ApplyWrongTypeControl(Arguments args)
        {
            int integerValue = int.Parse(args.AttributeValue, NumberStyles.Integer, CultureInfo.InvariantCulture);
            return ApplyAttribute(
                args,
                interop.CimBaseAPI.AttributeEnumType.cmAttInteger,
                integerValue,
                "CIMATRON CR-04 SLICE 3 WRONG-TYPE CONTROL SETUP",
                "cmAttInteger",
                "WRONG_TYPE_CONTROL_ATTACHED_AND_READ_BACK",
                "SAVE ONLY THIS DISPOSABLE CONTROL MODEL, THEN USE A DISPOSABLE ASSEMBLY THAT REFERENCES IT FOR THE SLICE 3 ADAPTER SMOKE.");
        }

        private static int ApplySteelGradeControl(Arguments args)
        {
            return ApplyAttribute(
                args,
                interop.CimBaseAPI.AttributeEnumType.cmAttString,
                args.AttributeValue,
                "CIMATRON CR-04 D-02 STEEL-GRADE CONTROL SETUP",
                "cmAttString",
                "STEEL_GRADE_ATTACHED_AND_READ_BACK",
                "SAVE ONLY THIS DISPOSABLE PART AFTER CONFIRMING THE READ-BACK, THEN STOP. THE SEPARATE PRODUCTION-READER VALIDATION MUST REMAIN READ-ONLY.");
        }

        private static int ApplyAttribute(
            Arguments args,
            interop.CimBaseAPI.AttributeEnumType attributeType,
            object attributeValue,
            string evidenceTitle,
            string expectedTypeName,
            string successResult,
            string continuationInstruction)
        {
            StringBuilder evidence = new StringBuilder();
            object appAccessObject = null;
            object applicationObject = null;
            object documentObject = null;
            try
            {
                evidence.AppendLine(evidenceTitle);
                evidence.AppendLine("ToolVersion: " + ToolVersion);
                evidence.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture));
                evidence.AppendLine("Operation: CONTROLLED_MODEL_MUTATION");
                evidence.AppendLine("AutoSave: DISABLED");
                evidence.AppendLine("WrongTypeControlMode: " + (args.WrongTypeControl ? "YES" : "NO"));
                evidence.AppendLine("SteelGradeControlMode: " + (args.SteelGradeControl ? "YES" : "NO"));

                appAccessObject = new interop.CimAppAccess.AppAccess();
                applicationObject = ((interop.CimAppAccess.AppAccess)appAccessObject).GetApplication();
                if (applicationObject == null) throw new InvalidOperationException("Cimatron is not running or unavailable.");
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)applicationObject;

                documentObject = application.GetActiveDoc();
                if (documentObject == null) throw new InvalidOperationException("Cimatron has no active document.");
                interop.CimatronE.ICimDocument document = (interop.CimatronE.ICimDocument)documentObject;
                if (!string.Equals(document.Type.ToString(), "cmPart", StringComparison.Ordinal))
                    throw new InvalidOperationException("Active document must be a Part; observed " + document.Type + ".");

                interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
                if (container == null) throw new InvalidOperationException("Active Part does not expose IModelContainer.");
                interop.CimMdlrAPI.IModel model = container.Model as interop.CimMdlrAPI.IModel;
                if (model == null) throw new InvalidOperationException("Active Part does not expose IModel.");
                if (!string.Equals(model.Title, args.ModelTitle, StringComparison.Ordinal))
                    throw new InvalidOperationException("Active model title is '" + model.Title + "', expected '" + args.ModelTitle + "'.");

                interop.CimMdlrAPI.ICimEntity entity = model.GetEntityById(args.EntityId, model);
                if (entity == null) throw new InvalidOperationException("Entity " + args.EntityId.ToString(CultureInfo.InvariantCulture) + " was not found.");
                if (!string.Equals(entity.Type.ToString(), "cmBody", StringComparison.Ordinal))
                    throw new InvalidOperationException("Entity " + args.EntityId.ToString(CultureInfo.InvariantCulture) + " must be cmBody; observed " + entity.Type + ".");

                interop.CimBaseAPI.IAttributeSink sink = entity as interop.CimBaseAPI.IAttributeSink;
                if (sink == null) throw new InvalidOperationException("Controlled body does not expose IAttributeSink.");

                evidence.AppendLine("ActiveContext: Part");
                evidence.AppendLine("ModelTitle: " + model.Title);
                evidence.AppendLine("EntityId: " + args.EntityId.ToString(CultureInfo.InvariantCulture));
                evidence.AppendLine("EntityType: " + entity.Type);
                evidence.AppendLine("AttributeType: " + expectedTypeName);
                evidence.AppendLine("AttributeName: " + args.AttributeName);
                evidence.AppendLine("AttributeValue: " + Convert.ToString(attributeValue, CultureInfo.InvariantCulture));

                ExistingAttributeState state = InspectExisting(sink, args.AttributeName, expectedTypeName, attributeValue, evidence);
                if (state == ExistingAttributeState.AlreadyPresent)
                {
                    evidence.AppendLine("Result: ALREADY_PRESENT");
                    evidence.AppendLine("MutationPerformed: NO");
                    if (args.WrongTypeControl)
                        AppendStringQueryObservation(sink, args.AttributeName, evidence);
                    WriteEvidence(evidence, args.WrongTypeControl, args.SteelGradeControl);
                    Console.WriteLine(evidence.ToString());
                    return 0;
                }
                if (state == ExistingAttributeState.Conflict)
                    throw new InvalidOperationException("An attribute with the requested name already exists with a different type or value; overwrite is prohibited.");

                interop.CimBaseAPI.IAttributeFactory factory = (interop.CimBaseAPI.IAttributeFactory)application.GetAttributeFactory();
                if (factory == null) throw new InvalidOperationException("IApplication.GetAttributeFactory() returned null.");
                interop.CimBaseAPI.IAttribute attribute = factory.Create(attributeType, args.AttributeName);
                if (attribute == null) throw new InvalidOperationException("IAttributeFactory.Create(" + expectedTypeName + ", name) returned null.");
                attribute.Value = attributeValue;
                sink.Attach(attribute);

                interop.CimBaseAPI.IAttribute readBack = sink.GetAttribute(attributeType, args.AttributeName);
                if (readBack == null) throw new InvalidOperationException("Exact attribute read-back returned null after Attach().");
                string readBackValue = Convert.ToString(readBack.Value, CultureInfo.InvariantCulture);
                string readBackNameLine = "ReadBack.Name: " + readBack.Name;
                string readBackTypeLine = "ReadBack.Type: " + readBack.Type;
                string readBackValueLine = "ReadBack.Value: " + readBackValue;
                evidence.AppendLine(readBackNameLine);
                evidence.AppendLine(readBackTypeLine);
                evidence.AppendLine(readBackValueLine);
                Console.WriteLine(readBackNameLine);
                Console.WriteLine(readBackTypeLine);
                Console.WriteLine(readBackValueLine);

                if (!string.Equals(readBack.Type.ToString(), expectedTypeName, StringComparison.Ordinal) ||
                    !string.Equals(readBackValue, Convert.ToString(attributeValue, CultureInfo.InvariantCulture), StringComparison.Ordinal))
                    throw new InvalidOperationException("Exact named attribute read-back did not match the requested type/value.");

                if (args.WrongTypeControl)
                    AppendStringQueryObservation(sink, args.AttributeName, evidence);

                evidence.AppendLine("Result: " + successResult);
                evidence.AppendLine("MutationPerformed: YES");
                evidence.AppendLine("MODEL MUTATED IN MEMORY - MANUAL SAVE REQUIRED");
                evidence.AppendLine(continuationInstruction);

                WriteEvidence(evidence, args.WrongTypeControl, args.SteelGradeControl);
                Console.WriteLine(evidence.ToString());
                return 0;
            }
            finally
            {
                Release(documentObject);
                Release(applicationObject);
                Release(appAccessObject);
            }
        }

        private static ExistingAttributeState InspectExisting(
            interop.CimBaseAPI.IAttributeSink sink,
            string name,
            string expectedTypeName,
            object expectedValue,
            StringBuilder evidence)
        {
            object[] attributes = sink.GetAttributes();
            evidence.AppendLine("ExistingAttributeCount: " + (attributes == null ? 0 : attributes.Length).ToString(CultureInfo.InvariantCulture));
            if (attributes == null) return ExistingAttributeState.Absent;

            foreach (object item in attributes)
            {
                interop.CimBaseAPI.IAttribute attribute = item as interop.CimBaseAPI.IAttribute;
                if (attribute == null || !string.Equals(attribute.Name, name, StringComparison.Ordinal)) continue;
                string existingValue = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture);
                evidence.AppendLine("ExistingMatch.Name: " + attribute.Name);
                evidence.AppendLine("ExistingMatch.Type: " + attribute.Type);
                evidence.AppendLine("ExistingMatch.Value: " + existingValue);
                return string.Equals(attribute.Type.ToString(), expectedTypeName, StringComparison.Ordinal) &&
                       string.Equals(existingValue, Convert.ToString(expectedValue, CultureInfo.InvariantCulture), StringComparison.Ordinal)
                    ? ExistingAttributeState.AlreadyPresent
                    : ExistingAttributeState.Conflict;
            }

            return ExistingAttributeState.Absent;
        }

        private static void AppendStringQueryObservation(
            interop.CimBaseAPI.IAttributeSink sink,
            string name,
            StringBuilder evidence)
        {
            try
            {
                interop.CimBaseAPI.IAttribute stringQuery = sink.GetAttribute(
                    interop.CimBaseAPI.AttributeEnumType.cmAttString,
                    name);
                evidence.AppendLine("PostSetupCmAttStringQuery.Status: " + (stringQuery == null ? "ABSENT" : "PRESENT"));
                evidence.AppendLine("PostSetupCmAttStringQuery.NonNull: " + (stringQuery == null ? "NO" : "YES"));
                if (stringQuery == null)
                    return;

                evidence.AppendLine("PostSetupCmAttStringQuery.Type: " + stringQuery.Type);
                evidence.AppendLine("PostSetupCmAttStringQuery.Value: " + Convert.ToString(stringQuery.Value, CultureInfo.InvariantCulture));
                evidence.AppendLine("PostSetupCmAttStringQuery.Name: " + stringQuery.Name);
            }
            catch (COMException ex)
            {
                evidence.AppendLine("PostSetupCmAttStringQuery.Status: READ_ERROR");
                evidence.AppendLine("PostSetupCmAttStringQuery.ExceptionType: " + ex.GetType().FullName);
                evidence.AppendLine("PostSetupCmAttStringQuery.HResult: 0x" + ex.HResult.ToString("X8", CultureInfo.InvariantCulture));
                evidence.AppendLine("PostSetupCmAttStringQuery.Message: " + ex.Message);
                Console.WriteLine("PostSetupCmAttStringQuery.Status: READ_ERROR");
                Console.WriteLine("PostSetupCmAttStringQuery.HResult: 0x" + ex.HResult.ToString("X8", CultureInfo.InvariantCulture));
            }
        }

        private static void WriteEvidence(StringBuilder evidence, bool wrongTypeControl, bool steelGradeControl)
        {
            string directory = Path.Combine(Environment.CurrentDirectory, "artifacts", "diagnostics");
            Directory.CreateDirectory(directory);
            string prefix = wrongTypeControl
                ? "cr04-slice3-wrong-type-control-setup-"
                : steelGradeControl
                    ? "cr04-d02-steel-grade-control-setup-"
                    : "known-answer-body-attribute-setup-";
            string path = Path.Combine(directory, prefix + DateTimeOffset.Now.ToString("yyyyMMdd-HHmmss") + ".txt");
            File.WriteAllText(path, evidence.ToString(), new UTF8Encoding(false));
            Console.WriteLine("EvidenceFile: " + Path.GetFullPath(path));
        }

        private static Exception Unwrap(Exception ex)
        {
            return ex is System.Reflection.TargetInvocationException && ex.InnerException != null ? ex.InnerException : ex;
        }

        private static void Release(object value)
        {
            if (value != null && Marshal.IsComObject(value)) Marshal.FinalReleaseComObject(value);
        }

        private enum ExistingAttributeState { Absent, AlreadyPresent, Conflict }

        private sealed class Arguments
        {
            internal string ExpectedContext { get; private set; }
            internal string ModelTitle { get; private set; }
            internal int EntityId { get; private set; }
            internal string AttributeName { get; private set; }
            internal string AttributeValue { get; private set; }
            internal bool Apply { get; private set; }
            internal bool WrongTypeControl { get; private set; }
            internal bool SteelGradeControl { get; private set; }

            internal static Arguments Parse(string[] args)
            {
                Arguments parsed = new Arguments();
                for (int index = 0; index < args.Length; index++)
                {
                    string key = args[index];
                    if (string.Equals(key, "--apply", StringComparison.OrdinalIgnoreCase)) { parsed.Apply = true; continue; }
                    if (string.Equals(key, "--cr04-wrong-type-control", StringComparison.OrdinalIgnoreCase)) { parsed.WrongTypeControl = true; continue; }
                    if (string.Equals(key, "--steel-grade-control", StringComparison.OrdinalIgnoreCase)) { parsed.SteelGradeControl = true; continue; }
                    if (index + 1 >= args.Length) throw new ArgumentException("Missing value for " + key + ".");
                    string value = args[++index];
                    if (string.Equals(key, "--expect", StringComparison.OrdinalIgnoreCase)) parsed.ExpectedContext = value;
                    else if (string.Equals(key, "--model-title", StringComparison.OrdinalIgnoreCase)) parsed.ModelTitle = value;
                    else if (string.Equals(key, "--entity-id", StringComparison.OrdinalIgnoreCase)) parsed.EntityId = ParseInt(key, value);
                    else if (string.Equals(key, "--attribute-name", StringComparison.OrdinalIgnoreCase)) parsed.AttributeName = value;
                    else if (string.Equals(key, "--attribute-value", StringComparison.OrdinalIgnoreCase)) parsed.AttributeValue = value;
                    else throw new ArgumentException("Unknown argument " + key + ".");
                }
                return parsed;
            }

            private static int ParseInt(string key, string value)
            {
                int result;
                if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result))
                    throw new ArgumentException(key + " requires an integer.");
                return result;
            }
        }
    }
}
