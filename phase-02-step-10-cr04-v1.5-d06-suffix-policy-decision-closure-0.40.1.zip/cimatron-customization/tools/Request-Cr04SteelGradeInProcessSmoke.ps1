[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$PartFilePath,
    [switch]$Cancel
)

$ErrorActionPreference = 'Stop'
$requestDirectory = Join-Path ([System.IO.Path]::GetTempPath()) 'CimatronCustomization'
$requestPath = Join-Path $requestDirectory 'cr04-steel-grade-in-process-smoke.request'

if ($Cancel) {
    if (Test-Path -LiteralPath $requestPath) {
        Remove-Item -LiteralPath $requestPath -Force
        Write-Host 'Cancelled CR-04 steel-grade in-process smoke request.'
    }
    else {
        Write-Host 'No CR-04 steel-grade in-process smoke request exists.'
    }
    return
}

if ([string]::IsNullOrWhiteSpace($PartFilePath)) {
    throw 'PartFilePath is required. Pass the absolute path of the saved disposable KA-PART-1-CR04-WRONG-TYPE Part file.'
}

$partFile = [System.IO.Path]::GetFullPath($PartFilePath)
if (-not [System.IO.File]::Exists($partFile)) {
    throw "PartFilePath does not exist: $partFile"
}
if ([System.IO.Path]::GetFileNameWithoutExtension($partFile).IndexOf('KA-PART-1-CR04-WRONG-TYPE', [System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
    throw 'PartFilePath must identify the saved disposable KA-PART-1-CR04-WRONG-TYPE Part.'
}

$repositoryRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$evidenceDirectory = Join-Path $repositoryRoot 'artifacts\diagnostics'
[System.IO.Directory]::CreateDirectory($requestDirectory) | Out-Null
[System.IO.Directory]::CreateDirectory($evidenceDirectory) | Out-Null
$timestamp = [DateTimeOffset]::Now.ToString('yyyyMMdd-HHmmss', [System.Globalization.CultureInfo]::InvariantCulture)
$evidencePath = Join-Path $evidenceDirectory ("cr04-steel-grade-production-reader-smoke-$timestamp.txt")

$lines = @(
    'Version=0.30.1'
    ('RequestedUtc=' + [DateTimeOffset]::UtcNow.ToString('O', [System.Globalization.CultureInfo]::InvariantCulture))
    ('EvidenceFile=' + $evidencePath)
    ('PartFile=' + $partFile)
)
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($requestPath, $lines, $utf8NoBom)

Write-Host 'Created one-shot CR-04 steel-grade production-reader in-process smoke request.'
Write-Host 'Open only KA-ASM-1-CR04-WRONG-TYPE-SMOKE, then click Cimatron Customization once within 30 minutes.'
Write-Host 'The saved disposable Part file will also be checked for timestamp/length changes.'
Write-Host 'This script does not launch Cimatron.'
Write-Host ("Part file: $partFile")
Write-Host ("Evidence will be written to: $evidencePath")
