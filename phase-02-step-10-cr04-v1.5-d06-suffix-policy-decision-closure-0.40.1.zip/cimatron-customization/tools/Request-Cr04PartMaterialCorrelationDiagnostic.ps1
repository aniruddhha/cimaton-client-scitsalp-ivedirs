[CmdletBinding()]
param(
    [switch]$Cancel
)

$ErrorActionPreference = 'Stop'
$requestDirectory = Join-Path ([System.IO.Path]::GetTempPath()) 'CimatronCustomization'
$requestPath = Join-Path $requestDirectory 'cr04-part-material-correlation-diagnostic.request'

if ($Cancel) {
    if (Test-Path -LiteralPath $requestPath) {
        Remove-Item -LiteralPath $requestPath -Force
        Write-Host 'Cancelled CR-04 Part Material correlation diagnostic request.'
    }
    else {
        Write-Host 'No CR-04 Part Material correlation diagnostic request exists.'
    }
    return
}

$repositoryRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$evidenceDirectory = Join-Path $repositoryRoot 'artifacts\diagnostics'
[System.IO.Directory]::CreateDirectory($requestDirectory) | Out-Null
[System.IO.Directory]::CreateDirectory($evidenceDirectory) | Out-Null
$timestamp = [DateTimeOffset]::Now.ToString('yyyyMMdd-HHmmss', [System.Globalization.CultureInfo]::InvariantCulture)
$evidencePath = Join-Path $evidenceDirectory ("cr04-part-material-correlation-diagnostic-$timestamp.txt")

$lines = @(
    'Version=0.38.3'
    ('RequestedUtc=' + [DateTimeOffset]::UtcNow.ToString('O', [System.Globalization.CultureInfo]::InvariantCulture))
    ('EvidenceFile=' + $evidencePath)
)
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($requestPath, $lines, $utf8NoBom)

Write-Host 'Created one-shot CR-04 Part Material correlation diagnostic request.'
Write-Host 'Keep the updated CR-04 test-copy Assembly active, then click Cimatron Customization once within 30 minutes.'
Write-Host 'This diagnostic is read-only and does not launch Cimatron or modify/save the model or Design Order.'
Write-Host ("Evidence will be written to: $evidencePath")
