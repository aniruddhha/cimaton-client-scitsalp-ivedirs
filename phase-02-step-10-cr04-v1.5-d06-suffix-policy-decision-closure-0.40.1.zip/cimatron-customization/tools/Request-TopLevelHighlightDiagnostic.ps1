[CmdletBinding()]
param(
    [switch]$Cancel
)

$ErrorActionPreference = 'Stop'
$requestDirectory = Join-Path ([System.IO.Path]::GetTempPath()) 'CimatronCustomization'
$requestPath = Join-Path $requestDirectory 'cr04-slice2a-toplevel-highlight-diagnostic.request'

if ($Cancel) {
    if (Test-Path -LiteralPath $requestPath) {
        Remove-Item -LiteralPath $requestPath -Force
        Write-Host "Cancelled CR-04 Slice 2A top-level highlight diagnostic request."
    }
    else {
        Write-Host "No CR-04 Slice 2A top-level highlight diagnostic request exists."
    }
    return
}

[System.IO.Directory]::CreateDirectory($requestDirectory) | Out-Null
$lines = @(
    'Version=0.26.4'
    ('RequestedUtc=' + [DateTimeOffset]::UtcNow.ToString('O', [System.Globalization.CultureInfo]::InvariantCulture))
)
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($requestPath, $lines, $utf8NoBom)

Write-Host "Created one-shot CR-04 Slice 2A top-level highlight diagnostic request."
Write-Host "Start Cimatron normally within 30 minutes. This script does not launch Cimatron."
