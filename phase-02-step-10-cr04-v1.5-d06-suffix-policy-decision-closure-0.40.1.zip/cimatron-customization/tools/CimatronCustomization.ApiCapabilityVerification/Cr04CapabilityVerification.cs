using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class Cr04CapabilityVerification
    {
        private const int MaxDepth = 16;
        private const string MissingAttributeSuffix = "__CR04_MISSING_CONTROL__";

        internal static int Run(VerificationArguments args)
        {
            if (!string.Equals(args.ExpectedContext, "Assembly", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("CR-04 capability mode requires --expect Assembly.");
            if (string.IsNullOrWhiteSpace(args.ModelTitle))
                throw new ArgumentException("CR-04 capability mode requires --model-title.");
            if (string.IsNullOrWhiteSpace(args.KnownAttributeName) || string.IsNullOrWhiteSpace(args.KnownAttributeValue))
                throw new ArgumentException("CR-04 capability mode requires --known-attribute-name and --known-attribute-value.");

            using (VerificationRuntimeContext context = VerificationRuntimeContext.Attach(args.ExpectedContext, "CR-04 SLICE 2A CAPABILITY INVESTIGATION"))
            {
                NoMutationEvidence before = NoMutationEvidence.Capture(context.Document);
                int exitCode = 1;
                try
                {
                    if (!string.Equals(context.Model.Title, args.ModelTitle, StringComparison.Ordinal))
                        throw new InvalidOperationException("Active Assembly model title is " + context.Model.Title + ", expected " + args.ModelTitle + ".");

                    interop.CimMdlrAPI.IAssemblyModel assembly = context.Model as interop.CimMdlrAPI.IAssemblyModel;
                    if (assembly == null)
                        throw new InvalidOperationException("Active Assembly model does not expose IAssemblyModel.");

                    context.Evidence.AppendLine("CR04.ModelTitle: " + context.Model.Title);
                    context.Evidence.AppendLine("CR04.ModelPID: " + (context.Model.PID ?? string.Empty));
                    context.Evidence.AppendLine("CR04.KnownAttributeName: " + args.KnownAttributeName);
                    context.Evidence.AppendLine("CR04.KnownAttributeValue: " + args.KnownAttributeValue);
                    context.Evidence.AppendLine("CR04.MissingAttributeControlName: " + args.KnownAttributeName + MissingAttributeSuffix);
                    context.Evidence.AppendLine("CR04.TraversalContract: ID checked before descent; descend only when get_SubInstances(1,0) is non-empty and model type is cmAssembly; maximum depth 16");
                    context.Evidence.AppendLine("CR04.OccurrenceIdentityRule: no self-instance heuristic; every occurrence from the highlighter-equivalent traversal participates in D-15 identity safety and body evidence is inspected as returned by the occurrence");

                    List<OccurrenceObservation> occurrences = new List<OccurrenceObservation>();
                    TraverseHighlighterScope(context, assembly, 0, "root", occurrences);
                    WriteOccurrenceSummary(context, occurrences);
                    AttributeSummary attributes = InspectAttributes(context, occurrences, args.KnownAttributeName, args.KnownAttributeValue);
                    WriteCollisionSummary(context, occurrences, attributes);

                    if (attributes.ExactKnownValueMatches == 0)
                        throw new InvalidOperationException("No cmBody returned the configured known cmAttString value. The prepared KA-ASM-CR04 control is not present or the requested attribute/value is incorrect.");

                    exitCode = 0;
                    return exitCode;
                }
                finally
                {
                    NoMutationEvidence after = NoMutationEvidence.Capture(context.Document);
                    bool unchanged = before.IsEquivalentTo(after);
                    context.Evidence.AppendLine("NoMutation.Before: " + before);
                    context.Evidence.AppendLine("NoMutation.After: " + after);
                    context.Evidence.AppendLine("NoMutation.Result: " + (unchanged ? "PASS" : "FAIL"));
                    string evidencePath = VerificationEvidenceWriter.Write("api-capability-cr04-slice2a", context.Evidence.ToString());
                    Console.WriteLine("Evidence file: " + evidencePath);
                    if (!unchanged && exitCode == 0)
                        throw new InvalidOperationException("CR-04 capability investigation changed the active Assembly or its persisted file evidence.");
                }
            }
        }

        private static void TraverseHighlighterScope(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IAssemblyModel assembly,
            int depth,
            string path,
            ICollection<OccurrenceObservation> output)
        {
            if (depth > MaxDepth)
            {
                context.Evidence.AppendLine("Traversal.DepthLimit: STOP path=" + path + "; depth=" + depth.ToString(CultureInfo.InvariantCulture));
                return;
            }

            object[] rawInstances = assembly.GetInstances();
            if (rawInstances == null)
            {
                context.Evidence.AppendLine("Traversal.GetInstances: NULL path=" + path + "; depth=" + depth.ToString(CultureInfo.InvariantCulture));
                return;
            }

            for (int index = 0; index < rawInstances.Length; index++)
            {
                interop.CimMdlrAPI.IAssInstance instance = rawInstances[index] as interop.CimMdlrAPI.IAssInstance;
                if (instance == null)
                    continue;

                interop.CimMdlrAPI.IModel model = instance.Model;
                string modelPid = model == null ? string.Empty : model.PID ?? string.Empty;
                string modelTitle = model == null ? string.Empty : model.Title ?? string.Empty;
                string modelType = model == null ? string.Empty : model.Type.ToString();
                int suppressed = instance.IsSuppressed;
                string occurrencePath = path + "/" + index.ToString(CultureInfo.InvariantCulture) + ":" + instance.ID.ToString(CultureInfo.InvariantCulture);
                object rawSubInstances = instance.get_SubInstances(1, 0);
                object[] subInstances = rawSubInstances as object[];
                bool hasSubInstances = subInstances != null && subInstances.Length > 0;
                bool descends = hasSubInstances && model != null && string.Equals(modelType, "cmAssembly", StringComparison.Ordinal);

                OccurrenceObservation observation = new OccurrenceObservation(
                    instance,
                    occurrencePath,
                    instance.ID,
                    modelPid,
                    suppressed);
                output.Add(observation);

                context.Evidence.AppendLine(
                    "Traversal.Occurrence: path=" + occurrencePath +
                    "; depth=" + depth.ToString(CultureInfo.InvariantCulture) +
                    "; instanceId=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                    "; suppressed=" + suppressed.ToString(CultureInfo.InvariantCulture) +
                    "; modelType=" + modelType +
                    "; modelTitle=" + modelTitle +
                    "; modelPID=" + modelPid +
                    "; subInstancesNonEmpty=" + hasSubInstances +
                    "; descends=" + descends);

                if (descends)
                    TraverseHighlighterScope(context, (interop.CimMdlrAPI.IAssemblyModel)model, depth + 1, occurrencePath, output);
            }
        }

        private static void WriteOccurrenceSummary(VerificationRuntimeContext context, IReadOnlyCollection<OccurrenceObservation> occurrences)
        {
            int suppressedCount = occurrences.Count(item => item.IsSuppressed != 0);
            context.Evidence.AppendLine("Traversal.TotalOccurrences: " + occurrences.Count.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("Traversal.SuppressedOccurrences: " + suppressedCount.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("Traversal.IdentityRule: no self-instance filtering or PID/title/InstanceId/synthetic-root-name heuristic; all highlighter-scope occurrences participate in D-15 uniqueness");
        }

        private static AttributeSummary InspectAttributes(
            VerificationRuntimeContext context,
            IEnumerable<OccurrenceObservation> occurrences,
            string knownAttributeName,
            string knownAttributeValue)
        {
            string missingAttributeName = knownAttributeName + MissingAttributeSuffix;
            AttributeSummary summary = new AttributeSummary();

            foreach (OccurrenceObservation occurrence in occurrences)
            {
                interop.CimMdlrAPI.ICimEntityList entities;
                try
                {
                    entities = occurrence.Instance.GetAllEntities();
                }
                catch (Exception ex)
                {
                    Exception raw = VerificationRuntimeContext.Unwrap(ex);
                    summary.GetAllEntitiesReadErrors++;
                    context.Evidence.AppendLine("AttributeOccurrence.GetAllEntities: READ_ERROR path=" + occurrence.Path + "; type=" + raw.GetType().FullName + "; HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) + "; message=" + raw.Message);
                    continue;
                }

                if (entities == null)
                {
                    summary.GetAllEntitiesNulls++;
                    context.Evidence.AppendLine("AttributeOccurrence.GetAllEntities: NULL path=" + occurrence.Path);
                    continue;
                }

                int bodyCount = 0;
                int occurrenceExactMatches = 0;
                for (int index = 1; index <= entities.Count; index++)
                {
                    interop.CimMdlrAPI.ICimEntity entity = entities[index] as interop.CimMdlrAPI.ICimEntity;
                    if (entity == null || !string.Equals(entity.Type.ToString(), "cmBody", StringComparison.Ordinal))
                        continue;

                    bodyCount++;
                    summary.BodyCount++;
                    interop.CimBaseAPI.IAttributeSink sink = entity as interop.CimBaseAPI.IAttributeSink;
                    if (sink == null)
                    {
                        context.Evidence.AppendLine("AttributeBody.Sink: ABSENT path=" + occurrence.Path + "; bodyId=" + entity.ID.ToString(CultureInfo.InvariantCulture));
                        continue;
                    }

                    bool exactKnownValue = ObserveNamedAttribute(context, summary, occurrence, entity.ID, sink, knownAttributeName, knownAttributeValue);
                    if (exactKnownValue)
                        occurrenceExactMatches++;
                    ObserveMissingAttribute(context, summary, occurrence, entity.ID, sink, missingAttributeName, exactKnownValue);
                    ObserveWrongTypeLookup(context, summary, occurrence, entity.ID, sink, knownAttributeName, exactKnownValue);
                }

                occurrence.ExactKnownValueMatches = occurrenceExactMatches;
                if (occurrenceExactMatches == 0)
                    summary.OccurrencesWithZeroExactKnownValue++;
                else
                {
                    summary.OccurrencesWithExactKnownValue++;
                    if (occurrenceExactMatches > 1)
                        summary.OccurrencesWithMultipleExactKnownValue++;
                }

                context.Evidence.AppendLine(
                    "AttributeOccurrence.Summary: path=" + occurrence.Path +
                    "; instanceId=" + occurrence.InstanceId.ToString(CultureInfo.InvariantCulture) +
                    "; bodyCount=" + bodyCount.ToString(CultureInfo.InvariantCulture) +
                    "; exactKnownValueMatches=" + occurrenceExactMatches.ToString(CultureInfo.InvariantCulture));
            }

            context.Evidence.AppendLine("AttributeSummary.BodyCount: " + summary.BodyCount.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.ExactKnownValueMatches: " + summary.ExactKnownValueMatches.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.OccurrencesWithZeroExactKnownValue: " + summary.OccurrencesWithZeroExactKnownValue.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.OccurrencesWithExactKnownValue: " + summary.OccurrencesWithExactKnownValue.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.OccurrencesWithMultipleExactKnownValue: " + summary.OccurrencesWithMultipleExactKnownValue.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownStringAbsent: " + summary.KnownStringAbsent.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownStringBlank: " + summary.KnownStringBlank.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownStringOtherValue: " + summary.KnownStringOtherValue.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownStringReadError: " + summary.KnownStringReadError.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.MissingControlReturnedNull: " + summary.MissingControlReturnedNull.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.MissingControlReturnedAttribute: " + summary.MissingControlReturnedAttribute.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.MissingControlReadError: " + summary.MissingControlReadError.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownValueBodyMissingControlReturnedNull: " + summary.KnownValueBodyMissingControlReturnedNull.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownValueBodyMissingControlReturnedAttribute: " + summary.KnownValueBodyMissingControlReturnedAttribute.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownValueBodyMissingControlReadError: " + summary.KnownValueBodyMissingControlReadError.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.WrongTypeReturnedNull: " + summary.WrongTypeReturnedNull.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.WrongTypeReturnedAttribute: " + summary.WrongTypeReturnedAttribute.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.WrongTypeReadError: " + summary.WrongTypeReadError.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownValueBodyWrongTypeReturnedNull: " + summary.KnownValueBodyWrongTypeReturnedNull.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownValueBodyWrongTypeReturnedAttribute: " + summary.KnownValueBodyWrongTypeReturnedAttribute.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.KnownValueBodyWrongTypeReadError: " + summary.KnownValueBodyWrongTypeReadError.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.GetAllEntitiesNulls: " + summary.GetAllEntitiesNulls.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("AttributeSummary.GetAllEntitiesReadErrors: " + summary.GetAllEntitiesReadErrors.ToString(CultureInfo.InvariantCulture));
            return summary;
        }

        private static bool ObserveNamedAttribute(
            VerificationRuntimeContext context,
            AttributeSummary summary,
            OccurrenceObservation occurrence,
            int bodyId,
            interop.CimBaseAPI.IAttributeSink sink,
            string attributeName,
            string expectedValue)
        {
            try
            {
                interop.CimBaseAPI.IAttribute attribute = sink.GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttString, attributeName);
                if (attribute == null)
                {
                    summary.KnownStringAbsent++;
                    context.Evidence.AppendLine("AttributeBody.KnownString: ABSENT path=" + occurrence.Path + "; bodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; name=" + attributeName);
                    return false;
                }

                string value = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                context.Evidence.AppendLine("AttributeBody.KnownString: PRESENT path=" + occurrence.Path + "; bodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; requestedName=" + attributeName + "; returnedName=" + attribute.Name + "; returnedType=" + attribute.Type + "; value=" + value);
                if (value.Length == 0)
                {
                    summary.KnownStringBlank++;
                    return false;
                }
                if (string.Equals(value, expectedValue, StringComparison.Ordinal))
                {
                    summary.ExactKnownValueMatches++;
                    return true;
                }

                summary.KnownStringOtherValue++;
                return false;
            }
            catch (Exception ex)
            {
                summary.KnownStringReadError++;
                WriteReadError(context, "AttributeBody.KnownString", occurrence.Path, bodyId, ex);
                return false;
            }
        }

        private static void ObserveMissingAttribute(
            VerificationRuntimeContext context,
            AttributeSummary summary,
            OccurrenceObservation occurrence,
            int bodyId,
            interop.CimBaseAPI.IAttributeSink sink,
            string attributeName,
            bool exactKnownValueBody)
        {
            try
            {
                interop.CimBaseAPI.IAttribute attribute = sink.GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttString, attributeName);
                if (attribute == null)
                {
                    summary.MissingControlReturnedNull++;
                    if (exactKnownValueBody)
                        summary.KnownValueBodyMissingControlReturnedNull++;
                    context.Evidence.AppendLine("AttributeBody.MissingControl: NULL path=" + occurrence.Path + "; bodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; name=" + attributeName);
                }
                else
                {
                    summary.MissingControlReturnedAttribute++;
                    if (exactKnownValueBody)
                        summary.KnownValueBodyMissingControlReturnedAttribute++;
                    context.Evidence.AppendLine("AttributeBody.MissingControl: PRESENT path=" + occurrence.Path + "; bodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; requestedName=" + attributeName + "; returnedName=" + attribute.Name + "; returnedType=" + attribute.Type + "; value=" + VerificationRuntimeContext.Format(attribute.Value));
                }
            }
            catch (Exception ex)
            {
                summary.MissingControlReadError++;
                if (exactKnownValueBody)
                    summary.KnownValueBodyMissingControlReadError++;
                WriteReadError(context, "AttributeBody.MissingControl", occurrence.Path, bodyId, ex);
            }
        }

        private static void ObserveWrongTypeLookup(
            VerificationRuntimeContext context,
            AttributeSummary summary,
            OccurrenceObservation occurrence,
            int bodyId,
            interop.CimBaseAPI.IAttributeSink sink,
            string attributeName,
            bool exactKnownValueBody)
        {
            try
            {
                interop.CimBaseAPI.IAttribute attribute = sink.GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttInteger, attributeName);
                if (attribute == null)
                {
                    summary.WrongTypeReturnedNull++;
                    if (exactKnownValueBody)
                        summary.KnownValueBodyWrongTypeReturnedNull++;
                    context.Evidence.AppendLine("AttributeBody.WrongTypeIntegerLookup: NULL path=" + occurrence.Path + "; bodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; name=" + attributeName);
                }
                else
                {
                    summary.WrongTypeReturnedAttribute++;
                    if (exactKnownValueBody)
                        summary.KnownValueBodyWrongTypeReturnedAttribute++;
                    context.Evidence.AppendLine("AttributeBody.WrongTypeIntegerLookup: PRESENT path=" + occurrence.Path + "; bodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; requestedName=" + attributeName + "; returnedName=" + attribute.Name + "; returnedType=" + attribute.Type + "; value=" + VerificationRuntimeContext.Format(attribute.Value));
                }
            }
            catch (Exception ex)
            {
                summary.WrongTypeReadError++;
                if (exactKnownValueBody)
                    summary.KnownValueBodyWrongTypeReadError++;
                WriteReadError(context, "AttributeBody.WrongTypeIntegerLookup", occurrence.Path, bodyId, ex);
            }
        }

        private static void WriteReadError(VerificationRuntimeContext context, string label, string path, int bodyId, Exception exception)
        {
            Exception raw = VerificationRuntimeContext.Unwrap(exception);
            context.Evidence.AppendLine(label + ": READ_ERROR path=" + path + "; bodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; type=" + raw.GetType().FullName + "; HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) + "; message=" + raw.Message);
        }

        private static void WriteCollisionSummary(
            VerificationRuntimeContext context,
            IReadOnlyCollection<OccurrenceObservation> occurrences,
            AttributeSummary attributes)
        {
            Dictionary<int, List<OccurrenceObservation>> byId = occurrences
                .GroupBy(item => item.InstanceId)
                .ToDictionary(group => group.Key, group => group.ToList());
            List<KeyValuePair<int, List<OccurrenceObservation>>> collisions = byId.Where(pair => pair.Value.Count > 1).OrderBy(pair => pair.Key).ToList();

            foreach (KeyValuePair<int, List<OccurrenceObservation>> collision in collisions)
            {
                string members = string.Join(
                    " | ",
                    collision.Value.Select(item => item.Path + ";pid=" + item.ModelPid + ";suppressed=" + item.IsSuppressed.ToString(CultureInfo.InvariantCulture)));
                context.Evidence.AppendLine("Collision.InstanceId: id=" + collision.Key.ToString(CultureInfo.InvariantCulture) + "; count=" + collision.Value.Count.ToString(CultureInfo.InvariantCulture) + "; members=" + members);
            }

            HashSet<int> collidingIds = new HashSet<int>(collisions.Select(item => item.Key));
            List<OccurrenceObservation> otherwiseValid = occurrences.Where(item => item.ExactKnownValueMatches > 0).ToList();
            int unsafeCount = otherwiseValid.Count(item => collidingIds.Contains(item.InstanceId));
            double percentage = otherwiseValid.Count == 0 ? 0.0 : (100.0 * unsafeCount / otherwiseValid.Count);

            context.Evidence.AppendLine("Collision.UniqueInstanceIds: " + byId.Count(pair => pair.Value.Count == 1).ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("Collision.RepeatedInstanceIds: " + collisions.Count.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("Collision.OccurrencesParticipating: " + collisions.Sum(pair => pair.Value.Count).ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("Collision.OtherwiseValidKnownAttributeOccurrences: " + otherwiseValid.Count.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("Collision.UnsafeOtherwiseValidKnownAttributeOccurrences: " + unsafeCount.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("Collision.UnsafePercentage: " + percentage.ToString("0.00", CultureInfo.InvariantCulture) + "%");
            context.Evidence.AppendLine("Collision.ScopeRule: full unfiltered highlighter-equivalent traversal; suppressed/excluded/zero-body occurrences all participate in InstanceId uniqueness; no self-instance heuristic is applied");
            context.Evidence.AppendLine("Collision.AttributeEvidenceExactMatches: " + attributes.ExactKnownValueMatches.ToString(CultureInfo.InvariantCulture));
        }

        private sealed class OccurrenceObservation
        {
            internal OccurrenceObservation(
                interop.CimMdlrAPI.IAssInstance instance,
                string path,
                int instanceId,
                string modelPid,
                int isSuppressed)
            {
                Instance = instance;
                Path = path;
                InstanceId = instanceId;
                ModelPid = modelPid;
                IsSuppressed = isSuppressed;
            }

            internal interop.CimMdlrAPI.IAssInstance Instance { get; }
            internal string Path { get; }
            internal int InstanceId { get; }
            internal string ModelPid { get; }
            internal int IsSuppressed { get; }
            internal int ExactKnownValueMatches { get; set; }
        }

        private sealed class AttributeSummary
        {
            internal int BodyCount { get; set; }
            internal int ExactKnownValueMatches { get; set; }
            internal int OccurrencesWithZeroExactKnownValue { get; set; }
            internal int OccurrencesWithExactKnownValue { get; set; }
            internal int OccurrencesWithMultipleExactKnownValue { get; set; }
            internal int KnownStringAbsent { get; set; }
            internal int KnownStringBlank { get; set; }
            internal int KnownStringOtherValue { get; set; }
            internal int KnownStringReadError { get; set; }
            internal int MissingControlReturnedNull { get; set; }
            internal int MissingControlReturnedAttribute { get; set; }
            internal int MissingControlReadError { get; set; }
            internal int KnownValueBodyMissingControlReturnedNull { get; set; }
            internal int KnownValueBodyMissingControlReturnedAttribute { get; set; }
            internal int KnownValueBodyMissingControlReadError { get; set; }
            internal int WrongTypeReturnedNull { get; set; }
            internal int WrongTypeReturnedAttribute { get; set; }
            internal int WrongTypeReadError { get; set; }
            internal int KnownValueBodyWrongTypeReturnedNull { get; set; }
            internal int KnownValueBodyWrongTypeReturnedAttribute { get; set; }
            internal int KnownValueBodyWrongTypeReadError { get; set; }
            internal int GetAllEntitiesNulls { get; set; }
            internal int GetAllEntitiesReadErrors { get; set; }
        }
    }
}
