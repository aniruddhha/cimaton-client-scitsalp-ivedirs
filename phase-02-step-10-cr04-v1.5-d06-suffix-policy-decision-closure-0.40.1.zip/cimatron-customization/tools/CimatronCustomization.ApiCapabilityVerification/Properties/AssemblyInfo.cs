using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("CimatronCustomization.ApiCapabilityVerification")]
[assembly: AssemblyDescription("Development-only Cimatron 2026 read-only API capability verification diagnostic")]
[assembly: AssemblyCompany("flux10x AI Systems")]
[assembly: AssemblyProduct("CimatronCustomization.ApiCapabilityVerification")]
[assembly: ComVisible(false)]
[assembly: Guid("c1948bb4-559e-4837-b48f-6ad8a5a7bb5b")]
[assembly: AssemblyVersion("0.24.4.0")]
[assembly: AssemblyFileVersion("0.24.4.0")]
