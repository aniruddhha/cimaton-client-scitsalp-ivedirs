using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class PartMaterialApiReflectionInvestigation
    {
        private const string InvestigationVersion = "0.38.4";

        private static readonly string[] TargetTypes =
        {
            "IApplication",
            "IPdm",
            "IDocAttribute",
            "DocAttribute",
            "ICimDocument",
            "IPartDocument",
            "IAssemblyDocument",
            "IModel",
            "IMdlrModel",
            "IAssInstance",
            "IAssemblyModel"
        };

        private static readonly string[] TargetApplicationMembers =
        {
            "GetPdm"
        };

        private static readonly string[] TargetPdmMembers =
        {
            "RetriveDocAttribute",
            "RetriveLinkAttribute",
            "GetRelatedDocuments",
            "GetDocumentByPath",
            "TitleOfPid"
        };

        internal static int Run()
        {
            string programDirectory = AppDomain.CurrentDomain.BaseDirectory;
            StringBuilder output = new StringBuilder();
            output.AppendLine("CIMATRON 2026 PART MATERIAL API REFLECTION INVESTIGATION");
            output.AppendLine("InvestigationVersion: " + InvestigationVersion);
            output.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture));
            output.AppendLine("InteropDirectory: " + programDirectory);
            output.AppendLine("RuntimeCalls: NONE (reflection-only installed-Interop investigation)");
            output.AppendLine("Native Part Material attribute identity: NOT VERIFIED");

            List<Assembly> assemblies = LoadInstalledInteropAssemblies(programDirectory, output);
            List<Type> allTypes = GetAllTypes(assemblies, output);

            bool typedMaterialCandidate = false;
            bool documentAttributeCandidate = false;

            foreach (string targetType in TargetTypes)
            {
                WriteTargetType(output, allTypes, targetType, ref typedMaterialCandidate, ref documentAttributeCandidate);
            }

            WriteExactInstalledApplicationSignatures(output, allTypes);
            WriteExactInstalledPdmSignatures(output, allTypes, ref documentAttributeCandidate);
            WriteGlobalMaterialMemberInventory(output, allTypes);

            output.AppendLine();
            output.AppendLine("CLASSIFICATION");
            if (typedMaterialCandidate || documentAttributeCandidate)
            {
                output.AppendLine("Classification=B");
                output.AppendLine("Result=CANDIDATE READ ROUTE FOUND — RUNTIME VALIDATION REQUIRED");
                output.AppendLine("TypedMaterialCandidate=" + typedMaterialCandidate);
                output.AppendLine("DocumentAttributeCandidate=" + documentAttributeCandidate);
                output.AppendLine("Native Part Material attribute identity: NOT VERIFIED");
            }
            else
            {
                output.AppendLine("Classification=A");
                output.AppendLine("Result=NO CANDIDATE DIRECT PART MATERIAL READ ROUTE FOUND");
                output.AppendLine("TypedMaterialCandidate=false");
                output.AppendLine("DocumentAttributeCandidate=false");
            }

            string evidence = VerificationEvidenceWriter.Write("part-material-api-reflection", output.ToString());
            Console.WriteLine("PART MATERIAL API REFLECTION INVESTIGATION: COMPLETE");
            Console.WriteLine("Evidence file: " + evidence);
            return 0;
        }

        private static List<Assembly> LoadInstalledInteropAssemblies(string programDirectory, StringBuilder output)
        {
            List<Assembly> assemblies = new List<Assembly>();
            output.AppendLine();
            output.AppendLine("INSTALLED INTEROP ASSEMBLIES");
            foreach (string path in Directory.GetFiles(programDirectory, "interop.*.dll").OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    Assembly assembly = Assembly.ReflectionOnlyLoadFrom(path);
                    assemblies.Add(assembly);
                    output.AppendLine("ASSEMBLY PRESENT: " + Path.GetFileName(path) + " | " + assembly.FullName);
                }
                catch (Exception exception)
                {
                    output.AppendLine("ASSEMBLY READ_ERROR: " + Path.GetFileName(path) + " | " + exception.GetType().FullName + " | " + exception.Message);
                }
            }

            return assemblies;
        }

        private static List<Type> GetAllTypes(IEnumerable<Assembly> assemblies, StringBuilder output)
        {
            List<Type> types = new List<Type>();
            foreach (Assembly assembly in assemblies)
            {
                try
                {
                    types.AddRange(assembly.GetTypes());
                }
                catch (ReflectionTypeLoadException exception)
                {
                    types.AddRange(exception.Types.Where(type => type != null));
                    output.AppendLine("TYPE LOAD_PARTIAL: " + assembly.GetName().Name + " | " + exception.Message);
                }
                catch (Exception exception)
                {
                    output.AppendLine("TYPE READ_ERROR: " + assembly.GetName().Name + " | " + exception.GetType().FullName + " | " + exception.Message);
                }
            }

            return types;
        }

        private static void WriteTargetType(
            StringBuilder output,
            IEnumerable<Type> allTypes,
            string simpleName,
            ref bool typedMaterialCandidate,
            ref bool documentAttributeCandidate)
        {
            List<Type> matches = allTypes
                .Where(type => string.Equals(type.Name, simpleName, StringComparison.Ordinal))
                .OrderBy(type => type.Assembly.GetName().Name, StringComparer.Ordinal)
                .ThenBy(type => type.FullName, StringComparer.Ordinal)
                .ToList();

            output.AppendLine();
            output.AppendLine("TARGET TYPE: " + simpleName);
            if (matches.Count == 0)
            {
                output.AppendLine("NOT_FOUND");
                return;
            }

            foreach (Type type in matches)
            {
                output.AppendLine("FOUND assembly=" + type.Assembly.GetName().Name + "; fullName=" + type.FullName + "; kind=" + GetTypeKind(type) + "; guid=" + type.GUID);
                Type[] inherited = type.GetInterfaces().OrderBy(item => item.FullName, StringComparer.Ordinal).ToArray();
                output.AppendLine("INHERITED_INTERFACES: " + (inherited.Length == 0 ? "<none>" : string.Join(", ", inherited.Select(item => item.FullName))));

                WriteDeclaredMembers(output, type, ref typedMaterialCandidate, ref documentAttributeCandidate);
                foreach (Type inheritedType in inherited)
                {
                    output.AppendLine("INHERITED TYPE assembly=" + inheritedType.Assembly.GetName().Name + "; fullName=" + inheritedType.FullName);
                    WriteDeclaredMembers(output, inheritedType, ref typedMaterialCandidate, ref documentAttributeCandidate);
                }
            }
        }

        private static void WriteDeclaredMembers(
            StringBuilder output,
            Type type,
            ref bool typedMaterialCandidate,
            ref bool documentAttributeCandidate)
        {
            MemberInfo[] members;
            try
            {
                members = type.GetMembers(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);
            }
            catch (Exception exception)
            {
                output.AppendLine("MEMBER READ_ERROR assembly=" + type.Assembly.GetName().Name + "; declaring=" + type.FullName + "; error=" + exception.GetType().FullName + " | " + exception.Message);
                return;
            }

            foreach (MemberInfo member in members.OrderBy(item => item.MemberType).ThenBy(item => item.Name, StringComparer.Ordinal))
            {
                output.AppendLine(FormatMember(member));
                if (IsTypedMaterialCandidate(type, member)) typedMaterialCandidate = true;
                if (string.Equals(type.Name, "IPdm", StringComparison.Ordinal) &&
                    string.Equals(member.Name, "RetriveDocAttribute", StringComparison.Ordinal) &&
                    IsUsableDocumentAttributeReadMember(member))
                {
                    documentAttributeCandidate = true;
                }
            }
        }

        private static void WriteExactInstalledApplicationSignatures(StringBuilder output, IEnumerable<Type> allTypes)
        {
            output.AppendLine();
            output.AppendLine("EXACT INSTALLED IAPPLICATION SIGNATURES");
            List<Type> applicationTypes = allTypes
                .Where(type => string.Equals(type.Name, "IApplication", StringComparison.Ordinal))
                .OrderBy(type => type.Assembly.GetName().Name, StringComparer.Ordinal)
                .ThenBy(type => type.FullName, StringComparer.Ordinal)
                .ToList();

            if (applicationTypes.Count == 0)
            {
                output.AppendLine("IApplication: NOT_FOUND");
                return;
            }

            foreach (Type applicationType in applicationTypes)
            {
                output.AppendLine("IAPPLICATION assembly=" + applicationType.Assembly.GetName().Name + "; fullName=" + applicationType.FullName);
                foreach (string memberName in TargetApplicationMembers)
                {
                    List<MemberInfo> matches = GetNamedPublicMembers(output, applicationType, memberName);
                    if (matches.Count == 0)
                    {
                        output.AppendLine("EXACT SIGNATURE " + memberName + ": NOT_FOUND");
                        continue;
                    }

                    foreach (MemberInfo member in matches)
                    {
                        output.AppendLine("EXACT SIGNATURE " + memberName + ": " + FormatMember(member));
                    }
                }
            }
        }

        private static void WriteExactInstalledPdmSignatures(StringBuilder output, IEnumerable<Type> allTypes, ref bool documentAttributeCandidate)
        {
            output.AppendLine();
            output.AppendLine("EXACT INSTALLED IPDM SIGNATURES");
            List<Type> pdmTypes = allTypes
                .Where(type => string.Equals(type.Name, "IPdm", StringComparison.Ordinal))
                .OrderBy(type => type.Assembly.GetName().Name, StringComparer.Ordinal)
                .ThenBy(type => type.FullName, StringComparer.Ordinal)
                .ToList();

            if (pdmTypes.Count == 0)
            {
                output.AppendLine("IPdm: NOT_FOUND");
                return;
            }

            foreach (Type pdmType in pdmTypes)
            {
                output.AppendLine("IPDM assembly=" + pdmType.Assembly.GetName().Name + "; fullName=" + pdmType.FullName);
                foreach (string memberName in TargetPdmMembers)
                {
                    List<MemberInfo> matches = GetNamedPublicMembers(output, pdmType, memberName);
                    if (matches.Count == 0)
                    {
                        output.AppendLine("EXACT SIGNATURE " + memberName + ": NOT_FOUND");
                        continue;
                    }

                    foreach (MemberInfo member in matches)
                    {
                        output.AppendLine("EXACT SIGNATURE " + memberName + ": " + FormatMember(member));
                        if (string.Equals(memberName, "RetriveDocAttribute", StringComparison.Ordinal) && IsUsableDocumentAttributeReadMember(member))
                        {
                            documentAttributeCandidate = true;
                        }
                    }
                }
            }
        }

        private static List<MemberInfo> GetNamedPublicMembers(StringBuilder output, Type type, string memberName)
        {
            List<MemberInfo> matches = new List<MemberInfo>();
            IEnumerable<Type> typeClosure = new[] { type }.Concat(type.GetInterfaces());
            foreach (Type current in typeClosure)
            {
                try
                {
                    matches.AddRange(current.GetMembers(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly)
                        .Where(member => string.Equals(member.Name, memberName, StringComparison.Ordinal)));
                }
                catch (Exception exception)
                {
                    output.AppendLine("MEMBER LOOKUP_ERROR assembly=" + current.Assembly.GetName().Name + "; declaring=" + current.FullName +
                        "; member=" + memberName + "; error=" + exception.GetType().FullName + " | " + exception.Message);
                }
            }

            return matches
                .GroupBy(member => member.DeclaringType.AssemblyQualifiedName + "|" + member.MemberType + "|" + FormatMember(member), StringComparer.Ordinal)
                .Select(group => group.First())
                .OrderBy(member => member.DeclaringType.Assembly.GetName().Name, StringComparer.Ordinal)
                .ThenBy(member => member.DeclaringType.FullName, StringComparer.Ordinal)
                .ThenBy(member => member.MemberType)
                .ThenBy(member => member.Name, StringComparer.Ordinal)
                .ToList();
        }

        private static void WriteGlobalMaterialMemberInventory(StringBuilder output, IEnumerable<Type> allTypes)
        {
            output.AppendLine();
            output.AppendLine("GLOBAL MATERIAL-NAMED MEMBER INVENTORY");
            int count = 0;
            foreach (Type type in allTypes.OrderBy(item => item.Assembly.GetName().Name, StringComparer.Ordinal).ThenBy(item => item.FullName, StringComparer.Ordinal))
            {
                MemberInfo[] members;
                try
                {
                    members = type.GetMembers(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);
                }
                catch (Exception exception)
                {
                    output.AppendLine("MATERIAL MEMBER READ_ERROR assembly=" + type.Assembly.GetName().Name + "; declaring=" + type.FullName +
                        "; error=" + exception.GetType().FullName + " | " + exception.Message);
                    continue;
                }

                foreach (MemberInfo member in members.Where(item => item.Name.IndexOf("material", StringComparison.OrdinalIgnoreCase) >= 0).OrderBy(item => item.Name, StringComparer.Ordinal))
                {
                    output.AppendLine("MATERIAL MEMBER " + FormatMember(member));
                    count++;
                }
            }

            output.AppendLine("MaterialNamedMemberCount=" + count.ToString(CultureInfo.InvariantCulture));
        }

        private static bool IsTypedMaterialCandidate(Type declaringType, MemberInfo member)
        {
            if (member.Name.IndexOf("material", StringComparison.OrdinalIgnoreCase) < 0) return false;

            // Cimatron 2026 documents ICimDocument.Materials as rendering parameters
            // (ambient/diffuse/specular/shininess/emission), not the Part steel/material property.
            if (string.Equals(declaringType.Name, "ICimDocument", StringComparison.Ordinal) &&
                string.Equals(member.Name, "Materials", StringComparison.Ordinal))
            {
                return false;
            }

            return member is PropertyInfo || member is MethodInfo;
        }

        private static bool IsUsableDocumentAttributeReadMember(MemberInfo member)
        {
            MethodInfo method = member as MethodInfo;
            if (method == null) return false;

            ParameterInfo[] parameters = method.GetParameters();
            if (parameters.Length < 2) return false;
            if (parameters[0].ParameterType != typeof(string)) return false;

            Type secondType = parameters[1].ParameterType;
            Type effectiveSecondType = secondType.IsByRef ? secondType.GetElementType() : secondType;
            return effectiveSecondType == typeof(object) || effectiveSecondType == typeof(object[]) || effectiveSecondType.IsArray;
        }

        private static string FormatMember(MemberInfo member)
        {
            string assemblyName = member.DeclaringType == null ? "<none>" : member.DeclaringType.Assembly.GetName().Name;
            string declaringType = member.DeclaringType == null ? "<none>" : member.DeclaringType.FullName;

            PropertyInfo property = member as PropertyInfo;
            if (property != null)
            {
                return "assembly=" + assemblyName + "; declaring=" + declaringType + "; kind=Property; name=" + property.Name +
                    "; get=" + (property.GetGetMethod() != null) + "; set=" + (property.GetSetMethod() != null) +
                    "; return=" + FormatType(property.PropertyType) + "; parameters=" + FormatParameters(property.GetIndexParameters());
            }

            MethodInfo method = member as MethodInfo;
            if (method != null)
            {
                return "assembly=" + assemblyName + "; declaring=" + declaringType + "; kind=Method; name=" + method.Name +
                    "; get=false; set=false; return=" + FormatType(method.ReturnType) + "; parameters=" + FormatParameters(method.GetParameters());
            }

            FieldInfo field = member as FieldInfo;
            if (field != null)
            {
                return "assembly=" + assemblyName + "; declaring=" + declaringType + "; kind=Field; name=" + field.Name +
                    "; get=true; set=" + (!field.IsInitOnly && !field.IsLiteral) + "; return=" + FormatType(field.FieldType) + "; parameters=<none>";
            }

            EventInfo eventInfo = member as EventInfo;
            if (eventInfo != null)
            {
                return "assembly=" + assemblyName + "; declaring=" + declaringType + "; kind=Event; name=" + eventInfo.Name +
                    "; get=false; set=false; return=" + FormatType(eventInfo.EventHandlerType) + "; parameters=<none>";
            }

            ConstructorInfo constructor = member as ConstructorInfo;
            if (constructor != null)
            {
                return "assembly=" + assemblyName + "; declaring=" + declaringType + "; kind=Constructor; name=" + constructor.Name +
                    "; get=false; set=false; return=" + declaringType + "; parameters=" + FormatParameters(constructor.GetParameters());
            }

            return "assembly=" + assemblyName + "; declaring=" + declaringType + "; kind=" + member.MemberType + "; name=" + member.Name +
                "; get=false; set=false; return=<n/a>; parameters=<n/a>";
        }

        private static string FormatParameters(IEnumerable<ParameterInfo> parameters)
        {
            ParameterInfo[] parameterArray = parameters.ToArray();
            if (parameterArray.Length == 0) return "<none>";
            return string.Join(", ", parameterArray.Select(parameter =>
                "[" + GetParameterDirection(parameter) + "] " +
                FormatType(parameter.ParameterType.IsByRef ? parameter.ParameterType.GetElementType() : parameter.ParameterType) + " " +
                parameter.Name));
        }

        private static string GetParameterDirection(ParameterInfo parameter)
        {
            if (parameter.IsOut) return "out";
            if (parameter.ParameterType.IsByRef) return "ref/by-ref";
            if (parameter.IsIn) return "in";
            return "in";
        }

        private static string GetTypeKind(Type type)
        {
            if (type.IsInterface) return "Interface";
            if (type.IsEnum) return "Enum";
            if (type.IsClass) return "Class";
            if (type.IsValueType) return "ValueType";
            return "Other";
        }

        private static string FormatType(Type type)
        {
            return type == null ? "<null>" : type.FullName ?? type.Name;
        }
    }
}
