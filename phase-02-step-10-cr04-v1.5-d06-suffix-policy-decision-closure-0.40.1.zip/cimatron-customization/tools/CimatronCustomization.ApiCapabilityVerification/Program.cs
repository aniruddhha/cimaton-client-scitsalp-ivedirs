using System;
using System.Globalization;
using System.Collections.Generic;
using System.Runtime.ExceptionServices;
using System.Threading;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class Program
    {
        internal const string ToolVersion = "0.24.4";

        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                if (args == null || args.Length == 0 || IsHelp(args[0])) { PrintUsage(); return args == null || args.Length == 0 ? 1 : 0; }
                Console.WriteLine("Cimatron API Capability Verification " + ToolVersion);
                if (EqualsArg(args[0], "--reflect-capability-api") && args.Length == 1) return CapabilityApiReflectionInventory.Run();
                if (EqualsArg(args[0], "--reflect-part-material-api") && args.Length == 1) return PartMaterialApiReflectionInvestigation.Run();
                if (EqualsArg(args[0], "--discover-geometry-targets")) return GeometryKnownAnswerDiscovery.Run(VerificationArguments.Parse(args));
                if (EqualsArg(args[0], "--inspect-current-selection")) return CurrentSelectionInspection.Run(VerificationArguments.Parse(args));
                if (EqualsArg(args[0], "--verify-geometry")) return GeometryServicesVerification.Run(VerificationArguments.Parse(args));
                if (EqualsArg(args[0], "--verify-assembly-context")) return AssemblyContextVerification.Run(VerificationArguments.Parse(args));
                if (EqualsArg(args[0], "--verify-component-properties")) return ComponentPropertySourceVerification.Run(VerificationArguments.Parse(args));
                if (EqualsArg(args[0], "--verify-hidden-state-candidates")) return HiddenStateCandidateVerification.Run(VerificationArguments.Parse(args));
                if (EqualsArg(args[0], "--verify-cr04-capabilities")) return RunCr04OnMtaThread(VerificationArguments.Parse(args));
                PrintUsage(); return 1;
            }
            catch (ArgumentException exception) { Console.Error.WriteLine("ARGUMENT ERROR: " + exception.Message); return 1; }
            catch (Exception exception) { Console.Error.WriteLine("UNEXPECTED ERROR"); Console.Error.WriteLine(exception); return 1; }
        }

        private static int RunCr04OnMtaThread(VerificationArguments args)
        {
            int exitCode = 1;
            Exception workerException = null;
            Thread worker = new Thread(() =>
            {
                try
                {
                    exitCode = Cr04CapabilityVerification.Run(args);
                }
                catch (Exception exception)
                {
                    workerException = exception;
                }
            });
            worker.SetApartmentState(ApartmentState.MTA);
            worker.Start();
            worker.Join();
            if (workerException != null)
                ExceptionDispatchInfo.Capture(workerException).Throw();
            return exitCode;
        }

        private static bool EqualsArg(string actual, string expected) => string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase);
        private static bool IsHelp(string value) => EqualsArg(value, "--help") || EqualsArg(value, "-h") || EqualsArg(value, "/?");
        private static void PrintUsage()
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  --reflect-capability-api");
            Console.WriteLine("  --reflect-part-material-api");
            Console.WriteLine("  --discover-geometry-targets --expect Part");
            Console.WriteLine("  --inspect-current-selection --expect Part");
            Console.WriteLine("  --verify-geometry --expect Part [--ucs-id N] [--reference-ucs-id N] [--entity-a N --entity-b N] [--face-id N] [--ray-origin x,y,z --ray-direction x,y,z]... [--edge-id N] [--entity-id N --point x,y,z]...");
            Console.WriteLine("  --verify-assembly-context --expect Assembly --model-title TITLE --entity-id N [--ucs-id N] [--highlight]");
            Console.WriteLine("  --verify-component-properties --expect Assembly --model-title TITLE --entity-id N --known-attribute-name NAME --known-attribute-value VALUE --known-material VALUE");
            Console.WriteLine("  --verify-hidden-state-candidates --expect Assembly");
            Console.WriteLine("  --verify-cr04-capabilities --expect Assembly --model-title TITLE --known-attribute-name NAME --known-attribute-value VALUE");
        }
    }

    internal sealed class VerificationArguments
    {
        internal string ExpectedContext { get; private set; }
        internal string ModelTitle { get; private set; }
        internal int? EntityId { get; private set; }
        internal int? EntityA { get; private set; }
        internal int? EntityB { get; private set; }
        internal int? UcsId { get; private set; }
        internal int? ReferenceUcsId { get; private set; }
        internal int? FaceId { get; private set; }
        internal int? EdgeId { get; private set; }
        internal List<double[]> RayOrigins { get; } = new List<double[]>();
        internal List<double[]> RayDirections { get; } = new List<double[]>();
        internal List<double[]> Points { get; } = new List<double[]>();
        internal bool Highlight { get; private set; }
        internal string KnownAttributeName { get; private set; }
        internal string KnownAttributeValue { get; private set; }
        internal string KnownMaterial { get; private set; }

        internal static VerificationArguments Parse(string[] args)
        {
            VerificationArguments parsed = new VerificationArguments();
            for (int i = 1; i < args.Length; i++)
            {
                string key = args[i];
                if (string.Equals(key, "--highlight", StringComparison.OrdinalIgnoreCase)) { parsed.Highlight = true; continue; }
                if (i + 1 >= args.Length) throw new ArgumentException("Missing value for " + key + ".");
                string value = args[++i];
                if (string.Equals(key, "--expect", StringComparison.OrdinalIgnoreCase)) parsed.ExpectedContext = value;
                else if (string.Equals(key, "--model-title", StringComparison.OrdinalIgnoreCase)) parsed.ModelTitle = value;
                else if (string.Equals(key, "--entity-id", StringComparison.OrdinalIgnoreCase)) parsed.EntityId = ParseInt(key, value);
                else if (string.Equals(key, "--entity-a", StringComparison.OrdinalIgnoreCase)) parsed.EntityA = ParseInt(key, value);
                else if (string.Equals(key, "--entity-b", StringComparison.OrdinalIgnoreCase)) parsed.EntityB = ParseInt(key, value);
                else if (string.Equals(key, "--ucs-id", StringComparison.OrdinalIgnoreCase)) parsed.UcsId = ParseInt(key, value);
                else if (string.Equals(key, "--reference-ucs-id", StringComparison.OrdinalIgnoreCase)) parsed.ReferenceUcsId = ParseInt(key, value);
                else if (string.Equals(key, "--face-id", StringComparison.OrdinalIgnoreCase)) parsed.FaceId = ParseInt(key, value);
                else if (string.Equals(key, "--edge-id", StringComparison.OrdinalIgnoreCase)) parsed.EdgeId = ParseInt(key, value);
                else if (string.Equals(key, "--ray-origin", StringComparison.OrdinalIgnoreCase)) parsed.RayOrigins.Add(ParseVector(key, value));
                else if (string.Equals(key, "--ray-direction", StringComparison.OrdinalIgnoreCase)) parsed.RayDirections.Add(ParseVector(key, value));
                else if (string.Equals(key, "--point", StringComparison.OrdinalIgnoreCase)) parsed.Points.Add(ParseVector(key, value));
                else if (string.Equals(key, "--known-attribute-name", StringComparison.OrdinalIgnoreCase)) parsed.KnownAttributeName = value;
                else if (string.Equals(key, "--known-attribute-value", StringComparison.OrdinalIgnoreCase)) parsed.KnownAttributeValue = value;
                else if (string.Equals(key, "--known-material", StringComparison.OrdinalIgnoreCase)) parsed.KnownMaterial = value;
                else throw new ArgumentException("Unknown argument " + key + ".");
            }
            if (parsed.RayOrigins.Count != parsed.RayDirections.Count)
                throw new ArgumentException("Each --ray-origin requires a matching --ray-direction.");
            return parsed;
        }

        private static int ParseInt(string key, string value)
        {
            int result; if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result)) throw new ArgumentException(key + " requires an integer."); return result;
        }
        private static double[] ParseVector(string key, string value)
        {
            string[] parts = value.Split(','); if (parts.Length != 3) throw new ArgumentException(key + " requires x,y,z.");
            double[] result = new double[3]; for (int i = 0; i < 3; i++) if (!double.TryParse(parts[i], NumberStyles.Float, CultureInfo.InvariantCulture, out result[i])) throw new ArgumentException(key + " contains a non-numeric value."); return result;
        }
    }
}
