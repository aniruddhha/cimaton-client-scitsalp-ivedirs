## 2026-10-07 — 0.40.1 CR-04 v1.5 D-06 Suffix-Policy Decision Closure

- **Approval:** user explicitly approved updating the governed documentation with the D-06 decision; exact approval receipt timestamp was not independently captured and is intentionally not invented.
- **Decision:** no separate suffix semantics are required for CR-04. Suffix text such as `Doosan`, `PCK`, `HH`, or `TSHH` is not separately maintained, parsed, stripped, mapped, or validated.
- **Production rule:** compare the full normalized Cimatron native `TMPL::Material` value with the full normalized Design Order `Remark` value for the mapped row. `CompareGradeTokenOnly = false` remains unchanged.
- **Implementation impact:** none. The existing production comparison direction already performs full-value comparison; no source/test/config/API/workbook/model change is required by this decision.
- **Governance impact:** D-06 changes from PROVISIONAL to RESOLVED in the v1.5 implementation specification. Product/runtime version remains `0.40.1`.
- **Next state:** D-06 no longer blocks the formal CR-04 v1.5 / Step 10 closure review.

## 2026-10-07 — Version 0.40.1 — Result Report CSV Validation Closure

- **Change ID:** PH02-ST10-CR04-V15-0401-CSV-VALIDATION-CLOSURE.
- **Change type:** VALIDATION CLOSURE / GOVERNANCE ONLY.
- **Quality-gate evidence:** `quality-gate-20261007-112824.txt` started `2026-10-07T11:28:24.2736432+05:30` and completed `2026-10-07T11:29:27.4562435+05:30`; Release x64 PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, Infrastructure, governed coverage, and Local Quality Gate PASS; ExitCode 0.
- **Live CSV evidence:** `Cimatron-Result-Report-20261007-113508.csv` contains the approved 13-column schema and 131 detail findings, followed by a reconciled summary: PASS 3, FAIL 0, WARNING 110, NOT FOUND 4, SKIPPED 13, INFO 1; Overall Status `ACTION REQUIRED`; correlation ID `76ce74d49e7b47be9848b814b24a6eb8`.
- **Positive live matches:** Cavity block -> Cavity -> `P-20-2311`; Core block -> Core -> `P-20-2311`; core fix insert-01 -> Core Insert -> `P-20-2311`, each with occurrence path and InstanceId traceability.
- **Interpretation:** remaining WARNING / NOT FOUND findings reflect controlled model/data state (including blank/unsupported Part Type and absent DO-linked categories), not a CSV exporter failure.
- **No-mutation:** user explicitly confirmed `Assembly remains unmodified after validation: YES`; exact chat receipt timestamp was not independently captured and is not invented.
- **Package boundary:** governance/documentation only. No production source, test source, configuration, thresholds, workbook/model, CSV runtime contract, Cimatron API route, or validation behavior changed. Raw quality-gate console capture and raw exported client Result Report CSV are intentionally excluded.
- **Status:** `0.40.1 USER VALIDATED / CLOSED`.

## 2026-10-07 — Version 0.40.1 — Result Report CSV CA1859 Warning Corrective

- **Change ID:** PH02-ST10-CR04-V15-0400-CA1859-CORRECTIVE.
- **Change type:** PATCH / WARNING CORRECTIVE / ARCHITECTURE GUARD / GOVERNANCE.
- **Approval:** user explicitly approved the narrow 0.40.1 warning corrective; exact approval receipt timestamp was not independently captured and is intentionally not invented.
- **Entering evidence:** `quality-gate-20261007-111615.txt` began at `2026-10-07T11:16:15.5456922+05:30` and completed at `2026-10-07T11:17:25.4410230+05:30`. Build/tests/coverage/local gate all passed and exit code was 0, but Release x64 emitted one CA1859 warning at `SteelGradeDesignOrderEvaluation.cs(270,63)`.
- **Root cause:** private `CollectContexts` declared `IReadOnlyList<FindingComponentContext>` although it always constructs and returns a `List<FindingComponentContext>`, triggering CA1859.
- **Corrective:** return the concrete `List<FindingComponentContext>` type only. No call-site, collection contents, ordering, deduplication, or business behavior change.
- **Architecture guard:** update only the protected SHA-256 entry for the approved `SteelGradeDesignOrderEvaluation.cs` change; this is required so the architecture gate recognizes the explicitly approved source revision.
- **Versioning:** Domain assembly/file version advances to `0.40.1.0`; Application/Plugin remain `0.40.0.0`.
- **Validation responsibility:** agent performs source/diff/hash/package checks only; user must rerun the full workstation quality gate before live Cimatron CSV acceptance.

## 2026-10-07 — Version 0.40.0 — Result Report CSV Component Traceability Enhancement

- **Change ID:** PH02-ST10-CR04-V15-RESULT-REPORT-CSV-ENHANCEMENT.
- **Change type:** FEATURE / REPORTING / TEST / GOVERNANCE.
- **Approval:** user explicitly selected CSV-only output and approved implementation of component title/location/status/summary enhancements; exact approval receipt timestamp was not independently captured and is intentionally not invented.
- **Entering baseline:** 0.39.9 USER VALIDATED / CLOSED, with `quality-gate-20261007-004937.txt` PASS, controlled live Form report `Cimatron-Result-Report-20261007-005224.csv`, correlation `e53384f0f4ed4eb1aeac1967804a89cf`, and manual no-mutation confirmation YES.
- **Reporting requirement:** preserve Cimatron assembly-tree traversal sequence; expose Component Title, Occurrence Path, Instance ID, Part Type, Mold Part Material, normalized Validation Status, and Finding Code; append a summary. DO Category and DO Material columns are intentionally not added.
- **Implementation:** optional immutable component-report context is carried on `Finding`, propagated through CR-04 evidence/evaluation and `FeatureFindingView`, then expanded by the CSV export path. Multi-occurrence category findings therefore produce one exported row per actual assembly occurrence.
- **Ordering:** component rows sort by captured traversal occurrence order. No alphabetical sort is introduced. Global/non-component findings remain auditable after component rows.
- **Status contract:** `Passed/Succeeded -> PASS`; `Failed/Error/Unsupported -> FAIL`; Warning -> WARNING; `DO_COMPONENT_NOT_FOUND -> NOT FOUND`; intentional non-Part/synthetic-root/excluded or existing Skipped/NotApplicable -> SKIPPED; remaining informational findings -> INFO.
- **Summary:** Total plus PASS/FAIL/WARNING/NOT FOUND/SKIPPED/INFO counts and Overall Status. Overall Status is ACTION REQUIRED when FAIL, WARNING, or NOT FOUND exists; otherwise PASS.
- **Compatibility/safety:** CSV output only, UTF-8 BOM/escaping retained; existing Feature/Requirement/Message/Measured/Limit/CorrelationId columns retained after the new component columns. No validation semantics, DO rules, Cimatron traversal/read APIs, highlight identity, configuration, thresholds, client workbook/model, or mutation behavior change.
- **Validation responsibility:** agent does not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Fresh user workstation quality-gate evidence is required before acceptance/live use.

## 2026-10-06 — Version 0.39.3 — Native Part Type Orchestration Architecture Contract Corrective

- **Change ID:** PH02-ST10-CR04-V15-PART-TYPE-ORCHESTRATION-ARCH-CONTRACT-CORRECTIVE.
- **Change type:** PATCH / CORRECTIVE / ARCHITECTURE TEST / GOVERNANCE.
- **Approval:** user explicitly approved the narrow 0.39.3 corrective after direct ArchitectureTests output identified the native Part Type/Part Material Form orchestration source-contract failure; exact approval receipt timestamp was not independently captured and is not invented.
- **Entering evidence:** `quality-gate-20261006-214154.txt` built Release x64 successfully with 0 warnings / 0 errors, then failed Architecture Tests and exited 1. Direct execution reported `CR-04 v1.5 native Part Type/Part Material Form orchestration lost a required contract.`
- **Root cause:** the Architecture guard required bracketed literal tokens `[CAD_PART_TYPE_MISSING]` and `[CAD_PART_TYPE_UNSUPPORTED]`, while production stores the codes as `CAD_PART_TYPE_MISSING` / `CAD_PART_TYPE_UNSUPPORTED` and adds brackets dynamically through `$"[{code}] ..."`. The business/runtime contract was present; only the source-token assertion was mismatched.
- **Corrective:** change only those two required Architecture tokens to the actual code literals while preserving every other native Part Type/Part Material Form-orchestration guard and forbidden legacy-path check.
- **Production boundary:** no change to `VerifySteelGradeAgainstDesignOrder.cs`, Part Type mapping, Part Material reading, DO X/Remark semantics, whitespace/case normalization, Form reader, Cimatron PDM adapter, Table mode, configuration, models/workbook, or mutation behavior.
- **Validation:** agent performs static/source/diff/checksum/package checks only; user must rerun the full workstation quality gate before live Cimatron validation.

## 2026-10-06 — Version 0.39.2 — Form-Reader Architecture Contract Corrective

- **Change ID:** PH02-ST10-CR04-V15-FORM-READER-ARCH-CONTRACT-CORRECTIVE.
- **Change type:** PATCH / CORRECTIVE / ARCHITECTURE TEST / TEST WARNING / GOVERNANCE.
- **Approval:** user explicitly approved the narrow 0.39.2 corrective after direct ArchitectureTests output identified the Form-reader source-contract guard failure; exact approval receipt timestamp was not independently captured and is not invented.
- **Entering evidence:** `quality-gate-20261006-212934.txt` built Release x64 successfully with 0 errors and one CA1859 warning, then failed Architecture Tests; direct execution reported `CR-04 v1.5 Form reader lost a required read-only or fail-closed source contract.`
- **Root cause:** the Architecture source guard required literal tokens `SelectedMaterialFamily` and `RawRemark` inside `ExcelDesignOrderFormReader.cs`, while the approved reader implementation uses local identifiers `selectedFamily` and `rawRemark` and passes them into the typed record properties. Runtime/business behavior was not missing; the guard and implementation identifiers were mismatched.
- **Corrective:** require `selectedFamily` and `rawRemark` in the Form-reader source guard, preserving all existing read-only/fail-closed tokens and forbidden-write checks.
- **Warning cleanup:** change only the `PartTypeCategoryResolverTests.Categories()` helper return type to its concrete array type, satisfying CA1859 with no test-semantic change.
- **Production boundary:** no change to `ExcelDesignOrderFormReader.cs`, native `TMPL::Part_Type` / `TMPL::Material`, DO selected-family X + Remark semantics, trim/normalization, Table mode, Cimatron adapter, config, or mutation behavior.
- **Validation:** agent performs static/source/diff/checksum/package checks only; user must rerun the full workstation quality gate before live Cimatron validation.

## 2026-10-06 — Version 0.39.1 — Part Type Resolver Compile Corrective

- **Change ID:** PH02-ST10-CR04-V15-PART-TYPE-RESOLVER-CS1628-CORRECTIVE.
- **Change type:** PATCH / CORRECTIVE / BUILD / GOVERNANCE.
- **Approval:** user explicitly approved the narrow 0.39.1 compile corrective after review of the failed 0.39.0 workstation quality gate; exact approval receipt timestamp was not independently captured and is not invented.
- **Entering evidence:** `quality-gate-20261006-211923.txt` restored quality tools successfully, then Release x64 compilation failed in `PartTypeCategoryResolver.cs(27,21)` with `CS1628: Cannot use ref, out, or in parameter 'normalizedPartType' inside an anonymous method, lambda expression, query expression, or local function`; gate exit code 1.
- **Root cause:** the 0.39.0 resolver assigned normalized input directly to the `normalizedPartType` out parameter and then referenced that out parameter inside a LINQ `Where` lambda, which C# prohibits.
- **Corrective:** compute `string normalized = NormalizeCategoryText(rawPartType)`, assign `normalizedPartType = normalized`, and reference `normalized` inside the LINQ predicate and blank check.
- **Regression scope:** existing `PartTypeCategoryResolverTests` already cover trim/collapse/case normalization, Pressure Pad mapping, blank Part Type, and unknown Part Type; no test source change is necessary for this compiler-only correction.
- **Production boundary:** no change to native Part Type/Part Material sources, DO X/Remark interpretation, steel-grade normalization/comparison, Table mode, Cimatron adapter, configuration, model/workbook handling, or mutation behavior.
- **Validation:** agent performed static/source/diff/checksum/package checks only; user must run the full workstation quality gate before any live Cimatron validation.

## 2026-10-06 — Version 0.39.0 — Native Part Type / Part Material Production Integration

- **Approval:** user explicitly approved the 0.39.0 production plan including trim/space handling and previously agreed fail-closed checks; exact approval receipt timestamp was not independently captured and is not invented.
- **Entering evidence:** 0.38.6 user quality gate PASS (`quality-gate-20261006-194848.txt`): Release x64, 0 warnings/0 errors, all governed suites PASS, coverage/local gate PASS, exit 0.
- **Runtime API evidence:** controlled diagnostics verified `TMPL::Part_Type=Core` and later `TMPL::Material=P-20-2311` on `Core block`; later run read 8/8 targets and reported `ModificationStateChanged=False`.
- **Production Form category source:** native `TMPL::Part_Type` by occurrence `ModelPid`; trim/collapse whitespace plus case-insensitive approved-profile matching; no ModelTitle fallback.
- **Production Form material source:** native `TMPL::Material`; leading/trailing trim before existing vocabulary/comparison semantics; blank required material fails closed.
- **Design Order rule:** selected family X columns C:H plus Remark I. Exactly one X + nonblank Remark is a requirement; no X + blank Remark is no requirement; multiple X, X+blank Remark, Remark without X, or invalid marker is an input Error.
- **Compatibility:** Table mode retains the existing BOM material route. Protected generic tabular, Domain comparison/normalizer, assembly traversal and highlight files remain unchanged.
- **Safety:** read-only PDM adapter only; no update/save/create Cimatron APIs and no workbook writes.
- **Validation state:** implementation packaged for user quality-gate execution; agent did not run build/tests/coverage/analyzers/SonarQube/Cimatron.

## 2026-10-06 — Version 0.38.6 — Part Property Discovery Interop Ref-Binding Corrective

- **Change ID:** PH02-ST10-CR04-V15-PART-PROPERTY-DISCOVERY-REF-BINDING-CORRECTIVE.
- **Change type:** BUGFIX / BUILD / TEST / DOCUMENTATION / GOVERNANCE.
- **Requirement / feature:** CR-04 v1.5 developer-only Part Type / Part Material / Remark document-attribute discovery diagnostic.
- **User feedback:** `quality-gate-20261006-193513.txt` failed during Release x64 Plugin compilation before governed tests/coverage/live Cimatron validation.
- **Root cause:** the 0.38.5 source called `IPdm.RetriveDocAttribute(..., out rawAttributes, ...)`, but the actual compile-time imported Cimatron 2026 Interop method requires the second argument to be passed with `ref`. The earlier reflection evidence exposed the parameter as output metadata, which was insufficient to determine the C# call-site keyword.
- **Corrective:** initialize `object rawAttributes = null` and call `RetriveDocAttribute(occurrence.ModelPid, ref rawAttributes, string.Empty)`.
- **Regression protection:** Architecture source guard now requires both the initialized object and the exact `ref` call and no longer accepts the failed `out` form.
- **Versioning:** diagnostic evidence version and Plugin assembly/file version advance to `0.38.6` / `0.38.6.0`; request schema remains `0.38.5` because its contract is unchanged.
- **Production boundary:** no production CR-04 category/source/comparison/configuration behavior, Design Order logic, model/workbook, dependency, or mutation API change.
- **Validation:** AI agent did not run build/tests/coverage/analyzers/SonarQube/Cimatron. User later supplied `quality-gate-20261006-194848.txt`: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0. Controlled runtime diagnostics then verified `TMPL::Part_Type=Core` and `TMPL::Material=P-20-2311`; the later run read 8/8 targets and reported `ModificationStateChanged=False`.

## 2026-10-06 — Version 0.38.5 — Step 10/v1.5 Part Property Document-Attribute Discovery Diagnostic

The user supplied clean 0.38.4 workstation quality-gate evidence and installed-Interop reflection evidence. The quality gate passed Release x64 with 0 warnings / 0 errors, all governed suites, coverage collection/gate, local gate, and exit 0. The reflection investigation returned Classification B: no typed native Part Material getter was found, while installed Cimatron 2026 Interop exposes the candidate read-only PDM route `IApplication.GetPdm()` plus `IPdm.RetriveDocAttribute(string, out object, string)` and `IDocAttribute.Name` / `Value`. The reflection run made no runtime Cimatron calls.

After a client call, the approved CR-04 design direction changed: Cimatron **Part Type** is intended to identify the component category (Cavity, Core, Cavity Insert, Core Insert, Moving Core, Angular Lifter, Pressure Pad, Wear Pad, Mould Base), replacing the earlier Details/Description direction. User UI evidence showed BOM `Type` returning `Modeler`; therefore BOM `Type` is not treated as Part Type and is not promoted into CR-04 mapping.

The user approved trying the PDM/document-attribute route. 0.38.5 adds only a developer-controlled discovery diagnostic. It consumes a versioned one-shot request, reuses the existing read-only assembly occurrence reader to obtain the approved targets and their `ModelPid`, calls the verified installed `GetPdm()` / `RetriveDocAttribute(ModelPid, out object, "")` route, and emits every returned `IDocAttribute.Name`, value runtime type, and value. The diagnostic does not guess or hard-code Part Type, Part Material, or Remark attribute names.

Eight existing controlled targets are retained: `Cavity block`, `Core block`, `main insert`, `Insert#2`, `Main Core insert`, `core fix insert-01`, `Slider-01`, `Lifter-01`. Active-document `IsModified()` is recorded before and after the read. Any modification-state change fails the diagnostic. Mutation APIs including document/link attribute updates, Save/SaveAs, MakeDirty, attribute attach/factory use, and document/model/entity creation/deletion are prohibited by the new Architecture source guard.

This is evidence collection only. Production `VerifySteelGradeAgainstDesignOrder`, category resolution, BOM material reader, Design Order parsing/comparison, Domain evaluation, configuration, client workbook, and models are unchanged. The historical custom `STEEL_GRADE` body attribute remains non-production and is not used as a fallback. Production redesign waits for user-supplied 0.38.5 evidence that proves the exact Part Type / Part Material / Remark internal identities.

## 2026-10-06 — Version 0.38.4 — Step 10/v1.5 Part Material Installed-Interop Reflection Investigation

The user approved the smallest safe follow-up to the 0.38.3 correlation diagnostic: a developer-only reflection investigation of installed Cimatron 2026 Interop. No production `src/` change is authorized.

The investigation covers two candidate routes. First, it inventories typed material-related members on the relevant application/document/model/instance interfaces and their inherited interfaces. Second, it inspects the installed PDM/document-attribute surface (`IPdm`, `IDocAttribute`, `DocAttribute`) and records the exact installed signatures of `RetriveDocAttribute`, `RetriveLinkAttribute`, `GetRelatedDocuments`, `GetDocumentByPath`, and `TitleOfPid`. It also inventories every installed-Interop public member whose name contains `material`.

Authoritative API documentation supports the PDM route as a candidate mechanism: `IPartDocument.Description` is documented as the value of document attribute `CN_DESCRIPTION`, and `IPdm.RetriveDocAttribute` is documented to retrieve file/document attributes using a full path or persistent document ID. However, this does **not** prove that native Cimatron Part Material itself is stored as a document attribute. The investigation therefore records only candidate availability; native Part Material attribute identity remains `NOT VERIFIED`.

The 0.38.3 production occurrence snapshot already carries `ModelPid`, populated from the occurrence model PID. That existing fact makes a later PID-based runtime PDM read technically investigable if and only if installed reflection evidence finds a usable candidate signature and the user separately approves a live read-only diagnostic. 0.38.4 does not invoke `GetPdm`, `RetriveDocAttribute`, or any other Cimatron runtime API.

TDD is enforced through a new architecture source guard. The new investigation must contain `Assembly.ReflectionOnlyLoadFrom`, preserve the approved target/signature/evidence contract, and must not contain runtime attachment or reflection invocation mechanisms including `GetApplication(`, `GetActiveDoc(`, `AppAccess`, `CimApplicationProvider`, `GetPdm(`, `MethodInfo.Invoke`, `.Invoke(`, `PropertyInfo.GetValue`, `.GetValue(`, `InvokeMember`, `Activator.CreateInstance`, `GetTypeFromProgID`, or `Marshal.GetActiveObject`. Existing Step 07 `--reflect-capability-api` behavior remains unchanged.

Historical U17 statements remain authoritative for the retained 07A evidence and are not rewritten. 0.38.4 adds a separate `Direct Part Material API reinvestigation — AWAITING USER EXECUTION` status. No reflection Classification A/B is recorded as project evidence until the user runs the new command and supplies the generated evidence.

Production CR-04 behavior remains unchanged: native Cimatron `Part Material` remains authoritative; validation remains read-only; no custom `STEEL_GRADE` fallback is introduced; all production source/config/category mapping/Design Order/Domain/model/workbook behavior remains byte-identical to 0.38.3.

## 2026-10-06 — 0.38.3 CR-04 Part Material correlation diagnostic closure

The user supplied a clean 0.38.3 workstation quality gate (`quality-gate-20261006-164624.txt`): Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage collection/gate PASS, local quality gate PASS, exit 0. The gate ran from `2026-10-06T16:46:24.2836871+05:30` to `2026-10-06T16:47:28.0677016+05:30`. Raw quality-gate evidence remains outside the cumulative package.

The subsequent controlled live diagnostic `cr04-part-material-correlation-diagnostic-20261006-165650.txt` completed in-process and read-only. It captured eight approved target occurrences and six BOM rows. Exact case-insensitive `ModelTitle` to BOM `Standard Number` correlation matched only `Lifter-01` with material `P20` and `core fix insert-01` with material `P-20-2311`. `Cavity block`, `Core block`, `Main Core insert`, `main insert`, `Insert#2`, and `Slider-01` had no exact BOM Standard Number match. The evidence therefore confirms a correlation limitation in the current BOM-table route; it does not establish that those Parts lack native Part Material. User-provided Cimatron UI evidence separately shows `Cavity block` native Part Material = `P-20-2311`.

No production corrective is made in this closure. The approved production rule remains native Cimatron `Part Material` as the Steel Grade source, compared read-only against the Design Order, with no fallback to the legacy custom `STEEL_GRADE` body attribute. The next step is a separately approved investigation for a direct Part-level API read of native Part Material. Production source/config/category mapping/DO handling/Cimatron API route/model/workbook/dependencies remain unchanged.

## 2026-10-06 — Version 0.38.2 — Step 10/v1.5 Part Material Single-Snapshot BOM Read Corrective

- **Change ID:** PH02-ST10-CR04-V15-PART-MATERIAL-SINGLE-SNAPSHOT-CORRECTIVE.
- **Change type:** PATCH / CORRECTIVE / TEST / DOCUMENTATION.
- **Entering QG evidence:** user-supplied `quality-gate-20261006-161418.txt` validated 0.38.1 with Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage collection/gate PASS, local gate PASS, exit 0. Raw evidence remains external.
- **Live evidence:** the subsequent 0.38.1 CR-04 live CSV again produced only `[CAD_PART_MATERIAL_READ_ERROR] READ_ERROR TABULAR_HEADERS_CHANGED`; native material comparison was still not reached.
- **Corrective decision:** remove the CR-04 adapter's independent `ExpectedBomHeaders` snapshot. `CimatronBomMaterialTableReader` performs one Cimatron BOM export and one `ITabularDataReader.Read(source)` of that exact CSV. Required columns are resolved by name from the same read snapshot.
- **Fail-closed behavior retained:** if `Standard Number` or required row values are missing, existing tabular errors remain; `Material` remains optional per-row so blank Part Material reaches the controlled missing-grade business result.
- **No behavioral broadening:** native Part Material remains the sole production steel-grade source; no `STEEL_GRADE` fallback, no model/workbook mutation, no new Cimatron API, no category/DO change, and no dependency change.
- **Tests:** Architecture and CimatronIntegration source-contract guards require the one-read snapshot call and prohibit `ExpectedBomHeaders`.
- **Versioning:** aligned production assemblies / feature version to `0.38.2.0` / `0.38.2` per PATCH governance.
- **Validation:** agent performed static/source/project/hash/package checks only. Fresh workstation QG is required before another controlled live CR-04 run.

## 2026-10-06 — Version 0.38.1 — Step 10/v1.5 Part Material BOM-Header Corrective

- **Change ID:** PH02-ST10-CR04-V15-PART-MATERIAL-BOM-HEADER-CORRECTIVE.
- **Change type:** PATCH / CORRECTIVE / TEST / DOCUMENTATION.
- **Entering QG evidence:** user-supplied `quality-gate-20261006-160141.txt` validated 0.38.0: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage collection/gate PASS, local gate PASS, exit 0. Raw evidence remains external.
- **Live evidence:** first 0.38.0 CR-04 run produced only `[CAD_PART_MATERIAL_READ_ERROR] READ_ERROR TABULAR_HEADERS_CHANGED` and therefore did not reach native material comparison.
- **Root cause:** the new `CimatronBomMaterialTableReader` passed only `Standard Number` and `Material` to the shared tabular reader's `expectedHeaders` parameter. That parameter is a full-row stability contract and requires exact count/order equality with the exported BOM header row. The verified BOM CSV contains seven columns.
- **Corrective:** `ExpectedBomHeaders` now matches the already verified seven-column BOM contract (`No.`, `Qty.`, `Standard Number`, `Sub Category`, `Category`, `Visible Part Size`, `Material`). Logical CR-04 mapping remains only `Standard Number -> ModelTitle` and `Material -> Part Material`.
- **No behavioral broadening:** native Part Material remains the sole production steel-grade source; no `STEEL_GRADE` fallback, no model/workbook mutation, no new Cimatron API, no category mapping change, no DO reader change, and no dependency change.
- **Tests:** architecture and CimatronIntegration source-contract guards now require the complete BOM header contract.
- **Versioning:** aligned changed production assemblies / feature version to `0.38.1.0` / `0.38.1` per PATCH governance.
- **Validation:** agent performed static/source/project/hash/package checks only. Fresh workstation QG is required before another controlled live CR-04 run.

## 2026-10-06 — Version 0.38.0 — Step 10/v1.5 Native Part Material Production Source

- **Change ID:** PH02-ST10-CR04-V15-PART-MATERIAL-PRODUCTION-SOURCE.
- **Change type:** IMPLEMENTATION / CONFIGURATION / TEST / DOCUMENTATION.
- **Requirement / feature:** CR-04 — steel grade verification against Design Order.
- **Reason:** client discussion and user-approved Cimatron evidence establish that Steel Grade is stored in the native Cimatron `Part Material` property. The 0.37.0 read-only diagnostic proved the existing `STEEL_GRADE` body-attribute path is absent/NO_BODY for relevant client-model occurrences, so it must not remain production truth.
- **Entering evidence:** `quality-gate-20261006-152016.txt` passed Release x64 with 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure, coverage and local quality gate, exit 0. `cr04-target-component-read-diagnostic-20261006-152500.txt` completed read-only with 130 occurrences / 883 bodies.
- **Production source:** native Part Material via the already verified `IAssemblyModel.GetBomManager()` / `IBOM.Export(..., cmNoFiltering, ...)` route; exported `Material` is grade evidence and `Standard Number` is correlated to occurrence `ModelTitle`.
- **Assembly context:** existing protected `CimatronAssemblyBodyAttributeReader` remains byte-identical and is retained for occurrence/category/suppression/highlight context. Its steel-grade attribute observation is ignored by production comparison; a private traversal-only placeholder name prevents production dependence on `STEEL_GRADE`.
- **New files:** `IBomMaterialTableReader.cs`, `BomMaterialTableResult.cs`, `BomMaterialRow.cs`, `CimatronBomMaterialTableReader.cs`.
- **Modified behavior:** `VerifySteelGradeAgainstDesignOrder` reads one native Part Material table per run and supplies material values as `BomMaterialValues`; optional category/component-key body attributes remain supported independently.
- **Configuration:** `SteelGradeSource=PartMaterial`; `SteelGradeAttributeName=STEEL_GRADE` removed from production config. No fallback to the custom attribute.
- **Backward compatibility:** byte-protected Domain finding codes such as `STEEL_GRADE_ATTRIBUTE_MISSING` / `STEEL_GRADE_ATTRIBUTE_AMBIGUOUS` are retained; the v1.5 spec explicitly records that these legacy code names can now describe native Part Material evidence.
- **Tests changed:** Application orchestration/feature tests, CimatronIntegration source-contract test, Architecture source/config/project guards. Test coverage includes ignored legacy steel-grade attribute read error, blank Part Material, Part Material read error and native Part Material composition.
- **Versioning:** changed Application, CimatronIntegration, DesignChecks and Plugin production assemblies bumped to `0.38.0.0`.
- **Protected files:** all eight v1.5 protected files remain byte-identical and continue to be guarded by SHA-256 Architecture tests.
- **Client-data boundary:** original production DO workbook and raw workstation evidence remain external and are not included in the cumulative ZIP.
- **AI execution boundary:** agent performed static source/XML/hash/package checks only; no build/tests/coverage/analyzers/SonarQube/Cimatron execution is claimed.
- **Validation:** AWAITING USER WORKSTATION QUALITY GATE, followed by controlled live CR-04 run on the test-copy assembly.

## 0.37.0 — 2026-10-06 — CR-04 target-component diagnostic architecture corrective

### Entering workstation evidence
User supplied `quality-gate-20261006-151118.txt` (raw evidence remains outside the cumulative ZIP). Release x64 build succeeded with zero errors but emitted CA1859 in `Cr04TargetComponentReadDiagnostic.SplitList`; Architecture tests then failed and the gate completed `2026-10-06T15:11:34.1570113+05:30` with exit code `1`. The prior CS0012 compile blocker was resolved, confirming the remaining issue was the direct Plugin-to-Domain project reference added by the first corrective.

### Approved corrective
The user explicitly approved the architecture-preserving correction: remove the direct `CimatronCustomization.Domain` project reference from Plugin, keep the diagnostic on already exposed Application/CimatronIntegration-facing types, and change `SplitList` to return `string[]` to remove CA1859. No architecture test is weakened.

The diagnostic continues to use the production `CimatronAssemblyBodyAttributeReader` and `SteelGradeCategoryResolver`. To preserve the existing Plugin boundary, it no longer dereferences the Domain-backed body reference. The `BodyEntityId` evidence column is retained for schema continuity but records `UNAVAILABLE_AT_PLUGIN_BOUNDARY`. This limitation is explicit and preferable to introducing a production architecture exception for a temporary read-only diagnostic.

### Scope protection and validation state
No production CR-04 business logic, category mapping, Design Order reader/input, Cimatron API route, model/workbook mutation/save path, dependency upgrade, or protected CR-04 file is changed. The AI agent performed static source/project/checksum/package checks only and did not execute MSBuild/tests/coverage/analyzers/SonarQube/Cimatron. Status remains **AWAITING USER WORKSTATION QUALITY GATE**.

## 0.37.0 — 2026-10-06 — CR-04 target-component diagnostic compile corrective

### Entering workstation evidence
User supplied `quality-gate-20261006-150312.txt` (raw evidence remains outside the cumulative ZIP). The gate started `2026-10-06T15:03:12.0776352+05:30` and completed `2026-10-06T15:03:30.0257730+05:30` with exit code `1`. Release x64 compilation stopped on `Cr04TargetComponentReadDiagnostic.cs(114,50)` with CS0012: `ModelEntityReference` is defined in `CimatronCustomization.Domain`, which the Plugin project did not directly reference. The same diagnostic file produced CA1861 at line 198 for a repeated constant separator array. No Cimatron runtime diagnostic was executed.

### Approved corrective
The user explicitly approved the smallest corrective. Exact approval receipt time was not independently captured and is not invented. Scope is limited to:

1. `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj` — add the existing `CimatronCustomization.Domain` project reference required by the diagnostic's compiled type dependency.
2. `src/CimatronCustomization.Plugin/Diagnostics/Cr04TargetComponentReadDiagnostic.cs` — replace the inline `new[] { ';' }` split separator with one `static readonly char[]` to remove CA1861 without behavior change.
3. Mandatory version/history/changelog/timesheet/handoff/checksum/package updates.

### Scope protection and validation state
No production CR-04 business logic/configuration/category mapping, no Cimatron API route, no model/workbook mutation/save behavior, and no diagnostic evidence schema is changed. The eight v1.5 protected files remain byte-identical. The AI agent performed static/package/checksum verification only and did not run MSBuild/tests/coverage/analyzers/SonarQube/Cimatron. Status remains **AWAITING USER WORKSTATION QUALITY GATE**.

## 0.37.0 — 2026-10-06 — CR-04 target-component read-only diagnostic

### Approved scope
User explicitly approved the exact smallest-safe diagnostic plan: add a one-shot 30-minute request, an in-process Plugin diagnostic that calls the existing production `CimatronAssemblyBodyAttributeReader`, a request PowerShell script, Plugin project/command wiring, an Architecture read-only guard, and required governance/timesheet/checksum/package updates. No model helper/save work is in scope.

### Why this diagnostic exists
The controlled live CR-04 report exported successfully but showed seven important failures across mapped target categories, including `STEEL_GRADE_ATTRIBUTE_MISSING` and `DO_COMPONENT_NOT_FOUND`, plus many expected unmapped-component warnings. The user approved a read-only diagnostic before any further model or production-logic changes. The diagnostic is intended to distinguish ModelTitle/category mapping, body/entity placement, and production attribute visibility.

### Implementation
- `Cr04TargetComponentReadDiagnosticRequest` is versioned `0.37.0`, expires after 30 minutes, and consumes the request atomically via rename/delete.
- `Cr04TargetComponentReadDiagnostic` calls `CimatronAssemblyBodyAttributeReader.ReadNamedAttributes("STEEL_GRADE", categoryAttributeName)` and applies `SteelGradeCategoryResolver.Resolve(...)` using the deployed CR-04 mapping configuration and the approved Sridevi Form category keys.
- Evidence columns are `OccurrencePath|InstanceId|ModelTitle|ModelPID|BodyEntityId|STEEL_GRADE status|STEEL_GRADE value|Category resolution`. Zero-body occurrences are retained as `NO_BODY`; every body observed by the production reader is written.
- `Request-Cr04TargetComponentReadDiagnostic.ps1` only arms/cancels the request and writes the evidence destination; it does not launch Cimatron.
- `CimatronCommandExecution` intercepts the one-shot request before opening the normal launcher.
- Architecture guards prohibit attach/factory/save/save-as/set-attribute/selection/delete/create-entity behavior and require production-reader/category-resolution reuse plus explicit Plugin compilation/wiring.

### Scope protection
No CR-04 business logic, production reader, category mapping configuration, Design Order reader/input support, model/workbook content, dependency, or Cimatron API route is changed. All eight v1.5 protected files remain byte-identical. The diagnostic writes only its external evidence text file.

### Entering workstation evidence
User supplied `quality-gate-20261006-141026.txt` for the 0.36.0 corrective baseline: Release x64 PASS; 0 warnings / 0 errors; Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS; coverage collection/gate PASS; local quality gate PASS; exit 0; completed `2026-10-06T14:11:21.8465591+05:30`. Raw capture remains outside this ZIP.

### Validation state
Agent performed static source/XML/protected-hash/package checks only and did not execute MSBuild, tests, coverage, analyzers, SonarQube, or Cimatron. Status: **AWAITING USER WORKSTATION QUALITY GATE**. After a clean gate, the user may arm the one-shot diagnostic and return its evidence file for analysis.

## 0.36.0 — 2026-10-06 — Result Report CSV export architecture-guard corrective

### Evidence and root cause
User supplied `quality-gate-20261006-140052.txt`: Release x64 build passed with 0 warnings / 0 errors, then Architecture tests failed; the gate completed at `2026-10-06T14:01:32.6994830+05:30` with exit code 1 before Domain/Application/CimatronIntegration/Infrastructure/coverage stages. This is not accepted PASS evidence.

The failure was traced to an existing Slice 3 architecture guard that concatenated all source project files and rejected the repository when both any `PackageReference Include=` token and any `Csv` token occurred anywhere in that combined text. Adding the approved source file `ResultReportCsvExporter.cs` introduced the word `Csv`, so the old guard falsely classified the source filename as a CSV package dependency.

### Corrective
Only `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs` behavior is corrected: the no-CSV-dependency rule now parses each source `.csproj`, enumerates actual MSBuild `PackageReference` elements, and rejects only package `Include` names containing `Csv`. The approved CSV exporter/UI implementation is unchanged. No dependency, production source, config, Cimatron API, Design Order input, model, or protected CR-04 file is changed by this corrective.

### Validation state
AI agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Status remains **AWAITING USER WORKSTATION QUALITY GATE**.

## 0.36.0 — 2026-10-06 — Result Report CSV export implementation

### Approved scope
User approved a reporting/UI-only enhancement to export the Result Report as CSV. The export must include all result rows, not only the active UI filter, and must not broaden Design Order input beyond `.xlsx`/`.xls`.

### Implementation
- Added pure Plugin-side `ResultReportCsvExporter` with UTF-8 BOM output and deterministic CSV escaping for comma, double quote, CR and LF.
- `FindingReportWindow` now offers `Export Results` through a standard `SaveFileDialog`.
- Export columns are Feature, Requirement, Status, Message, Measured, Limit, CorrelationId.
- Appended summary rows for Total, Passed, Succeeded, Failed, Warning, Error, NotApplicable, Skipped and Unsupported.
- Export always consumes the complete backing `rows` collection; status filtering remains display-only.
- Existing `OnFormClosed` selection restoration is unchanged.
- Added architecture guards for the new source file, unfiltered export contract, escaping/encoding contract, explicit Plugin compilation, and continued `.xlsx/.xls`-only Design Order picker.

### Scope protection / validation state
No CR-04 business logic, category mapping, DO reader, Cimatron integration/model access, production config, client workbook, dependencies, or protected CR-04 files are changed. CSV is output/reporting only. The AI agent did not execute MSBuild, unit/architecture tests, coverage, analyzers, SonarQube, or Cimatron. Status: **AWAITING USER WORKSTATION QUALITY GATE**.

## 2026-10-06 — Version 0.35.0 — Step 10/v1.5 Slice 5 Closure

- **Change ID:** PH02-ST10-CR04-V15-SLICE5-CLOSURE.
- **Change Type:** DOCUMENTATION / GOVERNANCE / PACKAGE CLOSURE ONLY.
- **Scope closed:** approved client test mapping and controlled validation preparation introduced in 0.35.0.
- **Accepted workstation evidence:** user-supplied `quality-gate-20261006-124558.txt`; capture `2026-10-06T12:45:58.0537119+05:30`; completed `2026-10-06T12:46:59.7108075+05:30`. Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage collection/gate PASS, local quality gate PASS, exit 0.
- **Coverage:** Domain 99.74%; Application 92.95%; DesignChecks 95.95%; Infrastructure 82.27%; CimatronIntegration 2.08% measured/no threshold.
- **User closure approval:** explicitly received. Closure-processing timestamp observed at `2026-10-06T12:48:16+05:30`; no earlier exact chat approval timestamp is invented.
- **Closure meaning:** Slice 5 is CLOSED / USER VALIDATED. This closes the approved mapping/config preparation only; controlled live CR-04 business validation remains the next separate step.
- **Safety boundary:** original client Design Order and baseline Cimatron models remain protected. Any steel-grade setup, mismatch setup, save, or other mutation must be performed only on disposable test copies.
- **Mapping boundary:** approved concrete mappings remain Cavity/Core/CavityInsert/CoreInsert/MovingCore/AngularLifter. MouldBase -> CK-45 remains an approved business expectation without an invented machine-readable ModelTitle pattern. Pressure Pad/Wear Pad remain unmapped.
- **D-02:** resolved as body/entity `STEEL_GRADE` / `cmAttString`, no BOM fallback, no alternate-type probing.
- **Protected scope:** all eight v1.5 protected files remain byte-identical; no source/config/test/runtime behavior changed during this closure step.
- **Evidence handling:** raw quality-gate capture is intentionally excluded from the cumulative ZIP.
- **AI execution boundary:** agent did not execute the workstation gate or Cimatron.
- **Status:** **CLOSED / USER VALIDATED**.

## 2026-10-06 — Version 0.35.0 — Step 10/v1.5 Slice 5 Approved Client Test Mapping

- **Change ID:** PH02-ST10-CR04-V15-SLICE5-CLIENT-TEST-MAPPING.
- **Change Type:** CONFIGURATION / TEST / DOCUMENTATION.
- **Requirement / feature:** CR-04 Steel Grade Design-Order Validation.
- **Approved scope:** use the user-approved client DO + reference mold model mapping for code validation; never modify the original client DO or baseline Cimatron models; use test copies only.
- **Configuration:** adds exact controlled mappings `Cavity=Cavity block`, `Core=Core block`, `CavityInsert=main insert`, `CavityInsert=Insert*`, `CoreInsert=Main Core insert`, `CoreInsert=core fix insert-01`, `MovingCore=Slider-01`, `AngularLifter=Lifter-01`.
- **Expected grades:** mapped categories above -> `P-20-2311`; Mould Base business expectation -> `CK-45`. No machine-readable Mould Base pattern is approved, therefore no `MouldBase=` entry is added. Pressure Pad/Wear Pad remain unmapped.
- **D-02:** resolved as body/entity `STEEL_GRADE` / `cmAttString`; no BOM fallback and no alternate-type probing.
- **Tests/guards:** feature test locks parsing/order of the exact approved test mapping; architecture guards accept only that configured mapping and reject invented Mould Base/Pressure Pad/Wear Pad patterns while preserving the existing Form category contract and `.xlsx/.xls` picker.
- **Files changed:** production config; focused Application/Architecture tests; v1.5 spec; required version/changelog/history/timesheet/handoff/checksum governance.
- **Protected scope:** all eight v1.5 protected files remain byte-identical. No dependency/project/Cimatron API change.
- **Validation:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. Status remains AWAITING USER QUALITY GATE. Controlled live validation must use copies of the client DO/reference models only.

## 2026-10-06 — Version 0.34.0 — Step 10/v1.5 Slice 4 Category-Contract Closure

- **Change ID:** PH02-ST10-CR04-V15-SLICE4-CLOSURE.
- **Change Type:** VALIDATION CLOSURE / DOCUMENTATION / PACKAGING.
- **Scope:** closes only the approved Slice 4 category-mapping contract hardening; no production source, test, config, project, dependency, Cimatron API, or protected-file behavior is changed by this closure package.
- **Accepted workstation evidence:** user-supplied `quality-gate-20261006-093924.txt`; capture `2026-10-06T09:39:24.5934880+05:30`; completed `2026-10-06T09:40:20.8062496+05:30`; Release x64 PASS; 0 warnings / 0 errors; Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS; coverage collection/gate PASS; local quality gate PASS; exit code 0.
- **Coverage:** Domain 99.74% (minimum 90%); Application 92.95% (minimum 90%); DesignChecks 95.95% (minimum 95%); Infrastructure 82.27% (minimum 80%); CimatronIntegration 2.08% measured with no threshold introduced.
- **Approval:** user explicitly approved closure. Observed approval-processing timestamp recorded as `2026-10-06T09:41:54+05:30`; no earlier exact chat timestamp is invented.
- **Protected scope:** all eight v1.5 protected files remain byte-identical to their accepted hashes. Production `ComponentCategoryPatterns` remains absent; real deployment ModelTitle strings/patterns remain unresolved production input.
- **Evidence packaging:** raw quality-gate evidence is intentionally excluded from the cumulative ZIP.
- **AI execution boundary:** agent did not execute the workstation gate or Cimatron.
- **Status:** **CLOSED / USER VALIDATED**.

## 2026-10-06 — Version 0.34.0 — Step 10/v1.5 Slice 4 Category-Mapping Contract Hardening

- **Change ID:** PH02-ST10-CR04-V15-SLICE4-CATEGORY-CONTRACT.
- **Change Type:** IMPLEMENTATION / TEST / ARCHITECTURE / DOCUMENTATION.
- **Baseline:** cumulative `0.33.0` Slice 3 closure package; Slice 3 is CLOSED / USER VALIDATED on `quality-gate-20261006-011609.txt`. Raw evidence remains external.
- **Approval:** user explicitly approved the exact Slice 4 file-by-file plan. Exact approval timestamp is not independently captured and is not invented. Agent active work began at observed `2026-10-06T01:39:04+05:30`.
- **Approved category contract:** the authoritative Form category keys remain the nine already defined in `SrideviQrDg02Rev04Profile`: `Cavity`, `Core`, `CavityInsert`, `CoreInsert`, `MovingCore`, `AngularLifter`, `PressurePad`, `WearPad`, `MouldBase`. User-facing labels remain profile-defined.
- **Opaque ModelTitle rule:** ModelTitle input is treated as deployment-configured opaque string/pattern data. No production naming convention is inferred. Exact strings are valid; existing wildcard semantics remain available only when explicitly configured.
- **Fail-closed hardening:** `SteelGradeDesignOrderValidation` now rejects any configured category key that does not exactly match a category in the composed Form profile, returning `CR04_CONFIGURATION_ERROR` before the Application use case executes.
- **Tests:** existing registered `SteelGradeDesignOrderValidationFeatureTests` now exercises all nine approved category keys with arbitrary ModelTitle strings and verifies an unknown key fails before the use case. No test-runner registration change is required.
- **Architecture guard:** adds Slice 4 checks for the nine approved profile key/label contracts, profile-driven validation tokens, unchanged `.xlsx/.xls` picker/no CSV, and absence of production `ComponentCategoryPatterns`. Existing protected-hash guard remains authoritative.
- **Production config:** unchanged. Real production ModelTitle strings remain unsupplied; no fake/default mapping is added.
- **Protected scope:** all eight v1.5 protected files remain byte-identical. No dependency, project reference, client workbook, Cimatron model, launcher behavior, or Cimatron API change.
- **AI execution boundary:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron.
- **Validation state:** **AWAITING USER WORKSTATION QUALITY GATE**. Required acceptance: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage/local quality gate PASS, exit 0.

## 2026-10-06 — Version 0.33.0 — Step 10/v1.5 Slice 3 Closure

- **Phase / Step:** 02 / 10 v1.5 Slice 3 closure.
- **Change ID:** PH02-ST10-CR04-V15-SLICE3-CLOSURE.
- **Change Type:** DOCUMENTATION / GOVERNANCE / PACKAGE CLOSURE ONLY.
- **Scope closed:** CR-04 v1.5 feature/config/composition wiring introduced in 0.33.0.
- **Accepted workstation evidence:** user-supplied `quality-gate-20261006-011609.txt`; capture timestamp `2026-10-06T01:16:09.5079086+05:30`; completed `2026-10-06T01:17:07.9087928+05:30`. Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage collection/gate PASS, local quality gate PASS, exit code 0.
- **Coverage:** Domain 99.74%; Application 92.95%; DesignChecks 95.42%; Infrastructure 82.27%; CimatronIntegration 2.08% measured/no threshold.
- **User closure approval:** explicitly received after evidence review. Available session timing establishes approximately `2026-10-06T01:19+05:30`; seconds are intentionally not invented.
- **Closure meaning:** Slice 3 wiring is CLOSED / USER VALIDATED. This does not resolve real production ModelTitle-to-category mappings or other still-open client inputs.
- **Live validation state:** a controlled Form business run remains intentionally blocked until real approved `ComponentCategoryPatterns` are supplied. The absence of those mappings is a client-input dependency, not a Slice 3 implementation failure.
- **Unchanged/open inputs:** final client confirmation of `STEEL_GRADE` / `cmAttString` naming, suffix semantics, blank-grade business meaning, and template validation-range defect disposition remain open as already documented.
- **Protected files:** all eight v1.5 protected files remain byte-identical to the accepted 0.32.1 baseline; no source/config/test/runtime change occurs in this closure step.
- **Evidence handling:** raw quality-gate capture remains external and is not included in the cumulative ZIP. Production client workbook remains excluded.
- **AI execution boundary:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron; closure relies only on user-supplied workstation evidence.

## 2026-10-06 — Version 0.33.0 — Step 10/v1.5 Slice 3 Feature/Config/Composition Wiring

- **Change ID:** PH02-ST10-CR04-V15-SLICE3-FEATURE-CONFIG-COMPOSITION.
- **Change Type:** IMPLEMENTATION / CONFIGURATION / TEST / ARCHITECTURE / DOCUMENTATION.
- **Baseline:** cumulative `0.32.1` Slice 2 closure package. Slice 1 and Slice 2 are CLOSED / USER VALIDATED; accepted 0.32.1 workstation gate is `quality-gate-20261006-004944.txt` with Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local gate PASS, exit 0. Raw evidence is not included.
- **Approval:** user explicitly approved the exact Slice 3 plan at `2026-10-06T01:01+05:30` from available session metadata. Precision is minute-only; seconds are intentionally not invented.
- **Feature wiring:** `SteelGradeDesignOrderValidation` now dispatches request construction by explicit `DesignOrderFormat`. Table mode preserves worksheet/header/component-key behavior. Form mode validates the composed profile, approved category-source policy, optional category attribute, category patterns/exclusions and existing comparison policy, then constructs the Slice 2 Form request.
- **Category configuration syntax:** `ComponentCategoryPatterns` uses semicolon-separated `CategoryKey=ModelTitlePattern` entries; repeated category keys allow multiple patterns for one category. `ComponentExclusionPatterns` uses semicolon-separated ModelTitle patterns. These are configuration transport only; actual client patterns are not hard-coded.
- **Composition:** `FeatureComposition` creates the existing `ExcelTabularDataReader` path, adds `ExcelDesignOrderFormReader`, creates `SrideviQrDg02Rev04Profile`, and injects both into the existing four-argument `VerifySteelGradeAgainstDesignOrder` constructor. No new Cimatron API use is introduced.
- **Production configuration:** replaces provisional Table parameters with only known v1.5 values: `DesignOrderFormat=Form`, profile `Sridevi_QR-DG-02_REV04`, `SteelGradeSource=BodyAttribute`, `SteelGradeAttributeName=STEEL_GRADE`, `ComponentCategorySource=ModelTitleWithOptionalAttributeOverride`, `SteelGradeRepresentation=Strict`, `CompareGradeTokenOnly=false`.
- **Fail-closed unresolved input:** production ModelTitle category patterns remain unresolved and `ComponentCategoryPatterns` is intentionally absent from production config. A Form run therefore returns a configuration error before the application use case until real client mappings are approved. No fake/default production pattern is inserted. Optional exclusions/category-attribute name also remain absent unless approved/configured.
- **Tests/guards:** existing registered `SteelGradeDesignOrderValidationFeatureTests` is extended for Table/Form request construction and Form validation; no test-runner registration change is required. Architecture guards require the new Form/profile composition, preserve the `.xlsx/.xls` launcher and no CSV, retain no persisted workbook path, prohibit unresolved category patterns in production config, and retain the existing protected-file hash guard.
- **Files modified for behavior:** `src/CimatronCustomization.DesignChecks/SteelGradeDesignOrderValidation.cs`; `src/CimatronCustomization.Plugin/FeatureComposition.cs`; `config/CimatronCustomization.config.xml`; `tests/CimatronCustomization.Application.Tests/SteelGradeDesignOrderValidationFeatureTests.cs`; `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`.
- **Protected scope:** all eight v1.5 protected files remain byte-identical to the 0.32.1 hashes. `FeatureLauncherWindow.cs` remains unchanged. No dependency/project upgrade is introduced.
- **Open production-closure inputs unchanged:** real ModelTitle category patterns, final client confirmation of `STEEL_GRADE` naming, suffix semantics, blank-grade meaning and production template validation-range defect disposition.
- **AI execution boundary:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron.
- **Validation:** **AWAITING USER WORKSTATION QUALITY GATE**. Required next evidence is Release x64, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure PASS, coverage/local quality gate PASS, exit 0. Live Cimatron validation remains after a clean wiring gate and sufficient approved production category mapping input.

## 2026-10-06 — Version 0.31.1 — Step 10/v1.5 Slice 1 Closure

- **Change ID:** PH02-ST10-CR04-V15-SLICE1-CLOSURE.
- **Change type:** DOCUMENTATION / QUALITY-GATE CLOSURE.
- **Scope:** close only the approved Slice 1 Form-reader implementation/corrective using supplied workstation evidence; no source/test/config/runtime behavior changes in this closure package.
- **Entering corrective:** 0.31.0 gate `quality-gate-20261005-235128.txt` passed the build/test/coverage/local gates but had two analyzer warnings. 0.31.1 corrected only CA1859 in `ExcelDesignOrderFormReader.cs` and CA1861 in `ExcelDesignOrderFormReaderTests.cs`.
- **Accepted workstation evidence:** `quality-gate-20261006-001103.txt`, capture timestamp `2026-10-06T00:11:03.9649033+05:30`, completed `2026-10-06T00:11:59.0242846+05:30`.
- **Build result:** Release x64 PASS, **0 warnings / 0 errors**.
- **Tests:** Architecture PASS; Domain PASS; Application PASS; CimatronIntegration PASS; Infrastructure PASS.
- **Coverage/local gates:** collection PASS; Domain 99.74% (min 90), Application 95.25% (min 90), DesignChecks 98.32% (min 95), Infrastructure 82.27% (min 80), CimatronIntegration 2.08% measured/no threshold; coverage gate PASS; local quality gate PASS; exit code 0.
- **Execution responsibility:** gate was run by the user on the workstation. The agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron.
- **Cimatron runtime:** not required for this isolated Form-reader slice; no Cimatron runtime PASS is inferred.
- **Client-data boundary:** production `4075_P_DO.XLSX` remains external and is not included in repository/checksums/ZIP.
- **Closure:** Slice 1 is CLOSED / USER VALIDATED. Exact chat receipt/approval timestamp was not independently captured and is not invented.
- **Next action:** prepare/confirm exact Slice 2 category-mapping + Form/Table orchestration file plan, then obtain explicit implementation approval before edits.

## 2026-10-05 — Version 0.30.1 — Step 10/v1.5 Stage A CR-04 Production-DO Specification

- **Change ID:** PH02-ST10-CR04-V15-STAGE-A-SPEC.
- **Change type:** DOCUMENTATION / REQUIREMENT SPECIFICATION ONLY.
- **Approval:** user explicitly approved the reviewed v1.5 draft. Exact approval timestamp was not independently captured and is not invented.
- **Agent work start:** `2026-10-05T23:30:58+05:30`, taken from the live local-time source after approval.
- **Client-data boundary:** production workbook `4075_P_DO.XLSX` was used only as external Stage A evidence. It is not copied into the repository, checksum manifest, or cumulative ZIP.
- **Verified production-form facts:** `Sheet1` populated, `Sheet2`/`Sheet3` empty, print area `A1:R39`; `A39` normalizes to `QR/DG/02 REV 04 03/12/2021`; `O5=ST4075 P`; category/grade anchors are rows 18–26 at columns A/I; X-mark columns C–H and data-validation ranges match the supplied Stage A facts.
- **Template defect:** `CC27=1.2343/H-11` and `CB28=EN-353` are outside the validation ranges applied to the grade cells. v1.5 records this as an open client clarification and prohibits silent vocabulary expansion.
- **Specification added:** `docs/requirements/CR-04-Steel-Grade-Design-Order-Validation-Implementation-Spec-v1.5.md`, status Proposal, superseding v1.4 as the approved design direction.
- **Platform reconciliation:** v1.5 records Slice 3 production adapter, Slice 4A feature wiring and Slice 4B runtime Design Order selection as closed for their accepted scopes, with governed handoff references.
- **Decision state:** D-01 Option A; D-02 `STEEL_GRADE`/`cmAttString` current direction pending client name confirmation; D-03 Form reader plus retained Table mode; D-04 configured ModelTitle patterns with optional category-attribute precedence; D-05 Strict + closed vocabulary; D-06 full value / `CompareGradeTokenOnly=false` provisional; D-09 runtime picker; D-11 Form-label trim/collapse + ordinal case-sensitive; D-15 unchanged; D-16 blank-grade rule; D-17 Assist Parts excluded.
- **Comparison compatibility:** source review confirms existing `SteelGradeDesignOrderEvaluation` groups CAD evidence by normalized `ComponentKey`, so category-keyed many-to-one input can be passed unchanged after upstream mapping/blank/vocabulary handling. Per-occurrence independent match/mismatch findings would require a separately approved Domain semantic change and are not assumed by v1.5.
- **Protected-source plan:** v1.5 records exact 0.30.1 SHA-256 hashes for the generic tabular reader/orchestration, production body-attribute reader, Domain comparison/normalizer and highlight-safety/highlighter files. A future Architecture guard is planned; no test/source changes occur in this documentation step.
- **Testing plan:** future implementation requires an anonymized production-layout fixture and explicit registration through each old-style `Program.cs` / Architecture `RunAll()` runner.
- **No-mutation contract:** final validation must cover Assembly and Part `IsModified` where available plus timestamps/lengths, and workbook read-only access with `FileShare.ReadWrite` plus unchanged timestamp/length. Existing 0.30.1 evidence is not overstated: it does not independently contain Part-document `IsModified`.
- **Files changed in this documentation step:** new v1.5 spec, `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, new session handoff, and regenerated `CHECKSUMS.sha256`.
- **Files unchanged:** all `src/**`, `tests/**`, `tools/**`, project/solution files, config, Cimatron models, production assemblies and v1.4 historical spec.
- **Validation boundary:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron. This step changes documentation only. Runtime evidence remains the accepted 0.30.1 gate/smoke evidence.
- **Next gate:** produce an exact future implementation file-by-file plan from the approved v1.5 proposal and wait for explicit approval before source/config/test edits.

## 2026-10-05 — Version 0.30.1 — Step 10 CR-04 Production-Reader Positive STEEL_GRADE Smoke

- **Approval/scope:** user explicitly approved the amended narrow plan after review. Exact approval timestamp was not independently captured and is not invented. Scope is limited to a developer-only one-shot read-only smoke against the controlled disposable Assembly/Part; no Domain comparison, Design Order processing, highlighter, baseline models, production configuration or production-reader implementation changes are authorized.
- **Baseline:** 0.30.0 remains the accepted runtime baseline. Its governed handoff records the controlled positive anchor: `KA-PART-1-CR04-WRONG-TYPE`, body/entity `4`, exact requested string lookup `STEEL_GRADE`, `cmAttString`, value `P-20-2311`, and separate read-only Assembly verification with no mutation.
- **Implementation:** added `Cr04SteelGradeSmokeProbe`, `Cr04SteelGradeInProcessSmokeRequest`, `Cr04SteelGradeInProcessSmoke`, and `Request-Cr04SteelGradeInProcessSmoke.ps1`; wired them through the old-style Integration/Plugin project compile lists and the Plugin command's developer-diagnostic interception path.
- **Exact production-reader route:** `Cr04SteelGradeSmokeProbe` owns `CimatronAssemblyBodyAttributeReader` and calls `ReadNamedAttributes("STEEL_GRADE", null)`. Here `null` means no body-attribute component-key lookup; this matches the current production direction because `ComponentKeySource` is `ModelTitle`, not `BodyAttribute`.
- **Known-answer behavior:** the smoke requires exactly one `KA-PART-1-CR04-WRONG-TYPE` occurrence, exactly one target body/entity `4` observation, `Present`, exact `P-20-2311`, and zero reader `ReadError` observations. Every returned body observation is written to the raw live evidence so the complete runtime observation set can be reviewed without inventing unverified pre-run statuses/values for non-target bodies. Any mismatch is a hard-stop diagnostic failure, not a CR-04 business-rule failure.
- **No-mutation evidence:** active disposable Assembly captures path, `IsModified()`, `LastWriteTimeUtc` and length before/after. The saved disposable Part path is supplied explicitly to the one-shot request and captures `LastWriteTimeUtc` and length before/after. Success requires both snapshots to remain equivalent. The Part path is explicit so no Cimatron filename/path behavior is guessed from PID.
- **Read-only source guard:** the new positive-smoke sources are guarded against exact tokens `.Save(`, `.Attach(`, `SetAttribute(`, `GetAttributes(`, `GetEntityById(` and `cmAttInteger`. The old wrong-type smoke is separately asserted to retain `CR04_WRONG_TYPE_CONTROL` / `FAIL_SAFE_READ_ERROR_OBSERVED`; it is not subjected to the positive-smoke `cmAttInteger` textual prohibition because that diagnostic intentionally describes the wrong-type control.
- **Architecture runner:** one new guard method is registered through existing `ArchitectureBoundaryTests.RunAll()`, taking registered guards from 17 to 18. `Program.cs` is unchanged and still emits aggregate Architecture PASS/FAIL only.
- **Decision state:** this smoke validates only the actual production reader's in-process path on the controlled model. It does not broaden or re-resolve D-02; D-02 remains VERIFIED for the current implementation direction, while client-specific v1.5 naming/template treatment remains pending.
- **Validation:** agent did not run build/tests/coverage/analyzers/SonarQube/Cimatron. User supplied the governed workstation and live evidence.
- **Precondition-stopped gate:** `quality-gate-20261005-225325.txt` at `2026-10-05T22:53:25.5534189+05:30` restored quality tools, then stopped because `CimatronE.exe` was still running; exit code `1`. This is recorded as a blocked/precondition run, not implementation failure.
- **Accepted workstation gate:** `quality-gate-20261005-225434.txt` started `2026-10-05T22:54:34.5587120+05:30`, completed `2026-10-05T22:55:14.1644215+05:30`: Release x64 PASS, `0` warnings / `0` errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure suites PASS, coverage collection/gate PASS, local quality gate PASS, exit code `0`.
- **Accepted controlled live smoke:** `cr04-steel-grade-production-reader-smoke-20261005-230201.txt` has runtime UTC timestamp `2026-10-05T17:32:45.7390447+00:00` (`2026-10-05T23:02:45.7390447+05:30` local). It records exact Assembly `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`, target model `KA-PART-1-CR04-WRONG-TYPE`, body/entity `4`, 14 total body observations, target observation `root/0:14` = `Present` / `P-20-2311`, all other returned body observations `Absent`, `ReadErrorCount=0`, `AssemblyNoMutation=PASS`, `PartFileNoMutation=PASS`, and `Result=PRODUCTION_READER_STEEL_GRADE_OBSERVED`.
- **Assembly-version traceability:** live evidence reports `PluginVersion=0.29.0`. Package/governance version is `0.30.1`; Plugin assembly metadata was intentionally not advanced in this narrow slice. This is documented to avoid a future stale-deployment misread.
- **Closure:** user approved the validated result. Exact chat approval timestamp was not independently captured and is not invented. D-02 remains VERIFIED for the current implementation direction; pending client-specific CR-04 v1.5 naming/template treatment remains unchanged. Raw console/runtime evidence stays outside cumulative ZIPs.

## 2026-10-05 — Version 0.30.0 — Step 10 CR-04 D-02 Controlled Steel-Grade Attribute Setup Helper

- **Phase / Step:** 02 / 10 D-02 controlled model setup.
- **Change ID:** PH02-ST10-CR04-D02-STEEL-GRADE-SETUP.
- **Change Type:** IMPLEMENTATION / TEST / DOCUMENTATION (development helper only).
- **Requirement / feature:** CR-04 steel-grade evidence source D-02 controlled Cimatron validation.
- **Prior quality evidence:** user-supplied `quality-gate-20261005-184300.txt`, timestamp `2026-10-05T18:43:00.7617959+05:30`, completed `2026-10-05T18:43:57.5349926+05:30`: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gate PASS, exit code 0. This closes the 0.29.1 warning corrective.
- **Approval:** user explicitly approved the controlled helper extension at approximately `2026-10-05T22:00+05:30` from available session metadata; seconds are not invented.
- **Purpose:** intentionally mutate only disposable Part `KA-PART-1-CR04-WRONG-TYPE` so body/entity `4` carries `STEEL_GRADE = P-20-2311` as `cmAttString`, then prove immediate same-process exact read-back before the user manually saves the disposable Part.
- **Implementation:** extends existing `KnownAnswerModelSetup` with explicit `--steel-grade-control`; hard guards exact model/entity/name/value; mutually excludes the existing wrong-type mode; reuses the proven `GetAttributeFactory()` / `Create(...)` / `Attach(...)` setter path; preserves conflict/no-overwrite behavior; writes distinct D-02 evidence; keeps autosave disabled.
- **Architecture protection:** adds `Cr04D02SteelGradeSetupMustRemainControlled` to architecture tests, requiring the exact disposable constants/string setter/read-back markers and rejecting save/autosave API tokens in the helper.
- **Files changed:** `tools/CimatronCustomization.KnownAnswerModelSetup/Program.cs`; helper `Properties/AssemblyInfo.cs`; `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`; required `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, new session handoff, and `CHECKSUMS.sha256`.
- **Protected/unchanged:** all `src/**`, solution/project/config files, production CR-04 feature/comparison/adapter/highlighter, Design Order parsing, CR-04 v1.4 requirement text, and unrelated tests/tools.
- **Save behavior:** helper never saves. After successful read-back the user manually saves only the disposable Part. The subsequent production-reader validation is a separate read-only step.
- **AI execution boundary:** agent did not build, run tests/coverage/analyzers/SonarQube, execute the helper, or run Cimatron.
- **Validation:** AWAITING USER QUALITY GATE, then controlled helper execution. D-02 remains NOT VERIFIED until user evidence is supplied.
- **Next action:** user runs the full quality gate for 0.30.0 and supplies the capture before executing the controlled helper.

## 2026-10-05 — Version 0.29.1 — Step 10/4 CR-04 Slice 4B CA1861 Test-Warning Corrective

- **Change ID:** PH02-ST10-CR04-SLICE4B-CA1861-WARNING-CORRECTIVE.
- **Change Type:** TEST / QUALITY-GATE CORRECTIVE / DOCUMENTATION.
- **Trigger:** user-supplied `quality-gate-20261005-183432.txt` for 0.29.0 completed Release x64 build and all governed test/coverage/local gates with exit code 0, but reported **1 warning / 0 errors**. Repository closure requires 0 warnings.
- **Warning:** CA1861 at `tests/CimatronCustomization.Application.Tests/FeatureLauncherApplicationTests.cs`, caused by the repeated inline one-item array argument in `ChecklistPassesRunInputsToFeatures`.
- **Approval:** user explicitly approved the narrow warning corrective. Session metadata establishes the approval at approximately `2026-10-05T18:35+05:30`; seconds are not invented.
- **Corrective:** adds `private static readonly string[] OneSelection = { "ONE" };` and replaces only the repeated inline `new[] { "ONE" }` argument with `OneSelection`. Test behavior and assertions are unchanged.
- **Files modified:** `tests/CimatronCustomization.Application.Tests/FeatureLauncherApplicationTests.cs`; `VERSION.md`; `CHANGELOG.md`; this history; `docs/time-tracking/PROJECT-TIMESHEET.csv`; new 0.29.1 session handoff; `CHECKSUMS.sha256`.
- **Protected/unchanged:** all `src/**`; project/solution files; production config; Application/DesignChecks/Plugin production assembly metadata; CR-04 requirement text; D-03/D-09 decisions; D-02/D-05/D-06 unresolved state; Cimatron adapter/highlighter; BOM route; D-15(b); Assist Part behavior; models.
- **AI execution boundary:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron.
- **Validation:** **AWAITING USER WORKSTATION QUALITY GATE** with required 0 warnings / 0 errors. Live Cimatron validation remains blocked until that clean gate.

## 2026-10-05 — Version 0.29.0 — Step 10/4 CR-04 Slice 4B Runtime Design-Order Selection

- **Change ID:** PH02-ST10-CR04-SLICE4B-RUNTIME-DO-SELECTION.
- **Change Type:** IMPLEMENTATION / UI / APPLICATION / TEST / CONFIGURATION / DOCUMENTATION.
- **Entering evidence:** user-supplied `quality-gate-20261005-171737.txt` for 0.28.1 is accepted as clean: Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gates PASS, exit code 0.
- **Approval:** user resolved D-09 to runtime browse/select and supplied `KA-ASM-1-CR04-WRONG-TYPE-SMOKE_DO(1).xlsx` as the controlled Design Order, then explicitly approved implementation. Approval time is recorded to minute precision from session metadata (`2026-10-05T17:01+05:30`); seconds are not invented.
- **Workbook-backed D-03 values:** worksheet `Input Sheet`; header row `1`; component-key header `Component`; steel-grade header `Steel Grade`. Workbook notes state `Component` equals the Cimatron model title and the workbook is selected through the CR-04 browse dialog at runtime.
- **D-09(c) implementation:** Plugin owns the WinForms `OpenFileDialog`; accepted `.xlsx` / `.xls` selection becomes per-run `FeatureRunInputs[DesignOrderPath]`. Cancel returns before checklist execution. No Design Order path is written to config, model, registry, or filesystem by this flow.
- **Application wiring:** `ExecuteFeatureChecklist` adds a backward-compatible overload carrying optional `FeatureRunInputs` into `FeatureExecutionContext`; existing callers remain valid.
- **DesignChecks wiring:** `SteelGradeDesignOrderValidation` removes `DesignOrderPath` from the rule-parameter definition and requires it as a runtime input; the existing `VerifySteelGradeAgainstDesignOrder` use case and `DesignOrderInputPathResolver` remain the execution path.
- **Configuration:** adds the approved D-03 values, D-01 `BodyAttribute`, and workbook-backed D-04 `ModelTitle`. D-02 `SteelGradeAttributeName` and D-05/D-06 (`SteelGradeRepresentation`, `CompareGradeTokenOnly`) remain intentionally absent because the user has not yet approved those customer values. This package therefore does not claim a complete executable production CR-04 parameter set.
- **Tests/guards:** focused feature test covers required runtime path and unchanged request mapping; checklist test proves run-input propagation; architecture guard requires the file dialog/cancel flow and approved D-03 config while forbidding persisted path/path-pattern configuration.
- **Files modified:** `src/CimatronCustomization.Application/ExecuteFeatureChecklist.cs`; Application `Properties/AssemblyInfo.cs`; `src/CimatronCustomization.DesignChecks/SteelGradeDesignOrderValidation.cs`; DesignChecks `Properties/AssemblyInfo.cs`; `src/CimatronCustomization.Plugin/FeatureLauncherWindow.cs`; Plugin `Properties/AssemblyInfo.cs`; `config/CimatronCustomization.config.xml`; `tests/CimatronCustomization.Application.Tests/FeatureLauncherApplicationTests.cs`; `tests/CimatronCustomization.Application.Tests/SteelGradeDesignOrderValidationFeatureTests.cs`; `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`; governance/time/checksum/handoff files.
- **Protected/unchanged:** Domain CR-04 evaluation, Slice-2 application use-case semantics, production Cimatron traversal/attribute adapter, Result Report/highlighter, BOM route, D-09(b), D-15(b), Assist Part handling, wrong-type smoke routes, CR-04 v1.4 requirement text, and the supplied DO workbook (not embedded in the cumulative project ZIP).
- **AI execution boundary:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron.
- **Validation:** **AWAITING USER WORKSTATION QUALITY GATE**. After a clean gate, resolve D-02/D-05/D-06 before a full business-validation live run.

## 2026-10-05 — Version 0.28.1 — Step 10/4 CR-04 Slice 4A Public-API Boundary Corrective

- **Change ID:** PH02-ST10-CR04-SLICE4A-PUBLIC-API-BOUNDARY-CORRECTIVE.
- **Change Type:** BUGFIX / ARCHITECTURE / TEST / DOCUMENTATION.
- **Trigger evidence:** user-supplied `quality-gate-20261005-164722.txt` restored quality tools successfully, then Release x64 compilation failed with CS0012 at `src/CimatronCustomization.Plugin/FeatureComposition.cs(38,71)` and gate exit code 1.
- **Root cause:** `SteelGradeDesignOrderValidation` exposed a public delegate constructor whose signature included Domain `Finding`; the Plugin call to the production constructor therefore forced compiler resolution against a Domain-backed public overload. Adding Plugin→Domain is prohibited.
- **Approved correction:** production constructor `SteelGradeDesignOrderValidation(VerifySteelGradeAgainstDesignOrder)` stays public; the delegate seam becomes internal and remains available only to `CimatronCustomization.Application.Tests` via `InternalsVisibleTo`.
- **Regression protection:** focused feature tests now cover the public production constructor null guard plus the internal delegate seam; Slice-4 architecture tests reject a public Domain-backed delegate constructor and require the internal seam.
- **Files modified:** `src/CimatronCustomization.DesignChecks/SteelGradeDesignOrderValidation.cs`; DesignChecks `Properties/AssemblyInfo.cs`; `tests/CimatronCustomization.Application.Tests/SteelGradeDesignOrderValidationFeatureTests.cs`; `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`; `VERSION.md`; `CHANGELOG.md`; this history; `docs/time-tracking/PROJECT-TIMESHEET.csv`; `CHECKSUMS.sha256`.
- **Protected/unchanged:** Plugin `FeatureComposition.cs`/project references, Domain/Application behavior, production Cimatron adapter, highlighter, tabular infrastructure, configuration, D-03/D-09 unresolved values, BOM route, D-15(b), Assist Part handling, developer smoke routes, and CR-04 requirement text.
- **AI execution boundary:** agent did not execute build/tests/coverage/analyzers/SonarQube/Cimatron.
- **Validation:** **AWAITING USER WORKSTATION QUALITY GATE**. Live Cimatron validation is blocked until the corrective gate is clean.

## 2026-10-05 — Version 0.28.0 — Step 10/4 CR-04 Slice 4A Feature Wiring

- **Change ID:** PH02-ST10-CR04-SLICE4A-FEATURE-WIRING.
- **Change Type:** IMPLEMENTATION / TEST / ARCHITECTURE / DOCUMENTATION.
- **Approval:** user explicitly approved the proposed Slice 4A scope. Exact approval timestamp was not independently captured and is intentionally not invented.
- **Requirement / Feature:** CR-04 Steel Grade Design-Order Validation; Slice 4 feature + registration, with production config values deferred until D-03/D-09 customer approval.
- **Implementation:** added `SteelGradeDesignOrderValidation` in DesignChecks. It is `FeatureKind.Validation`, `DocumentContextRequirement.Assembly`, read-only, consumes only validated rule parameters, supports the already-approved D-01 Option A / D-09(a) route, delegates business evaluation to `VerifySteelGradeAgainstDesignOrder`, and aggregates returned findings without duplicating Domain logic.
- **Registration:** `FeatureComposition` now wires the existing Excel tabular reader, mapping engine, production `CimatronAssemblyBodyAttributeReader`, path resolver, application use case, and DesignChecks feature. Plugin has no direct Domain reference.
- **Configuration:** production `config/CimatronCustomization.config.xml` remains byte-identical. D-03 worksheet/header values and the production D-09 operating choice are unresolved customer inputs; placeholders/defaults are prohibited.
- **Tests prepared:** new `SteelGradeDesignOrderValidationFeatureTests` covers metadata/read-only intent, approved request mapping, invalid SteelGradeSource/ComponentKeySource/representation, Attribute-key dependency, finding aggregation, and Part-context NotApplicable through the common execution pipeline. Architecture tests add Slice-4 wiring/boundary/config guards.
- **Files added:** `src/CimatronCustomization.DesignChecks/SteelGradeDesignOrderValidation.cs`; `tests/CimatronCustomization.Application.Tests/SteelGradeDesignOrderValidationFeatureTests.cs`; new Slice-4A session handoff.
- **Files modified:** DesignChecks project/AssemblyInfo; Plugin `FeatureComposition.cs`/AssemblyInfo; Application.Tests project/Program; ArchitectureBoundaryTests; `VERSION.md`; `CHANGELOG.md`; this history; `docs/time-tracking/PROJECT-TIMESHEET.csv`; `CHECKSUMS.sha256`.
- **Protected/unchanged:** Domain Slice 1 logic, Slice 2 application use case/ports, production Cimatron adapter behavior, highlighter, BOM route, D-09(b), D-15(b), collision-frequency work, Assist Part disposition, config values, developer smoke routes, and CR-04 v1.4 requirement text.
- **AI execution boundary:** no build/tests/coverage/analyzers/SonarQube/Cimatron execution performed by the agent.
- **Validation:** **AWAITING USER EXECUTION**. Required first action is the full workstation quality gate; live Cimatron validation is blocked until that gate is clean.
- **Known limitation:** the registered feature cannot execute successfully from production config until real D-03/D-09 parameters are approved and added; missing required parameters fail through the existing configuration pipeline as `Error`.
- **Next action:** user runs the full Release x64 quality gate and supplies the captured output.

## 2026-10-05 — Version 0.27.10 — Step 10 CR-04 Post-Closure New-Session Handoff

- **Phase / Step:** 02 / 10/3.
- **Change type:** DOCUMENTATION / GOVERNANCE / SESSION HANDOFF only.
- **Trigger:** user requested an updated cumulative ZIP containing the session handoff and a prompt for the next ChatGPT session after approving the prior wrong-type smoke closure.
- **Accepted baseline carried forward:** user workstation 0.27.10 quality gate passed Release x64 with 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests, coverage gate, local quality gate and exit code 0. The in-process Plugin wrong-type smoke returned `Present=0`, `Absent=0`, `ReadError=1`, `NoMutation=PASS`, `FAIL_SAFE_READ_ERROR_OBSERVED`; user manually confirmed the assembly remained unmodified.
- **Architecture continuity:** Plugin -> Domain remains forbidden. The accepted diagnostic boundary is Plugin -> CimatronIntegration smoke probe -> production `CimatronAssemblyBodyAttributeReader`. The failed external EXE/AppAccess and standalone EXE/CimApplicationProvider smoke routes are historical invalid routes and must not be reintroduced.
- **Files added:** post-closure handoff Markdown plus paste-ready new-session prompt text.
- **Existing files changed:** `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, `CHECKSUMS.sha256`.
- **Protected/unchanged:** all `src/**`, `tests/**`, `tools/**`, solution/project/config files and CR-04 requirement text.
- **Next-session rule:** read `AGENTS.md` in full and authoritative CR-04 records, determine the next unresolved item, present a file-by-file plan, and wait for explicit user approval before editing.
- **Validation:** no new build/test/Cimatron execution is required for this documentation-only handoff; prior user-validated 0.27.10 evidence remains the runtime baseline.

## 2026-10-05 — Version 0.27.10 — Step 10 CR-04 Slice 3 Wrong-Type In-Process Smoke Closure

- **Phase / Step:** 02 / 10/3.
- **Change ID:** PH02-ST10-CR04-SLICE3-INPROCESS-SMOKE-CLOSURE.
- **Change Type:** DOCUMENTATION / TEST / COMPATIBILITY.
- **Requirement / feature:** CR-04 Steel Grade Verification Against Design Order — Slice 3 wrong-type attribute runtime semantics and no-mutation confirmation.
- **Quality-gate evidence:** user-supplied `quality-gate-20261005-152644.txt`, started `2026-10-05T15:26:44.9762010+05:30` and completed `2026-10-05T15:27:42.8670054+05:30`: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, exit code 0.
- **Live Cimatron evidence:** one-shot in-process Plugin smoke evidence `cr04-slice3-in-process-smoke-20261005-153013.txt`, runtime timestamp `2026-10-05T10:01:22.5125495+00:00` (`2026-10-05T15:31:22.5125495+05:30`). Active assembly matched `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`; target model `KA-PART-1-CR04-WRONG-TYPE`; body entity `4`; target occurrences `1`; body-4 observations `1`; `Present=0`; `Absent=0`; `ReadError=1`; `NoMutation=PASS`; `Result=FAIL_SAFE_READ_ERROR_OBSERVED`.
- **No-mutation evidence:** before and after both reported `Modified=False`, identical `LastWriteUtc=2026-10-05T07:30:58.0497087Z`, and identical file length `193024`. User separately confirmed: `Assembly remains unmodified after the smoke: YES`.
- **Interpretation:** the real production adapter, invoked inside the Cimatron Plugin process, fail-safe classified the same-name/non-string wrong-type control as read error rather than a business failure or conforming present string. No alternate-type production probe was introduced.
- **Version note:** smoke evidence reports `PluginVersion=0.27.8`, which is expected because 0.27.9 and 0.27.10 changed CimatronIntegration only. Product/package baseline remains 0.27.10.
- **Files changed by closure package:** `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, new closure handoff under `docs/history/session-handoffs/`, and `CHECKSUMS.sha256`.
- **Protected/unchanged:** all `src/**`, `tests/**`, `tools/**`, solution/project/config files, CR-04 v1.4 requirement text, production adapter, Plugin runtime code, architecture rules, traversal, highlighter, BOM, D-09(b), D-15(b), Assist Part handling and client cleanup.
- **Build result:** PASS from user workstation evidence.
- **Runtime result:** CLOSED / USER VALIDATED for this governed wrong-type in-process smoke.
- **Known limitations / deferred work:** this closure proves only the approved wrong-type production-adapter smoke and no-mutation behavior. It does not silently close separately deferred CR-04 items or client-packaging cleanup obligations.
- **Next action:** continue only with the next separately approved CR-04 Slice 3/remaining-scope item.

## 2026-10-05 — Version 0.27.10 — Step 10 CR-04 Slice 3 CA1822 Warning Corrective

- **Change ID:** PH02-ST10-CR04-SLICE3-CA1822-CORRECTIVE.
- **Change Type:** BUGFIX / BUILD / DOCUMENTATION.
- **User evidence:** `quality-gate-20261005-151856.txt` completed at `2026-10-05T15:19:56.2107699+05:30` with Release x64 build PASS, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS and exit code 0.
- **Observed blocker:** build summary still contained 1 warning / 0 errors: CA1822 at `Cr04WrongTypeSmokeProbe.cs(16,46)` because `Read(...)` did not access instance data. Under project policy, live smoke remains blocked until a clean 0-warning gate is supplied.
- **Approval:** user explicitly approved the narrow 0.27.10 warning-only corrective. Approval is recorded to minute precision from available session metadata; seconds are not invented.
- **Root cause:** the developer-only probe created `CimatronAssemblyBodyAttributeReader` as a local variable inside `Read(...)`, leaving the instance method stateless and triggering CA1822.
- **Fix:** create the same production reader once as a private readonly field on each probe instance and call `_reader.ReadNamedAttributes(...)` from `Read(...)`. No business or fail-safe result semantics change.
- **Files changed:** `src/CimatronCustomization.CimatronIntegration/Cr04WrongTypeSmokeProbe.cs`; CimatronIntegration `Properties/AssemblyInfo.cs`; required `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, `CHECKSUMS.sha256`.
- **Protected/unchanged:** production `CimatronAssemblyBodyAttributeReader`, Plugin source/project references, architecture tests, CR-04 traversal/business semantics, wrong-type classification, FeatureComposition/config, BOM, D-09(b), D-15(b), Assist Part handling, highlighter and client cleanup.
- **Versioning:** CimatronIntegration metadata advanced to `0.27.10.0`; Plugin remains `0.27.8.0`.
- **AI execution boundary:** agent did not run build/tests/coverage/static analysis/Cimatron.
- **Validation:** AWAITING USER QUALITY GATE; live in-process smoke remains blocked pending clean workstation evidence.

## 2026-10-05 — Version 0.27.9 — Step 10 CR-04 Slice 3 Compile Corrective

- **Phase / Step:** 02 / 10/3.
- **Change ID:** PH02-ST10-CR04-SLICE3-COMPILE-CORRECTIVE.
- **Trigger:** user workstation `quality-gate-20261005-143341.txt` failed during Release x64 compilation with CS0102 in `Cr04WrongTypeSmokeProbeResult`: the type declared both an integer property `ReadError` and a static factory method `ReadError`; captured gate exit code 1.
- **Approval:** user explicitly approved the narrow compile corrective. Exact approval timestamp seconds were not independently captured and are not invented.
- **Implementation:** renamed only the static factory from `ReadError(string)` to `Failure(string)` and updated its three internal call sites. The `ReadError` result-count property remains unchanged.
- **Protected/unchanged:** production `CimatronAssemblyBodyAttributeReader`, CR-04 business semantics, traversal, wrong-type classification, Plugin→Domain prohibition, architecture-test rules, FeatureComposition/config, BOM, D-09(b), D-15(b), Assist Part handling, highlighter and client cleanup.
- **Versioning:** CimatronIntegration metadata advanced to `0.27.9.0`; Plugin remains `0.27.8.0`.
- **AI execution boundary:** agent did not run the Windows/.NET Framework quality gate, tests, coverage, deployment or Cimatron live smoke.
- **Validation:** AWAITING USER QUALITY GATE; live in-process smoke remains blocked until clean workstation evidence.

## 2026-10-05 — Version 0.27.8 — Step 10 CR-04 Slice 3 Architecture-Boundary Corrective

- **Phase / Step:** 02 / 10/3.
- **Change ID:** PH02-ST10-CR04-SLICE3-ARCHITECTURE-BOUNDARY-CORRECTIVE.
- **Trigger:** user workstation 0.27.7 gate built Release x64 with 0 warnings / 0 errors, then architecture tests failed because the Plugin project directly referenced Domain; standalone architecture-test output confirmed the exact expected-vs-actual reference mismatch.
- **Approval:** user explicitly approved removing the Plugin→Domain reference, moving Domain-dependent smoke interpretation into CimatronIntegration, and subsequently approved the required smoke-specific architecture-test adjustment. Exact approval timestamp seconds were not independently captured and are not invented.
- **Implementation:** added developer-only `Cr04WrongTypeSmokeProbe`/result in CimatronIntegration; Plugin smoke now calls that probe and consumes only primitive evidence. Removed the 0.27.7 Plugin Domain ProjectReference.
- **Architecture guard:** the general Plugin reference rule remains unchanged and still forbids Domain. The CR-04 smoke-specific guard now checks the Integration probe owns production-adapter/Domain-backed interpretation and prohibits production adapter/Domain observation types in Plugin smoke source.
- **Protected/unchanged:** `CimatronAssemblyBodyAttributeReader`, CR-04 business semantics, traversal, wrong-type classification, FeatureComposition/config, BOM, D-09(b), D-15(b), Assist Part handling, highlighter and client cleanup.
- **Versioning:** Plugin and CimatronIntegration metadata advanced to `0.27.8.0`.
- **AI execution boundary:** agent did not run the Windows/.NET Framework quality gate, tests, coverage, deployment or Cimatron live smoke.
- **Validation:** AWAITING USER QUALITY GATE; live in-process smoke remains blocked until clean workstation evidence.

## 2026-10-05 — 0.27.6 — CR-04 Slice 3 in-process plugin wrong-type smoke

The user explicitly approved the planned developer-only one-shot in-process smoke. The Plugin now consumes a versioned 30-minute request file before opening the normal launcher, obtains the current application through the authoritative class/in-process `CimServicesAPI.CimApplicationProvider` route, verifies the active saved Assembly is exactly the disposable `KA-ASM-1-CR04-WRONG-TYPE-SMOKE`, captures before/after document modified state and file timestamp/length, and calls the unchanged production `CimatronAssemblyBodyAttributeReader` for `CR04_WRONG_TYPE_CONTROL`. The smoke records the target `KA-PART-1-CR04-WRONG-TYPE` occurrence(s), body entity 4 observations, Present/Absent/ReadError counts and no-mutation result. Any Present observation is a hard stop; the accepted wrong-type result remains `FAIL_SAFE_READ_ERROR_OBSERVED` with Present=0, ReadError>=1 and NoMutation=PASS. Architecture guards keep this path one-shot/read-only and forbid CimAppAccess, alternate type probing, setters/save/attach, GetEntityById and FeatureComposition registration. Production CR-04 traversal/business semantics, config, BOM, D-09(b), D-15(b), Assist Part behavior and highlighter are unchanged. The Plugin assembly/file version advances to 0.27.6.0. The exact governing CR-04 v1.4 specification is included in `docs/requirements/` to make the cumulative package self-contained. Agent environment lacks the Windows/.NET Framework/Cimatron workstation toolchain, so no Release build/test/coverage or live Cimatron PASS is claimed; user quality gate and live smoke are required.

## 2026-10-05 — 0.27.3 — CR-04 Slice 3 wrong-type helper E_FAIL evidence corrective

The user supplied a clean `0.27.2` quality gate (`quality-gate-20261005-112440.txt`): Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gates PASS, exit code 0. The user then ran the approved disposable wrong-type setup. The helper printed `ReadBack.Type: cmAttInteger` and `ReadBack.Value: 2738`, proving the genuine non-string control was created/read back correctly, after which the deliberate production-shaped `GetAttribute(cmAttString, CR04_WRONG_TYPE_CONTROL)` call threw COM `E_FAIL`. Under the approved fail-safe rule, that observation is `ReadError`; no conforming-looking string was returned, so the mandatory hard stop was not triggered.

The defect was limited to the development helper's evidence path: `AppendStringQueryObservation` did not catch the expected COM read failure, so the top-level handler emitted `KNOWN-ANSWER SETUP FAILED` and skipped the normal evidence-file/result completion. User explicitly approved the narrow corrective. Version 0.27.3 catches only `COMException` around that deliberate post-setup string query, writes `PostSetupCmAttStringQuery.Status: READ_ERROR`, exception type, HRESULT and message, and then continues normal evidence writing. No production adapter, Application contract, highlighter, FeatureComposition, configuration, model-save behavior or CR-04 business rule changes. The helper assembly/file metadata advances to 0.27.3.0; CimatronIntegration production metadata remains 0.27.2.0. Agent did not build/run the workstation gate or Cimatron.

## 2026-10-05 — 0.27.2 — CR-04 Slice 3 CA1859 warning corrective

The user-supplied `quality-gate-20261005-111916.txt` showed Release x64 build PASS, all governed test suites PASS, coverage/local quality gates PASS and exit code 0, but the build summary contained one CA1859 warning in the newly added production adapter: `CimatronAssemblyBodyAttributeReader.ReadBodies` returned `IReadOnlyList<BodyAttributeObservation>` although the implementation always returns `List<BodyAttributeObservation>`. Project policy requires 0 warnings. This corrective changes only that private helper signature to `List<BodyAttributeObservation>`, with no public-contract or runtime semantic change. Because production source changed, CimatronIntegration assembly/file metadata advances to `0.27.2.0`. Live Slice 3 smoke remains blocked pending a clean 0-warning re-run quality gate.


## 2026-10-05 — 0.27.1 — CR-04 Slice 3 test-project reference corrective

The user-supplied `quality-gate-20261005-111143.txt` showed Release x64 compilation failure in `Cr04TraversalSafetyTests.cs`: CS0012 reported that `ModelEntityReference` is defined in `CimatronCustomization.Domain`, which was not directly referenced by `CimatronCustomization.CimatronIntegrationTests`; the captured quality gate ended with exit code 1. This corrective adds the missing Domain project reference only. No production runtime source or behavior changes. Live Slice 3 smoke remains blocked pending a clean re-run quality gate.

## 2026-10-04 — Version 0.25.0 — Step 11 CR-04 Slice 2 Closure / User Validation

- **Change ID:** PH02-ST11-CR04-SLICE2-APPLICATION-CLOSURE.
- **Scope:** documentation/evidence closure only; no production/test/runtime behavior change from the approved 0.25.0 implementation.
- **User quality evidence:** `quality-gate-20261004-203340.txt`, task `quality-gate`, working directory `C:\Users\GMMSPL\source\repos\cimatron-customization\cimatron-customization`.
- **Quality-gate timing:** started `2026-10-04T20:33:40.3027184+05:30`; completed `2026-10-04T20:34:09.4951348+05:30`.
- **Build/test result:** Release x64 PASS; 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS.
- **Coverage:** Application 94.63% >= 90%; Domain 99.74%; DesignChecks 98.11%; Infrastructure 88.24%; CimatronIntegration measured 2.66% with no threshold introduced; coverage collection/gate PASS; local quality gate PASS.
- **Exit code:** 0.
- **Packaging/recovery incident:** before the successful gate, the minimal 0.25.0 overlay did not contain `tools/Invoke-QualityGate.ps1` / `tools/Invoke-And-Capture.ps1`, and the current working tree temporarily lacked those scripts. The full repository/scripts were restored before the successful gate. Classify this as packaging/recovery, not a Slice 2 implementation failure. No code corrective was required from this incident.
- **Closure approval:** user explicitly approved closure after the clean quality-gate review; receipt recorded at `2026-10-04T20:35:56+05:30`.
- **AI execution boundary:** agent did not run the workstation build/tests/coverage or Cimatron; user evidence is authoritative.
- **Status:** **SLICE 2 CLOSED / USER VALIDATED**.
- **Carry-forward:** Slice 3 remains blocked by the outstanding Slice 2A gates: top-level CR-04 highlight confirmation, D-15(b) placement-specific mapping, genuine stored-as-non-string wrong-type control, customer-like collision-frequency measurement, and genuine Assist Part enumeration/identity evidence or explicit disposition.
## 2026-10-04 — Version 0.25.0 — Step 11 CR-04 Slice 2 Application Use Case + Ports

- **Phase / Step:** 02 / 11.
- **Change ID:** PH02-ST11-CR04-SLICE2-APPLICATION.
- **Change Type:** APPLICATION / TEST / DOCUMENTATION.
- **Approval:** user explicitly approved the revised Slice 2 plan including D-01=A, D-09(a) only, D-10 first-error, D-11 strict headers/no protected tabular change, full-traversal D-15 safety, provisional attribute semantics, the complete file list, version `0.25.0`, mandatory timestamps/governance, and no agent-run build/tests. Exact approval timestamp was not independently captured and is not invented.
- **Agent work start:** `2026-10-04T19:56:11+05:30`.
- **Entering Slice 2A evidence:** user-supplied `api-capability-cr04-slice2a-20261004-193644.txt`, Cimatron 2026 SP2P1, Assembly context. The nested `CR04_Suppressed_Child_Part` was observed at path `root/1:14/1:5` with `suppressed=1`; the parent occurrence `CR04_Suppressed_SubAssembly` was reported `suppressed=0`. The user additionally observed in the UI that parent suppress/unsuppress affects the child automatically. Classification: **LIVE OBSERVED / VERIFIED FOR EFFECTIVE CHILD SUPPRESSION** only; no stronger direct-parent-flag claim. `NoMutation.Result: PASS`.
- **Assist Part disposition:** UI investigation found no verified command/property to create or classify an Assist Part. `CR04_Assist_Part_Control` is explicitly a normal part occurrence and must not be treated as evidence. D-17 runtime fixture remains **NOT AVAILABLE / NOT VERIFIED** pending authoritative creation/classification evidence or a known genuine Assist Part assembly.
- **Remaining Slice 2A gates:** top-level CR-04 highlight confirmation; D-15(b) placement-specific mapping; genuine stored-as-non-string wrong-type control; collision-frequency measurement on a customer-like assembly; genuine Assist Part enumeration. Slice 3 remains blocked.
- **Application port:** added `IAssemblyBodyAttributeReader` with a full highlighter-equivalent traversal contract. Snapshot occurrences carry path, `InstanceId`, model title/PID, direct suppression observation, effective/inherited suppression and all body observations/references. Suppressed/zero-body/non-candidate rows remain in the snapshot for D-15 uniqueness.
- **Attribute semantics:** `AttributeObservationStatus` contains only `Present`, `Absent`, `ReadError`. No `UnsupportedType` observation exists in Slice 2. `CadComponentSteelGradeEvidence` is always created with `attributeTypeUnsupported=false`.
- **Use case:** added `VerifySteelGradeAgainstDesignOrder`. It validates D-09(a), reads the configured DO sheet through existing `ReadMappedTabularData`, keeps steel-grade row values transport-optional, validates Domain input errors before CAD access, reads the full CAD snapshot, excludes effective-suppressed occurrences from business evaluation, invokes the closed Slice 1 Domain evaluator, then applies D-15 reference filtering in Application.
- **D-15 message home:** `SteelGradeOccurrenceHighlightSafety` rebuilds only findings that lose an unsafe reference, preserves RequirementId/status/measured value/limit/location and appends `[HIGHLIGHT_UNAVAILABLE]`. No Domain change is made.
- **CAD error boundary:** a controlled snapshot read error or exception from the CAD evidence port becomes `[CAD_READ_ERROR]` / `Error`; per-body read error becomes `[CAD_ATTRIBUTE_READ_ERROR]` / `Error`. Unexpected programming defects in the tabular orchestration boundary are not converted by Slice 2 into `TABULAR_FILE_READ_ERROR`.
- **D-04 handling:** no customer default is invented. The request requires an explicit `SteelGradeComponentKeySource` (`ModelTitle` or `BodyAttribute`), and the second attribute name is required only for `BodyAttribute`. BOM Standard Number is intentionally absent because D-01=A.
- **DF-06:** new Application test proves an unexpected exception from the tabular port boundary propagates rather than being rewritten by the Slice 2 use case as `TABULAR_FILE_READ_ERROR`. The protected `ExcelTabularDataReader` exception filter is unchanged, so ST06-DF-06 remains open for its separately governed platform-hardening decision.
- **Tests prepared:** `DesignOrderInputPathResolverTests`, `SteelGradeOccurrenceHighlightSafetyTests`, and `VerifySteelGradeAgainstDesignOrderTests`; custom Application test runner and explicit project compile includes updated.
- **C-01:** `CimatronCustomization.Application` production assembly metadata advanced from `0.22.0.0` to `0.25.0.0`. Application.Tests assembly metadata is intentionally unchanged, matching the existing repository practice for prior production-layer version bumps.
- **Protected/unchanged:** Domain Slice 1, Step 08B adapters, `CimatronViewportEntityHighlighter`, CimatronIntegration production code, DesignChecks, Plugin, Infrastructure/Step 06 reader/mapping code, configuration, installer and Cimatron model data.
- **AI execution boundary:** agent did not build, run tests, run coverage/static analysis, launch Cimatron or claim PASS.
- **Validation:** AWAITING USER FULL RELEASE X64 QUALITY GATE with 0 warnings / 0 errors, all governed suites PASS, coverage PASS and exit code 0. No live Cimatron run is required for this Application-only increment.

## 2026-10-04 — Version 0.24.3 — Step 10 CR-04 Slice 2A Self-Instance Root/Relation Diagnostic

- **Phase / Step:** 02 / 10.
- **Change ID:** PH02-ST10-CR04-SLICE2A-SELF-INSTANCE-ROOT-DIAGNOSTIC.
- **Change Type:** API-DISCOVERY / TEST / DOCUMENTATION.
- **Approval:** user explicitly approved the read-only self-instance investigation, the exact 0.24.3 verifier/test/version/history/checksum scope, and the mandatory `PROJECT-TIMESHEET.csv` addition.
- **Entering quality evidence:** user-supplied `quality-gate-20261004-153520.txt` — Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local quality gate PASS, exit code 0.
- **Entering live evidence:** user-supplied `api-capability-cr04-slice2a-20261004-154451.txt`, ToolVersion 0.24.2, active `KA-ASM-1`, Assembly context, no-mutation PASS.
- **Observed traversal/collision facts:** exact highlighter-equivalent traversal returned 13 occurrences, one suppressed occurrence, repeated IDs `3`, `5`, `6`, 3 repeated IDs / 6 participating occurrences, and 1 of 3 otherwise-valid known-attribute occurrences unsafe under D-15 uniqueness (33.33%).
- **Observed attribute facts:** exact known `cmAttString` value appeared on three occurrences; missing-name control returned null for all inspected bodies; wrong-type `cmAttInteger` lookup unexpectedly returned an attribute on all three known-value bodies, so wrong-type-null cannot be assumed.
- **Blocking self-instance finding:** the current PID-equality diagnostic rule returned `Traversal.SelfInstances: 0`. That rule is therefore not promoted into production. ID `3` remains observation only and is never hard-coded.
- **Diagnostic change:** for every containing Assembly reached during the existing highlighter-equivalent traversal, call `IAssemblyModel.GetRootInstance()` and record root instance ID/model type/title/PID. For every traversed occurrence, record `AssRootInstance` and `AssParentInstance` IDs where readable and explicit comparison observations against the containing root object/ID. Root pseudo-instance parent getter is intentionally not called (`ROOT/N/A`) because prior governed runtime evidence showed root-parent `E_FAIL`.
- **Safety boundary:** current PID-based self flag is retained only as a provisional comparison signal so prior evidence remains reproducible; no new production self-instance rule, business evaluation rule, collision rule, or highlighter behavior is introduced.
- **Tests changed:** `Cr04TraversalSafetyTests` adds source-contract assertions requiring root acquisition, root-parent avoidance, per-occurrence root/parent relation evidence, direct root comparisons, and the explicit no-promotion statement.
- **Files changed:** `Cr04CapabilityVerification.cs`, `Cr04TraversalSafetyTests.cs`, verifier/test `AssemblyInfo.cs`, `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, and `CHECKSUMS.sha256` only.
- **Production impact:** none; no `src/**`, Plugin, configuration, installer or model data changed.
- **AI execution boundary:** agent did not build, run tests/coverage/static analysis, or run Cimatron.
- **Validation:** AWAITING USER 0.24.3 QUALITY GATE, then exactly one controlled read-only `KA-ASM-1` CR-04 capability rerun. Slice 2A remains OPEN.

## 2026-10-02 — Version 0.22.2 — Step 08B Closure / User Validation

- **Phase / Step:** 02 / 08B.
- **Change ID:** PH02-ST08B-CLOSURE.
- **Trigger:** after the approved 0.22.1 target-row material corrective, the user supplied a clean quality gate and a successful governed live rerun, then visually confirmed the production nested-highlight path and restoration.
- **Quality evidence:** `artifacts/console-captures/quality-gate-20261002-131500.txt` — Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- **Live feature evidence:** `artifacts/diagnostics/step-08b-live-validation-pass-0.22.1.png` — all nine Step 08B findings PASS: U8 structure, U13 nested body resolution, U13 exact named attribute, U7 assembly mapping, U12 nested production highlight reference readiness, U15 BOM export/readback, U15 locked material, programmatic no-mutation, and temp cleanup.
- **U12 visual evidence:** `artifacts/diagnostics/step-08b-u12-production-highlight-confirmed-0.22.1.png` records the user-executed normal Result Report `Highlight` action. The user stated the intended nested `KA-PART-1` body highlighted.
- **Restoration evidence:** `artifacts/diagnostics/step-08b-u12-highlight-restored-unmodified-0.22.1.png` plus explicit user confirmation record that the highlight restored after closing and the Assembly remained unmodified.
- **U8:** promoted to **IN-PROCESS VERIFIED** for the locked Assembly-context occurrence structure: three `KA-PART-1` occurrences total, two top-level via `GetInstancesByModel`, one nested via recursive `SubInstances`; runtime IDs remain evidence only.
- **U13:** promoted to **IN-PROCESS VERIFIED** for the nested occurrence body/entity attribute route: body ID 4 exactly once as `cmBody`, exact `cmAttString` named lookup `STEP07_B1_TEST_ATTRIBUTE=KNOWN_ANSWER_07C3`; returned `IAttribute.Name` is not a match gate. `IAssInstance.GetAllEntities()` remains installed-Interop + live-evidence only, not authoritative-SDK documented.
- **U7:** promoted to **IN-PROCESS VERIFIED** for mapping that nested Part body into Assembly context using `IAssemblyModel.GetAssemblyEntity`.
- **U12:** promoted to **IN-PROCESS VERIFIED** through the actual production Result Report Highlight path, including user visual confirmation and restoration.
- **U15:** promoted to **IN-PROCESS VERIFIED for the approved `cmNoFiltering` material-read scope**: target `Standard Number=KA-PART-1` matched once and `Material=1.2738`. This does not newly verify `cmVisibleOnly` visibility semantics in-process.
- **No-mutation / cleanup:** programmatic document modified-state, model file timestamp/length, model-folder listing guards PASS; Step08B temp run directory removed after readback; user additionally confirmed no modified Assembly state after highlight closure.
- **Traceability:** retains the first 0.22.0 U15 `READ_ERROR TABULAR_REQUIRED_VALUE_MISSING` and the approved 0.22.1 target-row corrective that allowed unrelated blank Material rows while requiring target-row Material.
- **Scope boundary:** documentation/evidence closure only. No production code, test behavior, Plugin/runtime behavior, configuration, installer, CR-04 logic, model data or assembly metadata changed from 0.22.1.
- **DF-05:** the developer-visible Step 08B diagnostic still must be gated/removed before D5 client packaging.
- **Closure:** user explicitly approved Step 08B closure after successful live evidence. Exact approval/feedback timestamps were not independently captured and are not invented.
- **AI execution boundary:** agent did not build, run tests/coverage, or run Cimatron; user workstation/runtime evidence is authoritative.
- **Status:** **STEP 08B CLOSED / USER VALIDATED**.

## 2026-10-02 — Version 0.22.1 — Step 08B U15 Target-Row Material Corrective

- **Trigger:** user supplied a clean 0.22.0 quality gate and the single governed live `KA-ASM-1` Step 08B Result Report. U8/U13/U7 passed; U12 reference creation passed but the production Highlight action was not attempted because U15 produced an Error and the single-run stopping rule fired. Programmatic no-mutation and Step08B temp cleanup passed.
- **Observed U15 error:** `READ_ERROR TABULAR_REQUIRED_VALUE_MISSING: Required value for logical column 'Material' is missing at source row 2.`
- **Root cause:** `CimatronBomMaterialExporter` configured both `Standard Number` and `Material` as globally required columns for every parsed BOM row. This caused the validated `ITabularDataReader` to reject the CSV on an unrelated row before the adapter could locate `Standard Number=KA-PART-1`. No evidence shows that the known-answer `KA-PART-1` row lost material `1.2738`.
- **Approved corrective:** preserve `Standard Number` as required; configure `Material` as optional at table-read level; after identifying target `KA-PART-1` rows, require a non-blank Material value on the target row itself. Missing/blank target Material is an explicit `READ_ERROR`, not a business-rule failure.
- **Files changed by approved corrective:** `CimatronBomMaterialExporter.cs`, `Step08BInProcessConfirmationTests.cs`, `ArchitectureBoundaryTests.cs`, plus approved version/history/capability/time/handoff/checksum/evidence records. No other production behavior is changed.
- **Regression intent:** retain `cmNoFiltering`, the locked Step 07 BOM header, existing `ITabularDataReader`, Step08B temp isolation/cleanup, and no-mutation evidence. Architecture source guards now require optional global Material mapping plus target-row `TryGetValue` enforcement.
- **Evidence carried forward:** `artifacts/console-captures/quality-gate-20261002-124744.txt` and `artifacts/diagnostics/step-08b-live-validation-u15-read-error-0.22.0.png`.
- **Assembly metadata:** remains `0.22.0.0`; the explicitly approved 0.22.1 corrective file list did not include production `AssemblyInfo.cs`, so metadata is not silently broadened.
- **Execution boundary:** agent did not build, run tests/coverage, or launch Cimatron. 0.22.1 requires user clean quality gate before any separately governed live rerun.

## 2026-10-02 — Version 0.22.0 — Step 08B U13/U15/U8/U7/U12 In-Process Confirmation Preparation

- **Phase / Step:** 02 / 08B.
- **Change ID:** PH02-ST08B-COMPONENT-PROPERTY-ASSEMBLY-CONTEXT-INPROCESS.
- **Approval:** user explicitly approved the amended Step 08B plan and later explicitly approved adding `tests/CimatronCustomization.Application.Tests/Program.cs` when the custom console runner registration was discovered as an additional required existing-file change. Exact approval timestamps were not independently captured and are not invented.
- **Context:** Assembly; locked known-answer model `KA-ASM-1`. No CR-04 business logic is implemented.
- **U8:** capability-named occurrence reader traverses the Assembly and expects 3 `KA-PART-1` occurrences total, 2 direct `GetInstancesByModel` results, and 1 nested occurrence reached through recursive `SubInstances`. Runtime instance ID is logged evidence only.
- **U13:** nested occurrence body ID 4 must resolve exactly once as `cmBody` through `IAssInstance.GetAllEntities()`, then exact lookup `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` must return `KNOWN_ANSWER_07C3`. Returned `IAttribute.Name` is evidence only. `GetAllEntities()` is explicitly classified as installed-Interop + governed runtime evidence only because it was not found in the authoritative SDK documentation index.
- **U7/U12:** the nested reference is mapped by `IAssemblyModel.GetAssemblyEntity`. The feature returns the nested reference on a finding; the production `CimatronViewportEntityHighlighter` now resolves nested references and uses the established `ISelection.Selection` highlight boundary. No UI/pause is embedded in feature execution.
- **U15:** `IBOM.Export` uses `cmNoFiltering` and a unique run directory below `%TEMP%/CimatronCustomization/Step08B/<timestamp>/`. The exported CSV is parsed with the existing `ITabularDataReader` against the locked Step 07 header contract; target row key is `Standard Number=KA-PART-1`, expected `Material=1.2738`. Row-count/visibility semantics remain out of scope.
- **Error boundary:** `GetBomManager()` or `IBOM.Export` COM failure becomes `READ_ERROR` / Error evidence and U15 remains unverified; there is no retry or alternate API. Unexpected exceptions still reach the common Plugin error boundary.
- **No-mutation:** occurrence/mapping readers use the Step 08A document/file mutation snapshot pattern. BOM additionally compares the saved model-folder listing before/after export. Temporary cleanup is constrained to the generated Step08B subtree; cleanup failure is Warning.
- **Tests/guards:** Application fake-port tests cover locked pass, mismatch, BOM read error, cleanup warning and constructor/context guards. The custom Application test runner explicitly calls the new test fixture. Architecture guards require occurrence enumeration + exact named string lookup, prohibit U13 `GetEntityById` and returned-name equality, require U7 `GetAssemblyEntity`, guard the U15 temp/readback contract, and guard the nested production highlight route.
- **DF-05:** diagnostic is developer-visible only and must be gated/removed before D5 client packaging.
- **Assembly metadata:** Application, CimatronIntegration, DesignChecks and Plugin aligned to `0.22.0.0`.
- **AI execution boundary:** agent did not build, run tests/coverage, or launch Cimatron and claims no PASS.
- **Stopping rule:** after a clean user quality gate, exactly one live `KA-ASM-1` feature run plus one Result Report Highlight action. Any failure/error/read error/wrong highlight/no-mutation issue stops further runtime work pending review and explicit corrective approval.
- **Validation:** AWAITING USER QUALITY GATE + SINGLE GOVERNED LIVE RUN.

## 2026-10-01 — Version 0.21.4 — Step 08A U1 In-Process Confirmation Closure

- **Scope:** documentation/evidence closure only after user approval; no runtime/source correction.
- **Quality evidence:** `quality-gate-20261001-023742.txt` completed Release x64 build with 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- **Live evidence:** user ran `U1 In-Process Geometry Confirmation [U1]` inside the registered Cimatron Plugin with `KA-PART-1` active. Final report passed Volume, Center, Surface Area, and no-mutation against the locked Step 07 baseline.
- **Observed final values:** Volume `227576.68583480848`; Center `[50.000000000000007,30.000000000000004,20.000000000000032]`; Surface Area `26684.937182392918`.
- **Diagnostic traceability:** an earlier diagnostic report from the same production diagnostic runtime showed zero current-path values while still proving model/entity context and no-mutation. A subsequent governed rerun returned the correct values. Because no evidence establishes why the transient zero observation occurred, the project records both observations and does not invent a root cause.
- **Capability decision:** U1 is promoted to **IN-PROCESS VERIFIED** for the approved Part-context scope. This authorizes U1 to proceed under later CR-specific work subject to the normal CR approval and architecture boundaries; it does not automatically implement any CR.
- **Closure:** user explicitly approved Step 08A closure. Step 08A is CLOSED / USER VALIDATED; Step 08B has not started. Exact feedback/approval receipt timestamps were not independently captured and are not invented.
- **Production impact of 0.21.4:** none; documentation, retained evidence, version, time ledger and checksums only.
- **Agent execution boundary:** agent did not build/test/run Cimatron; user workstation evidence is authoritative.


## 2026-10-01 — Version 0.21.3 — Step 08A CA1861 Quality-Gate Corrective

- **Phase / Step:** 02 / 08A.
- **Change ID:** PH02-ST08A-U1-QG-CA1861-CORRECTIVE.
- **Approval:** User explicitly approved the narrow test-only corrective after review of `quality-gate-20261001-023056.txt`; exact approval timestamp was not independently captured and is not invented.
- **Incoming workstation evidence:** 0.21.2 Release x64 build PASS, architecture/domain/application/CimatronIntegration/infrastructure tests PASS, coverage/local gates PASS, exit code 0; one Roslyn `CA1861` warning remained in `U1InProcessGeometryConfirmationTests.cs`.
- **Corrective:** replace only the inline sample diagnostic string array with one reusable `private static readonly string[] SampleDiagnosticEvidence`. Test intent and expected findings remain unchanged.
- **Production impact:** none. `src/**`, Plugin runtime behavior, U1 diagnostic paths, known-answer values and production assembly metadata remain unchanged from 0.21.2.
- **Evidence retention:** copied `quality-gate-20261001-023056.txt` into `artifacts/console-captures/`.
- **Validation:** AWAITING USER CLEAN QUALITY GATE. Do not run the live Cimatron diagnostic until the gate returns 0 warnings / 0 errors.
- **AI execution boundary:** agent did not build, run tests, launch Cimatron or claim PASS.

## 2026-10-01 — 0.21.0 — Phase 02 Step 08A U1 In-Process Confirmation Foundation

## 2026-10-01 — Version 0.21.2 — Step 08A U1 In-Process Path Diagnostic

- **Phase / Step:** 02 / 08A.
- **Change ID:** PH02-ST08A-U1-INPROCESS-PATH-DIAGNOSTIC.
- **Approval:** User explicitly approved the read-only diagnostic investigation after the first live Plugin run failed U1 geometry comparisons while no-mutation passed. Exact approval timestamp was not independently captured and is not invented.
- **Incoming workstation evidence:** `quality-gate-20261001-015904.txt` is a clean PASS with 0 warnings / 0 errors, all governed tests PASS, coverage/local gates PASS, exit code 0.
- **Incoming live evidence:** first U1 Plugin run reported Failed for Volume, Center, and Surface area; Passed for no-mutation. Screenshot retained as `artifacts/diagnostics/step-08a-u1-live-validation-failed-20261001.png`.
- **Diagnostic design:** retain the existing `GetEntityById(bodyId, model)` path as the primary result; additionally reproduce Step 07's `IEntityQuery` + `cmFilterEntityType/cmBody` + `Select()` + single-service-entity-list construction and call the same three `IGeomServices` methods.
- **Evidence surfaced:** model/document/path, requested/resolved body ID/type/runtime type/service cast, current-path raw volume/center/surface area, enumerated body count/IDs/types/runtime/service casts, target presence, and Step-07-equivalent raw values or explicit read error.
- **Interpretation boundary:** 0.21.2 is diagnostic only. Even if the Step-07-equivalent values match, no path is promoted or substituted until the user returns live evidence and approves the corrective.
- **No-mutation boundary:** before/after modified-state + saved-file timestamp/length check remains mandatory and wraps both read-only paths.
- **Tests:** Application fake-port coverage adds diagnostic-evidence surfacing as Warning rows. Real Cimatron compatibility still requires user execution.
- **Version metadata:** Application, CimatronIntegration, DesignChecks, and Plugin assembly/file versions aligned to `0.21.2.0`.
- **Production impact:** foundation diagnostic observability only; no CR/SA business rule, configuration, installer, or model modification.
- **AI execution boundary:** agent did not build, run tests, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER 0.21.2 QUALITY GATE and one controlled U1 diagnostic Plugin run.


- User approved starting Step 08A after Step 07D closure and requested strict documentation/time tracking.
- Scope is intentionally limited to U1 in-process confirmation; no customer CR behavior is implemented.
- Added Application contracts `IBodyGeometryMetricsReader` and `BodyGeometryMetricsSnapshot`.
- Added `CimatronBodyGeometryMetricsReader` in CimatronIntegration. It reuses only the U1 APIs already verified in Step 07 and rejects the wrong document context/model/body.
- Added `U1InProcessGeometryConfirmationFeature` in DesignChecks with the locked `KA-PART-1` B1 baseline: body ID `4`, volume `227576.685834808`, center `[50,30,20]`, surface area `26684.9371823929`.
- Added no-mutation evidence by comparing `ICimDocument.IsModified()`, saved path, file last-write UTC, and file length before/after the read. A changed/unverifiable state becomes an execution Error rather than a business-rule failure.
- Added Plugin composition registration and fake-port tests.
- Under separately approved metadata-only scope, aligned Application, CimatronIntegration, DesignChecks, and Plugin AssemblyVersion/AssemblyFileVersion to `0.21.0.0`.
- User-supplied Step 07D workstation evidence `quality-gate-20261001-013106.txt` records Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, exit code 0. SonarQube remains a separate credentialed server-side gate.
- Step 07D promotion whitelist approval is carried as the gate into Step 08. U2/U11/U14/U17 remain excluded. Step 06 deferred items remain carried forward.
- Agent did not build/test/run Cimatron. 0.21.0 remains `AWAITING USER QUALITY GATE AND LIVE IN-PROCESS VALIDATION`.

## 2026-09-30 — Version 0.20.17

- **Phase / Step:** 02 / 07C-2 — Assembly Context architecture-guard alignment.
- **Change ID:** PH02-ST07C2-ARCH-GUARD-ALIGNMENT.
- **Change Type:** ARCHITECTURE TEST CORRECTIVE / DOCUMENTATION.
- **Approval:** User explicitly approved the narrow 0.20.17 architecture-test alignment after 0.20.16 built cleanly but failed architecture tests.
- **Evidence entering change:** `quality-gate-20260930-033343.txt` — Release x64 build PASS, 0 warnings, 0 errors, then `ARCHITECTURE TESTS: FAIL`, exit code 1.
- **Root cause:** the architecture guard still searched for the obsolete direct restore statement and therefore rejected the newly approved helper-based restore path that correctly handles an originally empty selection.
- **Correction:** update only the source-text architecture guard to require snapshot, highlight assignment, helper restore call, empty-list fallback, and restore assignment.
- **Production Impact:** none. No production `src/**`, Plugin, CR/SA, configuration, model data, COM call, distance logic, highlight sequence or restore runtime logic changed.
- **AI Execution Boundary:** agent did not build, run tests or launch Cimatron.
- **Validation:** AWAITING USER 0.20.17 QUALITY GATE; live 07C-2 remains blocked until PASS.

## 2026-09-30 — Version 0.20.16 — Step 07C-2 Compile Corrective

- **Phase / Step:** 02 / 07C-2 — Assembly Context verification.
- **Change ID:** PH02-ST07C2-COMPILE-CORRECTIVE.
- **Change Type:** DEVELOPMENT DIAGNOSTIC COMPILE CORRECTIVE / DOCUMENTATION.
- **Evidence entering change:** user workstation `quality-gate-20260930-032936.txt` failed with CS0411 at `AssemblyContextVerification.cs(214,21)` and `(218,21)` because `VerificationRuntimeContext.TryObserve<T>` could not infer `T` for matrix/vector observations. Release x64 build exited 1, so no live 0.20.15 verification is accepted.
- **Root cause:** the 0.20.15 source used `out object _` without an explicit generic argument on two `TryObserve` calls under the project's C# 7.3 compiler.
- **Fix:** change only those calls to `TryObserve<object>`; no runtime algorithm or Cimatron API input changes.
- **Known-answer state:** manual UI recording completed before runtime verification; model `KA-PART-1`, body ID `4`, top-level body gap `25.000 mm`, UCS `UCS10_1`, UI assembly extents unavailable.
- **Production Impact:** none. Production `src/**`, Plugin, CR/SA logic, configuration and model data unchanged.
- **AI Execution Boundary:** agent did not build, run tests, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER 0.20.16 QUALITY GATE, then the single approved live KA-ASM-1 run. U7-U12 remain unverified.

## 2026-09-30 — Version 0.20.15 — Step 07C-2 Assembly Context Verification Preparation

- **Phase / Step:** 02 / 07C-2.
- **Change ID:** PH02-ST07C2-ASSEMBLY-CONTEXT-VERIFY.
- **Change Type:** DEVELOPMENT-DIAGNOSTIC CORRECTIVE / READ-ONLY EVIDENCE PREPARATION / DOCUMENTATION.
- **Approval:** User explicitly approved the revised 07C-2 plan after independent review. Exact approval timestamp was not independently captured and is intentionally not invented.
- **07C-2A evidence rule:** user records expected assembly tree/nesting, placements/transforms, suppress/lock states, intended cross-component pair/distance and assembly bounding box from Cimatron UI/Measure tools. These expected values must not be generated by the APIs being tested. API discovery is permitted for identifiers the UI does not expose.
- **Implementation:** updated only the existing development `--verify-assembly-context` path. Occurrence suppression/lock reads are guarded; matching occurrence local/root transformations are recorded; `GetInstancesByModel`, `GetAssemblyEntity`, reverse `InstanceByAssemblyEnt` MATCH/MISMATCH and lock getter evidence are retained; `--ucs-id` can select the bounding-box UCS; all matching occurrence pairs are evaluated by `MinDistancePos` with IDs/depths/closest points; highlight pauses for visual observation and restores a captured or originally-empty selection.
- **Evidence independence:** no expected transform/state/gap/bounding-box values are hard-coded by the agent. Runtime output is evidence to compare against the separately user-recorded UI known answers.
- **Production impact:** none. No production `src/**`, Plugin behavior, CR/SA implementation, configuration, installer or model data changed.
- **Tests added/changed:** none. This is a development-only COM verifier path with mandatory workstation build/test gate and live Cimatron evidence.
- **AI execution boundary:** agent did not build, run tests or launch Cimatron and does not claim PASS.
- **Validation:** AWAITING USER 07C-2A UI KNOWN-ANSWER CAPTURE, 0.20.15 QUALITY GATE, AND ONE LIVE KA-ASM-1 ASSEMBLY-CONTEXT RUN. U7-U12 remain not verified until evidence is returned.
- **Stopping rule:** after the one approved live run, unresolved behavior is recorded as a limitation unless separately approved corrective work is required.

## 2026-09-30 — Version 0.20.14 — Step 07C-1 Geometry Services Closure

- **Phase / Step:** 02 / 07C-1.
- **Change ID:** PH02-ST07C1-CLOSURE.
- **Change Type:** DOCUMENTATION / GOVERNANCE CLOSURE.
- **Approval:** User explicitly approved 07C-1 closure after review of the final 0.20.13 live evidence. Exact approval timestamp was not independently captured and is intentionally not invented.
- **Quality evidence:** user workstation `quality-gate-20260930-010629.txt` completed with Release x64 build PASS, 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, exit code 0.
- **Final live evidence:** `api-capability-geometry-20260930-010854.txt`, ToolVersion 0.20.13, Part/mm context. `GetPiercingPoints` corrected case 1 returned `(100,30,20)`; bounded-face miss case 2 returned `null`; pointing-away case 3 returned `null`; direction-length case 4 with `(-2,0,0)` returned the same `(100,30,20)` point. `GetEntityPointDistance` again returned `10` and `14.142135623730951` mm. UCS 251/reference 2 rotated face-list boxes remained consistent. No-mutation evidence was `UNCHANGED`.
- **Capability conclusion:** U4 `GetPiercingPoints` is VERIFIED for the known-answer semantics exercised. U6 remains VERIFIED. U2 remains PARTIALLY VERIFIED because rotated face/entity-list semantics are established but body-list input still returns `[1,1,1,0,0,0]`. `SurfacesArea` remains NOT AVAILABLE in the installed 2026 SP2P1 contract.
- **Stop rule honored:** no additional 07C-1 runtime experiment is requested. Any residual uncertainty is carried as a documented limitation.
- **Production impact:** none. This closure changes documentation/governance only. No `src/**`, Plugin, CR/SA implementation, configuration, model data, tests, or diagnostic runtime behavior changed.
- **Transition:** 07C-1 CLOSED. The closure removes the procedural blocker on 07C-2, but 07C-2 is NOT STARTED and requires separate explicit approval.
- **AI execution boundary:** agent did not build, run tests, or launch Cimatron for 0.20.14; closure relies only on user-supplied workstation evidence.

## 2026-09-30 — Version 0.20.12 — Step 07C-1R4 Piercing Return-Shape Inspection

- **Phase / Step:** 02 / 07C-1R4.
- **Change ID:** PH02-ST07C1R4-PIERCING-RETURN-SHAPE.
- **Change Type:** DEVELOPMENT-DIAGNOSTIC RUNTIME-EVIDENCE CORRECTIVE / DOCUMENTATION.
- **Approval:** User explicitly approved the proposed 07C-1R4 scope: inspect the raw `GetPiercingPoints` return without numeric conversion, print each returned item's type/value, correct stale diagnostic version metadata, preserve read-only behavior, and maintain time/history/checksum records. Exact approval timestamp was not independently captured and is intentionally not invented.
- **Evidence entering change:** user quality gate `quality-gate-20260930-003832.txt` completed PASS with 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0. User live file `api-capability-geometry-20260930-004342.txt` showed all three `GetPiercingPoints` calls reached Cimatron but the diagnostic then raised `InvalidCastException` because at least one item in the returned array was not directly numeric. The same run retained UCS 251/reference 2 rotated-UCS evidence, `GetEntityPointDistance` values `10` and `14.142135623730951`, and no-mutation `UNCHANGED`.
- **Root cause classification:** the actual COM return shape is still unknown. The 0.20.10/0.20.11 diagnostic assumed every top-level `object[]` item was directly convertible to `double`; the live run disproved that assumption. The failure is still in evidence interpretation after the Cimatron call, not evidence that `GetPiercingPoints` itself is unavailable.
- **Approved fix:** call `GetPiercingPoints` exactly as before, capture the raw `object`, record its runtime type/value, and if it is an array record array type/rank/length plus every top-level item's runtime type/value. Nested arrays are represented through the existing recursive formatter. Do not convert the result to `double[]` in this inspection step.
- **Version metadata:** `Program.ToolVersion`, assembly version, and file version aligned to `0.20.12`; this corrects the stale `ToolVersion: 0.20.10` observed in the post-0.20.11 live evidence.
- **Production Impact:** none. No `src/**`, Plugin, CR/SA, configuration, or model-data change. 07C-2 remains blocked.
- **Tests Added/Changed:** none; the approved scope is a development-only COM return-shape inspection and the package relies on the existing quality gate plus mandatory live Cimatron evidence.
- **AI Execution Boundary:** agent did not build, run tests, launch Cimatron, or claim PASS for 0.20.12.
- **Validation:** AWAITING USER 0.20.12 QUALITY GATE and rerun of the same three approved piercing rays against face 90.
- **Next Action:** user runs the normal quality gate; only after PASS, reruns the existing final geometry command and returns the evidence file.

## 2026-09-30 — Version 0.20.10

- **Phase / Step:** 02 / 07C-1R3 — Piercing-array conversion corrective.
- **Change ID:** PH02-ST07C1R3-PIERCING-ARRAY-CORRECTIVE.
- **Change Type:** DEVELOPMENT DIAGNOSTIC BUGFIX / DOCUMENTATION.
- **Approval:** User explicitly approved the narrow 07C-1R3 corrective: accept the `object[]` returned by `GetPiercingPoints`, safely convert numeric values, correct stale evidence ToolVersion metadata, preserve production behavior, and maintain time/history records. Exact approval timestamp was not independently captured and is intentionally not invented.
- **Evidence entering change:** user live file `api-capability-geometry-20260930-001052.txt` showed UCS 251/reference 2 rotated-UCS evidence, `GetEntityPointDistance` values `10` and `14.142135623730951` with closest points `(100,30,20)` and `(100,60,20)`, three `GetPiercingPoints` runtime-binder conversion errors (`object[]` -> `double[]`), and no-mutation `UNCHANGED`.
- **Root cause:** the installed Cimatron `GetPiercingPoints` COM return surfaced as a one-dimensional `object[]`; the diagnostic used a direct `(double[])` cast. The Cimatron call itself was reached, so the failure is diagnostic result conversion, not evidence that the API capability failed.
- **Fix:** replace the direct cast with a guarded one-dimensional numeric-array conversion using invariant `Convert.ToDouble`; retain `double[]` evidence formatting. Evidence ToolVersion now uses `Program.ToolVersion` instead of the stale `0.20.7` literal. Diagnostic assembly/file version aligned to `0.20.10`.
- **Production Impact:** none. No `src/**`, Plugin, CR/SA, configuration, or model-data change. 07C-2 remains blocked.
- **Tests Added/Changed:** none; this is a development-only COM-return adaptation with no existing isolated diagnostic test harness. User quality gate remains mandatory.
- **AI Execution Boundary:** agent did not build, run tests, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER 0.20.10 QUALITY GATE and rerun of the three approved piercing rays against face 90.
- **Next Action:** user runs the normal quality gate, then copies/runs the 0.20.10 diagnostic and returns the piercing evidence.

## 2026-09-29 — Version 0.20.9

- **Phase / Step:** 02 / 07C-1R2 — Final Geometry Services resolution preparation.
- **Change ID:** PH02-ST07C1R2-FINAL-GEOMETRY-PREP.
- **Approval:** User explicitly approved the proposed 07C-1R2 scope: known-angle 30° Z UCS verification plus final `GetEntityPointDistance` and `GetPiercingPoints` known-answer evidence, with 07C-2 remaining blocked.
- **Diagnostic correction required by approved evidence design:** the prior implementation accepted only one ray and one point and sent piercing rays to all bodies. 0.20.9 keeps the existing mode but accepts repeated ray/point cases and, when `--face-id` is present, sends piercing calls to the guarded face list so face-90 bounded semantics can actually be tested.
- **Contract classification alignment:** absent installed `IGeomServices.SurfacesArea` now records `NOT_AVAILABLE`, matching the evidence-backed 2026 SP2P1 Interop finding.
- **Known-answer model boundary:** the agent did not fabricate or edit a Cimatron `.elt` file because no editable known-answer model file is present in this development package and Cimatron model editing is workstation/runtime work. User must create `KA_UCS_30Z` in the disposable `KA-PART-1`, same origin as UCS 2, +30° about Z, then discover the actual ID.
- **Production impact:** none; no `src/**`, Plugin behavior, production configuration, or CR/SA implementation changed.
- **AI execution boundary:** agent did not build, run tests, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER QUALITY GATE, rotated-UCS creation/discovery, and final live geometry evidence. 07C-1 remains open; 07C-2 blocked.

## 2026-09-29 — Version 0.20.7

- **Phase:** 02 — CR Platform Extensions
- **Step:** 07C-1R — Geometry Services build corrective
- **Change ID:** PH02-ST07C1R-QG-CORRECTIVE
- **Change Type:** DEVELOPMENT DIAGNOSTIC COMPILE CORRECTIVE / DOCUMENTATION
- **Approval:** User explicitly approved a narrow 0.20.7 build-fix package only after reviewing the 0.20.6 quality-gate failure.
- **User evidence:** `quality-gate-20260929-185330.txt` reported CS1061 at `GeometryServicesVerification.cs(141,82)`: installed `IFace` has no `Area` definition; Release x64 build failed with exit code 1.
- **Correction:** Removed the invalid direct `IFace.Area()` call. Face-area evidence remains on the existing reflection-guarded `IGeomServices.SurfacesArea` path only. Missing/failed installed API remains explicit evidence and is not replaced by an invented contract.
- **Scope boundary:** No production `src/**`, Plugin behavior, model mutation, CR/SA logic, or 07C-2/3/4 work changed. Other 07C-1R behavior remains unchanged.
- **AI Execution Boundary:** Agent did not build, run tests, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER 0.20.7 QUALITY GATE.

## 2026-09-29 — Version 0.20.6

- **Phase:** 02 — CR Platform Extensions
- **Step:** 07C-1R — Geometry Services remaining-evidence resolution
- **Change ID:** PH02-ST07C1R-GEOMETRY-RESOLUTION
- **Change Type:** DEVELOPMENT DIAGNOSTIC / READ-ONLY EVIDENCE RESOLUTION / DOCUMENTATION
- **Approval:** User explicitly approved the narrow 07C-1R scope after external review identified two omitted capability statuses (`GetPiercingPoints`, `GetEntityPointDistance`) plus the need to settle body-vs-face UCS bounding-box behavior and make face ID 90 a guarded test target.
- **Evidence entering change:** User workstation 0.20.5 quality gate passed with exit code 0. Live geometry evidence `api-capability-geometry-20260929-184047.txt` and `api-capability-geometry-20260929-184155.txt` confirmed B1/B2 metrics, 25 mm minimum distance, convex/concave edge results, and no mutation.
- **Implementation:** Extended only the existing `--verify-geometry` path with `--face-id` and `--reference-ucs-id`; added face-type guard, conditional reflected `SurfacesArea` call if present in installed Interop, face-only and B1-face-list UCS bounding boxes, and explicit NOT_TESTED lines for omitted ray/point inputs.
- **Interpretation boundary:** `[1,1,1,0,0,0]` is not declared an empty-box sentinel until the user supplies the controlled face-list comparison. Main/reference UCS ID and numeric ray/point known answers remain user/evidence inputs and are not guessed.
- **Production Impact:** None. No production `src/**`, Plugin behavior, configuration, CR/SA logic, or 07C-2/3/4 work changed.
- **AI Execution Boundary:** Agent did not build, run tests, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER QUALITY GATE AND LIVE 07C-1R EVIDENCE.

## 2026-09-29 — Version 0.20.5

- **Phase:** 02 — CR Platform Extensions
- **Step:** 07C-1D — Geometry Services verification execution checkpoint
- **Change ID:** PH02-ST07C1D-GEOMETRY-VERIFY
- **Change Type:** DOCUMENTATION / DIAGNOSTIC VERSION TRACEABILITY
- **User Evidence:** 0.20.4 full quality gate PASS, exit code 0; selected test face ID 90; selected convex edge ID 89 with `cmConvex`; selected concave edge ID 95 with `cmConcave`; all live selection evidence unchanged/no-mutation. Earlier discovery established B1 body 4, B2 body 5, 25 mm minimum distance, and `KA_UCS_90Z` ID 2 after explicit activation.
- **Change:** Lock the known-answer IDs in project documentation and publish exact `--verify-geometry` execution commands using only evidence-backed parameters. Update development-tool version labels to 0.20.5 for evidence traceability.
- **Production Impact:** None. No production `src/**`, Plugin behavior, configuration, CR/SA logic, or Geometry Services implementation logic changed.
- **Known Limitation:** Ray/through-hole and face-point known-answer numeric inputs remain unresolved and must not be inferred.
- **Validation:** AI did not run build/tests/Cimatron. User quality gate and live 07C-1 Geometry Services evidence are pending.

## 2026-09-29 — Version 0.20.3 — Step 07C-1A Geometry Known-Answer Discovery

- **Phase / Step:** 02 / 07C-1A.
- **Change ID:** PH02-ST07C1A-GEOMETRY-DISCOVERY.
- **Change Type:** DEVELOPMENT DIAGNOSTIC / READ-ONLY API DISCOVERY / DOCUMENTATION.
- **Approval:** User explicitly approved the 0.20.3 discovery diagnostic after confirming that 07C-1 must first record actual KA-PART-1 model/entity/UCS/edge IDs and known-answer values and must not guess IDs or jump to 07C-2.
- **Problem:** The 0.20.2 `--verify-geometry` mode consumes IDs but does not discover them; using unverified values would violate the Step 07 handoff.
- **Implementation:** Added `GeometryKnownAnswerDiscovery.cs` and command `--discover-geometry-targets --expect Part`. It enumerates actual bodies/faces/edges through installed entity filters, records body metrics and pair minimum distance, probes edge convexity at parameter 0.5, records active UCS entity identity where exposed, and searches the installed `EntityEnumType` names for UCS candidates at runtime rather than hard-coding an uncertain UCS enum.
- **Safety:** Read-only. Captures file/model no-mutation evidence before and after. It does not assign B1/B2/test-face/convex/concave/UCS roles from enumeration order.
- **Versioning:** Step 07 developer diagnostic source/version markers advanced to 0.20.3; production assemblies are unchanged.
- **Documentation:** Updated known-answer-model and API-capability registers; added 0.20.3 session handoff; updated version/changelog/time ledger/checksums.
- **AI Execution Boundary:** Agent did not build, run tests, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER QUALITY GATE AND LIVE DISCOVERY EVIDENCE.
- **Next Action:** User runs the quality gate, then the discovery mode with validated KA-PART-1 active and preferably `KA_UCS_90Z` activated; return evidence before finalizing 07C-1 verification inputs. 07C-2 remains blocked.

## 0.18.0 — 2026-09-28

### Step 06C1 — Mapping Contracts & Configuration
- Records Step 06B closure from user-supplied quality-gate and in-process Cimatron probe evidence.
- Adds `TabularFieldMappingDefinition` for logical field name, one-or-more configured source header candidates/aliases, approved `Text`/`Decimal` type, and required/optional metadata.
- Adds `TabularMappingDefinition` as a named, consumer-neutral mapping profile.
- Rejects blank/duplicate logical fields and ambiguous header candidates case-insensitively at configuration construction time.
- Adds focused Application contract tests for aliases, uniqueness and metadata preservation.
- No workbook-header matching engine, row-validation engine, CR-04/CR-22 business logic, Infrastructure reader behavior, dependency version, or Cimatron model/plugin behavior changed.
- Validation status: **AWAITING USER QUALITY GATE**.

## 2026-09-28 — Version 0.17.5

- **Phase/Step:** 02 / 06B — Reader Technology & Infrastructure live host validation.
- **User evidence entering change:** 0.17.4 quality gate PASS: Release x64 build PASS, 0 warnings / 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage gate/local quality gate PASS, exit code 0.
- **Observed launcher issue:** the diagnostic helper directly started `CimatronE.exe`; on the user workstation that direct process exited cleanly with exit code 0 and no Cimatron UI. The normal installed shortcut targets the same EXE/working directory, so the exact launch-behavior difference was not proven.
- **Design correction:** Step 06B does not need to own Cimatron startup. The helper now writes a one-shot request under `%TEMP%\CimatronCustomization` and tells the operator to start Cimatron normally. This keeps validation focused on in-process tabular-reader compatibility rather than Cimatron launch mechanics.
- **Trigger safety:** request contains version, UTC creation timestamp, known-answer input path and evidence path; the Plugin atomically moves/consumes the request, requires version `0.17.5` and age <= 30 minutes, and deletes the consumed request after handling.
- **Normal behavior:** when no request exists, `TryRunRequested` returns false and the existing Feature Launcher path continues unchanged.
- **Scope:** probe/read behavior, ExcelDataReader 3.9.0, System.ValueTuple 4.5.0, architecture boundary, CR-04/CR-22 logic and Cimatron model behavior are unchanged.
- **Validation:** AWAITING USER EXECUTION. AI did not build/test/run Cimatron.

## 2026-09-28 — Version 0.17.4

- User-run 0.17.3 quality gate: Release x64 build PASS with 0 warnings / 0 errors, then Architecture Tests FAIL.
- Direct architecture-test evidence: `Plugin boundary violation: unexpected top-level production source files were found.`
- Root cause: `TabularReaderRuntimeProbe.cs` was introduced as a sixth top-level source file in the Plugin project, violating the long-standing thin-entry-point source whitelist.
- Correction: moved the unchanged diagnostic probe implementation to `src/CimatronCustomization.Plugin/Diagnostics/TabularReaderRuntimeProbe.cs` and updated the project compile include.
- No architecture rule was weakened; no CR-04/CR-22 logic, reader behavior, or Cimatron model behavior changed.
- Status: awaiting user-run 0.17.4 quality gate; live Cimatron probe remains pending.

## 2026-09-28 — Version 0.17.3

- **Phase:** 02 — CR Platform Extensions
- **Step:** 06B — Reader Technology & Infrastructure live host validation
- **Change ID:** PH02-ST06B-PROBE01
- **Change Type:** DEVELOPMENT DIAGNOSTIC / LIVE VALIDATION PROBE
- **User Evidence Entering Change:** 0.17.2 quality gate PASS: Release x64 build PASS; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0. Filesystem preflight found `ExcelDataReader.dll` version 3.9.0.0 and `System.ValueTuple.dll` file version 4.6.26515.06 in the Cimatron 2026 Program directory.
- **Reason:** Filesystem presence cannot prove that the real `CimatronE.exe` host can bind the approved dependency graph and execute `ExcelTabularDataReader` without runtime load/binding failure.
- **Implementation:** Added `TabularReaderRuntimeProbe` to the Plugin and an opt-in trigger at the top-level command boundary. The probe is entered only when `CIMATRON_STEP06B_TABULAR_PROBE_FILE` is non-empty; otherwise the existing launcher flow continues unchanged. Added `Start-Step06BTabularProbe.ps1` to launch Cimatron with process-local probe variables.
- **Known-answer validation:** Probe reads the existing static BIFF8 fixture worksheet `Input` through `ExcelTabularDataReader` and requires one row containing `Block_A`, `1.2344`, `12.5`. It records process identity plus loaded Plugin/Infrastructure/ExcelDataReader/System.ValueTuple assembly versions and locations.
- **Safety:** Read-only file operation; no Cimatron model API access; no model mutation; no CR-04/CR-22 business execution. The normal Feature Launcher is bypassed only in the explicitly triggered probe process.
- **Validation:** AWAITING USER EXECUTION. AI did not execute build/tests/Cimatron. User must run the full quality gate first, then run the controlled Cimatron probe and return the evidence file.

## 2026-09-28 — Version 0.17.2

- **Phase:** 02 — CR Platform Extensions
- **Step:** 06B — Reader Technology & Infrastructure corrective validation
- **Change ID:** P02-S06B-XLS-FIXTURE-CORRECTION
- **Change Type:** TEST / DOCUMENTATION
- **Reason:** User-run 0.17.1 build was clean, but the Infrastructure test runner isolated one failure: `ReadsLegacyBiff2Workbook`. The synthetic BIFF2 stream does not carry the named worksheet metadata required by the production mapping contract.
- **Files Added:** `tests/CimatronCustomization.Infrastructure.Tests/TestData/Step06/LegacyInput.xls`; Step 06B validation handoff.
- **Files Modified:** Infrastructure test source/project, Infrastructure/Test assembly versions, `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, regenerated `CHECKSUMS.sha256`.
- **Production Behavior:** Unchanged. `ExcelTabularDataReader` is byte-for-byte unchanged from 0.17.1.
- **Test Correction:** Use static BIFF8/CDF legacy `.xls` fixture with worksheet `Input`, configured header row 1, and known-answer `Part`/`Steel Grade`/`Weight` values.
- **Validation:** **AWAITING USER EXECUTION.** User should rerun the Infrastructure test executable first, then the full quality gate.
- **Runtime Result:** Cimatron in-process dependency compatibility remains NOT VERIFIED.

## 2026-09-28 — Version 0.17.0

- **Phase:** 02 — CR Platform Extensions
- **Step:** 06B — Reader Technology & Infrastructure
- **Change ID:** P02-S06B-TABULAR-READER
- **Change Type:** IMPLEMENTATION / DEPENDENCY / TEST / DOCUMENTATION
- **Requirement / Feature:** WP8 runtime tabular reader supporting future CR-04 and CR-22 consumers.
- **Reason:** 06A established the dependency-neutral port; the approved 06B decision selected ExcelDataReader 3.9.0 for read-only `.xlsx`, `.xls`, and `.csv` support on .NET Framework 4.8.
- **Files Added:** `src/CimatronCustomization.Infrastructure/ExcelTabularDataReader.cs`; `tests/CimatronCustomization.Infrastructure.Tests/ExcelTabularDataReaderTests.cs`; `docs/platform/STEP-06B-TABULAR-READER.md`; `tools/Test-TabularDependencyPreflight.ps1`.
- **Existing Files Modified:** Infrastructure/Test `.csproj` files for approved package/reference and test registration; Infrastructure/Test `AssemblyInfo.cs` for 0.17.0; Infrastructure test `Program.cs`; `DEPENDENCIES.md`; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; regenerated `CHECKSUMS.sha256`.
- **Previous Behavior:** No runtime adapter could read workbook/CSV data through `ITabularDataReader`.
- **New Behavior:** Prepared Infrastructure adapter reads configured tables from `.xlsx`, `.xls`, or `.csv`, converts only approved `Text`/`Decimal` values, skips blank mapped rows, applies explicit safety limits and returns stable all-or-nothing errors.
- **Problem / Root Cause:** CR-04/CR-22 platform support requires customer master-data reads but the real customer workbook layout is still unavailable and Excel COM is unsuitable for deployment.
- **Fix:** Use a lightweight pinned file reader behind the Application port while keeping layout mapping external and business logic out of Infrastructure.
- **Tests Added/Changed:** Infrastructure tests for CSV, generated XLSX, generated BIFF2 XLS, missing worksheet/column, invalid decimal, row limit and size limit; test runner registration updated.
- **Validation:** **AWAITING USER EXECUTION.** AI did not build, run tests, restore NuGet packages, or execute Cimatron.
- **Cimatron Version:** 2026.x target unchanged; Cimatron API is not used by the reader.
- **Build Result:** AWAITING USER EXECUTION.
- **Runtime Result:** Cimatron in-process dependency compatibility NOT VERIFIED.
- **Known Limitations:** Customer workbook layout/formula/date/locale/merged/hidden semantics remain unknown. CSV worksheet name is ignored. Invariant decimal-string parsing is temporary until customer evidence requires another policy. Host binding collision risk remains open until preflight/live probe.
- **Next Action:** User runs dependency preflight before build, returns output; if acceptable, user runs full quality gate. After clean evidence, prepare/execute controlled in-process Cimatron reader probe before closing 06B.

## 2026-09-28 — Version 0.16.0

- **Phase:** 02 — CR Platform Extensions
- **Step:** 06A — Tabular input requirement and Application contract
- **Change ID:** P02-S06A-TABULAR-CONTRACT
- **Change Type:** IMPLEMENTATION / TEST / DOCUMENTATION
- **Requirement / Feature:** WP8 tabular-input platform capability supporting future CR-04 and CR-22 implementation.
- **Reason:** The approved Phase 02 specification requires an Application port that reads customer tabular master data while keeping the customer workbook layout configuration-driven. The actual customer DO Input Sheet and slider weight/diameter table layouts are not yet supplied.
- **Files Added:** `src/CimatronCustomization.Application/ITabularDataReader.cs`, `TabularColumnDefinition.cs`, `TabularReadResult.cs`, `TabularRow.cs`, `TabularSourceDefinition.cs`, `TabularTable.cs`, `TabularValue.cs`, `TabularValueType.cs`; `tests/CimatronCustomization.Application.Tests/TabularInputContractTests.cs`; `tests/TestData/Step06/*`; `docs/platform/STEP-06-TABULAR-INPUT-CONTRACT.md`.
- **Existing Files Modified:** Application/Test `.csproj` files to compile the new approved files; Application test `Program.cs` to execute the contract tests; Application `AssemblyInfo.cs` for the new 0.16.0 Application capability version; `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, and regenerated `CHECKSUMS.sha256` for mandatory release traceability/integrity.
- **Previous Behavior:** No tabular-input Application port or typed tabular contract existed.
- **New Behavior:** Application exposes a dependency-neutral, configuration-driven tabular contract with runtime file path, worksheet/header/column mappings, typed `Text`/`Decimal` values, row/table models, and all-or-nothing read results.
- **Problem / Root Cause:** WP8 could not be implemented safely from a guessed customer workbook layout.
- **Fix:** Separate stable logical column names from customer source headers and keep worksheet/header/column mapping external to the reader contract. Use only requirement-proven cell types in 06A.
- **Tests Added/Changed:** `TabularInputContractTests` covers required source/mapping validation, duplicate mapping rejection, approved type set, typed rows, required-column consistency, and all-or-nothing actionable read results.
- **Validation:** **AWAITING USER EXECUTION.** Per AGENTS.md, AI did not run build, tests, coverage, quality gate, or Cimatron.
- **Cimatron Version:** 2026.x target unchanged; 06A contains no Cimatron API usage.
- **Build Result:** AWAITING USER EXECUTION.
- **Runtime Result:** Not applicable to 06A until a reader implementation exists.
- **Known Limitations:** Customer worksheet names, header rows, columns, formulas, merged cells, hidden sheets/rows, locale/date semantics, supported file formats, shared-read behavior and size limits are unresolved. No runtime Excel reader dependency is selected. Temporary CSV fixtures are not customer layouts.
- **Next Action:** User runs the standard full quality gate. After PASS and approval, Step 06B presents the reader/library decision and host-process dependency check before any runtime dependency is added.

## 2026-09-27 — Version 0.15.36

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05C2-B — Hidden occurrence-state validation
- **Change Type:** DOCUMENTED EXCEPTION / STEP CLOSURE CHECKPOINT
- **User Quality Evidence:** 0.15.35 full quality gate completed cleanly: Release x64 build PASS with 0 warnings / 0 errors; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.
- **Final Runtime Evidence:** `--probe-occurrence-interfaces` queried 528 unique installed-Interop COM IIDs per known-answer occurrence and released each successful interface pointer immediately. Visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B` exposed identical interface sets. No-mutation evidence was `UNCHANGED`.
- **Newly Surfaced Interface:** `IEntityQuery` was the only supported interface missed by the prior visibility-name search. Reflection showed only `CreateFilter`, `GetFilter`, `Select`, and `SetFilter`; there is no hidden/visibility getter. No newly discovered member was invoked.
- **Stopping Rule Applied:** End reflection-based hidden-state discovery. FR-021 is now `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance`.
- **Closure Decision:** Step 05C2-B is closed with the documented FR-021 hidden-state exception. This is a technical step closure, not approval to change CR-11 product scope. Any suppressed-only initial shipping decision requires explicit client/product approval.
- **Version-label Correction:** Development diagnostic `ToolVersion`/banner corrected from stale 0.15.34 to 0.15.36 only; runtime probing semantics unchanged.
- **Production Impact:** None. Production `src/`, Assembly Pick, and production Zoom-to-result remain unchanged.
- **Vendor Dependency:** Hidden occurrence readback remains pending authoritative Cimatron guidance. Vendor-outreach status is not asserted by this package.

## 0.15.34 — Phase 02 Step 05C2-B — Final occurrence COM-interface diagnostic

User explicitly approved one final reflection-based hidden-state diagnostic with a defined method and stopping point. User-run 0.15.33 quality gate is PASS (Release x64 0 warnings / 0 errors; all required test suites PASS; coverage/local gate PASS; exit 0). User-run 0.15.33 `--reflect-visibility-api` also succeeded and confirmed there is no genuinely new occurrence-level visibility getter in the name-based inventory: `IgnoreInShowOperations` is already non-discriminating, `_IAssInstance.get_Show_()` remains closed by 0.15.29 `E_NOINTERFACE`, and the visibility/blank attributes remain metadata without occurrence semantics.

### Approved method
- Enumerate every COM interface type/GUID from installed `interop.Cim*.dll`; retain aliases but deduplicate runtime checks by IID.
- Locate visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B` in the approved known-answer Assembly using already-approved read-only occurrence traversal/model-title/suppression reads.
- For each target occurrence call `Marshal.QueryInterface` exactly once per unique IID, record support/HRESULT, and immediately `Marshal.Release` every successful returned pointer; release the acquired IUnknown after the loop.
- Where supported, read COM class/type-info metadata through `IProvideClassInfo.GetClassInfo` and/or `IDispatch.GetTypeInfo`.
- Emit an interface × object matrix.
- For supported interfaces the previous visibility-name search missed, reflect member metadata and classify getter/setter/method only; do not invoke any newly discovered member.
- Capture before/after no-mutation evidence. Production `src/`, Assembly Pick, and production Zoom-to-result remain unchanged.

### Expectation and stopping rule
Identical interface sets are the expected/most likely outcome because hidden versus visible is normally data on the same object type rather than a different interface identity. If analysis of this run yields no new supported interface/member path, reflection-based hidden-state discovery stops. FR-021 is then to be recorded as `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance`, and Step 05C2-B closure with that documented exception is to be proposed. Any suppressed-only initial product scope is a client/product decision and must not be made silently. Vendor-email status is not asserted by this package and must be confirmed if the stop rule triggers.

### Validation
AI did not run build/tests/Cimatron. User must run the full quality gate first; only after PASS run `CimatronCustomization.ZoomCommandDiscovery.exe --probe-occurrence-interfaces` with the approved known-answer copy active and return the generated evidence.

# Implementation History

## 2026-10-01 — Phase 02 Step 08A Quality-Gate Warning Corrective — 0.21.1

User workstation evidence `quality-gate-20261001-015133.txt` confirmed the Step 08A implementation builds and all governed test/coverage/local gates pass, but the Release x64 build emitted one `CA1806` warning from `U1InProcessGeometryConfirmationTests.cs`. The warning is confined to the guard-clause test where the constructor is expected to throw for a null reader.

0.21.1 changes only that test statement so the analyzer can see the constructed value is consumed (`GC.KeepAlive`). No production source or Cimatron behavior is changed. The supplied capture is retained as evidence. A new user workstation quality gate is required because the project standard remains **0 warnings / 0 errors**. Live U1 in-process validation remains blocked until that clean gate is returned.

## 2026-10-01 — 0.21.0 — Phase 02 Step 08A U1 In-Process Confirmation Foundation

- User approved starting Step 08A after Step 07D closure and requested strict documentation/time tracking.
- Scope is intentionally limited to U1 in-process confirmation; no customer CR behavior is implemented.
- Added Application contracts `IBodyGeometryMetricsReader` and `BodyGeometryMetricsSnapshot`.
- Added `CimatronBodyGeometryMetricsReader` in CimatronIntegration. It reuses only the U1 APIs already verified in Step 07 and rejects the wrong document context/model/body.
- Added `U1InProcessGeometryConfirmationFeature` in DesignChecks with the locked `KA-PART-1` B1 baseline: body ID `4`, volume `227576.685834808`, center `[50,30,20]`, surface area `26684.9371823929`.
- Added no-mutation evidence by comparing `ICimDocument.IsModified()`, saved path, file last-write UTC, and file length before/after the read. A changed/unverifiable state becomes an execution Error rather than a business-rule failure.
- Added Plugin composition registration and fake-port tests.
- Under separately approved metadata-only scope, aligned Application, CimatronIntegration, DesignChecks, and Plugin AssemblyVersion/AssemblyFileVersion to `0.21.0.0`.
- User-supplied Step 07D workstation evidence `quality-gate-20261001-013106.txt` records Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, exit code 0. SonarQube remains a separate credentialed server-side gate.
- Step 07D promotion whitelist approval is carried as the gate into Step 08. U2/U11/U14/U17 remain excluded. Step 06 deferred items remain carried forward.
- Agent did not build/test/run Cimatron. 0.21.0 remains `AWAITING USER QUALITY GATE AND LIVE IN-PROCESS VALIDATION`.

## 0.15.33 — Phase 02 Step 05C2-B — Architecture guard evidence-marker correction

User-run 0.15.32 validation produced a clean Release x64 build with 0 warnings and 0 errors, then failed Architecture Tests with exit code 1. Static review traced the failure to `ZoomDiscoveryToolMustRemainReadOnlyAndDevelopmentOnly`: the 0.15.32 reflection diagnostic omitted four required closed-route cast-evidence marker strings. 0.15.33 restores only those markers in `InteropReflectionInventory.cs`; no reflection behavior, runtime API invocation, production `src/`, Assembly Pick, or production Zoom-to-result behavior changes. FR-021 remains open.


## 0.15.32 — Phase 02 Step 05C2-B — Occurrence/component visibility reflection narrowing

### User-validated evidence entering this change
- 0.15.30 full quality gate PASS: Release x64 build succeeded with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage collection/gate and local quality gate PASS; exit code 0.
- 0.15.30 live known-answer diagnostic used ToolVersion 0.15.30, observed 9 occurrences, preserved no-mutation evidence, and retained suppressed `Block_B`.
- Visible `Block_A`, suppressed `Block_B`, and hidden-not-suppressed `Known_Pocket_Body` all produced `IgnoreInShowOperations=0`; occurrence `cmAttVisibility` and `cmAttBlankLevel` were absent for all three comparison cases. Therefore those compatible `IAssInstance` candidates do not discriminate hidden state in this runtime/model.
- `_IAssInstance.get_Show_()` remains closed by the earlier validated explicit-cast failure (`InvalidCastException`, HRESULT `0x80004002 / E_NOINTERFACE`) for every tested occurrence.

### Approved 0.15.32 implementation
- Modified only the development diagnostic `tools/CimatronCustomization.ZoomCommandDiscovery/InteropReflectionInventory.cs` plus version/history/handoff/checksum documentation.
- Added occurrence/component context terms (`AssInstance`, `AssemblyInstance`, `Occurrence`, `Component`, `Instance`) and a dedicated reflection-only section that lists visibility/display members only when they are read-only property getters.
- Reflection metadata records interface assembly/name/GUID/base interfaces and getter signatures. It does not attach to Cimatron, inspect a document, or invoke any newly discovered member.
- Existing ambiguous methods and setters remain excluded from the read-only candidate section. Attribute enum values remain metadata and are not assigned occurrence semantics.
- Production `src/`, Assembly Pick, and production Zoom-to-result remain byte-for-byte unchanged by this step.

### Required workstation validation
1. Run the full quality gate and provide the capture.
2. Only after a clean gate, run `CimatronCustomization.ZoomCommandDiscovery.exe --reflect-visibility-api`.
3. Review the generated reflection evidence. Do not approve or invoke a new runtime getter merely from its name; any runtime probe requires a separate scoped approval and known-answer comparison.
4. CR-11 FR-021 remains OPEN until a supported occurrence-level read-only hidden-state signal is verified.

## 0.15.30 — Step 05C2-B compatible IAssInstance visibility-candidate comparison

### Evidence entering this increment
- User-run 0.15.29 quality gate passed cleanly: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage/local quality gates PASS; exit code 0.
- User-run `--assembly-entities` on the approved known-answer Assembly completed with 9 occurrences, 18 entity inspections, no traversal/entity limits and no-mutation evidence `UNCHANGED`.
- Explicit cast of every runtime occurrence to `interop.CimMdlrAPI._IAssInstance` failed with `System.InvalidCastException` and HRESULT `0x80004002 (E_NOINTERFACE)`, including visible `Block_A`, suppressed `Block_B`, and hidden-not-suppressed `Known_Pocket_Body`. The metadata interface exists, but the runtime occurrence COM objects do not expose it; the `Show_` route is closed for this target/runtime evidence.
- Existing known-answer evidence remains intact: both repeated `Block_A` placements are distinct by full occurrence path, `Block_B` is suppressed, `Known_Pocket_Body` is not suppressed, and the real Mold Pocket body reports `MbPocket=1`.

### Approved 0.15.30 diagnostic
- Use the already-compatible `interop.CimMdlrAPI.IAssInstance` only.
- Read `IgnoreInShowOperations` through its getter only.
- Read occurrence-level `cmAttVisibility` and `cmAttBlankLevel` through `IAssInstance.GetAttribute(..., string.Empty)` and, only when present, `IAttribute.Value`.
- Record raw `PRESENT value=...`, `ABSENT`, or exact `READ_ERROR` exception/HRESULT per candidate and per occurrence. A failure of one candidate remains evidence and does not prevent the remaining read-only candidates from being collected.
- Compare the raw results for visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`; do not assign visibility semantics before workstation evidence.
- Preserve existing traversal, budgets, watchdog, body-attribute checks and before/after no-mutation evidence.
- `_IAssInstance` cast/`Show_` is no longer invoked. All setters and visibility mutation remain prohibited. Production `src/` remains unchanged.

### Validation status
- AI did not run build/tests/Cimatron. User must first run the full quality gate. After it passes, rerun `--assembly-entities` on the same known-answer copy and return console output plus the generated evidence file.

## 0.15.29 — Step 05C2-B architecture assertion correction

### Trigger evidence
- User-run 0.15.28 quality gate: Release x64 build PASS with 0 warnings / 0 errors, then Architecture Tests FAIL and overall exit code 1.
- Direct ArchitectureTests execution reported the Step 05C2-B evidence-contract guard failure. Inspection showed the only stale required token was `HiddenStateDetection: UNRESOLVED`; 0.15.28 intentionally emits `HiddenStateDetection: RUNTIME PROBE PENDING` before the approved live getter validation.

### Approved correction
- Changes only the Architecture Test expectation from `UNRESOLVED` to `RUNTIME PROBE PENDING`.
- No `AssemblyEntityInventory` change and no runtime/API behavior change. Production `src/` remains untouched.

### Validation status
- Awaiting user quality-gate rerun. Live `--assembly-entities` validation must not proceed until that gate passes.

## 0.15.28 — Step 05C2-B getter-only occurrence visibility runtime probe

### Evidence entering this increment
- User-run 0.15.27 quality gate passed cleanly: Release x64 build, required test suites, coverage gate and local quality gate all PASS with 0 warnings / 0 errors.
- User-run `--reflect-visibility-api` exited 0 and found one `_IAssInstance` interface in `interop.CimMdlrAPI.dll`, GUID `4C8A5941-F526-11D5-B89D-006008719C4A`.
- Reflection classified `get_Show_()` as a read-only property getter and `set_Show_()` as a mutating setter. The earlier `as` cast returned null and therefore produced no exception/HRESULT.
- `cmAttVisibility` and `cmAttBlankLevel` remain entity/body-level candidates; occurrence semantics are unproven.

### Approved implementation
- Development-only `AssemblyEntityInventory` now performs an explicit `_IAssInstance` compatibility cast for each occurrence. A failed cast is evidence, not a business-rule failure: exact exception type and HRESULT are recorded in the occurrence row and durable trace.
- Only after successful interface acquisition is `get_Show_()` read. No setter is invoked. The returned integer is deliberately not interpreted in code.
- Known-answer validation must compare visible `Block_A`, hidden-but-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`, plus before/after no-mutation evidence.
- Architecture protection requires the explicit compatibility evidence/getter-only tokens and continues to forbid setter/mutation tokens.
- No production `src/` change and no new Cimatron API name/signature is introduced beyond the reflection-proven getter.

### Validation status
- Awaiting user quality-gate and Cimatron known-answer runtime execution.

## 2026-09-27 — Version 0.15.26 — Phase 02 / Step 05C2-B

- **Step Name:** Hidden Occurrence-State API Reflection Discovery.
- **Change ID:** P02-S05C2B-HIDDEN-STATE-DISCOVERY.
- **Trigger evidence:** User-run 0.15.25 quality gate passed with Release x64 build PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS and exit code 0. The subsequent non-elevated known-answer traversal returned exit code 0 with `OccurrencesObserved=9`, `RevisitCount=0`, no limits reached, no-mutation `UNCHANGED`, both `Block_A` placements emitted as direct root children with distinct paths (`root:-1/8@ordinal-3`, `root:-1/5@ordinal-6`) and known offsets `[-30,0,20]` and `[100,0,20]`, suppressed `Block_B`, and real Mold Pocket `MbPocket(cmAttInteger)=1`.
- **Remaining dependency:** CR-11 FR-021 hidden-but-not-suppressed occurrence detection. The approved copy model's `Known_Pocket_Body` is intended as the hidden component occurrence; this must be distinguished from body/entity visibility.
- **Current cast finding:** `AssemblyEntityInventory.ReadControlledShowState` targets `interop.CimMdlrAPI._IAssInstance` with a C# `as` cast. In user-validated runtime evidence that cast returned null. Because `as` returns null rather than throwing for an incompatible interface, the exact current failure evidence is `ExceptionType=NONE`, `HRESULT=N/A`; this does not prove whether `Show_` is a safe read-only getter.
- **Discovery:** adds `--reflect-visibility-api`, reflection-only against installed `interop.Cim*.dll`. It inventories all `_IAssInstance` interface copies/GUID metadata/base interfaces, searches `Show/Visible/Visibility/Hidden/Hide/Blank/Display/State`, and classifies every matching member as property-get/property-set/accessor/method with a safety label.
- **Attribute candidates:** reflection records `cmAttVisibility` and `cmAttBlankLevel` where present. These remain **body/entity-level candidates only** unless later evidence proves occurrence-level semantics through an approved read-only path.
- **Safety:** no newly discovered member is called; no AppAccess/document attach is performed by this mode; no production `src/` change.
- **Parallel authoritative source:** user will ask Cimatron for the supported read-only API to determine whether an assembly occurrence is hidden but not suppressed.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or execute Cimatron for 0.15.26.

## 2026-09-27 — Version 0.15.25 — Phase 02 / Step 05C2-B

- **Step Name:** Controlled Assembly Traversal — Repeated-Occurrence Identity / Definition-Cycle Correction.
- **Change ID:** P02-S05C2B-OCCURRENCE-IDENTITY.
- **Trigger evidence:** User-created known-answer Assembly `CR11_Smoke_Assembly_Prepared` completed the 0.15.24 diagnostic with exit code 0, no mutation, no traversal/entity limits, a real Mold Pocket body at occurrence `root:-1/11` with `MbPocket(cmAttInteger)=1`, suppressed `Block_B`, and nested transform evidence. The Cimatron tree showed `Block_A(2)`, but evidence emitted only one `Block_A` row while `OccurrencesObserved=9` and `RevisitCount=1`.
- **Design finding:** Positive `InstanceId` cannot be treated as authoritative global placed-occurrence identity. Pre-fix evidence emitted one `Block_A` as a direct child of the root with `InstanceId=8`; the Cimatron tree showed two `Block_A` placements under that same root. The dropped sibling's runtime ID cannot be claimed until the corrected run emits it. CR-11 FR-020 reporting therefore requires occurrence-path identity; this also validates the earlier `PickResult` occurrence-path design direction.
- **Correction:** Full diagnostic occurrence path now includes sibling ordinal (`<id-or-no-id>@ordinal-N`) and is authoritative for each placed occurrence. Global `VisitedIdentity` deduplication is removed.
- **Cycle protection:** A real recursion cycle is guarded only when a `cmAssembly` occurrence's referenced definition `IModel.PID` already exists in its ancestor Assembly-definition chain. This uses an already-approved read-only getter; no new Cimatron API is introduced. If PID is missing, no identity guess is made; existing depth/occurrence limits remain the fail-safe.
- **Cycle validation limitation:** A real recursive self-containing Cimatron Assembly is not available/expected, so the live cycle guard is recorded as **not exercised at runtime**. Architecture tests protect the intended source structure; they do not claim live cycle execution.
- **Validation target:** Same known-answer model must emit both `Block_A` placements with distinct occurrence paths and their known transform offsets, `RevisitCount=0`, suppressed `Block_B`, real `MbPocket=1`, no limit reached, no mutation, and exit code 0.
- **Hidden state:** Remains separately unresolved under CR-11 FR-021 because `_IAssInstance` cast is unavailable in current runtime evidence.
- **Scope:** Diagnostic-only; no production `src/`, Assembly Pick, or production Zoom-to-result change.
- **Files Changed:** `tools/CimatronCustomization.ZoomCommandDiscovery/AssemblyEntityInventory.cs`; diagnostic `Properties/AssemblyInfo.cs`; `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; `docs/history/session-handoffs/phase-02-step-05c2-handoff.md`; regenerated `CHECKSUMS.sha256`.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or execute Cimatron for 0.15.25.

## 2026-09-27 — Version 0.15.24 — Phase 02 / Step 05C2-B

- **Step Name:** Controlled Assembly Traversal — Separate Occurrence/Entity Budgets and Evidence Completeness.
- **Change ID:** P02-S05C2B-SEPARATE-BUDGETS.
- **Trigger evidence:** User-run 0.15.23 quality gate PASS. Subsequent real-mold `--assembly-entities` completed successfully with 80 occurrences and 490 body attribute checks; no-mutation evidence was `UNCHANGED`. Nested sub-assemblies and suppressed occurrences were observed. A body at `root:-1/8/137` exposed `MbCooling(cmAttInteger)=1`, proving that the cooling marker can be read through an Assembly occurrence. The shared 2000-item guard was reached, so complete occurrence traversal was not established.
- **Decision:** Separate the traversal budget from entity inspection. Occurrence recursion has `MaximumOccurrences=2000`; entity-list item inspection has `MaximumEntityInspections=2000`. Entity exhaustion never terminates occurrence recursion.
- **False-negative protection:** Every occurrence has an `EntityInspectionStatus`. Exhausted-budget cases are explicitly marked as not inspected or partially inspected. Those statuses must never be interpreted as absence of `MbPocket` or `MbCooling`.
- **Occurrence-only mode:** `--assembly-entities --occurrence-only` keeps the same read-only occurrence/model/transform/suppression traversal while disabling `GetAllEntities` and attribute inspection.
- **Runtime evidence:** Total elapsed runtime and independent occurrence/entity counters and limit flags are written to evidence and console summary.
- **Acceptance findings:** `MbCooling via occurrence = PROVEN` from user evidence; `MbPocket via occurrence = NOT YET PROVEN`; hidden-state detection = `UNRESOLVED — CR-11 FR-021 dependency` because `_IAssInstance` cast remained unavailable. 05C2-B remains open until the small known-answer copy assembly is checked for repeated component/known transform, one `MbPocket` body, one hidden and one suppressed occurrence, and comparison against the Cimatron tree.
- **Safety:** No new Cimatron API; existing watchdog, depth/revisit/no-mutation controls retained; occurrence-only mode makes no entity/body/attribute calls; no production `src/` changes.
- **Files Changed:** `tools/CimatronCustomization.ZoomCommandDiscovery/AssemblyEntityInventory.cs`; `tools/CimatronCustomization.ZoomCommandDiscovery/Program.cs`; diagnostic `Properties/AssemblyInfo.cs`; `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; `docs/history/session-handoffs/phase-02-step-05c2-handoff.md`; regenerated `CHECKSUMS.sha256`.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or execute Cimatron for 0.15.24.

## 2026-09-26 — Version 0.15.23 — Phase 02 / Step 05C2-B

- **Step Name:** Controlled Assembly Traversal — Root Parent Runtime Correction.
- **Change ID:** P02-S05C2B-ROOT-PARENT-CORRECTION.
- **Trigger evidence:** User-run 0.15.22 local quality gate PASS with 0 warnings / 0 errors, all required tests PASS, coverage/local quality gate PASS, exit code 0. During the first controlled `--assembly-entities` runtime, AppAccess attach, active Assembly/document checks, `IModelContainer.Model`, `IAssemblyModel.GetRootInstance`, and root ID access all returned successfully. The root ID was `-1`. The next call, `IAssInstance.get_AssParentInstance root:-1`, failed with `System.Runtime.InteropServices.COMException`, HRESULT `0x80004005` (`E_FAIL`).
- **Decision:** Treat the Cimatron root as a root pseudo-instance for parent evidence. A root has no parent, so no parent COM call is made for `isRoot`; evidence records `ParentId=ROOT/N/A`. Non-root occurrences still use the approved `get_AssParentInstance` + parent-ID read.
- **Cycle guard:** The existing rule remains unchanged: use stable occurrence ID only when ID > 0; otherwise use the full occurrence path. Therefore root ID `-1` is not used as a global identity.
- **Test protection:** Architecture guard requires the `if (!isRoot)` root-parent guard to occur before the parent-instance call and retains all prior allow-list/checkpoint/mutation prohibitions.
- **Scope:** Diagnostic-only corrective patch. No new Cimatron API, no production `src/` change, no traversal-depth/item/watchdog/no-mutation semantics change, and no production Assembly Pick/Zoom behavior change.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or execute Cimatron for 0.15.23.
- **Next Action:** User runs the full quality gate. If clean, rerun `--assembly-entities` on the copy of the known test Assembly and return console output plus generated evidence/trace.

## 2026-09-26 — Version 0.15.22 — Phase 02 / Step 05C2-B

### Scope
Approved corrective increment after the user-run 0.15.21 quality gate reported two CA1834 warnings and an Architecture Tests failure: `Step 05C2 Assembly entity inventory must retain immediate diagnostic checkpoints around the potentially blocking COM calls.`

### Root cause
- The 0.15.21 runtime traversal already routes approved potentially blocking calls through `RunApiCall`, which writes a `BEGIN API` checkpoint immediately before `call()` and an `END API` checkpoint immediately after a successful return.
- The architecture guard was stale: it still required literal checkpoint text for the removed exploratory `GetInstances`, `Select`, and `GetFaces` path, so it failed even though the new controlled wrapper retained immediate checkpointing.
- `FormatObject` also used `StringBuilder.Append(string)` for single-character constants at two locations, producing CA1834 warnings.

### Change
- Updated the architecture guard to require the approved 05C2-B call labels plus the generic `RunApiCall` BEGIN/call/END checkpoint tokens and their source ordering.
- Changed only the two single-character `StringBuilder.Append` calls from string to char overloads.
- Advanced the diagnostic assembly/product package version to 0.15.22.
- No production `src/`, Cimatron API allow-list, traversal semantics, timeout behavior, or mutation policy changed.

### Validation
**AWAITING USER EXECUTION.** The AI agent did not build, test, or run Cimatron. User must rerun the full quality gate and supply the capture. Target: 0 warnings, 0 errors, Architecture Tests PASS, full local quality gate PASS.

## 2026-09-26 — Version 0.15.21 — Phase 02 / Step 05C2-B

- **Change Type:** DEVELOPMENT DIAGNOSTIC / CONTROLLED RUNTIME EXPERIMENT.
- **Approval:** User explicitly approved the 05C2-B read-only API allow-list and the exact file delta before implementation.
- **Input Evidence:** User-supplied 0.15.20 quality gate passed with 0 warnings / 0 errors and exit code 0. `--reflect-assembly-api` succeeded against the installed Cimatron 2026 interop and produced a base-interface-aware inventory with no live runtime calls.
- **Traversal Boundary:** Diagnostic uses the approved Assembly occurrence surface (`GetRootInstance`, `get_SubInstances`, parent/root/ID/suppressed/show getters, transformation getters, `GetAllEntities`, entity-list getters, read-only body attribute lookup).
- **Removed Diagnostic Path:** Previous exploratory `GetInstances/CreateFilter/SetFilter/Select/GetFaces` path is removed from `AssemblyEntityInventory.cs`.
- **Hang Protection:** Each Cimatron API call is surrounded by a 15-second observer watchdog. The watchdog never calls Cimatron; if the STA call blocks it records the call and terminates only the diagnostic process with exit code 7.
- **Traversal Guards:** Maximum depth 16, maximum total items 2000, revisit/cycle guard uses stable occurrence ID when available and full occurrence path fallback otherwise.
- **Failure Evidence:** API failures record the call, exception type, HRESULT, and message in the durable trace/console.
- **No-Mutation Evidence:** Active document `IsModified`, document path, filesystem last-write timestamp, and file length are captured before and after traversal; mismatch returns exit code 8. Validation must be performed on a copy of the known test Assembly, never a client source file.
- **CR-11 Diagnostic:** Occurrence-reached bodies are cast to `interop.CimBaseAPI.IAttributeSink`; the diagnostic performs read-only `GetAttribute(cmAttInteger, "MbPocket")` and `GetAttribute(cmAttInteger, "MbCooling")` checks. Attribute mutation APIs are prohibited.
- **Architecture Guard:** Requires the approved allow-list/safety tokens and forbids old exploratory traversal APIs, document open/load/activation/save, suppression, setters, attribute Attach/Detach, and transformation mutation calls.
- **Production Scope:** No production `src/`, Assembly Pick, Highlight, or Zoom-to-result behavior change.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or run Cimatron.
- **Next Action:** User runs the local quality gate. If clean, run `--assembly-entities` only against a copy of the known test Assembly with nested sub-assembly, repeated component at known offsets, hidden occurrence, suppressed occurrence, pocket body, and cooling body; compare evidence with the Cimatron tree.

# Implementation History

## 2026-09-26 — Version 0.15.20 — Phase 02 / Step 05C2-A

- **Step Name:** CA1859 Diagnostic Warning Cleanup.
- **Change ID:** P02-S05C2A-CA1859-WARNING-CLEANUP.
- **Change Type:** CORRECTIVE / DIAGNOSTIC / DOCUMENTATION.
- **Trigger evidence:** User-run 0.15.19 quality gate completed with Release x64 build PASS, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local quality gate PASS and exit code 0, but emitted one CA1859 warning at `InteropReflectionInventory.cs(165,48)`.
- **Approved correction:** Change only the helper return type from `IEnumerable<MemberInfo>` to `MemberInfo[]`, matching `Type.GetMembers(...)`. The two existing callers consume the result through LINQ/`foreach`, so behavior is intentionally unchanged.
- **Versioning:** Diagnostic version strings and assembly version advanced from 0.15.19 to 0.15.20; progressive ZIP/version/history artifacts updated accordingly.
- **Production boundary:** No production `src/` file changed. No Cimatron runtime/API call was added or changed. Production Assembly Pick and production Zoom-to-result remain unchanged.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or execute Cimatron.
- **Next Action:** User runs the 0.15.20 quality gate. Proceed to `--reflect-assembly-api` only after a clean 0-warning / 0-error result.

## 2026-09-26 — Version 0.15.19 — Phase 02 / Step 05C2-A

- **Step Name:** Installed-Interop Assembly API Surface Inventory.
- **Change ID:** P02-S05C2A-INSTALLED-INTEROP-ASSEMBLY-SURFACE.
- **Change Type:** API-DISCOVERY / DIAGNOSTIC / TEST / DOCUMENTATION.
- **Requirement / Feature:** Before implementing any further Assembly occurrence/entity traversal, enumerate the exact installed Cimatron 2026 Interop interfaces/members needed to construct a separately approved read-only API allow-list.
- **Reason:** Public SDK descriptions have previously differed from the installed Interop surface. The user approved a two-stage safeguard: 05C2-A inventories the installed surface; 05C2-B may later implement only explicitly approved calls.
- **Prior workstation evidence:** 0.15.18 local quality gate PASS with 0 warnings / 0 errors; Release x64 and required tests PASS; coverage/local quality gate PASS. With non-elevated Cimatron, non-admin Discovery `--attach-only --apartment=MTA` PASSed with exit 0. Running the same diagnostic from Administrator PowerShell failed immediately with the intended elevation-mismatch message and exit 6, confirming the 0.15.18 fail-fast guard.
- **Implementation:** Added `--reflect-assembly-api` to the developer diagnostic. It scans installed `interop.Cim*.dll` files by `Assembly.ReflectionOnlyLoadFrom`, enumerates relevant interface/member candidates, includes inherited interfaces through `GetInterfaces()`, and writes exact member signatures plus declaring-interface evidence.
- **Safety:** This mode performs no live Cimatron runtime call and therefore does not attach to Cimatron, open/load/activate component documents, traverse an assembly, modify selection/view/model state, execute commands, or save data. Member existence is evidence only; it does **not** establish runtime safety or side-effect behavior.
- **Test protection:** Architecture test requires the dedicated switch, reflection-only loading, inherited-interface scan, and explicit no-runtime-call evidence; it rejects live AppAccess/document calls from the reflection source.
- **Files Changed:** `tools/CimatronCustomization.ZoomCommandDiscovery/InteropReflectionInventory.cs`; `tools/CimatronCustomization.ZoomCommandDiscovery/Program.cs`; diagnostic `Properties/AssemblyInfo.cs`; `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`; `docs/platform/CIMATRON-2026-ZOOM-COMMAND-DISCOVERY.md`; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; regenerated `CHECKSUMS.sha256`.
- **Build Result:** AWAITING USER EXECUTION. AI agent did not build or run tests.
- **Runtime Result:** AWAITING USER EXECUTION for `--reflect-assembly-api`; no Cimatron runtime session is required because the mode is reflection-only.
- **Known Limitation:** The inventory proves installed signatures only. For each candidate 05C2-B call, read-only/side-effect status still requires an explicit evidence basis; uncertain calls must be excluded or separately tested.
- **Next Action:** User runs the 0.15.19 quality gate, then runs `--reflect-assembly-api` and returns the generated findings file for construction of the proposed 05C2-B read-only allow-list.

## 2026-09-26 — Version 0.15.18 — Phase 02 / Step 05C2

- **Step Name:** Elevation / Process-Visibility Diagnostic Hardening.
- **Change ID:** P02-S05C2-ELEVATION-PRECONDITION-HARDENING.
- **Workstation evidence:** User-run 0.15.17 local quality gate PASS with 0 warnings / 0 errors; corrected `trace-selftest` named task PASS / exit 0. Elevated PowerShell attach-only runs timed out for both STA and MTA at the parameterless `GetApplication()` boundary with exit 5.
- **Diagnostic defects found in 0.15.17:** process inventory matched `CimatronCustomization.ZoomCommandDiscovery` instead of the real Cimatron host, making its single-instance PASS invalid; direct `GetMethod` reflection missed inherited COM-interface methods.
- **External process evidence:** Task Manager showed `CimatronE.exe` PID 2516, user `GMMSPL`, x64 and `Elevated=No`.
- **Isolation result:** From a normal, non-Administrator PowerShell while the same Cimatron session remained open, `Cr11RuntimeProbe.exe` attached successfully and reported `Active document is cmAssembly`; the same non-elevated shell then ran Discovery `--attach-only --apartment=MTA` and received `ATTACH ONLY: PASS (MTA)` / exit 0. The observed attach timeout is therefore attributed to the elevation mismatch, not to STA/MTA alone or to parameterless `GetApplication()` itself.
- **Implementation:** exact `Process.GetProcessesByName("CimatronE")`; records target PID/session/elevation and same-session evidence; confirmed elevation mismatch fails fast before COM attach with exit code 6 and a direct remediation message. Unknown elevation evidence is recorded but is not falsely treated as a mismatch.
- **Reflection correction:** parameterless `GetApplication()` lookup now searches the AppAccess type and inherited interfaces returned by `GetInterfaces()`.
- **Scope:** development diagnostics only. No production `src/`, Assembly Pick, Highlight, Assembly traversal, or production Zoom-to-result changes.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or execute Cimatron for 0.15.18.

## 2026-09-26 — Version 0.15.17 — Phase 02 / Step 05C2

- **Step Name:** GetApplication Attach-Only STA/MTA Isolation.
- **Change ID:** P02-S05C2-GETAPPLICATION-APARTMENT-DIAGNOSTIC.
- **Reason / latest workstation evidence:** User-run 0.15.16 local quality gate passed with 0 warnings / 0 errors and all required local tests/coverage passed. `--trace-selftest` passed and recorded `ApartmentState: STA`. The subsequent `--assembly-entities` run reached `CHECKPOINT 02` (`AppAccess created; calling GetApplication`) and then stopped progressing; the durable heartbeat continued for more than one minute at `CHECKPOINT 02`. This proves `new AppAccess()` returned and the parameterless `GetApplication()` boundary did not return during the observation window.
- **Known-good comparison supplied by user/reviewer:** an earlier `Cr11RuntimeProbe` on the same machine successfully used parameterless `new AppAccess().GetApplication()` from an MTA/no-`[STAThread]` console probe. That probe source is not included in this package, so its MTA/working status is recorded as user-supplied runtime evidence, not re-derived source evidence.
- **Discovery-tool comparison confirmed from repository:** .NET Framework 4.8, x64, embedded Cimatron manifest, Program-folder output, and parameterless `GetApplication()` already match the known-good description. The intentional diagnostic variable is therefore STA versus MTA worker apartment (plus invocation environment).
- **Implementation:** Added `--attach-only --apartment=STA|MTA`. The attach call executes on a background worker whose apartment is explicitly set before start. The controller waits 30 seconds; on timeout it durably records `ATTACH TIMEOUT` and returns exit code 5 without calling `Thread.Abort` or otherwise force-cancelling unmanaged COM.
- **Evidence recorded:** reflection description of the parameterless `GetApplication()` method, worker apartment, pre/post attach checkpoints, Cimatron process count, Cimatron PID(s), Windows Session ID(s), tool elevation from the existing trace header, and operator-confirmation requirements for no open dialog/no active command/matching elevation.
- **Missed 0.15.16 condition:** `--trace-selftest` existed in the executable but `Invoke-And-Capture.ps1` still restricted `-Task` to `quality-gate,assembly-entities`. 0.15.17 adds the missing `trace-selftest` named task and an architecture guard so this omission is not repeated.
- **Scope:** Developer diagnostic only. No new Assembly traversal calls, no alternative `GetApplication` signatures/arguments, and no production `src/`, Assembly Pick, Highlight, or production Zoom-to-result changes.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, or execute Cimatron.

## 2026-09-26 — Version 0.15.16 — Phase 02 / Step 05C2

- **Step Name:** Durable Diagnostic Startup / Capture Isolation.
- **Change ID:** P02-S05C2-DURABLE-TRACE-ISOLATION.
- **Trigger evidence:** The user-run cumulative 0.15.14/0.15.15 local quality gate passed with 0 warnings / 0 errors and all required test/coverage gates PASS, but the subsequent `assembly-entities` capture contained only the wrapper header before manual stop and no in-process `CHECKPOINT` output.
- **Decision:** Do not guess at a Cimatron COM blocking call. First separate process/managed-entry/dispatch/COM progress with evidence independent of stdout capture.
- **Implementation:** Added `DiagnosticTraceWriter.cs`; per-record append/write-through/`Flush(true)`/close under `%LOCALAPPDATA%\CimatronCustomization\diagnostics\zoom-discovery-<timestamp>-pid<PID>.log`; startup environment header; 3-second background heartbeat; `--trace-selftest`; existing Assembly checkpoints mirrored to file.
- **Apartment state:** `Main` was already `[STAThread]` in the 0.15.15 package. This is preserved byte-for-behavior; 0.15.16 only records the observed apartment state.
- **Architecture guard:** Requires the trace source/project entry/self-test, LocalAppData path, write-through flush, environment fields and heartbeat, and prohibits Cimatron Interop usage from the trace writer.
- **External fallback validation:** If no `Main entered` record exists, inspect Task Manager and Event Viewer → Windows Logs → Application for SideBySide, .NET Runtime, Application Error and Windows Error Reporting entries; also record exact launch command/redirection and elevation state.
- **Production boundary:** No production `src/` file changed. Production Assembly Pick and production Zoom-to-result remain unchanged. No new Cimatron API call was added.
- **Validation:** AWAITING USER EXECUTION. The AI agent did not build, run tests, or execute Cimatron.

## 0.15.27
- Corrects the 0.15.26 development-only visibility reflection diagnostic compile failure (`CS0136`) by renaming the conflicting local variable to `guidValue`.
- No reflection behavior, Cimatron API usage, or production `src/` changes.
- User must rerun the quality gate elevated because the prior non-elevated run also hit Program Files deployment access-denied errors.

## 0.15.15 — Step 05C2 Session Handoff — 2026-09-26

- Created `docs/history/session-handoffs/phase-02-step-05c2-handoff.md` in the AGENTS.md-prescribed handoff location.
- The handoff records the closed 0.15.4 Step 05B2 baseline, Step 05C1 command/reflection discovery, 0.15.9 Part Zoom Selection PASS, Assembly Pick boundary, 0.15.10 Assembly entity diagnostic, 0.15.13 console-capture/quality-gate PASS, the first Assembly diagnostic hang, and the approved 0.15.14 checkpoint instrumentation.
- Records that 0.15.14 remains unvalidated on the user's workstation and that no further implementation should occur before its quality gate and checkpointed Assembly run are reviewed.
- Records the exact commands and files to read first in the next session.
- No production source, diagnostic runtime behavior, or Cimatron behavior changed.

## 2026-09-26 — Version 0.15.14 — Phase 02 / Step 05C2

- **Step Name:** Assembly Entity Diagnostic Checkpoints.
- **Change ID:** P02-S05C2-ASSEMBLY-INVENTORY-CHECKPOINTS.
- **Change Type:** API-DISCOVERY / DIAGNOSTIC / TEST / DOCUMENTATION.
- **Reason:** User-run 0.15.13 `assembly-entities` launched successfully through the console-capture helper but emitted no tool output before it had to be stopped, leaving the blocking Cimatron COM call unknown.
- **Fix:** Added timestamped checkpoints immediately before and after the already-approved read-only COM calls in `AssemblyEntityInventory`. Every checkpoint explicitly flushes `Console.Out` so redirected PowerShell capture receives the last completed step before a hang.
- **Calls bracketed:** standalone AppAccess creation, `GetApplication`, `GetActiveDoc`, document type, `container.Model`, `GetInstances`, `instance.Model`, model type, `CreateFilter`, `SetFilter`, `Select`, body-list access, and `GetFaces`.
- **Test protection:** Architecture test now requires checkpoint markers, `Console.Out.Flush()`, and checkpoints around the main potentially blocking calls while preserving the existing no-command/no-selection/no-PickTool read-only guard.
- **Scope:** Developer diagnostic only. No production `src/` behavior changed. No new Cimatron API was introduced.
- **Prior workstation validation:** 0.15.13 local quality gate PASS with 0 warnings / 0 errors; coverage/local quality gate PASS. Console-capture helper successfully wrote the uploaded quality-gate file.
- **Runtime observation:** 0.15.13 Assembly inventory did not return and emitted no diagnostic lines before manual stop; root cause remains **NOT YET IDENTIFIED**.
- **Validation:** AWAITING USER EXECUTION for 0.15.14 quality gate and live Assembly inventory checkpoint capture.
- **Next Action:** User runs the 0.15.14 local quality gate before the next Cimatron runtime probe.


## 2026-09-26 — Version 0.15.13 — Phase 02 / Step 05C2

- **Step Name:** PowerShell 5.1 Console Capture Compatibility Fix.
- **Change ID:** P02-S05C2-CONSOLE-CAPTURE-PS51.
- **Reason:** Workstation execution of 0.15.12 failed inside `Invoke-And-Capture.ps1` with an ambiguous `Tee-Object` parameter-set binding error before the selected task ran.
- **Fix:** Removed `Tee-Object` from the capture path. Native child stdout/stderr now flows through `ForEach-Object`; each rendered line is written to the console and appended to the timestamped capture file with `Add-Content`. Error-path capture uses the same explicit write/append approach.
- **Preserved behavior:** `-Task quality-gate` and `-Task assembly-entities`, effective-command header, timestamps, capture path, and child-process exit-code propagation.
- **Scope:** Utility/version/history/changelog/checksum only; no production source or Cimatron behavior changes.
- **Validation:** AWAITING USER EXECUTION.

## 2026-09-26 — Version 0.15.12 — Phase 02 / Step 05C2

- **Step Name:** Named-Task Console Capture Utility Fix.
- **Change ID:** P02-S05C2-CONSOLE-CAPTURE-NAMED-TASKS.
- **Reason:** Workstation execution showed that 0.15.11 could not be conveniently invoked under the machine execution-policy restrictions because its mandatory `-Command` scriptblock could not be supplied through `powershell -File`; `-Task` did not yet exist.
- **Fix:** `Invoke-And-Capture.ps1` now accepts only `-Task quality-gate` or `-Task assembly-entities` and internally invokes the fixed approved command for that task.
- **Capture behavior:** stdout/stderr are tee'd to `artifacts/console-captures/` while still displayed, and the effective command, timestamps, exit code and capture path are recorded.
- **Scope:** Utility/documentation/version/checksum only; no production source or Cimatron behavior changes.
- **Validation:** AWAITING USER EXECUTION.

## 2026-09-26 — Version 0.15.9 — Phase 02 / Step 05C2

- **Step Name:** Controlled Native Zoom Selection Validation.
- **Change ID:** P02-S05C2-ZOOM-SELECTION-LIVE-PROBE.
- **Change Type:** API-VALIDATION / DEVELOPER DIAGNOSTIC / ARCHITECTURE GUARD.
- **Requirement / Feature:** CR-11 FR-014 Zoom-to-result prerequisite.
- **Prior workstation evidence:** 0.15.8 Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests PASS; coverage collection/gate and local quality gate PASS.
- **Discovery evidence:** Installed-Interop reflection completed successfully (13 assemblies, 251 name matches). No direct viewport `ZoomToEntity`/`FitEntity` style API was identified. Part and Assembly command-pool inventories each returned 1401 commands and 74 candidates; both contain `&Display,Zoom Selection`.
- **Approved scope:** Controlled development-only proof of the exact native command. No production Zoom wiring.
- **New source:** `tools/CimatronCustomization.ZoomCommandDiscovery/ZoomSelectionValidation.cs`.
- **Changed source:** diagnostic `Program.cs`/project, ArchitectureTests guard, version/history/changelog/Zoom verification documentation/checksums.
- **Cimatron APIs used by the validation mode:** `AppAccess.GetApplication`, `IApplication.GetActiveDoc`, `IModelContainer.Model`, `IModel.GetEntityById`, `ISelection.Selection` get/set, `IApplication.GetPoolCommands`, `IPoolCommands.GetCommand`, `ICimCommand.Execute`.
- **Command restriction:** The diagnostic executes exactly one resolved native command: category `&Display`, command `Zoom Selection`. `ExecutePluginCommand`, PickTool APIs, document mutation and model mutation remain prohibited.
- **Selection safety:** Prior selection is captured before validation and restored in `finally` after command execution/failure.
- **Evidence:** A diagnostic text file records context/model PID/entity id/command and that command execution returned. Visual framing remains a user-observed runtime result and is never inferred by the tool.
- **Known limitation:** This probe accepts an active-model entity id only; nested assembly-occurrence/entity addressing is not introduced or validated here.
- **Validation:** AWAITING USER EXECUTION. The AI agent did not build, run tests, or execute Cimatron.
- **Next Action:** User runs the local quality gate; if clean, run the Part controlled validation with a known active-model entity id and report the visual result before any Assembly execution.


## 2026-09-26 — Version 0.15.8 — Phase 02 / Step 05C1

### Microsoft.CSharp binder dependency correction
- Workstation quality-gate run of 0.15.7 failed at compile time with **0 warnings / 1 error**: `CS0656` for `Microsoft.CSharp.RuntimeBinder.Binder.Convert` in `CommandPoolInventory.cs`.
- Root cause: the new standalone diagnostic project used an interop/dynamic conversion path but did not reference the .NET Framework `Microsoft.CSharp` assembly.
- Added only the required `Microsoft.CSharp` project reference and bumped diagnostic/version traceability to 0.15.8.
- Production projects and Step 05C1 runtime behavior are unchanged.
- Validation remains **AWAITING USER EXECUTION**.

## 2026-09-26 — Version 0.15.7 — Phase 02 / Step 05C1

- **Step Name:** Dedicated read-only Zoom/View discovery tool.
- **Change ID:** P02-S05C1-ZOOM-DISCOVERY-TOOL
- **Change Type:** API-DISCOVERY / DIAGNOSTIC / ARCHITECTURE / DOCUMENTATION.
- **Requirement / Feature:** CR-11 FR-014 Zoom-to-result prerequisite.
- **Reason:** The 0.15.6 `--discover-zoom-commands` path produced no visible shell output on the target workstation. A dedicated standalone tool is required so Interop/view and command-pool evidence can be gathered without coupling diagnostics to the test executable.
- **0.15.6 root-cause evidence:** Repository inspection shows a classic .NET Framework `OutputType=Exe` project with explicit `Program.cs`, no `Microsoft.NET.Test.Sdk` reference and no SDK-style generated-program configuration. Therefore an SDK-generated replacement entry point is not supported by source evidence. Development ZIPs exclude `obj/`, so the exact workstation silent-invocation mechanism is not asserted without the workstation build artifacts.
- **Files Changed:** Added dedicated tool project/source/manifest; added it to the development solution; removed obsolete test discovery/filter files and hook; added architecture enforcement; updated Zoom discovery guide/version/changelog/history/checksums.
- **Standalone runtime boundary:** `AppAccess.GetApplication()`; embedded official Cimatron side-by-side manifest; x64; output in `C:\Program Files\Cimatron\Cimatron\2026.0\Program`; same privilege level as Cimatron required.
- **Approved live API allow-list:** `GetApplication`, `GetActiveDoc`, read-only `ProductName`, `Version`, document `Type`, `GetPoolCommands`, `GetCommandsNames`. No command execution or viewport/model/selection mutation is permitted.
- **Reflection mode:** Reflection-only scan of installed `interop.Cim*.dll` public interface members matching Zoom/Fit/View/Frame/Camera. No Cimatron process is required.
- **Live evidence mode:** Complete `CategoryName,CommandName` dump, separately with Part and Assembly active. Header records tool version, timestamp, Cimatron product/version and active document context.
- **Route decision:** No automatic choice between view API and native command. User approval is required after evidence review.
- **Tests/guards:** Architecture guard enforces diagnostic isolation, x64/manifest/runtime location, approved API tokens, mutation prohibition and removal of the obsolete 0.15.6 hook.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build, run tests, invoke Cimatron, or claim runtime PASS.
- **Next Action:** User runs `tools\Invoke-QualityGate.ps1`; if clean, run `--reflect`, then `--commands --expect Part` and `--commands --expect Assembly`, and return the three evidence files.

## 2026-09-26 — Version 0.15.6 — Phase 02 / Step 05C1

- **Step Name:** Native Zoom Command Discovery — Analyzer Warning Cleanup
- **Change ID:** P02-S05C1-CA1861-TEST-CLEANUP
- **Change Type:** TEST / BUILD
- **Requirement / Feature:** CR-11 FR-014 Zoom-to-result prerequisite
- **Reason:** User-run 0.15.5 Release build passed but emitted two `CA1861` analyzer warnings in the newly added candidate-filter tests.
- **Files Changed:** `ZoomCommandCandidateFilterTests.cs`, VERSION, CHANGELOG, IMPLEMENTATION-HISTORY, CHECKSUMS.
- **Previous Behavior:** Two test methods passed inline constant arrays to `ZoomCommandCandidateFilter.Filter(...)`, producing `CA1861`.
- **New Behavior:** The same test data is held in `static readonly` fixtures and reused.
- **Problem / Root Cause:** Repeated constant array arguments trigger the analyzer's allocation warning even though functional behavior is correct.
- **Fix:** Move only those test arrays to class-level `static readonly` fields.
- **Tests Added/Changed:** Existing candidate-filter tests only; assertions and tested behavior are unchanged.
- **Validation:** User evidence for 0.15.5: build/tests/coverage/local quality gate PASS, **2 warnings / 0 errors**. Version 0.15.6 is **AWAITING USER EXECUTION**.
- **Cimatron Version:** Target 2026.x.
- **Build Result:** AWAITING USER EXECUTION for 0.15.6.
- **Runtime Result:** Native zoom command discovery has not yet been run for 0.15.6.
- **Known Limitations:** This change only removes analyzer warnings; it does not identify or execute a zoom command.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if clean, run the approved `--discover-zoom-commands` diagnostic.

## 2026-09-26 — Version 0.15.5 — Phase 02 / Step 05C1

- **Step Name:** Native Zoom Command Discovery
- **Change ID:** P02-S05C1-ZOOM-COMMAND-DISCOVERY
- **Change Type:** API-DISCOVERY / TEST / DOCUMENTATION
- **Requirement / Feature:** CR-11 FR-014 Zoom-to-result prerequisite
- **Reason:** The public SDK documents PoolCommands but no exact target-workstation zoom/fit command identity has yet been proven.
- **Files Changed:** CimatronIntegration test program/project, new discovery/filter/test sources, zoom discovery documentation, VERSION/CHANGELOG/IMPLEMENTATION-HISTORY/CHECKSUMS.
- **Previous Behavior:** No controlled repository diagnostic existed to inventory exact native Cimatron command names.
- **New Behavior:** Development test executable accepts `--discover-zoom-commands`, lists candidate native command names, and executes nothing.
- **Problem / Root Cause:** Production Zoom-to-result cannot safely be implemented from guessed command names.
- **Fix:** Add a read-only discovery diagnostic around documented `GetPoolCommands()` / `GetCommandsNames()` APIs.
- **Tests Added/Changed:** Pure deterministic candidate-filter tests are included in the normal CimatronIntegration test run.
- **Validation:** AWAITING USER EXECUTION. Agent did not build, run tests, or invoke Cimatron.
- **Cimatron Version:** Target 2026.x.
- **Build Result:** AWAITING USER EXECUTION.
- **Runtime Result:** AWAITING USER EXECUTION.
- **Known Limitations:** Candidate names are not proof of zoom behavior; no candidate may be promoted until controlled live execution is observed.
- **Next Action:** User runs quality gate, then the discovery diagnostic, and returns complete output.

## 2026-09-26 — Step 05B2 Closure — Version 0.15.4

- **Phase / Step:** Phase 02 / Step 05B2 — Production Pick Integration.
- **Closure:** **CLOSED / VERIFIED** by explicit user approval after workstation and live Cimatron validation.
- **Quality Gate:** Release x64 PASS with 0 warnings / 0 errors; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests PASS; coverage collection/gate and local quality gate PASS.
- **Coverage:** Domain 100%; Application 95.75%; DesignChecks 100%; Infrastructure 98.48%; CimatronIntegration 4.57% measured with no Step 05B2 threshold.
- **Live 0.15.4 regression check:** Active Pick left idle on the same Part no longer falsely reports `SOURCE_DOCUMENT_CLOSED`.
- **Live Busy:** Second `Pick Entity (Part)` request while the first is active returns `Busy / PICK_ALREADY_ACTIVE`; the original Pick remains active.
- **Live Esc/repeat:** Esc returns `Cancelled / ESC`; a subsequent Pick starts and normal entity selection completes successfully.
- **Live source close:** Closing the source Part during active Pick returns `Cancelled / SOURCE_DOCUMENT_CLOSED`, restores the Feature Launcher safely and does not crash Cimatron.
- **Document switch:** Previously live-verified controlled `Cancelled / CIMATRON_TOOL_POPPED`; 0.15.4 leaves that path unchanged.
- **Exactly-once evidence:** No duplicate popup after source close was explicitly live-verified on 0.15.3. The final 0.15.4 close retest did not separately report post-dismissal duplicate behavior, but the exactly-once implementation was unchanged.
- **Log evidence limitation:** The 0.15.4 `ViewportPickCompleted` JSONL line was not separately pasted/supplied in chat; no live log PASS is inferred.
- **Deferred:** Assembly/sub-assembly/component occurrence Pick, multi-select, NC Pick and Zoom remain outside Step 05B2.
- **Next Action:** Start a new session from the closure handoff and plan the next remaining viewport-interaction increment only; no new production implementation is approved by this closure.

## 2026-09-26 — Version 0.15.4

- **Phase / Step:** Phase 02 / Step 05B2 — Production Pick Integration.
- **Change Type:** BUGFIX / LIVE REGRESSION.
- **0.15.3 workstation evidence:** Release x64 and all reported local tests/coverage/quality gates PASS with 0 warnings / 0 errors. The first source-document-close live test returned one `Cancelled / SOURCE_DOCUMENT_CLOSED` result and no duplicate popup.
- **Regression symptom:** After that success, subsequent `Pick Entity (Part)` actions could immediately/consistently end with `SOURCE_DOCUMENT_CLOSED` while the source Part was still open.
- **Root cause:** The 0.15.3 lifecycle watchdog treated a `SessionDocumentIdentityRegistry` token as a stable live-document identity. That token is keyed by the managed COM wrapper object. A repeated `GetActiveDoc()` can expose a distinct managed wrapper for the same underlying Cimatron Part, creating a false token mismatch.
- **Fix:** The watchdog now evaluates the already verified Part model PID and document type from `GetActiveDoc()` on the captured STA/UI context. Matching model PID means the source is still current irrespective of managed wrapper identity.
- **Switch preservation:** A different active model is only a mismatch sample; the four consecutive 250 ms confirmation window remains, allowing the already live-verified Cimatron `OnToolPoped` switch completion to win before source-close inference.
- **Unchanged:** Exactly-once `TryComplete`, strong PickTool retention/release, late duplicate suppression, direct close completion, Application Pick contract, Feature Launcher UI, Step 05A Highlight, and deferred scope.
- **Regression tests:** Added stable-model-PID positive coverage, repeated same-source probes that never accumulate lifecycle loss, and different/no-model negative identity coverage.
- **Validation:** AWAITING USER EXECUTION for 0.15.4. AI agent did not run build/tests/coverage/local gate or Cimatron.
- **Next Action:** User runs `tools\Invoke-QualityGate.ps1`, deploys 0.15.4, verifies repeated normal Pick starts stay active/select normally, then repeats source-document-close and document-switch cases.

## 2026-09-26 — Version 0.15.3

- **Phase / Step:** Phase 02 / Step 05B2 — Production Pick Integration.
- **Change Type:** BUGFIX / PICK LIFECYCLE.
- **Symptom:** User live test closed the source Part document while Pick was active; the document closed, but no result popup appeared and no new `ViewportPickCompleted` log entry was produced.
- **Root Cause:** The production adapter relied on PickTool COM callbacks to finish the request. The verified close-document scenario produced no normal completion callback, leaving the strong PickTool/session state active.
- **Fix:** Added a 250 ms STA-marshalled source-document identity watchdog. If the source token remains non-current for four consecutive observations and the normal tool callback has not already completed, the managed PickTool completes directly as `Cancelled` / `SOURCE_DOCUMENT_CLOSED` without attempting `PopTool` on the disappeared source.
- **Exactly-once guard:** `ViewportPickSessionState.TryComplete` accepts only the first completion for the active tool, releases the strong reference, clears lifecycle state, and rejects late duplicate completion. `CimatronViewportPickTool` also remains internally completion-once.
- **Preservation:** The one-second confirmation window is intentionally subordinate to the already live-verified normal active-document-switch `OnToolPoped` path. Normal Pick, Esc, repeat Pick, focus/z-order behavior, no-COM-registration behavior, and Step 05A Highlight are not intentionally changed.
- **API verification:** Official Cimatron SDK documentation confirms `IApplication.GetActiveDoc()` as the supported method for obtaining the current active Cimatron document. No unverified document-list or close-event API was introduced.
- **Tests Added/Changed:** CimatronIntegration state tests now cover exactly-once completion, strong-reference release, persistent source-token loss, and mismatch reset.
- **Validation:** AWAITING USER EXECUTION. AI agent did not execute Visual Studio build/tests/coverage/local quality gate or live Cimatron validation.
- **Next Action:** User runs `tools\Invoke-QualityGate.ps1`, deploys the 0.15.3 Plugin DLL, then repeats the source-document-close live case and verifies one `Cancelled / SOURCE_DOCUMENT_CLOSED` result plus one matching `ViewportPickCompleted` log entry.

## 2026-09-26 — Version 0.15.2 live validation / document-close blocker

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05B2 — Production Pick Integration
- **Change Type:** VALIDATION / HANDOFF ONLY — NO PRODUCTION CODE CHANGE
- **Quality Gate:** User-run warning-corrected package PASS: Release x64, Architecture, Domain, Application, CimatronIntegration, Infrastructure, coverage collection/gate and local quality gate; **0 warnings / 0 errors**.
- **Coverage:** Domain 100%; Application 95.75%; DesignChecks 100%; Infrastructure 98.48%; CimatronIntegration 3.44% measured with no threshold introduced for this step.
- **Live PASS:** normal Part Pick; Esc cancellation; repeat Pick after Esc; active-document switch during Pick.
- **Busy Live:** NOT TESTED THROUGH CURRENT UI because the launcher hides while Pick is active; automated state tests remain the evidence.
- **Current Blocker:** Closing the source document during an active Pick closes the document but does not produce a result/cancellation dialog. Recent JSONL evidence contains no corresponding `ViewportPickCompleted` entry, so normal tool-pop completion must not be assumed.
- **Proposed Correction:** Detect source-document disappearance, complete exactly once as `Cancelled` / `SOURCE_DOCUMENT_CLOSED`, release strong PickTool state, restore UI, and ignore any late duplicate COM completion.
- **Approval Boundary:** Proposed correction is NOT yet approved; do not modify production code until explicit user approval.
- **Handoff:** `docs/history/session-handoffs/phase-02-step-05b2-document-close-defect-session-handoff-0.15.2.md`.

## 2026-09-26 — Version 0.15.2 warning-only correction

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05B2 — Production Pick Integration
- **Change Type:** TEST QUALITY / WARNING-ONLY
- **User Evidence Before Correction:** Release x64 build PASS; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests PASS; coverage collection/gate and local quality gate PASS; 0 errors; 7 warnings.
- **Warnings:** Six `CA1806` and one `CA1861`, all in `tests/CimatronCustomization.Application.Tests/ViewportPickContractTests.cs`.
- **Correction:** Exception-path constructors are now explicitly consumed by the test helper, and the fixed assembly-ready occurrence-path test data is held in a `static readonly` field.
- **Scope:** Test-only correction. No production source, Pick contract, COM/Interop behavior, coverage exclusion, UI behavior, or deferred CR-11 scope changed.
- **Validation:** User re-execution PASS with 0 warnings / 0 errors and all local test/coverage/quality gates PASS.


## 2026-09-26 — Version 0.15.2

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05B2 — Production Pick Integration
- **Change ID:** PH02-ST05B2
- **Change Type:** PLATFORM / CIMATRON INTEGRATION / TEST
- **Approved Scope:** Promote the live-verified 0.15.1 Part Pick spike into an Application-owned production Pick abstraction without enabling Assembly/NC/multi-select/Zoom behavior.
- **Application Contract:** Added non-blocking callback-based `IViewportEntityPicker`; immutable request/result/document-identity models; final outcomes `Picked`, `Cancelled`, `Unsupported`, `Failed`, `Busy`, `StaleResult`.
- **Document Identity:** Each observed document COM object receives a session-scoped token. Token, not path, is authoritative for entity-id reuse. Path/title remain descriptive metadata. A no-longer-current source token yields `StaleResult`.
- **Threading:** PickTool completion is delivered from the Cimatron COM event path on the Cimatron STA/UI thread. Caller cancellation is posted through the synchronization context captured at `BeginPick`; no UI-thread blocking/wait loop is introduced.
- **Selection:** Single entity only. Body/Face/Edge caller filters are translated into the verified Cimatron entity-type filter so disallowed types are normally not selectable. Post-pick type checking is defensive only.
- **Concurrency:** One active Pick only; a second request returns `Busy` and leaves the first request active.
- **Cancellation:** Esc, caller `CancellationToken`, document switch/close detection and normal Cimatron tool pop produce controlled completion/cleanup.
- **COM Boundary:** Production `CimatronViewportPickTool` retains the verified 0.15.1 fixed GUID and implements `Tool`, `IToolEvents`, `IPickToolEvents`, `IFigureEvent`; the assembly remains `ComVisible(false)` and no COM registration is added.
- **Diagnostic Spike Disposition:** Removed `CimatronPartPickSpike`, `CimatronDiagnosticPickTool`, `PartPickSpikeOutcome` and `PartPickSpikeStartResult` from the Release source tree. Historical 0.15.1 package/docs remain the reference.
- **Testing:** Added Application contract tests and CimatronIntegration pure state/token tests. Architecture guards enforce COM visibility, verified PushPickTool use, cancellation/threading/result requirements and removal of the diagnostic spike.
- **Coverage:** No exclusions added. CimatronIntegration tests are included in coverage collection and its package rate is reported informationally; existing governed thresholds remain unchanged.
- **CR-11 Dependencies:** Assembly/occurrence Pick, multi-select, and Zoom-to-result remain explicit deferred dependencies.
- **Validation:** AWAITING USER EXECUTION. No build/test/coverage/live-Cimatron PASS is claimed by the agent.
- **Live Cases Required:** normal Pick; Esc; caller cancellation; Busy; repeated Pick after Esc; no active document; document switch; document close; stale-result rejection; type-filter behavior; launcher/result focus; no crash/freeze; no second Cimatron process; Cimatron exit only if safe (otherwise `NOT TESTED`).


## 2026-09-26 — Version 0.15.1 CLOSED

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05B1 — Part-only Pick Spike
- **Change ID:** PH02-ST05B1-CLOSE
- **Change Type:** CLOSURE / DOCUMENTATION / HANDOFF
- **Scope:** Formal closure only. No production or test code changes are made by this closure package.
- **Final Quality Gate:** User-run Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage collection/gate and local quality gate PASS.
- **Coverage:** Domain 100%; Application 95.41%; DesignChecks 100%; Infrastructure 98.48%.
- **Live Runtime:** Part Pick success PASS; Esc cancellation/tool cleanup PASS; result-dialog reachability PASS; launcher foreground restoration PASS; post-result Cimatron focus return PASS; active-document switch during Pick PASS.
- **Interop Result:** Direct managed-object `IToolContainer.PushPickTool(...)` handoff works without COM registration on the validated Cimatron 2026 environment.
- **Lifecycle Result:** Strongly retained modeless launcher + owned dedicated result dialog + explicit Cimatron focus return is the validated 0.15.1 lifecycle.
- **Session Safety:** Picked entity IDs are current-session only and must never be persisted/reused as durable model references.
- **Accepted Spike Behavior:** Temporary Pick selection may clear when the tool ends. Persistent post-pick highlight is not a 0.15.1 requirement.
- **Deferred:** Production Result Report Pick integration, Application-owned Pick port/result model, Assembly/NC Pick, persistent post-pick highlight, and Zoom.
- **Validation State:** **CLOSED / VERIFIED** from user-supplied evidence.
- **Next Action:** Step 05B2 planning only, using the new handoff document; implementation requires explicit user approval under `AGENTS.md`.


### 0.15.1 Step 05B1 focus-return analyzer warning correction
- **User validation before this correction:** Focus-return live behavior PASS. Full local quality gate PASS for Release x64, Architecture, Domain, Application, Infrastructure, coverage and local gate, with one remaining analyzer warning.
- **Warning:** `CA1806` in `FeatureLauncherWindow.IsCurrentProcessForeground()` because the return value from Win32 `GetWindowThreadProcessId` was ignored.
- **Correction:** Capture the returned foreground thread ID and return `false` if the API returns 0; otherwise compare the returned process ID with the current Cimatron process exactly as before.
- **Architecture protection:** The Step 05B1 source-contract guard now requires the checked `GetWindowThreadProcessId` return-value pattern.
- **Scope:** Warning-only hardening. No PickTool/Interop behavior, COM registration, result-dialog behavior, launcher ownership, persistent selection/highlight, Result Report Pick integration, or customer CR/SA behavior change.
- **Validation:** NOT VERIFIED / AWAITING USER RE-EXECUTION.

### 0.15.1 Step 05B1 result-dialog focus-return correction
- **Live evidence:** User confirmed the launcher-foreground correction works after switching away from Cimatron and back, and active-document switching during Pick behaved as expected. A later sequence `Pick Spike (Part)` -> Esc -> close result dialog caused Cimatron to lose foreground and another application to come to front.
- **Root cause boundary:** The existing callback restored the launcher before showing the owned result dialog, but after `ShowDialog` returned it only called `Activate()` on the launcher. That did not explicitly re-establish the captured Cimatron top-level window as the foreground application.
- **Correction:** After the dedicated Pick result dialog closes, call a narrow `RestoreCimatronAndLauncherFocus()` helper. When a captured Cimatron main-window handle is available it calls Win32 `SetForegroundWindow` for that handle, then reuses `RestoreToFront()` for the modeless owned Feature Launcher.
- **Architecture protection:** Step 05B1 source-contract coverage now requires both the explicit Cimatron `SetForegroundWindow` handoff and the post-result `RestoreCimatronAndLauncherFocus()` call.
- **Scope:** No PickTool/Interop changes, no COM registration, no persistent selection/highlight behavior, no Result Report Pick integration, and no customer CR/SA behavior changes.
- **Validation:** NOT VERIFIED / AWAITING USER RE-EXECUTION for this focus-return correction.

### 0.15.1 Step 05B1 launcher foreground correction
- **Live evidence:** The dedicated Pick result dialog remained reachable and Esc cancellation behaved correctly, but after switching away from Cimatron and back the modeless Feature Launcher itself could remain behind. A control check confirmed that pressing Esc without starting Pick does not create a Pick session.
- **Correction:** The strongly retained modeless Feature Launcher is now shown as an owned window of the current Cimatron process main window. A lightweight WinForms timer observes foreground-process transitions and calls the existing restore/activate path only when Cimatron regains foreground, the launcher is visible/enabled, and no Pick is active.
- **Foreground policy:** The launcher is not made permanently TopMost and does not continuously steal focus while the user works inside Cimatron; activation occurs only on the external-window -> Cimatron-process transition.
- **Architecture protection:** Updated source-contract coverage requires Cimatron ownership, modeless strong retention, the foreground-transition monitor, and the active-Pick/visibility guards.
- **Scope:** No PickTool/Interop signature change, no COM registration, no selection-persistence change, no Result Report Pick integration, and no customer CR/SA behavior change.
- **Previous validation:** Architecture-compliant dedicated result-dialog package quality gate PASS with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate/local quality gate PASS.
- **Validation:** Live external-window -> Cimatron launcher restoration was user-confirmed, and active-document switching during Pick was also user-confirmed. No package-specific local quality-gate transcript was supplied before the subsequent focus-return defect was found.

### 0.15.1 Step 05B1 dedicated result-dialog correction
- **Live evidence:** Pick success completed correctly and Esc cancellation produced the expected `Skipped` result, but after toggling windows the standard owned MessageBox could still fall behind and become difficult to close.
- **Correction:** Added a dedicated nested `PickSpikeResultDialog` inside `FeatureLauncherWindow.cs`, owned by the Feature Launcher, preserving the Plugin top-level source boundary. The dialog is TopMost while open, has its own OK action, and is used only for Step 05B1 completion/cancellation outcomes.
- **Architecture protection:** Updated the Step 05B1 source-contract guard to require the dedicated owned TopMost result dialog.
- **Scope:** No PickTool/Interop signature change, no COM registration, no persistent selection/highlight change, and no customer CR/SA behavior change.
- **Validation:** NOT VERIFIED / AWAITING USER RE-EXECUTION.

## 2026-09-25 — Version 0.15.1

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05B1 — Part-only Pick Spike
- **Change ID:** PH02-ST05B1
- **Change Type:** API-DISCOVERY / FOUNDATION / DIAGNOSTIC / TEST
- **Requirement / Feature:** Verify the Cimatron 2026 interactive PickTool lifecycle before adding final Result Report Pick integration.
- **Reason:** Official documentation and the previous plan left uncertainty around modal UI behavior, exact Tool/ITool signatures, `IToolContainer` vs document methods, COM registration, event lifecycle, cancellation, and session-only entity IDs.
- **API Discovery Evidence:** User ran two reflection inspections against installed `interop.CimBaseAPI.dll` and `interop.CimMdlrAPI.dll` version `2026.201.2064.662`. Exact `ITool`, `IToolEvents`, `IPickToolEvents`, `IFigureEvent`, `IToolContainer`, `Tool`, and `IEntityFilter` signatures are recorded in `docs/platform/CIMATRON-2026-PICK-TOOL-VERIFICATION.md`. Installed `IPartDocument` reflection did not expose `PushPickTool`; the verified installed boundary is `IToolContainer.PushPickTool`.
- **Files Added:** `CimatronDiagnosticPickTool.cs`; `CimatronPartPickSpike.cs`; `PartPickSpikeStartResult.cs`; `PartPickSpikeOutcome.cs`; `docs/platform/CIMATRON-2026-PICK-TOOL-VERIFICATION.md`.
- **Files Modified:** CimatronIntegration project file; Plugin `FeatureLauncherWindow.cs`; Plugin `CimatronCommandExecution.cs`; Architecture `ArchitectureBoundaryTests.cs`; seven production `AssemblyInfo.cs` version files; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; `docs/platform/CR-PLATFORM-GUIDE.md`; regenerated `CHECKSUMS.sha256`.
- **Previous Behavior:** Highlight was live-verified, while Pick and Zoom were Unsupported. The modal launcher/report workflow had no safe verified interactive Pick path.
- **New Behavior:** A dedicated launcher diagnostic action starts an asynchronous Part-only face PickTool, keeps the tool strongly referenced, records bounded event diagnostics, ends after first pick/cancel/pop, and restores the launcher through a completion callback. After live evidence showed that hiding a modal `ShowDialog()` launcher terminates the dialog lifetime, the launcher lifecycle was corrected to a strongly retained modeless `Show()` window so hiding it no longer cancels the PickTool.
- **COM Boundary:** CimatronIntegration remains assembly-level `ComVisible(false)`. Only `CimatronDiagnosticPickTool` opts into `[ComVisible(true)]` with fixed GUID `8C05B1D6-7440-4EF7-A369-9A86B54AE151` and `ClassInterfaceType.None`. No registration/unregistration behavior is added.
- **Lifecycle:** Esc is handled if Cimatron delivers it through `OnKeyboardEvent`; normal Cimatron pop/MMB is allowed; launcher closing requests cancellation; active Part model PID is checked during callbacks and a detected switch cancels the pick. Immediate document-switch detection is not claimed if Cimatron emits no subsequent event.
- **Data Safety:** Picked Cimatron entity IDs are logged/displayed as current-session diagnostic values only and are not persisted as durable identifiers. No model mutation/write API is added.
- **Tests Added/Changed:** Architecture/source-contract protection for the single COM-visible class, fixed GUID, installed Tool interfaces, Part-only scope, `IToolContainer.PushPickTool` boundary, modeless/strongly-retained launcher lifecycle, Cimatron-window ownership, and foreground-transition restore guard.
- **Validation:** User-supplied local quality gate before lifecycle correction: PASS, 0 warnings / 0 errors. After the modeless-launcher correction, the user reran the local quality gate: PASS with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS. Live Part pick succeeded with current-session entity ID 48; Esc cancellation and the dedicated result-dialog path were also verified. The remaining observation is launcher foreground restoration after switching away from Cimatron and back.
- **Result Dialog Correction:** Completion/cancellation uses the dedicated nested `PickSpikeResultDialog`, owned by the Feature Launcher and TopMost only while that result dialog is open. The launcher itself is not permanently TopMost. Architecture source-contract coverage protects this behavior.
- **Selection Semantics:** Cimatron clears the temporary PickTool selection when the diagnostic tool ends; this is accepted for the 0.15.1 spike. Persistent post-pick highlight is deferred to 0.15.2.
- **Cimatron Version:** Target 2026.x; installed Interop evidence and live runtime from Cimatron 2026.0.
- **Build Result:** ARCHITECTURE-COMPLIANT DEDICATED RESULT-DIALOG PACKAGE QUALITY GATE PASS; LAUNCHER-FOREGROUND CORRECTION NOT VERIFIED.
- **Runtime Result:** PARTIAL/POSITIVE — no-registration PickTool push, Part pick completion, Esc cancellation, and dedicated result-dialog reachability verified; launcher foreground restoration after external window switching and active-document-switch validation remain open.
- **Known Limitations:** Part-only; face-only diagnostic filter; no final Application pick port; no Result Report Pick integration; no Assembly/NC Pick; no Zoom; no COM registration; document switching is detected only when another tool callback occurs.
- **Next Action:** User re-runs the local quality gate on the launcher-foreground-corrected package, then live-validates external window toggle -> Cimatron launcher restoration and the remaining active-document-switch case. Direct no-registration PickTool activation, Part pick completion, and Esc cancellation are already verified by live evidence.


## 2026-09-25 — Version 0.15.0

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05A — Viewport Highlight
- **Change ID:** PH02-ST05A
- **Change Type:** PLATFORM CAPABILITY / READ-ONLY VIEWPORT INTERACTION
- **Requirement / Scope:** Introduce the first verified Result Report → active Cimatron viewport interaction without guessing Zoom or Pick APIs.
- **Application Boundary:** Added `IViewportEntityHighlighter` and `ViewportHighlightResult`; normal unsupported conditions are explicit, while unexpected runtime exceptions are not converted into business outcomes.
- **Presentation Projection:** `FeatureFindingView` projects finding entity references as opaque current-session strings so Plugin remains free of a Domain project reference.
- **Cimatron Adapter:** Added `CimatronViewportEntityHighlighter`; resolves active-model entity references, verifies current model PID/session identity, creates an entity list, and assigns it to `ISelection.Selection`.
- **Official API Evidence:** Cimatron documentation states `ISelection.Selection` gets/sets selected entities and shows selected entities highlighted; `ICimEntityList` can be created and populated with entities. Compatibility is Cimatron 2024 or later.
- **UI:** Result Report exposes **Highlight** only where a row carries entity references. **Zoom — Unsupported** and **Pick — Unsupported** remain disabled.
- **Limitation:** Nested assembly-instance entity highlighting is intentionally Unsupported until runtime behavior is verified; no zoom/display-transformation or PickTool integration is implemented.
- **Tests:** Added Application coverage for viewport result contracts and finding-reference projection; added Architecture protection requiring the verified `ISelection.Selection` boundary and forbidding Step 05A PickTool/display-transform implementation.
- **Production Behavior Impact:** Adds read-only viewport selection/highlight interaction; no model mutation/write capability.
- **User Validation:** Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS.
- **Coverage:** Domain 100%; Application 95.41%; DesignChecks 100%; Infrastructure 98.48%.
- **Live Standalone Part:** Result Report Highlight visibly selected/highlighted the corresponding finding geometry in orange in the active Cimatron viewport; no error was shown.
- **Live Mold Assembly Guard:** Highlight on a nested assembly-instance finding returned the intended controlled Unsupported message: nested assembly-instance highlighting is not verified in Step 05A.
- **Deferred Actions:** Zoom and Pick remained disabled/Unsupported exactly as designed.
- **Validation State:** VERIFIED from user-supplied workstation and live Cimatron evidence. Step 05A CLOSED.
- **Next Action:** Plan Step 05B for the remaining viewport interaction scope; implementation still requires explicit approval under `AGENTS.md`.


## 2026-09-25 — Version 0.14.11

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports guarded attribute/color compatibility
- **Change ID:** PH02-ST04-FIX11
- **Change Type:** LIVE-RUNTIME-COMPATIBILITY / READ-ONLY
- **Evidence:** Correlation `bc56bfd20991494288ea499ee9d9ccd1` proved application version 0.14.10 was loaded and the remaining `System.ArgumentException` escaped from `CimatronModelInspectionAdapter.ReadColor()` at its second `IAttributeSink.GetAttributes()` call.
- **Fix:** Centralized all adapter `GetAttributes()` access through `TryGetRawAttributes()`; `ReadAttributes()` and `ReadColor()` now share the same entity-specific `ArgumentException` conversion to controlled `Unsupported`.
- **Color Semantics:** `ReadColor()` prefixes the controlled reason with `Color inspection:`; assembly-instance `Color` handling and the explicit `cmAttColor` loop are unchanged.
- **Error Semantics:** The guarded helper catches only `ArgumentException`; unexpected attribute-read exceptions still propagate.
- **Tests:** Strengthened source-contract coverage so exactly one `GetAttributes()` call remains and it must be inside the guarded helper; broad catches are rejected within that helper.
- **Production Behavior Impact:** Prevents the confirmed second attribute enumeration during color inspection from converting an otherwise unsupported entity into an overall Error.
- **Cimatron API Impact:** No write/model-mutation API added.
- **User Validation:** Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS.
- **Coverage:** Domain 100%; Application 95.31%; DesignChecks 100%; Infrastructure 98.48%.
- **Problematic Part:** Total 5 / Passed 2 / Unsupported 3 / Error 0; Attributes, Color and Bounding Box returned controlled Unsupported results.
- **Representative Mold Assembly:** Total 7 / Passed 6 / Unsupported 1 / Error 0; 130 components.
- **Representative Part Regression:** Total 5 / Passed 2 / Unsupported 3 / Error 0.
- **Runtime Evidence:** Correlation `bfd082fc3d04457bbdd7de9f67c0380c` reported `applicationVersion` 0.14.11 with empty `exceptionType` and `exceptionMessage`.
- **Validation State:** VERIFIED from user-supplied workstation and live Cimatron evidence. Step 04 CLOSED.
- **Next Action:** Step 05 — `viewport-highlight-zoom-picks` (`0.15.0`) planning only; implementation still requires explicit approval under `AGENTS.md`.

## 2026-09-25 — Version 0.14.10

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports entity-attribute compatibility
- **Change ID:** PH02-ST04-FIX10
- **Change Type:** LIVE-RUNTIME-COMPATIBILITY / READ-ONLY
- **Evidence:** 0.14.9 JSONL stack trace proved `interop.CimBaseAPI.IAttributeSink.GetAttributes()` throws `System.ArgumentException` for the failing entity.
- **Fix:** Convert only that `ArgumentException` into `ModelReadResult.Unsupported` with an explicit message.
- **Error Semantics:** Other exception types are not swallowed.
- **Tests:** Added source-contract coverage in ArchitectureTests without requiring a live Cimatron COM session.
- **Production Behavior Impact:** Prevents entity-specific unsupported attribute access from failing the whole inspection probe.
- **Cimatron API Impact:** No write/model-mutation API added.
- **Validation State:** NOT VERIFIED until user workstation quality gate and live failing-Part rerun.

## 2026-09-25 — Version 0.14.9

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — exception-stack diagnostics corrective patch
- **Change ID:** PH02-ST04-FIX09
- **Change Type:** TEST-HARNESS / BUILD-FIX / NO-PRODUCTION-CHANGE
- **Reason:** 0.14.8 failed Release x64 compilation because `RunAll()` called a logger diagnostic test method whose body was not present.
- **Fix:** Added the missing test method and helper only.
- **Production Behavior Impact:** None.
- **Cimatron API Impact:** None.
- **Validation State:** NOT VERIFIED until user workstation quality gate.

## 2026-09-25 — Version 0.14.8

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — exception-stack diagnostic infrastructure
- **Change ID:** PH02-ST04-FIX08
- **Change Type:** LOGGING / DIAGNOSTICS / NO-BEHAVIOR-CHANGE
- **Reason:** Live Part failures remained unlocalizable because JSONL logs persisted only exception type/message, not stack trace or inner exception detail.
- **Change:** Persist `exceptionStackTrace` and full `exceptionDetail` via `Exception.ToString()`.
- **Tests:** Added Infrastructure coverage verifying stack/source-method/detail output.
- **Production Behavior Impact:** None intended; logging enrichment only.
- **Cimatron API Impact:** None.
- **Validation State:** NOT VERIFIED until user workstation quality gate and one failing Part rerun.

## 2026-09-25 — Version 0.14.7

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports pre-topology diagnostics
- **Change ID:** PH02-ST04-FIX07
- **Change Type:** DIAGNOSTICS / READ-ONLY
- **Reason:** The 0.14.6 live Part run still failed with an unlabelled range exception, narrowing the remaining boundary to application/document/type access before model-container handling.
- **Change:** Added exact stage labels to application retrieval, active-document retrieval, and document-type access.
- **Production Behavior Impact:** Diagnostic context only.
- **Cimatron API Impact:** No write/model-mutation API added.
- **Validation State:** NOT VERIFIED until user workstation quality gate and live Part rerun.

## 2026-09-25 — Version 0.14.6

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports Part-entry diagnostics
- **Change ID:** PH02-ST04-FIX06
- **Change Type:** DIAGNOSTICS / READ-ONLY
- **Reason:** The 0.14.5 representative assembly passed, but a live Part still failed with an unlabelled `Value does not fall within the expected range.` exception, proving the failure is outside the previously wrapped topology stages.
- **Change:** Added exact stage context around the remaining Part/model/reference COM boundary.
- **Production Behavior Impact:** Diagnostic context only; no intended inspection-result semantics change.
- **Cimatron API Impact:** No write/model-mutation API added.
- **Validation State:** NOT VERIFIED until user workstation quality gate and live Part rerun.

## 2026-09-25 — Version 0.14.5

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports live-runtime compatibility/diagnostics
- **Change ID:** PH02-ST04-FIX05
- **Change Type:** RUNTIME-COMPATIBILITY / DIAGNOSTICS / READ-ONLY
- **Reason:** Two live Cimatron runs exposed independent runtime boundaries: dynamic `GetInstances()` dispatch failure and a generic topology range exception without stage information.
- **Assembly Fix:** Typed `IAssemblyModel.GetInstances()` call with `object[]` consumption and per-element `IAssInstance` casting.
- **Topology Diagnostic Fix:** Exact stage labels around each read-only topology API boundary.
- **Production Behavior Impact:** Read-only inspection only; no customer business-rule changes.
- **Cimatron API Impact:** No write/model-mutation API added.
- **Validation State:** NOT VERIFIED until user workstation quality gate and both live Cimatron reruns.

## 2026-09-25 — Version 0.14.4

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports live COM compatibility correction
- **Change ID:** PH02-ST04-FIX04
- **Change Type:** RUNTIME INTEROP COMPATIBILITY / READ-ONLY
- **Evidence:** 0.14.3 local quality gate PASS with zero warnings; live Model Inspection Probe returned an Error showing `object[]` could not be implicitly converted to the expected assembly-instance array.
- **Root Location:** Three direct `IAssemblyModel.GetInstances()` assignments in `CimatronModelInspectionAdapter`.
- **Fix:** Invoke `GetInstances()` through the runtime COM surface, treat the returned value as `Array`, and cast each usable element to `IAssInstance`; all three traversal/lookup paths now use the same helper.
- **Production Behavior Impact:** Assembly enumeration compatibility only; no model writes and no business-rule change.
- **Automated Test Note:** The COM marshaling shape is runtime-specific and cannot be faithfully recreated by the existing non-Cimatron quality-gate tests; repeat live validation is mandatory.
- **Next Action:** Run the local quality gate, then rerun Model Inspection Probe on the same representative Assembly.

## 2026-09-25 — Version 0.14.3

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports zero-warning corrective patch
- **Change ID:** PH02-ST04-FIX03
- **Change Type:** ANALYZER / CLEANUP / NO-FEATURE-CHANGE
- **Reason:** User explicitly requested removal/fix of all 36 remaining analyzer warnings after 0.14.2.
- **Warning Classes Addressed:** CA1806, CA1822, CA1825, CA1852, CA1859, CA1861.
- **Production Behavior Impact:** None intended; changes are static/mechanical refactors only.
- **Cimatron API Impact:** None; no COM/API call was added, removed, or changed.
- **Analyzer Suppressions Added:** None.
- **User Validation:** 0.14.2 local quality gate PASS with 36 warnings; 0.14.3 awaits workstation execution.
- **Expected Result:** local quality gate remains PASS with 0 warnings.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if green and warning-free, proceed to live Step 04 Model Inspection Probe validation.

## 2026-09-25 — Version 0.14.2

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports warning-cleanup corrective patch
- **Change ID:** PH02-ST04-FIX02
- **Change Type:** ANALYZER / CLEANUP / NO-BEHAVIOR-CHANGE
- **Reason:** User-supplied 0.14.1 quality-gate evidence was fully green but showed 40 warnings versus the established 35-warning baseline. Inspection identified exactly five Step-04-introduced warnings.
- **Fix:** Replaced one LINQ `FirstOrDefault` on an indexable read-only list with direct count/index access, and narrowed four private/internal collection parameters to the concrete `List<>` types already supplied by their callers.
- **Production Behavior Impact:** None.
- **Cimatron API Impact:** None.
- **Tests/Quality:** No test semantics changed; 0.14.1 DesignChecks coverage was already 100%.
- **User Validation:** 0.14.1 local quality gate PASS; 0.14.2 awaits user execution.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if warning count returns to baseline and gate stays green, proceed to live Step 04 Model Inspection Probe validation.

## 2026-09-25 — Version 0.14.1

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports coverage corrective patch
- **Change ID:** PH02-ST04-FIX01
- **Change Type:** TEST / COVERAGE / WARNING-HYGIENE
- **Reason:** User-supplied 0.14.0 quality-gate evidence showed all builds/test suites passing but `CimatronCustomization.DesignChecks` coverage at 73.15%, below the required 95%. The warning count also increased from the established 35-warning baseline to 40.
- **Root Cause:** `ModelInspectionProbeFeature` introduced several guarded result paths that were not exercised by the initial fake-port tests.
- **Fix:** Expanded `ModelAccessPlatformTests` to execute constructor guards, null-context guard, unavailable assembly, empty assembly/topology, body-only topology, supported bounding-box behavior, unavailable attributes, and supported color output. Corrective tests avoid avoidable new analyzer patterns.
- **Production Code Impact:** None other than version/traceability metadata.
- **Cimatron API Impact:** None.
- **User Validation:** 0.14.0 Release/architecture/test suites PASS; DesignChecks coverage gate FAIL at 73.15%; 0.14.1 awaits user execution.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1` and supplies DesignChecks coverage plus total warning count.

## 2026-09-25 — Version 0.14.0

- **Phase:** 02 — CR Platform Extensions
- **Step:** 04 — Cimatron Model Access Ports
- **Change ID:** PH02-ST04
- **Change Type:** PLATFORM / CIMATRON INTEGRATION / FOUNDATION PROBE
- **Scope:** WP5 plus `FOUNDATION-MODEL-INSPECTION-PROBE`.
- **Previous-Step Validation:** Step 03 / 0.13.2 CLOSED from user evidence: Release x64 and all local suites PASS; Domain 100%, Application 94.76%, Infrastructure 98.45%; coverage/local gate PASS; live launcher, result report and Part-context two-feature checklist PASS.
- **Application Boundary:** Added read-only assembly, attribute, color and topology ports plus Cimatron-independent snapshots and `ModelReadResult<T>`.
- **Integration:** Added `CimatronModelInspectionAdapter`; Cimatron COM remains confined to CimatronIntegration/Plugin outer boundaries.
- **Architecture Change:** CimatronIntegration now explicitly references Domain because approved port signatures use Domain-owned `ModelEntityReference`, `Point3`, and `Direction3`. This is an inward outer-adapter dependency and does not expose Cimatron references inward.
- **U1:** Assembly traversal/model identity/context/id/color/suppression/root-relative placement verified from official Cimatron SDK.
- **U2:** Entity attributes verified through `IAttributeSink`; instance/component attribute access remains controlled `Unsupported`.
- **U3:** Instance color and explicit entity `cmAttColor` verified.
- **U4:** Body/face enumeration and Cimatron 2026 topology interfaces plus surface type/area/normal-at-point verified; bounding-box access remains controlled `Unsupported`.
- **Read-only:** No save, move, recolor, attach/detach attribute or modifying procedure API is called.
- **Probe:** Model Inspection Probe reports assembly/topology summaries and representative attribute/color findings; unsupported sub-capabilities remain explicit instead of guessed.
- **Tests:** Added Application/fake-port contract/orchestration tests. Real Cimatron validation remains mandatory and cannot be replaced by mocks.
- **Performance:** Existing execution logging supplies duration. Live target is to investigate materially slower-than-approximately-15-second customer-size assembly inspection.
- **D5:** Probe is present in this development/foundation package; client-shipping policy remains unresolved and must not be inferred from this package.
- **Agent Validation:** NOT VERIFIED.
- **Next Action:** User runs local quality gate; if green, execute Model Inspection Probe on representative Part/Assembly and provide live evidence.

## 2026-09-25 — Version 0.13.2

- **Phase:** 02 — CR Platform Extensions
- **Step:** 03 — Feature Launcher and Result Report UX corrective patch
- **Change ID:** PH02-ST03-FIX02
- **Change Type:** UX / BUGFIX
- **Reason:** Live Cimatron validation showed that checking `Rule Parameter Probe` did not select its tree node. `Run Feature` uses `TreeView.SelectedNode`, so it responded with `Select a feature first.` despite the checked feature being visibly active.
- **Root Cause:** WinForms `TreeView` checkbox state and node selection are independent. Step 03 wired `BeforeCheck` and `AfterSelect` but did not synchronize a user's checkbox interaction with the current selected node.
- **Fix:** Added `AfterCheck` handling for feature nodes so checkbox interaction also assigns `featureTree.SelectedNode`.
- **Behavior Preserved:** `Run Feature` remains single-current-feature execution; `Run Selected` remains checked-feature checklist execution.
- **Production Scope:** Plugin UI only.
- **Application/Domain Impact:** None.
- **Cimatron API Impact:** None.
- **User Validation:** 0.13.1 local quality gate PASS; live launcher/applicability PASS; checked-vs-selected UX defect reproduced. 0.13.2 awaits user execution.
- **Next Action:** User reruns local quality gate, then validates single-feature execution, checklist execution and result report in live Cimatron.

## 2026-09-25 — Version 0.13.1

- **Phase:** 02 — CR Platform Extensions
- **Step:** 03 — Feature Launcher and Result Report corrective patch
- **Change ID:** PH02-ST03-FIX01
- **Change Type:** ARCHITECTURE TEST / TEST ANALYZER CLEANUP
- **Reason:** User-supplied 0.13.0 quality-gate output showed Release x64 PASS but Architecture tests FAIL because the thin-Plugin source allow-list had not been updated for the two approved Step 03 UI classes.
- **Architecture Change:** No new architecture decision. The test now reflects the already-approved Step 03 Plugin UI composition boundary.
- **Warning Scope:** Only warnings introduced by `FeatureLauncherApplicationTests.cs` in Step 03 are cleaned; existing warning baseline is preserved.
- **Production Code Impact:** None beyond version metadata.
- **Cimatron API Impact:** None.
- **User Validation:** 0.13.0 Release x64 PASS / Architecture FAIL; 0.13.1 awaiting user execution.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if green, continue Step 03 live Cimatron launcher/report validation.

## 2026-09-25 — Version 0.13.0

- **Phase:** 02 — CR Platform Extensions
- **Step:** 03 — Feature Launcher and Result Report
- **Change ID:** PH02-ST03
- **Change Type:** PLATFORM / UI / APPLICATION
- **Scope:** WP2 plus WP7 report window only.
- **Previous-Step Validation:** Step 02 / 0.12.0 CLOSED from user evidence: Release x64 and all test suites PASS; Domain 100%, Application 93.71%, Infrastructure 98.45%; coverage/local gate PASS; live schema-2 Rule Parameter Probe PASS with `ProbeLength = 25 mm`.
- **Previous Behavior:** The registered command immediately ran the foundation features and displayed one fixed message box.
- **New Behavior:** The command opens a launcher that lists registered features by kind/group, shows applicability, supports single or selected checklist execution, and opens a sortable/filterable result report. Startup diagnostics are available from the launcher.
- **Architecture:** UI remains in Plugin. Availability/checklist orchestration and Domain-to-presentation projection live in Application. Plugin does not add a Domain project reference.
- **Cimatron API Impact:** No new API/Interop methods. Existing runtime/session adapters are reused.
- **U10:** No explicit official Cimatron threading rule was found in the reviewed Plugin Command pages. Step 03 therefore keeps all Cimatron interaction and feature execution on the command/UI thread and records U10 as UNVERIFIED rather than guessing.
- **Tests:** Added Application tests for availability, unavailable contexts, shared-correlation sequential checklist execution, invalid selections, and presentation-safe finding projection.
- **User Validation:** AWAITING USER EXECUTION.
- **Next Action:** Run local quality gate, then validate launcher/listing/single/checklist/report behavior in Cimatron 2026.0 SP2P1.

## 2026-09-25 — Version 0.12.0

- **Phase:** 02 — CR Platform Extensions
- **Step:** 02 — Rule Parameter Configuration
- **Change ID:** PH02-ST02
- **Change Type:** PLATFORM / CONFIGURATION / FOUNDATION PROBE
- **Requirement / Feature:** WP4 versioned rule-parameter configuration.
- **Behavior:** Features may declare typed rule-parameter metadata. The execution pipeline resolves a validated per-feature parameter set before execution. Missing/invalid required values produce controlled `Error` reports rather than silent defaults.
- **Configuration:** Schema 2 adds `<features>/<feature>/<parameters>/<parameter>`. Schema 1 migrates in memory to schema 2; logging configuration remains compatible.
- **Color representation:** `#RRGGBB` at the platform/configuration boundary; Cimatron mapping deferred.
- **Foundation proof:** `FOUNDATION-RULE-PARAMETER-PROBE` reads required decimal `ProbeLength` (mm).
- **Cimatron API Impact:** None.
- **Customer Logic:** None. No CR/SA parameter values introduced.
- **Tests:** Added Application parameter/pipeline tests and Infrastructure schema/provider tests.
- **User Validation:** AWAITING USER EXECUTION.
- **Next Action:** User runs local quality gate, then validates readiness + parameter probe in live Cimatron.

## 2026-09-25 — Version 0.11.3

- **Phase:** 02 — CR Platform Extensions
- **Step:** 01 — Feature Contract and Composition coverage-pipeline corrective patch
- **Change ID:** PH02-ST01-FIX03
- **Change Type:** QUALITY TOOLING / COVERAGE / BUGFIX
- **Reason:** User reran 0.11.2 and Domain coverage remained exactly 55.56% despite expanded Domain tests.
- **Investigation Result:** `CimatronCustomization.Domain.Tests` compiles `PlatformResultModelTests.cs` and `Program.Main` invokes `PlatformResultModelTests.RunAll()`. However, `tools\Invoke-Coverage.ps1` collected only Application.Tests and Infrastructure.Tests. Domain.Tests was never passed to `dotnet-coverage`.
- **Root Cause:** Coverage collection omission, not missing Domain test execution.
- **Fix:** Collect `Domain.Tests.exe` into `domain.coverage.xml` and merge it with Application and Infrastructure coverage before running `Test-CoverageGate.ps1`.
- **Production Code Impact:** None.
- **Cimatron API Impact:** None.
- **User Validation:** 0.11.2 Release build and all test suites PASS; Domain coverage stayed 55.56%; 0.11.3 awaits user execution.
- **Expected Validation Signal:** Coverage phase prints a Domain test session and reports `domain.coverage.xml` before merging three coverage files.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1` and supplies the final coverage percentages.

## 2026-09-25 — Version 0.11.2

- **Phase:** 02 — CR Platform Extensions
- **Step:** 01 — Feature Contract and Composition coverage corrective patch
- **Change ID:** PH02-ST01-FIX02
- **Change Type:** TEST / COVERAGE / BUGFIX
- **Reason:** User-supplied 0.11.1 quality-gate evidence showed all builds/tests passing but Domain coverage at 55.56%, below the 90% gate.
- **Production Code Impact:** None.
- **Test Change:** Expanded `PlatformResultModelTests.cs` to cover the new Step 01 Domain model comprehensively, including validation guards, value accessors, collection behavior, empty/error paths, and canonical aggregation severity.
- **Cimatron API Impact:** None.
- **User Validation:** 0.11.1 build/test suites PASS; Domain coverage gate FAIL at 55.56%. 0.11.2 awaiting user execution.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`.

## 2026-09-25 — Version 0.11.1

- **Phase:** 02 — CR Platform Extensions
- **Step:** 01 — Feature Contract and Composition corrective patch
- **Step Name:** feature-contract-and-composition
- **Change ID:** PH02-ST01-FIX01
- **Change Type:** BUGFIX / BUILD / ARCHITECTURE-PRESERVING
- **Requirement / Feature:** Restore the approved Step 01 Release x64 build without weakening the Plugin boundary.
- **Reason:** User-supplied 0.11.0 Release x64 output reported `CS0012` at `CimatronCommandExecution.cs` because Plugin accessed `FeatureExecutionReport.Status`, whose canonical `ResultStatus` type is owned by Domain, while architecture tests intentionally forbid Plugin → Domain.
- **Files Changed:** `FeatureExecutionReport.cs`; `CimatronCommandExecution.cs`; focused Application test; assembly/version metadata; `VERSION.md`, `CHANGELOG.md`, this history, and `CHECKSUMS.sha256`.
- **Previous Behavior:** Plugin directly formatted `report.Status`, causing the compiler to require a forbidden direct Domain reference.
- **New Behavior:** Application exposes `StatusText`; Plugin formats that Application-owned string and remains free of a Domain project reference.
- **Problem / Root Cause:** A Domain-owned enum leaked through the Application report into the outer Plugin presentation path. The architecture rule was correct; the presentation boundary was incomplete.
- **Fix:** Add a presentation-safe `StatusText` projection in Application rather than adding `Plugin → Domain`.
- **Cimatron API Impact:** None.
- **Tests Added/Changed:** Added a focused assertion that a `Passed` report exposes `StatusText == "Passed"`; existing architecture tests continue to forbid Plugin → Domain.
- **User Validation:** 0.11.0 Release x64 FAIL with `CS0012`; 0.11.1 AWAITING USER EXECUTION.
- **Cimatron Version:** Target/validated baseline 2026.0 SP2P1.
- **Build Result:** AWAITING USER EXECUTION for 0.11.1.
- **Runtime Result:** AWAITING USER EXECUTION.
- **Known Limitations:** Existing analyzer-warning cleanup remains outside scope. No customer CR/SA logic or new Cimatron API usage.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if green, continue with the approved live Cimatron Step 01 validation.

## 2026-09-25 — Version 0.11.0

- **Phase:** 02 — CR Platform Extensions
- **Step:** 01 — Feature Contract and Composition
- **Step Name:** feature-contract-and-composition
- **Change ID:** PH02-ST01
- **Change Type:** PLATFORM / ARCHITECTURE / TEST
- **Requirement / Feature:** WP1 + WP3 + WP6 + WP9, approved D6 Option B, and Phase 01 Step 10 documentation closeout.
- **Reason:** Establish the shared execution/result/composition contract required before customer CR business rules are introduced.
- **Files Changed:** `AGENTS.md`; Domain/Application/Plugin source and project files required by WP1/WP3/WP6/WP9; Domain/Application/Architecture tests and their project files; all assembly version metadata; `VERSION.md`, `CHANGELOG.md`, this history, `CHECKSUMS.sha256`; added `docs/platform/CR-PLATFORM-GUIDE.md`.
- **Previous Behavior:** Feature status was free text, the execution contract had no context/findings, feature metadata lacked traceability/applicability fields, and Plugin built the registry directly inside `OnCommand`.
- **New Behavior:** Canonical enum statuses, Automation-only `Succeeded`, execution context/findings, metadata/applicability enforcement, requirement-aware logging, and dedicated explicit Plugin composition.
- **Problem / Root Cause:** The Phase 01 generic executor proved registry-backed execution but did not yet provide the richer contracts required by production CR/SA features.
- **Fix:** Added the approved platform contracts and moved explicit registry construction into the dedicated Plugin composition class without adding customer business logic or new Cimatron API calls.
- **Cimatron API Impact:** None. No new COM/Interop surface is used in this step.
- **Tests Added/Changed:** Domain platform-result/value-object tests; Application execution/metadata/applicability/status tests; architecture dependency-graph updates.
- **Previous-Step Validation:** 0.10.0 PASS based on user-supplied Release x64, test, coverage, local-gate and live Cimatron evidence recorded in the Step 10 → Phase 02 handoff.
- **Validation:** AWAITING USER EXECUTION for 0.11.0.
- **Cimatron Version:** Target/validated baseline 2026.0 SP2P1.
- **Build Result:** AWAITING USER EXECUTION.
- **Runtime Result:** AWAITING USER EXECUTION.
- **Known Limitations:** No customer CR/SA logic; rule-parameter config, launcher/report UI, model-read ports, viewport interaction and tabular input remain later platform steps. Existing analyzer-warning cleanup remains outside scope.
- **Next Action:** User runs `tools\Invoke-QualityGate.ps1`, then validates the command in real Cimatron and supplies evidence.

## 2026-09-17 — Version 0.8.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 08 — Registry Framework
- **Step Name:** registry-framework
- **Change ID:** PH01-ST08
- **Change Type:** IMPLEMENTATION / TEST / ARCHITECTURE
- **Requirement / Feature:** Establish a scalable explicit registry so future validations and automations can be added without large switch statements or reflection-based discovery.
- **Reason:** The first end-to-end vertical slice was validated successfully. Before scaling toward many CRs/SAs, the Application layer needs a stable metadata/execution contract and registry that can host both Validation and Automation feature categories.
- **Files Changed:** Added Application feature-registry contracts/classes and the Active Part readiness registry wrapper; updated Application project compile items, Plugin command composition/wiring, Application test project/runner, added registry tests, advanced assembly/version metadata, and updated changelog/history/checksums.
- **Previous Behavior:** Plugin directly instantiated and executed `CheckActivePartReadiness`.
- **New Behavior:** Plugin composition root creates an `ActivePartReadinessFeature`, registers it in `FeatureRegistry`, resolves its metadata by stable feature id, executes it through the common registry contract, and displays the structured result.
- **Problem / Root Cause:** Planned scalability foundation; not a production defect.
- **Fix:** N/A.
- **Tests Added/Changed:** Added Application registry tests for normal execution, case-insensitive lookup, deterministic metadata order, duplicate-id rejection, null/invalid registrations, unknown/blank lookup, metadata validation, feature-outcome validation, and the registry-backed foundation readiness feature.
- **Validation:** AWAITING USER EXECUTION for 0.8.0.
- **Cimatron Version:** 2026.0 SP2P1 based on user-supplied runtime evidence.
- **Build Result:** Previous 0.7.0 Release x64 PASS; 0.8.0 AWAITING USER EXECUTION.
- **Runtime Result:** Previous 0.7.0 in-process Active Part readiness PASS; 0.8.0 AWAITING USER EXECUTION.
- **Known Limitations:** Registry population is explicit at the composition root; no reflection, dynamic assembly scanning, DI framework, production CR/SA registrations, or customer configuration are included. Existing analyzer warnings from earlier approved scope remain outside this step. SonarQube remains a separate server-side gate.
- **Next Action:** User runs `tools\Invoke-QualityGate.ps1`; if it passes, user opens an active Part in Cimatron and executes the registered command once to confirm the registry-backed readiness result is `Passed`.

## 2026-09-17 — Version 0.5.5

- **Phase:** 01 — Engineering Foundation
- **Step:** 05 — Cimatron Session Boundary corrective patch
- **Step Name:** cimatron-session-boundary
- **Change ID:** PH01-ST05-FIX05
- **Change Type:** BUGFIX / API-DISCOVERY / TEST
- **Requirement / Feature:** Validate the production in-process Cimatron session boundary through the actual Plugin DLL path.
- **Reason:** The optional external diagnostic EXE cannot use `CimAppAccess.GetApplication()` on the workstation because the corresponding COM class is not registered. The production Plugin is already loaded in-process and uses the Class-project `CimApplicationProvider` path.
- **Files Changed:** `CimatronCommandExecution.cs`, Plugin project references, `ArchitectureBoundaryTests.cs`, plus approved version/changelog/history/checksum metadata.
- **Previous Behavior:** Plugin command displayed only the baseline success message; mandatory Step 05 runtime validation depended on an external diagnostic path unavailable on the workstation.
- **New Behavior:** Plugin command composes `CimatronSessionAdapter`, reads the current in-process session snapshot, and displays application/document/context facts. Plugin → CimatronIntegration is explicitly permitted as a composition-root dependency.
- **Problem / Root Cause:** External diagnostic COM-registration availability does not prove or represent the production in-process Plugin session path.
- **Fix:** Move mandatory runtime validation to the production Plugin path without changing the Application session contract or CimatronIntegration adapter.
- **Tests Added/Changed:** ArchitectureTests updated for the approved composition-root dependency. Existing Application tests/coverage remain unchanged.
- **Validation:** AWAITING USER EXECUTION for 0.5.5.
- **Cimatron Version:** 2026.0 SP2P1 based on prior user-supplied validation.
- **Build Result:** 0.5.4 local quality gate PASS based on user evidence; 0.5.5 AWAITING USER EXECUTION.
- **Runtime Result:** 0.5.4 optional EXE path FAIL (`REGDB_E_CLASSNOTREG`); 0.5.5 in-process Plugin runtime AWAITING USER EXECUTION.
- **Known Limitations:** Standalone `CimAppAccess` diagnostic remains optional and is not a mandatory production validation path on this workstation. Existing Plugin `CA1852` warning remains outside this corrective scope.
- **Next Action:** User runs the local quality gate, starts Cimatron with an active Part, and executes the registered command once.

## 2026-09-17 — Version 0.5.4

- **Phase:** 01 — Engineering Foundation
- **Step:** 05 — Cimatron Session Boundary corrective patch
- **Step Name:** cimatron-session-boundary
- **Change ID:** PH01-ST05-FIX04
- **Change Type:** BUGFIX / BUILD
- **Requirement / Feature:** Restore compilation of the approved optional Cimatron diagnostic EXE without changing production session behavior.
- **Reason:** User-supplied Release x64 output reported `CS0656` for `Microsoft.CSharp.RuntimeBinder.Binder.Convert` in the diagnostic `Program.cs`.
- **Files Changed:** Diagnostic EXE project file plus approved version/changelog/history/checksum metadata.
- **Previous Behavior:** The diagnostic used dynamic COM/Interop conversion without referencing the .NET Framework `Microsoft.CSharp` runtime-binder assembly.
- **New Behavior:** The diagnostic project explicitly references `Microsoft.CSharp`; diagnostic source and production adapter behavior are unchanged.
- **Problem / Root Cause:** Missing framework reference required by C# dynamic binding in the diagnostic EXE.
- **Fix:** Added `<Reference Include="Microsoft.CSharp" />` only to `CimatronCustomization.CimatronIntegrationTests.csproj`.
- **Tests Added/Changed:** None; existing quality gate and live diagnostic remain the regression validation.
- **Validation:** AWAITING USER EXECUTION for 0.5.4.
- **Cimatron Version:** 2026.0 target.
- **Build Result:** 0.5.3 FAIL with `CS0656`; 0.5.4 AWAITING USER EXECUTION.
- **Runtime Result:** AWAITING USER EXECUTION.
- **Known Limitations:** Existing `CA1852` Plugin warning remains outside this patch. SonarQube remains a separate server-side gate.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if it passes, run the diagnostic EXE with Cimatron open and an active Part.

## 2026-09-17 — Version 0.5.3

- **Phase:** 01 — Engineering Foundation
- **Step:** 05 — Cimatron Session Boundary corrective patch
- **Step Name:** cimatron-session-boundary
- **Change ID:** PH01-ST05-FIX03
- **Change Type:** BUGFIX / API-DISCOVERY / TEST
- **Requirement / Feature:** Use the Cimatron-supported application-access mechanism appropriate to the external diagnostic EXE without altering the production Class-project session adapter.
- **Reason:** User-supplied live diagnostic output returned `REGDB_E_CLASSNOTREG` while an EXE invoked the Class-project `CimApplicationProvider` path. Official Cimatron documentation distinguishes EXE access (`CimAppAccess.AppAccess`) from Class-project access (`CimApplicationProvider`).
- **Files Changed:** Integration diagnostic `Program.cs` and `.csproj`, plus version/changelog/history/checksum metadata.
- **Previous Behavior:** The diagnostic EXE instantiated `CimatronSessionAdapter`, causing the Class-project provider path to be executed outside its intended project/runtime context.
- **New Behavior:** The diagnostic EXE connects through `AppAccess.GetApplication()`; the production adapter remains unchanged.
- **Problem / Root Cause:** Project-type-specific Cimatron application access was not separated in the diagnostic harness.
- **Fix:** Use the documented EXE-project AppAccess path in the diagnostic and remove its project dependency on CimatronIntegration.
- **Tests Added/Changed:** Diagnostic harness changed; existing Application and Architecture tests remain unchanged.
- **Validation:** AWAITING USER EXECUTION for 0.5.3.
- **Cimatron Version:** 2026.0 target.
- **Build Result:** 0.5.2 local quality gate PASS; 0.5.3 AWAITING USER EXECUTION.
- **Runtime Result:** 0.5.2 external diagnostic FAIL with `REGDB_E_CLASSNOTREG`; 0.5.3 AWAITING USER EXECUTION.
- **Known Limitations:** Production Class-project session access still requires in-process Cimatron runtime validation before Step 05 is closed. SonarQube remains separate.
- **Next Action:** User reruns `Invoke-QualityGate.ps1`, then runs the diagnostic EXE with Cimatron open and an active Part.

## 2026-09-17 — Version 0.5.2

- **Phase:** 01 — Engineering Foundation
- **Step:** 05 — Cimatron Session Boundary corrective patch
- **Step Name:** cimatron-session-boundary
- **Change ID:** PH01-ST05-FIX02
- **Change Type:** BUGFIX / BUILD
- **Requirement / Feature:** Restore compilation of the approved Cimatron session adapter without changing its behavior.
- **Reason:** User-supplied Release x64 output reported `CS0656` for `Microsoft.CSharp.RuntimeBinder.Binder.Convert` after the Cimatron Interop references were successfully resolved.
- **Files Changed:** `src/CimatronCustomization.CimatronIntegration/CimatronCustomization.CimatronIntegration.csproj` plus approved version/changelog/history/checksum metadata.
- **Previous Behavior:** The project used `dynamic` Interop conversion without referencing the .NET Framework `Microsoft.CSharp` runtime-binder assembly.
- **New Behavior:** CimatronIntegration explicitly references `Microsoft.CSharp`; adapter source is unchanged.
- **Problem / Root Cause:** Missing framework reference required by C# dynamic binding.
- **Fix:** Added `<Reference Include="Microsoft.CSharp" />` only.
- **Tests Added/Changed:** None; existing local quality gate and live session diagnostic remain the regression validation.
- **Validation:** AWAITING USER EXECUTION for 0.5.2.
- **Cimatron Version:** 2026.0 target.
- **Build Result:** 0.5.1 FAIL with `CS0656`; 0.5.2 AWAITING USER EXECUTION.
- **Runtime Result:** AWAITING USER EXECUTION.
- **Known Limitations:** Existing `CA1852` Plugin warning remains outside this patch. SonarQube remains a separate server-side gate.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if it passes, run the live Cimatron session diagnostic.

## 2026-09-17 — Version 0.5.1

- **Phase:** 01 — Engineering Foundation
- **Step:** 05 — Cimatron Session Boundary corrective patch
- **Step Name:** cimatron-session-boundary
- **Change ID:** PH01-ST05-FIX01
- **Change Type:** BUGFIX / BUILD
- **Requirement / Feature:** Restore build-time resolution of the approved Cimatron 2026 Interop dependencies for the session adapter.
- **Reason:** User-supplied Release x64 output showed MSB3245 for `interop.CimatronE` and `interop.CimServicesAPI`, followed by `CS0246` namespace errors in `CimatronSessionAdapter.cs`.
- **Files Changed:** `src/CimatronCustomization.CimatronIntegration/CimatronCustomization.CimatronIntegration.csproj` plus approved version/changelog/history/checksum metadata.
- **Previous Behavior:** CimatronIntegration used project-relative Interop HintPaths, so MSBuild searched beside the project and could not locate the Cimatron assemblies.
- **New Behavior:** The project defines configurable `CimatronProgramDir` with the verified Cimatron 2026 Program directory as its default, and both Interop references resolve through that property.
- **Problem / Root Cause:** Incorrect project-relative HintPaths for externally installed Cimatron Interop assemblies.
- **Fix:** Route both HintPaths through `$(CimatronProgramDir)`; no session adapter source behavior changed.
- **Tests Added/Changed:** None; existing local quality gate and live session diagnostic are the regression validation.
- **Validation:** AWAITING USER EXECUTION for 0.5.1.
- **Cimatron Version:** 2026.0 target installation path used by the validated plugin baseline.
- **Build Result:** 0.5.0 FAIL from unresolved Interop references; 0.5.1 AWAITING USER EXECUTION.
- **Runtime Result:** AWAITING USER EXECUTION.
- **Known Limitations:** Default path assumes the standard Cimatron 2026.0 Program location; `CimatronProgramDir` may be overridden by MSBuild when required. Existing `CA1852` plugin warning remains outside this patch.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1`; if it passes, start Cimatron with an active Part and run the session diagnostic.

## 2026-09-17 — Version 0.5.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 05 — Cimatron Session Boundary
- **Step Name:** cimatron-session-boundary
- **Change ID:** PH01-ST05
- **Change Type:** IMPLEMENTATION / API-DISCOVERY / TEST
- **Requirement / Feature:** Establish an inward-facing session/context port and an outer Cimatron adapter before feature work begins.
- **Reason:** Future CR/SA use cases require a controlled way to determine whether Cimatron is available and whether an active supported document context exists without leaking COM/Interop into Application or Domain.
- **Files Changed:** Added Application session port/model files, CimatronIntegration adapter, Application tests, live integration diagnostic, quality-test runner; updated solution/project references, coverage orchestration, version metadata, changelog, history, and checksums.
- **Previous Behavior:** No reusable Cimatron session/context boundary existed.
- **New Behavior:** Application consumes `ICimatronSession`; CimatronIntegration implements it using `CimApplicationProvider`, `IApplication.GetActiveDoc()`, and the active document `Type`. Part, Assembly, and NC are recognized; other active document types are reported as Unsupported.
- **Problem / Root Cause:** Planned architecture foundation; not a defect fix.
- **Fix:** N/A.
- **Tests Added/Changed:** Added focused Application snapshot tests; local quality gate now runs Application tests and collects Application coverage. Added a user-run CimatronIntegration diagnostic for real-environment validation.
- **Validation:** AWAITING USER EXECUTION.
- **Cimatron Version:** 2026.x target; exact runtime behavior must be validated by the user.
- **Build Result:** AWAITING USER EXECUTION.
- **Runtime Result:** AWAITING USER EXECUTION.
- **Known Limitations:** `cmPart`, `cmAssembly`, and `cmNc` are the only document-type names recognized in this step. Other types, including any NC-part-specific type, remain `Unsupported` until separately verified. SonarQube remains a separate server-side gate.
- **Next Action:** User runs Release x64/local quality gate, then runs the live session diagnostic with Cimatron open and reports output.

## 2026-09-17 — Version 0.4.1

- **Phase:** 01 — Engineering Foundation
- **Step:** 04 — Quality Infrastructure corrective patch
- **Step Name:** quality-infrastructure
- **Change ID:** PH01-ST04-FIX01
- **Change Type:** BUGFIX / TEST
- **Requirement / Feature:** Correct foundation coverage gating without changing production behavior.
- **Reason:** User-supplied quality-gate output showed `CimatronCustomization.Domain` reported as substantive source even though only generated `obj` C# files and `Properties/AssemblyInfo.cs` existed.
- **Files Changed:** `tools/Test-CoverageGate.ps1` plus approved version/changelog/history/checksum metadata.
- **Previous Behavior:** Recursive source detection included generated `bin`/`obj` C# files, causing a false coverage failure when a governed foundation project had no substantive production source.
- **New Behavior:** Generated `bin`/`obj` C# files and `Properties/AssemblyInfo.cs` are ignored for substantive-source detection.
- **Problem / Root Cause:** Coverage-gate source discovery did not exclude generated build directories.
- **Fix:** Added explicit `bin`/`obj` path exclusions while retaining the AssemblyInfo exclusion.
- **Tests Added/Changed:** No production tests changed; the existing quality-gate workflow is rerun by the user as regression validation.
- **Validation:** AWAITING USER EXECUTION for 0.4.1.
- **Cimatron Version:** 2026.0 SP2P1 based on prior user-supplied validation.
- **Build Result:** 0.4.0 Release x64 PASS based on user evidence; 0.4.1 AWAITING USER EXECUTION.
- **Runtime Result:** No production behavior change.
- **Known Limitations:** SonarQube still requires configured server/project/token. Existing `CA1852` warning is recorded but intentionally outside this corrective scope.
- **Next Action:** User reruns `tools\Invoke-QualityGate.ps1` and supplies the full output.

## 2026-09-17 — Version 0.4.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 04 — Quality Infrastructure
- **Step Name:** quality-infrastructure
- **Change ID:** PH01-ST04
- **Change Type:** BUILD / TEST / CONFIGURATION
- **Requirement / Feature:** Establish the mandatory C#/.NET quality tooling baseline before business features are introduced.
- **Reason:** Enforce consistent analyzer behavior, repeatable Release builds, architecture validation, coverage collection/gating, and SonarQube-ready analysis.
- **Files Changed:** Added root quality configuration, development dependency inventory, local tool manifest, coverage settings, quality scripts and testing documentation; assembly version metadata advanced to 0.4.0.0.
- **Previous Behavior:** Architecture boundaries were enforced, but analyzer/coverage/SonarQube orchestration was not yet established.
- **New Behavior:** The repository contains pinned quality dependencies and repeatable user-run scripts for Release build, architecture tests, coverage, coverage thresholds and SonarQube submission.
- **Problem / Root Cause:** Planned engineering-foundation work; not a defect fix.
- **Fix:** N/A.
- **Tests Added/Changed:** No production unit logic added. Existing ArchitectureTests remain unchanged; quality scripts orchestrate their Release execution.
- **Validation:** AWAITING USER EXECUTION for 0.4.0.
- **Cimatron Version:** 2026.0 SP2P1 based on prior user-supplied validation.
- **Build Result:** AWAITING USER EXECUTION for 0.4.0. Previous 0.3.1 ArchitectureTests PASS based on user evidence.
- **Runtime Result:** No production behavior change intended; Cimatron regression must be rechecked after user build.
- **Known Limitations:** No substantive Domain/Application/DesignChecks/Infrastructure production logic exists yet, so governed coverage may correctly report NOT APPLICABLE during this foundation step. SonarQube requires approved server access/credentials and cannot be claimed PASS until user evidence is supplied.
- **Next Action:** User runs `tools\Invoke-QualityGate.ps1`, reports output, then runs SonarQube analysis when server details are available.

## 2026-09-17 — Version 0.3.1

- **Phase:** 01 — Engineering Foundation
- **Step:** 03 — Architecture Enforcement corrective patch
- **Step Name:** architecture-enforcement
- **Change ID:** PH01-ST03-FIX01
- **Change Type:** BUGFIX / BUILD
- **Requirement / Feature:** Restore compilation of the ArchitectureTests project without changing production behavior or architecture rules.
- **Reason:** User-supplied Release build feedback reported that `XmlReader` is defined in `System.Xml`, which the ArchitectureTests project did not reference.
- **Files Changed:** ArchitectureTests project file plus approved version/changelog/history/checksum metadata.
- **Previous Behavior:** ArchitectureTests failed to compile because `System.Xml.Linq` usage required the base `System.Xml` framework assembly reference.
- **New Behavior:** ArchitectureTests project explicitly references `System.Xml` and is prepared for rebuild.
- **Problem / Root Cause:** Missing `<Reference Include="System.Xml" />` in `CimatronCustomization.ArchitectureTests.csproj`.
- **Fix:** Added only the missing .NET Framework assembly reference.
- **Tests Added/Changed:** None; existing architecture-test logic is unchanged.
- **Validation:** PASS based on user-supplied Release x64 ArchitectureTests output.
- **Cimatron Version:** 2026.0 SP2P1 (based on prior user-supplied runtime evidence).
- **Build Result:** PASS for the 0.3.1 ArchitectureTests Release executable based on user evidence.
- **Runtime Result:** ArchitectureTests returned `ARCHITECTURE TESTS: PASS`; production Cimatron behavior remained previously validated.
- **Known Limitations:** Assembly version attributes remained from the approved 0.3.0 Step 03 baseline; this patch was limited to the missing-reference corrective scope.
- **Next Action:** Completed; superseded by Step 04.

## 2026-09-17 — Version 0.3.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 03 — Architecture Enforcement
- **Step Name:** architecture-enforcement
- **Change ID:** PH01-ST03
- **Change Type:** TEST
- **Requirement / Feature:** Enforce the approved pragmatic Clean/Hexagonal dependency boundaries before feature implementation expands.
- **Reason:** Prevent architectural drift as the solution grows toward many CR and SA features.
- **Files Changed:** Added ArchitectureTests project; solution updated to include it; version/changelog/history/checksum metadata updated; assembly version metadata advanced to 0.3.0.0.
- **Previous Behavior:** Seven-project Hexagonal skeleton existed but dependency rules were not automatically checked.
- **New Behavior:** An executable architecture-test harness fails with a non-zero exit code when approved project-reference or Cimatron-boundary rules are violated.
- **Problem / Root Cause:** Architecture boundaries were documented but not mechanically enforced.
- **Fix:** Added repository-aware project/reference architecture tests without adding third-party dependencies.
- **Tests Added/Changed:** Project-reference direction, Domain isolation, DesignChecks read-only boundary, direct Cimatron dependency boundary, thin Plugin boundary.
- **Validation:** AWAITING USER EXECUTION for 0.3.0.
- **Cimatron Version:** 2026.0 SP2P1 (based on prior user-supplied runtime evidence).
- **Build Result:** AWAITING USER EXECUTION for 0.3.0. Previous 0.2.0 Release x64 build PASS (7 succeeded, 0 failed, 0 skipped) based on user evidence.
- **Runtime Result:** No production behavior change intended. Previous 0.2.0 Cimatron command regression PASS based on user evidence.
- **Known Limitations:** Test harness enforces project/reference and source-boundary structure; semantic read-only behavior of future DesignChecks will require additional tests as implementations are added.
- **Next Action:** User rebuilds Release x64, runs the ArchitectureTests executable, and reports the results.

## 2026-09-17 — Version 0.2.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 02 — Hexagonal Solution Skeleton
- **Step Name:** hexagonal-solution-skeleton
- **Change ID:** PH01-ST02
- **Change Type:** IMPLEMENTATION
- **Requirement / Feature:** Establish pragmatic Clean/Hexagonal project boundaries around the validated official Cimatron plugin template.
- **Reason:** Provide a scalable foundation for many future CR and SA features without placing business logic in the Cimatron plugin boundary.
- **Files Changed:** New solution and six new class-library projects; Plugin csproj gains Application project reference; Plugin AssemblyInfo version metadata updated.
- **Previous Behavior:** Validated standalone official-template-compatible Plugin baseline.
- **New Behavior:** Same Plugin source behavior within a seven-project Hexagonal solution skeleton.
- **Problem / Root Cause:** N/A — planned architecture foundation.
- **Fix:** N/A.
- **Tests Added/Changed:** None in this structural step.
- **Validation:** PASS based on user-supplied build and Cimatron runtime evidence.
- **Cimatron Version:** 2026.0 SP2P1.
- **Build Result:** PASS — Release x64 rebuild: 7 succeeded, 0 failed, 0 skipped.
- **Runtime Result:** PASS — registered command executed the same expected baseline success message.
- **Known Limitations:** No CR/SA logic, session abstraction, registry, DI, logging/config implementation, or quality-tool expansion in this step.
- **Next Action:** Completed; superseded by Step 03.

## 2026-09-17 — Version 0.6.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 06 — Thin Plugin Shell / Application Orchestration
- **Step Name:** thin-plugin-application-orchestration
- **Change ID:** PH01-ST06
- **Change Type:** IMPLEMENTATION / TEST
- **Requirement / Feature:** Keep the official-template-compatible Plugin thin by moving session workflow orchestration into the Application layer.
- **Reason:** The Plugin must remain the Cimatron command/UI shell and composition root while Application owns use-case orchestration.
- **Files Changed:** Added `ReadCurrentCimatronSession.cs` and its focused tests; updated Application/Application.Tests project compile lists and test runner; changed `CimatronCommandExecution.cs` to call the Application use case; advanced assembly/version metadata; updated changelog/history/checksums.
- **Previous Behavior:** The Plugin command directly invoked `ICimatronSession.GetCurrentSession()` on `CimatronSessionAdapter` and then rendered the returned snapshot.
- **New Behavior:** The Plugin composes `CimatronSessionAdapter` with `ReadCurrentCimatronSession`; the Application use case owns session-reading orchestration and returns the same snapshot for UI presentation.
- **Problem / Root Cause:** Planned architecture refinement; not a runtime defect.
- **Fix:** N/A.
- **Tests Added/Changed:** Added use-case delegation and null-dependency tests; existing snapshot, architecture, coverage, build, and real Cimatron regression checks remain applicable.
- **Validation:** AWAITING USER EXECUTION for 0.6.0.
- **Cimatron Version:** 2026.0 SP2P1 based on user-supplied Step 05 runtime evidence.
- **Build Result:** 0.5.5 PASS; 0.6.0 AWAITING USER EXECUTION.
- **Runtime Result:** 0.5.5 in-process session boundary PASS; 0.6.0 AWAITING USER EXECUTION.
- **Known Limitations:** Existing CA1852/CA1859 analyzer warnings remain outside this approved step. SonarQube remains a separate server-side gate. No CR/SA logic or registry exists yet.
- **Next Action:** User runs the local quality gate, then executes the registered command inside Cimatron with an active Part and reports the result.


## 2026-09-17 — Version 0.6.1

- **Phase:** 01 — Engineering Foundation
- **Step:** 06 — Thin Plugin Shell / Application Orchestration corrective patch
- **Step Name:** thin-plugin-application-orchestration
- **Change ID:** PH01-ST06-FIX01
- **Change Type:** BUGFIX / TEST
- **Requirement / Feature:** Restore Step 06 test compilation without changing production orchestration behavior.
- **Reason:** User-supplied Release x64 feedback reported `CS1729` in `ReadCurrentCimatronSessionTests` and a test-only `CA1806` analyzer warning.
- **Files Changed:** `ReadCurrentCimatronSessionTests.cs`; assembly version metadata; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; regenerated `CHECKSUMS.sha256`.
- **Previous Behavior:** The new Application test attempted to construct `CimatronSessionSnapshot` through a non-existent four-argument constructor, blocking the Release build.
- **New Behavior:** The test uses the approved `ActiveDocument(...)` factory and the null-dependency constructor invocation is assigned to a local variable.
- **Problem / Root Cause:** Test code did not match the existing immutable snapshot factory API.
- **Fix:** Corrected test construction only; no production source behavior changed.
- **Tests Added/Changed:** Existing `ReadCurrentCimatronSessionTests` corrected; no new production behavior introduced.
- **Validation:** AWAITING USER EXECUTION for 0.6.1.
- **Cimatron Version:** 2026.0 SP2P1 based on user-supplied Step 05 runtime evidence.
- **Build Result:** 0.6.0 FAIL due to test compilation; 0.6.1 AWAITING USER EXECUTION.
- **Runtime Result:** No production behavior change; prior 0.5.5 in-process session validation PASS.
- **Known Limitations:** Existing Plugin `CA1852` remains outside this corrective scope. SonarQube remains a separate server-side gate.
- **Next Action:** User reruns the local quality gate and then performs the in-process Cimatron command regression.

## 2026-09-17 — Version 0.7.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 07 — First Representative Vertical Slice
- **Step Name:** first-representative-vertical-slice
- **Change ID:** PH01-ST07
- **Change Type:** IMPLEMENTATION / TEST
- **Requirement / Feature:** Prove one complete read-only Hexagonal vertical slice before arbitrary-complexity production CR/SA implementation begins.
- **Reason:** The foundation layers had been validated individually, but one small end-to-end business-style flow was needed to prove Plugin → Application → Cimatron session port/adapter → Domain rule → structured result → Plugin/UI without introducing geometry or modifying Cimatron data.
- **Files Changed:** Added Domain result/status/readiness rule; added Application readiness use case/outcome; added Domain test project and tests; expanded Application tests; updated Plugin command presentation; updated solution, Domain/Application/Application.Tests project files, local quality-gate script, assembly/version/changelog/history/checksum metadata.
- **Previous Behavior:** Plugin executed the Application session-reading use case and displayed raw Cimatron session facts.
- **New Behavior:** Plugin executes `CheckActivePartReadiness`; Application reads the current session, invokes the pure Domain readiness validation, maps the Domain result to an outer-boundary outcome, and the Plugin displays the structured readiness status/message.
- **Problem / Root Cause:** Planned foundation validation; not a production defect.
- **Fix:** N/A.
- **Tests Added/Changed:** Added dedicated Domain tests for Error/NotApplicable/Unsupported/Passed readiness results and invalid result message; added Application orchestration tests for all readiness paths and dependency/outcome validation; local quality gate now runs Domain tests as well as Application/Architecture tests.
- **Validation:** AWAITING USER EXECUTION for 0.7.0.
- **Cimatron Version:** 2026.0 SP2P1 based on prior user-supplied validation.
- **Build Result:** Previous 0.6.1 Release x64 PASS; 0.7.0 AWAITING USER EXECUTION.
- **Runtime Result:** Previous 0.6.1 in-process Cimatron regression PASS; 0.7.0 AWAITING USER EXECUTION.
- **Known Limitations:** Synthetic foundation slice only; not a customer CR/SA feature. No geometry, selection, modifying automation, registry, DI framework, logging/configuration implementation, or SonarQube server-side validation is included. Existing Plugin CA1852 warning remains outside this scope.
- **Next Action:** User runs `tools\Invoke-QualityGate.ps1`; if it passes, user opens an active Part in Cimatron and executes the registered command once to confirm `Passed` readiness output.

## 2026-09-17 — Version 0.9.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 09 — Logging / Configuration / Startup Diagnostics
- **Change ID:** PH01-ST09
- **Change Type:** FOUNDATION / OPERABILITY
- **Scope:** Add production operational foundations without adding customer CR/SA behavior.
- **Architecture:** Application owns startup orchestration and ports; Infrastructure owns XML configuration and rolling JSON-lines logging; CimatronIntegration owns Cimatron runtime/version access; Plugin remains the thin composition root.
- **Configuration:** Schema version 1; missing, malformed, unsupported, or invalid configuration fails explicitly.
- **Logging:** Bounded file size/retention and required structured operational fields; no CAD geometry/client-sensitive payloads.
- **Cimatron API:** `IApplication.ProductName` and `IApplication.Version` are used for runtime diagnostics, together with active-document context.
- **Tests:** Added Application startup-diagnostics tests and a new Infrastructure test executable for configuration/logging behavior.
- **Quality:** Local quality gate extended with Infrastructure tests; coverage collection merges Application and Infrastructure runs; Infrastructure minimum remains 80%.
- **Validation:** AWAITING USER EXECUTION. The AI agent did not execute Visual Studio build/tests/Cimatron runtime validation.
- **Excluded:** No CR/SA logic, customer tolerances/rules, geometry/selection work, modifying automation, DI framework, reflection discovery, or unrelated warning cleanup.

## 2026-09-17 — Version 0.9.1

- **Phase:** 01 — Engineering Foundation
- **Step:** 09 — Logging / Configuration / Startup Diagnostics corrective patch
- **Step Name:** logging-configuration-startup-diagnostics
- **Change ID:** PH01-ST09-FIX01
- **Change Type:** BUGFIX / TEST
- **Symptom:** User-supplied Release x64 build for 0.9.0 failed with 22 C# compiler errors in `RollingJsonFileLogger.cs`.
- **Environment:** Cimatron customization repository on the user workstation; Release x64 quality-gate build.
- **Root Cause:** Generated JSON serialization/escaping code contained malformed C# string literals; the focused logger test contained the same quoting defect.
- **Fix:** Corrected JSON property/string escaping literals in `RollingJsonFileLogger`; corrected the logger test literals and added a regression assertion for quote/backslash/newline escaping.
- **Files Changed:** `RollingJsonFileLogger.cs`; `RollingJsonFileLoggerTests.cs`; assembly version metadata; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; regenerated `CHECKSUMS.sha256`.
- **Scope Control:** No Step 09 behavior expansion and no unrelated analyzer-warning cleanup.
- **Validation:** AWAITING USER EXECUTION for 0.9.1.
- **Build Result:** 0.9.0 FAIL due to logger compile syntax; 0.9.1 AWAITING USER EXECUTION.
- **Next Action:** User reruns `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-QualityGate.ps1`; after it passes, perform the in-process Cimatron Step 09 runtime regression.

## 2026-09-17 — Version 0.9.2

- **Phase:** 01 — Engineering Foundation
- **Step:** 09 — Logging / Configuration / Startup Diagnostics corrective patch
- **Change ID:** PH01-ST09-FIX02
- **Change Type:** BUGFIX / BUILD DEPENDENCY
- **Symptom:** User-supplied 0.9.1 Release x64 build failed with `CS0012` in `XmlStartupConfigurationProvider.cs`: `XmlReader` is defined in unreferenced assembly `System.Xml`.
- **Root Cause:** Infrastructure referenced `System.Xml.Linq` but omitted the required .NET Framework `System.Xml` assembly reference.
- **Fix:** Added `<Reference Include="System.Xml" />` to `CimatronCustomization.Infrastructure.csproj`.
- **Scope Control:** No production behavior expansion and no unrelated analyzer-warning cleanup.
- **Validation:** AWAITING USER EXECUTION for 0.9.2.
- **Next Action:** User reruns `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-QualityGate.ps1`.

## 2026-09-17 — Version 0.9.3

- **Phase:** 01 — Engineering Foundation
- **Step:** 09 — Logging / Configuration / Startup Diagnostics corrective patch
- **Change ID:** PH01-ST09-FIX03
- **Change Type:** BUGFIX / TEST COMPILATION
- **Symptom:** User-supplied 0.9.2 Release x64 build failed with 16 `CS1003` syntax errors in `StartupConfigurationTests.cs`.
- **Root Cause:** XML test payloads embedded double quotes without C# escaping.
- **Fix:** Escaped the XML attribute quotes in the two affected Infrastructure configuration tests. A consolidated review of Step 09 source/test string literals found no additional malformed literals in the inspected Step 09 files.
- **Scope Control:** No production behavior expansion and no unrelated analyzer-warning cleanup.
- **Validation:** AWAITING USER EXECUTION for 0.9.3.
- **Next Action:** User reruns `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-QualityGate.ps1`.
## 2026-09-17 — Version 0.9.4

- **Phase / Step:** Phase 01 / Step 09 — Logging / Configuration / Startup Diagnostics.
- **Type:** Corrective PATCH.
- **Trigger:** User quality-gate evidence showed Infrastructure test failure because rapid rolling generated a duplicate destination filename.
- **Change:** Rolled filenames now use the millisecond timestamp plus a deterministic numeric suffix when a path already exists.
- **Regression:** Rapid repeated rolling is exercised before bounded-retention verification.
- **Scope guard:** No unrelated warnings, architecture, or feature behavior changed.
- **Validation:** AWAITING USER EXECUTION for 0.9.4.


## 2026-09-17 — Version 0.10.0

- **Phase:** 01 — Engineering Foundation
- **Step:** 10 — Generic Validation / Automation Execution Framework + Result/Reporting Polish
- **Change ID:** PH01-ST10
- **Change Type:** FOUNDATION / EXECUTION FRAMEWORK / TEST
- **Requirement / Feature:** Provide one common Application-owned execution/reporting path for registry-backed Validation and Automation features before production CR/SA work begins.
- **Reason:** Step 08 established explicit feature registration and Step 09 established operational logging/startup diagnostics, but Plugin still executed and logged the representative readiness feature directly. A common executor is required so future features do not duplicate execution/error/timing/logging behavior.
- **Files Added:** `src/CimatronCustomization.Application/ExecuteRegisteredFeature.cs`; `src/CimatronCustomization.Application/FeatureExecutionReport.cs`; `tests/CimatronCustomization.Application.Tests/ExecuteRegisteredFeatureTests.cs`.
- **Files Modified:** Application project file; `FeatureRegistry.cs`; Plugin `CimatronCommandExecution.cs`; Application test project/program; assembly version metadata; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; regenerated `CHECKSUMS.sha256`.
- **Architecture:** Application owns common feature execution/reporting; Plugin remains the thin composition root; registry remains explicit with no reflection or DI framework.
- **Execution Semantics:** Normal feature outcomes are preserved. Unknown feature ids and unexpected feature execution exceptions are converted to standardized `Error` reports with exception context and Error-level structured logs. Logging failures are not swallowed by the executor and remain operational failures for the Plugin top-level boundary.
- **Reporting:** Reports include feature id, name, nullable kind (unknown ids are not assigned a misleading category), status, message, elapsed duration, and optional exception context.
- **Logging:** Existing Step 09 correlation id, application version, Cimatron version, duration, status, and exception context flow through the common executor.
- **Tests Added/Changed:** Focused Application tests cover success, Failed, Warning, Error, unknown feature, exception-to-Error behavior, duration/report metadata, correlation/log metadata, and Validation/Automation categories.
- **Previous Validation:** User-supplied 0.9.4 evidence: Release x64 PASS; Architecture/Domain/Application/Infrastructure tests PASS; Domain 95.24%, Application 100%, Infrastructure 100%; coverage gate PASS; local quality gate PASS; live Cimatron startup diagnostics PASS; structured runtime log PASS.
- **Validation:** AWAITING USER EXECUTION for 0.10.0. AI agent did not execute build/tests/Cimatron validation.
- **Known Limitations:** No production CR/SA feature, geometry/selection work, modifying automation, customer rule configuration, DI/reflection framework, SonarQube server-side validation, or unrelated analyzer-warning cleanup in this step.
- **Next Action:** User runs `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-QualityGate.ps1`; after it passes, execute the registered command in Cimatron and verify the existing readiness result and structured feature log entry.

## 2026-09-27 — Version 0.15.31

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05C2-B — Hidden occurrence-state validation
- **Change Type:** DOCUMENTATION / SESSION HANDOFF CHECKPOINT
- **Scope:** Preserve current Step 05C2-B state for continuation in a new chat without changing code or runtime behavior.
- **Recorded Evidence:** 0.15.29 user-run quality gate PASS; live known-answer traversal clean/no-mutation; `_IAssInstance` explicit cast rejected by all tested occurrences with `InvalidCastException` / `0x80004002 (E_NOINTERFACE)`; FR-021 remains open.
- **Current Pending Validation:** 0.15.30 compatible `IAssInstance` candidate comparison (`IgnoreInShowOperations`, `cmAttVisibility`, `cmAttBlankLevel`) has been packaged but no accepted 0.15.30 quality-gate/live evidence has yet been supplied.
- **Files Changed:** `docs/history/session-handoffs/phase-02-step-05c2-handoff.md`; `VERSION.md`; `CHANGELOG.md`; `IMPLEMENTATION-HISTORY.md`; regenerated `CHECKSUMS.sha256`.
- **Production Impact:** None. Production `src/`, tests, binaries, Assembly Pick, and production Zoom-to-result are unchanged.
- **Next Action:** In the new session, read `AGENTS.md` and the handoff, then obtain the user-run 0.15.30 quality-gate capture before any live candidate-comparison conclusions.


## 2026-09-27 — Version 0.15.35

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05C2-B — Hidden occurrence-state validation
- **Change Type:** DEVELOPMENT-DIAGNOSTIC ANALYZER WARNING CORRECTION
- **User Evidence:** 0.15.34 quality gate completed with Release x64 build PASS; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0; three CA1859 warnings in `OccurrenceComInterfaceInventory.cs`.
- **Correction:** Change only the three flagged concrete collection properties from interface types to their concrete `List<T>` / `Dictionary<TKey,TValue>` types.
- **Behavioral Impact:** None. COM `QueryInterface` probing method, immediate release discipline, type-info collection, reflection-only member classification, expected identical-interface outcome, and stopping rule remain unchanged.
- **Production Impact:** None. Production `src/`, Assembly Pick, and production Zoom-to-result remain unchanged.
- **Next Action:** User reruns the full quality gate. Only after 0 warnings / 0 errors and a clean gate should `--probe-occurrence-interfaces` be executed.

## 2026-09-28 — Version 0.17.1

- **Phase:** 02 — CR Platform Extensions
- **Step:** 06B — Reader Technology & Infrastructure corrective patch
- **Change ID:** PH02-ST06B-FIX01
- **Change Type:** BUGFIX / BUILD REFERENCE / ANALYZER CLEANUP
- **User Evidence:** 0.17.0 quality gate restored packages successfully but Release x64 build failed in `CimatronCustomization.Infrastructure`; 25 compiler errors cascaded from missing `System.Data`, and CA1859 flagged `ResolveColumns` using an interface type for a concrete `string[]` input.
- **Root Cause:** ExcelDataReader's `IExcelDataReader` inherits .NET `IDataReader` / `IDataRecord`; classic .NET Framework project compilation therefore requires an explicit `System.Data` reference.
- **Fix:** Added `<Reference Include="System.Data" />` to Infrastructure. Changed only the private `ResolveColumns` header parameter to `string[]` and its `Count` usage to `Length`.
- **Scope Control:** ExcelDataReader 3.9.0 and System.ValueTuple 4.5.0 remain pinned. No CR-04/CR-22 business logic, Cimatron API behavior, supported-format policy, safety limit, or Application contract changes.
- **Validation:** AWAITING USER EXECUTION for 0.17.1.
- **Next Action:** User reruns `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate`.


## 2026-09-28 — Version 0.18.1

- **Phase:** 02 — CR Platform Extensions
- **Step:** 06C2 — Mapping & Validation Engine
- **Change ID:** PH02-ST06C2
- **Change Type:** APPLICATION CAPABILITY / VALIDATION / TEST
- **Previous Validation:** User-supplied 0.18.0 evidence showed Release x64 build PASS; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; Application coverage 95.89%; Infrastructure coverage 91.02%; coverage gate PASS; local quality gate PASS; exit code 0.
- **Scope:** Implement pure Application-layer mapping policy over the approved 06C1 contracts; do not alter ExcelDataReader or Cimatron behavior.
- **Header Resolution:** `TabularMappingEngine.ResolveHeaders` matches configured source-header candidates case-insensitively and emits resolved `TabularColumnDefinition` values for the existing reader contract.
- **Fail-Closed Schema Validation:** Required logical fields with no matching configured header fail; more than one matching alias fails; duplicate physical occurrences of a configured header fail as ambiguous. Missing optional headers are permitted.
- **Mapped Row Validation:** `ValidateRows` verifies required logical values and the approved `Text` / `Decimal` value type metadata while preserving source-row identity for valid consumer-neutral rows.
- **Errors:** Stable codes distinguish required-header missing, ambiguous header, required-value missing, and value-type mismatch. Messages expose logical field names and row numbers where needed but never cell values.
- **Architecture:** Application remains independent of Infrastructure/Cimatron. Reader file access remains in Infrastructure. Step 06D will orchestrate actual reader integration.
- **Tests:** Added focused Application tests covering primary/alias resolution, case-insensitive matching, optional missing headers, required missing headers, multiple aliases, duplicate physical headers, required row values, type mismatches, value non-disclosure, and valid row preservation.
- **Excluded:** CR-04 steel-grade comparison; CR-22 finger-pin lookup/business rules; customer-specific workbook layouts; Cimatron model modification; Plugin behavior change.
- **Validation:** AWAITING USER EXECUTION for 0.18.1. AI agent did not run the Visual Studio build/tests/Cimatron runtime validation.
- **Next Action:** User runs `powershell -ExecutionPolicy Bypass -File .\\tools\\Invoke-And-Capture.ps1 -Task quality-gate` and provides the capture before 06C2 closure or 06C3 work.


## 2026-09-28 — Version 0.18.1 Session Handoff Documentation Refresh

- **Phase:** 02 — CR Platform Extensions
- **Step:** 06C2 — Mapping & Validation Engine
- **Change Type:** DOCUMENTATION / SESSION HANDOFF CHECKPOINT
- **Reason:** User explicitly requested confirmation of proper engineering documentation and a complete session handoff inside the newly packaged ZIP before executing the 0.18.1 quality gate.
- **Documentation Change:** Expanded `docs/history/session-handoffs/phase-02-step-06c2-mapping-validation-handoff-0.18.1.md` to the full handoff schema required by `AGENTS.md`, including latest approved package, exact approval boundary, completed/pending work, files added/modified, approved existing-file changes, prepared tests, quality-gate status, known errors/limitations, important decisions, Cimatron API findings, exact next action, read-first list, and a new-session continuation prompt.
- **Scope Guard:** No production source behavior, Application mapping logic, Infrastructure reader logic, Plugin/Cimatron behavior, tests, dependency choice, or CR-04/CR-22 business rules were changed by this documentation refresh.
- **Validation:** 0.18.1 remains AWAITING USER EXECUTION. No build/test/Cimatron PASS is asserted by the documentation refresh.
- **Next Action:** User unblocks the extracted package and runs `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate`, then supplies the captured evidence before 06C2 closure.

## 2026-09-28 — Version 0.18.2 — Pre-06C3 Analyzer Warning Cleanup

- **Phase/Step:** 02 / post-06C2 hardening before 06C3.
- **Change ID:** PH02-ST06C2-WARN-CLEANUP
- **Change Type:** ANALYZER CLEANUP / TEST MAINTAINABILITY / DOCUMENTATION
- **Approval:** User explicitly approved closing the warning set before 06C3.
- **User Evidence Entering Change:** The 0.18.1 captured quality gate completed with Release x64 build PASS, all governed test suites PASS, coverage/local quality gate PASS, exit code 0, and 20 analyzer warnings.
- **Warning Inventory:** 2 x `CA1822` on the public instance methods `TabularMappingEngine.ResolveHeaders` and `ValidateRows`; 18 x `CA1861` in the two focused Application mapping test classes for repeated constant array arguments.
- **Design Decision:** Do not make the mapping engine public API static solely to satisfy `CA1822`. The class is intentionally shaped as an Application service for future orchestration. Add narrow source-level suppressions with explicit justification on those two methods only.
- **Test Cleanup:** Replace each constant string-array argument flagged by `CA1861` with named `static readonly` test fixture arrays. Production mapping contracts defensively copy header sequences, so fixture reuse does not alter test isolation or production behavior.
- **Behavioral Impact:** None intended. Mapping resolution, validation semantics, error codes, error privacy, source-row preservation and consumer-neutral behavior are unchanged.
- **Out of Scope:** Step 06C3 integration verification, Step 06D reader orchestration, CR-04/CR-22 business rules, Cimatron model/plugin behavior, unrelated warning cleanup/refactoring.
- **Versioning:** Application assembly advanced from `0.18.1.0` to `0.18.2.0`; product package version advanced to `0.18.2`.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build/test/run Cimatron.
- **Required Next Action:** User runs the standard captured quality gate and supplies the capture. Confirm PASS and verify the prior 20 warnings are gone before authorizing 06C3 implementation.

## 2026-09-28 — Version 0.18.3 — Step 06C3 Integration Verification

- **Phase/Step:** 02 / 06C3 — mapping integration verification and Step 06C closure candidate.
- **Change ID:** PH02-ST06C3.
- **Change Type:** TEST / INTEGRATION VERIFICATION / DOCUMENTATION.
- **Approval:** User explicitly approved proceeding to 06C3 after the 0.18.2 warning-cleanup quality gate passed with 0 warnings / 0 errors.
- **User Evidence Entering Change:** Release x64 build PASS; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage gate PASS; local quality gate PASS; exit code 0.
- **Implementation Decision:** No new production orchestration is introduced. The existing 06C1 mapping contracts and 06C2 mapping/validation engine already expose the required pure Application behavior; 06C3 therefore verifies their composition with the existing tabular source/table contracts through focused integration-style Application tests.
- **Verification Added:** Resolved primary/alias headers populate `TabularSourceDefinition`; consumer-neutral `TabularTable` rows flow into `ValidateRows`; optional mappings remain compatible; ambiguous schemas fail closed with no reader columns; invalid rows fail closed, retain source-row context, and do not disclose customer values.
- **Files Added:** `tests/CimatronCustomization.Application.Tests/TabularMappingIntegrationTests.cs`; `docs/history/session-handoffs/phase-02-step-06c3-integration-verification-handoff-0.18.3.md`.
- **Files Modified:** Application test project registration, Application test harness registration, `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, regenerated `CHECKSUMS.sha256`.
- **Production Impact:** None intentionally. No `src/` production file is changed by 06C3.
- **Out of Scope:** Step 06D reader orchestration; Step 06E live validation; CR-04/CR-22 business logic; Cimatron model/plugin behavior; unrelated cleanup/refactoring.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build/test/run Cimatron.
- **Required Next Action:** User runs the standard captured quality gate and supplies the capture. If fully PASS, review evidence and obtain explicit approval before closing Step 06C and proceeding to Step 06D.

## 2026-09-28 — Version 0.18.3 — Step 06C Formal Closure / 06D Handoff Documentation

- **Phase/Step:** 02 / Step 06C closure checkpoint.
- **Change Type:** VALIDATION RECORD / APPROVAL RECORD / DOCUMENTATION-ONLY HANDOFF.
- **User Evidence:** `quality-gate-20260928-151541.txt` completed with Release x64 build PASS, 0 warnings, 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, and exit code 0.
- **Coverage Evidence:** Application 96.35% (minimum 90%); DesignChecks 100% (minimum 95%); Infrastructure 91.84% (minimum 80%); CimatronIntegration 4.57% measured with no threshold introduced in Step 05B2.
- **Approval:** User explicitly approved Step 06C closure after the 0.18.3 quality-gate evidence was reviewed.
- **Authoritative State:** 06B CLOSED / APPROVED; 06C1 CLOSED / APPROVED; 06C2 CLOSED / APPROVED; 0.18.2 warning cleanup VALIDATED / APPROVED; 06C3 VALIDATED / APPROVED; Step 06C CLOSED / APPROVED; Step 06D NOT STARTED.
- **Documentation:** Updated `VERSION.md`; appended a post-validation closure section to the 06C3 handoff; added `docs/history/session-handoffs/phase-02-step-06c-to-step-06d-session-handoff-0.18.3.md`; updated changelog/history; regenerated checksums.
- **Behavioral Impact:** None. This refresh changes documentation/checksums only; no `src/`, test logic, project file, dependency, Plugin/Cimatron behavior, or CR business logic is changed.
- **Next Action:** Before any Step 06D file change, read `AGENTS.md`, this new 06C → 06D handoff and relevant Step 06 documentation, then prepare the exact 06D execution plan/blast radius for explicit user approval.


## 2026-09-28 — Version 0.18.3 — AGENTS CSV Time-Ledger Policy Migration

- **Phase/Step:** 02 / 06C -> 06D Handoff documentation checkpoint.
- **Change ID:** PH02-DOC-TIMELEDGER-CSV.
- **Change Type:** DOCUMENTATION / GOVERNANCE / TIME-TRACKING MIGRATION.
- **Approval:** User explicitly instructed replacement of the supplied `AGENTS.md`, requested the updated ZIP, and requested documentation maintenance.
- **Policy Change:** `docs/time-tracking/PROJECT-TIMESHEET.csv` is now the authoritative detailed time ledger; duplicate phase-wise Markdown timesheets are no longer maintained.
- **Migration:** Preserved the previously measured `TT-BOOTSTRAP-001` timing values in CSV form. Historical unavailable approval timestamps remain empty and are explained in `Notes`; no timestamps were invented.
- **Files Added:** `docs/time-tracking/PROJECT-TIMESHEET.csv`.
- **Files Removed:** `docs/time-tracking/PROJECT-TIMESHEET.md`, `docs/time-tracking/phase-02-timesheet.md`.
- **Files Modified:** `AGENTS.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `VERSION.md`, `CHECKSUMS.sha256`.
- **Behavioral Impact:** None. Documentation/governance only.
- **Validation:** AWAITING USER EXECUTION. AI agent did not build/test/run Cimatron.
- **Next Action:** User runs the standard captured quality gate and returns the capture; then the CSV row is closed with the actual feedback timestamp and durations.

## 2026-09-28 — Version 0.18.3 — CSV Time-Ledger Migration Validation Closure

- **Phase/Step:** 02 / 06C -> 06D Handoff documentation checkpoint.
- **Change ID:** PH02-DOC-TIMELEDGER-CSV-CLOSE.
- **Change Type:** VALIDATION RECORD / DOCUMENTATION / TIME-TRACKING CLOSURE.
- **User Evidence:** `quality-gate-20260928-154231.txt` confirmed Release x64 build PASS, 0 warnings, 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, exit code 0.
- **Time Ledger:** Closed `TT-CSV-MIGRATION-001` with actual feedback timestamp `2026-09-28T15:43:33+05:30`, task closure `2026-09-28T15:44:07+05:30`, agent active time `1.60` minutes, user-feedback wait `2.55` minutes, rework `0.00` minutes, and calendar elapsed `4.15` minutes.
- **Behavioral Impact:** None. Documentation/governance only.
- **Next Action:** Step 06D remains the next eligible implementation step and requires its own approved plan before any code changes.

## 2026-09-28 — Version 0.19.0 — Step 06D Reader Orchestration / Architecture Integration

- **Phase / Step:** 02 / 06D.
- **Change ID:** PH02-ST06D.
- **Change Type:** IMPLEMENTATION / TEST / INTEGRATION / DOCUMENTATION.
- **Approval:** User explicitly approved the revised three-work-item 06D scope after requiring stale-source protection, canonical result-state reuse, and live-probe integration.
- **Requirement / Feature:** WP8 generic tabular-input orchestration supporting future CR-04 and CR-22 consumers without implementing those business rules.
- **Design Decision — Physical Reads:** A single physical read was considered. It would require moving raw workbook value interpretation/conversion into Application or materially changing the approved reader contracts. That would broaden 06D. The approved design therefore retains two reads with strict header-snapshot consistency protection.
- **Source Consistency:** Header discovery uses the same file existence/format/maximum-size controls as row reading. The complete ordered discovered header row is supplied to pass two. If pass-two headers differ, `ExcelTabularDataReader` returns `TABULAR_HEADERS_CHANGED` before column resolution or row acceptance.
- **Canonical Outcome:** `ReadMappedTabularDataResult` uses the existing Domain `ResultStatus` enum only. Successful orchestration is `Passed`; controlled orchestration failures are `Error`. `TabularProcessingStage` records Discovery/Mapping/Read/Validation separately and is not a status model.
- **Application Flow:** `ReadMappedTabularData` performs discovery → mapping resolution → mapped source construction → consistent reader pass → row validation → validated table.
- **Live Probe:** `TabularReaderRuntimeProbe` now invokes `ReadMappedTabularData` with the real `ExcelTabularDataReader`. `tools/Start-Step06DTabularProbe.ps1` prepares the one-shot request and does not launch Cimatron.
- **Tests Added/Changed:** New Application orchestration tests cover success and each failure stage; Infrastructure tests cover discovery size limits and file/header mutation between passes. Existing reader behavior remains covered by the prior suite.
- **Versioning:** Product version and changed production assemblies advanced to `0.19.0` / `0.19.0.0`.
- **Scope Exclusions:** No CR-04/CR-22 rules, customer-specific workbook layouts, Plugin UI change, Cimatron model modification, dependency changes, or unrelated cleanup/refactor.
- **AI Execution Boundary:** Agent did not run build/tests/coverage/Cimatron. Static package checks only are permitted before user execution.
- **Validation:** AWAITING USER EXECUTION.
- **Step 06 Remaining Work:** Only final user quality-gate evidence, live mapped-tabular Cimatron probe evidence, documentation/time-ledger closure, and explicit Step 06 closure approval. No additional architecture sub-step is planned.


## 2026-09-28 — Version 0.19.1 — Step 06D Quality-Gate Corrective Patch

- **Phase / Step:** 02 / 06D.
- **Change ID:** PH02-ST06D-QG-CORRECTIVE.
- **Change Type:** BUGFIX / TEST / ANALYZER CLEANUP / DOCUMENTATION.
- **Approval:** User explicitly approved the smallest corrective scope after 0.19.0 quality-gate failure evidence was reviewed.
- **Evidence:** `quality-gate-20260928-155942.txt` showed build succeeded, Release x64 PASS, Architecture PASS, Domain PASS, 4 warnings, `APPLICATION TESTS: FAIL`, and exit code 1.
- **Root Cause:** The new validation-stage unit test built a `TabularTable` whose source contract required Decimal while supplying Text. `TabularTable` correctly rejected the invalid fixture during construction, so `ReadMappedTabularData` never reached its validation stage.
- **Fix:** Make the fixture source contract Text-compatible so `TabularTable` is valid, while the separate mapping still expects Decimal; orchestration can then exercise and report the intended validation-stage mismatch.
- **Analyzer Fixes:** Replaced two LINQ `First()` calls on indexable collections with `[0]`; replaced inline constant-array test input with a static readonly fixture; replaced zero-length array allocation with `Array.Empty<string>()`.
- **Files Changed:** `src/CimatronCustomization.Application/ReadMappedTabularData.cs`, Application `AssemblyInfo.cs`, `tests/CimatronCustomization.Application.Tests/ReadMappedTabularDataTests.cs`, governance/version/history/time-ledger/handoff/checksum files.
- **Behavioral Impact:** No intended production behavior change beyond analyzer-neutral indexing; orchestration architecture and live probe remain exactly as approved in 0.19.0.
- **Validation:** AWAITING USER EXECUTION. AI agent did not run build/tests/Cimatron.
- **Next Action:** User runs the captured quality gate. Live probe remains blocked until the quality gate is clean.

### 2026-09-28 — Phase 02 Step 06D 0.19.1 quality-gate validation
User-supplied `quality-gate-20260928-160425.txt` confirmed Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage and local quality gates PASS; exit code 0. Corrective quality-gate cycle closed. Live Cimatron Step 06D probe remains the next required evidence.


### 2026-09-28 — Phase 02 Step 06D live validation closure
- **Evidence:** `step06d-tabular-probe-20260928-160906.txt` plus user Cimatron screenshot.
- **Runtime:** `ProcessName: CimatronE`; probe ran in-process from the Cimatron 2026 Program directory.
- **Orchestration:** `OrchestrationResult: PASS`, `OrchestrationStage: Completed`, no error code/message.
- **Known Answer:** one row; `Block_A`, steel grade `1.2344`, weight `12.5`.
- **Dependencies:** `ExcelDataReader` 3.9.0.0 loaded from the Cimatron Program directory; `System.ValueTuple` not loaded for this path.
- **Result:** Step 06D validation PASS. No additional architecture sub-step is planned.
- **Remaining:** explicit Step 06 closure approval against WP8 definition of done.

## 2026-09-28 — Version 0.19.1 — Step 06 Overall Closure

- **Phase/Step:** 02 / Step 06 — Generic Tabular Input Platform closure.
- **Approval:** User explicitly approved Step 06 overall closure after reviewing the clean 0.19.1 quality-gate evidence and successful live Step 06D Cimatron probe.
- **Definition of Done:** WP8 reader, configuration mapping, controlled failure modes, dependency/runtime approval, Application orchestration, stale-header protection, and live in-process probe evidence are complete.
- **Validation Evidence:** `quality-gate-20260928-160425.txt`, `quality-gate-20260928-160821.txt`, `step06d-tabular-probe-20260928-160906.txt`, plus the user-supplied Cimatron PASS screenshot.
- **Authoritative State:** Step 06D VALIDATED / CLOSED; Step 06 overall CLOSED / APPROVED.
- **Behavior Change:** None in this closure update; documentation/time-ledger/checksum/handoff only.
- **Next Action:** Determine the next planned Phase 02 requirement/step from the governing roadmap/requirements and prepare its exact plan/blast radius for explicit approval. Do not add another Step 06 sub-step.


### 2026-09-28 — Phase 02 Step 06 final closure validation
- **Evidence:** `quality-gate-20260928-161934.txt`.
- **Result:** Release x64 build PASS; 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage gate PASS; local quality gate PASS; exit code 0.
- **Authoritative State:** Step 06 overall VALIDATED / CLOSED.
- **Behavior Change:** None; final closure documentation/time-ledger/checksum update only.


## 2026-09-28 — Version 0.19.1 — Step 06E Live Validation & Closure Documentation Alignment

- **Phase / Step:** 02 / 06E — Live Validation & Closure.
- **Change ID:** PH02-ST06E-DOC-ALIGN.
- **Change Type:** DOCUMENTATION / TRACEABILITY / DEFERRED-RISK REGISTER.
- **Approval:** User explicitly approved the 06E documentation-alignment package and instructed that deferred review findings be documented and carried forward until their owning CR/release decision. Exact approval timestamp was not independently captured and is intentionally not invented.
- **Alignment:** The live Cimatron probe previously labeled 06D and the subsequent Step 06 closure are the planned 06E activity in substance. Existing evidence filenames remain unchanged for integrity.
- **06E Evidence:** in-process `CimatronE` probe PASS through `ReadMappedTabularData` using `LegacyInput.xls`; 0.19.1 corrective quality gate PASS; final closure quality gate `quality-gate-20260928-161934.txt` PASS with 0 warnings / 0 errors and exit code 0; user closure approval.
- **Deferred Findings:** Added `docs/platform/STEP-06-DEFERRED-FINDINGS.md`. ST06-DF-01/04 carry to CR-04 and CR-22 planning; ST06-DF-02 is mandatory for CR-22; ST06-DF-03 is mandatory for CR-04; ST06-DF-05 carries to D5/client packaging; ST06-DF-06 carries to first CR-04/CR-22 integration and pre-client-release hardening.
- **Behavioral Impact:** None. No production/source/test/project/dependency change.
- **Authoritative State:** 06E VALIDATED / CLOSED; Step 06 overall remains VALIDATED / CLOSED.


### 2026-09-28 — Step 06E documentation-alignment validation
- **Evidence:** `quality-gate-20260928-164128.txt`.
- **Result:** Release x64 build PASS; 0 warnings / 0 errors; all governed test suites PASS; coverage gate PASS; local quality gate PASS; exit code 0.
- **Authoritative State:** Step 06E documentation alignment VALIDATED / CLOSED; Step 06 overall remains VALIDATED / CLOSED.
- **Deferred Findings:** `docs/platform/STEP-06-DEFERRED-FINDINGS.md` remains mandatory carry-forward until its owning CR/release decisions explicitly resolve, accept, or supersede each item.
- **Behavior Change:** None; documentation/time-ledger/checksum closure only.


## 2026-09-29 — Version 0.20.0 — Step 07 Cimatron API Capability Verification

- **Phase / Step:** 02 / 07.
- **Change ID:** PH02-ST07.
- **Change Type:** API-DISCOVERY / DEVELOPMENT DIAGNOSTIC / DOCUMENTATION.
- **Approval:** User explicitly approved the Step 07 implementation plan, including Option A new-tool placement, 07C-4 hidden-state candidate scope, tolerances (`1e-3 mm`, `1e-2 mm³`, relative `1e-6`), and version `0.20.0`. Exact approval timestamp was not independently captured; it is intentionally not invented.
- **Tool Placement:** Added `tools/CimatronCustomization.ApiCapabilityVerification/`; existing `ZoomCommandDiscovery` remains outside the approved change set.
- **07A:** Reflection-only installed-Interop inventory resolves duplicate namespaces/assemblies, GUIDs, base interfaces, property access kind, methods and enum values for all Step 07 targets.
- **07B:** Added user-owned known-answer Part/Assembly construction specification and blank authoritative values sheet.
- **07C:** Added read-only live probes for geometry services, assembly-context entity resolution/nested highlight, component attribute/BOM sources, and the separately approved FR-021 hidden-state candidates.
- **Safety:** Every live mode captures document `IsModified`, path, file last-write UTC, and length before/after. BOM output is created only below the Step 07 temp folder. Temporary highlight snapshots/restores prior selection. Mutating API tokens are architecture-guarded.
- **07D:** Added a new verification register with every item initially `NOT VERIFIED — AWAITING USER EXECUTION`; no capability is promoted from agent implementation alone.
- **Production Impact:** None intended. No production source, configuration, Plugin behavior, CR/SA rule, production port/adapter, or client packaging decision is changed.
- **Out-of-process Limitation:** All Step 07 live capability evidence remains out-of-process; Step 08 must reconfirm any promoted surface in-process.
- **Deferred Findings:** Step 06 `ST06-DF-01…06` remain `DEFERRED` and mandatory carry-forward.
- **AI Execution Boundary:** Agent did not run build/tests/coverage/Cimatron. Static package/integrity inspection only.
- **Validation:** AWAITING USER EXECUTION.


## 2026-09-29 — Version 0.20.1 — Step 07 Quality-Gate Corrective Patch

- **Phase / Step:** 02 / 07.
- **Change ID:** PH02-ST07-QG-CORRECTIVE.
- **Evidence:** user-supplied `quality-gate-20260929-141352.txt`.
- **Observed result:** Release x64 build FAILED, 0 warnings / 12 errors, exit code 1. The failure occurred before governed test/coverage gates could establish PASS.
- **Failure scope:** all reported compiler errors were inside `tools/CimatronCustomization.ApiCapabilityVerification/`; production projects were not changed to address the failure.
- **Root causes:** missing `Microsoft.CSharp` runtime-binder reference for installed interop conversions; several installed COM signatures surface documented arrays as object/variant returns; `GetEntityPointDistance` requires an `out IPointData`; `get_SubInstances` required explicit object typing for generic observation.
- **Correction:** narrow compile-only adaptation inside the approved Step 07 diagnostic project plus mandatory version/history/time/handoff/checksum records.
- **Production impact:** none intended; `src/**`, `config/**`, existing ZoomCommandDiscovery sources, unrelated tests and `AGENTS.md` remain outside the corrective change set.
- **Validation:** AWAITING USER EXECUTION. Agent did not run build/tests/Cimatron.
- **Next action:** rerun the full captured quality gate on 0.20.1; do not run 07A/07C until it passes cleanly.


## 2026-09-29 — Version 0.20.1 — Step 07 Quality-Gate Validation

- **Evidence:** user-supplied `quality-gate-20260929-142529.txt`.
- **Result:** Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage gate PASS; local quality gate PASS; exit code 0.
- **Scope:** validates the 0.20.1 compile corrective. No 07A/07C capability was promoted by this gate.

## 2026-09-29 — Version 0.20.2 — Step 07 Reflection-Only Enum Corrective

- **Phase / Step:** 02 / 07.
- **Change ID:** PH02-ST07-07A-REFLECTION-CORRECTIVE.
- **Evidence:** user console output from the first 07A execution on 0.20.1.
- **Observed result:** tool terminated with `InvalidOperationException: Code execution is prohibited in an assembly loaded as ReflectionOnly.` before valid reflection evidence was produced.
- **Root cause:** `CapabilityApiReflectionInventory` attempted `Enum.GetNames` / `Enum.Parse` on reflection-only enum types. Those APIs require runtime enum operations and are invalid for `ReflectionOnlyLoadFrom` types.
- **Correction:** enumerate enum literal metadata via `Type.GetFields(BindingFlags.Public | BindingFlags.Static)` and read each literal with `FieldInfo.GetRawConstantValue()`. No enum parsing or enum object creation remains in the reflection-only path.
- **Safety boundary:** 07A remains metadata-only and does not call `AppAccess`, `GetApplication`, `GetActiveDoc`, or any Cimatron runtime surface.
- **Production impact:** none intended; `src/**`, `config/**`, existing ZoomCommandDiscovery sources, unrelated tests and `AGENTS.md` remain outside the corrective change set.
- **Validation:** AWAITING USER EXECUTION. Agent did not run build/tests/Cimatron.
- **Next action:** rerun full quality gate on 0.20.2; if clean, close Cimatron and rerun `--reflect-capability-api`.


## 2026-09-29 — Step 07 Session Handoff — 0.20.2

- User workstation quality gate `quality-gate-20260929-143207.txt`: PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- User-run 07A reflection inventory `api-capability-reflection-20260929-143432.txt`: COMPLETE; footer confirms `RuntimeCalls: NONE`.
- Verification register updated with evidence-backed installed signatures. Runtime capability statuses remain pending 07C, except the instance-attribute getter is recorded `NOT AVAILABLE` because 07A shows `IAssInstance.Attribute` is SET-ONLY.
- KA-PART-1 preparation observed with two bodies, through-hole, `KA_UCS_90Z`, and part/model material `1.2738`; body-level custom attribute is not claimed.
- User explicitly stated that KA-ASM-1 is ready for continuation. Final ids/transforms/lock/gap values remain to be recorded before runtime comparison.
- No production or Step 07 tool code change. Documentation/time-ledger/handoff/checksum update only.
- Next session starts with 07C-1 preparation/execution against KA-PART-1; do not jump to 07C-2/3/4.

## 2026-09-29 — Version 0.20.4 — Step 07C-1C Current Selection ID Inspection

- **Phase / Step:** 02 / 07C-1C.
- **Change ID:** PH02-ST07C1C-SELECTION-ID.
- **Approval:** User explicitly approved preparation of the 0.20.4 selection-ID diagnostic. Exact approval timestamp was not independently captured and is intentionally not invented.
- **Reason:** 0.20.3 enumerated 90 face IDs and 152 edge IDs but deliberately did not infer semantic roles. The user then visually chose the intended test face. Assigning a face ID from enumeration order would violate the no-guess rule.
- **Implementation:** Added `CurrentSelectionInspection` and `--inspect-current-selection --expect Part`. It reads `ISelection.Selection`, records actual selected IDs/types, and, when the selected entity is an edge, reads `GetEdgeConvexity(..., 0.5)`. It does not assign or clear selection.
- **Safety:** Standard Step 07 no-mutation before/after evidence remains mandatory. No write API is introduced by the new diagnostic.
- **0.20.3 evidence:** user quality gate `quality-gate-20260929-175613.txt` passed with exit code 0. Discovery evidence `api-capability-geometry-known-answer-discovery-20260929-180559.txt` confirmed Part/mm context, two bodies (IDs 4/5), 25 mm body-pair minimum distance, and active UCS ID 2 after the user explicitly activated `KA_UCS_90Z`; no-mutation evidence was UNCHANGED.
- **Known-answer mapping:** user visually confirmed the large complex left body as B1 and the separate right rectangular body as B2, and selected the intended test face. The test-face entity ID and intended convex/concave edge IDs remain pending 0.20.4 evidence.
- **Production impact:** none intended; production source/configuration/Plugin and 07C-2/3/4 remain unchanged.
- **AI execution boundary:** agent did not build/tests/run Cimatron and does not claim 0.20.4 PASS.


## 2026-09-29 — Version 0.20.8 — Step 07C-1R Session Handoff / Evidence Alignment

- **Phase / Step:** 02 / 07C-1R.
- **Change ID:** PH02-ST07C1R-SESSION-HANDOFF.
- **Change Type:** DOCUMENTATION / EVIDENCE ALIGNMENT / SESSION HANDOFF.
- **User evidence:** `quality-gate-20260929-190027.txt`, `api-capability-geometry-known-answer-discovery-20260929-190407.txt`, `api-capability-geometry-20260929-191114.txt`, plus user screenshots of the KA-PART-1 UCS feature/UI.
- **Quality gate:** 0.20.7 user workstation quality gate PASS with 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, exit code 0.
- **Runtime geometry:** B1/B2 metrics and 25 mm gap remain stable; UCS 2 and 249 both resolve; B1 face-list boxes differ between the frames; body-list `GetBoundingBoxByUCS` returns `[1,1,1,0,0,0]` in both; face 90 resolves and returns flat-axis boxes; no mutation.
- **UCS interpretation:** do not label 249 “Main UCS.” Based on B1 and face-90 boxes, UCS 249 is axis-parallel to UCS 2 and consistent with a `(50,60,0)` translation. This does not verify rotated-axis bounding-box semantics.
- **API classification correction:** `SurfacesArea` is **NOT AVAILABLE** in installed Cimatron 2026 SP2P1 Interop because the member is absent; “BLOCKED” is not used for an absent API.
- **Remaining 07C-1 runtime work:** `GetEntityPointDistance` and `GetPiercingPoints` still require one controlled run using the evidence-backed point/ray inputs recorded in the session handoff. A known-angle rotated UCS check is proposed to settle UCS-oriented bounding-box semantics before CR-01/CR-25 consumption.
- **Scope boundary:** no source/test/config/model behavior change in 0.20.8. No 07C-2 implementation or execution is authorized.
- **AI execution boundary:** agent did not build/tests/run Cimatron for 0.20.8; this handoff records user-supplied evidence only.

## 2026-09-30 — Version 0.20.11 — Step 07C-1R3 Compile Corrective

- **Phase / Step:** 02 / 07C-1R3.
- **Change ID:** PH02-ST07C1R3-COMPILE-CORRECTIVE.
- **Change Type:** DEVELOPMENT-DIAGNOSTIC COMPILE CORRECTIVE.
- **User evidence:** 0.20.10 quality-gate capture `quality-gate-20260930-002511.txt` and direct Release-build output reported CS0411 at `GeometryServicesVerification.cs(131,25)`.
- **Root cause:** the compiler could not infer `T` for `VerificationRuntimeContext.TryObserve<T>` around the dynamic/COM `GetPiercingPoints` expression.
- **Approved fix:** specify `TryObserve<double[]>` explicitly. No geometry behavior, conversion behavior, ray inputs, target entity, or production code is changed.
- **Scope boundary:** production `src/**`, Plugin, CR/SA logic, model data, and 07C-2 remain unchanged.
- **Validation:** awaiting user quality gate and, after PASS, the same three-ray piercing rerun.
- **AI execution boundary:** agent did not build/tests/run Cimatron and does not claim PASS.


## 2026-09-30 — 0.20.13 — Phase 02 / Step 07C-1R5 — Final Geometry Semantics Run Preparation

- **Change ID:** PH02-ST07C1R5-FINAL-GEOMETRY-SEMANTICS.
- **Change Type:** BUGFIX / API-DISCOVERY / DOCUMENTATION.
- **Requirement / Feature:** 07C-1 Geometry Services — `IGeomServices.GetPiercingPoints` final semantics resolution.
- **Approval:** User explicitly instructed analysis against existing 07A + piercing evidence, correction of argument order, one final batched 07C-1 run, and closure after that run regardless of residual uncertainty.
- **Root Cause:** Installed 07A reflection signature is `GetPiercingPoints(iDirection, iBasePositin, iEntList)`, while the 0.20.12 diagnostic passed `origin` first and `direction` second.
- **Evidence Analysis:** The 0.20.12 results validate the diagnosis. Case 1 used actual base `(-1,0,0)` and direction `(150,30,20)`; at X=100, `t=101/150`, giving `(100,20.2,13.4666666666667)`, exactly the observed point. Case 2 similarly gives `(100,47.1333333333333,13.4666666666667)`. Case 3 used actual base `(1,0,0)` and direction `(150,30,20)`; `t=99/150`, giving `(100,19.8,13.2)`, exactly observed. All three actual parameters have positive `t`, so the intended miss/pointing-away cases do not distinguish one-way ray from infinite line.
- **Fix:** Map CLI `--ray-direction` to installed `iDirection` and `--ray-origin` to installed `iBasePositin`; record both inputs before each call.
- **Final Test Batch:** Corrected three original cases plus direction `(-2,0,0)` magnitude check; two existing face-90 point-distance cases; UCS 251 versus reference UCS 2 rotated bounding-box checks; no-mutation snapshot.
- **Stop Rule:** No further 07C-1 live experiments after the final batch. Residual ambiguity becomes a documented limitation and 07C-1 closes.
- **Files Changed:** development diagnostic geometry file/version metadata; capability register; VERSION/CHANGELOG/history; time ledger; new handoff; checksum manifest.
- **Production Impact:** None. `src/**` remains byte-identical.
- **Build Result:** AWAITING USER EXECUTION.
- **Runtime Result:** AWAITING USER FINAL LIVE RUN.
- **Cimatron Version:** 2026.0 SP2P1 / build 2026,0201,2064,662.
- **Next Action:** User runs quality gate; after PASS, user performs the single final 07C-1 batch and supplies evidence.

## 2026-09-30 — Version 0.20.14 — Step 07C-1 Closure Session Handoff

- **Phase / Step:** 02 / 07C-1.
- **Change ID:** PH02-ST07C1-CLOSURE-SESSION-HANDOFF.
- **Change Type:** DOCUMENTATION / SESSION HANDOFF.
- **Approval:** User explicitly requested a cumulative session-handoff ZIP after approving 07C-1 closure.
- **State recorded:** 07C-1 CLOSED / USER VALIDATED; 07C-2 UNBLOCKED BUT NOT STARTED.
- **Evidence carried forward:** v0.20.13 quality-gate PASS, final geometry evidence `api-capability-geometry-20260930-010854.txt`, final piercing semantics, point-distance evidence, rotated-UCS evidence, and no-mutation UNCHANGED.
- **Scope boundary:** no production `src/**`, tests, model data, configuration, Plugin behavior, or diagnostic runtime behavior change. This handoff does not authorize 07C-2.
- **AI execution boundary:** agent did not build/tests/run Cimatron for this handoff-only submission.


## 2026-09-30 — Version 0.20.17 — Step 07C-2 Closure / User Validation

- **Phase / Step:** 02 / 07C-2.
- **Evidence:** `quality-gate-20260930-033812.txt` and `api-capability-assembly-context-20260930-034145.txt`, plus user visual confirmations.
- **Quality gate:** PASS — Release x64 build, 0 warnings / 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests, coverage gate and local quality gate all PASS; exit code 0.
- **Live result:** correct 0.20.17 verifier executed in active Assembly context. Three `KA-PART-1` occurrences were traversed; transformations, assembly entities, reverse instance lookup, lock getter, active-UCS assembly box, highlight pauses, selection restore and no-mutation evidence were recorded.
- **User validation:** all three highlights visually correct; selection empty after completion; no unsaved-change indicator; explicit closure approval received.
- **Capability state:** U7/U8/U9/U10/U12 VERIFIED; U11 PARTIALLY VERIFIED because no independent UI assembly-box value was available.
- **Limitation:** cross-occurrence `MinDistancePos` returned 0 for all three occurrence pairs despite distinct transforms and the independent 25.000 mm top-level B1-to-B1 measurement. Carry this as an assembly-placement limitation; do not request another 07C-2 probe.
- **Production impact:** none. This closure/handoff is documentation/evidence only. Step 07 remains development/out-of-process; production promotion still requires later in-process confirmation.
- **Status:** **07C-2 CLOSED / USER VALIDATED**.


## 2026-09-30 — Version 0.20.18 — Step 07C-3 Component Property / BOM Verification Preparation

- **Phase / Step:** 02 / 07C-3.
- **Change ID:** PH02-ST07C3-COMPONENT-PROPERTY-BOM.
- **Approval:** User approved the amended 07C-3 scope and then approved the identifier correction that keeps existing U16 for 07C-4 and assigns the new model/material getter evidence item to U17. Exact approval timestamps were not independently captured and are not invented.
- **Scope:** U13 known body attribute read; U14 retained SET-ONLY classification; U15 BOM CSV export/material evidence; U17 retained-evidence-only material getter check. 07C-4 hidden-state interpretation and the 07C-2 `MinDistancePos` limitation are out of scope.
- **Implementation:** hardened the existing development verifier to require explicit known-answer attribute/material values, verify the target is a body, record known attribute matches in Part and assembly context, constrain BOM outputs to the existing Step07 temp root, inspect only known-answer KA-PART-1 material fields, and record a model-folder listing guard.
- **U17 evidence:** the authoritative 0.20.17 package retains the 07A conclusions but not raw 07A reflection output showing any readable model/Part material getter. Therefore U17 is `NOT AVAILABLE FROM RETAINED 07A EVIDENCE`; no new reflection run or speculative getter call was added.
- **Production impact:** none. No production `src/**`, Plugin, CR/SA behavior, configuration, installer or customer model files changed.
- **Model setup boundary:** the user must deliberately create the known B1 body attribute in disposable KA-PART-1 through Cimatron UI, save, and reopen/reload KA-ASM-1 before the live baseline. The package does not modify `.elt` files.
- **Validation:** AWAITING USER WORKSTATION QUALITY GATE AND ONE LIVE 07C-3 RUN. Agent did not run build/tests/coverage/Cimatron and does not claim PASS.
- **Stopping rule:** one governed live run. Unresolved behavior is documented as limitation unless a separate corrective is explicitly approved.


## 2026-09-30 — Version 0.20.19 — Step 07C-3 Verifier Compile Corrective

- **Phase / Step:** 02 / 07C-3.
- **Change ID:** PH02-ST07C3-COMPILE-CORRECTIVE.
- **Change Type:** DEVELOPMENT-DIAGNOSTIC COMPILE CORRECTIVE / DOCUMENTATION.
- **Approval:** User explicitly approved the narrow verifier compile correction after review of the failed workstation quality-gate evidence. Exact approval timestamp was not independently captured and is not invented.
- **Evidence entering change:** `quality-gate-20260930-115502.txt` and `quality-gate-20260930-115729.txt`, both exit code 1. The second capture exposes `CS1061` at `ComponentPropertySourceVerification.cs(54,109)` and `(55,119)`: `AttributeObservation` has no `Status` member. It also records separate access-denied deployment/copy failures in `C:\Program Files\Cimatron\Cimatron\2026.0\Program`.
- **Root cause:** the 0.20.18 evidence writer treated the private `AttributeObservation` enum as though it were an object with a `Status` property.
- **Fix:** only the two U13 evidence expressions are changed from `<enum>.Status` to direct enum rendering. This preserves the existing enum values (`Absent`, `Matched`, `NotMatched`, `ReadError`) and does not change Cimatron API behavior.
- **Version alignment:** development verifier ToolVersion and assembly/file version advanced to `0.20.19`.
- **Production impact:** none. No production `src/**`, Plugin/CR-SA/configuration/installer/model behavior changed.
- **Tests added/changed:** none. The compiler itself is the direct regression gate for this source defect; no runtime behavior was changed. Existing governed quality gate remains mandatory.
- **AI execution boundary:** agent did not build, run tests/coverage, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER 0.20.19 QUALITY GATE. The single approved 07C-3 live run remains blocked until that gate passes.

## 2026-09-30 — Version 0.20.20 — Step 07C-3 Known-Answer Body Attribute Setup Helper

- **Phase / Step:** 02 / 07C-3 setup prerequisite.
- **Change ID:** PH02-ST07C3-KA-BODY-ATTRIBUTE-SETUP.
- **Change Type:** DEVELOPMENT-ONLY CONTROLLED MODEL SETUP UTILITY / DOCUMENTATION.
- **Approval:** User explicitly approved implementing the separate setup helper in this chat. Exact approval timestamp was not independently captured and is not invented.
- **Entering evidence:** user workstation `quality-gate-20260930-120311.txt` validates 0.20.19 with Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS and exit code 0.
- **Reason:** U13 needs a deliberate body-level known-answer attribute on B1. The existing Part/model material `1.2738` must not be reused as proof of body-attribute readability, and the existing 07C-3 verifier must remain read-only.
- **Implementation:** added separate `tools/CimatronCustomization.KnownAnswerModelSetup/`. The helper requires explicit `--apply`, exact Part context, exact model title `KA-PART-1`, exact B1 body entity ID `4`, and exact diagnostic `cmAttString` name/value `STEP07_B1_TEST_ATTRIBUTE = KNOWN_ANSWER_07C3`.
- **Fail-closed behavior:** inspect existing attributes first; exact match reports `ALREADY_PRESENT`; same name with different type/value fails and does not overwrite; non-body/wrong context/wrong model/wrong ID/wrong requested name/value all fail before mutation.
- **Mutation:** create through `IApplication.GetAttributeFactory()` and `IAttributeFactory.Create(cmAttString, name)`, assign string `Value`, call `IAttributeSink.Attach()`, then exact `GetAttribute(cmAttString, name)` read-back. No Save/SaveAs/Close call exists.
- **User workflow:** after successful attach/read-back, helper explicitly reports in-memory mutation and manual save requirement. User saves `KA-PART-1`, then reopens/reloads `KA-ASM-1` before the read-only 07C-3 baseline.
- **Capability status:** setup alone does not promote U13. U13/U15 remain pending the single governed read-only 07C-3 live run; U14 remains NOT AVAILABLE; U17 remains NOT AVAILABLE FROM RETAINED 07A EVIDENCE; U16/07C-4 untouched.
- **Production impact:** none. No production `src/**`, Plugin, CR/SA/configuration/installer/customer model behavior changed.
- **AI execution boundary:** agent did not build, run tests/coverage or run Cimatron and does not claim 0.20.20 PASS.

## 2026-09-30 — Version 0.20.21 — Step 07C-3 Known-Answer Attribute Read-Back Diagnostic Corrective

- **Phase / Step:** 02 / 07C-3 setup prerequisite.
- **Change ID:** PH02-ST07C3-KA-READBACK-DIAGNOSTIC.
- **Change Type:** BUGFIX / DEVELOPMENT-ONLY DIAGNOSTIC OBSERVABILITY.
- **Approval:** User explicitly approved this narrow corrective after the failed controlled setup run; exact approval timestamp was not independently captured and is not invented.
- **Entering quality evidence:** completed `quality-gate-20260930-124150.txt` validates 0.20.20 with Release x64 PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local quality gates PASS and exit code 0.
- **Observed runtime symptom:** user ran the approved setup command against active `KA-PART-1`; the helper reported `KNOWN-ANSWER SETUP FAILED: System.InvalidOperationException: Exact attribute read-back did not match the requested name/type/value.` This establishes that the code passed `Attach()` and obtained a non-null read-back object, but 0.20.20 printed the observed fields only after the comparison, so the mismatching field was hidden.
- **Recovery instruction:** do not save the mutated in-memory Part after the failed run; close `KA-PART-1` without saving and reopen it before another setup attempt.
- **Root cause of diagnostic gap:** `ReadBack.Name`, `ReadBack.Type`, and `ReadBack.Value` were appended/output only after the equality check. A mismatch therefore threw before those observations reached the console.
- **Fix:** calculate and print the three actual read-back fields immediately after `GetAttribute(...)` returns and before the existing fail-closed comparison. Comparison semantics are unchanged.
- **Behavior intentionally unchanged:** exact model/entity/name/value restrictions, `cmAttString`, no overwrite, `Attach()`, exact `GetAttribute(cmAttString, name)`, fail-on-mismatch, no Save/SaveAs/Close, and the separate read-only 07C-3 verifier.
- **Tests added/changed:** none; no production or business logic changed. The mandatory workstation quality gate and controlled Cimatron rerun remain the regression/behavior evidence.
- **Capability status:** U13 remains NOT VERIFIED; U15 remains NOT VERIFIED; U14/U17 classifications and U16/07C-4 reservation remain unchanged.
- **Production impact:** none. `src/**` remains byte-identical to 0.20.20.
- **AI execution boundary:** agent did not build, run tests/coverage or run Cimatron and does not claim 0.20.21 PASS.

## 2026-09-30 — Version 0.20.22 — Step 07C-3 Known-Answer Attribute Name-Observation Corrective

- **Phase / Step:** 02 / 07C-3 setup prerequisite.
- **Change ID:** PH02-ST07C3-KA-NAME-OBSERVATION-CORRECTIVE.
- **Change Type:** BUGFIX / DEVELOPMENT-ONLY EVIDENCE-DRIVEN VALIDATION CORRECTIVE.
- **Approval:** User explicitly approved this narrow corrective after reviewing the 0.20.21 runtime evidence. Exact approval timestamp was not independently captured and is not invented.
- **Entering quality evidence:** `quality-gate-20260930-125811.txt` validates 0.20.21 with Release x64 PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local quality gates PASS and exit code 0.
- **Observed runtime evidence:** user-run 0.20.21 setup against active `KA-PART-1` printed blank `ReadBack.Name`, `ReadBack.Type: cmAttString`, and `ReadBack.Value: KNOWN_ANSWER_07C3`, then failed the old name/type/value equality gate.
- **Interpretation:** the code had already called exact `GetAttribute(cmAttString, args.AttributeName)` and passed the non-null guard. Therefore the requested named lookup succeeded, and the returned type/value matched; only returned `IAttribute.Name` was blank.
- **Fix:** retain exact named lookup and logging of all three observed fields, but validate only non-null read-back, exact `cmAttString` type, and exact requested value. Returned `Name` is evidence only.
- **Behavior intentionally unchanged:** exact Part/model/body restrictions, explicit `--apply`, diagnostic name/value constants, no overwrite, factory/Create/Attach path, no alternate APIs, no Save/SaveAs/Close, and separate read-only 07C-3 verifier.
- **Capability status:** setup corrective does not itself verify U13. U13/U15 remain NOT VERIFIED; U14/U17 classifications and U16/07C-4 reservation remain unchanged.
- **Production impact:** none. `src/**` remains byte-identical to 0.20.21.
- **AI execution boundary:** agent did not build, run tests/coverage or run Cimatron and does not claim 0.20.22 PASS.


## 2026-09-30 — Version 0.20.23 — Step 07C-3 Occurrence-Entity / Named-Attribute Corrective

- **Phase / Step:** 02 / 07C-3.
- **Change ID:** PH02-ST07C3-OCCURRENCE-ENTITY-ATTRIBUTE-CORRECTIVE.
- **Change Type:** BUGFIX / DEVELOPMENT-ONLY LIVE-EVIDENCE CORRECTIVE.
- **Approval:** User explicitly approved after the first governed 07C-3 run failed and requested extra care because of repeated revisits; exact approval timestamp was not independently captured and is not invented.
- **Entering quality evidence:** `quality-gate-20260930-130837.txt` validates 0.20.22 with Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gates PASS, exit code 0.
- **Known-answer setup evidence:** user-run 0.20.22 setup returned `ATTACHED_AND_READ_BACK` on `KA-PART-1` entity 4 (`cmBody`) with exact `cmAttString` value `KNOWN_ANSWER_07C3`; user then manually saved and reopened `KA-ASM-1`.
- **Verifier failure evidence:** 0.20.19 read-only verifier raised COM `0x80040207` on `instance.Model.GetEntityById(4, partModel)` before U13/BOM evidence.
- **Independent read-only confirmation:** `assembly-occurrence-entity-diagnostic-20260930-131646.txt` observed body entity 4 (and 5 where applicable) on the same `KA-PART-1` occurrences through `IAssInstance.GetAllEntities()`, with no-mutation result `UNCHANGED`.
- **Fix:** `ComponentPropertySourceVerification` now resolves the requested entity from `IAssInstance.GetAllEntities()` using exact ID plus `cmBody` checks; null/missing/wrong-type/duplicate matches fail closed.
- **Attribute fix:** `GetAttributes()` remains evidence enumeration, while exact U13 confirmation uses `GetAttribute(cmAttString, requestedName)` and requires non-null/exact type/exact value. Returned `IAttribute.Name` is logged only because the proven Cimatron 2026 behavior returns it blank after successful named lookup.
- **Regression guard:** architecture tests require occurrence enumeration + exact named string lookup and prohibit the failed `partModel.GetEntityById(...)` token and old `attribute.Name` equality gate in the 07C-3 verifier.
- **Scope unchanged:** assembly-context conversion, BOM temp export/evidence, no-mutation guards, U14/U17 classifications, and 07C-4 exclusion are preserved.
- **Production impact:** none. Production `src/**` remains unchanged.
- **AI execution boundary:** agent did not build, run tests/coverage, or run Cimatron and does not claim 0.20.23 PASS.


## 2026-09-30 — Version 0.20.24 — Step 07C-3 Closure / User Validation

- **Phase / Step:** 02 / 07C-3.
- **Scope:** documentation, evidence retention, capability-status promotion, session handoff, time ledger and checksums only.
- **Approval:** User reviewed the successful final 07C-3 evidence and explicitly approved closure. Exact approval timestamp was not independently captured and is not invented.
- **Quality evidence:** `quality-gate-20260930-133008.txt` — Release x64 build PASS; 0 warnings / 0 errors; governed tests PASS; coverage/local gates PASS; exit code 0.
- **Live evidence:** `api-capability-component-properties-20260930-133403.txt` — active Assembly context; known model `KA-PART-1`; entity ID 4 matched `cmBody` through occurrence enumeration.
- **U13:** VERIFIED. Part-model and assembly-context named lookups both returned `cmAttString` / `KNOWN_ANSWER_07C3`. Blank returned `IAttribute.Name` is retained as observed runtime behavior and is not used as an equality requirement.
- **U15:** VERIFIED for approved scope. Both BOM filters exported CSVs; each had a Material column and one `KA-PART-1` known-answer row with `Material=1.2738`. Row-count difference is not interpreted here.
- **U14/U17:** unchanged evidence-backed limitations. U16/07C-4 untouched.
- **Safety:** no-mutation file state UNCHANGED and model-folder listing UNCHANGED.
- **Boundary:** no production `src/**`, Plugin, verifier runtime, setup-helper, test, configuration, installer, CR/SA or model behavior change.
- **Status:** STEP 07C-3 CLOSED / USER VALIDATED.

## 2026-09-30 — Version 0.20.25 — Step 07C-4 U16 Hidden-State Verification Preparation

- **Phase / Step:** 02 / 07C-4.
- **Change ID:** PH02-ST07C4-U16-HIDDEN-STATE-PREP.
- **Approval:** User explicitly approved beginning 07C-4, approved the amended conditions separating occurrence-hidden from body-hidden semantics and BOM filtering, completed the separate known-answer model preparation, then approved the narrow diagnostic preparation. Exact approval timestamps are not independently captured and are not invented.
- **Requirement / Feature:** U16 / CR-11 FR-021 read-only hidden/visibility-state capability verification.
- **Known-answer model:** finalized copy `KA-ASM-1-U16-HiddenBody-Control`, preserving `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, suppressed `Block_B`, and adding visible `Visible_Component_With_Hidden_Body` with hidden `Hidden_Body_Control` plus visible `Visible_Anchor_Body`. Original baseline preserved.
- **Reason:** prior hidden-state verifier could read body `Show` candidates and export both BOM filters, but it did not provide enough evidence to distinguish occurrence-hidden from body-hidden semantics or identify BOM membership differences.
- **Implementation:** `HiddenStateCandidateVerification` now enumerates occurrence-reached entities through `IAssInstance.GetAllEntities()`, records occurrence title/suppression/body counts, maps bodies into assembly context, and reads only `ICimEntity.Show`. It exports both BOM filters, records each CSV membership row, and emits exact no-filtering-only / visible-only row-set differences. Semantics remain explicitly unassigned in code.
- **API basis:** retained 07A reflection evidence records `ICimEntity.Show` as `Int32` getter/setter; this verifier invokes getter only. `IBOM.Export` and both filter enum values were already verified in 07C-3.
- **Stopping rule:** one governed live run. Classify `Show` separately for occurrence-hidden and body-hidden controls, and classify the BOM route separately. If neither candidate discriminates the known hidden occurrence, FR-021 hidden support remains BLOCKED pending Cimatron guidance.
- **Files changed:** development-only verifier version/source plus architecture/source-contract test, version/changelog/history/capability documentation, session handoff, time ledger and checksum manifest.
- **Production impact:** none; `src/**`, Plugin, configuration, installer and customer behavior unchanged.
- **Validation:** AWAITING USER 0.20.25 QUALITY GATE + SINGLE GOVERNED LIVE RUN. Agent did not build/test/run Cimatron and claims no PASS.

## 2026-09-30 — Version 0.20.26 — Step 07C-4 BOM Read-Error Corrective

- **Phase / Step:** 02 / 07C-4.
- **Change ID:** PH02-ST07C4-BOM-READ-ERROR-CORRECTIVE.
- **Approval:** User explicitly approved the narrow corrective after supplying the corrected-model runtime evidence. Exact approval timestamp was not independently captured and is not invented.
- **Entering quality evidence:** `quality-gate-20260930-154440.txt` validates 0.20.25 with Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage/local quality gates PASS, exit code 0.
- **Entering runtime evidence:** `api-capability-hidden-state-candidates-20260930-172746.txt` against the corrected single-Part hidden-body model. `Visible_Component_With_Hidden_Body` is one unsuppressed occurrence with three bodies; two returned `Show.GET=1` and one returned `Show.GET=0`. Hidden-not-suppressed `Known_Pocket_Body` returned `Show.GET=1`. This verifies `ICimEntity.Show` as body/entity visibility evidence, not occurrence-hidden evidence.
- **Observed blocker:** `IAssemblyModel.GetBomManager()` returned COM `E_FAIL` (`0x80004005`) before the BOM filter stage, while no-mutation evidence remained `UNCHANGED`. Therefore the corrected-model `cmVisibleOnly` route remains unresolved.
- **Corrective:** `HiddenStateCandidateVerification` now uses `VerificationRuntimeContext.TryObserve` for `GetBomManager()`. On failure it records the existing `READ_ERROR`, emits `BOM.Stage: SKIPPED_AFTER_READ_ERROR`, keeps BOM semantics unassigned, and proceeds to the final stopping-rule/no-mutation evidence.
- **Regression guard:** architecture source-contract test now requires the non-fatal `TryObserve("GetBomManager"...)` path and explicit skipped-after-read-error evidence marker.
- **Production impact:** none. No `src/**`, Plugin, configuration, installer, CR/SA behavior, or model behavior changed.
- **AI execution boundary:** agent did not build, run tests/coverage, or execute Cimatron.
- **Validation:** AWAITING USER 0.20.26 QUALITY GATE + CONTROLLED LIVE RETRY. U16 `Show` semantics are verified; FR-021 BOM route remains pending runtime confirmation.


## 2026-09-30 — Version 0.20.27 — Step 07C-4 Closure / User Validation

- **Phase / Step:** 02 / 07C-4.
- **Scope:** closure documentation, evidence retention, capability-status promotion, session handoff, time ledger and checksums only.
- **Approval:** user reviewed the final 0.20.26 runtime classification and explicitly approved closure. Exact approval timestamp was not independently captured and is not invented.
- **Quality evidence:** `quality-gate-20260930-173544.txt` — Release x64 build PASS, 0 warnings / 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage/local quality gates PASS, exit code 0. The preceding `quality-gate-20260930-173441.txt` attempt was blocked only because `CimatronE.exe` was still running.
- **Final live evidence:** `api-capability-hidden-state-candidates-20260930-173818.txt` on corrected `KA-ASM-1-U16-HiddenBody-Control`.
- **Body/entity semantics:** visible bodies returned `Show.GET=1`; one deliberately hidden body inside the visible unsuppressed control occurrence returned `Show.GET=0`.
- **Occurrence semantics:** hidden-not-suppressed `Known_Pocket_Body` returned `Show.GET=1`; therefore `ICimEntity.Show` is not an occurrence-hidden getter.
- **BOM route:** `cmNoFiltering` included `Known_Pocket_Body`; `cmVisibleOnly` excluded it. `Visible_Component_With_Hidden_Body` remained in both filters despite containing a hidden body. This verifies BOM visibility filtering as the read-only candidate route for hidden component/occurrence detection required by CR-11 FR-021.
- **Safety:** final no-mutation evidence `UNCHANGED`.
- **Capability classification:** U16 VERIFIED for the approved 07C-4 scope. Step 08 in-process confirmation remains required before production promotion.
- **Boundary:** no production `src/**`, Plugin, configuration, installer, CR/SA behavior, runtime diagnostic code, or known-answer model behavior changed in this closure package.
- **Status:** STEP 07C-4 CLOSED / USER VALIDATED.

## 2026-10-01 — Version 0.20.28 — Step 07D Verification Register and Promotion Recommendations

- **Phase / Step:** 02 / 07D.
- **Change ID:** PH02-ST07D-VERIFICATION-REGISTER-RECOMMENDATIONS.
- **Change Type:** DOCUMENTATION / GOVERNANCE / PROMOTION-GATE FINALIZATION.
- **Approval:** User explicitly approved proceeding with Step 07D after confirming that 07D had not yet been formally closed. Exact approval timestamp was not independently captured and is not invented.
- **Scope:** finalize evidence-backed Step 07 statuses, define the Step 08 eligibility whitelist, exclude non-VERIFIED capabilities from production-promotion consideration, retain Step 06 deferred findings, and update handoff/version/history/time/checksum records only.
- **Eligibility rule:** only a capability with final Step 07 status `VERIFIED` may enter Step 08 in-process confirmation and later production-port / first-CR-slice consideration. Step 08 confirmation remains mandatory before any production use.
- **Eligible:** U1, U3, U4, U5, U6, U7, U8, U9, U10, U12, U13, U15, U16.
- **Not eligible:** U2 and U11 remain `PARTIALLY VERIFIED`; U14 remains `NOT AVAILABLE`; U17 remains `NOT AVAILABLE FROM RETAINED 07A EVIDENCE`.
- **Status discipline:** no `DOC-MISMATCH` or `BLOCKED` classification is introduced without evidence supporting that classification.
- **Step 06 carry-forward:** `ST06-DF-01` through `ST06-DF-06` remain `DEFERRED`; no item is resolved, accepted or superseded by 07D.
- **Production impact:** none. No production `src/**`, Plugin, configuration, installer, diagnostic runtime, test, CR/SA behavior, or model behavior changed.
- **AI execution boundary:** no build, tests, coverage, static analysis or Cimatron runtime execution is performed or claimed by the agent. This is a documentation/governance package based on already user-validated Step 07 evidence.
- **Status:** IMPLEMENTATION PREPARED / AWAITING USER REVIEW. Step 08 is not started.

---

## 2026-10-02 — 0.23.0 — Phase 02 Step 09 — CR-04 Slice 1 Domain Rules

**Change ID:** PH02-ST09-CR04-SLICE1-DOMAIN  
**Change Type:** IMPLEMENTATION / TEST / DOCUMENTATION  
**Requirement / Feature:** CR-04 — Steel Grade Design-Order Validation

### Reason

Implement the user-approved Slice 1 pure-Domain rules from CR-04 Implementation Specification v1.4 before any Application or Cimatron adapter work.

### Files added

- `src/CimatronCustomization.Domain/SteelGradeRepresentation.cs`
- `src/CimatronCustomization.Domain/SteelGradeComparisonPolicy.cs`
- `src/CimatronCustomization.Domain/SteelGradeNormalizer.cs`
- `src/CimatronCustomization.Domain/NormalizedSteelGrade.cs`
- `src/CimatronCustomization.Domain/ComponentKeyNormalizer.cs`
- `src/CimatronCustomization.Domain/DesignOrderSteelGradeEntry.cs`
- `src/CimatronCustomization.Domain/CadComponentSteelGradeEvidence.cs`
- `src/CimatronCustomization.Domain/SteelGradeDesignOrderEvaluation.cs`
- `tests/CimatronCustomization.Domain.Tests/SteelGradeNormalizerTests.cs`
- `tests/CimatronCustomization.Domain.Tests/ComponentKeyNormalizerTests.cs`
- `tests/CimatronCustomization.Domain.Tests/SteelGradeDesignOrderEvaluationTests.cs`
- `docs/history/session-handoffs/phase-02-step-09-cr04-domain-rules-0.23.0.md`

### Existing files modified

- `src/CimatronCustomization.Domain/CimatronCustomization.Domain.csproj` — compile wiring for approved new Domain files.
- `tests/CimatronCustomization.Domain.Tests/CimatronCustomization.Domain.Tests.csproj` — compile wiring for approved new tests.
- `tests/CimatronCustomization.Domain.Tests/Program.cs` — registers the three new fixtures in the custom test runner; without this change the tests would compile but not execute.
- `src/CimatronCustomization.Domain/Properties/AssemblyInfo.cs` — changed production assembly metadata to `0.23.0.0`.
- `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md` — governed version/traceability records.
- `docs/time-tracking/PROJECT-TIMESHEET.csv` — authoritative engineering-time record.
- `CHECKSUMS.sha256` — regenerated package manifest.

### Previous behavior

The Domain layer contained no CR-04 steel-grade comparison model or evaluation logic.

### New behavior

Pure Domain code can normalize configured steel-grade representations, normalize component keys, validate Design-Order rows, evaluate supplied CAD steel-grade evidence, and create CR-04 findings with stable message prefixes. It performs no IO and has no Cimatron/Interop dependency.

### Provisional decisions implemented

- **D-08:** DO row without evaluated CAD component = `Failed`; grade-bearing CAD component missing from DO = `Warning`; CAD-only component with no grade is not reported.
- **D-14:** zero distinct grade values = missing, one = usable, more than one = ambiguous `Failed`; duplicate normalized DO key = `Error`.
- **D-16:** key + blank DO grade = `[DO_GRADE_MISSING]` `Error`; this remains provisional pending customer answer.

D-05/D-06 are represented as policy inputs rather than hard-coded customer defaults.

### C-02 Step 08B traceability note

The closed Step 08B live evidence involved two distinct execution correlations: the Result Report run with correlation prefix `ecc1f44b...` and the later production Highlight interaction with correlation prefix `508db3e5...`. The 0.22.2 closure handoff described one governed live rerun plus the separate Highlight evidence but did not record both correlations explicitly. CR-04 requires every execution/highlight correlation to be recorded going forward. Full correlation values are not present in the 0.22.2 package text available to this implementation, so only the evidence-backed prefixes are recorded here rather than inventing missing characters.

### Tests added / changed

Added custom-runner tests for normalization, token mode, Strict numeric ambiguity, Werkstoff canonicalization, named grades, component-key behavior, all currently representable CR-04 finding conditions, provisional D-08/D-14/D-16 rules, repeated evidence grouping/reference de-duplication, and canonical result aggregation.

### Validation

**AWAITING USER EXECUTION.** The AI agent did not run Visual Studio build, unit tests, architecture tests, coverage, Roslyn/Sonar, or Cimatron.

The user must additionally inspect Cobertura class-level evidence for the new CR-04 Domain classes and demonstrate **>=95% line / >=90% branch** for the new rules; the existing package-level Domain 90% gate does not independently prove the CR-04 target.

### Cimatron version

Target baseline remains Cimatron 2026.0 SP2P1 (build 2026,0201,2064,662). No Cimatron API behavior is implemented or promoted in Slice 1.

### Known limitations / next action

Slice 2A remains mandatory for exact `FindInstance()`-equivalent safety traversal, self-instance observation/exclusion, natural `InstanceId` collisions and collision-frequency measurement, missing named string attribute semantics, wrong-type semantics, top-level highlight, suppressed-parent behavior, and assist-part enumeration before adapter approval.


---

## 2026-10-02 — 0.23.1 — Phase 02 Step 09 — CR-04 Slice 1 Warning/Coverage Corrective

**Change ID:** PH02-ST09-CR04-SLICE1-QG-COVERAGE-CORRECTIVE  
**Change Type:** CORRECTIVE / TEST / DOCUMENTATION

### Trigger evidence

User-supplied `quality-gate-20261002-230402.txt` showed Release x64/tests/coverage/local gate PASS and exit code 0, but 26 analyzer warnings. User-supplied `coverage.cobertura.xml` showed `CadComponentSteelGradeEvidence` at 91.67% line / 85.71% branch, below the approved CR-04 Slice 1 >=95% / >=90% class-level target.

### Corrective

- `SteelGradeDesignOrderEvaluation.CollectReferences` now returns its concrete `List<ModelEntityReference>` internally, removing CA1859 without changing externally visible behavior.
- Constant test arrays are reused through `static readonly` fields, removing CA1861 warnings without changing test semantics.
- Constructor exception tests explicitly retain created values through `GC.KeepAlive`, removing CA1806 while preserving the negative-path assertions.
- Added focused `CadComponentSteelGradeEvidence` tests covering null optional collections, original-key fallback, null entity-reference collection, and null item rejection.
- Domain assembly metadata advanced to `0.23.1.0` because production source changed.

### Boundary

No business finding rules, provisional D-08/D-14/D-16 decisions, Cimatron APIs, Application/DesignChecks/CimatronIntegration/Plugin code, configuration, tabular behavior, highlighter behavior or Slice 2A assumptions changed.

### Validation

**AWAITING USER CLEAN QUALITY GATE + UPDATED COBERTURA.** The agent did not run build, tests, coverage, analyzers or Cimatron.

## 2026-10-02 — Version 0.24.0 — CR-04 Slice 2A Capability Investigation

- **Phase / Step:** 02 / 10 (CR-04 Slice 2A).
- **Change ID:** PH02-ST10-CR04-SLICE2A-CAPABILITY-INVESTIGATION.
- **Change Type:** API-DISCOVERY / DEVELOPMENT-DIAGNOSTIC / TEST / DOCUMENTATION.
- **Approval:** User explicitly approved the Slice 2A plan and version 0.24.0 in this chat. Exact approval timestamp was not independently captured and is not invented.
- **Entering evidence:** user-supplied `quality-gate-20261002-232331.txt` showed Release x64 build PASS with 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gates PASS, Domain overall 99.74%, exit code 0. User-supplied `coverage.cobertura(1).xml` showed the new CR-04 production classes satisfy the approved >=95% line / >=90% branch target, including `CadComponentSteelGradeEvidence` 100% / 100%. Slice 1 / 0.23.1 is therefore CLOSED / USER VALIDATED.
- **Requirement / Feature:** CR-04 Steel Grade Verification Against Design Order — mandatory Slice 2A runtime capability investigation before adapter approval.
- **Reason:** D-15 occurrence-reference safety, self-instance behavior, missing/wrong-type attribute semantics and `GetAllEntities()` behavior must be measured in the real supported Cimatron environment rather than assumed.
- **Implementation:** added `Cr04CapabilityVerification.cs`. The diagnostic fails closed unless the active context is Assembly, the active model title exactly matches the requested `--model-title`, and at least one body returns the configured known `cmAttString` value. It traverses the exact existing highlighter search scope: depth >16 stops, every current instance participates, descent occurs only when `get_SubInstances(1,0)` is non-empty and the instance model is `cmAssembly`.
- **Self-instance rule:** an occurrence is marked self-instance only when its model PID equals the PID of the containing assembly being traversed. ID 3 is counted only as an observation; no ID is hard-coded. Self-instances remain in collision/uniqueness evidence but are skipped for component/body attribute evaluation.
- **Collision evidence:** all repeated `InstanceId` values are emitted with path/PID/self/suppressed members. The diagnostic separately reports the number and percentage of non-self occurrences with exact configured known-grade evidence whose `InstanceId` collides anywhere in the full traversal scope.
- **Attribute evidence:** for every non-self occurrence body reached through `IAssInstance.GetAllEntities()`, record known named `cmAttString`, a deliberately missing-name `cmAttString` control, and wrong-type `cmAttInteger` lookup using the known name. Null returns and exceptions are recorded separately; no status mapping is promoted in this slice. Per-occurrence body count and zero/one/multiple exact-known-value counts are recorded.
- **Read-only guard:** before/after `NoMutationEvidence` is captured and the run fails if a nominally successful diagnostic changes the active Assembly/persisted-file evidence. No Save/SaveAs/Close/Attach/create/mutation API is introduced.
- **Tests:** added `Cr04TraversalSafetyTests.cs` and registered it in the custom CimatronIntegration test runner. Tests protect the production highlighter source conditions, fake-tree scope equivalence, self-instance PID detection, suppressed-collision participation, and depth 16 behavior.
- **Files Changed:** new `tools/CimatronCustomization.ApiCapabilityVerification/Cr04CapabilityVerification.cs`; new `tests/CimatronCustomization.CimatronIntegrationTests/Cr04TraversalSafetyTests.cs`; modified verifier/test project files, custom test/verifier Program files, changed development AssemblyInfo files, `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, Slice 2A handoff, `CHECKSUMS.sha256`.
- **Production impact:** none. Existing production highlighter and all production `src/**` files are intentionally unchanged from 0.23.1.
- **API authority:** `IAssemblyModel.GetInstances()` is documented in the Cimatron API documentation. `IAssInstance.GetAllEntities()` remains an installed-Interop/runtime-evidence capability and is not promoted to documented SDK status.
- **AI execution boundary:** agent did not build, run tests/coverage, launch Cimatron, or claim runtime PASS.
- **Validation:** AWAITING USER 0.24.0 QUALITY GATE, then one controlled read-only `KA-ASM-CR04` Cimatron diagnostic run.
- **Known limitations / stop rule:** blank-string semantics can be concluded only if the prepared model actually contains a blank control for the requested name. Slice 3 remains blocked until runtime evidence is reviewed; unexpected behavior requires design/spec revision rather than silent mapping.

## 2026-10-02 — Version 0.24.1 — CR-04 Slice 2A Analyzer Warning Corrective

- **Phase / Step:** 02 / 10 (CR-04 Slice 2A).
- **Change ID:** PH02-ST10-CR04-SLICE2A-CA1859-CORRECTIVE.
- **Change Type:** BUGFIX / TEST / DOCUMENTATION.
- **Approval:** User explicitly approved the narrow warning-only corrective after supplying the 0.24.0 quality-gate capture. Exact approval timestamp was not independently captured and is not invented.
- **Entering evidence:** user-supplied `quality-gate-20261002-235449.txt` showed Release x64 build PASS, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS and exit code 0, but 3 `CA1859` warnings / 0 errors, all confined to `Cr04TraversalSafetyTests.cs`.
- **Root cause:** three private test-only members exposed broader collection abstractions (`IReadOnlyList<T>` / `IList<T>`) even though their implementation always creates/owns concrete `List<T>` instances, triggering CA1859.
- **Fix:** changed only `TraverseHighlighterEquivalent` and `TraverseCr04Safety` return types to `List<FakeObservation>` and `FakeAssembly.Instances` to `List<FakeInstance>`. Call-site behavior and test assertions remain unchanged.
- **Versioning:** changed CimatronIntegrationTests assembly metadata advanced from `0.24.0.0` to `0.24.1.0`. Development verifier metadata remains `0.24.0.0` because verifier code did not change.
- **Production impact:** none. No production `src/**` file changed; no verifier/runtime behavior changed.
- **Regression protection:** existing Slice 2A traversal-safety tests remain the protection; no new behavioral case was necessary because the correction is static-analysis/type-specific only.
- **AI execution boundary:** agent did not build, run tests/coverage, launch Cimatron, or claim the corrective PASS.
- **Validation:** AWAITING USER 0.24.1 CLEAN QUALITY GATE. Live Cimatron Slice 2A run remains blocked until the clean gate is reviewed.


## 2026-10-04 — Phase 02 Step 10 — CR-04 Slice 2A session handoff refresh (0.24.1)

- User supplied `quality-gate-20261003-000106.txt` for the 0.24.1 corrective.
- Workstation evidence: Release x64 build PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, exit code 0.
- Slice 2A is **not closed**; live Cimatron runtime evidence remains mandatory.
- User asked whether a new `KA-ASM-CR04` is required. Review of `Cr04CapabilityVerification` confirms `--model-title` is parameterized and the live verifier only requires at least one `cmBody` returning the configured known `cmAttString` value. Therefore the first run may use existing `KA-ASM-1` with the previously verified `STEP07_B1_TEST_ATTRIBUTE=KNOWN_ANSWER_07C3`. A dedicated `KA-ASM-CR04` remains optional for controlled blank/collision/edge cases if existing models are insufficient.
- Documentation/evidence/handoff refresh only. No source/test/verifier/runtime behavior change.

## 2026-10-04 — Version 0.24.2 — CR-04 Slice 2A MTA Attach Corrective

- **Phase / Step:** 02 / 10 (CR-04 Slice 2A).
- **Change ID:** PH02-ST10-CR04-SLICE2A-MTA-ATTACH-CORRECTIVE.
- **Change Type:** CORRECTIVE / DEVELOPMENT-DIAGNOSTIC / TEST / DOCUMENTATION.
- **Approval:** User explicitly approved the narrow CR-04 MTA-worker correction after the live verifier attach failure and successful MTA attach-only control. Exact approval timestamp was not independently captured and is not invented.
- **Trigger evidence:** the first `KA-ASM-1` `--verify-cr04-capabilities` run launched verifier 0.24.0 but failed in `VerificationRuntimeContext.Attach` at `interop.CimAppAccess.IAppAccess.GetApplication()` with COM `0x80040154` / `Class not registered`, before any CR-04 traversal/attribute/model evidence was collected. The follow-up existing attach-only diagnostic run from normal non-elevated PowerShell returned `ATTACH ONLY: PASS (MTA)`.
- **Correction:** `Program.Main` remains `[STAThread]`; only the `--verify-cr04-capabilities` route parses arguments and dispatches `Cr04CapabilityVerification.Run` onto a dedicated thread configured with `ApartmentState.MTA` before start. The CLI joins the worker synchronously. Worker exceptions are captured and rethrown with `ExceptionDispatchInfo` so the existing top-level Argument/Unexpected error boundary remains authoritative and no exception is swallowed.
- **Regression protection:** `Cr04TraversalSafetyTests` now protects the unchanged STA entry point plus the CR-04-only MTA route, MTA assignment, synchronous join, CR-04 execution on the worker and exception propagation. Existing traversal/self-instance/collision/depth tests remain unchanged.
- **Versioning:** development verifier and changed CimatronIntegrationTests assembly/file metadata advance to `0.24.2.0`; tool display version advances to `0.24.2`. Production assembly metadata is unchanged.
- **Production impact:** none. No `src/**`, Plugin, Domain rule, highlighter, customer configuration, installer, or model mutation behavior changed.
- **AI execution boundary:** agent prepared source/tests/docs/package only and did not build, execute tests/coverage, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER 0.24.2 CLEAN QUALITY GATE, then controlled live `KA-ASM-1` CR-04 capability retry. Slice 2A remains open.
## 2026-10-04 — Version 0.24.4 — CR-04 Slice 2A D-15 Occurrence-Identity Corrective

- **Phase / Step:** 02 / 10 (CR-04 Slice 2A).
- **Change ID:** PH02-ST10-CR04-SLICE2A-D15-OCCURRENCE-IDENTITY-CORRECTIVE.
- **Change Type:** CORRECTIVE / DEVELOPMENT-DIAGNOSTIC / TEST / DOCUMENTATION.
- **Approval:** User explicitly instructed not to continue trial-and-error, requested the proper solution, then explicitly approved the exact 0.24.4 corrective file scope. Exact approval timestamp was not independently captured and is not invented.
- **Entering evidence:** user-supplied 0.24.3 quality gate showed Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, coverage/local quality gates PASS and exit code 0. The subsequent controlled live `KA-ASM-1` evidence showed root ID `-1`, no reliable special self classification from root/parent evidence, the same real `InstanceId` collisions (`3`, `5`, `6`), known/missing/wrong-type attribute behavior, and `NoMutation.Result: PASS`. The evidence/banner still reported verifier `0.24.2`.
- **Root cause:** Slice 2A diagnostic code had introduced a provisional self-instance concept and later root/relation investigation even though approved CR-04 v1.4 D-15 defines safety by `InstanceId` uniqueness across the full unfiltered production-highlighter-equivalent traversal and does not require self-instance filtering. The extra classifier created an unnecessary runtime assumption and a false blocker.
- **Corrective design:** remove the self-instance dependency entirely. Every traversed occurrence participates in D-15 uniqueness. Every traversed occurrence is eligible for `GetAllEntities()` body evidence. Internal/synthetic occurrences with zero bodies naturally yield no grade evidence. No PID/title/ID/root-filename heuristic and no `GetRootInstance`/`AssRootInstance`/`AssParentInstance` relation is used to classify or filter business evidence.
- **Collision behavior:** repeated `InstanceId` detection remains unchanged in scope. Suppressed/excluded/zero-body occurrences still participate. `otherwiseValid` now means every occurrence with one or more exact configured known-attribute matches; no self exclusion exists.
- **Regression protection:** source-contract tests now forbid self/root classification hooks in `Cr04CapabilityVerification`, protect current tool banner `0.24.4`, and keep exact production-highlighter traversal, MTA dispatch, suppressed collision participation and depth-16 equivalence checks. Fake traversal proves PID equality does not remove any occurrence from safety/body-evidence eligibility.
- **Versioning:** development verifier and CimatronIntegrationTests assembly/file metadata advance to `0.24.4.0`; console tool display advances to `0.24.4`. Production assembly metadata is unchanged.
- **Production impact:** none. No `src/**`, Plugin, production highlighter, CR-04 production adapter/business rule, customer configuration, installer, or CAD model is changed.
- **API authority:** official SDK confirms `IAssemblyModel.GetInstances()` returns assembly instances and `IAssInstance.SubInstances` is the documented nested-instance route. `GetAssemblyEntity` maps a part entity into a specified assembly instance but does not create a documented self-instance classification requirement. The approved D-15 specification remains the controlling identity rule.
- **AI execution boundary:** agent prepared source/tests/docs/package only and did not build, execute tests/coverage/static analysis, launch Cimatron, or claim PASS.
- **Validation:** AWAITING USER 0.24.4 CLEAN QUALITY GATE, then one controlled read-only `KA-ASM-1` CR-04 capability rerun. Slice 2A remains open until user evidence is reviewed.


## 0.24.5 — 2026-10-04 — CR-04 Slice 2A Session Handoff

- User supplied and agent reviewed `quality-gate-20261004-163304.txt`: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gate PASS, exit code 0.
- User supplied and agent reviewed `api-capability-cr04-slice2a-20261004-164017.txt`: verifier version 0.24.4, no self-instance heuristic, full D-15 highlighter-equivalent uniqueness scope, expected attribute observations, repeated IDs 3/5/6, 33.33% unsafe otherwise-valid known-attribute occurrences, and `NoMutation.Result: PASS`.
- Recorded that CR-04 must not hard-code or infer a self-instance classifier from `InstanceId`, `Root.elt`, PID/title equality, `GetRootInstance`, `AssRootInstance` or `AssParentInstance`.
- Added a new-session handoff. Step 10 remains open pending requirement-by-requirement Slice 2A closure review; no new probe is authorized by this handoff.
- Per explicit user packaging instruction, generated `artifacts/**` console/runtime outputs and raw historical console/verifier `.txt` evidence files are excluded from the 0.24.5 delivery package. Validated workstation results are summarized in governed docs rather than redundantly copied into the ZIP.
- Documentation/governance/package cleanup only; no production `src/**`, verifier runtime, tests, configuration, installer or Cimatron model behavior changed.

## 2026-10-04 — 0.25.0 — CR-04 Post-Slice-2 Session Handoff

- **Phase / Step:** Phase 02 / Step 11 closed; return to remaining Slice 2A gate disposition before Slice 3.
- **Change Type:** DOCUMENTATION / GOVERNANCE / SESSION HANDOFF ONLY.
- **User request:** explicitly requested an updated ZIP with a session handoff and new-session prompt. Exact request receipt timestamp was not independently captured and is not invented.
- **Entering state:** CR-04 Slice 2 Application 0.25.0 is CLOSED / USER VALIDATED. User workstation quality gate started `2026-10-04T20:33:40.3027184+05:30`, completed `2026-10-04T20:34:09.4951348+05:30`, with Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, Application coverage 94.63%, coverage/local quality gates PASS and exit code 0.
- **Carry-forward:** Slice 2A remains open for top-level highlight confirmation, D-15(b) placement-specific mapping disposition, a genuine stored-as-non-string wrong-type control, collision-frequency measurement on a customer-like assembly, and genuine Assist Part evidence or an approved explicit disposition.
- **Assist Part:** remains NOT AVAILABLE / NOT VERIFIED. `CR04_Assist_Part_Control` is a normal part and is not evidence of a genuine Assist Part.
- **Suppression:** effective child suppression is preserved as live observed; the tested child reported suppressed while the parent diagnostic row itself reported suppressed=0, so no stronger parent-flag claim is made.
- **Packaging:** the earlier minimal-overlay missing-script incident remains classified as PACKAGING / RECOVERY, not a Slice 2 code failure. Future minimal ZIPs must not replace/delete the full repository.
- **Next step:** new session must prepare a precise remaining Slice 2A gate closure/disposition plan only. No code/model change and no Slice 3 work is approved by this handoff.

## 2026-10-04 — CR-04 Slice 2A Package 1 revised-plan disposition record (0.25.0)

**Scope:** documentation/governance only. The approved governing text is stored verbatim in `docs/history/session-handoffs/CR-04-SLICE-2A-REVISED-CLOSURE-PLAN-0.25.0.md`. Approval date is 2026-10-04; exact approval timestamp was not captured and is not invented.

The earlier five-gate closure plan is superseded. The following dispositions deliberately supersede the CR-04 v1.4 §8.3 / §17 Slice 2A pre-adapter list for these items; the v1.4 spec file itself is unchanged:

- D-15(b) placement-specific mapping — **DEFERRED**.
- Collision-frequency measurement — **MOVED TO SLICE 5** closure evidence.
- D-17 Assist Parts — **EXCLUDED-PROVISIONAL** pending customer answer.
- Wrong-type attribute semantics — **FAIL-SAFE RULE**; genuine same-name non-string evidence moves to Slice 3 adapter smoke, with adapter acceptance stopping for a user decision if the wrong-type query returns a conforming-looking value.

Slice 2A remains **OPEN — one gate remaining: top-level highlight (Package 2)**. Before Package 2 files are proposed, the full repository must be inspected for the two approved hard stops: existing top-level support in `CimatronViewportEntityHighlighter` and a D-15(a)-safe unique top-level KA-PART-1 `InstanceId`. No Package 2 implementation is authorized by this Package 1 record.

No production/runtime/test/model behavior changed. No build, tests, coverage, or Cimatron execution was required for this documentation-only package.

## 2026-10-04 — CR-04 Slice 2A Package 1A handoff consistency corrective (0.25.0)

- **Phase / Step:** Phase 02 / `10/2A`.
- **Change ID:** PH02-ST10-CR04-SLICE2A-PKG1A-HANDOFF-CORRECTIVE.
- **Change Type:** DOCUMENTATION / GOVERNANCE / HANDOFF CONSISTENCY CORRECTIVE ONLY.
- **Approval:** User explicitly approved the exact seven-path Package 1A file list before implementation. Exact approval timestamp was not independently captured and is not invented.
- **Reason:** Package 1 correctly persisted the revised Slice 2A dispositions and verbatim governing plan, but the new-session prompt, earlier handoff body and `VERSION.md` still exposed stale five-gate current-state instructions. Package 1A removes that session-to-session ambiguity without reopening any disposition.
- **Corrective scope:** exactly seven changed paths: new-session prompt, post-Slice-2 handoff, `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `PROJECT-TIMESHEET.csv`, and `CHECKSUMS.sha256`. All other packaged files are required byte-identical to Package 1.
- **Versioning:** **version deliberately not bumped**; Product Version remains `0.25.0` because this is documentation/governance-only corrective work with no product, source, test, tool, config or model change, consistent with the post-Slice-2 handoff and Package 1 precedent.
- **Current state after corrective:** Slice 2 CLOSED / USER VALIDATED; Slice 2A OPEN with one remaining gate, top-level highlight (Package 2). D-15(b) DEFERRED; collision-frequency MOVED TO SLICE 5; D-17 EXCLUDED-PROVISIONAL; wrong-type FAIL-SAFE RULE.
- **Package 2:** full repository required. First answer both governing hard stops from source/evidence; if either fails, STOP and report. No Package 2 implementation is authorized by this corrective.
- **Packaging:** `phase-02-step-11-cr04-slice-2a-package-1a-handoff-corrective-0.25.0.zip` is an overlay package and must not replace the full repository.
- **Runtime impact:** none. No build/test/Cimatron execution required for this documentation/governance-only corrective.

## 2026-10-04 — CR-04 Slice 2A Package 2 top-level highlight diagnostic — 0.26.0

- Package 1 (`phase-02-step-11-cr04-slice-2a-revised-plan-package-1-0.25.0.zip`) and Package 1A (`phase-02-step-11-cr04-slice-2a-package-1a-handoff-corrective-0.25.0.zip`) are **ACCEPTED / USER VALIDATED**. Exact acceptance timestamps were not captured; none were invented.
- Composed baseline in approved order: 0.24.4 full package → 0.25.0 implementation overlay → 0.25.0 closure → post-Slice-2 handoff → Package 1 → Package 1A. Baseline checks passed before edits.
- Hard stop (a) passed against `CimatronViewportEntityHighlighter.cs` SHA-256 `c048b330f856da970b9f66fa0c196509b1b61d163861dba6bfdd5112095ffaf9`: top-level occurrence resolution is supported by `FindInstance` at depth 0 over `assembly.GetInstances()`, followed by occurrence entity resolution and `GetAssemblyEntity`.
- Hard stop (b) accepted as historical feasibility evidence only. Runtime selection now traverses the live session, considers all highlighter-scope occurrences, keeps unsuppressed depth-0 `KA-PART-1` candidates with globally unique InstanceIds, and selects the lowest unique ID.
- Added the approved developer-only diagnostic and tests. The environment gate is evaluated when `FeatureComposition.CreateRegistry()` is called for a newly opened launcher; registration occurs only when `CIMATRON_DEV_ENABLE_CR04_SLICE2A_TOPLEVEL_HIGHLIGHT_DIAGNOSTIC` equals exactly `1`.
- C-03 preserved: `[TOPLEVEL_HIGHLIGHT_TARGET_READY]` is Passed only for target/body resolution and explicitly says Highlight is not confirmed; the Package 2 gate is closed only by user visual evidence.
- **BLOCKING CLIENT-PACKAGING OBLIGATION:** diagnostic registration, all eight diagnostic source files, the request script, and the two diagnostic test files MUST be removed under a separately approved change before any client package is built.
- Status: implementation complete; awaiting user workstation quality gate and then one live run. Stop on first failure; no retry/corrective without approval.


## 2026-10-04 — CR-04 Slice 2A Package 2 quality-gate corrective — 0.26.1

- **Trigger:** user workstation 0.26.0 quality gate stopped during Release x64 build with four CA1861 warnings and two compile errors: `IAssemblyModel.Title` and `ICimDocument.Path` were not members of the referenced Cimatron interop. No live Cimatron diagnostic was run.
- **Approval:** user explicitly approved the narrow API/analyzer corrective and requested console output to be saved as a `.txt` file. Exact approval timestamp was not independently captured and is not invented.
- **API verification:** authoritative Cimatron API documentation confirms `ICimDocument.Title` and `string ICimDocument.GetPath()`.
- **Production corrective:** active assembly title check now uses `document.Title`; document file-state path capture now uses `document.GetPath()`.
- **Test corrective:** repeated literal arrays in `TopLevelHighlightDiagnosticFeatureTests` are held in `static readonly` fields to eliminate the reported CA1861 findings while preserving scenarios.
- **Capture workflow:** existing `Invoke-And-Capture.ps1 -Task quality-gate` writes the complete console stream and exit code to `artifacts/console-captures/quality-gate-<timestamp>.txt`; package now carries the empty capture directory marker.
- **Version:** PATCH bump from 0.26.0 to 0.26.1 because this is a compatible corrective fix.
- **Validation:** AWAITING USER EXECUTION. Agent did not build, run tests/coverage, or execute Cimatron. Required next action is one captured user workstation quality gate with Cimatron closed. STOP on any failure. Only after a clean gate may the already-approved exactly-one live run occur.
- **Unchanged:** D-15(b) DEFERRED; collision-frequency MOVED TO SLICE 5; D-17 EXCLUDED-PROVISIONAL; wrong-type FAIL-SAFE RULE; Slice 3 BLOCKED; client-packaging diagnostic-removal obligation remains BLOCKING.


## 2026-10-05 — CR-04 Slice 2A Package 2 DesignChecks coverage corrective — 0.26.2

- **Symptom:** user workstation 0.26.1 quality gate passed Release x64 build (0 warnings / 0 errors) and all governed test suites, then failed the existing DesignChecks coverage gate at `92.48%` versus required `95%`.
- **Evidence:** user supplied the merged `coverage.cobertura.xml`; inspection showed `TopLevelHighlightDiagnosticFeature` static Definition initialization and constructor null guard were not exercised by the Package 2 feature fixture.
- **Root cause:** the Package 2 tests validated Execute success/fail-closed paths but did not access `Definition` or exercise the null-reader guard.
- **Approved fix:** add only focused tests for the governed feature metadata and constructor null guard. No runtime production behavior change is authorized.
- **Version:** PATCH bump from 0.26.1 to 0.26.2 under the compatible-corrective rule; production assembly/feature version metadata only is updated for version consistency.
- **Validation:** agent did not execute build/tests/coverage/Cimatron. User must run the captured workstation quality gate. Live diagnostic remains blocked until PASS.
- **Client packaging:** blocking removal obligation for Package 2 diagnostic registration, eight diagnostic source files, the request script and two diagnostic test files remains unchanged.


## 2026-10-05 — CR-04 Slice 2A Package 2 quality-gate validation and pre-run startup crash handoff — 0.26.2

- User supplied captured workstation quality-gate evidence `quality-gate-20261005-001015.txt`: started `2026-10-05T00:10:15.9618726+05:30`, completed `2026-10-05T00:10:56.3305423+05:30`, Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage collection/gate PASS, DesignChecks 98.33% >= 95%, local quality gate PASS, exit code 0.
- Package 2 quality gate is USER VALIDATED.
- The live top-level-highlight diagnostic did not execute. With the session diagnostic variable set to `1`, Cimatron exited before Feature Launcher.
- Windows evidence: matching `CimatronE.exe` / `ucrtbase.dll` / exception `0xc0000409` startup failures at `2026-10-05 00:19:29 +05:30` and `2026-10-05 00:20:26 +05:30`.
- User clarification preserved: first launch was an unexpected immediate exit and the user was unsure whether they caused it; second launch was a deliberate confirmation attempt. Do not classify these as two intentional governed diagnostic executions.
- `[TOPLEVEL_HIGHLIGHT_TARGET_READY]` not observed; Result Report/Highlight not reached; live viewport validation remains OPEN.
- No diagnostic-enabled retry, runtime corrective, Slice 3 work, or client-package diagnostic removal is authorized by this handoff.
- New-session context is AMBER. Recommended next decision, requiring explicit user approval, is one normal-startup control with the diagnostic variable absent.
- Runtime/console evidence files remain excluded from progressive ZIPs per project packaging direction; filenames/timestamps/conclusions are documented here and in the handoff.

## 2026-10-05 — 0.26.3 — CR-04 Slice 2A Package 2 request-file opt-in corrective

- **Approval:** user explicitly approved `0.26.3 corrective (request-file opt-in)` and then corrected the Plugin project assumption, explicitly authorizing exactly one `Compile Include="Diagnostics\TopLevelHighlightDiagnosticRequest.cs"` entry. Exact approval timestamp was not independently captured and is not invented.
- **Governing plan recovery:** user supplied the Package 1 plan file. Attached bytes were verified SHA-256 `6b6d3f9ca1c2c56bbce45a3b438e37b8a5baba25d4de917a37c5ae6ce7b9d320` and restored byte-identically at the governed path.
- **Startup evidence:** user-supplied Windows/Application/WER evidence records two 2026-10-05 pre-Feature-Launcher crashes with `ucrtbase.dll`, `0xc0000409`, offset `0xa527e`, no matching `CimatronCustomization*` module in the newest WER module list, and the same archived WER signature on 2026-09-24 before Package 2 existed. Normal startup later succeeded after PC restart with 0.26.2 deployed and the CR-04 diagnostic absent from the five-feature launcher. Start/exit timestamps were not captured.
- **Evidence conclusion:** transient workstation/Cimatron fault cleared by restart; root cause not established. Package 2 code and the historical environment-variable gate are not implicated. The live diagnostic has never executed; the single governed live run remains unused.
- **Opt-in corrective:** replaced the environment-variable gate with a one-shot request file consumed by `TopLevelHighlightDiagnosticRequest.TryConsume()`. The request is atomically moved before reading, valid only for `Version=0.26.3` and `RequestedUtc` in exact `O` format aged 0–30 minutes, then deleted in `finally`. Invalid/stale/read-failure requests return false and show one warning that the diagnostic is not registered.
- **Request tool:** added `tools/Request-TopLevelHighlightDiagnostic.ps1`, which creates the two-line request in UTF-8 without BOM or cancels it; it never launches Cimatron and never manipulates environment variables.
- **Reader contract corrective:** all post-argument-check work is inside one outer try/catch; any exception returns Error `[TOPLEVEL_HIGHLIGHT_API_ERROR]` with no reference. The before-snapshot occurs immediately after active-document acquisition. Assembly title is read from `(assembly as IModel).Title`, compared `OrdinalIgnoreCase`, and mismatch evidence includes the observed title.
- **Mutation/feature contract:** introduced `TopLevelHighlightNoMutationState` with `NotEvaluated`, `Unchanged`, `Changed`; mutation change is Error `[TOPLEVEL_HIGHLIGHT_MUTATION_DETECTED]`. The feature promotes Passed only for `Passed + reference + Unchanged`; all other shapes become Error `[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR]` with no reference. Evidence is `PASS`, `CHANGED`, or `NOT_EVALUATED`.
- **Tests/guards:** existing feature-test file gains Passed+null-reference, Passed+NotEvaluated, and Changed cases. Architecture guards ignore whitespace for the exact `TryConsume` registration, prohibit the retired env-var name from `src/`/`tools/`, restrict the request filename to its request class/script, forbid `GetRootInstance`, `AssRootInstance`, `AssParentInstance`, `ISelection`, `IViewportEntityHighlighter` in the reader, prohibit the four known-answer literals in reader/selector, require the explicit Plugin Compile entry, and retain the protected highlighter SHA-256 pin.
- **Client packaging:** BLOCKED until registration, all eight diagnostic source files (existing seven plus the request class), the request script, and the two diagnostic test files are removed under separate approval.
- **Versioning:** Product `0.26.3`; Plugin, CimatronIntegration, Application and DesignChecks assembly/file versions `0.26.3.0`; no other assembly metadata bump.
- **AI execution boundary:** agent prepared source/tests/docs/package only. It did not build, run tests/coverage, deploy, execute the request script, or run Cimatron. No live-gate PASS is claimed.
## 2026-10-05 — 0.26.3 — CA1806 test-only quality-gate corrective

- **Evidence:** user supplied `quality-gate-20261005-015308.txt`. The captured run started `2026-10-05T01:53:08.0091018+05:30` and completed `2026-10-05T01:53:42.5021339+05:30`; Release x64 build, architecture/domain/application/Cimatron Integration/infrastructure tests, coverage gate and local quality gate all reported PASS with exit code 0, but the Release build reported 1 warning / 0 errors: CA1806 in `TopLevelHighlightDiagnosticFeatureTests.cs`. Under the project 0-warning acceptance rule, the governed quality gate was not accepted.
- **Approval:** user explicitly approved the narrow CA1806 corrective. Exact approval timestamp was not independently captured and is not invented.
- **Corrective:** changed only the existing diagnostic feature-test file so the intentionally created `TopLevelHighlightDiagnosticFeature(null)` instance is consumed through `GC.KeepAlive(...)`, preserving the constructor-guard assertion while removing CA1806.
- **Scope:** production code, request-file gate, Plugin project file, assembly versions and diagnostic runtime behavior are unchanged. Version remains `0.26.3`.
- **Execution boundary:** agent did not build, run tests/coverage or launch Cimatron. A new clean captured workstation quality gate is required before the single governed live run.



## 2026-10-05 — Version 0.26.4 — CR-04 Slice 2A Package 2 Temporary-Highlight Restoration Corrective

- **Phase / Step:** 02 / 10/2A.
- **Change ID:** PH02-ST10-CR04-SLICE2A-PKG2-HIGHLIGHT-RESTORE-CORRECTIVE.
- **Change Type:** PRODUCTION CORRECTIVE / TEST / DOCUMENTATION.
- **Entering evidence:** clean 0.26.3 workstation quality gate had already passed. The first governed live run used the wrong `KA-ASM-1` fixture and was classified as invalid-fixture execution. A separately approved replacement run used `Model\KA-ASM-1-Step07C4-U16-single-part-corrected\CR11_BASELINE\KA-ASM-1.elt`, correlation ID `e9a94f01c46c4dadb0e323d0ef18f3a9`. Result Report was Passed with `[TOPLEVEL_HIGHLIGHT_TARGET_READY]`; the intended top-level `KA-PART-1` highlight and absence of unrelated highlighting were visually confirmed; programmatic no-mutation passed and the assembly remained unmodified. Temporary highlight restoration after report close was NO, so Package 2 was not closed.
- **Read-only investigation root cause:** `FindingReportWindow.HighlightSelectedFinding()` called only `viewportEntityHighlighter.Highlight(...)`; `FindingReportWindow`/`FeatureLauncherWindow` close-dispose flow performed no restore. `CimatronViewportEntityHighlighter.Highlight()` replaced `ISelection.Selection` with the temporary entity list and retained no previous selection.
- **Approval boundary:** user first approved the exact corrective source/test/governance scope. Before editing, version consistency analysis found the governed request class, diagnostic feature traceability, and request script hard-coded `0.26.3`; work stopped and the user separately approved those three additional existing files.
- **Application contract:** `IViewportEntityHighlighter` gains `RestoreSelection()`.
- **Cimatron adapter corrective:** the protected `CimatronViewportEntityHighlighter.cs` is modified only for temporary selection lifecycle support. It captures the original `ISelection.Selection` immediately before the first temporary highlight assignment, retains that capture across subsequent highlights in the same Result Report, and restores it through the same verified `ISelection.Selection` boundary. If the captured selection was null/empty, restoration assigns a new empty `CimEntityList`. The approved `FindInstance` depth-16 traversal, `get_SubInstances(1,0)` condition, occurrence entity lookup and `GetAssemblyEntity` mapping are unchanged.
- **Plugin lifecycle corrective:** `FindingReportWindow.OnFormClosed` calls `RestoreSelection()` in a try/finally that still invokes `base.OnFormClosed(e)`. Restore exceptions are not swallowed.
- **Regression protection:** `Cr04TraversalSafetyTests` now requires the capture/restore fragments and report-close wiring. `ArchitectureBoundaryTests` removes the historical byte-identical SHA-256 pin and replaces it with narrow semantic guards preserving the verified traversal/mapping/highlight/restore contract.
- **Version alignment:** one-shot request consumer, diagnostic feature traceability, and request script use `0.26.4`; Plugin, CimatronIntegration, Application and DesignChecks assembly/file versions are `0.26.4.0`.
- **Protected/unmodified behavior:** no CR-04 rule decisions reopened; no diagnostic reader traversal, target selector, no-mutation logic, feature registration, Cimatron model, Design Order business logic, D-15 disposition, D-17 disposition, wrong-type disposition, or Slice 3 work is changed.
- **AI execution boundary:** under `AGENTS.md`, the agent did not execute build/tests/coverage, deployment, request script, or Cimatron validation.
- **User workstation quality-gate evidence:** `quality-gate-20261005-025934.txt` started `2026-10-05T02:59:34.0925662+05:30` and completed `2026-10-05T03:00:32.5420808+05:30`; Release x64 build PASS, `0` warnings / `0` errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage collection/gate PASS, local quality gate PASS, exit code `0`.
- **Governed live validation:** on the approved `KA-ASM-1` fixture, the user confirmed `[TOPLEVEL_HIGHLIGHT_TARGET_READY]`, intended top-level `KA-PART-1` highlighted = YES, unrelated occurrence highlighted = NO, highlight restored/cleared after Result Report close = YES, and assembly remained unmodified = YES.
- **Closure:** Package 2 corrective acceptance is satisfied. User explicitly approved closure; receipt timestamp `2026-10-05T03:14:41+05:30`. Status: **CLOSED / USER VALIDATED**.
- **Execution boundary:** the AI agent did not execute build/tests/coverage, deployment, request script, or Cimatron validation; all validation evidence is user supplied.

## 2026-10-05 — Version 0.26.4 — CR-04 Slice 2A to Slice 3 Planning Session Handoff

- **Phase / Step:** Phase 02 / current CR-04 Slice 2A closure handoff into Slice 3 planning.
- **Change ID:** PH02-ST10-CR04-SLICE2A-TO-SLICE3-PLANNING-HANDOFF.
- **Change Type:** DOCUMENTATION / GOVERNANCE / SESSION HANDOFF.
- **User request:** user explicitly requested a session-handoff ZIP and prompt for the next chat after Slice 2A Package 2 was closed/user validated. Exact request timestamp seconds were not independently captured and are not invented.
- **Baseline:** `phase-02-step-10-cr04-slice-2a-package-2-highlight-restore-closure-0.26.4.zip`.
- **Current state carried forward:** 0.26.4 workstation quality gate PASS with 0 warnings / 0 errors, all governed suites and coverage/local gate PASS, exit 0; governed live validation confirmed target highlight YES, unrelated highlight NO, Result Report close restoration YES, assembly unmodified YES.
- **Planning boundary:** Slice 3 implementation is not approved. The new session must first read `AGENTS.md`, governing CR-04 materials and current code, then present the exact implementation plan/new-file list/existing-file list/risks/tests/quality gate/live smoke plan and wait for explicit approval.
- **Mandatory Slice 3 concern:** production Cimatron body-attribute adapter planning plus genuine same-name stored-as-non-string wrong-type smoke under the approved FAIL-SAFE RULE. If a genuine wrong-type value queried as `cmAttString` appears conforming, adapter acceptance stops for a user decision.
- **Decisions preserved:** D-15(a) full-scope uniqueness; D-15(b) DEFERRED; collision-frequency MOVED TO SLICE 5; D-17 EXCLUDED-PROVISIONAL; first-match fallback prohibited.
- **Client packaging:** Package 2 developer diagnostic/request-script cleanup remains separately approved-only and blocking before any client package.
- **Files added:** new handoff Markdown and new-session prompt text.
- **Files modified:** `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, and regenerated `CHECKSUMS.sha256`.
- **Production impact:** none. No `src/**`, tests, tools, configuration, model, or installer behavior changed.
- **AI execution boundary:** agent did not build, run tests/coverage, deploy, execute request scripts, or launch Cimatron.
- **Context:** AMBER — begin the next implementation step only in the new session.



## 2026-10-05 — Version 0.27.0 — CR-04 Slice 3 Production Cimatron Body-Attribute Adapter

- **Phase / Step:** 02 / CR-04 Slice 3.
- **Approval boundary:** user explicitly approved the previously presented read-only Slice 3 plan before implementation. Exact approval timestamp seconds were not independently captured and are not invented.
- **Production adapter:** adds `CimatronAssemblyBodyAttributeReader` behind the existing `IAssemblyBodyAttributeReader`; no Application contract expansion was required.
- **Traversal:** full highlighter-equivalent scope, `GetInstances()`, current occurrence retained before descent, `get_SubInstances(1, 0)`, assembly-only descent, depth stop 16. Suppressed and otherwise business-irrelevant occurrences remain in the snapshot for D-15; inherited suppression is propagated without pre-filtering.
- **Body/attribute route:** occurrence `GetAllEntities()` -> `cmBody` -> exact named `GetAttribute(cmAttString, requestedName)`. `GetAllEntities()` remains installed-Interop + governed runtime evidence only and is not claimed as authoritative SDK-documented. Returned `IAttribute.Name` is not consulted.
- **Fail-safe wrong-type policy:** null is provisional `Absent`; unexpected returned type, unreadable value, conversion failure, or API/runtime exception becomes `ReadError`; production never probes alternate attribute types and never produces `UnsupportedType`.
- **Reference compatibility:** body references retain the existing `entity|InstanceId|base64(ModelPID)|EntityId` current-session format consumed by the validated highlighter. D-15(a) remains in Application; D-15(b) remains deferred.
- **Development-only genuine control:** `KnownAnswerModelSetup` gains an explicit wrong-type mode restricted to disposable model `KA-PART-1-CR04-WRONG-TYPE`, entity 4, `CR04_WRONG_TYPE_CONTROL=2738`, created/read back as `cmAttInteger`; no overwrite and no autosave. The helper also records how an immediate `cmAttString` query presents the stored control, but this is setup evidence only.
- **Live adapter smoke:** the existing CimatronIntegration test executable gains an environment-gated smoke inside the approved `Cr04TraversalSafetyTests.cs` file. With opt-in set, it calls the real production adapter, targets the controlled model/body, records Present/Absent/ReadError counts, verifies active-document modified/file timestamp/length equivalence, and hard-stops if any controlled body is reported `Present`.
- **Architecture guards:** require the approved traversal/body/string-lookup/reference/suppression contracts and prohibit `GetEntityById`, `GetAttributes`, `cmAttInteger` probing, mutation calls, and unapproved placement APIs in production adapter source. The existing highlighter is not modified.
- **Versioning:** CimatronIntegration and KnownAnswerModelSetup assembly/file metadata are `0.27.0.0`; product version is `0.27.0`.
- **Excluded:** no FeatureComposition registration, DesignChecks CR-04 feature, production config, BOM route, D-09(b), D-15(b), collision-frequency measurement, Assist Part investigation, highlighter change, 08B refactor, customer real-sample run, or Package-2 diagnostic cleanup.
- **Validation boundary:** agent did not execute build/tests/coverage, deployment, setup utility, or Cimatron. `0.27.0` is **AWAITING USER WORKSTATION QUALITY GATE + CONTROLLED LIVE WRONG-TYPE ADAPTER SMOKE**; no PASS or closure is claimed.


## 2026-10-05 — CR-04 Slice 3 helper evidence version-stamp corrective — 0.27.4

- **Trigger:** user workstation `quality-gate-20261005-121959.txt` for 0.27.3 passed Release x64 with 0 warnings / 0 errors, all governed suites, coverage/local gates and exit code 0. The subsequent controlled helper rerun produced the expected genuine wrong-type evidence but displayed stale `ToolVersion: 0.27.0`.
- **Live evidence preserved:** at `2026-10-05T12:23:23.7867285+05:30`, body entity 4 on disposable `KA-PART-1-CR04-WRONG-TYPE` read back `CR04_WRONG_TYPE_CONTROL` as `cmAttInteger=2738`; deliberate `cmAttString` query returned `READ_ERROR`, HRESULT `0x80004005`; result `WRONG_TYPE_CONTROL_ATTACHED_AND_READ_BACK`; autosave disabled.
- **Approval:** user explicitly approved the narrow version-stamp corrective. Exact approval timestamp seconds were not independently captured and are not invented.
- **Corrective:** update only the development helper `ToolVersion` evidence constant and helper assembly/file version to `0.27.4`; production adapter/runtime semantics remain unchanged.
- **Validation:** AWAITING USER EXECUTION. Agent did not build, run tests/coverage, execute the helper, or run Cimatron. Required next action is one clean captured workstation quality gate, then one helper rerun to obtain version-consistent evidence.
- **Scope unchanged:** D-15(b) remains deferred; collision-frequency measurement remains Slice 5; D-17 remains EXCLUDED-PROVISIONAL; Package-2 client-packaging diagnostic-removal obligation remains blocking.

## 2026-10-05 — CR-04 Slice 3 smoke existing-session attach corrective — 0.27.5

- **Trigger:** user workstation `quality-gate-20261005-122845.txt` for 0.27.4 passed Release x64 with 0 warnings / 0 errors, all governed suites, coverage/local gates and exit code 0. The subsequent helper rerun at `2026-10-05T12:57:02.5871775+05:30` produced version-consistent genuine wrong-type evidence (`ToolVersion: 0.27.4`, `cmAttInteger=2738`, `cmAttString` `READ_ERROR`, HRESULT `0x80004005`).
- **Live smoke failure:** with the required disposable assembly already open, the first production-adapter smoke command launched a second Cimatron instance. Inspection isolated the launch to the test-only `MutationObservation.Capture()` pre-check, which used `interop.CimAppAccess.AppAccess().GetApplication()`; the production adapter itself uses `interop.CimServicesAPI.CimApplicationProvider`. The smoke attempt is invalid and no adapter PASS is claimed.
- **Approval:** user explicitly approved the narrow smoke-harness attach-route corrective. Exact approval timestamp seconds were not independently captured and are not invented.
- **Corrective:** `Cr04TraversalSafetyTests.cs` now obtains the live application through `interop.CimServicesAPI.CimApplicationProvider().GetApplication()`; the CimatronIntegrationTests project direct interop reference is switched from `interop.CimAppAccess` to `interop.CimServicesAPI` so the test source compiles against that verified provider.
- **Production impact:** none. No `src/**` file is changed; production adapter traversal, attribute read/classification, current-session entity references, and no-mutation behavior are unchanged.
- **Validation:** AWAITING USER EXECUTION. Agent did not build, run tests/coverage, deploy, or run Cimatron. Required next action is one clean captured workstation quality gate, then one re-run of the controlled adapter smoke with the original disposable assembly active.
- **Scope unchanged:** D-15(b) remains deferred; collision-frequency measurement remains Slice 5; D-17 remains EXCLUDED-PROVISIONAL; Package-2 client-packaging diagnostic-removal obligation remains blocking.


## 0.27.5 — 2026-10-05 — Slice 3 in-process smoke planning session handoff

- User workstation `quality-gate-20261005-132327.txt` accepted clean: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, completed `2026-10-05T13:24:26.6154143+05:30`, exit code 0.
- The subsequent 0.27.5 external CimatronIntegrationTests smoke failed before adapter validation with `COMException 0x80040154 / REGDB_E_CLASSNOTREG` while instantiating `CimServicesAPI.CimApplicationProvider` in `MutationObservation.Capture()`. This run is INVALID smoke-harness evidence, not a production-adapter failure.
- Authoritative Cimatron API documentation `general/startingcsharpapp.md` was consulted: EXE projects are documented to use `CimAppAccess.AppAccess` for the running active application; class/in-process projects are documented to use `CimServicesAPI.CimApplicationProvider`.
- Because the earlier documented EXE/AppAccess route launched a second Cimatron instance on this workstation and the 0.27.5 standalone CimApplicationProvider route is not the documented EXE model, the recommended next direction is a developer-only in-process plugin smoke using the already-running Cimatron application context.
- No in-process smoke implementation is included in this handoff. The next session must inspect/verify the exact plugin route, present a file-by-file plan, and obtain explicit user approval before editing.
- Documentation/governance/checksum/package-only handoff. Product/code baseline remains 0.27.5. Agent did not build/test/run coverage/deploy/Cimatron.


## 2026-10-05 — CR-04 Slice 3 Plugin Domain-reference build corrective — 0.27.7

- **Trigger:** user workstation `quality-gate-20261005-140642.txt` failed Release x64 compilation before tests with three CS0012 errors because `Cr04Slice3WrongTypeInProcessSmoke.cs` consumes Domain type `ModelEntityReference` without a direct Plugin project reference to `CimatronCustomization.Domain`; gate exit code 1.
- **Corrective:** add only the missing direct Domain ProjectReference to `CimatronCustomization.Plugin.csproj`; advance Plugin assembly/file metadata to `0.27.7.0`.
- **Runtime impact:** none beyond corrected build wiring. In-process smoke logic and production `CimatronAssemblyBodyAttributeReader` source are unchanged; CR-04 business semantics/traversal/wrong-type mapping/config/BOM/D-09(b)/D-15(b)/Assist Part/highlighter/client-cleanup scope remain unchanged.
- **Validation:** AWAITING USER EXECUTION. No PASS claimed; live smoke remains blocked until a clean quality gate.


## 0.30.0 — 2026-10-05 — D-02 controlled steel-grade evidence validated / session handoff

- Accepted user workstation `quality-gate-20261005-221151.txt`: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Recorded two safe failed helper attempts while the active document was still `cmAssembly`; both stopped before mutation.
- Recorded successful controlled helper execution at `2026-10-05T22:20:13.7867815+05:30` on standalone disposable `KA-PART-1-CR04-WRONG-TYPE`, entity/body `4`: attached `STEEL_GRADE=P-20-2311` as `cmAttString`, exact string value read back, `MutationPerformed: YES`, autosave disabled.
- User confirmed the disposable Part was manually saved. Exact chat receipt timestamp is not independently captured and is not invented.
- Accepted separate read-only capability evidence timestamped `2026-10-05T22:24:44.8894448+05:30`: exact `cmAttString` lookup found `P-20-2311` on occurrence `root/10:14`, body `4`; exactly one exact known-value occurrence; no string read errors; `NoMutation.Result: PASS`; assembly file timestamp and size unchanged.
- Recorded Cimatron API observation that returned attribute `Name` is blank even though exact named lookup succeeds.
- Recorded diagnostic wrong-type observation on the same body: exact same name queried as `cmAttInteger` returned value `144`. Production CR-04 must therefore continue exact `cmAttString` lookup only and must not probe/fallback to alternate types.
- D-02 body-level string evidence is now VERIFIED for the current direction: configured attribute name `STEEL_GRADE`, type `cmAttString`.
- Next governed step is a narrow read-only in-process smoke extension for the actual production `CimatronAssemblyBodyAttributeReader`; current smoke remains hard-coded to the earlier wrong-type control.
- Added cumulative post-validation session handoff and next-session prompt. Raw workstation/runtime evidence remains excluded from the ZIP. No production `src/**`, test/tool logic, project/config, or requirement-specification changes were made for this documentation-only handoff.


## 0.31.0 — 2026-10-05 — CR-04 v1.5 Slice 1 Form reader implementation

- **Approval:** user approved the exact v1.5 implementation plan before source edits. User-message time is available only to minute precision (`2026-10-05T23:35+05:30`); seconds are not invented. Agent implementation work timestamp was observed at `2026-10-05T23:46:16+05:30`.
- **Scope:** Slice 1 only. Added Form-reader Application contracts, Infrastructure reader/client profile, anonymized test fixture, Infrastructure tests/runner registration, project compile/content entries, Architecture guards, and governance/checksums.
- **Read-only behavior:** workbook open is constrained to `FileMode.Open`, `FileAccess.Read`, `FileShare.ReadWrite`; no workbook save/write route is added. `.xls` uses ExcelDataReader binary reader and `.xlsx` uses OpenXML reader. Form failure never falls back to the existing Table pipeline.
- **Client-data boundary:** production `4075_P_DO.XLSX` is not included. The test workbook is independently generated/anonymized and uses synthetic guard, mould number and grade vocabulary.
- **Protected files:** all eight v1.5 protected 0.30.1 files remain byte-identical and are SHA-256-pinned by Architecture tests.
- **Not included:** category mapping/resolution, vocabulary business findings, blank-grade orchestration, DesignChecks/config/Plugin wiring, Domain semantic changes, Cimatron production reader changes, or live validation.
- **Validation boundary:** agent did not run build/tests/coverage/analyzers/SonarQube/Cimatron. `0.31.0` awaits user workstation quality-gate evidence; Slice 2 remains blocked until review.


## 0.31.1 — 2026-10-06 — CR-04 v1.5 Slice 1 analyzer-warning corrective

- **Entering evidence:** user-supplied `quality-gate-20261005-235128.txt` started `2026-10-05T23:51:28.8826601+05:30` and completed `2026-10-05T23:52:06.3366160+05:30`. Release x64 build completed; Architecture, Domain, Application, CimatronIntegration and Infrastructure suites PASS; coverage/local quality gate PASS; exit code 0. The build summary nevertheless contained 2 warnings / 0 errors, so the mandatory zero-warning gate was not satisfied.
- **Warning 1:** CA1859 in `src/CimatronCustomization.Infrastructure/ExcelDesignOrderFormReader.cs` on `ReadRows(...)`. Approved corrective changes only the private method return type from `IReadOnlyList<object[]>` to the already-returned concrete `List<object[]>`; caller behavior and public contracts are unchanged.
- **Warning 2:** CA1861 in `tests/CimatronCustomization.Infrastructure.Tests/ExcelDesignOrderFormReaderTests.cs`. Approved corrective replaces the repeated expected-grade array literal with one `static readonly` array; test intent and assertions are unchanged.
- **Scope boundary:** no Form profile values, fixture data, Application contracts, Table path, Domain logic, Cimatron production adapters, DesignChecks, Plugin, configuration, dependency versions, models, or protected v1.5 files changed.
- **Validation boundary:** agent did not run build/tests/coverage/analyzers/SonarQube/Cimatron. A fresh full workstation quality gate with 0 warnings / 0 errors is required before Slice 1 closure or Slice 2 implementation.

## 0.32.0 — 2026-10-06 — CR-04 v1.5 Slice 2 category mapping + Form/Table orchestration

### Approved scope
- User approved Slice 2 Application mapping/orchestration and tests, then separately approved the narrow Domain amendment required to add the distinct `ResultStatus.Info` semantic used by the v1.5 specification.
- Exact approval timestamps were not independently captured and are intentionally not invented.

### Implementation
- Added `SteelGradeCategoryPattern`, `SteelGradeCategoryMappingConfiguration`, `SteelGradeCategoryResolution`, `SteelGradeCategoryResolver`, and `SteelGradeVocabularyValidation` in Application.
- ModelTitle mapping uses deterministic case-sensitive glob syntax (`*` = any run of characters, `?` = one character). No production client patterns are invented or configured in this slice.
- Optional category body attribute takes precedence when a present nonblank value exists. Unknown attribute category does not silently fall back to ModelTitle. Multiple distinct category-attribute values are ambiguous.
- Exclusion patterns apply when no category-attribute override is present and produce Info. Unmapped/multi-category occurrences produce Warning and are not passed into grade comparison.
- Form mode reads the approved Slice 1 typed Form result, performs D-16 blank-grade handling and D-05 closed-vocabulary validation, and sends only valid nonblank categories plus uniquely mapped CAD evidence to the existing Domain evaluator using stable category keys.
- The existing Domain evaluator therefore retains many-CAD-components-to-one-DO-category grouping unchanged.
- Added `MOULD_NUMBER_CHECK_NOT_PERFORMED` Info because no approved Cimatron mould identity source exists.
- Existing Table mode retains the prior `ReadMappedTabularData` route and old request constructor.

### Tests / architecture
- Added category resolver and vocabulary tests; expanded CR-04 orchestration tests for Form many-to-one, D-16, exclusions, and mould Info; added Domain Info semantics test.
- New tests are explicitly registered through Application and Domain `Program.cs` runners.
- Architecture guard checks Form/category orchestration tokens, no Form-to-Table fallback, Info presence, and test-runner registration.
- Existing Slice 1 protected SHA-256 guard remains authoritative for the eight protected files.

### Validation state
- Static package checks only were performed by the agent (project XML parsing, source-brace sanity, protected-file SHA-256 verification, cumulative manifest/package construction). These are not build/test evidence.
- Agent did not execute MSBuild, unit/architecture tests, coverage, analyzers, SonarQube, or Cimatron.
- Status: AWAITING USER WORKSTATION QUALITY GATE. Slice 3 remains blocked until the supplied gate is reviewed and accepted.


## 0.32.1 — 2026-10-06 — CR-04 v1.5 Slice 2 warning corrective

### Entering workstation evidence
User supplied `quality-gate-20261006-004117.txt`:

- capture timestamp: `2026-10-06T00:41:17.5004062+05:30`;
- completion: `2026-10-06T00:42:17.8229625+05:30`;
- Release x64 build: PASS;
- Architecture, Domain, Application, CimatronIntegration and Infrastructure: PASS;
- coverage collection/gate: PASS;
- local quality gate: PASS;
- exit code: `0`;
- **11 warnings / 0 errors**.

Coverage was Domain 99.74%, Application 92.95%, DesignChecks 98.32%, Infrastructure 82.27%, and CimatronIntegration 2.08% measured/no threshold.

### Approved corrective scope
User explicitly approved a warning-only corrective after the supplied gate was reviewed. Exact chat approval/feedback receipt timestamps were not independently captured and are intentionally not invented.

Only these code/test changes are permitted and made:

1. `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrder.cs`
   - private `CollectReferences(...)` return type changed from `IReadOnlyList<ModelEntityReference>` to `ModelEntityReference[]` to satisfy CA1859; returned data was already materialized with `ToArray()`.
2. `tests/CimatronCustomization.Application.Tests/SteelGradeVocabularyValidationTests.cs`
   - three warning-producing constant vocabulary arrays moved to `static readonly` fields.
3. `tests/CimatronCustomization.Application.Tests/SteelGradeCategoryResolverTests.cs`
   - warning-producing constant category/exclusion arrays moved to `static readonly` fields.
4. `tests/CimatronCustomization.Application.Tests/VerifySteelGradeAgainstDesignOrderTests.cs`
   - the warning-producing Cavity-pattern / exclusion arrays used by the exclusion-Info test moved to `static readonly` fields.
5. Mandatory version/history/changelog/timesheet/handoff/checksum/package updates.

### Scope protection
No business logic or test intent changes. No source outside the approved warning sites is modified. The eight v1.5 protected files remain byte-identical. No Plugin/config/Cimatron-model/client-workbook/dependency changes. Raw workstation evidence remains outside the cumulative ZIP.

### Validation state
Agent performed static package/checksum/protected-file verification only; this is not workstation build/test evidence. Agent did not run MSBuild, tests, coverage, analyzers, SonarQube, or Cimatron.

Status: **AWAITING USER WORKSTATION QUALITY GATE**. Slice 2 remains open until a fresh full gate shows 0 warnings / 0 errors and all governed gates PASS.


## 0.32.1 — 2026-10-06 — CR-04 v1.5 Slice 2 workstation quality-gate closure

### Accepted workstation evidence
User supplied `quality-gate-20261006-004944.txt` (raw capture remains outside the cumulative ZIP):

- capture timestamp: `2026-10-06T00:49:44.5212946+05:30`;
- completion: `2026-10-06T00:50:38.7666844+05:30`;
- Release x64 build: PASS;
- **0 warnings / 0 errors**;
- Architecture / Domain / Application / CimatronIntegration / Infrastructure: PASS;
- coverage collection/gate: PASS;
- local quality gate: PASS;
- exit code: `0`;
- coverage: Domain 99.74%, Application 92.95%, DesignChecks 98.32%, Infrastructure 82.27%, CimatronIntegration 2.08% measured/no threshold.

### Closure decision
- The user requested the updated cumulative session handoff after the clean 0.32.1 gate was reviewed. Exact chat feedback/approval receipt timestamp was not independently captured and is intentionally not invented.
- Slice 2 is therefore **CLOSED / USER VALIDATED**.
- Closure package changes are documentation/governance/checksum/package only. No source/test/config/runtime/Cimatron-model behavior is changed from the accepted 0.32.1 warning-corrective baseline.
- The eight v1.5 protected files remain byte-identical.
- Raw quality-gate evidence and the production client workbook remain excluded.

### Next step
Slice 3 is feature/config/composition wiring. Before any edit, the next session must re-read `AGENTS.md`, v1.5 specification, latest history/changelog/version and the Slice 2 closure handoff, then present the exact Slice 3 file/scope plan and wait for explicit approval. No real client ModelTitle category patterns may be invented. Final CR-04 production closure remains blocked by unresolved client inputs including production ModelTitle naming patterns, final production steel-grade attribute name, suffix-use semantics, blank-grade business meaning confirmation, and the template validation-range defect disposition.

## 2026-10-06 — 0.38.3 CR-04 Part Material correlation diagnostic

User approved a narrow read-only diagnostic after the 0.38.2 live Result Report proved native Part Material reading works end-to-end but exposed occurrence-to-BOM correlation/evaluation discrepancies. User-provided Cimatron UI evidence shows `Cavity block` Part Material = `P-20-2311`, while the live Result Report reported the mapped Cavity category with no usable grade; therefore no production logic change was authorized before correlation evidence is captured.

Implemented a new one-shot Plugin diagnostic and request script. The diagnostic uses the production assembly occurrence reader and category resolver, reads the production BOM Part Material table through the already-approved BOM route, and records the eight approved target ModelTitles with occurrence path, InstanceId, exact BOM Standard Number/Material match, category resolution, and correlation result. The complete BOM Standard Number/Material snapshot is included in the diagnostic evidence to expose any naming divergence. No model or workbook mutation/save is performed. Production comparison logic, configuration, category mapping, Design Order reader, vocabulary, Cimatron API route, and dependencies are unchanged.

The AI agent performed only static/source/XML/checksum/package-integrity preparation and did not run build/tests/coverage/analyzers/SonarQube/Cimatron. Workstation quality gate and controlled live diagnostic remain user-run validation gates.


## 2026-10-06 — 0.39.4 CR-04 v1.5 DesignChecks coverage corrective

### Entering workstation evidence
User supplied `quality-gate-20261006-215037.txt`: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure test suites PASS. Coverage collection completed, but the governed gate failed because `CimatronCustomization.DesignChecks` measured 92.14% against its 95% minimum. Domain measured 99.74%, Application 91.87%, Infrastructure 81%, and Cimatron Integration 1.95% measured/no threshold.

### Approved scope
User explicitly approved a narrow 0.39.4 coverage-only slice. No production behavior change is authorized. Exact approval receipt timestamp was not independently captured and is intentionally not invented.

### Test-only implementation
`tests/CimatronCustomization.Application.Tests/SteelGradeDesignOrderValidationFeatureTests.cs` now exercises additional existing DesignChecks branches through the public feature execution surface: null context rejection, null application findings rejection, missing required Table worksheet/header/component-key header/steel-grade header/component-key source parameters, and missing required Form profile/category-source parameters. The existing test parameter builder gains a test-only omission switch so these fail-closed branches can be exercised without modifying production source.

No `src/**` production file is changed in this corrective. Native `TMPL::Part_Type` / `TMPL::Material`, DO selected-family X + Remark rules, trim/normalization policy, Table mode, Form mode, PDM adapter, configuration, model/workbook, and read-only behavior remain unchanged.

### Validation state
The AI agent performed static source/diff/checksum/package preparation only and did not run MSBuild, tests, coverage, analyzers, SonarQube, or Cimatron. Status: AWAITING USER WORKSTATION QUALITY GATE.


## 2026-10-06 — 0.39.5 CR-04 v1.5 DesignChecks dead-code / coverage corrective

### Entering evidence
User supplied `quality-gate-20261006-221138.txt`: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration and Infrastructure suites PASS; coverage collection PASS; DesignChecks measured 93.45% against the 95% minimum. The supplied `coverage.cobertura.xml` showed 571 covered / 611 coverable DesignChecks lines.

### Mandatory pre-check
Repo-wide `src/`, `tests/`, `tools/` search found no caller or reflection access for private `TryParseCategoryPatterns`. The sole test-side text match is the Architecture forbidden-token guard `TryParseCategoryPatterns(patternText, formProfile`, which verifies that Form production wiring does not call the legacy parser. `InternalsVisibleTo` exists for Application.Tests but provides no access to this private method. Pre-check: PASS.

### Production change
Only `src/CimatronCustomization.DesignChecks/SteelGradeDesignOrderValidation.cs` behavior is changed, plus the changed DesignChecks assembly version stamp. The orphaned private `TryParseCategoryPatterns` routine is removed. It became orphaned when 0.39.0 migrated Form component classification to native `TMPL::Part_Type`. The exclusion parser is simplified without behavior change: `SplitList` continues to use `RemoveEmptyEntries`, trim and `Length > 0`, so the impossible post-filter blank rejection is removed and the caller no longer handles an impossible failure result.

No other category-pattern surface is retired. `ComponentCategoryPatterns` parameter definition/validation/config remains in place. **Open follow-up decision:** determine whether and when to retire the now-obsolete `ComponentCategoryPatterns` parameter surface in a separately approved change.

### Tests
Added the user-approved methods to the existing `RunAll()` methods with business/result assertions and no reflection/private access. `Program.cs` remains unchanged. Coverage/regression cases cover configured public construction, empty exclusion separators, unavailable occurrence source, missing nested reference, unavailable/invalid mapping, BOM material mismatch, no-mutation failure, null execution context, and null diagnostic ID collection normalization.

### Projected coverage
From the 0.39.4 XML baseline: 571/611 = 93.453%. Removing 26 coverable lines from orphaned `TryParseCategoryPatterns`, replacing the 12-line exclusion parser with an expected 3 coverable-line behavior-equivalent parser, and simplifying the caller by an expected net 2 coverable lines yields an estimated new denominator of 574. The change removes 31 previously-uncovered lines and six previously-covered parser lines net of replacement; the approved tests are expected to cover eight previously-uncovered reachable lines, giving an estimated 573/574 = 99.826% DesignChecks line coverage. This is a projection only; the user workstation XML is authoritative.

Application and Infrastructure thresholds are unchanged. The 0.39.4 gate reported Application 91.87% (90% minimum, +1.87 pp) and Infrastructure 81.45% (80% minimum, +1.45 pp). The DesignChecks-focused tests do not change either source denominator.

### Validation state
Static source/diff/package checks only in the agent environment. Full Release x64 workstation quality gate remains required before 0.39.5 can be accepted.


## 2026-10-06 — 0.39.6 0.39.5 Application-test / CA1859 corrective

### Entering evidence
User supplied `quality-gate-20261006-232537.txt` from the 0.39.5 workstation run. Release x64 build passed, Architecture and Domain tests passed, then Application Tests failed and the gate exited before coverage collection. The build emitted one CA1859 warning at `SteelGradeDesignOrderValidation.cs(323,46)`.

### Root cause
The new `MissingNestedBodyReferenceSkipsMappingAndHighlight` test asserted aggregate `Passed`. Existing production `FindingAggregation` assigns `Skipped` greater severity than `Passed`, and the scenario intentionally emits two `Skipped` findings for U7/U12, so the correct aggregate is `Skipped`. This is a test expectation defect, not a runtime defect. The CA1859 warning is caused by private `ParseExclusionPatterns` returning interface type `IReadOnlyList<string>` while directly returning the concrete `string[]` produced by unchanged `SplitList`.

### Approved corrective
- Test-only expectation change: `Passed` -> `Skipped` for the missing nested-reference aggregate.
- Warning-only signature change: private `ParseExclusionPatterns` returns `string[]`; method body and caller semantics unchanged.
- DesignChecks assembly/file version aligned to `0.39.6.0`.
- Static re-review of all other tests introduced in 0.39.5 found no analogous status-expectation defect; no further test edits made.

### Scope exclusions
No threshold change; no CR-04 logic change; no parser behavior change; no `Program.cs` change; no configuration change; no `ComponentCategoryPatterns` retirement; no other production source edits.

### Validation state
Agent environment performed static source/diff/package checks only. Full Release x64 workstation quality gate remains required before 0.39.6 can be accepted.
## 2026-10-07 — 0.39.7 CR-04 v1.5 Form non-Part eligibility corrective

- **Change ID:** PH02-ST10-CR04-V15-NON-PART-FORM-ELIGIBILITY-CORRECTIVE.
- **Change type:** BUGFIX / APPLICATION ORCHESTRATION / CIMATRON OCCURRENCE EVIDENCE / TEST / GOVERNANCE.
- **Approval:** user explicitly approved the narrow 0.39.7 correction after reviewing the seven stable live `CAD_PART_PROPERTY_READ_ERROR` cases; exact approval receipt timestamp was not independently captured and is intentionally blank in the time ledger.
- **Entering quality evidence:** `quality-gate-20261006-233537.txt` accepted 0.39.6 with Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, governed coverage PASS including DesignChecks 100%, local gate PASS, exit 0.
- **Entering live evidence:** `Cimatron-Result-Report-20261007-000856.csv` produced valid `STEEL_GRADE_MATCH` findings for Cavity, Core, and CoreInsert at `P-20-2311`, while seven higher-level/nested assembly occurrences failed native Part-property PDM reads with the same `Value does not fall within the expected range` message.
- **Root cause:** `CimatronAssemblyBodyAttributeReader` correctly retained every occurrence before nested descent for highlighter-equivalent safety, but `VerifySteelGradeAgainstDesignOrder.ExecuteForm` attempted `IPartDocumentPropertyReader.Read(ModelPid)` for every unsuppressed occurrence without distinguishing `cmPart` from assembly/non-Part model types. The Part-specific PDM adapter was therefore invoked for non-Part PIDs.
- **Corrective:** preserve full traversal and carry the occurrence's existing `IModel.Type.ToString()` into `AssemblyBodyAttributeOccurrence.ModelType`; in Form orchestration, after configured exclusion handling and before the native Part-property reader call, skip any model type other than exact `cmPart` and emit `[CAD_NON_PART_SKIPPED]` with `Info` status.
- **Fail-safe preservation:** real `cmPart` native property read failures continue to emit the underlying Error code/message; no exception swallowing or downgrade is introduced.
- **Tests:** Application regression covers a `cmAssembly` occurrence producing Info with zero Part-reader calls and a `cmPart` controlled read failure remaining Error with exactly one reader call. Cimatron Integration source-contract test requires the traversal adapter to pass `model.Type.ToString()` while retaining the existing pre-descent occurrence add contract. Existing Form Cavity/Core-style native Part tests remain unchanged.
- **Versioning:** Application and CimatronIntegration assembly/file versions advance to `0.39.7.0`; product version advances to `0.39.7`.
- **Explicit non-scope:** no traversal filtering/removal, ModelTitle category fallback, Part Type/Part Material identity change, DO X/Remark/vocabulary/category rule change, Table-mode change, threshold/config/workbook/model mutation, or unrelated cleanup.
- **Acceptance:** AI agent does not run workstation build/tests/coverage/Cimatron. User must run the full quality gate, then rerun the same controlled production Form validation and confirm the former non-Part PDM errors are replaced by `CAD_NON_PART_SKIPPED` Info while Cavity/Core/CoreInsert matching remains intact.
## 2026-10-07 — 0.39.8 0.39.7 architecture-guard alignment corrective

- **Change ID:** PH02-ST10-CR04-V15-0397-ARCH-GUARD-CORRECTIVE.
- **Change type:** TEST-GOVERNANCE / ARCHITECTURE GUARD ALIGNMENT / VERSIONING.
- **Approval:** user explicitly approved the exact 0.39.8 narrow corrective; precise approval receipt timestamp is not independently captured and is intentionally left blank in the time ledger.
- **Entering evidence:** `quality-gate-20261007-002443.txt` shows Release x64 build PASS with 0 warnings / 0 errors, followed by Architecture Tests FAIL and gate exit before later suites/coverage.
- **Root cause:** `Cr04V15FormReaderMustRemainGuarded` still protected `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs` with the old SHA-256 `6335016dbc2edc1aa27272a195e290cd43bcf2f25ec79ce197051900090032df`, while the explicitly approved 0.39.7 file content hashes to `7fede8fcd63d4bbad4213110cc561c5b78f2b41d1cc57d64623398c283106368`.
- **Corrective:** update only that single protected hash entry in `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`.
- **Explicit non-scope:** no production `src/**` changes, no CR-04 behavior changes, no threshold/configuration changes, no other architecture guard changes, no refactor/cleanup.
- **Acceptance:** full workstation quality gate is required.
## 2026-10-07 — 0.39.9 CR-04 v1.5 synthetic Root.elt Form eligibility corrective

- **Change ID:** PH02-ST10-CR04-V15-SYNTHETIC-ROOT-FORM-ELIGIBILITY-CORRECTIVE.
- **Approval:** user explicitly approved the exact 0.39.9 correction after reviewing the occurrence-level evidence; exact approval receipt timestamp is not independently captured and is intentionally blank in the time ledger.
- **Entering quality evidence:** `quality-gate-20261007-003106.txt` accepted 0.39.8 with Release x64 PASS, 0 warnings / 0 errors, all governed suites PASS, governed coverage PASS, local gate PASS, exit 0.
- **Entering live evidence:** `Cimatron-Result-Report-20261007-003425.csv` preserved Cavity/Core/CoreInsert matches and produced six expected `CAD_NON_PART_SKIPPED` Info findings, while seven Part-property read errors remained.
- **Root-cause evidence:** `api-capability-cr04-slice2a-20261007-004150.txt` shows exactly seven synthetic occurrences reported as `cmPart` with exact `ModelPid = \\5\Root.elt`: the active/top assembly synthetic root plus one synthetic child under each affected nested assembly. The diagnostic explicitly preserves the locked no-self-instance-filtering D-15 traversal rule.
- **Corrective:** Form orchestration preserves every traversal occurrence, keeps the existing non-`cmPart` skip, then skips exact synthetic `\\5\Root.elt` before `IPartDocumentPropertyReader.Read` and emits `[CAD_SYNTHETIC_ROOT_SKIPPED]` with Info status.
- **Tests:** adds a focused Application test with `ModelType=cmPart` and `ModelPid=\\5\Root.elt`, asserting Info and zero native Part-property reader calls. Existing `cmAssembly` skip/no-read and genuine `cmPart` controlled read-error tests remain unchanged and registered in `RunAll()`.
- **Versioning:** Application assembly/file version advances to `0.39.9.0`; product version advances to `0.39.9`.
- **Explicit non-scope:** no traversal filtering/removal, D-15/highlight identity change, Cimatron Integration source change, ModelTitle heuristic, Part Type/Part Material rule change, DO X/Remark/category/vocabulary change, Table-mode change, threshold/config/workbook/model mutation, or unrelated cleanup.
- **Acceptance:** AI agent does not run workstation build/tests/coverage/Cimatron. User must run full quality gate, restart Cimatron, rerun the same controlled Form validation, and confirm the former seven Part-property errors become `CAD_SYNTHETIC_ROOT_SKIPPED` Info while Cavity/Core/CoreInsert matching remains intact.


## 2026-10-07 — 0.39.9 CR-04 v1.5 synthetic Root.elt Form eligibility corrective — VALIDATION CLOSURE

- **Closure type:** DOCUMENTATION / GOVERNANCE / EVIDENCE SUMMARY ONLY. No production, test, configuration, threshold, workbook, or model behavior change.
- **Quality-gate evidence:** user-supplied `quality-gate-20261007-004937.txt`, capture timestamp `2026-10-07T00:49:37.5423893+05:30`, accepted Release x64 with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure suites PASS; coverage/local gate PASS; exit code 0.
- **Live evidence:** user-supplied `Cimatron-Result-Report-20261007-005224.csv` confirmed `CAD_PART_PROPERTY_READ_ERROR=0`, `CAD_SYNTHETIC_ROOT_SKIPPED=7`, `CAD_NON_PART_SKIPPED=6`, and three preserved `STEEL_GRADE_MATCH` findings for Cavity, Core, and CoreInsert at `P-20-2311`. Correlation ID: `e53384f0f4ed4eb1aeac1967804a89cf`.
- **No-mutation evidence:** user manually confirmed `Assembly remains unmodified after this validation run: YES`. Exact chat receipt timestamp was not independently captured and is intentionally not invented.
- **Remaining live findings:** Design-Order categories CavityInsert, MovingCore, AngularLifter, and MouldBase remain not found in the controlled model data. These are test/model preparation gaps and do not invalidate the 0.39.9 corrective.
- **Corrective closure:** the seven Cimatron synthetic `\\5\\Root.elt` occurrences remain in full D-15/highlighter-equivalent traversal but are excluded only from native Part-document property validation, exactly as approved. The seven prior synthetic-root Part-property read Errors are eliminated without suppressing genuine real-Part read failures.
- **Evidence packaging rule:** client Design Order and raw exported Result Report CSV remain external evidence and are not added to the repository/cumulative ZIP. Governance records only filenames, authoritative timestamps where available, counts, correlation ID, and user no-mutation confirmation.
- **Status:** `0.39.9 USER VALIDATED / CLOSED`.

## 2026-10-07 — 0.40.1 Result Report CSV Session Handoff Refresh

- **Change ID:** PH02-ST10-CR04-V15-0401-SESSION-HANDOFF.
- **Change type:** DOCUMENTATION / GOVERNANCE / SESSION HANDOFF ONLY.
- **User request:** create an updated cumulative ZIP containing the current session handoff and provide a prompt for the next session.
- **Runtime/version boundary:** product/runtime remains `0.40.1`; no production source or test behavior is changed by this handoff refresh.
- **State carried forward:** 0.40.1 remains AWAITING USER QUALITY GATE. The previous 0.40.0 workstation gate passed build/tests/coverage/local gate and exited 0 but contained one CA1859 warning; 0.40.1 contains the approved warning-only corrective and requires a fresh full quality gate with 0 warnings / 0 errors before live CSV acceptance.
- **Artifacts added:** `phase-02-step-10-cr04-v1.5-result-report-csv-session-handoff-0.40.1.md` and `phase-02-step-10-cr04-v1.5-result-report-csv-new-session-prompt-0.40.1.txt`.
- **Timestamps:** agent handoff work started `2026-10-07T11:23:21+05:30` and finalized `2026-10-07T11:24:37+05:30`; exact user-request receipt timestamp is not independently captured and is not invented.
