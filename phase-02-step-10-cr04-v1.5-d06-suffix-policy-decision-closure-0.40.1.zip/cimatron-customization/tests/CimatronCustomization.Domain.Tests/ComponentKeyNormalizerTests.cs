using System;

namespace CimatronCustomization.Domain.Tests
{
    internal static class ComponentKeyNormalizerTests
    {
        internal static void RunAll()
        {
            KeyWhitespaceIsNormalized();
            KeysCompareOrdinalIgnoringCase();
            SubstringsDoNotMatch();
            MissingKeyNormalizesToEmpty();
        }

        private static void KeyWhitespaceIsNormalized()
        {
            AssertEqual(
                "CORE INSERT",
                ComponentKeyNormalizer.Normalize("  CORE\t\u00A0  INSERT  "),
                "Normalized key");
        }

        private static void KeysCompareOrdinalIgnoringCase()
        {
            AssertTrue(ComponentKeyNormalizer.EqualsKey("Core Insert", " core\tinsert "), "Case-insensitive key equality");
        }

        private static void SubstringsDoNotMatch()
        {
            AssertFalse(ComponentKeyNormalizer.EqualsKey("CORE", "CORE_INSERT"), "No substring matching");
        }

        private static void MissingKeyNormalizesToEmpty()
        {
            AssertEqual(string.Empty, ComponentKeyNormalizer.Normalize(null), "Null key");
            AssertEqual(string.Empty, ComponentKeyNormalizer.Normalize("  "), "Blank key");
        }

        private static void AssertTrue(bool value, string label)
        {
            if (!value)
            {
                throw new InvalidOperationException(label + " expected true.");
            }
        }

        private static void AssertFalse(bool value, string label)
        {
            if (value)
            {
                throw new InvalidOperationException(label + " expected false.");
            }
        }

        private static void AssertEqual<T>(T expected, T actual, string label)
        {
            if (!Equals(expected, actual))
            {
                throw new InvalidOperationException($"{label}: expected '{expected}', actual '{actual}'.");
            }
        }
    }
}
