using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Domain.Tests
{
    internal static class SteelGradeDesignOrderEvaluationTests
    {
        private static readonly string[] Grade12738 = { "1.2738" };
        private static readonly string[] Grade12311 = { "1.2311" };
        private static readonly string[] Grade17131 = { "1.7131" };
        private static readonly string[] Grade12080 = { "1.2080" };
        private static readonly string[] Grade12343 = { "1.2343" };
        private static readonly string[] MissingGrades = { null, " " };
        private static readonly string[] SingleMissingGrade = { null };
        private static readonly string[] AmbiguousBodyGrades = { "1.2738", "1.2311" };
        private static readonly string[] DuplicateBodyGrades = { "1.2738", "1.2738" };
        private static readonly string[] WrongTypePlacement = { "root/WRONG_TYPE_CONTROL" };

        internal static void RunAll()
        {
            MatchingGradePassesAndPreservesSafeReferences();
            DifferentGradeFails();
            MissingCadGradeFails();
            MultipleDistinctBodyGradesFailAsAmbiguous();
            DuplicateSameBodyGradeIsSingleValue();
            DesignOrderComponentNotFoundFails();
            CadComponentWithGradeNotInDesignOrderWarns();
            CadComponentWithoutGradeNotInDesignOrderIsNotReported();
            DuplicateNormalizedDesignOrderKeyErrorsAndStops();
            BlankDesignOrderGradeErrorsProvisionally();
            AmbiguousNumericDesignOrderGradeErrors();
            EmptyDesignOrderErrors();
            OptionBBomBlankMaterialIsMissingNotError();
            OptionCSourceDisagreementFails();
            UnsupportedAttributeTypeIsRepresentableWithoutAssumingRuntimeMapping();
            RepeatedEvidenceProducesOneBusinessFindingAndDeduplicatesReferences();
            AggregationPreservesCanonicalPrecedence();
            ConstructorsRejectInvalidInput();
            OptionalCollectionsDefaultToEmpty();
            EvaluateRejectsInvalidCollections();
        }

        private static void MatchingGradePassesAndPreservesSafeReferences()
        {
            ModelEntityReference reference = new ModelEntityReference("instance:10/body:4");
            Finding finding = Single(
                Entries(Entry("CORE_INSERT", "1.2738", 2)),
                Evidence(Cad("CORE_INSERT", Grade12738, reference)));

            AssertEqual(ResultStatus.Passed, finding.Status, "Match status");
            AssertPrefix("[STEEL_GRADE_MATCH]", finding.Message, "Match code");
            AssertEqual(1, finding.EntityReferences.Count, "Match refs");
            AssertSame(reference, finding.EntityReferences[0], "Reference preserved");
        }

        private static void DifferentGradeFails()
        {
            Finding finding = Single(
                Entries(Entry("CAVITY_INSERT", "1.2738", 2)),
                Evidence(Cad("CAVITY_INSERT", Grade12311)));

            AssertEqual(ResultStatus.Failed, finding.Status, "Mismatch status");
            AssertPrefix("[STEEL_GRADE_MISMATCH]", finding.Message, "Mismatch code");
        }

        private static void MissingCadGradeFails()
        {
            Finding finding = Single(
                Entries(Entry("WEDGE", "1.2379", 2)),
                Evidence(Cad("WEDGE", MissingGrades)));

            AssertEqual(ResultStatus.Failed, finding.Status, "Missing attribute status");
            AssertPrefix("[STEEL_GRADE_ATTRIBUTE_MISSING]", finding.Message, "Missing code");
        }

        private static void MultipleDistinctBodyGradesFailAsAmbiguous()
        {
            Finding finding = Single(
                Entries(Entry("HEEL_BLOCK", "1.2738", 2)),
                Evidence(Cad("HEEL_BLOCK", AmbiguousBodyGrades, null, bodyCount: 2)));

            AssertEqual(ResultStatus.Failed, finding.Status, "Ambiguous status");
            AssertPrefix("[STEEL_GRADE_ATTRIBUTE_AMBIGUOUS]", finding.Message, "Ambiguous code");
        }

        private static void DuplicateSameBodyGradeIsSingleValue()
        {
            Finding finding = Single(
                Entries(Entry("HEEL_BLOCK", "1.2738", 2)),
                Evidence(Cad("HEEL_BLOCK", DuplicateBodyGrades, null, bodyCount: 2)));

            AssertEqual(ResultStatus.Passed, finding.Status, "Same multi-body value passes");
        }

        private static void DesignOrderComponentNotFoundFails()
        {
            Finding finding = Single(
                Entries(Entry("EJECTOR_PLATE", "1.1730", 2)),
                Array.Empty<CadComponentSteelGradeEvidence>());

            AssertEqual(ResultStatus.Failed, finding.Status, "DO component not found status");
            AssertPrefix("[DO_COMPONENT_NOT_FOUND]", finding.Message, "DO component not found code");
        }

        private static void CadComponentWithGradeNotInDesignOrderWarns()
        {
            IReadOnlyList<Finding> findings = Evaluate(
                Entries(Entry("CORE_INSERT", "1.2738", 2)),
                Evidence(
                    Cad("CORE_INSERT", Grade12738),
                    Cad("GUIDE_STRIP", Grade17131)));

            Finding warning = findings.Single(item => item.Status == ResultStatus.Warning);
            AssertPrefix("[CAD_COMPONENT_NOT_IN_DO]", warning.Message, "CAD-not-in-DO code");
        }

        private static void CadComponentWithoutGradeNotInDesignOrderIsNotReported()
        {
            IReadOnlyList<Finding> findings = Evaluate(
                Entries(Entry("CORE_INSERT", "1.2738", 2)),
                Evidence(
                    Cad("CORE_INSERT", Grade12738),
                    Cad("SUPPORT_PILLAR", SingleMissingGrade)));

            AssertEqual(1, findings.Count, "No warning for valueless CAD-only component");
            AssertEqual(ResultStatus.Passed, findings[0].Status, "Only match remains");
        }

        private static void DuplicateNormalizedDesignOrderKeyErrorsAndStops()
        {
            IReadOnlyList<Finding> findings = Evaluate(
                Entries(
                    Entry("CORE INSERT", "1.2738", 2),
                    Entry(" core\tinsert ", "1.2738", 3)),
                Evidence(Cad("CORE INSERT", Grade12738)));

            AssertEqual(1, findings.Count, "Duplicate key stops evaluation");
            AssertEqual(ResultStatus.Error, findings[0].Status, "Duplicate key status");
            AssertPrefix("[DO_DUPLICATE_COMPONENT_KEY]", findings[0].Message, "Duplicate key code");
        }

        private static void BlankDesignOrderGradeErrorsProvisionally()
        {
            Finding finding = Single(
                Entries(Entry("CORE_INSERT", " ", 2)),
                Evidence(Cad("CORE_INSERT", Grade12738)));

            AssertEqual(ResultStatus.Error, finding.Status, "Blank grade provisional status");
            AssertPrefix("[DO_GRADE_MISSING]", finding.Message, "Blank grade code");
        }

        private static void AmbiguousNumericDesignOrderGradeErrors()
        {
            Finding finding = Single(
                Entries(Entry("CORE_INSERT", "1.208", 2)),
                Evidence(Cad("CORE_INSERT", Grade12080)));

            AssertEqual(ResultStatus.Error, finding.Status, "Ambiguous numeric status");
            AssertPrefix("[DO_GRADE_AMBIGUOUS_NUMERIC]", finding.Message, "Ambiguous numeric code");
        }

        private static void EmptyDesignOrderErrors()
        {
            Finding finding = Single(
                Array.Empty<DesignOrderSteelGradeEntry>(),
                Array.Empty<CadComponentSteelGradeEvidence>());

            AssertEqual(ResultStatus.Error, finding.Status, "No rows status");
            AssertPrefix("[NO_DO_ROWS]", finding.Message, "No rows code");
        }

        private static void OptionBBomBlankMaterialIsMissingNotError()
        {
            CadComponentSteelGradeEvidence cad = Cad(
                "CORE_INSERT",
                Array.Empty<string>(),
                null,
                bomValues: MissingGrades);

            Finding finding = Single(
                Entries(Entry("CORE_INSERT", "1.2738", 2)),
                Evidence(cad));

            AssertEqual(ResultStatus.Failed, finding.Status, "Blank BOM material is business missing");
            AssertPrefix("[STEEL_GRADE_ATTRIBUTE_MISSING]", finding.Message, "Blank BOM material code");
        }

        private static void OptionCSourceDisagreementFails()
        {
            CadComponentSteelGradeEvidence cad = Cad(
                "CORE_INSERT",
                Grade12738,
                null,
                bomValues: Grade12311);

            Finding finding = Single(
                Entries(Entry("CORE_INSERT", "1.2738", 2)),
                Evidence(cad));

            AssertEqual(ResultStatus.Failed, finding.Status, "Source disagreement status");
            AssertPrefix("[STEEL_GRADE_SOURCE_DISAGREEMENT]", finding.Message, "Source disagreement code");
        }

        private static void UnsupportedAttributeTypeIsRepresentableWithoutAssumingRuntimeMapping()
        {
            CadComponentSteelGradeEvidence cad = new CadComponentSteelGradeEvidence(
                "WRONG_TYPE_CONTROL",
                "WRONG_TYPE_CONTROL",
                Array.Empty<string>(),
                1,
                WrongTypePlacement,
                Array.Empty<ModelEntityReference>(),
                attributeTypeUnsupported: true);

            Finding finding = Single(
                Entries(Entry("WRONG_TYPE_CONTROL", "1.2738", 2)),
                Evidence(cad));

            AssertEqual(ResultStatus.Unsupported, finding.Status, "Unsupported type status");
            AssertPrefix("[STEEL_GRADE_ATTRIBUTE_TYPE_UNSUPPORTED]", finding.Message, "Unsupported type code");
        }

        private static void RepeatedEvidenceProducesOneBusinessFindingAndDeduplicatesReferences()
        {
            ModelEntityReference shared = new ModelEntityReference("safe:body:4");
            IReadOnlyList<Finding> findings = Evaluate(
                Entries(Entry("SLIDER", "1.2343", 2)),
                Evidence(
                    Cad("SLIDER", Grade12343, shared),
                    Cad("slider", Grade12343, shared)));

            AssertEqual(1, findings.Count, "Repeated placements grouped by key");
            AssertEqual(ResultStatus.Passed, findings[0].Status, "Repeated placement business result");
            AssertEqual(1, findings[0].EntityReferences.Count, "Repeated reference deduplicated");
        }

        private static void AggregationPreservesCanonicalPrecedence()
        {
            IReadOnlyList<Finding> findings = Evaluate(
                Entries(
                    Entry("CORE_INSERT", "1.2738", 2),
                    Entry("CAVITY_INSERT", "1.2738", 3)),
                Evidence(
                    Cad("CORE_INSERT", Grade12738),
                    Cad("CAVITY_INSERT", Grade12311),
                    Cad("GUIDE_STRIP", Grade17131)));

            AssertEqual(
                ResultStatus.Failed,
                FindingAggregation.Aggregate(findings, ResultStatus.Passed),
                "Failed dominates warning and passed");
        }

        private static void ConstructorsRejectInvalidInput()
        {
            ExpectException<ArgumentException>(() => KeepAlive(new DesignOrderSteelGradeEntry(null, "1.2738", 1)), "Missing DO key");
            ExpectException<ArgumentOutOfRangeException>(() => KeepAlive(new DesignOrderSteelGradeEntry("X", "1.2738", 0)), "Invalid row number");
            ExpectException<ArgumentException>(() => KeepAlive(new CadComponentSteelGradeEvidence(null, null, null, 0, null, null)), "Missing CAD key");
            ExpectException<ArgumentOutOfRangeException>(() => KeepAlive(new CadComponentSteelGradeEvidence("X", "X", null, -1, null, null)), "Negative body count");

            ModelEntityReference[] referencesWithNull = new ModelEntityReference[1];
            ExpectException<ArgumentException>(
                () => KeepAlive(new CadComponentSteelGradeEvidence("X", "X", null, 0, null, referencesWithNull)),
                "Null reference");
        }

        private static void OptionalCollectionsDefaultToEmpty()
        {
            CadComponentSteelGradeEvidence evidence = new CadComponentSteelGradeEvidence(
                "X",
                null,
                null,
                0,
                null,
                null);

            AssertEqual("X", evidence.OriginalKey, "Blank original key falls back to component key");
            AssertEqual(0, evidence.AttributeGradeValues.Count, "Null attribute collection becomes empty");
            AssertEqual(0, evidence.BomMaterialValues.Count, "Null BOM collection becomes empty");
            AssertEqual(0, evidence.PlacementDescriptions.Count, "Null placement collection becomes empty");
            AssertEqual(0, evidence.EntityReferences.Count, "Null reference collection becomes empty");
            AssertEqual(false, evidence.HasBomEvidence, "Empty BOM evidence flag");
        }

        private static void EvaluateRejectsInvalidCollections()
        {
            ExpectException<ArgumentNullException>(() => SteelGradeDesignOrderEvaluation.Evaluate(null, Evidence(), Policy()), "Null entries");
            ExpectException<ArgumentNullException>(() => SteelGradeDesignOrderEvaluation.Evaluate(Entries(), null, Policy()), "Null evidence");
            ExpectException<ArgumentNullException>(() => SteelGradeDesignOrderEvaluation.Evaluate(Entries(), Evidence(), null), "Null policy");
            ExpectException<ArgumentException>(() => SteelGradeDesignOrderEvaluation.Evaluate(new DesignOrderSteelGradeEntry[] { null }, Evidence(), Policy()), "Null entry item");
            ExpectException<ArgumentException>(() => SteelGradeDesignOrderEvaluation.Evaluate(Entries(Entry("X", "1.2738", 1)), new CadComponentSteelGradeEvidence[] { null }, Policy()), "Null evidence item");
        }

        private static IReadOnlyList<Finding> Evaluate(
            IEnumerable<DesignOrderSteelGradeEntry> entries,
            IEnumerable<CadComponentSteelGradeEvidence> evidence)
        {
            return SteelGradeDesignOrderEvaluation.Evaluate(entries, evidence, Policy());
        }

        private static Finding Single(
            IEnumerable<DesignOrderSteelGradeEntry> entries,
            IEnumerable<CadComponentSteelGradeEvidence> evidence)
        {
            IReadOnlyList<Finding> findings = Evaluate(entries, evidence);
            AssertEqual(1, findings.Count, "Single finding count");
            return findings[0];
        }

        private static SteelGradeComparisonPolicy Policy()
        {
            return new SteelGradeComparisonPolicy(SteelGradeRepresentation.Strict, false);
        }

        private static DesignOrderSteelGradeEntry Entry(string key, string grade, int row)
        {
            return new DesignOrderSteelGradeEntry(key, grade, row);
        }

        private static DesignOrderSteelGradeEntry[] Entries(params DesignOrderSteelGradeEntry[] entries)
        {
            return entries;
        }

        private static CadComponentSteelGradeEvidence[] Evidence(params CadComponentSteelGradeEvidence[] evidence)
        {
            return evidence;
        }

        private static CadComponentSteelGradeEvidence Cad(
            string key,
            IEnumerable<string> attributeValues,
            ModelEntityReference reference = null,
            int bodyCount = 1,
            IEnumerable<string> bomValues = null)
        {
            return new CadComponentSteelGradeEvidence(
                key,
                key,
                attributeValues,
                bodyCount,
                new[] { "root/" + key },
                reference == null ? Array.Empty<ModelEntityReference>() : new[] { reference },
                bomValues);
        }

        private static void KeepAlive(object value)
        {
            GC.KeepAlive(value);
        }

        private static void AssertPrefix(string expectedPrefix, string actual, string label)
        {
            if (actual == null || !actual.StartsWith(expectedPrefix, StringComparison.Ordinal))
            {
                throw new InvalidOperationException($"{label}: expected prefix '{expectedPrefix}', actual '{actual}'.");
            }
        }

        private static void AssertEqual<T>(T expected, T actual, string label)
        {
            if (!Equals(expected, actual))
            {
                throw new InvalidOperationException($"{label}: expected '{expected}', actual '{actual}'.");
            }
        }

        private static void AssertSame(object expected, object actual, string label)
        {
            if (!ReferenceEquals(expected, actual))
            {
                throw new InvalidOperationException(label + " reference mismatch.");
            }
        }

        private static void ExpectException<TException>(Action action, string label)
            where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException)
            {
                return;
            }

            throw new InvalidOperationException(label + " did not throw " + typeof(TException).Name + ".");
        }
    }
}
