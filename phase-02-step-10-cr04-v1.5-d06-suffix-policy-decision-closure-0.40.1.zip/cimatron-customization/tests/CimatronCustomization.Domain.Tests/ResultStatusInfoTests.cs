using System;

namespace CimatronCustomization.Domain.Tests
{
    internal static class ResultStatusInfoTests
    {
        internal static void RunAll()
        {
            InfoIsDistinctAndDoesNotEscalatePassedAggregate();
        }

        private static void InfoIsDistinctAndDoesNotEscalatePassedAggregate()
        {
            if (ResultStatus.Info == ResultStatus.Passed ||
                ResultStatus.Info == ResultStatus.Succeeded ||
                ResultStatus.Info == ResultStatus.Warning ||
                ResultStatus.Info == ResultStatus.Error)
            {
                throw new InvalidOperationException("ResultStatus.Info must remain a distinct informational status.");
            }

            ResultStatus aggregate = FindingAggregation.Aggregate(
                new[] { new Finding("TEST", ResultStatus.Info, "Informational finding.") },
                ResultStatus.Passed);
            if (aggregate != ResultStatus.Passed)
                throw new InvalidOperationException("Informational findings must not escalate an otherwise Passed validation aggregate.");
        }
    }
}
