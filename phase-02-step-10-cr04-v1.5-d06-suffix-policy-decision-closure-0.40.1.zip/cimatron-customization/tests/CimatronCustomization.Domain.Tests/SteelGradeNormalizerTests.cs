using System;

namespace CimatronCustomization.Domain.Tests
{
    internal static class SteelGradeNormalizerTests
    {
        internal static void RunAll()
        {
            AbsentValuesRemainAbsent();
            WhitespaceIsTrimmedAndCollapsed();
            ComparisonIsCaseInsensitive();
            TokenModeKeepsOnlyFirstToken();
            StrictDesignOrderShortWerkstoffIsAmbiguous();
            StrictCadShortWerkstoffIsNotAmbiguous();
            WerkstoffCanonicalPadsToFourDecimals();
            WerkstoffCanonicalLeavesNamedGradesUnchanged();
            NormalizedGradeRejectsMissingValues();
            NormalizationRejectsMissingPolicy();
        }

        private static void AbsentValuesRemainAbsent()
        {
            SteelGradeComparisonPolicy policy = Strict(false);
            AssertTrue(SteelGradeNormalizer.NormalizeCad(null, policy).IsAbsent, "Null CAD grade absent");
            AssertTrue(SteelGradeNormalizer.NormalizeCad(" \t\u00A0 ", policy).IsAbsent, "Whitespace CAD grade absent");
            AssertTrue(SteelGradeNormalizer.NormalizeDesignOrder(null, policy).IsAbsent, "Null DO grade absent");
        }

        private static void WhitespaceIsTrimmedAndCollapsed()
        {
            SteelGradeNormalizationResult result = SteelGradeNormalizer.NormalizeCad(
                "  1.2738\t\u00A0  PCK  ",
                Strict(false));

            AssertEqual("1.2738 PCK", result.Grade.ComparisonKey, "Collapsed grade");
        }

        private static void ComparisonIsCaseInsensitive()
        {
            NormalizedSteelGrade left = SteelGradeNormalizer.NormalizeCad("NAK80", Strict(false)).Grade;
            NormalizedSteelGrade right = SteelGradeNormalizer.NormalizeCad("nak80", Strict(false)).Grade;
            AssertTrue(left.EqualsGrade(right), "Grade equality ignores case");
            AssertFalse(left.EqualsGrade(null), "Grade does not equal null");
        }

        private static void TokenModeKeepsOnlyFirstToken()
        {
            SteelGradeNormalizationResult result = SteelGradeNormalizer.NormalizeCad(
                "1.2738   PCK",
                Strict(true));

            AssertEqual("1.2738", result.Grade.ComparisonKey, "Token-only grade");
        }

        private static void StrictDesignOrderShortWerkstoffIsAmbiguous()
        {
            SteelGradeNormalizationResult result = SteelGradeNormalizer.NormalizeDesignOrder("1.208", Strict(false));
            AssertTrue(result.IsAmbiguousNumeric, "Strict short Werkstoff must be ambiguous on DO side");
            AssertSame(null, result.Grade, "Ambiguous result has no grade");
        }

        private static void StrictCadShortWerkstoffIsNotAmbiguous()
        {
            SteelGradeNormalizationResult result = SteelGradeNormalizer.NormalizeCad("1.208", Strict(false));
            AssertFalse(result.IsAmbiguousNumeric, "CAD side has no numeric-cell ambiguity guard");
            AssertEqual("1.208", result.Grade.ComparisonKey, "CAD short Werkstoff kept as text");
        }

        private static void WerkstoffCanonicalPadsToFourDecimals()
        {
            SteelGradeComparisonPolicy policy = new SteelGradeComparisonPolicy(
                SteelGradeRepresentation.WerkstoffCanonical,
                false);

            AssertEqual("1.2080", SteelGradeNormalizer.NormalizeDesignOrder("1.208", policy).Grade.ComparisonKey, "1.208 canonical");
            AssertEqual("1.2000", SteelGradeNormalizer.NormalizeCad("1.2", policy).Grade.ComparisonKey, "1.2 canonical");
            AssertTrue(
                SteelGradeNormalizer.NormalizeDesignOrder("1.208", policy).Grade.EqualsGrade(
                    SteelGradeNormalizer.NormalizeCad("1.2080", policy).Grade),
                "Canonical grades match");
        }

        private static void WerkstoffCanonicalLeavesNamedGradesUnchanged()
        {
            SteelGradeComparisonPolicy policy = new SteelGradeComparisonPolicy(
                SteelGradeRepresentation.WerkstoffCanonical,
                false);

            AssertEqual("P20", SteelGradeNormalizer.NormalizeCad("P20", policy).Grade.ComparisonKey, "P20 unchanged");
            AssertEqual("NAK80", SteelGradeNormalizer.NormalizeCad("NAK80", policy).Grade.ComparisonKey, "NAK80 unchanged");
            AssertEqual("H13", SteelGradeNormalizer.NormalizeCad("H13", policy).Grade.ComparisonKey, "H13 unchanged");
        }

        private static void NormalizedGradeRejectsMissingValues()
        {
            ExpectException<ArgumentException>(() => KeepAlive(new NormalizedSteelGrade(null, "X")), "Missing original grade");
            ExpectException<ArgumentException>(() => KeepAlive(new NormalizedSteelGrade("X", null)), "Missing comparison key");
            ExpectException<ArgumentNullException>(() => SteelGradeNormalizationResult.Success(null), "Missing normalized grade");
        }

        private static void NormalizationRejectsMissingPolicy()
        {
            ExpectException<ArgumentNullException>(() => SteelGradeNormalizer.NormalizeCad("1.2738", null), "Missing CAD policy");
            ExpectException<ArgumentNullException>(() => SteelGradeNormalizer.NormalizeDesignOrder("1.2738", null), "Missing DO policy");
        }

        private static SteelGradeComparisonPolicy Strict(bool tokenOnly)
        {
            return new SteelGradeComparisonPolicy(SteelGradeRepresentation.Strict, tokenOnly);
        }

        private static void KeepAlive(object value)
        {
            GC.KeepAlive(value);
        }

        private static void AssertTrue(bool value, string label)
        {
            if (!value)
            {
                throw new InvalidOperationException(label + " expected true.");
            }
        }

        private static void AssertFalse(bool value, string label)
        {
            if (value)
            {
                throw new InvalidOperationException(label + " expected false.");
            }
        }

        private static void AssertEqual<T>(T expected, T actual, string label)
        {
            if (!Equals(expected, actual))
            {
                throw new InvalidOperationException($"{label}: expected '{expected}', actual '{actual}'.");
            }
        }

        private static void AssertSame(object expected, object actual, string label)
        {
            if (!ReferenceEquals(expected, actual))
            {
                throw new InvalidOperationException(label + " reference mismatch.");
            }
        }

        private static void ExpectException<TException>(Action action, string label)
            where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException)
            {
                return;
            }

            throw new InvalidOperationException(label + " did not throw " + typeof(TException).Name + ".");
        }
    }
}
