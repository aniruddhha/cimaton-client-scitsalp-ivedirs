using System;
using System.Collections.Generic;
using System.Linq;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class VerifySteelGradeAgainstDesignOrderTests
    {
        private static readonly string[] SkipPartExclusions = { "SKIP_*" };

        private const string ComponentHeader = "Component";
        private const string GradeHeader = "Steel Grade";
        private const string GradeAttribute = "MATERIAL";
        private static readonly string[] StandardHeaders = { ComponentHeader, GradeHeader };
        private static readonly string[] ComponentOnlyHeaders = { ComponentHeader };
        private static readonly string[] GradeOnlyHeaders = { GradeHeader };

        internal static void RunAll()
        {
            SuccessfulMatchUsesPartMaterialAndReturnsPassed();
            BodyAttributeComponentKeyNameIsRequested();
            DiscoveryFailureStopsBeforeCadRead();
            MappingFailureStopsBeforeCadRead();
            ReadFailureStopsBeforeCadRead();
            ValidationFailureStopsBeforeCadRead();
            BlankGradeReachesDomainAndBecomesDoGradeMissing();
            MissingGradeHeaderIsReportedEvenThoughPerRowGradeIsOptional();
            CadSnapshotReadErrorBecomesErrorFinding();
            CadPortExceptionBecomesErrorFinding();
            SteelGradeAttributeReadErrorIsIgnoredWhenPartMaterialIsAvailable();
            PartMaterialReadErrorBecomesErrorFinding();
            BlankPartMaterialBecomesMissingFinding();
            SuppressedOccurrenceIsExcludedFromBusinessEvaluationButStillParticipatesInD15();
            MissingBodyAttributeDoesNotBlockPartMaterialMatch();
            ZeroBodyOccurrenceCanMatchPartMaterial();
            ProgrammingDefectIsNotRemappedToTabularFileReadError();
            FormModeUsesNativePartTypeAndPartMaterialForManyToOne();
            FormNoRequirementWithMappedComponentProducesNoGradeFinding();
            FormBlankPartTypeProducesWarning();
            FormBlankPartMaterialProducesError();
            FormWhitespaceAndCasePartTypeMaps();
            FormExclusionProducesInfo();
            FormNonPartOccurrenceIsSkippedBeforePartPropertyRead();
            FormSyntheticRootOccurrenceIsSkippedBeforePartPropertyRead();
            FormPartPropertyReadErrorRemainsError();
        }

        private static void SuccessfulMatchUsesPartMaterialAndReturnsPassed()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, GradeBody("ref:1", "1.2738"))));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(1, findings.Count, "Finding count");
            AssertEqual(ResultStatus.Passed, findings[0].Status, "Match status");
            AssertContains(findings[0].Message, "[STEEL_GRADE_MATCH]", "Match code");
            AssertEqual(GradeAttribute, assemblyReader.RequestedSteelGradeAttributeName, "Traversal compatibility attribute name");
            AssertEqual(1, assemblyReader.ReadCount, "CAD reader invocation");
        }

        private static void BodyAttributeComponentKeyNameIsRequested()
        {
            const string keyAttribute = "ITEM_NO";
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "ITEM-001", "1.2738")));
            BodyAttributeObservation body = new BodyAttributeObservation(
                new ModelEntityReference("ref:key"),
                AttributeObservationStatus.Present,
                "1.2738",
                null,
                AttributeObservationStatus.Present,
                "ITEM-001",
                null);
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, body)));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(
                Request(SteelGradeComponentKeySource.BodyAttribute, keyAttribute));

            AssertEqual(ResultStatus.Passed, findings[0].Status, "Attribute-key match status");
            AssertEqual(keyAttribute, assemblyReader.RequestedComponentKeyAttributeName, "Configured component-key attribute name");
        }

        private static void DiscoveryFailureStopsBeforeCadRead()
        {
            FakeTabularReader tableReader = FakeTabularReader.DiscoveryFailure(
                "TABULAR_FILE_NOT_FOUND",
                "The configured tabular input file does not exist.");
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot());

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "Tabular error status");
            AssertContains(findings[0].Message, "[TABULAR_FILE_NOT_FOUND]", "Tabular error code");
            AssertEqual(0, assemblyReader.ReadCount, "CAD reader not called");
        }

        private static void MappingFailureStopsBeforeCadRead()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                GradeOnlyHeaders,
                Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot());

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "Mapping error status");
            AssertContains(findings[0].Message, "[TABULAR_MAPPING_REQUIRED_HEADER_MISSING]", "Mapping error code");
            AssertEqual(0, assemblyReader.ReadCount, "CAD reader not called after mapping failure");
        }

        private static void ReadFailureStopsBeforeCadRead()
        {
            FakeTabularReader tableReader = FakeTabularReader.ReadFailure(
                "TABULAR_HEADERS_CHANGED",
                "Headers changed between discovery and read.");
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot());

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "Read error status");
            AssertContains(findings[0].Message, "[TABULAR_HEADERS_CHANGED]", "Read error code");
            AssertEqual(0, assemblyReader.ReadCount, "CAD reader not called after read failure");
        }

        private static void ValidationFailureStopsBeforeCadRead()
        {
            FakeTabularReader tableReader = FakeTabularReader.ValidationFailure();
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot());

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "Validation error status");
            AssertContains(findings[0].Message, "[TABULAR_MAPPING_VALUE_TYPE_MISMATCH]", "Validation error code");
            AssertEqual(0, assemblyReader.ReadCount, "CAD reader not called after validation failure");
        }

        private static void BlankGradeReachesDomainAndBecomesDoGradeMissing()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(RowWithBlankGrade(2, "Block_A")));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, GradeBody("ref:1", "1.2738"))));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "Blank grade status");
            AssertContains(findings[0].Message, "[DO_GRADE_MISSING]", "Blank grade Domain code");
            AssertEqual(0, assemblyReader.ReadCount, "CAD reader not called after Domain rejects blank grade");
        }

        private static void MissingGradeHeaderIsReportedEvenThoughPerRowGradeIsOptional()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                ComponentOnlyHeaders,
                Rows(new TabularRow(2, new Dictionary<string, TabularValue>
                {
                    ["ComponentKey"] = TabularValue.FromText("Block_A")
                })));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot());

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "Missing header status");
            AssertContains(findings[0].Message, "[TABULAR_MAPPING_REQUIRED_HEADER_MISSING]", "Missing grade header code");
            AssertEqual(0, assemblyReader.ReadCount, "CAD reader not called for invalid DO header");
        }

        private static void CadSnapshotReadErrorBecomesErrorFinding()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(
                AssemblyBodyAttributeSnapshot.ReadError("Cimatron assembly traversal failed."));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "CAD snapshot error status");
            AssertContains(findings[0].Message, "[CAD_READ_ERROR]", "CAD error code");
        }


        private static void CadPortExceptionBecomesErrorFinding()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(true);

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "CAD port exception status");
            AssertContains(findings[0].Message, "[CAD_READ_ERROR]", "CAD port exception code");
        }

        private static void SteelGradeAttributeReadErrorIsIgnoredWhenPartMaterialIsAvailable()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            ModelEntityReference reference = new ModelEntityReference("ref:error");
            BodyAttributeObservation body = new BodyAttributeObservation(
                reference,
                AttributeObservationStatus.ReadError,
                null,
                "Attribute lookup failed.",
                AttributeObservationStatus.Absent,
                null,
                null);
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, body)));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Passed, findings[0].Status, "Legacy steel-grade attribute read error ignored");
            AssertContains(findings[0].Message, "[STEEL_GRADE_MATCH]", "Part Material match code");
        }

        private static void PartMaterialReadErrorBecomesErrorFinding()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, GradeBody("ref:1", "ignored"))));
            FakeBomMaterialReader materialReader = new FakeBomMaterialReader(
                BomMaterialTableResult.ReadError("BOM material control failure."));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader, materialReader).Execute(Request());

            AssertEqual(ResultStatus.Error, findings[0].Status, "Part Material read error status");
            AssertContains(findings[0].Message, "[CAD_PART_MATERIAL_READ_ERROR]", "Part Material read error code");
        }

        private static void BlankPartMaterialBecomesMissingFinding()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, GradeBody("ref:1", "ignored"))));
            FakeBomMaterialReader materialReader = new FakeBomMaterialReader(
                BomMaterialTableResult.Succeeded(new[] { new BomMaterialRow("Block_A", string.Empty, 2) }));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader, materialReader).Execute(Request());

            AssertEqual(ResultStatus.Failed, findings[0].Status, "Blank Part Material status");
            AssertContains(findings[0].Message, "[STEEL_GRADE_ATTRIBUTE_MISSING]", "Backward-compatible missing-grade code");
        }

        private static void SuppressedOccurrenceIsExcludedFromBusinessEvaluationButStillParticipatesInD15()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            ModelEntityReference activeReference = new ModelEntityReference("ref:active");
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, GradeBody(activeReference.Value, "1.2738")),
                new AssemblyBodyAttributeOccurrence(
                    "root/1:5",
                    5,
                    "SuppressedControl",
                    "pid:suppressed",
                    true,
                    true,
                    Array.Empty<BodyAttributeObservation>())));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Passed, findings[0].Status, "Business comparison ignores suppressed control");
            AssertEqual(0, findings[0].EntityReferences.Count, "Suppressed collision makes active reference unsafe");
            AssertContains(findings[0].Message, "highlight unavailable", "D-15 message");
        }

        private static void MissingBodyAttributeDoesNotBlockPartMaterialMatch()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "Block_A", "1.2738")));
            ModelEntityReference reference = new ModelEntityReference("ref:absent");
            BodyAttributeObservation absent = new BodyAttributeObservation(
                reference,
                AttributeObservationStatus.Absent,
                null,
                null,
                AttributeObservationStatus.Absent,
                null,
                null);
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:5", 5, "Block_A", false, absent)));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader).Execute(Request());

            AssertEqual(ResultStatus.Passed, findings[0].Status, "Missing legacy body attribute does not block Part Material");
            AssertContains(findings[0].Message, "[STEEL_GRADE_MATCH]", "Part Material match code");
            if (findings.Any(finding => finding.Status == ResultStatus.Unsupported))
                throw new InvalidOperationException("Part Material production mode must not emit Unsupported from the ignored legacy body-attribute status.");
        }

        private static void ZeroBodyOccurrenceCanMatchPartMaterial()
        {
            FakeTabularReader tableReader = new FakeTabularReader(
                StandardHeaders,
                Rows(Row(2, "ZERO_BODY", "GRADE-Z")));
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:54", 54, "ZERO_BODY", false, Array.Empty<BodyAttributeObservation>())));
            FakeBomMaterialReader materialReader = new FakeBomMaterialReader(
                BomMaterialTableResult.Succeeded(new[] { new BomMaterialRow("ZERO_BODY", "GRADE-Z", 2) }));

            IReadOnlyList<Finding> findings = CreateUseCase(tableReader, assemblyReader, materialReader).Execute(Request());

            AssertEqual(ResultStatus.Passed, findings[0].Status, "Zero-body Part Material match status");
            AssertContains(findings[0].Message, "[STEEL_GRADE_MATCH]", "Zero-body Part Material match code");
        }

        private static void ProgrammingDefectIsNotRemappedToTabularFileReadError()
        {
            ThrowingHeaderReader reader = new ThrowingHeaderReader();
            ReadMappedTabularData readMapped = new ReadMappedTabularData(reader, reader, new TabularMappingEngine());
            VerifySteelGradeAgainstDesignOrder useCase = new VerifySteelGradeAgainstDesignOrder(
                readMapped,
                new FakeAssemblyReader(Snapshot()),
                new FakeBomMaterialReader(DefaultPartMaterials()),
                new DesignOrderInputPathResolver());

            try
            {
                useCase.Execute(Request());
            }
            catch (InvalidOperationException exception)
            {
                AssertContains(exception.Message, "programming defect", "Programming defect propagated");
                return;
            }

            throw new InvalidOperationException("DF-06 application-boundary test expected the programming defect to propagate rather than become TABULAR_FILE_READ_ERROR.");
        }


        private static void FormModeUsesNativePartTypeAndPartMaterialForManyToOne()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:1", 1, "Opaque_A", false, GradeBody("ref:cav-a", "IGNORED")),
                Occurrence("root/0:2", 2, "Opaque_B", false, GradeBody("ref:cav-b", "IGNORED"))));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-001", FormCategory("Cavity", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>
            {
                ["pid:root/0:1"] = PartDocumentPropertyResult.Succeeded("Cavity", "GRADE-A"),
                ["pid:root/0:2"] = PartDocumentPropertyResult.Succeeded("Cavity", "GRADE-A")
            });

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));

            Finding match = findings.Single(finding => finding.Message.IndexOf("[STEEL_GRADE_MATCH]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Passed, match.Status, "Form many-to-one match status");
            AssertEqual(2, match.EntityReferences.Count, "Form many-to-one reference count");
            AssertEqual(2, match.ComponentContexts.Count, "Form many-to-one export context count");
            AssertEqual("Opaque_A", match.ComponentContexts[0].ComponentTitle, "First export component title");
            AssertEqual("root/0:1", match.ComponentContexts[0].OccurrencePath, "First export occurrence path");
            AssertEqual(1, match.ComponentContexts[0].InstanceId, "First export instance id");
            AssertEqual(0, match.ComponentContexts[0].OccurrenceOrder, "First export occurrence order");
            AssertEqual("Cavity", match.ComponentContexts[0].PartType, "First export Part Type");
            AssertEqual("GRADE-A", match.ComponentContexts[0].PartMaterial, "First export Part Material");
            AssertEqual("Opaque_B", match.ComponentContexts[1].ComponentTitle, "Second export component title");
            AssertEqual(1, match.ComponentContexts[1].OccurrenceOrder, "Second export occurrence order");
            Finding mouldInfo = findings.Single(finding => finding.Message.IndexOf("[MOULD_NUMBER_CHECK_NOT_PERFORMED]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Info, mouldInfo.Status, "Mould-number informational status");
            AssertEqual(2, properties.ReadCount, "Native Part-property reads");
        }

        private static void FormNoRequirementWithMappedComponentProducesNoGradeFinding()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(Occurrence("root/0:1", 1, "Opaque", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-002", FormCategory("Cavity", string.Empty, "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>
            {
                ["pid:root/0:1"] = PartDocumentPropertyResult.Succeeded("Cavity", string.Empty)
            });

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));

            if (findings.Any(finding => finding.Message.IndexOf("[DO_GRADE_MISSING]", StringComparison.Ordinal) >= 0 || finding.Message.IndexOf("[CAD_PART_MATERIAL_MISSING]", StringComparison.Ordinal) >= 0))
                throw new InvalidOperationException("A Form row with no selected family and blank Remark must create no steel-grade requirement.");
        }

        private static void FormBlankPartTypeProducesWarning()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(Occurrence("root/0:1", 1, "Opaque", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-003", FormCategory("Cavity", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>
            {
                ["pid:root/0:1"] = PartDocumentPropertyResult.Succeeded("   ", "GRADE-A")
            });

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));
            Finding warning = findings.Single(finding => finding.Message.IndexOf("[CAD_PART_TYPE_MISSING]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Warning, warning.Status, "Blank Part Type status");
            AssertEqual(1, warning.ComponentContexts.Count, "Blank Part Type export context count");
            AssertEqual("Opaque", warning.ComponentContexts[0].ComponentTitle, "Blank Part Type export component title");
            AssertEqual("GRADE-A", warning.ComponentContexts[0].PartMaterial, "Blank Part Type export material");
        }

        private static void FormBlankPartMaterialProducesError()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(Occurrence("root/0:1", 1, "Opaque", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-004", FormCategory("Cavity", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>
            {
                ["pid:root/0:1"] = PartDocumentPropertyResult.Succeeded("Cavity", "   ")
            });

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));
            Finding error = findings.Single(finding => finding.Message.IndexOf("[CAD_PART_MATERIAL_MISSING]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Error, error.Status, "Blank Part Material status");
        }

        private static void FormWhitespaceAndCasePartTypeMaps()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(Occurrence("root/0:1", 1, "Opaque", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-005", FormCategory("CavityInsert", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>
            {
                ["pid:root/0:1"] = PartDocumentPropertyResult.Succeeded("  cavity    insert  ", " GRADE-A ")
            });

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));
            Finding match = findings.Single(finding => finding.Message.IndexOf("[STEEL_GRADE_MATCH]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Passed, match.Status, "Whitespace/case Part Type match status");
        }

        private static void FormExclusionProducesInfo()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(Occurrence("root/0:1", 1, "SKIP_PART", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-006", FormCategory("Cavity", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>());

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(SkipPartExclusions));

            Finding info = findings.Single(finding => finding.Message.IndexOf("[CAD_COMPONENT_EXCLUDED]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Info, info.Status, "Excluded component informational status");
            AssertEqual(0, properties.ReadCount, "Excluded occurrence must not invoke native Part-property reader");
        }

        private static void FormNonPartOccurrenceIsSkippedBeforePartPropertyRead()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:1", 1, "Nested Assembly", "cmAssembly", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-007", FormCategory("Cavity", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>());

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));

            Finding info = findings.Single(finding => finding.Message.IndexOf("[CAD_NON_PART_SKIPPED]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Info, info.Status, "Non-Part occurrence informational status");
            AssertContains(info.Message, "cmAssembly", "Non-Part occurrence model type evidence");
            AssertEqual(1, info.ComponentContexts.Count, "Non-Part export context count");
            AssertEqual("Nested Assembly", info.ComponentContexts[0].ComponentTitle, "Non-Part export component title");
            AssertEqual("root/0:1", info.ComponentContexts[0].OccurrencePath, "Non-Part export occurrence path");
            AssertEqual(0, properties.ReadCount, "Non-Part occurrence must not invoke native Part-property reader");
        }

        private static void FormSyntheticRootOccurrenceIsSkippedBeforePartPropertyRead()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:3", 3, "AMPL_123_top_assm_MD", @"\\5\Root.elt", "cmPart", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-008", FormCategory("Cavity", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>());

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));

            Finding info = findings.Single(finding => finding.Message.IndexOf("[CAD_SYNTHETIC_ROOT_SKIPPED]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Info, info.Status, "Synthetic Root.elt occurrence informational status");
            AssertContains(info.Message, "Root.elt", "Synthetic Root.elt occurrence evidence");
            AssertEqual(0, properties.ReadCount, "Synthetic Root.elt occurrence must not invoke native Part-property reader");
        }

        private static void FormPartPropertyReadErrorRemainsError()
        {
            FakeTabularReader tableReader = new FakeTabularReader(StandardHeaders, Array.Empty<TabularRow>());
            FakeAssemblyReader assemblyReader = new FakeAssemblyReader(Snapshot(
                Occurrence("root/0:1", 1, "Cavity block", "cmPart", false)));
            FakeFormReader formReader = new FakeFormReader(FormResult("MOULD-008", FormCategory("Cavity", "GRADE-A", "GRADE-A")));
            FakePartPropertyReader properties = new FakePartPropertyReader(new Dictionary<string, PartDocumentPropertyResult>
            {
                ["pid:root/0:1"] = PartDocumentPropertyResult.Error("CAD_PART_PROPERTY_READ_ERROR", "Controlled Part read failure.")
            });

            IReadOnlyList<Finding> findings = CreateFormUseCase(tableReader, formReader, assemblyReader, properties).Execute(FormRequest(Array.Empty<string>()));

            Finding error = findings.Single(finding => finding.Message.IndexOf("[CAD_PART_PROPERTY_READ_ERROR]", StringComparison.Ordinal) >= 0);
            AssertEqual(ResultStatus.Error, error.Status, "Genuine Part property-read failure status");
            AssertContains(error.Message, "Controlled Part read failure", "Genuine Part property-read failure detail");
            AssertEqual(1, properties.ReadCount, "cmPart occurrence must invoke native Part-property reader");
        }

        private static VerifySteelGradeAgainstDesignOrder CreateFormUseCase(
            FakeTabularReader tabularReader,
            FakeFormReader formReader,
            FakeAssemblyReader assemblyReader,
            FakePartPropertyReader partPropertyReader)
        {
            return new VerifySteelGradeAgainstDesignOrder(
                new ReadMappedTabularData(tabularReader, tabularReader, new TabularMappingEngine()),
                formReader,
                assemblyReader,
                new FakeBomMaterialReader(DefaultPartMaterials()),
                partPropertyReader,
                new DesignOrderInputPathResolver());
        }

        private static VerifySteelGradeAgainstDesignOrderRequest FormRequest(IEnumerable<string> exclusions)
        {
            return new VerifySteelGradeAgainstDesignOrderRequest(
                @"C:\Data\CR04\DesignOrder.xlsx",
                GradeAttribute,
                new SteelGradeComparisonPolicy(SteelGradeRepresentation.Strict, false),
                FormProfile(),
                exclusions);
        }

        private static DesignOrderFormProfile FormProfile()
        {
            return new DesignOrderFormProfile(
                "TEST_PROFILE",
                "Sheet1",
                39,
                0,
                "TEST REV 01",
                5,
                14,
                new[]
                {
                    new DesignOrderFormCategoryDefinition("Cavity", "Cavity", "Cavity", 18, 0, 8, "CC", 14, 26),
                    new DesignOrderFormCategoryDefinition("CavityInsert", "Cavity Insert", "Cavity Insert", 20, 0, 8, "CC", 14, 26)
                });
        }

        private static DesignOrderFormReadResult FormResult(string mouldNumber, params DesignOrderFormCategoryRecord[] categories)
        {
            return DesignOrderFormReadResult.Succeeded("TEST_PROFILE", "TEST REV 01", mouldNumber, categories);
        }

        private static DesignOrderFormCategoryRecord FormCategory(string categoryKey, string grade, params string[] permittedGrades)
        {
            string selectedFamily = string.IsNullOrWhiteSpace(grade) ? string.Empty : "P-20";
            return new DesignOrderFormCategoryRecord(categoryKey, categoryKey, 18, selectedFamily, grade, (grade ?? string.Empty).Trim(), permittedGrades);
        }

        private static VerifySteelGradeAgainstDesignOrder CreateUseCase(
            FakeTabularReader tabularReader,
            FakeAssemblyReader assemblyReader)
        {
            return new VerifySteelGradeAgainstDesignOrder(
                new ReadMappedTabularData(tabularReader, tabularReader, new TabularMappingEngine()),
                assemblyReader,
                new FakeBomMaterialReader(DefaultPartMaterials()),
                new DesignOrderInputPathResolver());
        }

        private static VerifySteelGradeAgainstDesignOrder CreateUseCase(
            FakeTabularReader tabularReader,
            FakeAssemblyReader assemblyReader,
            FakeBomMaterialReader materialReader)
        {
            return new VerifySteelGradeAgainstDesignOrder(
                new ReadMappedTabularData(tabularReader, tabularReader, new TabularMappingEngine()),
                assemblyReader,
                materialReader,
                new DesignOrderInputPathResolver());
        }

        private static BomMaterialTableResult DefaultPartMaterials()
        {
            return BomMaterialTableResult.Succeeded(new[]
            {
                new BomMaterialRow("Block_A", "1.2738", 2),
                new BomMaterialRow("CAV_A", "GRADE-A", 3),
                new BomMaterialRow("CAV_B", "GRADE-A", 4),
                new BomMaterialRow("SKIP_PART", "GRADE-A", 5)
            });
        }

        private static VerifySteelGradeAgainstDesignOrderRequest Request()
        {
            return Request(SteelGradeComponentKeySource.ModelTitle, null);
        }

        private static VerifySteelGradeAgainstDesignOrderRequest Request(
            SteelGradeComponentKeySource componentKeySource,
            string componentKeyAttributeName)
        {
            return new VerifySteelGradeAgainstDesignOrderRequest(
                @"C:\Data\CR04\DesignOrder.xlsx",
                "Input Sheet",
                1,
                ComponentHeader,
                GradeHeader,
                GradeAttribute,
                componentKeySource,
                componentKeyAttributeName,
                new SteelGradeComparisonPolicy(SteelGradeRepresentation.Strict, false));
        }

        private static AssemblyBodyAttributeSnapshot Snapshot(params AssemblyBodyAttributeOccurrence[] occurrences)
        {
            return AssemblyBodyAttributeSnapshot.Succeeded(occurrences ?? Array.Empty<AssemblyBodyAttributeOccurrence>());
        }

        private static AssemblyBodyAttributeOccurrence Occurrence(
            string path,
            int instanceId,
            string modelTitle,
            bool suppressed,
            params BodyAttributeObservation[] bodies)
        {
            return Occurrence(path, instanceId, modelTitle, "cmPart", suppressed, bodies);
        }

        private static AssemblyBodyAttributeOccurrence Occurrence(
            string path,
            int instanceId,
            string modelTitle,
            string modelType,
            bool suppressed,
            params BodyAttributeObservation[] bodies)
        {
            return Occurrence(path, instanceId, modelTitle, "pid:" + path, modelType, suppressed, bodies);
        }

        private static AssemblyBodyAttributeOccurrence Occurrence(
            string path,
            int instanceId,
            string modelTitle,
            string modelPid,
            string modelType,
            bool suppressed,
            params BodyAttributeObservation[] bodies)
        {
            return new AssemblyBodyAttributeOccurrence(
                path,
                instanceId,
                modelTitle,
                modelPid,
                modelType,
                suppressed,
                suppressed,
                bodies ?? Array.Empty<BodyAttributeObservation>());
        }

        private static BodyAttributeObservation GradeBody(string reference, string grade)
        {
            return new BodyAttributeObservation(
                new ModelEntityReference(reference),
                AttributeObservationStatus.Present,
                grade,
                null,
                AttributeObservationStatus.Absent,
                null,
                null);
        }

        private static TabularRow[] Rows(params TabularRow[] rows)
        {
            return rows;
        }

        private static TabularRow Row(int sourceRowNumber, string component, string grade)
        {
            return new TabularRow(sourceRowNumber, new Dictionary<string, TabularValue>
            {
                ["ComponentKey"] = TabularValue.FromText(component),
                ["SteelGrade"] = TabularValue.FromText(grade)
            });
        }

        private static TabularRow RowWithBlankGrade(int sourceRowNumber, string component)
        {
            return new TabularRow(sourceRowNumber, new Dictionary<string, TabularValue>
            {
                ["ComponentKey"] = TabularValue.FromText(component)
            });
        }

        private static void AssertContains(string actual, string expectedFragment, string scenario)
        {
            if (actual == null || actual.IndexOf(expectedFragment, StringComparison.OrdinalIgnoreCase) < 0)
                throw new InvalidOperationException(scenario + " expected fragment '" + expectedFragment + "' in '" + actual + "'.");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }

        private sealed class FakeAssemblyReader : IAssemblyBodyAttributeReader
        {
            private readonly AssemblyBodyAttributeSnapshot snapshot;
            private readonly bool throwOnRead;

            internal FakeAssemblyReader(AssemblyBodyAttributeSnapshot snapshot)
            {
                this.snapshot = snapshot;
            }

            internal FakeAssemblyReader(bool throwOnRead)
            {
                this.throwOnRead = throwOnRead;
            }

            internal int ReadCount { get; private set; }
            internal string RequestedSteelGradeAttributeName { get; private set; }
            internal string RequestedComponentKeyAttributeName { get; private set; }

            public AssemblyBodyAttributeSnapshot ReadNamedAttributes(
                string steelGradeAttributeName,
                string componentKeyAttributeName)
            {
                ReadCount++;
                RequestedSteelGradeAttributeName = steelGradeAttributeName;
                RequestedComponentKeyAttributeName = componentKeyAttributeName;
                if (throwOnRead)
                    throw new InvalidOperationException("COM/runtime control");
                return snapshot;
            }
        }


        private sealed class FakePartPropertyReader : IPartDocumentPropertyReader
        {
            private readonly IReadOnlyDictionary<string, PartDocumentPropertyResult> results;

            internal FakePartPropertyReader(IReadOnlyDictionary<string, PartDocumentPropertyResult> results)
            {
                this.results = results ?? throw new ArgumentNullException(nameof(results));
            }

            internal int ReadCount { get; private set; }

            public PartDocumentPropertyResult Read(string modelPid)
            {
                ReadCount++;
                return results.TryGetValue(modelPid, out PartDocumentPropertyResult result)
                    ? result
                    : PartDocumentPropertyResult.Error("CAD_PART_PROPERTY_READ_ERROR", "No fake native Part-property result was configured for " + modelPid + ".");
            }
        }


        private sealed class FakeBomMaterialReader : IBomMaterialTableReader
        {
            private readonly BomMaterialTableResult result;

            internal FakeBomMaterialReader(BomMaterialTableResult result)
            {
                this.result = result;
            }

            internal int ReadCount { get; private set; }

            public BomMaterialTableResult ReadMaterialTable()
            {
                ReadCount++;
                return result;
            }
        }


        private sealed class FakeFormReader : IDesignOrderFormReader
        {
            private readonly DesignOrderFormReadResult result;

            internal FakeFormReader(DesignOrderFormReadResult result)
            {
                this.result = result;
            }

            internal int ReadCount { get; private set; }

            public DesignOrderFormReadResult Read(string filePath, DesignOrderFormProfile profile)
            {
                ReadCount++;
                return result;
            }
        }

        private sealed class FakeTabularReader : ITabularHeaderReader, ITabularDataReader
        {
            private readonly TabularHeaderDiscoveryResult discovery;
            private readonly TabularRow[] rows;
            private readonly TabularReadResult explicitReadResult;

            internal FakeTabularReader(string[] headers, TabularRow[] rows)
            {
                discovery = TabularHeaderDiscoveryResult.Succeeded(headers);
                this.rows = rows;
            }

            private FakeTabularReader(
                TabularHeaderDiscoveryResult discovery,
                TabularReadResult explicitReadResult)
            {
                this.discovery = discovery;
                this.explicitReadResult = explicitReadResult;
                rows = Array.Empty<TabularRow>();
            }

            internal static FakeTabularReader DiscoveryFailure(string code, string message)
            {
                return new FakeTabularReader(
                    TabularHeaderDiscoveryResult.Error(code, message),
                    null);
            }

            internal static FakeTabularReader ReadFailure(string code, string message)
            {
                return new FakeTabularReader(
                    TabularHeaderDiscoveryResult.Succeeded(StandardHeaders),
                    TabularReadResult.Error(code, message));
            }

            internal static FakeTabularReader ValidationFailure()
            {
                TabularSourceDefinition source = new TabularSourceDefinition(
                    @"C:\Data\CR04\DesignOrder.xlsx",
                    "Input Sheet",
                    1,
                    new[]
                    {
                        new TabularColumnDefinition("ComponentKey", ComponentHeader, TabularValueType.Decimal, true),
                        new TabularColumnDefinition("SteelGrade", GradeHeader, TabularValueType.Text, false)
                    });
                TabularRow row = new TabularRow(2, new Dictionary<string, TabularValue>
                {
                    ["ComponentKey"] = TabularValue.FromDecimal(1m),
                    ["SteelGrade"] = TabularValue.FromText("1.2738")
                });
                return new FakeTabularReader(
                    TabularHeaderDiscoveryResult.Succeeded(StandardHeaders),
                    TabularReadResult.Succeeded(new TabularTable(source, new[] { row })));
            }

            public TabularHeaderDiscoveryResult DiscoverHeaders(TabularHeaderSourceDefinition source)
            {
                return discovery;
            }

            public TabularReadResult Read(TabularSourceDefinition source)
            {
                return BuildRead(source);
            }

            public TabularReadResult Read(TabularSourceDefinition source, IReadOnlyList<string> expectedHeaders)
            {
                return BuildRead(source);
            }

            private TabularReadResult BuildRead(TabularSourceDefinition source)
            {
                return explicitReadResult ?? TabularReadResult.Succeeded(new TabularTable(source, rows));
            }
        }

        private sealed class ThrowingHeaderReader : ITabularHeaderReader, ITabularDataReader
        {
            public TabularHeaderDiscoveryResult DiscoverHeaders(TabularHeaderSourceDefinition source)
            {
                throw new InvalidOperationException("programming defect control");
            }

            public TabularReadResult Read(TabularSourceDefinition source)
            {
                throw new InvalidOperationException("programming defect control");
            }

            public TabularReadResult Read(TabularSourceDefinition source, IReadOnlyList<string> expectedHeaders)
            {
                throw new InvalidOperationException("programming defect control");
            }
        }
    }
}
