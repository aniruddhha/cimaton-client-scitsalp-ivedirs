using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class TopLevelHighlightTargetSelectorTests
    {
        internal static void RunAll()
        {
            UniqueCandidateSelected();
            LowestUniqueIdChosenWhenTwoAreUnique();
            SuppressedCollisionRejectsCandidate();
            NoUniqueCandidateFailsClosed();
            NestedLowerIdDoesNotBeatTopLevelCandidate();
        }

        private static void UniqueCandidateSelected()
        {
            TopLevelHighlightTargetSelection result = Select(Occurrence(12, 0, "KA-PART-1", false));
            AssertEqual(12, result.SelectedInstanceId.Value, "Unique candidate");
        }

        private static void LowestUniqueIdChosenWhenTwoAreUnique()
        {
            TopLevelHighlightTargetSelection result = Select(
                Occurrence(13, 0, "KA-PART-1", false),
                Occurrence(12, 0, "KA-PART-1", false));
            AssertEqual(12, result.SelectedInstanceId.Value, "Lowest unique candidate");
        }

        private static void SuppressedCollisionRejectsCandidate()
        {
            TopLevelHighlightTargetSelection result = Select(
                Occurrence(12, 0, "KA-PART-1", false),
                Occurrence(12, 1, "SuppressedControl", true));
            AssertTrue(!result.IsSelected, "Suppressed collider rejects candidate");
            AssertEqual(1, result.RepeatedInstanceIds.Count, "Repeated ID count");
        }

        private static void NoUniqueCandidateFailsClosed()
        {
            TopLevelHighlightTargetSelection result = Select(
                Occurrence(12, 0, "KA-PART-1", false),
                Occurrence(12, 1, "Other", false));
            AssertTrue(!result.IsSelected, "No unique candidate");
            AssertContains(result.FailureMessage, "[TOPLEVEL_HIGHLIGHT_NO_SAFE_CANDIDATE]", "Stable failure prefix");
        }

        private static void NestedLowerIdDoesNotBeatTopLevelCandidate()
        {
            TopLevelHighlightTargetSelection result = Select(
                Occurrence(2, 1, "KA-PART-1", false),
                Occurrence(12, 0, "KA-PART-1", false));
            AssertEqual(12, result.SelectedInstanceId.Value, "Top-level candidate wins over nested lower ID");
        }

        private static TopLevelHighlightTargetSelection Select(params TopLevelHighlightCandidateOccurrence[] occurrences)
        {
            return TopLevelHighlightTargetSelector.Select(occurrences, "KA-PART-1");
        }

        private static TopLevelHighlightCandidateOccurrence Occurrence(int id, int depth, string title, bool suppressed)
        {
            return new TopLevelHighlightCandidateOccurrence(id, depth, title, suppressed);
        }

        private static void AssertContains(string actual, string fragment, string scenario)
        {
            if (actual == null || actual.IndexOf(fragment, StringComparison.Ordinal) < 0)
                throw new InvalidOperationException(scenario + " expected '" + fragment + "' in '" + actual + "'.");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }

        private static void AssertTrue(bool condition, string scenario)
        {
            if (!condition) throw new InvalidOperationException(scenario + " expected true.");
        }
    }
}
