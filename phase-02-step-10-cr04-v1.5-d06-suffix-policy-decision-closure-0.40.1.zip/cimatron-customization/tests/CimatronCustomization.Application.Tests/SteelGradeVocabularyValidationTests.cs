using System;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class SteelGradeVocabularyValidationTests
    {
        private static readonly string[] DoosanVocabulary = { "P-20-2311 Doosan" };
        private static readonly string[] DesignOrderVocabulary = { "CK-45", "EN-31" };
        private static readonly string[] BaseP20Vocabulary = { "P-20-2311" };

        internal static void RunAll()
        {
            StrictVocabularyAcceptsWhitespaceNormalizedExactValue();
            StrictVocabularyRejectsUnknownDesignOrderValue();
            StrictFullValueComparisonDoesNotStripSuffix();
        }

        private static void StrictVocabularyAcceptsWhitespaceNormalizedExactValue()
        {
            SteelGradeComparisonPolicy policy = new SteelGradeComparisonPolicy(SteelGradeRepresentation.Strict, false);
            bool known = SteelGradeVocabularyValidation.IsKnownCadValue(
                "  P-20-2311   Doosan ",
                DoosanVocabulary,
                policy);
            Assert(known, "Whitespace-normalized known CAD grade should be accepted.");
        }

        private static void StrictVocabularyRejectsUnknownDesignOrderValue()
        {
            SteelGradeComparisonPolicy policy = new SteelGradeComparisonPolicy(SteelGradeRepresentation.Strict, false);
            bool known = SteelGradeVocabularyValidation.IsKnownDesignOrderValue(
                "EN-353",
                DesignOrderVocabulary,
                policy);
            Assert(!known, "Unknown Design-Order grade must be rejected by the closed vocabulary.");
        }

        private static void StrictFullValueComparisonDoesNotStripSuffix()
        {
            SteelGradeComparisonPolicy policy = new SteelGradeComparisonPolicy(SteelGradeRepresentation.Strict, false);
            bool known = SteelGradeVocabularyValidation.IsKnownCadValue(
                "P-20-2311 PCK",
                BaseP20Vocabulary,
                policy);
            Assert(!known, "CompareGradeTokenOnly=false must not strip suffixes during vocabulary validation.");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition)
                throw new InvalidOperationException(message);
        }
    }
}
