using System;
using System.Collections.Generic;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class SteelGradeOccurrenceHighlightSafetyTests
    {
        internal static void RunAll()
        {
            RepeatedInstanceIdAcrossFullTraversalRemovesUnsafeReferenceAndPreservesStatus();
            SuppressedAndZeroBodyOccurrencesParticipateInUniqueness();
            UniqueReferenceRemainsUnchanged();
        }

        private static void RepeatedInstanceIdAcrossFullTraversalRemovesUnsafeReferenceAndPreservesStatus()
        {
            ModelEntityReference unsafeReference = new ModelEntityReference("occurrence:5/body:4");
            AssemblyBodyAttributeSnapshot snapshot = AssemblyBodyAttributeSnapshot.Succeeded(new[]
            {
                Occurrence("root/0:5", 5, false, unsafeReference),
                Occurrence("root/1:5", 5, false, new ModelEntityReference("occurrence:5b/body:4"))
            });
            Finding source = new Finding("CR-04", ResultStatus.Failed, "[STEEL_GRADE_MISMATCH] mismatch", entityReferences: new[] { unsafeReference });

            IReadOnlyList<Finding> result = SteelGradeOccurrenceHighlightSafety.Apply(new[] { source }, snapshot);

            AssertEqual(ResultStatus.Failed, result[0].Status, "Business status preserved");
            AssertEqual(0, result[0].EntityReferences.Count, "Unsafe reference removed");
            AssertContains(result[0].Message, "highlight unavailable", "Ambiguous highlight explanation");
        }

        private static void SuppressedAndZeroBodyOccurrencesParticipateInUniqueness()
        {
            ModelEntityReference candidateReference = new ModelEntityReference("candidate/body:4");
            AssemblyBodyAttributeSnapshot snapshot = AssemblyBodyAttributeSnapshot.Succeeded(new[]
            {
                Occurrence("root/0:7", 7, false, candidateReference),
                new AssemblyBodyAttributeOccurrence(
                    "root/1:7",
                    7,
                    "SuppressedControl",
                    "pid:suppressed",
                    true,
                    true,
                    Array.Empty<BodyAttributeObservation>())
            });
            Finding source = new Finding("CR-04", ResultStatus.Passed, "[STEEL_GRADE_MATCH] match", entityReferences: new[] { candidateReference });

            IReadOnlyList<Finding> result = SteelGradeOccurrenceHighlightSafety.Apply(new[] { source }, snapshot);

            AssertEqual(0, result[0].EntityReferences.Count, "Suppressed zero-body collision participates");
            AssertContains(result[0].Message, "highlight unavailable", "Suppressed collision explanation");
        }

        private static void UniqueReferenceRemainsUnchanged()
        {
            ModelEntityReference reference = new ModelEntityReference("unique/body:4");
            AssemblyBodyAttributeSnapshot snapshot = AssemblyBodyAttributeSnapshot.Succeeded(new[]
            {
                Occurrence("root/0:9", 9, false, reference)
            });
            Finding source = new Finding("CR-04", ResultStatus.Warning, "[CAD_COMPONENT_NOT_IN_DO] warning", entityReferences: new[] { reference });

            IReadOnlyList<Finding> result = SteelGradeOccurrenceHighlightSafety.Apply(new[] { source }, snapshot);

            AssertEqual(1, result[0].EntityReferences.Count, "Unique reference preserved");
            AssertEqual(source.Message, result[0].Message, "Message unchanged when safe");
        }

        private static AssemblyBodyAttributeOccurrence Occurrence(
            string path,
            int instanceId,
            bool suppressed,
            ModelEntityReference reference)
        {
            return new AssemblyBodyAttributeOccurrence(
                path,
                instanceId,
                "Block_A",
                "pid:" + path,
                suppressed,
                suppressed,
                new[]
                {
                    new BodyAttributeObservation(
                        reference,
                        AttributeObservationStatus.Present,
                        "1.2738",
                        null,
                        AttributeObservationStatus.Absent,
                        null,
                        null)
                });
        }

        private static void AssertContains(string actual, string expectedFragment, string scenario)
        {
            if (actual == null || actual.IndexOf(expectedFragment, StringComparison.OrdinalIgnoreCase) < 0)
                throw new InvalidOperationException(scenario + " expected fragment '" + expectedFragment + "' in '" + actual + "'.");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }
    }
}
