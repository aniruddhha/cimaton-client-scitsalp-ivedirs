using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class PartTypeCategoryResolverTests
    {
        internal static void RunAll()
        {
            TrimsCollapsesAndIgnoresCase();
            MapsPressurePadToMisspelledProductionRow();
            BlankPartTypeDoesNotResolve();
            UnknownPartTypeDoesNotResolve();
        }

        private static void TrimsCollapsesAndIgnoresCase()
        {
            bool resolved = PartTypeCategoryResolver.TryResolve(
                "  cavity   INSERT  ",
                Categories(),
                out string categoryKey,
                out string normalized);

            Assert(resolved, "Whitespace/case normalized Part Type should resolve.");
            AssertEqual("CavityInsert", categoryKey, "Resolved category");
            AssertEqual("cavity INSERT", normalized, "Normalized Part Type preserves original case while collapsing whitespace");
        }

        private static void MapsPressurePadToMisspelledProductionRow()
        {
            bool resolved = PartTypeCategoryResolver.TryResolve("Pressure Pad", Categories(), out string categoryKey, out _);
            Assert(resolved, "Pressure Pad should resolve.");
            AssertEqual("PressurePad", categoryKey, "Pressure Pad logical key");
        }

        private static void BlankPartTypeDoesNotResolve()
        {
            bool resolved = PartTypeCategoryResolver.TryResolve("   ", Categories(), out _, out string normalized);
            Assert(!resolved, "Blank Part Type must not resolve.");
            AssertEqual(string.Empty, normalized, "Blank normalized Part Type");
        }

        private static void UnknownPartTypeDoesNotResolve()
        {
            bool resolved = PartTypeCategoryResolver.TryResolve("Other", Categories(), out _, out _);
            Assert(!resolved, "Unknown Part Type must not resolve.");
        }

        private static DesignOrderFormCategoryDefinition[] Categories()
        {
            return new[]
            {
                new DesignOrderFormCategoryDefinition("CavityInsert", "Cavity Insert", "Cavity Insert", 20, 0, 8, "CC", 14, 26),
                new DesignOrderFormCategoryDefinition("PressurePad", "Pressuer Pad", "Pressure Pad", 24, 0, 8, "CB", 29, 31)
            };
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }
    }
}
