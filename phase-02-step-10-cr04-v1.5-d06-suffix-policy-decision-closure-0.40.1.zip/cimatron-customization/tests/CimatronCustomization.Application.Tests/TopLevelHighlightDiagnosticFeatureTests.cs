using System;
using System.Collections.Generic;
using CimatronCustomization.Application;
using CimatronCustomization.DesignChecks;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class TopLevelHighlightDiagnosticFeatureTests
    {
        private static readonly int[] ReadyCandidateInstanceIds = { 12, 13 };
        private static readonly int[] TraversedInstanceIds = { 3, 5, 6 };
        private static readonly int[] FailClosedCandidateInstanceIds = { 6 };

        internal static void RunAll()
        {
            DefinitionExposesGovernedDiagnosticMetadata();
            ConstructorRejectsNullReader();
            ReadyFindingIsPassedButDoesNotClaimVisualConfirmation();
            ErrorResultIsContractErrorWithNoReference();
            PassedResultWithNullReferenceIsContractError();
            PassedResultWithNotEvaluatedMutationIsContractError();
            ChangedMutationIsContractErrorWithNoReference();
            NullExecutionContextIsRejected();
            NullDiagnosticIdCollectionsFormatAsEmpty();
        }

        private static void DefinitionExposesGovernedDiagnosticMetadata()
        {
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(null));
            FeatureDefinition definition = feature.Definition;

            AssertEqual(TopLevelHighlightDiagnosticFeature.FeatureId, definition.Id, "Feature id");
            AssertEqual("CR-04 Slice 2A Top-Level Highlight Diagnostic", definition.Name, "Feature name");
            AssertEqual(FeatureKind.Validation, definition.Kind, "Feature kind");
            AssertEqual("Developer Diagnostics", definition.FunctionalGroup, "Functional group");
            AssertEqual(DocumentContextRequirement.Assembly, definition.RequiredDocumentContext, "Document context");
            AssertEqual(true, definition.IsReadOnly, "Read-only intent");
            AssertEqual(2, definition.RequirementIds.Count, "Requirement count");
            AssertEqual("CR-04", definition.RequirementIds[0], "Requirement 0");
            AssertEqual("D-15", definition.RequirementIds[1], "Requirement 1");
        }

        private static void ConstructorRejectsNullReader()
        {
            try
            {
                GC.KeepAlive(new TopLevelHighlightDiagnosticFeature(null));
                throw new InvalidOperationException("Null reader should be rejected.");
            }
            catch (ArgumentNullException ex)
            {
                AssertEqual("reader", ex.ParamName, "Null reader parameter");
            }
        }

        private static void ReadyFindingIsPassedButDoesNotClaimVisualConfirmation()
        {
            ModelEntityReference reference = new ModelEntityReference("entity|12|cGlk|4");
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(
                new TopLevelHighlightDiagnosticResult(ResultStatus.Passed, "Ready.", 13, ReadyCandidateInstanceIds, TraversedInstanceIds, 12, reference, TopLevelHighlightNoMutationState.Unchanged)));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Passed, outcome.Status, "Ready status");
            AssertEqual(1, outcome.Findings.Count, "One finding");
            AssertEqual(1, outcome.Findings[0].EntityReferences.Count, "One reference");
            AssertContains(outcome.Findings[0].Message, "[TOPLEVEL_HIGHLIGHT_TARGET_READY]", "Ready prefix");
            AssertContains(outcome.Findings[0].Message, "ProgrammaticNoMutation=PASS", "No-mutation evidence");
            AssertContains(outcome.Findings[0].Message, "Highlight is NOT confirmed by this finding", "C-03 wording");
        }

        private static void ErrorResultIsContractErrorWithNoReference()
        {
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(
                new TopLevelHighlightDiagnosticResult(ResultStatus.Error, "[TOPLEVEL_HIGHLIGHT_NO_SAFE_CANDIDATE] no candidate.", 13, FailClosedCandidateInstanceIds, TraversedInstanceIds, null, null, TopLevelHighlightNoMutationState.Unchanged)));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Error, outcome.Status, "Error status");
            AssertEqual(0, outcome.Findings[0].EntityReferences.Count, "No unsafe reference");
            AssertContains(outcome.Findings[0].Message, "[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR]", "Contract error prefix");
            AssertContains(outcome.Findings[0].Message, "[TOPLEVEL_HIGHLIGHT_NO_SAFE_CANDIDATE]", "Reader detail retained");
        }

        private static void PassedResultWithNullReferenceIsContractError()
        {
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(
                new TopLevelHighlightDiagnosticResult(ResultStatus.Passed, "Missing reference.", 13, ReadyCandidateInstanceIds, TraversedInstanceIds, 12, null, TopLevelHighlightNoMutationState.Unchanged)));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Error, outcome.Status, "Passed plus null reference status");
            AssertEqual(0, outcome.Findings[0].EntityReferences.Count, "Passed plus null reference must fail closed");
            AssertContains(outcome.Findings[0].Message, "[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR]", "Passed plus null reference contract error");
        }

        private static void PassedResultWithNotEvaluatedMutationIsContractError()
        {
            ModelEntityReference reference = new ModelEntityReference("entity|12|cGlk|4");
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(
                new TopLevelHighlightDiagnosticResult(ResultStatus.Passed, "Mutation not evaluated.", 13, ReadyCandidateInstanceIds, TraversedInstanceIds, 12, reference, TopLevelHighlightNoMutationState.NotEvaluated)));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Error, outcome.Status, "Not-evaluated mutation status");
            AssertEqual(0, outcome.Findings[0].EntityReferences.Count, "Not-evaluated mutation must remove reference");
            AssertContains(outcome.Findings[0].Message, "[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR]", "Not-evaluated mutation contract error");
            AssertContains(outcome.Findings[0].Message, "ProgrammaticNoMutation=NOT_EVALUATED", "Not-evaluated evidence");
        }

        private static void ChangedMutationIsContractErrorWithNoReference()
        {
            ModelEntityReference reference = new ModelEntityReference("entity|12|cGlk|4");
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(
                new TopLevelHighlightDiagnosticResult(ResultStatus.Passed, "Mutation changed.", 13, ReadyCandidateInstanceIds, TraversedInstanceIds, 12, reference, TopLevelHighlightNoMutationState.Changed)));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Error, outcome.Status, "Changed mutation status");
            AssertEqual(0, outcome.Findings[0].EntityReferences.Count, "Changed mutation must remove reference");
            AssertContains(outcome.Findings[0].Message, "[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR]", "Changed mutation contract error");
            AssertContains(outcome.Findings[0].Message, "ProgrammaticNoMutation=CHANGED", "Changed mutation evidence");
        }

        private static void NullExecutionContextIsRejected()
        {
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(null));
            try
            {
                feature.Execute(null);
                throw new InvalidOperationException("Null execution context should be rejected.");
            }
            catch (ArgumentNullException ex)
            {
                AssertEqual("context", ex.ParamName, "Null execution context parameter");
            }
        }

        private static void NullDiagnosticIdCollectionsFormatAsEmpty()
        {
            ModelEntityReference reference = new ModelEntityReference("entity|12|cGlk|4");
            TopLevelHighlightDiagnosticFeature feature = new TopLevelHighlightDiagnosticFeature(new FakeReader(
                new TopLevelHighlightDiagnosticResult(ResultStatus.Passed, "Ready.", 13, null, null, 12, reference, TopLevelHighlightNoMutationState.Unchanged)));
            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Passed, outcome.Status, "Null diagnostic id collection status");
            AssertContains(outcome.Message, "CandidateInstanceIds=[]", "Null candidate ids format");
            AssertContains(outcome.Message, "RepeatedInstanceIds=[]", "Null repeated ids format");
        }

        private static FeatureExecutionContext CreateContext()
        {
            return new FeatureExecutionContext(
                "correlation",
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly));
        }

        private sealed class FakeReader : ITopLevelHighlightDiagnosticReader
        {
            private readonly TopLevelHighlightDiagnosticResult result;
            internal FakeReader(TopLevelHighlightDiagnosticResult result) { this.result = result; }
            public TopLevelHighlightDiagnosticResult Read(string expectedAssemblyTitle, string expectedModelTitle, string attributeName, string attributeValue, string expectedAttributeType) { return result; }
        }

        private static void AssertContains(string actual, string fragment, string scenario)
        {
            if (actual == null || actual.IndexOf(fragment, StringComparison.Ordinal) < 0)
                throw new InvalidOperationException(scenario + " expected '" + fragment + "' in '" + actual + "'.");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }
    }
}
