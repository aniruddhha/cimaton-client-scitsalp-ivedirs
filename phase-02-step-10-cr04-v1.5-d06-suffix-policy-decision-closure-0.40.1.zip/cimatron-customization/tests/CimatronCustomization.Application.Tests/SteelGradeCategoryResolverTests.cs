using System;
using System.Collections.Generic;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class SteelGradeCategoryResolverTests
    {
        private static readonly string[] CavityAndCoreCategories = { "Cavity", "Core" };
        private static readonly string[] CoreCategories = { "Core" };
        private static readonly string[] SkipCoreExclusions = { "SKIP_*" };
        private static readonly string[] CoreAndMovingCoreCategories = { "Core", "MovingCore" };

        internal static void RunAll()
        {
            CategoryAttributeTakesPrecedenceOverModelTitlePattern();
            UnknownCategoryAttributeDoesNotFallBackToModelTitle();
            ExclusionIsResolvedBeforeModelTitleMappingWhenAttributeIsAbsent();
            MultipleCategoryMatchesAreAmbiguous();
            UnmatchedModelTitleIsUnmapped();
        }

        private static void CategoryAttributeTakesPrecedenceOverModelTitlePattern()
        {
            AssemblyBodyAttributeOccurrence occurrence = Occurrence(
                "CORE_A",
                Body("ref:1", AttributeObservationStatus.Present, "Cavity"));
            SteelGradeCategoryMappingConfiguration configuration = Configuration(
                "CATEGORY",
                new[] { new SteelGradeCategoryPattern("Core", "CORE_*") },
                Array.Empty<string>());

            SteelGradeCategoryResolution resolution = SteelGradeCategoryResolver.Resolve(
                occurrence,
                configuration,
                CavityAndCoreCategories);

            AssertEqual(SteelGradeCategoryResolutionKind.Mapped, resolution.Kind, "Attribute precedence kind");
            AssertEqual("Cavity", resolution.CategoryKey, "Attribute precedence category");
        }

        private static void UnknownCategoryAttributeDoesNotFallBackToModelTitle()
        {
            AssemblyBodyAttributeOccurrence occurrence = Occurrence(
                "CORE_A",
                Body("ref:2", AttributeObservationStatus.Present, "UnknownCategory"));
            SteelGradeCategoryMappingConfiguration configuration = Configuration(
                "CATEGORY",
                new[] { new SteelGradeCategoryPattern("Core", "CORE_*") },
                Array.Empty<string>());

            SteelGradeCategoryResolution resolution = SteelGradeCategoryResolver.Resolve(
                occurrence,
                configuration,
                CoreCategories);

            AssertEqual(SteelGradeCategoryResolutionKind.UnknownAttributeCategory, resolution.Kind, "Unknown attribute category kind");
        }

        private static void ExclusionIsResolvedBeforeModelTitleMappingWhenAttributeIsAbsent()
        {
            AssemblyBodyAttributeOccurrence occurrence = Occurrence(
                "SKIP_CORE",
                Body("ref:3", AttributeObservationStatus.Absent, null));
            SteelGradeCategoryMappingConfiguration configuration = Configuration(
                "CATEGORY",
                new[] { new SteelGradeCategoryPattern("Core", "*_CORE") },
                SkipCoreExclusions);

            SteelGradeCategoryResolution resolution = SteelGradeCategoryResolver.Resolve(
                occurrence,
                configuration,
                CoreCategories);

            AssertEqual(SteelGradeCategoryResolutionKind.Excluded, resolution.Kind, "Exclusion kind");
        }

        private static void MultipleCategoryMatchesAreAmbiguous()
        {
            AssemblyBodyAttributeOccurrence occurrence = Occurrence(
                "PART_CORE_A",
                Body("ref:4", AttributeObservationStatus.Absent, null));
            SteelGradeCategoryMappingConfiguration configuration = Configuration(
                null,
                new[]
                {
                    new SteelGradeCategoryPattern("Core", "*CORE*"),
                    new SteelGradeCategoryPattern("MovingCore", "PART_*")
                },
                Array.Empty<string>());

            SteelGradeCategoryResolution resolution = SteelGradeCategoryResolver.Resolve(
                occurrence,
                configuration,
                CoreAndMovingCoreCategories);

            AssertEqual(SteelGradeCategoryResolutionKind.Ambiguous, resolution.Kind, "Ambiguous mapping kind");
        }

        private static void UnmatchedModelTitleIsUnmapped()
        {
            AssemblyBodyAttributeOccurrence occurrence = Occurrence(
                "OTHER",
                Body("ref:5", AttributeObservationStatus.Absent, null));

            SteelGradeCategoryResolution resolution = SteelGradeCategoryResolver.Resolve(
                occurrence,
                Configuration(null, new[] { new SteelGradeCategoryPattern("Core", "CORE_*") }, Array.Empty<string>()),
                CoreCategories);

            AssertEqual(SteelGradeCategoryResolutionKind.Unmapped, resolution.Kind, "Unmapped kind");
        }

        private static SteelGradeCategoryMappingConfiguration Configuration(
            string attributeName,
            IEnumerable<SteelGradeCategoryPattern> patterns,
            IEnumerable<string> exclusions)
        {
            return new SteelGradeCategoryMappingConfiguration(attributeName, patterns, exclusions);
        }

        private static AssemblyBodyAttributeOccurrence Occurrence(string modelTitle, params BodyAttributeObservation[] bodies)
        {
            return new AssemblyBodyAttributeOccurrence("root/0:1", 1, modelTitle, "pid:1", false, false, bodies);
        }

        private static BodyAttributeObservation Body(
            string reference,
            AttributeObservationStatus categoryStatus,
            string categoryValue)
        {
            return new BodyAttributeObservation(
                new ModelEntityReference(reference),
                AttributeObservationStatus.Present,
                "GRADE-A",
                null,
                categoryStatus,
                categoryValue,
                null);
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }
    }
}
