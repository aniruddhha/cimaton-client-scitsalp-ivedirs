using System;
using System.Collections.Generic;
using CimatronCustomization.Application;
using CimatronCustomization.DesignChecks;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class SteelGradeDesignOrderValidationFeatureTests
    {
        internal static void RunAll()
        {
            DefinitionMatchesCr04Contract();
            PublicConstructorAcceptsConfiguredUseCase();
            PublicConstructorRejectsNullUseCase();
            InternalTestSeamRejectsNullValidationDelegate();
            ValidTableParametersCreatePartMaterialRequest();
            ValidFormParametersCreateApprovedV15Request();
            MissingRuntimeDesignOrderPathFailsBeforeApplicationUseCase();
            InvalidDesignOrderFormatFailsBeforeApplicationUseCase();
            InvalidSteelGradeSourceFailsBeforeApplicationUseCase();
            InvalidTableComponentKeySourceFailsBeforeApplicationUseCase();
            TableAttributeKeyRequiresAttributeName();
            FormRequiresComposedProfile();
            FormProfileMustMatchComposedProfile();
            FormCategorySourceMustMatchApprovedValue();
            FormDoesNotRequireCategoryPatterns();
            FormPreservesOptionalExclusionPatterns();
            ExclusionListIgnoresEmptyEntries();
            InvalidRepresentationFailsBeforeApplicationUseCase();
            NullExecutionContextIsRejected();
            NullApplicationFindingsAreRejected();
            MissingTableWorksheetFailsBeforeApplicationUseCase();
            MissingTableHeaderRowFailsBeforeApplicationUseCase();
            MissingTableComponentHeaderFailsBeforeApplicationUseCase();
            MissingTableSteelGradeHeaderFailsBeforeApplicationUseCase();
            MissingTableComponentKeySourceFailsBeforeApplicationUseCase();
            MissingFormProfileParameterFailsBeforeApplicationUseCase();
            MissingFormCategorySourceFailsBeforeApplicationUseCase();
            FindingSeverityIsAggregated();
            PartContextIsNotApplicableThroughRegisteredExecutionPipeline();
        }

        private static void DefinitionMatchesCr04Contract()
        {
            SteelGradeDesignOrderValidation feature = Feature(_ => Array.Empty<Finding>());
            FeatureDefinition definition = feature.Definition;

            AssertEqual(SteelGradeDesignOrderValidation.FeatureId, definition.Id, "Feature id");
            AssertEqual("Steel Grade Design-Order Validation", definition.Name, "Feature name");
            AssertEqual(FeatureKind.Validation, definition.Kind, "Feature kind");
            AssertEqual("Design Checks", definition.FunctionalGroup, "Functional group");
            AssertEqual(DocumentContextRequirement.Assembly, definition.RequiredDocumentContext, "Document context");
            AssertEqual(true, definition.IsReadOnly, "Read-only intent");
            AssertEqual(1, definition.RequirementIds.Count, "Requirement count");
            AssertEqual("CR-04", definition.RequirementIds[0], "Requirement id");
            AssertEqual(16, definition.RuleParameterDefinitions.Count, "Parameter count");
        }

        private static void PublicConstructorAcceptsConfiguredUseCase()
        {
            VerifySteelGradeAgainstDesignOrder useCase = new VerifySteelGradeAgainstDesignOrder(
                new ReadMappedTabularData(new NeverHeaderReader(), new NeverDataReader(), new TabularMappingEngine()),
                new NeverAssemblyReader(),
                new NeverBomReader(),
                new DesignOrderInputPathResolver());

            SteelGradeDesignOrderValidation feature = new SteelGradeDesignOrderValidation(useCase);

            AssertEqual(SteelGradeDesignOrderValidation.FeatureId, feature.Definition.Id, "Configured public constructor feature id");
            AssertEqual(true, feature.Definition.IsReadOnly, "Configured public constructor read-only intent");
        }

        private static void PublicConstructorRejectsNullUseCase()
        {
            try
            {
                GC.KeepAlive(new SteelGradeDesignOrderValidation((VerifySteelGradeAgainstDesignOrder)null));
                throw new InvalidOperationException("Null application use case should be rejected.");
            }
            catch (ArgumentNullException exception)
            {
                AssertEqual("validation", exception.ParamName, "Null use-case parameter");
            }
        }

        private static void InternalTestSeamRejectsNullValidationDelegate()
        {
            try
            {
                GC.KeepAlive(new SteelGradeDesignOrderValidation(
                    (Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>>)null));
                throw new InvalidOperationException("Null validation delegate should be rejected.");
            }
            catch (ArgumentNullException exception)
            {
                AssertEqual("executeValidation", exception.ParamName, "Null delegate parameter");
            }
        }

        private static void ValidTableParametersCreatePartMaterialRequest()
        {
            VerifySteelGradeAgainstDesignOrderRequest observed = null;
            SteelGradeDesignOrderValidation feature = Feature(request =>
            {
                observed = request;
                return new[] { new Finding("CR-04", ResultStatus.Passed, "Compared.") };
            });

            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Table",
                componentKeySource: "Attribute",
                componentKeyAttributeName: "ITEM_NO",
                representation: "WerkstoffCanonical",
                compareTokenOnly: true)));

            AssertEqual(ResultStatus.Passed, outcome.Status, "Outcome status");
            Assert(observed != null, "Application request captured");
            AssertEqual(DesignOrderFormat.Table, observed.DesignOrderFormat, "DO format");
            AssertEqual(@"C:\Orders\M123_DO.xlsx", observed.DesignOrderFilePath, "DO path");
            AssertEqual("Input Sheet", observed.WorksheetName, "Worksheet");
            AssertEqual(2, observed.HeaderRowNumber, "Header row");
            AssertEqual("Component", observed.ComponentKeyHeader, "Component header");
            AssertEqual("Steel Grade", observed.SteelGradeHeader, "Grade header");
            AssertContains(observed.SteelGradeAttributeName, "TRAVERSAL_ONLY", "Production request uses traversal-only placeholder rather than configured steel-grade attribute");
            AssertEqual(SteelGradeComponentKeySource.BodyAttribute, observed.ComponentKeySource, "Key source");
            AssertEqual("ITEM_NO", observed.ComponentKeyAttributeName, "Key attribute");
            AssertEqual(SteelGradeRepresentation.WerkstoffCanonical, observed.ComparisonPolicy.Representation, "Representation");
            AssertEqual(true, observed.ComparisonPolicy.CompareGradeTokenOnly, "Token policy");
        }

        private static void ValidFormParametersCreateApprovedV15Request()
        {
            VerifySteelGradeAgainstDesignOrderRequest observed = null;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(request =>
            {
                observed = request;
                return new[] { new Finding("CR-04", ResultStatus.Passed, "Compared.") };
            }, profile);

            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                steelGradeAttributeName: "STEEL_GRADE",
                designOrderProfile: profile.ProfileId,
                categorySource: "PartType",
                exclusionPatterns: "BOLT-*;SCREW-*",
                representation: "Strict",
                compareTokenOnly: false)));

            AssertEqual(ResultStatus.Passed, outcome.Status, "Outcome status");
            Assert(observed != null, "Application request captured");
            AssertEqual(DesignOrderFormat.Form, observed.DesignOrderFormat, "DO format");
            AssertEqual(profile, observed.FormProfile, "Form profile");
            AssertContains(observed.SteelGradeAttributeName, "TRAVERSAL_ONLY", "Form request uses traversal-only placeholder rather than STEEL_GRADE");
            AssertEqual(SteelGradeRepresentation.Strict, observed.ComparisonPolicy.Representation, "Representation");
            AssertEqual(false, observed.ComparisonPolicy.CompareGradeTokenOnly, "Token policy");
            AssertEqual(2, observed.ComponentExclusionPatterns.Count, "Exclusion count");
        }

        private static void MissingRuntimeDesignOrderPathFailsBeforeApplicationUseCase()
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(), null));
            AssertEqual(ResultStatus.Error, outcome.Status, "Missing runtime path status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "DesignOrderPath", "Run input named");
            AssertContains(outcome.Message, "browse/select", "Browse instruction named");
        }

        private static void InvalidDesignOrderFormatFailsBeforeApplicationUseCase()
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(format: "Csv")));
            AssertEqual(ResultStatus.Error, outcome.Status, "Invalid format status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "DesignOrderFormat", "Parameter named");
            AssertContains(outcome.Message, "Table", "Table allowed value named");
            AssertContains(outcome.Message, "Form", "Form allowed value named");
        }

        private static void InvalidSteelGradeSourceFailsBeforeApplicationUseCase()
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(steelGradeSource: "BodyAttribute")));
            AssertEqual(ResultStatus.Error, outcome.Status, "Invalid source status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "SteelGradeSource", "Parameter named");
            AssertContains(outcome.Message, "PartMaterial", "Allowed value named");
        }

        private static void InvalidTableComponentKeySourceFailsBeforeApplicationUseCase()
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(componentKeySource: "BomStandardNumber")));
            AssertEqual(ResultStatus.Error, outcome.Status, "Invalid key source status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "ComponentKeySource", "Parameter named");
        }

        private static void TableAttributeKeyRequiresAttributeName()
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                componentKeySource: "Attribute",
                componentKeyAttributeName: null)));
            AssertEqual(ResultStatus.Error, outcome.Status, "Missing key attribute status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "ComponentKeyAttributeName", "Parameter named");
        }

        private static void FormRequiresComposedProfile()
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: "Sridevi_QR-DG-02_REV04",
                categoryPatterns: "Cavity=CAV-*")));
            AssertEqual(ResultStatus.Error, outcome.Status, "Missing composed profile status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "DesignOrderProfile", "Parameter named");
            AssertContains(outcome.Message, "no Form profile", "Composition failure named");
        }

        private static void FormProfileMustMatchComposedProfile()
        {
            bool called = false;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); }, profile);
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: "Wrong_Profile",
                categoryPatterns: "Cavity=CAV-*")));
            AssertEqual(ResultStatus.Error, outcome.Status, "Profile mismatch status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, profile.ProfileId, "Approved profile named");
        }

        private static void FormCategorySourceMustMatchApprovedValue()
        {
            bool called = false;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); }, profile);
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: profile.ProfileId,
                categorySource: "ModelTitleWithOptionalAttributeOverride",
                categoryPatterns: "Cavity=CAV-*")));
            AssertEqual(ResultStatus.Error, outcome.Status, "Category source status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "ComponentCategorySource", "Parameter named");
            AssertContains(outcome.Message, "PartType", "Approved source named");
        }

        private static void FormDoesNotRequireCategoryPatterns()
        {
            VerifySteelGradeAgainstDesignOrderRequest observed = null;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(request =>
            {
                observed = request;
                return new[] { new Finding("CR-04", ResultStatus.Passed, "Compared.") };
            }, profile);

            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: profile.ProfileId,
                categorySource: "PartType",
                categoryPatterns: null)));

            AssertEqual(ResultStatus.Passed, outcome.Status, "Part Type Form configuration status");
            Assert(observed != null, "Application request captured");
            AssertEqual(0, observed.ComponentExclusionPatterns.Count, "No exclusions by default");
        }

        private static void FormPreservesOptionalExclusionPatterns()
        {
            VerifySteelGradeAgainstDesignOrderRequest observed = null;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(request =>
            {
                observed = request;
                return new[] { new Finding("CR-04", ResultStatus.Passed, "Compared.") };
            }, profile);

            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: profile.ProfileId,
                categorySource: "PartType",
                exclusionPatterns: "Assist*;IGNORE_*")));

            AssertEqual(ResultStatus.Passed, outcome.Status, "Part Type Form exclusions status");
            Assert(observed != null, "Application request captured");
            AssertEqual(2, observed.ComponentExclusionPatterns.Count, "Exclusion count");
            AssertEqual("Assist*", observed.ComponentExclusionPatterns[0], "First exclusion preserved");
        }

        private static void ExclusionListIgnoresEmptyEntries()
        {
            VerifySteelGradeAgainstDesignOrderRequest observed = null;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(request =>
            {
                observed = request;
                return new[] { new Finding("CR-04", ResultStatus.Passed, "Compared.") };
            }, profile);

            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: profile.ProfileId,
                categorySource: "PartType",
                exclusionPatterns: "A;;B;")));

            AssertEqual(ResultStatus.Passed, outcome.Status, "Separator-only exclusion entries status");
            Assert(observed != null, "Application request captured");
            AssertEqual(2, observed.ComponentExclusionPatterns.Count, "Filtered exclusion count");
            AssertEqual("A", observed.ComponentExclusionPatterns[0], "First filtered exclusion");
            AssertEqual("B", observed.ComponentExclusionPatterns[1], "Second filtered exclusion");
        }

        private static void InvalidRepresentationFailsBeforeApplicationUseCase()
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(representation: "Loose")));
            AssertEqual(ResultStatus.Error, outcome.Status, "Invalid representation status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, "SteelGradeRepresentation", "Parameter named");
            AssertContains(outcome.Message, "WerkstoffCanonical", "Allowed value named");
        }


        private static void NullExecutionContextIsRejected()
        {
            SteelGradeDesignOrderValidation feature = Feature(_ => Array.Empty<Finding>());
            try
            {
                feature.Execute(null);
                throw new InvalidOperationException("Null execution context should be rejected.");
            }
            catch (ArgumentNullException exception)
            {
                AssertEqual("context", exception.ParamName, "Null context parameter");
            }
        }

        private static void NullApplicationFindingsAreRejected()
        {
            SteelGradeDesignOrderValidation feature = Feature(_ => null);
            try
            {
                feature.Execute(Context(Parameters()));
                throw new InvalidOperationException("Null application findings should be rejected.");
            }
            catch (InvalidOperationException exception)
            {
                AssertContains(exception.Message, "returned no findings collection", "Null findings failure");
            }
        }

        private static void MissingTableWorksheetFailsBeforeApplicationUseCase()
        {
            AssertMissingRequiredTableParameter(SteelGradeDesignOrderValidation.DesignOrderWorksheetNameParameter);
        }

        private static void MissingTableHeaderRowFailsBeforeApplicationUseCase()
        {
            AssertMissingRequiredTableParameter(SteelGradeDesignOrderValidation.DesignOrderHeaderRowParameter);
        }

        private static void MissingTableComponentHeaderFailsBeforeApplicationUseCase()
        {
            AssertMissingRequiredTableParameter(SteelGradeDesignOrderValidation.DesignOrderComponentKeyHeaderParameter);
        }

        private static void MissingTableSteelGradeHeaderFailsBeforeApplicationUseCase()
        {
            AssertMissingRequiredTableParameter(SteelGradeDesignOrderValidation.DesignOrderSteelGradeHeaderParameter);
        }

        private static void MissingTableComponentKeySourceFailsBeforeApplicationUseCase()
        {
            AssertMissingRequiredTableParameter(SteelGradeDesignOrderValidation.ComponentKeySourceParameter);
        }

        private static void MissingFormProfileParameterFailsBeforeApplicationUseCase()
        {
            bool called = false;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); }, profile);
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: profile.ProfileId,
                categorySource: "PartType",
                omittedParameterName: SteelGradeDesignOrderValidation.DesignOrderProfileParameter)));

            AssertEqual(ResultStatus.Error, outcome.Status, "Missing Form profile parameter status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, SteelGradeDesignOrderValidation.DesignOrderProfileParameter, "Missing Form profile parameter named");
        }

        private static void MissingFormCategorySourceFailsBeforeApplicationUseCase()
        {
            bool called = false;
            DesignOrderFormProfile profile = FormProfile();
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); }, profile);
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(
                format: "Form",
                designOrderProfile: profile.ProfileId,
                categorySource: "PartType",
                omittedParameterName: SteelGradeDesignOrderValidation.ComponentCategorySourceParameter)));

            AssertEqual(ResultStatus.Error, outcome.Status, "Missing Form category-source status");
            AssertEqual(false, called, "Application use case not called");
            AssertContains(outcome.Message, SteelGradeDesignOrderValidation.ComponentCategorySourceParameter, "Missing category-source parameter named");
        }

        private static void AssertMissingRequiredTableParameter(string parameterName)
        {
            bool called = false;
            SteelGradeDesignOrderValidation feature = Feature(_ => { called = true; return Array.Empty<Finding>(); });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters(omittedParameterName: parameterName)));

            AssertEqual(ResultStatus.Error, outcome.Status, "Missing Table parameter status for " + parameterName);
            AssertEqual(false, called, "Application use case not called for " + parameterName);
            AssertContains(outcome.Message, parameterName, "Missing Table parameter named");
        }

        private static void FindingSeverityIsAggregated()
        {
            SteelGradeDesignOrderValidation feature = Feature(_ => new[]
            {
                new Finding("CR-04", ResultStatus.Passed, "Pass."),
                new Finding("CR-04", ResultStatus.Failed, "Mismatch.")
            });
            FeatureExecutionOutcome outcome = feature.Execute(Context(Parameters()));
            AssertEqual(ResultStatus.Failed, outcome.Status, "Aggregate status");
            AssertEqual(2, outcome.Findings.Count, "Finding count");
        }

        private static void PartContextIsNotApplicableThroughRegisteredExecutionPipeline()
        {
            SteelGradeDesignOrderValidation feature = Feature(_ => throw new InvalidOperationException("Feature must not execute for Part context."));
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[] { feature });
            ExecuteRegisteredFeature executor = new ExecuteRegisteredFeature(
                registry,
                new NullLogger(),
                "0.34.0",
                new FixedParameterProvider(Parameters()));

            FeatureExecutionReport report = executor.Execute(
                SteelGradeDesignOrderValidation.FeatureId,
                new FeatureExecutionContext("corr", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)),
                "2026.0");

            AssertEqual(ResultStatus.NotApplicable, report.Status, "Part context status");
        }

        private static SteelGradeDesignOrderValidation Feature(
            Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>> execute,
            DesignOrderFormProfile profile = null)
        {
            return new SteelGradeDesignOrderValidation(execute, profile);
        }

        private static FeatureExecutionContext Context(
            RuleParameterSet parameters,
            string designOrderPath = @"C:\Orders\M123_DO.xlsx")
        {
            FeatureRunInputs runInputs = designOrderPath == null
                ? new FeatureRunInputs()
                : new FeatureRunInputs(new Dictionary<string, object>
                {
                    { SteelGradeDesignOrderValidation.DesignOrderPathRunInput, designOrderPath }
                });

            return new FeatureExecutionContext(
                "corr",
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly),
                parameters,
                runInputs);
        }

        private static RuleParameterSet Parameters(
            string format = "Table",
            string steelGradeSource = "PartMaterial",
            string steelGradeAttributeName = "MATERIAL",
            string componentKeySource = "ModelTitle",
            string componentKeyAttributeName = null,
            string designOrderProfile = null,
            string categorySource = "PartType",
            string categoryAttributeName = null,
            string categoryPatterns = null,
            string exclusionPatterns = null,
            string representation = "Strict",
            bool compareTokenOnly = false,
            string omittedParameterName = null)
        {
            FeatureDefinition definition = Feature(_ => Array.Empty<Finding>()).Definition;
            List<RuleParameterValue> values = new List<RuleParameterValue>();
            foreach (RuleParameterDefinition parameter in definition.RuleParameterDefinitions)
            {
                string raw = null;
                object value = null;
                bool include = true;

                switch (parameter.Name)
                {
                    case SteelGradeDesignOrderValidation.DesignOrderFormatParameter: raw = format; value = raw; break;
                    case SteelGradeDesignOrderValidation.DesignOrderProfileParameter: raw = designOrderProfile; value = raw; include = raw != null; break;
                    case SteelGradeDesignOrderValidation.DesignOrderWorksheetNameParameter: raw = "Input Sheet"; value = raw; include = string.Equals(format, "Table", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.DesignOrderHeaderRowParameter: raw = "2"; value = 2; include = string.Equals(format, "Table", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.DesignOrderComponentKeyHeaderParameter: raw = "Component"; value = raw; include = string.Equals(format, "Table", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.DesignOrderSteelGradeHeaderParameter: raw = "Steel Grade"; value = raw; include = string.Equals(format, "Table", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.SteelGradeSourceParameter: raw = steelGradeSource; value = raw; break;
                    case SteelGradeDesignOrderValidation.SteelGradeAttributeNameParameter: raw = steelGradeAttributeName; value = raw; break;
                    case SteelGradeDesignOrderValidation.ComponentKeySourceParameter: raw = componentKeySource; value = raw; include = string.Equals(format, "Table", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.ComponentKeyAttributeNameParameter: raw = componentKeyAttributeName; value = raw; include = raw != null && string.Equals(format, "Table", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.ComponentCategorySourceParameter: raw = categorySource; value = raw; include = string.Equals(format, "Form", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.ComponentCategoryAttributeNameParameter: raw = categoryAttributeName; value = raw; include = raw != null && string.Equals(format, "Form", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.ComponentCategoryPatternsParameter: raw = categoryPatterns; value = raw; include = raw != null && string.Equals(format, "Form", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.ComponentExclusionPatternsParameter: raw = exclusionPatterns; value = raw; include = raw != null && string.Equals(format, "Form", StringComparison.OrdinalIgnoreCase); break;
                    case SteelGradeDesignOrderValidation.SteelGradeRepresentationParameter: raw = representation; value = raw; break;
                    case SteelGradeDesignOrderValidation.CompareGradeTokenOnlyParameter: raw = compareTokenOnly ? "true" : "false"; value = compareTokenOnly; break;
                    default: throw new InvalidOperationException("Unexpected CR-04 parameter: " + parameter.Name);
                }

                if (string.Equals(parameter.Name, omittedParameterName, StringComparison.Ordinal))
                    include = false;

                if (include)
                    values.Add(new RuleParameterValue(parameter, raw, value));
            }
            return new RuleParameterSet(values);
        }

        private static DesignOrderFormProfile FormProfile()
        {
            return new DesignOrderFormProfile(
                "Sridevi_QR-DG-02_REV04",
                "Sheet1",
                39,
                0,
                "QR/DG/02 REV 04 03/12/2021",
                5,
                14,
                new[]
                {
                    new DesignOrderFormCategoryDefinition("Cavity", "Cavity", 18, 0, 8, "CC", 14, 26),
                    new DesignOrderFormCategoryDefinition("Core", "Core", 19, 0, 8, "CC", 14, 26),
                    new DesignOrderFormCategoryDefinition("CavityInsert", "Cavity Insert", 20, 0, 8, "CC", 14, 26),
                    new DesignOrderFormCategoryDefinition("CoreInsert", "Core Insert", 21, 0, 8, "CC", 14, 26),
                    new DesignOrderFormCategoryDefinition("MovingCore", "Moving Core", 22, 0, 8, "CC", 14, 26),
                    new DesignOrderFormCategoryDefinition("AngularLifter", "Angular Lifter", 23, 0, 8, "CC", 14, 26),
                    new DesignOrderFormCategoryDefinition("PressurePad", "Pressuer Pad", 24, 0, 8, "CB", 29, 31),
                    new DesignOrderFormCategoryDefinition("WearPad", "Wear Pad", 25, 0, 8, "CC", 32, 39),
                    new DesignOrderFormCategoryDefinition("MouldBase", "Mould Base", 26, 0, 8, "CC", 32, 39)
                });
        }

        private sealed class NeverHeaderReader : ITabularHeaderReader
        {
            public TabularHeaderDiscoveryResult DiscoverHeaders(TabularHeaderSourceDefinition source) { throw new InvalidOperationException("Not expected."); }
        }

        private sealed class NeverDataReader : ITabularDataReader
        {
            public TabularReadResult Read(TabularSourceDefinition source) { throw new InvalidOperationException("Not expected."); }
            public TabularReadResult Read(TabularSourceDefinition source, IReadOnlyList<string> expectedHeaders) { throw new InvalidOperationException("Not expected."); }
        }

        private sealed class NeverAssemblyReader : IAssemblyBodyAttributeReader
        {
            public AssemblyBodyAttributeSnapshot ReadNamedAttributes(string steelGradeAttributeName, string componentKeyAttributeName) { throw new InvalidOperationException("Not expected."); }
        }

        private sealed class NeverBomReader : IBomMaterialTableReader
        {
            public BomMaterialTableResult ReadMaterialTable() { throw new InvalidOperationException("Not expected."); }
        }

        private sealed class FixedParameterProvider : IRuleParameterProvider
        {
            private readonly RuleParameterSet parameters;
            internal FixedParameterProvider(RuleParameterSet parameters) { this.parameters = parameters; }
            public RuleParameterSet LoadFor(FeatureDefinition definition) { return parameters; }
        }

        private sealed class NullLogger : IApplicationLogger
        {
            public void Log(ApplicationLogEntry entry) { }
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }

        private static void AssertContains(string value, string expected, string name)
        {
            if (value == null || value.IndexOf(expected, StringComparison.Ordinal) < 0)
                throw new InvalidOperationException(name + " expected to contain '" + expected + "' but was '" + value + "'.");
        }

        private static void AssertEqual<T>(T expected, T actual, string name)
        {
            if (!object.Equals(expected, actual))
                throw new InvalidOperationException(name + " expected '" + expected + "' but got '" + actual + "'.");
        }
    }
}
