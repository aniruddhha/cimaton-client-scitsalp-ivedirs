using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class FeatureLauncherApplicationTests
    {
        private static readonly string[] FirstAndSecondSelection = { "FIRST", "SECOND" };
        private static readonly string[] BlankSelection = { " " };
        private static readonly string[] EitherSelection = { "EITHER" };
        private static readonly string[] OneSelection = { "ONE" };

        internal static void RunAll()
        {
            ListsApplicableAndUnavailableFeatures();
            HandlesUnavailableApplicationAndDocument();
            ChecklistRunsSequentiallyWithSharedCorrelation();
            ChecklistPassesRunInputsToFeatures();
            ChecklistRejectsInvalidSelections();
            FindingViewsDoNotLeakDomainTypesToPresentation();
            CoversAvailabilityAndChecklistGuardContracts();
        }

        private static void ListsApplicableAndUnavailableFeatures()
        {
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[]
            {
                new StubFeature("PART", "Part Feature", DocumentContextRequirement.Part),
                new StubFeature("EITHER", "Either Feature", DocumentContextRequirement.Either)
            });

            FeatureAvailability[] features = new ListAvailableFeatures(registry).Execute(CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly));
            AssertEqual(2, features.Length, "Feature count");
            AssertEqual(false, features[0].IsApplicable, "Part feature availability in Assembly");
            Assert(features[0].Reason.Contains("Requires Part"), "Part feature reason");
            AssertEqual(true, features[1].IsApplicable, "Either feature availability in Assembly");
            AssertEqual("Tests", features[1].FunctionalGroup, "Functional group");
            AssertEqual("REQ-EITHER", features[1].RequirementIdsText, "Requirement ids");
        }

        private static void HandlesUnavailableApplicationAndDocument()
        {
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[] { new StubFeature("PART", "Part Feature", DocumentContextRequirement.Part) });
            ListAvailableFeatures list = new ListAvailableFeatures(registry);
            AssertEqual(false, list.Execute(CimatronSessionSnapshot.ApplicationUnavailable())[0].IsApplicable, "Unavailable application");
            AssertEqual(false, list.Execute(CimatronSessionSnapshot.NoActiveDocument())[0].IsApplicable, "Missing document");
        }

        private static void ChecklistRunsSequentiallyWithSharedCorrelation()
        {
            RecordingLogger logger = new RecordingLogger();
            StubFeature first = new StubFeature("FIRST", "First", DocumentContextRequirement.Part);
            StubFeature second = new StubFeature("SECOND", "Second", DocumentContextRequirement.Part);
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[] { first, second });
            ExecuteRegisteredFeature executor = new ExecuteRegisteredFeature(registry, logger, "0.14.10", new EmptyRuleParameterProvider());
            ExecuteFeatureChecklist checklist = new ExecuteFeatureChecklist(executor);

            FeatureChecklistReport report = checklist.Execute(
                FirstAndSecondSelection,
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part),
                "2026.0",
                "checklist-correlation");

            AssertEqual("checklist-correlation", report.CorrelationId, "Checklist correlation");
            AssertEqual(2, report.Reports.Count, "Checklist report count");
            AssertEqual(1, first.ExecutionCount, "First execution count");
            AssertEqual(1, second.ExecutionCount, "Second execution count");
            AssertEqual("Passed", report.Reports[0].StatusText, "First status");
        }

        private static void ChecklistPassesRunInputsToFeatures()
        {
            RecordingLogger logger = new RecordingLogger();
            StubFeature feature = new StubFeature("ONE", "One", DocumentContextRequirement.Part);
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[] { feature });
            ExecuteFeatureChecklist checklist = new ExecuteFeatureChecklist(
                new ExecuteRegisteredFeature(registry, logger, "0.29.0", new EmptyRuleParameterProvider()));
            FeatureRunInputs runInputs = new FeatureRunInputs(new Dictionary<string, object>
            {
                { "DesignOrderPath", @"C:\Orders\Selected.xlsx" }
            });

            checklist.Execute(
                OneSelection,
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part),
                "2026.0",
                "run-input-correlation",
                runInputs);

            object observed;
            Assert(feature.LastRunInputs != null, "Run inputs captured");
            Assert(feature.LastRunInputs.Values.TryGetValue("DesignOrderPath", out observed), "Design Order run input present");
            AssertEqual(@"C:\Orders\Selected.xlsx", observed as string, "Design Order run input value");
        }

        private static void ChecklistRejectsInvalidSelections()
        {
            RecordingLogger logger = new RecordingLogger();
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[] { new StubFeature("ONE", "One", DocumentContextRequirement.Part) });
            ExecuteFeatureChecklist checklist = new ExecuteFeatureChecklist(new ExecuteRegisteredFeature(registry, logger, "0.14.10", new EmptyRuleParameterProvider()));

            ExpectException<ArgumentNullException>(() => checklist.Execute(null, CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part), "2026.0", "x"));
            ExpectException<ArgumentException>(() => checklist.Execute(Array.Empty<string>(), CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part), "2026.0", "x"));
            ExpectException<ArgumentException>(() => checklist.Execute(BlankSelection, CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part), "2026.0", "x"));
        }

        private static void FindingViewsDoNotLeakDomainTypesToPresentation()
        {
            Finding finding = new Finding(
                "REQ-X",
                ResultStatus.Warning,
                "Measured value needs review.",
                new Measurement(10.5d, "mm"),
                new Measurement(10d, "mm"),
                new[] { new ModelEntityReference("entity|0|cGlk|42") });
            FeatureExecutionReport report = new FeatureExecutionReport(
                "X", "Feature X", FeatureKind.Validation, ResultStatus.Warning, "Review.", 1L, new[] { finding });

            FeatureFindingView[] views = report.FindingViews;
            AssertEqual(1, views.Length, "Finding view count");
            AssertEqual("REQ-X", views[0].RequirementId, "Finding requirement");
            AssertEqual("Warning", views[0].StatusText, "Finding status text");
            AssertEqual("10.5 mm", views[0].MeasuredValueText, "Measured text");
            AssertEqual("10 mm", views[0].LimitText, "Limit text");
            AssertEqual(1, views[0].EntityReferenceValues.Length, "Entity reference view count");
            AssertEqual("entity|0|cGlk|42", views[0].EntityReferenceValues[0], "Entity reference view value");
        }


        private static void CoversAvailabilityAndChecklistGuardContracts()
        {
            ExpectConstructionException<ArgumentException>(() => new FeatureAvailability(" ", "Name", FeatureKind.Validation, "Group", "REQ", "Part", true, "Reason"));
            ExpectConstructionException<ArgumentException>(() => new FeatureAvailability("ID", " ", FeatureKind.Validation, "Group", "REQ", "Part", true, "Reason"));
            ExpectConstructionException<ArgumentException>(() => new FeatureAvailability("ID", "Name", FeatureKind.Validation, " ", "REQ", "Part", true, "Reason"));
            ExpectConstructionException<ArgumentException>(() => new FeatureAvailability("ID", "Name", FeatureKind.Validation, "Group", " ", "Part", true, "Reason"));
            ExpectConstructionException<ArgumentException>(() => new FeatureAvailability("ID", "Name", FeatureKind.Validation, "Group", "REQ", " ", true, "Reason"));
            ExpectConstructionException<ArgumentException>(() => new FeatureAvailability("ID", "Name", FeatureKind.Validation, "Group", "REQ", "Part", true, " "));
            ExpectConstructionException<ArgumentNullException>(() => new ListAvailableFeatures(null));

            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[]
            {
                new StubFeature("ASSEMBLY", "Assembly Feature", DocumentContextRequirement.Assembly),
                new StubFeature("EITHER", "Either Feature", DocumentContextRequirement.Either)
            });
            ListAvailableFeatures list = new ListAvailableFeatures(registry);
            FeatureAvailability[] part = list.Execute(CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part));
            AssertEqual(false, part[0].IsApplicable, "Assembly feature in Part");
            AssertEqual(true, part[1].IsApplicable, "Either feature in Part");
            AssertEqual(false, list.Execute(CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Nc))[1].IsApplicable, "Either feature in NC");
            ExpectException<ArgumentNullException>(() => list.Execute(null));

            ExpectConstructionException<ArgumentException>(() => new FeatureChecklistReport(" ", Array.Empty<FeatureExecutionReport>()));
            ExpectConstructionException<ArgumentNullException>(() => new FeatureChecklistReport("x", null));

            RecordingLogger logger = new RecordingLogger();
            ExecuteFeatureChecklist checklist = new ExecuteFeatureChecklist(new ExecuteRegisteredFeature(registry, logger, "0.14.10", new EmptyRuleParameterProvider()));
            ExpectException<ArgumentNullException>(() => checklist.Execute(EitherSelection, null, "2026.0", "x"));
            ExpectException<ArgumentException>(() => checklist.Execute(EitherSelection, CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part), "2026.0", " "));
            ExpectConstructionException<ArgumentNullException>(() => new ExecuteFeatureChecklist(null));

            Finding noMeasurement = new Finding("REQ-NONE", ResultStatus.Passed, "No measurement.");
            FeatureExecutionReport noMeasurementReport = new FeatureExecutionReport("N", "No Measurement", FeatureKind.Validation, ResultStatus.Passed, "OK", 0L, new[] { noMeasurement });
            AssertEqual(string.Empty, noMeasurementReport.FindingViews[0].MeasuredValueText, "Empty measured text");
            AssertEqual(string.Empty, noMeasurementReport.FindingViews[0].LimitText, "Empty limit text");
        }

        private static FeatureTraceability Traceability()
        {
            return new FeatureTraceability("Description.", "Acceptance.", "Inputs.", "Outputs.", "Dependencies.", "None.", "None.", "Failures.", "Tests.", "0.14.10", "Tests only.");
        }

        private static void ExpectConstructionException<TException>(Func<object> factory) where TException : Exception
        {
            try { GC.KeepAlive(factory()); }
            catch (TException) { return; }
            throw new InvalidOperationException("Expected " + typeof(TException).Name + ".");
        }

        private static void ExpectException<TException>(Action action) where TException : Exception
        {
            try { action(); }
            catch (TException) { return; }
            throw new InvalidOperationException("Expected " + typeof(TException).Name + ".");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
            {
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
            }
        }

        private sealed class StubFeature : IApplicationFeature
        {
            internal StubFeature(string id, string name, DocumentContextRequirement context)
            {
                Definition = new FeatureDefinition(id, name, FeatureKind.Validation, new[] { "REQ-" + id }, "Tests", context, true, Traceability());
            }

            public FeatureDefinition Definition { get; }
            public int ExecutionCount { get; private set; }
            public FeatureRunInputs LastRunInputs { get; private set; }

            public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
            {
                ExecutionCount++;
                LastRunInputs = context.RunInputs;
                return new FeatureExecutionOutcome(ResultStatus.Passed, "Executed.", new[] { new Finding(Definition.RequirementIds[0], ResultStatus.Passed, "Passed.") });
            }
        }

        private sealed class EmptyRuleParameterProvider : IRuleParameterProvider
        {
            public RuleParameterSet LoadFor(FeatureDefinition definition) { return RuleParameterSet.Empty; }
        }

        private sealed class RecordingLogger : IApplicationLogger
        {
            public void Log(ApplicationLogEntry entry) { }
        }
    }
}
