using System;

namespace CimatronCustomization.Application.Tests
{
    internal static class Program
    {
        private static int Main()
        {
            try
            {
                CheckActivePartReadinessTests.RunAll();
                CimatronSessionSnapshotTests.RunAll();
                ExecuteRegisteredFeatureTests.RunAll();
                FeatureRegistryTests.RunAll();
                ReadCurrentCimatronSessionTests.RunAll();
                RunStartupDiagnosticsTests.RunAll();
                RuleParameterTests.RunAll();
                FeatureLauncherApplicationTests.RunAll();
                ModelAccessPlatformTests.RunAll();
                U1InProcessGeometryConfirmationTests.RunAll();
                Step08BInProcessConfirmationTests.RunAll();
                ViewportHighlightResultTests.RunAll();
                ViewportPickContractTests.RunAll();
                TabularInputContractTests.RunAll();
                TabularMappingContractTests.RunAll();
                TabularMappingEngineTests.RunAll();
                TabularMappingIntegrationTests.RunAll();
                ReadMappedTabularDataTests.RunAll();
                DesignOrderInputPathResolverTests.RunAll();
                SteelGradeOccurrenceHighlightSafetyTests.RunAll();
                VerifySteelGradeAgainstDesignOrderTests.RunAll();
                SteelGradeCategoryResolverTests.RunAll();
                SteelGradeVocabularyValidationTests.RunAll();
                PartTypeCategoryResolverTests.RunAll();
                TopLevelHighlightTargetSelectorTests.RunAll();
                TopLevelHighlightDiagnosticFeatureTests.RunAll();
                SteelGradeDesignOrderValidationFeatureTests.RunAll();
                Console.WriteLine("APPLICATION TESTS: PASS");
                return 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("APPLICATION TESTS: FAIL");
                Console.Error.WriteLine(exception);
                return 1;
            }
        }
    }
}
