using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class DesignOrderInputPathResolverTests
    {
        internal static void RunAll()
        {
            AbsolutePathIsReturnedUnchanged();
            RelativePathIsRejected();
            TokenizedPathIsRejected();
            InvalidPathCharactersAreRejected();
            BlankPathIsRejected();
        }

        private static void AbsolutePathIsReturnedUnchanged()
        {
            string path = @"C:\Data\CR04\DesignOrder.xlsx";
            string resolved = new DesignOrderInputPathResolver().ResolveAbsolutePath(path);
            AssertEqual(path, resolved, "Absolute path");
        }

        private static void RelativePathIsRejected()
        {
            AssertThrows<ArgumentException>(
                () => new DesignOrderInputPathResolver().ResolveAbsolutePath(@"Data\DesignOrder.xlsx"),
                "Relative path");
        }

        private static void TokenizedPathIsRejected()
        {
            AssertThrows<ArgumentException>(
                () => new DesignOrderInputPathResolver().ResolveAbsolutePath(@"{AssemblyFolder}\DesignOrder.xlsx"),
                "Deferred D-09(b) token path");
        }


        private static void InvalidPathCharactersAreRejected()
        {
            AssertThrows<ArgumentException>(
                () => new DesignOrderInputPathResolver().ResolveAbsolutePath("C:\\Data\\bad\0name.xlsx"),
                "Invalid path characters");
        }

        private static void BlankPathIsRejected()
        {
            AssertThrows<ArgumentException>(
                () => new DesignOrderInputPathResolver().ResolveAbsolutePath("  "),
                "Blank path");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }

        private static void AssertThrows<TException>(Action action, string scenario)
            where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException)
            {
                return;
            }

            throw new InvalidOperationException(scenario + " expected " + typeof(TException).Name + ".");
        }
    }
}
