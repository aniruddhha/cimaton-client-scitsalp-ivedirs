using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomization.Infrastructure.Tests
{
    internal static class ExcelDesignOrderFormReaderTests
    {
        private static readonly string[] PressurePadExpectedGrades = { "GRADE-E", "GRADE-F", "GRADE-G" };

        public static void RunAll()
        {
            ReadsAnonymizedFormFixture();
            NormalizesTemplateGuardWhitespace();
            NormalizesCategoryLabelWhitespaceAndCase();
            RejectsWrongTemplateGuard();
            RejectsMissingWorksheet();
            PreservesBlankGradesAndTrailingSpaceLabels();
            ReadsConfiguredVocabularyRanges();
            RejectsMissingRequiredLabel();
            RejectsDuplicateRequiredLabel();
            ReadsLegacyXlsThroughFormReader();
            ReadsSelectedMaterialFamilyAndTrimmedRemark();
            BlankSelectionAndBlankRemarkCreateNoRequirement();
            RejectsMultipleMaterialSelections();
            RejectsSelectionWithoutRemark();
            RejectsRemarkWithoutSelection();
            RejectsInvalidSelectionMarker();
            RejectsUnsupportedExtension();
        }

        private static void ReadsAnonymizedFormFixture()
        {
            DesignOrderFormReadResult result = ReadFixture(CreateFixtureProfile());
            Assert(result.IsSuccess, "Anonymized Form fixture should read successfully.");
            Assert(result.ProfileId == "Anonymized_QR_TEST", "Profile id mismatch.");
            Assert(result.NormalizedTemplateGuard == "TEST/FORM/01 REV 01 01/01/2026", "Template guard normalization mismatch.");
            Assert(result.MouldNumber == "TEST-MOULD-001", "Mould-number anchor mismatch.");
            Assert(result.Categories.Count == 9, "Expected nine Form categories.");
            Assert(result.Categories.Single(category => category.CategoryKey == "Cavity").SteelGrade == "GRADE-A", "Cavity grade mismatch.");
            Assert(result.Categories.Single(category => category.CategoryKey == "MouldBase").SteelGrade == "GRADE-B", "Mould-base grade mismatch.");
        }

        private static void NormalizesTemplateGuardWhitespace()
        {
            DesignOrderFormReadResult result = ReadFixture(CreateFixtureProfile());
            Assert(result.IsSuccess, "Whitespace runs in the Form guard should collapse before ordinal comparison.");
        }

        private static void NormalizesCategoryLabelWhitespaceAndCase()
        {
            string path = CreateMaterialSelectionWorkbook(" X ", string.Empty, "P-20-2311", "  cOrE   ");
            try
            {
                DesignOrderFormReadResult result = new ExcelDesignOrderFormReader().Read(path, CreateMaterialSelectionProfile());
                Assert(result.IsSuccess, "Category labels should trim/collapse whitespace and compare case-insensitively.");
                Assert(result.Categories.Single().ProductionLabel == "cOrE", "Normalized row label should preserve source case after whitespace normalization.");
            }
            finally { File.Delete(path); }
        }

        private static void RejectsWrongTemplateGuard()
        {
            DesignOrderFormProfile profile = CreateProfile("WRONG GUARD", "Sheet1", "Cavity");
            AssertError(ReadFixture(profile), "FORM_TEMPLATE_GUARD_MISMATCH");
        }

        private static void RejectsMissingWorksheet()
        {
            DesignOrderFormProfile profile = CreateProfile("TEST/FORM/01 REV 01 01/01/2026", "MissingSheet", "Cavity");
            AssertError(ReadFixture(profile), "FORM_WORKSHEET_NOT_FOUND");
        }

        private static void PreservesBlankGradesAndTrailingSpaceLabels()
        {
            DesignOrderFormReadResult result = ReadFixture(CreateFixtureProfile());
            Assert(result.IsSuccess, "Fixture should read successfully.");
            DesignOrderFormCategoryRecord core = result.Categories.Single(category => category.CategoryKey == "Core");
            Assert(core.ProductionLabel == "Core", "Form labels should be normalized by trim/collapse whitespace.");
            Assert(result.Categories.Single(category => category.CategoryKey == "CavityInsert").SteelGrade == string.Empty, "Blank grade must remain explicit blank.");
        }

        private static void ReadsConfiguredVocabularyRanges()
        {
            DesignOrderFormReadResult result = ReadFixture(CreateFixtureProfile());
            Assert(result.IsSuccess, "Fixture should read successfully.");
            DesignOrderFormCategoryRecord cavity = result.Categories.Single(category => category.CategoryKey == "Cavity");
            DesignOrderFormCategoryRecord pressurePad = result.Categories.Single(category => category.CategoryKey == "PressurePad");
            DesignOrderFormCategoryRecord mouldBase = result.Categories.Single(category => category.CategoryKey == "MouldBase");
            Assert(cavity.PermittedGrades.Count == 13, "Cavity vocabulary should come from the configured CC14:CC26 range.");
            Assert(cavity.PermittedGrades.Contains("GRADE-A-H2"), "Expected first vocabulary-range value was not read.");
            Assert(pressurePad.PermittedGrades.SequenceEqual(PressurePadExpectedGrades), "Pressure-pad vocabulary mismatch.");
            Assert(mouldBase.PermittedGrades.Contains("GRADE-B"), "Mould-base vocabulary should come from the configured CC32:CC39 range.");
        }

        private static void RejectsMissingRequiredLabel()
        {
            DesignOrderFormProfile profile = CreateProfile("TEST/FORM/01 REV 01 01/01/2026", "Sheet1", "Not Present");
            AssertError(ReadFixture(profile), "FORM_LABEL_NOT_FOUND");
        }

        private static void RejectsDuplicateRequiredLabel()
        {
            string path = CreateDuplicateLabelWorkbook();
            try
            {
                DesignOrderFormReadResult result = new ExcelDesignOrderFormReader().Read(
                    path,
                    new DesignOrderFormProfile(
                        "DuplicateLabel",
                        "Sheet1",
                        1,
                        0,
                        "TEST GUARD",
                        2,
                        14,
                        new[] { new DesignOrderFormCategoryDefinition("Cavity", "Cavity", 2, 0, 8, "CC", 4, 4) }));
                AssertError(result, "FORM_LABEL_DUPLICATE");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void ReadsLegacyXlsThroughFormReader()
        {
            string fixturePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TestData", "Step06", "LegacyInput.xls");
            Assert(File.Exists(fixturePath), "Legacy XLS/BIFF8 fixture should be copied to the test output directory.");

            DesignOrderFormProfile profile = new DesignOrderFormProfile(
                "LegacyFormContract",
                "Input",
                1,
                0,
                "Part",
                2,
                0,
                new[] { new DesignOrderFormCategoryDefinition("Block", "Block_A", 2, 0, 1, "B", 2, 2) });

            DesignOrderFormReadResult result = new ExcelDesignOrderFormReader().Read(fixturePath, profile);
            Assert(result.IsSuccess, ".xls should enter the Form reader and be parsed as BIFF8.");
            Assert(result.Categories[0].SteelGrade == "1.2344", "Legacy .xls grade mismatch.");
        }

        private static void ReadsSelectedMaterialFamilyAndTrimmedRemark()
        {
            string path = CreateMaterialSelectionWorkbook(" X ", string.Empty, "  P-20-2311  ");
            try
            {
                DesignOrderFormReadResult result = new ExcelDesignOrderFormReader().Read(path, CreateMaterialSelectionProfile());
                Assert(result.IsSuccess, "One X plus nonblank Remark should be valid.");
                DesignOrderFormCategoryRecord category = result.Categories.Single();
                Assert(category.SelectedMaterialFamily == "P-20", "Selected material family mismatch.");
                Assert(category.SteelGrade == "P-20-2311", "Remark should trim before comparison.");
                Assert(category.RawRemark == "  P-20-2311  ", "Raw Remark must remain available for evidence/reporting.");
                Assert(category.HasMaterialRequirement, "Selected family plus Remark should create a material requirement.");
            }
            finally { File.Delete(path); }
        }

        private static void BlankSelectionAndBlankRemarkCreateNoRequirement()
        {
            string path = CreateMaterialSelectionWorkbook(string.Empty, string.Empty, "   ");
            try
            {
                DesignOrderFormReadResult result = new ExcelDesignOrderFormReader().Read(path, CreateMaterialSelectionProfile());
                Assert(result.IsSuccess, "No X plus blank Remark should be valid.");
                Assert(!result.Categories.Single().HasMaterialRequirement, "Blank row must create no material requirement.");
            }
            finally { File.Delete(path); }
        }

        private static void RejectsMultipleMaterialSelections()
        {
            string path = CreateMaterialSelectionWorkbook("X", "x", "P-20-2311");
            try { AssertError(new ExcelDesignOrderFormReader().Read(path, CreateMaterialSelectionProfile()), "FORM_MATERIAL_SELECTION_MULTIPLE"); }
            finally { File.Delete(path); }
        }

        private static void RejectsSelectionWithoutRemark()
        {
            string path = CreateMaterialSelectionWorkbook("X", string.Empty, "   ");
            try { AssertError(new ExcelDesignOrderFormReader().Read(path, CreateMaterialSelectionProfile()), "FORM_REMARK_REQUIRED"); }
            finally { File.Delete(path); }
        }

        private static void RejectsRemarkWithoutSelection()
        {
            string path = CreateMaterialSelectionWorkbook(string.Empty, string.Empty, "P-20-2311");
            try { AssertError(new ExcelDesignOrderFormReader().Read(path, CreateMaterialSelectionProfile()), "FORM_MATERIAL_SELECTION_REQUIRED"); }
            finally { File.Delete(path); }
        }

        private static void RejectsInvalidSelectionMarker()
        {
            string path = CreateMaterialSelectionWorkbook("Y", string.Empty, "P-20-2311");
            try { AssertError(new ExcelDesignOrderFormReader().Read(path, CreateMaterialSelectionProfile()), "FORM_MATERIAL_SELECTION_MARKER_INVALID"); }
            finally { File.Delete(path); }
        }

        private static DesignOrderFormProfile CreateMaterialSelectionProfile()
        {
            return new DesignOrderFormProfile(
                "MaterialSelection",
                "Sheet1",
                1,
                0,
                "TEST GUARD",
                2,
                14,
                new[] { new DesignOrderFormCategoryDefinition("Core", "Core", "Core", 2, 0, 8, "CC", 4, 4) },
                new[]
                {
                    new DesignOrderFormMaterialFamilyDefinition("P-20", 2),
                    new DesignOrderFormMaterialFamilyDefinition("AL", 3)
                });
        }

        private static string CreateMaterialSelectionWorkbook(string p20Marker, string alMarker, string remark)
        {
            return CreateMaterialSelectionWorkbook(p20Marker, alMarker, remark, "Core");
        }

        private static string CreateMaterialSelectionWorkbook(string p20Marker, string alMarker, string remark, string categoryLabel)
        {
            string path = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + ".xlsx");
            using (FileStream stream = File.Create(path))
            using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Create))
            {
                WriteEntry(archive, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
                WriteEntry(archive, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
                WriteEntry(archive, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
                WriteEntry(archive, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
                string sheet = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>" +
                    "<row r=\"1\"><c r=\"A1\" t=\"inlineStr\"><is><t>TEST GUARD</t></is></c></row>" +
                    "<row r=\"2\"><c r=\"A2\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" + EscapeXml(categoryLabel) + "</t></is></c><c r=\"C2\" t=\"inlineStr\"><is><t>" + EscapeXml(p20Marker) + "</t></is></c><c r=\"D2\" t=\"inlineStr\"><is><t>" + EscapeXml(alMarker) + "</t></is></c><c r=\"I2\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" + EscapeXml(remark) + "</t></is></c><c r=\"O2\" t=\"inlineStr\"><is><t>MOULD-1</t></is></c></row>" +
                    "<row r=\"4\"><c r=\"CC4\" t=\"inlineStr\"><is><t>P-20-2311</t></is></c></row></sheetData></worksheet>";
                WriteEntry(archive, "xl/worksheets/sheet1.xml", sheet);
            }
            return path;
        }

        private static string EscapeXml(string value)
        {
            return (value ?? string.Empty).Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
        }

        private static void RejectsUnsupportedExtension()
        {
            string path = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + ".csv");
            File.WriteAllText(path, "not a form", new UTF8Encoding(false));
            try
            {
                AssertError(new ExcelDesignOrderFormReader().Read(path, CreateFixtureProfile()), "FORM_UNSUPPORTED_FORMAT");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static DesignOrderFormReadResult ReadFixture(DesignOrderFormProfile profile)
        {
            string fixturePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TestData", "CR04", "AnonymizedForm.xlsx");
            Assert(File.Exists(fixturePath), "The anonymized CR-04 Form fixture should be copied to the test output directory.");
            return new ExcelDesignOrderFormReader().Read(fixturePath, profile);
        }

        private static DesignOrderFormProfile CreateFixtureProfile()
        {
            return new DesignOrderFormProfile(
                "Anonymized_QR_TEST",
                "Sheet1",
                39,
                0,
                "TEST/FORM/01 REV 01 01/01/2026",
                5,
                14,
                new[]
                {
                    Category("Cavity", "Cavity", 18, "CC", 14, 26),
                    Category("Core", "Core", 19, "CC", 14, 26),
                    Category("CavityInsert", "Cavity Insert", 20, "CC", 14, 26),
                    Category("CoreInsert", "Core Insert", 21, "CC", 14, 26),
                    Category("MovingCore", "Moving Core", 22, "CC", 14, 26),
                    Category("AngularLifter", "Angular Lifter", 23, "CC", 14, 26),
                    Category("PressurePad", "Pressuer Pad", 24, "CB", 29, 31),
                    Category("WearPad", "Wear Pad", 25, "CC", 32, 39),
                    Category("MouldBase", "Mould Base", 26, "CC", 32, 39)
                });
        }

        private static DesignOrderFormProfile CreateProfile(string guard, string worksheet, string label)
        {
            return new DesignOrderFormProfile(
                "TestProfile",
                worksheet,
                39,
                0,
                guard,
                5,
                14,
                new[] { Category("Cavity", label, 18, "CC", 14, 26) });
        }

        private static DesignOrderFormCategoryDefinition Category(string key, string label, int row, string vocabularyColumn, int startRow, int endRow)
        {
            return new DesignOrderFormCategoryDefinition(key, label, row, 0, 8, vocabularyColumn, startRow, endRow);
        }

        private static string CreateDuplicateLabelWorkbook()
        {
            string path = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + ".xlsx");
            using (FileStream stream = File.Create(path))
            using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Create))
            {
                WriteEntry(archive, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
                WriteEntry(archive, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
                WriteEntry(archive, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
                WriteEntry(archive, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
                WriteEntry(archive, "xl/worksheets/sheet1.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData><row r=\"1\"><c r=\"A1\" t=\"inlineStr\"><is><t>TEST GUARD</t></is></c></row><row r=\"2\"><c r=\"A2\" t=\"inlineStr\"><is><t>Cavity</t></is></c><c r=\"I2\" t=\"inlineStr\"><is><t>GRADE-A</t></is></c><c r=\"O2\" t=\"inlineStr\"><is><t>TEST-MOULD</t></is></c></row><row r=\"3\"><c r=\"A3\" t=\"inlineStr\"><is><t>Cavity</t></is></c></row><row r=\"4\"><c r=\"CC4\" t=\"inlineStr\"><is><t>GRADE-A</t></is></c></row></sheetData></worksheet>");
            }
            return path;
        }

        private static void WriteEntry(ZipArchive archive, string name, string content)
        {
            ZipArchiveEntry entry = archive.CreateEntry(name);
            using (StreamWriter writer = new StreamWriter(entry.Open(), new UTF8Encoding(false)))
                writer.Write(content);
        }

        private static void AssertError(DesignOrderFormReadResult result, string expectedCode)
        {
            Assert(!result.IsSuccess, "Expected Form reader error.");
            Assert(result.ErrorCode == expectedCode, "Expected error code " + expectedCode + " but received " + result.ErrorCode + ".");
            Assert(!string.IsNullOrWhiteSpace(result.ErrorMessage), "Form reader error message must be actionable.");
            Assert(result.Categories.Count == 0, "Failed Form read must not expose partial category data.");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
