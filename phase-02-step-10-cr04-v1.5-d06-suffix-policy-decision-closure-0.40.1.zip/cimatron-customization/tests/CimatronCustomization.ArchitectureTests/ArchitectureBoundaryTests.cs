using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Xml.Linq;

namespace CimatronCustomization.ArchitectureTests
{
    internal static class ArchitectureBoundaryTests
    {
        private static readonly XNamespace MsBuildNamespace = "http://schemas.microsoft.com/developer/msbuild/2003";

        internal static void RunAll()
        {
            string repositoryRoot = FindRepositoryRoot();

            ProjectReferencesMustPointInward(repositoryRoot);
            DomainMustNotReferenceCimatron(repositoryRoot);
            DesignChecksMustRemainReadOnlyAtTheProjectBoundary(repositoryRoot);
            CimatronDependenciesMustRemainAtApprovedOuterBoundaries(repositoryRoot);
            PluginMustRemainAThinCimatronEntryPoint(repositoryRoot);
            AttributeReaderMustHandleEntitySpecificArgumentException(repositoryRoot);
            ViewportHighlightMustRemainWithinVerifiedSelectionApi(repositoryRoot);
            Step08BProductionBoundariesMustRemainGuarded(repositoryRoot);
            Cr04Slice3ProductionAdapterMustRemainGuarded(repositoryRoot);
            Cr04D02SteelGradeSetupMustRemainControlled(repositoryRoot);
            Cr04Slice4FeatureWiringMustRemainGuarded(repositoryRoot);
            Cr04Slice3InProcessSmokeMustRemainGuarded(repositoryRoot);
            Cr04SteelGradeProductionReaderSmokeMustRemainGuarded(repositoryRoot);
            Cr04V15FormReaderMustRemainGuarded(repositoryRoot);
            Cr04V15Slice2MappingMustRemainGuarded(repositoryRoot);
            Cr04V15Slice3WiringMustRemainGuarded(repositoryRoot);
            Cr04PartMaterialProductionSourceMustRemainGuarded(repositoryRoot);
            Cr04V15Slice4CategoryContractMustRemainGuarded(repositoryRoot);
            ResultReportCsvExportMustRemainGuarded(repositoryRoot);
            Cr04TargetComponentReadDiagnosticMustRemainGuarded(repositoryRoot);
            Cr04PartMaterialCorrelationDiagnosticMustRemainGuarded(repositoryRoot);
            Cr04PartPropertyDiscoveryDiagnosticMustRemainGuarded(repositoryRoot);
            TopLevelHighlightDiagnosticMustRemainGuarded(repositoryRoot);
            ProductionPickMustRemainWithinVerifiedComBoundary(repositoryRoot);
            ZoomDiscoveryToolMustRemainReadOnlyAndDevelopmentOnly(repositoryRoot);
            ZoomSelectionValidationMustRemainControlledAndDevelopmentOnly(repositoryRoot);
            PartMaterialApiReflectionInvestigationMustRemainReflectionOnly(repositoryRoot);
            ApiCapabilityVerificationMustRemainReadOnlyAndDevelopmentOnly(repositoryRoot);
        }

        private static void ProjectReferencesMustPointInward(string repositoryRoot)
        {
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Domain", Array.Empty<string>());
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.CimatronIntegration", "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.DesignChecks", "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Automations", "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Infrastructure", "CimatronCustomization.Application");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Plugin",
                "CimatronCustomization.Application",
                "CimatronCustomization.Automations",
                "CimatronCustomization.CimatronIntegration",
                "CimatronCustomization.DesignChecks",
                "CimatronCustomization.Infrastructure");
        }

        private static void DomainMustNotReferenceCimatron(string repositoryRoot)
        {
            string domainProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Domain");
            AssertNoAssemblyReferencesContaining(domainProject, "Cim", "interop.");
            AssertNoProjectReference(domainProject, "CimatronCustomization.CimatronIntegration");
        }

        private static void DesignChecksMustRemainReadOnlyAtTheProjectBoundary(string repositoryRoot)
        {
            string designChecksProject = GetProjectPath(repositoryRoot, "CimatronCustomization.DesignChecks");
            AssertNoProjectReference(designChecksProject, "CimatronCustomization.Automations");
            AssertNoProjectReference(designChecksProject, "CimatronCustomization.CimatronIntegration");
            AssertNoAssemblyReferencesContaining(designChecksProject, "Cim", "interop.");

            string automationsProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Automations");
            AssertNoProjectReference(automationsProject, "CimatronCustomization.DesignChecks");
            AssertNoProjectReference(automationsProject, "CimatronCustomization.CimatronIntegration");
            AssertNoAssemblyReferencesContaining(automationsProject, "Cim", "interop.");
        }

        private static void CimatronDependenciesMustRemainAtApprovedOuterBoundaries(string repositoryRoot)
        {
            string[] projectsWithoutDirectCimatronDependencies =
            {
                "CimatronCustomization.Domain",
                "CimatronCustomization.Application",
                "CimatronCustomization.DesignChecks",
                "CimatronCustomization.Automations",
                "CimatronCustomization.Infrastructure"
            };

            foreach (string projectName in projectsWithoutDirectCimatronDependencies)
            {
                AssertNoAssemblyReferencesContaining(GetProjectPath(repositoryRoot, projectName), "Cim", "interop.");
            }
        }

        private static void PluginMustRemainAThinCimatronEntryPoint(string repositoryRoot)
        {
            string pluginProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Plugin");
            AssertNoProjectReference(pluginProject, "CimatronCustomization.Domain");

            string pluginDirectory = Path.GetDirectoryName(pluginProject);
            string[] productionSources = Directory.GetFiles(pluginDirectory, "*.cs", SearchOption.TopDirectoryOnly)
                .Select(Path.GetFileName)
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            string[] expectedSources =
            {
                "CimatronCommandExecution.cs",
                "CimatronPluginCommand.cs",
                "FeatureComposition.cs",
                "FeatureLauncherWindow.cs",
                "FindingReportWindow.cs",
                "ResultReportCsvExporter.cs"
            };

            if (!productionSources.SequenceEqual(expectedSources, StringComparer.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "Plugin boundary violation: unexpected top-level production source files were found. " +
                    "The Plugin project must remain a thin Cimatron entry point until an explicit architecture change is approved.");
            }
        }


        private static void AttributeReaderMustHandleEntitySpecificArgumentException(string repositoryRoot)
        {
            string sourcePath = Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.CimatronIntegration",
                "CimatronModelInspectionAdapter.cs");

            string source = File.ReadAllText(sourcePath);
            const string getAttributesCall = ".GetAttributes()";
            int getAttributesCount = 0;
            int searchIndex = 0;
            while ((searchIndex = source.IndexOf(getAttributesCall, searchIndex, StringComparison.Ordinal)) >= 0)
            {
                getAttributesCount++;
                searchIndex += getAttributesCall.Length;
            }

            if (getAttributesCount != 1)
            {
                throw new InvalidOperationException(
                    "Cimatron model inspection adapter must contain exactly one GetAttributes() call. Every GetAttributes() call must go through the guarded TryGetRawAttributes helper.");
            }

            int helperStart = source.IndexOf("private static bool TryGetRawAttributes(", StringComparison.Ordinal);
            if (helperStart < 0)
            {
                throw new InvalidOperationException(
                    "Cimatron model inspection adapter must define TryGetRawAttributes so every GetAttributes() call goes through the guarded helper.");
            }

            int nextMethod = source.IndexOf("        public ModelReadResult<BodyTopologySnapshot> ReadCurrentTopology()", helperStart, StringComparison.Ordinal);
            if (nextMethod < 0)
            {
                throw new InvalidOperationException(
                    "Cimatron model inspection adapter source contract could not determine the end of TryGetRawAttributes.");
            }

            string helperSource = source.Substring(helperStart, nextMethod - helperStart);
            if (helperSource.IndexOf(getAttributesCall, StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "The single GetAttributes() call must be located inside the guarded TryGetRawAttributes helper.");
            }

            if (helperSource.IndexOf("catch (ArgumentException exception)", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "TryGetRawAttributes must convert live entity-specific GetAttributes ArgumentException failures into a controlled Unsupported result.");
            }

            if (source.IndexOf("GetAttributes() is not supported for this entity", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Cimatron model attribute reader must provide an explicit Unsupported message for entity-specific GetAttributes rejection.");
            }

            if (helperSource.IndexOf("catch (Exception", StringComparison.Ordinal) >= 0 ||
                helperSource.IndexOf("catch (COMException", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "TryGetRawAttributes must catch only ArgumentException; unexpected GetAttributes exceptions must still propagate.");
            }
        }

        private static void ViewportHighlightMustRemainWithinVerifiedSelectionApi(string repositoryRoot)
        {
            string sourcePath = Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.CimatronIntegration",
                "CimatronViewportEntityHighlighter.cs");

            if (!File.Exists(sourcePath))
            {
                throw new InvalidOperationException("Step 05A requires the Cimatron viewport highlight adapter.");
            }

            string source = File.ReadAllText(sourcePath);
            if (source.IndexOf("ISelection", StringComparison.Ordinal) < 0 ||
                source.IndexOf("selection.Selection = entityList", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Viewport highlighting must use the verified Cimatron ISelection.Selection boundary.");
            }

            if (source.IndexOf("IPickTool", StringComparison.Ordinal) >= 0 ||
                source.IndexOf("IDisplayUtils", StringComparison.Ordinal) >= 0 ||
                source.IndexOf("PushPickTool", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05A must not implement unapproved PickTool or zoom/display-transformation behavior.");
            }

            string pluginProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Plugin");
            AssertNoProjectReference(pluginProject, "CimatronCustomization.Domain");
        }

        private static void Step08BProductionBoundariesMustRemainGuarded(string repositoryRoot)
        {
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string occurrenceSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronOccurrenceEntityAttributeReader.cs"));
            if (occurrenceSource.IndexOf("nestedInstance.GetAllEntities()", StringComparison.Ordinal) < 0 ||
                occurrenceSource.IndexOf("GetAttribute(", StringComparison.Ordinal) < 0 ||
                occurrenceSource.IndexOf("AttributeEnumType.cmAttString", StringComparison.Ordinal) < 0 ||
                occurrenceSource.IndexOf("GetEntityById(", StringComparison.Ordinal) >= 0 ||
                occurrenceSource.IndexOf("string.Equals(attribute.Name", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U13 adapter must use occurrence-reached GetAllEntities plus exact named cmAttString lookup and must not regress to GetEntityById or returned IAttribute.Name equality.");
            }

            string mapperSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronAssemblyEntityMapper.cs"));
            if (mapperSource.IndexOf("assembly.GetAssemblyEntity(", StringComparison.Ordinal) < 0 ||
                mapperSource.IndexOf("FindOccurrenceEntity", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U7 adapter must map the occurrence-owned entity through IAssemblyModel.GetAssemblyEntity.");
            }

            string bomSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronBomMaterialExporter.cs"));
            if (bomSource.IndexOf("ComponentsFilterOption.cmNoFiltering", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("ITabularDataReader", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("new TabularColumnDefinition(\"Model\", \"Standard Number\", TabularValueType.Text, true)", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("new TabularColumnDefinition(\"Material\", \"Material\", TabularValueType.Text, false)", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("row.TryGetValue(\"Material\"", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("Required Material value is missing for target model", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("Path.GetTempPath()", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("\"CimatronCustomization\", \"Step08B\"", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("Directory.Delete(runDirectory, true)", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U15 adapter must retain cmNoFiltering export, validated tabular readback, required Standard Number, optional non-target Material values, target-row Material enforcement, and governed Step08B temporary cleanup.");
            }

            string highlighterSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronViewportEntityHighlighter.cs"));
            if (highlighterSource.IndexOf("Nested Cimatron entity references require an active Assembly document.", StringComparison.Ordinal) < 0 ||
                highlighterSource.IndexOf("assembly.GetAssemblyEntity(occurrenceEntity", StringComparison.Ordinal) < 0 ||
                highlighterSource.IndexOf("selection.Selection = entityList", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U12 production highlight path must resolve the nested occurrence, map it into Assembly context, and use the verified ISelection.Selection boundary.");
            }
        }

        private static void Cr04Slice3ProductionAdapterMustRemainGuarded(string repositoryRoot)
        {
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string adapterPath = Path.Combine(integrationDirectory, "CimatronAssemblyBodyAttributeReader.cs");
            string source = File.ReadAllText(adapterPath);

            string[] required =
            {
                "IAssemblyBodyAttributeReader",
                "assembly.GetInstances()",
                "instance.get_SubInstances(1, 0)",
                "MaximumTraversalDepth = 16",
                "instance.GetAllEntities()",
                "cmBody",
                "AttributeEnumType.cmAttString",
                "parentEffectivelySuppressed || directlySuppressed",
                "AssemblyBodyAttributeSnapshot.ReadError",
                "CreateEntityReference(instance.ID, modelPid, entity.ID)"
            };
            foreach (string marker in required)
            {
                if (source.IndexOf(marker, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 Slice 3 adapter is missing required guarded contract: " + marker + ".");
            }

            string[] forbidden =
            {
                "GetEntityById(",
                "GetAttributes()",
                "AttributeEnumType.cmAttInteger",
                ".Attach(",
                "SetAttribute",
                ".Save",
                "AssParentInstance",
                "AssRootInstance",
                "GetRootInstance()"
            };
            foreach (string marker in forbidden)
            {
                if (source.IndexOf(marker, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("CR-04 Slice 3 adapter contains forbidden production behavior: " + marker + ".");
            }

            string highlighterPath = Path.Combine(integrationDirectory, "CimatronViewportEntityHighlighter.cs");
            string highlighter = File.ReadAllText(highlighterPath);
            if (highlighter.IndexOf("if (instance.ID == instanceId)", StringComparison.Ordinal) < 0 ||
                highlighter.IndexOf("instance.get_SubInstances(1, 0)", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Slice 3 must not replace or weaken the validated production highlighter traversal contract.");
            }

            string setupPath = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.KnownAnswerModelSetup", "Program.cs");
            string setup = File.ReadAllText(setupPath);
            string[] setupRequired =
            {
                "--cr04-wrong-type-control",
                "KA-PART-1-CR04-WRONG-TYPE",
                "CR04_WRONG_TYPE_CONTROL",
                "AttributeEnumType.cmAttInteger",
                "overwrite is prohibited",
                "AutoSave: DISABLED"
            };
            foreach (string marker in setupRequired)
            {
                if (setup.IndexOf(marker, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 Slice 3 wrong-type setup lost required fail-closed control: " + marker + ".");
            }
        }

        private static void Cr04D02SteelGradeSetupMustRemainControlled(string repositoryRoot)
        {
            string setupPath = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.KnownAnswerModelSetup", "Program.cs");
            string setup = File.ReadAllText(setupPath);
            string[] required =
            {
                "--steel-grade-control",
                "KA-PART-1-CR04-WRONG-TYPE",
                "STEEL_GRADE",
                "P-20-2311",
                "AttributeEnumType.cmAttString",
                "GetAttributeFactory()",
                "sink.Attach(attribute)",
                "STEEL_GRADE_ATTACHED_AND_READ_BACK",
                "AutoSave: DISABLED",
                "overwrite is prohibited",
                "MANUAL SAVE REQUIRED"
            };

            foreach (string fragment in required)
            {
                if (setup.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 D-02 controlled steel-grade setup lost required guard: " + fragment + ".");
            }

            if (setup.IndexOf("document.Save", StringComparison.Ordinal) >= 0 ||
                setup.IndexOf(".Save()", StringComparison.Ordinal) >= 0 ||
                setup.IndexOf("SaveAs(", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("CR-04 D-02 controlled steel-grade setup must never auto-save the disposable Part.");
            }
        }

        private static void Cr04Slice4FeatureWiringMustRemainGuarded(string repositoryRoot)
        {
            string designChecksDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.DesignChecks");
            string featurePath = Path.Combine(designChecksDirectory, "SteelGradeDesignOrderValidation.cs");
            if (!File.Exists(featurePath))
                throw new InvalidOperationException("CR-04 Slice 4 DesignChecks feature source is missing.");

            string feature = File.ReadAllText(featurePath);
            string[] requiredFeatureFragments =
            {
                "STEEL-GRADE-DESIGN-ORDER-VALIDATION",
                "DocumentContextRequirement.Assembly",
                "FeatureKind.Validation",
                "VerifySteelGradeAgainstDesignOrderRequest",
                "DesignOrderPathRunInput",
                "context.RunInputs.Values.TryGetValue",
                "SteelGradeSourceParameter",
                "PartMaterial",
                "ComponentKeySourceParameter",
                "SteelGradeRepresentationParameter",
                "CompareGradeTokenOnlyParameter"
            };
            foreach (string fragment in requiredFeatureFragments)
            {
                if (feature.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 Slice 4 feature lost required guarded contract: " + fragment + ".");
            }

            string[] forbiddenFeatureFragments =
            {
                "interop.",
                "SetAttribute",
                ".Save",
                "CimatronBomMaterialExporter",
                "DesignOrderPathPattern",
                "public SteelGradeDesignOrderValidation(Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>>"
            };
            foreach (string fragment in forbiddenFeatureFragments)
            {
                if (feature.IndexOf(fragment, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("CR-04 Slice 4 feature contains unapproved behavior: " + fragment + ".");
            }

            if (feature.IndexOf("internal SteelGradeDesignOrderValidation(", StringComparison.Ordinal) < 0 ||
                feature.IndexOf("Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>> executeValidation", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "CR-04 Slice 4 test seam must remain internal so Plugin constructor resolution does not require a direct Domain reference.");
            }

            string compositionPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "FeatureComposition.cs");
            string composition = File.ReadAllText(compositionPath);
            string[] requiredCompositionFragments =
            {
                "new CimatronAssemblyBodyAttributeReader()",
                "new CimatronBomMaterialTableReader(cr04TabularReader)",
                "new DesignOrderInputPathResolver()",
                "new ReadMappedTabularData(cr04TabularReader, cr04TabularReader, new TabularMappingEngine())",
                "new ExcelDesignOrderFormReader()",
                "SrideviQrDg02Rev04Profile.Create()",
                "new SteelGradeDesignOrderValidation("
            };
            foreach (string fragment in requiredCompositionFragments)
            {
                if (composition.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 Slice 4 composition lost required production wiring: " + fragment + ".");
            }

            string pluginProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Plugin");
            AssertNoProjectReference(pluginProject, "CimatronCustomization.Domain");

            string launcherPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "FeatureLauncherWindow.cs");
            string launcher = File.ReadAllText(launcherPath);
            string[] requiredLauncherFragments =
            {
                "OpenFileDialog",
                "Select CR-04 Design Order Excel File",
                "Excel workbooks (*.xlsx;*.xls)|*.xlsx;*.xls",
                "SteelGradeDesignOrderValidation.DesignOrderPathRunInput",
                "new FeatureRunInputs",
                "dialog.ShowDialog(this) != DialogResult.OK",
                "return;"
            };
            foreach (string fragment in requiredLauncherFragments)
            {
                if (launcher.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 D-09(c) launcher flow lost required runtime browse/cancel guard: " + fragment + ".");
            }

            string configPath = Path.Combine(repositoryRoot, "config", "CimatronCustomization.config.xml");
            string config = File.ReadAllText(configPath);
            string[] requiredConfigFragments =
            {
                "id=\"STEEL-GRADE-DESIGN-ORDER-VALIDATION\"",
                "name=\"DesignOrderFormat\" value=\"Form\"",
                "name=\"DesignOrderProfile\" value=\"Sridevi_QR-DG-02_REV04\"",
                "name=\"SteelGradeSource\" value=\"PartMaterial\"",
                "name=\"ComponentCategorySource\" value=\"PartType\"",
                "name=\"SteelGradeRepresentation\" value=\"Strict\"",
                "name=\"CompareGradeTokenOnly\" value=\"false\""
            };
            foreach (string fragment in requiredConfigFragments)
            {
                if (config.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 approved controlled-validation configuration is missing: " + fragment + ".");
            }

            if (config.IndexOf("name=\"DesignOrderPath\"", StringComparison.Ordinal) >= 0 ||
                config.IndexOf("name=\"DesignOrderPathPattern\"", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("CR-04 D-09(c) must not persist a Design Order path or path pattern in production configuration.");
            }
        }

        private static void Cr04Slice3InProcessSmokeMustRemainGuarded(string repositoryRoot)
        {
            string pluginDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin");
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string smokePath = Path.Combine(pluginDirectory, "Diagnostics", "Cr04Slice3WrongTypeInProcessSmoke.cs");
            string probePath = Path.Combine(integrationDirectory, "Cr04WrongTypeSmokeProbe.cs");
            string requestPath = Path.Combine(pluginDirectory, "Diagnostics", "Cr04Slice3WrongTypeInProcessSmokeRequest.cs");
            string commandPath = Path.Combine(pluginDirectory, "CimatronCommandExecution.cs");
            string scriptPath = Path.Combine(repositoryRoot, "tools", "Request-Cr04Slice3WrongTypeInProcessSmoke.ps1");
            string pluginProjectPath = Path.Combine(pluginDirectory, "CimatronCustomization.Plugin.csproj");
            string integrationProjectPath = Path.Combine(integrationDirectory, "CimatronCustomization.CimatronIntegration.csproj");

            foreach (string path in new[] { smokePath, probePath, requestPath, commandPath, scriptPath, pluginProjectPath, integrationProjectPath })
            {
                if (!File.Exists(path))
                    throw new InvalidOperationException("CR-04 Slice 3 in-process smoke file is missing: " + path);
            }

            string smoke = File.ReadAllText(smokePath);
            string probe = File.ReadAllText(probePath);
            string request = File.ReadAllText(requestPath);
            string command = File.ReadAllText(commandPath);
            string script = File.ReadAllText(scriptPath);
            string pluginProject = File.ReadAllText(pluginProjectPath);
            string integrationProject = File.ReadAllText(integrationProjectPath);

            string[] requiredPluginSmokeFragments =
            {
                "new interop.CimServicesAPI.CimApplicationProvider()",
                "new Cr04WrongTypeSmokeProbe()",
                "probe.Read(TargetModelTitle, AttributeName, TargetBodyEntityId)",
                "ExpectedAssemblyTitle = \"KA-ASM-1-CR04-WRONG-TYPE-SMOKE\"",
                "TargetModelTitle = \"KA-PART-1-CR04-WRONG-TYPE\"",
                "AttributeName = \"CR04_WRONG_TYPE_CONTROL\"",
                "TargetBodyEntityId = 4",
                "result = \"HARD_STOP_PRESENT_OBSERVED\"",
                "result = \"FAIL_SAFE_READ_ERROR_OBSERVED\"",
                "MutationSnapshot.Capture(activeDocument)",
                "before.IsEquivalentTo(after)"
            };
            foreach (string fragment in requiredPluginSmokeFragments)
            {
                if (smoke.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 Slice 3 Plugin smoke lost required fail-safe/read-only behavior: " + fragment);
            }

            string[] forbiddenPluginSmokeFragments =
            {
                "CimAppAccess",
                "CimatronAssemblyBodyAttributeReader",
                "AssemblyBodyAttributeSnapshot",
                "AssemblyBodyAttributeOccurrence",
                "BodyAttributeObservation",
                "ModelEntityReference",
                "SetAttribute",
                ".Attach(",
                ".Save",
                "FeatureComposition",
                "GetEntityById",
                "AttributeEnumType.cmAttInteger"
            };
            foreach (string fragment in forbiddenPluginSmokeFragments)
            {
                if (smoke.IndexOf(fragment, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("CR-04 Slice 3 Plugin smoke contains forbidden boundary/runtime behavior: " + fragment);
            }

            string[] requiredProbeFragments =
            {
                "new CimatronAssemblyBodyAttributeReader()",
                "reader.ReadNamedAttributes(attributeName, null)",
                "string.Equals(item.ModelTitle, targetModelTitle, StringComparison.Ordinal)",
                "HasEntityId(body, targetBodyEntityId)",
                "AttributeObservationStatus.Present",
                "AttributeObservationStatus.Absent",
                "AttributeObservationStatus.ReadError",
                "Cr04WrongTypeSmokeProbeResult"
            };
            foreach (string fragment in requiredProbeFragments)
            {
                if (probe.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 Slice 3 Integration smoke probe lost required production-adapter interpretation: " + fragment);
            }

            string[] forbiddenProbeFragments =
            {
                "CimAppAccess",
                "SetAttribute",
                ".Attach(",
                ".Save",
                "GetEntityById",
                "AttributeEnumType.cmAttInteger"
            };
            foreach (string fragment in forbiddenProbeFragments)
            {
                if (probe.IndexOf(fragment, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("CR-04 Slice 3 Integration smoke probe contains forbidden behavior: " + fragment);
            }

            if (request.IndexOf("File.Move(requestPath, consumingPath)", StringComparison.Ordinal) < 0 ||
                request.IndexOf("MaximumRequestAge = TimeSpan.FromMinutes(30)", StringComparison.Ordinal) < 0 ||
                request.IndexOf("RequestVersion = \"0.27.6\"", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Slice 3 smoke request must remain one-shot, versioned, and time-limited.");
            }

            if (command.IndexOf("Cr04Slice3WrongTypeInProcessSmoke.TryRunRequested(out cr04SmokeResult)", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 Slice 3 in-process smoke must remain an explicit one-shot Plugin command interception.");

            if (script.IndexOf("This script does not launch Cimatron.", StringComparison.Ordinal) < 0 ||
                script.IndexOf("Version=0.27.6", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Slice 3 smoke request script must remain developer-only and must not launch Cimatron.");
            }

            if (pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04Slice3WrongTypeInProcessSmokeRequest.cs\" />", StringComparison.Ordinal) < 0 ||
                pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04Slice3WrongTypeInProcessSmoke.cs\" />", StringComparison.Ordinal) < 0 ||
                pluginProject.IndexOf("<Name>CimatronCustomization.Domain</Name>", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("CR-04 Slice 3 Plugin smoke must remain explicitly compiled without a direct Domain project reference.");
            }

            if (integrationProject.IndexOf("<Compile Include=\"Cr04WrongTypeSmokeProbe.cs\" />", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 Slice 3 Integration smoke probe must remain explicitly compiled by the old-style CimatronIntegration project.");

            string requestFileName = "cr04-slice3-wrong-type-" + "in-process-smoke.request";
            foreach (string root in new[] { Path.Combine(repositoryRoot, "src"), Path.Combine(repositoryRoot, "tools"), Path.Combine(repositoryRoot, "tests") })
            {
                foreach (string path in Directory.GetFiles(root, "*", SearchOption.AllDirectories))
                {
                    string source;
                    try { source = File.ReadAllText(path); }
                    catch (IOException) { continue; }
                    if (source.IndexOf(requestFileName, StringComparison.Ordinal) >= 0 &&
                        !string.Equals(path, requestPath, StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals(path, scriptPath, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new InvalidOperationException("CR-04 Slice 3 smoke request filename may appear only in its request class and request script: " + path);
                    }
                }
            }
        }

        private static void Cr04SteelGradeProductionReaderSmokeMustRemainGuarded(string repositoryRoot)
        {
            string pluginDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin");
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string smokePath = Path.Combine(pluginDirectory, "Diagnostics", "Cr04SteelGradeInProcessSmoke.cs");
            string probePath = Path.Combine(integrationDirectory, "Cr04SteelGradeSmokeProbe.cs");
            string requestPath = Path.Combine(pluginDirectory, "Diagnostics", "Cr04SteelGradeInProcessSmokeRequest.cs");
            string commandPath = Path.Combine(pluginDirectory, "CimatronCommandExecution.cs");
            string scriptPath = Path.Combine(repositoryRoot, "tools", "Request-Cr04SteelGradeInProcessSmoke.ps1");
            string pluginProjectPath = Path.Combine(pluginDirectory, "CimatronCustomization.Plugin.csproj");
            string integrationProjectPath = Path.Combine(integrationDirectory, "CimatronCustomization.CimatronIntegration.csproj");

            foreach (string path in new[] { smokePath, probePath, requestPath, commandPath, scriptPath, pluginProjectPath, integrationProjectPath })
            {
                if (!File.Exists(path))
                    throw new InvalidOperationException("CR-04 steel-grade production-reader smoke file is missing: " + path);
            }

            string smoke = File.ReadAllText(smokePath);
            string probe = File.ReadAllText(probePath);
            string request = File.ReadAllText(requestPath);
            string command = File.ReadAllText(commandPath);
            string script = File.ReadAllText(scriptPath);
            string pluginProject = File.ReadAllText(pluginProjectPath);
            string integrationProject = File.ReadAllText(integrationProjectPath);

            string[] requiredProbeFragments =
            {
                "new CimatronAssemblyBodyAttributeReader()",
                "ReadNamedAttributes(\"STEEL_GRADE\", null)",
                "TargetModelTitle = \"KA-PART-1-CR04-WRONG-TYPE\"",
                "TargetBodyEntityId = 4",
                "ExpectedValue = \"P-20-2311\"",
                "targetOccurrenceCount != 1",
                "targetBodies.Count != 1",
                "target.SteelGradeStatus != AttributeObservationStatus.Present",
                "string.Equals(target.SteelGradeValue, ExpectedValue, StringComparison.Ordinal)",
                "readErrorCount != 0",
                "BodyObservation="
            };
            foreach (string fragment in requiredProbeFragments)
            {
                if (probe.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 steel-grade probe lost required controlled production-reader behavior: " + fragment);
            }

            string[] requiredSmokeFragments =
            {
                "ExpectedAssemblyTitle = \"KA-ASM-1-CR04-WRONG-TYPE-SMOKE\"",
                "new Cr04SteelGradeSmokeProbe()",
                "probe.Read()",
                "DocumentSnapshot.Capture(activeDocument)",
                "FileSnapshot.Capture(request.PartFile)",
                "assemblyBefore.IsEquivalentTo(assemblyAfter)",
                "partBefore.IsEquivalentTo(partAfter)",
                "PRODUCTION_READER_STEEL_GRADE_OBSERVED",
                "HARD_STOP_KNOWN_ANSWER_MISMATCH",
                "Scope=CONTROLLED_MODEL_PRODUCTION_READER_PATH_ONLY"
            };
            foreach (string fragment in requiredSmokeFragments)
            {
                if (smoke.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 steel-grade Plugin smoke lost required one-shot/read-only behavior: " + fragment);
            }

            string[] forbiddenExactCallTokens =
            {
                ".Save(",
                ".Attach(",
                "SetAttribute(",
                "GetAttributes(",
                "GetEntityById(",
                "cmAttInteger"
            };
            foreach (string source in new[] { smoke, probe, request })
            {
                foreach (string forbidden in forbiddenExactCallTokens)
                {
                    if (source.IndexOf(forbidden, StringComparison.Ordinal) >= 0)
                        throw new InvalidOperationException("CR-04 steel-grade smoke must remain read-only and exact-string-only; forbidden token: " + forbidden);
                }
            }

            string[] requiredRequestFragments =
            {
                "RequestVersion = \"0.30.1\"",
                "cr04-steel-grade-in-process-smoke.request",
                "TimeSpan.FromMinutes(30)",
                "File.Move(requestPath, consumingPath)",
                "Path.IsPathRooted(evidenceFile)",
                "Path.IsPathRooted(partFile)",
                "File.Exists(partFile)",
                "File.Delete(consumingPath)"
            };
            foreach (string fragment in requiredRequestFragments)
            {
                if (request.IndexOf(fragment, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 steel-grade smoke request lost required one-shot guard: " + fragment);
            }

            if (command.IndexOf("Cr04SteelGradeInProcessSmoke.TryRunRequested(out cr04SteelGradeSmokeResult)", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 steel-grade smoke must remain an explicit one-shot Plugin command interception.");

            if (script.IndexOf("Version=0.30.1", StringComparison.Ordinal) < 0 ||
                script.IndexOf("PartFilePath is required", StringComparison.Ordinal) < 0 ||
                script.IndexOf("This script does not launch Cimatron.", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 steel-grade smoke request script must remain versioned, Part-file-bound and developer-only.");
            }

            if (pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04SteelGradeInProcessSmokeRequest.cs\" />", StringComparison.Ordinal) < 0 ||
                pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04SteelGradeInProcessSmoke.cs\" />", StringComparison.Ordinal) < 0 ||
                pluginProject.IndexOf("<Name>CimatronCustomization.Domain</Name>", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("CR-04 steel-grade Plugin smoke must remain explicitly compiled without a direct Domain project reference.");
            }

            if (integrationProject.IndexOf("<Compile Include=\"Cr04SteelGradeSmokeProbe.cs\" />", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 steel-grade Integration smoke probe must remain explicitly compiled by the old-style CimatronIntegration project.");

            string wrongTypeSmokePath = Path.Combine(pluginDirectory, "Diagnostics", "Cr04Slice3WrongTypeInProcessSmoke.cs");
            string wrongTypeSmoke = File.ReadAllText(wrongTypeSmokePath);
            if (wrongTypeSmoke.IndexOf("AttributeName = \"CR04_WRONG_TYPE_CONTROL\"", StringComparison.Ordinal) < 0 ||
                wrongTypeSmoke.IndexOf("FAIL_SAFE_READ_ERROR_OBSERVED", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Existing CR-04 wrong-type smoke semantics must remain unchanged alongside the positive smoke.");
            }
        }

        private static void TopLevelHighlightDiagnosticMustRemainGuarded(string repositoryRoot)
        {
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string highlighterPath = Path.Combine(integrationDirectory, "CimatronViewportEntityHighlighter.cs");
            string highlighter = File.ReadAllText(highlighterPath);
            string[] requiredHighlighterFragments =
            {
                "if (depth > 16)",
                "instance.get_SubInstances(1, 0)",
                "assembly.GetAssemblyEntity(occurrenceEntity",
                "previousSelection = selection.Selection",
                "CaptureSelectionIfNeeded(selection);",
                "selection.Selection = entityList",
                "capturedSelection.Selection = restore;"
            };
            foreach (string required in requiredHighlighterFragments)
            {
                if (highlighter.IndexOf(required, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("CR-04 Slice 2A Package 2 highlighter lost required traversal/highlight/restore fragment: " + required);
            }

            string reportPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "FindingReportWindow.cs");
            string report = File.ReadAllText(reportPath);
            if (report.IndexOf("protected override void OnFormClosed(FormClosedEventArgs e)", StringComparison.Ordinal) < 0 ||
                report.IndexOf("viewportEntityHighlighter.RestoreSelection();", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Result Report must restore the temporary viewport selection on every form-close path.");
            }

            string readerPath = Path.Combine(integrationDirectory, "CimatronTopLevelHighlightDiagnosticReader.cs");
            string reader = File.ReadAllText(readerPath);
            string[] requiredReaderFragments =
            {
                "assembly.GetInstances()",
                "instance.get_SubInstances(1, 0)",
                "if (depth > 16)",
                "TopLevelHighlightTargetSelector.Select",
                "selected.Instance.GetAllEntities()",
                "AttributeEnumType.cmAttString",
                "interop.CimMdlrAPI.IModel assemblyModel = assembly as interop.CimMdlrAPI.IModel",
                "StringComparison.OrdinalIgnoreCase",
                "CreateEntityReference(selectedId, ownerModel.PID ?? string.Empty, matchingBodies[0].ID)",
                "[TOPLEVEL_HIGHLIGHT_API_ERROR]",
                "[TOPLEVEL_HIGHLIGHT_MUTATION_DETECTED]"
            };
            foreach (string required in requiredReaderFragments)
            {
                if (reader.IndexOf(required, StringComparison.Ordinal) < 0)
                    throw new InvalidOperationException("Top-level highlight diagnostic reader lost required read-only contract fragment: " + required);
            }

            string[] forbiddenReaderFragments =
            {
                ".Save(",
                "SaveAs",
                "SuppressComponents",
                ".IsSuppressed =",
                ".Show =",
                ".Attribute =",
                "SetAttribute",
                "Attach(",
                "GetRootInstance",
                "AssRootInstance",
                "AssParentInstance",
                "ISelection",
                "IViewportEntityHighlighter"
            };
            foreach (string forbidden in forbiddenReaderFragments)
            {
                if (reader.IndexOf(forbidden, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("Top-level highlight diagnostic reader must remain read-only and within the approved API boundary; forbidden fragment: " + forbidden);
            }

            string selectorPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Application", "TopLevelHighlightTargetSelector.cs");
            string selector = File.ReadAllText(selectorPath);
            if (selector.IndexOf("expectedModelTitle", StringComparison.Ordinal) < 0 ||
                selector.IndexOf("counts[id] == 1", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Top-level target selector must remain pure, parameterized, and globally InstanceId-unique.");
            }

            string[] knownAnswerFragments =
            {
                "KA-PART-1",
                "KA-ASM-1",
                "STEP07_B1_TEST_ATTRIBUTE",
                "KNOWN_ANSWER_07C3"
            };
            foreach (string knownAnswer in knownAnswerFragments)
            {
                if (reader.IndexOf(knownAnswer, StringComparison.Ordinal) >= 0 || selector.IndexOf(knownAnswer, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("Top-level diagnostic reader/selector must not hard-code known-answer values: " + knownAnswer);
            }

            string pluginPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "FeatureComposition.cs");
            string plugin = File.ReadAllText(pluginPath);
            string pluginWithoutWhitespace = new string(plugin.Where(character => !char.IsWhiteSpace(character)).ToArray());
            const string normalizedRegistration = "if(TopLevelHighlightDiagnosticRequest.TryConsume()){features.Add(newTopLevelHighlightDiagnosticFeature(newCimatronTopLevelHighlightDiagnosticReader()));}";
            if (pluginWithoutWhitespace.IndexOf(normalizedRegistration, StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Top-level highlight diagnostic registration must use the exact one-shot TryConsume gate.");
            }

            string environmentGateName = "CIMATRON_DEV_ENABLE_CR04_" + "SLICE2A_TOPLEVEL_HIGHLIGHT_DIAGNOSTIC";
            foreach (string root in new[] { Path.Combine(repositoryRoot, "src"), Path.Combine(repositoryRoot, "tools") })
            {
                foreach (string path in Directory.GetFiles(root, "*", SearchOption.AllDirectories))
                {
                    string source;
                    try { source = File.ReadAllText(path); }
                    catch (IOException) { continue; }
                    if (source.IndexOf(environmentGateName, StringComparison.Ordinal) >= 0)
                        throw new InvalidOperationException("The retired CR-04 diagnostic environment variable must not appear in src/ or tools/: " + path);
                }
            }

            string requestFileName = "cr04-slice2a-" + "toplevel-highlight-diagnostic.request";
            string requestClassPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "Diagnostics", "TopLevelHighlightDiagnosticRequest.cs");
            string requestScriptPath = Path.Combine(repositoryRoot, "tools", "Request-TopLevelHighlightDiagnostic.ps1");
            foreach (string root in new[] { Path.Combine(repositoryRoot, "src"), Path.Combine(repositoryRoot, "tools"), Path.Combine(repositoryRoot, "tests") })
            {
                foreach (string path in Directory.GetFiles(root, "*", SearchOption.AllDirectories))
                {
                    string source;
                    try { source = File.ReadAllText(path); }
                    catch (IOException) { continue; }
                    if (source.IndexOf(requestFileName, StringComparison.Ordinal) >= 0 &&
                        !string.Equals(path, requestClassPath, StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals(path, requestScriptPath, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new InvalidOperationException("The CR-04 request file name may appear only in its request class and request script: " + path);
                    }
                }
            }

            string pluginProject = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "CimatronCustomization.Plugin.csproj"));
            if (pluginProject.IndexOf("<Compile Include=\"Diagnostics\\TopLevelHighlightDiagnosticRequest.cs\" />", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("The new request class must have an explicit Compile entry in the old-style Plugin project.");

            int registrationCount = 0;
            foreach (string sourcePath in Directory.GetFiles(Path.Combine(repositoryRoot, "src"), "*.cs", SearchOption.AllDirectories))
            {
                string source = File.ReadAllText(sourcePath);
                int index = 0;
                const string registration = "new TopLevelHighlightDiagnosticFeature(";
                while ((index = source.IndexOf(registration, index, StringComparison.Ordinal)) >= 0)
                {
                    registrationCount++;
                    index += registration.Length;
                }
            }
            if (registrationCount != 1)
                throw new InvalidOperationException("Exactly one production registration path is allowed for TopLevelHighlightDiagnosticFeature.");
        }

        private static void ProductionPickMustRemainWithinVerifiedComBoundary(string repositoryRoot)
        {
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string assemblyInfo = File.ReadAllText(Path.Combine(integrationDirectory, "Properties", "AssemblyInfo.cs"));
            if (assemblyInfo.IndexOf("[assembly: ComVisible(false)]", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "CimatronIntegration must remain ComVisible(false) at assembly level; only the approved production PickTool class may opt in.");
            }

            string[] comVisibleSources = Directory.GetFiles(integrationDirectory, "*.cs", SearchOption.TopDirectoryOnly)
                .Where(path => File.ReadAllText(path).IndexOf("[ComVisible(true)]", StringComparison.Ordinal) >= 0)
                .Select(Path.GetFileName)
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            string[] expectedComVisibleSources = { "CimatronViewportPickTool.cs" };
            if (!comVisibleSources.SequenceEqual(expectedComVisibleSources, StringComparer.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "Step 05B2 allows exactly one COM-visible CimatronIntegration class: CimatronViewportPickTool.");
            }

            string pickToolSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronViewportPickTool.cs"));
            if (pickToolSource.IndexOf("[Guid(\"8C05B1D6-7440-4EF7-A369-9A86B54AE151\")]", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.Tool", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.IToolEvents", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.IPickToolEvents", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.IFigureEvent", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Production PickTool must retain the verified fixed GUID and installed Cimatron Tool/event interfaces from Step 05B1.");
            }

            string pickerSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronViewportEntityPicker.cs"));
            if (pickerSource.IndexOf("IToolContainer", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("PushPickTool", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmPart", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("ViewportPickOutcome.Busy", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("SynchronizationContext.Current", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("CancellationToken", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmBody", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmFace", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmEdge", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 production Pick must remain Part-only, non-blocking/cancellable, use IToolContainer.PushPickTool, expose Busy/StaleResult, and enforce the approved Cimatron entity-type filter.");
            }

            string resultValidatorSource = File.ReadAllText(Path.Combine(integrationDirectory, "ViewportPickResultValidator.cs"));
            if (resultValidatorSource.IndexOf("ViewportPickOutcome.StaleResult", StringComparison.Ordinal) < 0 ||
                resultValidatorSource.IndexOf("SOURCE_DOCUMENT_STALE", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 must fail closed with the approved StaleResult outcome before a source-document-scoped entity ID can be reused.");
            }

            if (pickerSource.IndexOf("RegAsm", StringComparison.OrdinalIgnoreCase) >= 0 ||
                pickToolSource.IndexOf("RegAsm", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 must retain direct managed-object handoff and must not introduce COM registration behavior.");
            }

            string[] removedSpikeFiles =
            {
                "CimatronPartPickSpike.cs",
                "CimatronDiagnosticPickTool.cs",
                "PartPickSpikeOutcome.cs",
                "PartPickSpikeStartResult.cs"
            };
            if (removedSpikeFiles.Any(name => File.Exists(Path.Combine(integrationDirectory, name))))
            {
                throw new InvalidOperationException(
                    "The Step 05B1 diagnostic spike must not remain in the 0.15.2 Release production source tree.");
            }

            string commandSource = File.ReadAllText(Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.Plugin",
                "CimatronCommandExecution.cs"));
            if (commandSource.IndexOf("launcher.ShowDialog()", StringComparison.Ordinal) >= 0 ||
                commandSource.IndexOf("launcher.ShowOwnedByCimatron();", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("activeLauncher.RestoreToFront();", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("Process.GetCurrentProcess().MainWindowHandle", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("private static FeatureLauncherWindow activeLauncher", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("IViewportEntityPicker viewportEntityPicker", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 requires the modeless/strongly-retained launcher lifecycle and Application-owned production Pick port.");
            }

            string launcherSource = File.ReadAllText(Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.Plugin",
                "FeatureLauncherWindow.cs"));
            if (launcherSource.IndexOf("Pick Spike (Part)", StringComparison.Ordinal) >= 0 ||
                launcherSource.IndexOf("CimatronPartPickSpike", StringComparison.Ordinal) >= 0 ||
                launcherSource.IndexOf("IViewportEntityPicker", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("new CancellationTokenSource()", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("viewportEntityPicker.BeginPick", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("viewportEntityPicker.ValidateForCurrentDocument", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("BringToFront();", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("Show(new WindowHandleOwner(cimatronWindowHandle));", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("foregroundMonitor.Tick += ForegroundMonitorTick;", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("GetForegroundWindow()", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("SetForegroundWindow(cimatronWindowHandle);", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("uint foregroundThreadId = GetWindowThreadProcessId", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("if (foregroundThreadId == 0)", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("currentProcessForeground && !cimatronWasForeground", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("Visible && Enabled && !viewportEntityPicker.IsActive", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("private sealed class PickResultDialog : Form", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("PickResultDialog.ShowResult(", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("RestoreCimatronAndLauncherFocus();", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("TopMost = true;", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("dialog.ShowDialog(owner);", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 UI must remove the diagnostic spike path while preserving the verified launcher/result focus lifecycle and using the Application production Pick contract.");
            }
        }


        private static void ZoomDiscoveryToolMustRemainReadOnlyAndDevelopmentOnly(string repositoryRoot)
        {
            string toolDirectory = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.ZoomCommandDiscovery");
            string toolProject = Path.Combine(toolDirectory, "CimatronCustomization.ZoomCommandDiscovery.csproj");
            string programSource = File.ReadAllText(Path.Combine(toolDirectory, "Program.cs"));
            string commandSource = File.ReadAllText(Path.Combine(toolDirectory, "CommandPoolInventory.cs"));
            string reflectionSource = File.ReadAllText(Path.Combine(toolDirectory, "InteropReflectionInventory.cs"));
            string assemblyEntitySource = File.ReadAllText(Path.Combine(toolDirectory, "AssemblyEntityInventory.cs"));
            string occurrenceInterfaceSource = File.ReadAllText(Path.Combine(toolDirectory, "OccurrenceComInterfaceInventory.cs"));
            string traceWriterPath = Path.Combine(toolDirectory, "DiagnosticTraceWriter.cs");
            if (!File.Exists(traceWriterPath))
            {
                throw new InvalidOperationException("Step 05C2 durable diagnostic trace writer is missing.");
            }

            string traceWriterSource = File.ReadAllText(traceWriterPath);
            string projectSource = File.ReadAllText(toolProject);
            string captureSource = File.ReadAllText(Path.Combine(repositoryRoot, "tools", "Invoke-And-Capture.ps1"));

            if (projectSource.IndexOf("C:\\Program Files\\Cimatron\\Cimatron\\2026.0\\Program", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<ApplicationManifest>app.manifest</ApplicationManifest>", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<PlatformTarget>x64</PlatformTarget>", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C1 standalone discovery tool must remain x64, use the embedded Cimatron side-by-side manifest, and build into the Cimatron 2026 Program folder.");
            }

            string combinedSource = programSource + commandSource + reflectionSource + assemblyEntitySource + occurrenceInterfaceSource;

            string[] assemblyReflectionRequiredTokens =
            {
                "--reflect-assembly-api",
                "RunAssemblyApi()",
                "AssemblyApiTerms",
                "ReflectionOnlyLoadFrom",
                "GetInterfaces()",
                "RuntimeCalls: NONE (reflection-only installed-Interop inventory)"
            };
            if (assemblyReflectionRequiredTokens.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                reflectionSource.IndexOf("new AppAccess", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetActiveDoc()", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-A Assembly API surface inventory must remain reflection-only, base-interface-aware, and free of live Cimatron runtime calls.");
            }

            string[] visibilityReflectionRequiredTokens =
            {
                "--reflect-visibility-api",
                "RunVisibilityApi()",
                "VisibilityTerms",
                "Show",
                "Visible",
                "Visibility",
                "Hidden",
                "Hide",
                "Blank",
                "Display",
                "State",
                "_IASSINSTANCE COPIES",
                "CurrentCastTarget: interop.CimMdlrAPI._IAssInstance",
                "CurrentCastMechanism: C# 'as' cast",
                "CurrentCastExceptionType: NONE",
                "CurrentCastHRESULT: N/A",
                "PROPERTY_GET",
                "PROPERTY_SET",
                "AMBIGUOUS_METHOD_NOT_INVOKED",
                "cmAttVisibility",
                "cmAttBlankLevel",
                "BODY/ENTITY-LEVEL CANDIDATES ONLY",
                "NewlyDiscoveredMemberInvocation: PROHIBITED / NOT CALLED",
                "FR-021 remains OPEN"
            };
            if (visibilityReflectionRequiredTokens.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                reflectionSource.IndexOf("interop.CimAppAccess", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetApplication()", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetActiveDoc()", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B hidden-state discovery must remain reflection-only, classify visibility members by access kind, inventory _IAssInstance copies and visibility attributes, and invoke no newly discovered Cimatron member.");
            }
            string[] occurrenceInterfaceRequiredTokens =
            {
                "--probe-occurrence-interfaces",
                "Marshal.QueryInterface",
                "Marshal.Release(supportedPointer)",
                "Marshal.Release(unknown)",
                "IProvideClassInfo",
                "GetClassInfo",
                "IDispatch.GetTypeInfo",
                "INTERFACE x OBJECT SUPPORT MATRIX",
                "VISIBLE_Block_A",
                "HIDDEN_NOT_SUPPRESSED_Known_Pocket_Body",
                "SUPPRESSED_Block_B",
                "NewlyDiscoveredMemberInvocation: PROHIBITED / NOT CALLED",
                "EXPECTED: visible/hidden/suppressed occurrences likely expose identical COM interface sets",
                "STOP reflection search",
                "suppressed: supported; hidden: BLOCKED — pending Cimatron guidance"
            };
            string[] occurrenceInterfaceForbiddenTokens =
            {
                ".Execute(",
                "PushPickTool",
                "PopTool",
                "Selection(",
                "Highlight(",
                "CreateProcedure(",
                "RemoveAttribute(",
                "SuppressComponents(",
                "Save()",
                "SaveAs("
            };
            if (occurrenceInterfaceRequiredTokens.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                occurrenceInterfaceForbiddenTokens.Any(value => occurrenceInterfaceSource.IndexOf(value, StringComparison.Ordinal) >= 0) ||
                projectSource.IndexOf("<Compile Include=\"OccurrenceComInterfaceInventory.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B final occurrence COM-interface diagnostic must query each IID read-only, release COM pointers immediately, classify newly found interfaces by reflection only, and retain the approved stopping rule.");
            }

            string[] forbiddenMutationCalls =
            {
                ".Execute(",
                "ExecutePluginCommand",
                "PushPickTool",
                "PopTool",
                "Selection(",
                "Highlight("
            };
            if (forbiddenMutationCalls.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) >= 0))
            {
                throw new InvalidOperationException(
                    "Step 05C1 discovery tool is evidence-only and must not execute Cimatron commands or mutate selection/view/model state.");
            }

            string[] allowedApiTokens =
            {
                "GetApplication()",
                "GetActiveDoc()",
                "GetPoolCommands()",
                "GetCommandsNames()",
                "application.ProductName",
                "application.Version",
                "activeDocument.Type"
            };
            if (allowedApiTokens.Any(value => commandSource.IndexOf(value, StringComparison.Ordinal) < 0))
            {
                throw new InvalidOperationException(
                    "Step 05C1 live inventory must retain only the approved read-only application/document/command-pool calls and metadata reads.");
            }

            string[] assemblyInventoryRequiredTokens =
            {
                "GetApplication()",
                "GetActiveDoc()",
                "GetRootInstance()",
                "SubInstances[1, 0]",
                "AssParentInstance",
                "AssRootInstance",
                "IsSuppressed",
                "IgnoreInShowOperations",
                "IAssInstance.get_IgnoreInShowOperations GETTER_ONLY",
                "GetAttribute(attributeType, string.Empty)",
                "cmAttVisibility",
                "cmAttBlankLevel",
                "LegacyShowProbe: CLOSED BY USER-VALIDATED 0.15.29 RUN",
                "OccurrenceVisibilityMutation: PROHIBITED / NOT CALLED",
                "OccurrenceVisibilitySemantics: raw candidate values are evidence only",
                "Transformation[rootParent]",
                ".Matrix",
                ".Vector",
                "GetAllEntities()",
                "entities.Count",
                "entities[index]",
                "GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttInteger, attributeName)",
                "IsModified()",
                "GetPath()",
                "ApiCallTimeoutMilliseconds = 15000",
                "ApiCallTimeoutExitCode = 7",
                "MaximumDepth = 16",
                "MaximumOccurrences = 2000",
                "MaximumEntityInspections = 2000",
                "Environment.Exit(ApiCallTimeoutExitCode)",
                "OccurrenceIdentity: full traversal path with sibling ordinal",
                "CycleGuard: ancestor assembly definition ModelPID only",
                "@ordinal-",
                "ancestorAssemblyDefinitions.Contains(modelPid)",
                "SKIPPED_DEFINITION_CYCLE_GUARD"
            };
            string[] assemblyInventoryForbiddenTokens =
            {
                "GetInstances()",
                "CreateFilter(",
                "SetFilter(",
                "Select()",
                "GetFaces()",
                "OpenDocument(",
                "OpenDocumentAsync(",
                "SetActiveDocument(",
                "Save()",
                "SaveAs(",
                "SuppressComponents(",
                "CreateProcedure(",
                "RemoveAttribute(",
                ".Attach(",
                ".Detach(",
                ".Move(",
                ".Rotate(",
                ".ScaleFactor(",
                ".Inverse(",
                "VisitedIdentity",
                "(interop.CimMdlrAPI._IAssInstance)instance",
                "extended.Show_",
                "set_",
                ".Show_ =",
                "Show_="
            };
            if (assemblyInventoryRequiredTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                assemblyInventoryForbiddenTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) >= 0) ||
                assemblyEntitySource.IndexOf(".Execute(", StringComparison.Ordinal) >= 0 ||
                assemblyEntitySource.IndexOf("selection.Selection", StringComparison.Ordinal) >= 0 ||
                assemblyEntitySource.IndexOf("PushPickTool", StringComparison.Ordinal) >= 0 ||
                assemblyEntitySource.IndexOf("PopTool", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B Assembly diagnostic must remain inside the approved read-only installed-Interop allow-list with timeout, traversal limits, cycle guard, attribute reads, and no-mutation evidence.");
            }

            if (projectSource.IndexOf("<Compile Include=\"AssemblyEntityInventory.cs\" />", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<Compile Include=\"DiagnosticTraceWriter.cs\" />", StringComparison.Ordinal) < 0 ||
                programSource.IndexOf("--assembly-entities", StringComparison.Ordinal) < 0 ||
                programSource.IndexOf("--occurrence-only", StringComparison.Ordinal) < 0 ||
                programSource.IndexOf("--trace-selftest", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 Assembly entity inventory/trace diagnostic source and entry points must remain present.");
            }

            string[] durableTraceRequiredTokens =
            {
                "Environment.SpecialFolder.LocalApplicationData",
                "CimatronCustomization",
                "diagnostics",
                "FileOptions.WriteThrough",
                "stream.Flush(true)",
                "Environment.CommandLine",
                "IsElevated()",
                "GetApartmentState()",
                "HEARTBEAT alive; lastCheckpoint="
            };
            if (durableTraceRequiredTokens.Any(value => traceWriterSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                traceWriterSource.IndexOf("interop.", StringComparison.OrdinalIgnoreCase) >= 0 ||
                traceWriterSource.IndexOf("CimAppAccess", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 durable trace must remain user-writable, write-through, environment-aware, heartbeat-enabled, and independent of Cimatron APIs.");
            }

            string[] selfTestRequiredTokens =
            {
                "Dispatch: trace-selftest",
                "TRACE SELFTEST checkpoint 1",
                "TRACE SELFTEST checkpoint 2",
                "TRACE SELFTEST completed"
            };
            if (selfTestRequiredTokens.Any(value => programSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                captureSource.IndexOf("'trace-selftest'", StringComparison.Ordinal) < 0 ||
                captureSource.IndexOf("@('--trace-selftest')", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 trace self-test must retain its Cimatron-independent checkpoints and named capture task.");
            }

            string[] attachDiagnosticRequiredTokens =
            {
                "--attach-only",
                "--apartment=STA",
                "--apartment=MTA",
                "worker.SetApartmentState(requestedApartment)",
                "AttachTimeoutMilliseconds = 30000",
                "ATTACH CHECKPOINT A2",
                "ATTACH CHECKPOINT A3",
                "ATTACH TIMEOUT",
                "return 5;",
                "GetApplication reflection signature",
                "GetInterfaces()",
                "Process.GetProcessesByName(\"CimatronE\")",
                "CimatronProcessCount:",
                "SessionId=",
                "Elevated=",
                "ATTACH PRECONDITION FAILED: confirmed elevation mismatch",
                "AttachElevationMismatchExitCode = 6",
                "OPERATOR_CONFIRMATION_REQUIRED"
            };
            if (attachDiagnosticRequiredTokens.Any(value => programSource.IndexOf(value, StringComparison.Ordinal) < 0))
            {
                throw new InvalidOperationException(
                    "Step 05C2 attach-only diagnostic must retain switchable STA/MTA execution, bounded observation, inherited-interface signature evidence, exact CimatronE process/elevation evidence, and mismatch fail-fast behavior.");
            }

            string[] assemblyBudgetEvidenceRequiredTokens =
            {
                "TryConsumeOccurrence",
                "TryConsumeEntityInspection",
                "OccurrenceLimitReached",
                "EntityInspectionLimitReached",
                "ENTITIES_NOT_INSPECTED_ENTITY_BUDGET_EXHAUSTED",
                "PARTIAL_ENTITY_INSPECTION_BUDGET_EXHAUSTED",
                "DISABLED_OCCURRENCE_ONLY",
                "EntityInspectionStatus",
                "TotalRunTime:",
                "MbCoolingViaOccurrence: PROVEN BY USER-VALIDATED 0.15.23 RUN",
                "MbPocketViaOccurrence: PROVEN BY USER-VALIDATED 0.15.24 KNOWN-ANSWER RUN",
                "OccurrenceIdentityFinding: InstanceId is not authoritative placed-occurrence identity",
                "CycleGuardRuntimeStatus: recursive self-assembly cycle not exercised in live Cimatron validation",
                "HiddenStateDetection: RUNTIME CANDIDATE COMPARISON PENDING",
                "FalseNegativeRule:"
            };
            if (assemblyBudgetEvidenceRequiredTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                programSource.IndexOf("AssemblyEntityInventory.Run(!occurrenceOnly)", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B must keep occurrence traversal and entity-inspection budgets independent, explicitly mark skipped/partial entity inspection, record runtime/open findings, and expose read-only occurrence-only mode.");
            }

            string[] assemblyInventoryCheckpointTokens =
            {
                "CHECKPOINT ",
                "Console.Out.Flush()",
                "WriteCheckpoint(ref checkpointNumber, \"BEGIN API \" + label)",
                "T value = call();",
                "WriteCheckpoint(ref checkpointNumber, \"END API \" + label)",
                "AppAccess.GetApplication",
                "IApplication.GetActiveDoc",
                "IAssemblyModel.GetRootInstance",
                "string parentId = \"ROOT/N/A\";",
                "if (!isRoot)",
                "IAssInstance.get_AssParentInstance",
                "IAssInstance.get_SubInstances",
                "IAssInstance.GetAllEntities",
                "IAttributeSink.GetAttribute(cmAttInteger, ",
                "IAssInstance.get_Transformation(",
                "IModelTransformation.get_Matrix",
                "IModelTransformation.get_Vector",
                "ICimDocument.IsModified"
            };
            if (assemblyInventoryCheckpointTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) < 0))
            {
                throw new InvalidOperationException(
                    "Step 05C2 Assembly entity inventory must retain immediate diagnostic checkpoints around the approved potentially blocking COM calls.");
            }

            int rootParentGuard = assemblyEntitySource.IndexOf("if (!isRoot)", StringComparison.Ordinal);
            int parentCall = assemblyEntitySource.IndexOf("IAssInstance.get_AssParentInstance", StringComparison.Ordinal);
            if (rootParentGuard < 0 || parentCall <= rootParentGuard)
            {
                throw new InvalidOperationException(
                    "Step 05C2 root pseudo-instance must skip the parent-instance COM call and record parent as not applicable.");
            }

            int beginApiCheckpoint = assemblyEntitySource.IndexOf(
                "WriteCheckpoint(ref checkpointNumber, \"BEGIN API \" + label)",
                StringComparison.Ordinal);
            int wrappedApiCall = assemblyEntitySource.IndexOf("T value = call();", StringComparison.Ordinal);
            int endApiCheckpoint = assemblyEntitySource.IndexOf(
                "WriteCheckpoint(ref checkpointNumber, \"END API \" + label)",
                StringComparison.Ordinal);
            if (beginApiCheckpoint < 0 || wrappedApiCall <= beginApiCheckpoint || endApiCheckpoint <= wrappedApiCall)
            {
                throw new InvalidOperationException(
                    "Step 05C2 Assembly API wrapper must checkpoint immediately before and after the wrapped COM call.");
            }

            string srcDirectory = Path.Combine(repositoryRoot, "src");
            foreach (string productionProject in Directory.GetFiles(srcDirectory, "*.csproj", SearchOption.AllDirectories))
            {
                string text = File.ReadAllText(productionProject);
                if (text.IndexOf("CimatronCustomization.ZoomCommandDiscovery", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    throw new InvalidOperationException(
                        "Production projects must not reference the Step 05C1 diagnostic tool: " + productionProject);
                }
            }

            string integrationTestProject = Path.Combine(
                repositoryRoot,
                "tests",
                "CimatronCustomization.CimatronIntegrationTests",
                "CimatronCustomization.CimatronIntegrationTests.csproj");
            string integrationTestProgram = Path.Combine(
                repositoryRoot,
                "tests",
                "CimatronCustomization.CimatronIntegrationTests",
                "Program.cs");
            if (File.ReadAllText(integrationTestProject).IndexOf("ZoomCommandDiscovery", StringComparison.OrdinalIgnoreCase) >= 0 ||
                File.ReadAllText(integrationTestProgram).IndexOf("discover-zoom-commands", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                throw new InvalidOperationException(
                    "The obsolete 0.15.6 test-executable zoom discovery hook must remain removed.");
            }
        }

        private static void AssertProjectReferences(string repositoryRoot, string projectName, params string[] expectedProjectNames)
        {
            string projectPath = GetProjectPath(repositoryRoot, projectName);
            XDocument document = XDocument.Load(projectPath);

            string[] actualProjectNames = document
                .Descendants(MsBuildNamespace + "ProjectReference")
                .Select(reference => reference.Element(MsBuildNamespace + "Name"))
                .Where(name => name != null)
                .Select(name => name.Value)
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            string[] expected = expectedProjectNames
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (!actualProjectNames.SequenceEqual(expected, StringComparer.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    projectName + " project references are invalid. Expected: [" + string.Join(", ", expected) +
                    "]; Actual: [" + string.Join(", ", actualProjectNames) + "].");
            }
        }

        private static void AssertNoProjectReference(string projectPath, string forbiddenProjectName)
        {
            XDocument document = XDocument.Load(projectPath);
            bool found = document
                .Descendants(MsBuildNamespace + "ProjectReference")
                .Select(reference => reference.Element(MsBuildNamespace + "Name"))
                .Where(name => name != null)
                .Any(name => string.Equals(name.Value, forbiddenProjectName, StringComparison.OrdinalIgnoreCase));

            if (found)
            {
                throw new InvalidOperationException(
                    Path.GetFileNameWithoutExtension(projectPath) + " must not reference " + forbiddenProjectName + ".");
            }
        }

        private static void AssertNoAssemblyReferencesContaining(string projectPath, params string[] forbiddenFragments)
        {
            XDocument document = XDocument.Load(projectPath);
            IEnumerable<string> references = document
                .Descendants(MsBuildNamespace + "Reference")
                .Select(reference => (string)reference.Attribute("Include"))
                .Where(include => !string.IsNullOrWhiteSpace(include));

            foreach (string reference in references)
            {
                foreach (string forbiddenFragment in forbiddenFragments)
                {
                    if (reference.IndexOf(forbiddenFragment, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        throw new InvalidOperationException(
                            Path.GetFileNameWithoutExtension(projectPath) +
                            " contains forbidden direct Cimatron dependency: " + reference + ".");
                    }
                }
            }
        }

        private static void ZoomSelectionValidationMustRemainControlledAndDevelopmentOnly(string repositoryRoot)
        {
            string toolDirectory = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.ZoomCommandDiscovery");
            string validationSourcePath = Path.Combine(toolDirectory, "ZoomSelectionValidation.cs");
            string projectPath = Path.Combine(toolDirectory, "CimatronCustomization.ZoomCommandDiscovery.csproj");
            string programPath = Path.Combine(toolDirectory, "Program.cs");

            if (!File.Exists(validationSourcePath))
            {
                throw new InvalidOperationException("Step 05C2 requires the controlled Zoom Selection validation diagnostic.");
            }

            string validationSource = File.ReadAllText(validationSourcePath);
            string projectSource = File.ReadAllText(projectPath);
            string programSource = File.ReadAllText(programPath);

            if (validationSource.IndexOf("private const string ZoomCategoryName = \"&Display\";", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("private const string ZoomCommandName = \"Zoom Selection\";", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("GetCommand(ZoomCategoryName, ZoomCommandName)", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("zoomSelectionCommand.Execute();", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 may execute only the explicitly discovered &Display / Zoom Selection native command.");
            }

            if (CountOccurrences(validationSource, ".Execute();") != 1)
            {
                throw new InvalidOperationException(
                    "Step 05C2 diagnostic must contain exactly one native command execution call.");
            }

            if (validationSource.IndexOf("selection.Selection = validationSelection;", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("RestorePreviousSelection", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 must use the verified ISelection.Selection boundary and restore the prior selection after validation.");
            }

            string[] forbiddenCalls =
            {
                "ExecutePluginCommand",
                "PushPickTool",
                "PopTool",
                "SetActiveDocument",
                "UpdateSelection("
            };
            if (forbiddenCalls.Any(value => validationSource.IndexOf(value, StringComparison.Ordinal) >= 0))
            {
                throw new InvalidOperationException(
                    "Step 05C2 controlled validation must not broaden into other Cimatron command, PickTool, document, or selection mutation APIs.");
            }

            if (projectSource.IndexOf("interop.CimMdlrAPI.dll", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<Compile Include=\"ZoomSelectionValidation.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 diagnostic project must compile only the approved Cimatron selection validation source with the installed Cimatron modeler interop.");
            }

            if (programSource.IndexOf("--validate-zoom-selection", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 diagnostic entry point is missing the approved controlled validation mode.");
            }

            string srcDirectory = Path.Combine(repositoryRoot, "src");
            foreach (string productionProject in Directory.GetFiles(srcDirectory, "*.csproj", SearchOption.AllDirectories))
            {
                string text = File.ReadAllText(productionProject);
                if (text.IndexOf("CimatronCustomization.ZoomCommandDiscovery", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    throw new InvalidOperationException(
                        "Production projects must not reference the Step 05C2 diagnostic tool: " + productionProject);
                }
            }
        }


        private static void PartMaterialApiReflectionInvestigationMustRemainReflectionOnly(string repositoryRoot)
        {
            string toolDirectory = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.ApiCapabilityVerification");
            string investigationPath = Path.Combine(toolDirectory, "PartMaterialApiReflectionInvestigation.cs");
            string projectPath = Path.Combine(toolDirectory, "CimatronCustomization.ApiCapabilityVerification.csproj");
            string programPath = Path.Combine(toolDirectory, "Program.cs");
            string invokePath = Path.Combine(repositoryRoot, "tools", "Invoke-ApiCapabilityVerification.ps1");

            if (!File.Exists(investigationPath))
            {
                throw new InvalidOperationException("Part Material API reflection investigation source is missing.");
            }

            string source = File.ReadAllText(investigationPath);
            string[] requiredTokens =
            {
                "Assembly.ReflectionOnlyLoadFrom",
                "IApplication", "IPdm", "IDocAttribute", "DocAttribute", "ICimDocument", "IPartDocument",
                "IAssemblyDocument", "IModel", "IMdlrModel", "IAssInstance", "IAssemblyModel",
                "GetPdm", "RetriveDocAttribute", "RetriveLinkAttribute", "GetRelatedDocuments", "GetDocumentByPath", "TitleOfPid",
                "GLOBAL MATERIAL-NAMED MEMBER INVENTORY",
                "RuntimeCalls: NONE (reflection-only installed-Interop investigation)",
                "Native Part Material attribute identity: NOT VERIFIED",
                "Classification=A", "Classification=B"
            };
            if (requiredTokens.Any(token => source.IndexOf(token, StringComparison.Ordinal) < 0))
            {
                throw new InvalidOperationException("Part Material API investigation must retain the approved reflection-only targets and evidence contract.");
            }

            string[] forbiddenTokens =
            {
                "GetApplication(", "GetActiveDoc(", "AppAccess", "CimApplicationProvider", "GetPdm(",
                "MethodInfo.Invoke", ".Invoke(", "PropertyInfo.GetValue", ".GetValue(", "InvokeMember",
                "Activator.CreateInstance", "GetTypeFromProgID", "Marshal.GetActiveObject"
            };
            if (forbiddenTokens.Any(token => source.IndexOf(token, StringComparison.Ordinal) >= 0))
            {
                throw new InvalidOperationException("Part Material API investigation must not attach to Cimatron or invoke reflected/runtime members.");
            }

            string projectSource = File.ReadAllText(projectPath);
            if (projectSource.IndexOf("<Compile Include=\"PartMaterialApiReflectionInvestigation.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Part Material API investigation must remain explicitly compiled by the old-style verification project.");
            }

            string programSource = File.ReadAllText(programPath);
            if (programSource.IndexOf("--reflect-part-material-api", StringComparison.Ordinal) < 0 ||
                programSource.IndexOf("PartMaterialApiReflectionInvestigation.Run()", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Part Material API reflection command registration is missing.");
            }

            string invokeSource = File.ReadAllText(invokePath);
            if (invokeSource.IndexOf("part-material-reflect", StringComparison.Ordinal) < 0 ||
                invokeSource.IndexOf("--reflect-part-material-api", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Part Material API reflection PowerShell mode is missing.");
            }
        }

        private static void ApiCapabilityVerificationMustRemainReadOnlyAndDevelopmentOnly(string repositoryRoot)
        {
            string toolDirectory = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.ApiCapabilityVerification");
            string projectPath = Path.Combine(toolDirectory, "CimatronCustomization.ApiCapabilityVerification.csproj");
            string reflectionPath = Path.Combine(toolDirectory, "CapabilityApiReflectionInventory.cs");
            if (!File.Exists(projectPath) || !File.Exists(reflectionPath))
            {
                throw new InvalidOperationException("Step 07 API capability verification tool is missing.");
            }

            string projectSource = File.ReadAllText(projectPath);
            if (projectSource.IndexOf("C:\\Program Files\\Cimatron\\Cimatron\\2026.0\\Program", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<ApplicationManifest>app.manifest</ApplicationManifest>", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<PlatformTarget>x64</PlatformTarget>", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("interop.CimServicesAPI.dll", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07 verification tool must remain x64, Program-folder output, embedded-manifest, and explicitly reference installed CimServicesAPI.");
            }

            string reflectionSource = File.ReadAllText(reflectionPath);
            if (reflectionSource.IndexOf("ReflectionOnlyLoadFrom", StringComparison.Ordinal) < 0 ||
                reflectionSource.IndexOf("RuntimeCalls: NONE (reflection-only installed-Interop inventory)", StringComparison.Ordinal) < 0 ||
                reflectionSource.IndexOf("AppAccess", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetActiveDoc()", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("Step 07 07A path must remain installed-Interop reflection-only with no Cimatron runtime attach.");
            }

            string[] sourceFiles = Directory.GetFiles(toolDirectory, "*.cs", SearchOption.AllDirectories);
            string combined = string.Join("\n", sourceFiles.Where(path => !string.Equals(path, reflectionPath, StringComparison.OrdinalIgnoreCase)).Select(File.ReadAllText));
            string[] forbiddenTokens =
            {
                "Show =", ".Color =", ".Lock =", ".Attribute =", "IgnoreInShowOperations =", "ActiveInstance =", "ActivateUcs =",
                "SuppressComponents", "SetDimensionByName", "RenameComponent", "CreateProcedure", "DeleteProcedure", "DeleteProcedureById",
                ".Execute()", "Save()", "SaveAs(", "Close()", "SetActiveDocument", "PushPickTool", "PopTool", "ExecutePluginCommand", "GetCommand",
                "GetAttributeFactory", "AddProcedure"
            };
            if (forbiddenTokens.Any(token => combined.IndexOf(token, StringComparison.Ordinal) >= 0))
            {
                throw new InvalidOperationException("Step 07 verification source contains a prohibited modifying Cimatron API token.");
            }

            string assemblySource = File.ReadAllText(Path.Combine(toolDirectory, "AssemblyContextVerification.cs"));
            if (assemblySource.IndexOf("previousSelection = selection.Selection", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("selection.Selection = highlightList", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("RestoreSelection(context, previousSelection)", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("restore = (interop.CimMdlrAPI.ICimEntityList)new interop.CimBaseAPI.CimEntityList()", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("selection.Selection = restore", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07 optional highlight must snapshot selection, restore through the guarded helper, and restore an empty list when the original selection was empty.");
            }

            string componentSource = File.ReadAllText(Path.Combine(toolDirectory, "ComponentPropertySourceVerification.cs"));
            if (componentSource.IndexOf("Path.GetTempPath()", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("\"CimatronCustomization\", \"Step07\"", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("bom.Export(stem", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07 BOM export must remain constrained to a new %TEMP%/CimatronCustomization/Step07 folder.");
            }

            if (componentSource.IndexOf("instance.GetAllEntities()", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("FindBodyEntityOnOccurrence", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("sink.GetAttribute(", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("AttributeEnumType.cmAttString", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("partModel.GetEntityById(args.EntityId.Value, partModel)", StringComparison.Ordinal) >= 0 ||
                componentSource.IndexOf("string.Equals(attribute.Name, knownAttributeName", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("Step 07C-3 known-body verification must use occurrence-reached entity enumeration plus exact named string-attribute lookup, without the failed model GetEntityById path or returned IAttribute.Name equality gate.");
            }

            string hiddenStateSource = File.ReadAllText(Path.Combine(toolDirectory, "HiddenStateCandidateVerification.cs"));
            if (hiddenStateSource.IndexOf("instance.GetAllEntities()", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("visibleEntity.Show", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("context.TryObserve(\"GetBomManager\"", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("BOM.Stage: SKIPPED_AFTER_READ_ERROR", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("BOMMembership.Difference.OnlyInNoFiltering", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("BOMMembership.SemanticsAssignedInCode=FALSE", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("StoppingRule: SINGLE RUN", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07C-4 hidden-state verification must remain getter-only, occurrence/body discriminating, BOM-membership explicit, semantics-neutral, and single-run governed.");
            }

            if (combined.IndexOf("No-mutation evidence: ", StringComparison.Ordinal) < 0 ||
                combined.IndexOf("CHANGED_OR_UNVERIFIED", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Every Step 07 live verification mode must retain no-mutation evidence and fail-closed wording.");
            }

            string srcDirectory = Path.Combine(repositoryRoot, "src");
            foreach (string productionProject in Directory.GetFiles(srcDirectory, "*.csproj", SearchOption.AllDirectories))
            {
                if (File.ReadAllText(productionProject).IndexOf("CimatronCustomization.ApiCapabilityVerification", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    throw new InvalidOperationException("Production projects must not reference the Step 07 development-only verification tool: " + productionProject);
                }
            }
        }

        private static void Cr04V15FormReaderMustRemainGuarded(string repositoryRoot)
        {
            Dictionary<string, string> protectedHashes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "src/CimatronCustomization.Infrastructure/ExcelTabularDataReader.cs", "9858864342f8a5f1424aeb990b0710a063659681566cfb4c0701cd0b957df0ce" },
                { "src/CimatronCustomization.Application/ReadMappedTabularData.cs", "12e04641d9d75d2a13a3a490662f7af41a709e469503eaade660282d07d8aad1" },
                { "src/CimatronCustomization.Application/TabularMappingEngine.cs", "2e0f41a7c6c6e9490063775466dad83e3cddfbc671bcb3713d5ba96b4650ca16" },
                { "src/CimatronCustomization.CimatronIntegration/CimatronAssemblyBodyAttributeReader.cs", "7fede8fcd63d4bbad4213110cc561c5b78f2b41d1cc57d64623398c283106368" },
                { "src/CimatronCustomization.Domain/SteelGradeDesignOrderEvaluation.cs", "d96a9640cb41ff3cc567272d273b483b9c541c37c9be37e59ee46ae1e067483e" },
                { "src/CimatronCustomization.Domain/SteelGradeNormalizer.cs", "e04ea719beb39ada1909c038a86b64d4864119ccbcd75f3d747cf486cd7c7ca9" },
                { "src/CimatronCustomization.Application/SteelGradeOccurrenceHighlightSafety.cs", "cee7a144788bd93af7ac86aeaaa54a14f8deaf9f73c636dd8ede51aaa0286964" },
                { "src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityHighlighter.cs", "aea16a6ee05e3bc873dc5785784bfebd5a564548a7c66c03fa7e457247eb9711" }
            };

            foreach (KeyValuePair<string, string> item in protectedHashes)
            {
                string path = Path.Combine(repositoryRoot, item.Key.Replace('/', Path.DirectorySeparatorChar));
                string actual = ComputeSha256(path);
                if (!string.Equals(actual, item.Value, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("CR-04 v1.5 protected file changed without approval: " + item.Key + ".");
            }

            string formReaderPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Infrastructure", "ExcelDesignOrderFormReader.cs");
            string formReader = File.ReadAllText(formReaderPath);
            string[] requiredTokens =
            {
                "FileMode.Open",
                "FileAccess.Read",
                "FileShare.ReadWrite",
                "CreateBinaryReader",
                "CreateOpenXmlReader",
                "FORM_TEMPLATE_GUARD_MISMATCH",
                "FORM_LABEL_NOT_FOUND",
                "FORM_LABEL_DUPLICATE",
                "FORM_MATERIAL_SELECTION_MARKER_INVALID",
                "FORM_MATERIAL_SELECTION_MULTIPLE",
                "FORM_REMARK_REQUIRED",
                "FORM_MATERIAL_SELECTION_REQUIRED",
                "selectedFamily",
                "rawRemark"
            };
            if (requiredTokens.Any(token => formReader.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 Form reader lost a required read-only or fail-closed source contract.");

            string[] forbiddenTokens = { ".Save(", "FileAccess.Write", "FileMode.Create", "ExcelTabularDataReader", "ReadMappedTabularData" };
            if (forbiddenTokens.Any(token => formReader.IndexOf(token, StringComparison.Ordinal) >= 0))
                throw new InvalidOperationException("CR-04 v1.5 Form reader must remain read-only and separate from the generic Table reader.");

            string infrastructureRunner = File.ReadAllText(Path.Combine(repositoryRoot, "tests", "CimatronCustomization.Infrastructure.Tests", "Program.cs"));
            if (infrastructureRunner.IndexOf("ExcelDesignOrderFormReaderTests.RunAll()", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 v1.5 Form-reader tests must be explicitly registered in the Infrastructure test runner.");

            string fixturePath = Path.Combine(repositoryRoot, "tests", "CimatronCustomization.Infrastructure.Tests", "TestData", "CR04", "AnonymizedForm.xlsx");
            if (!File.Exists(fixturePath))
                throw new InvalidOperationException("CR-04 v1.5 anonymized Form fixture is missing.");

            string[] clientWorkbookMatches = Directory.GetFiles(repositoryRoot, "*.xlsx", SearchOption.AllDirectories)
                .Where(path => Path.GetFileName(path).IndexOf("4075", StringComparison.OrdinalIgnoreCase) >= 0)
                .ToArray();
            if (clientWorkbookMatches.Length > 0)
                throw new InvalidOperationException("The production client Design Order workbook must not be present in the repository/package.");
        }


        private static void Cr04V15Slice2MappingMustRemainGuarded(string repositoryRoot)
        {
            string resultStatus = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Domain", "ResultStatus.cs"));
            if (resultStatus.IndexOf("Info,", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 v1.5 requires the distinct ResultStatus.Info informational status.");

            string useCase = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Application", "VerifySteelGradeAgainstDesignOrder.cs"));
            string formMethodToken = "private IReadOnlyList<Finding> ExecuteForm(";
            int formStart = useCase.IndexOf(formMethodToken, StringComparison.Ordinal);
            int nextMethod = formStart < 0 ? -1 : useCase.IndexOf("        private AssemblyBodyAttributeSnapshot ReadAssembly(", formStart, StringComparison.Ordinal);
            if (formStart < 0 || nextMethod < 0)
                throw new InvalidOperationException("CR-04 v1.5 Form orchestration boundary could not be located.");

            string formMethod = useCase.Substring(formStart, nextMethod - formStart);
            string[] requiredFormTokens =
            {
                "formReader.Read(",
                "partDocumentPropertyReader.Read(occurrence.ModelPid)",
                "PartTypeCategoryResolver.TryResolve(",
                "SteelGradeVocabularyValidation.IsKnownDesignOrderValue(",
                "SteelGradeVocabularyValidation.IsKnownCadValue(",
                "CAD_PART_TYPE_MISSING",
                "CAD_PART_TYPE_UNSUPPORTED",
                "[CAD_PART_MATERIAL_MISSING]",
                "[MOULD_NUMBER_CHECK_NOT_PERFORMED]",
                "SteelGradeDesignOrderEvaluation.Evaluate("
            };
            if (requiredFormTokens.Any(token => formMethod.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 native Part Type/Part Material Form orchestration lost a required contract.");
            if (formMethod.IndexOf("SteelGradeCategoryResolver.Resolve(", StringComparison.Ordinal) >= 0 ||
                formMethod.IndexOf("GetPartMaterialValues(materialTable, occurrence.ModelTitle)", StringComparison.Ordinal) >= 0 ||
                formMethod.IndexOf("readMappedTabularData.Execute(", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("CR-04 v1.5 Form mode must not use ModelTitle category mapping, BOM correlation, or the generic Table reader.");
            }

            string applicationRunner = File.ReadAllText(Path.Combine(repositoryRoot, "tests", "CimatronCustomization.Application.Tests", "Program.cs"));
            string[] applicationRegistrations =
            {
                "VerifySteelGradeAgainstDesignOrderTests.RunAll()",
                "PartTypeCategoryResolverTests.RunAll()",
                "SteelGradeVocabularyValidationTests.RunAll()"
            };
            if (applicationRegistrations.Any(token => applicationRunner.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 native Part-property Application tests must be explicitly registered in Program.cs.");
        }

        private static void Cr04V15Slice3WiringMustRemainGuarded(string repositoryRoot)
        {
            string feature = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.DesignChecks", "SteelGradeDesignOrderValidation.cs"));
            string[] requiredFeatureTokens =
            {
                "DesignOrderFormatParameter = \"DesignOrderFormat\"",
                "DesignOrderProfileParameter = \"DesignOrderProfile\"",
                "ComponentCategorySourceParameter = \"ComponentCategorySource\"",
                "ComponentExclusionPatternsParameter = \"ComponentExclusionPatterns\"",
                "ApprovedCategorySource = \"PartType\"",
                "TryCreateTableRequest(",
                "TryCreateFormRequest(",
                "new VerifySteelGradeAgainstDesignOrderRequest(",
                "formProfile,",
                "exclusions"
            };
            if (requiredFeatureTokens.Any(token => feature.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 feature/config request wiring lost native Part Type Form-mode contract.");

            string[] forbiddenFeatureTokens =
            {
                "TryParseCategoryPatterns(patternText, formProfile",
                "new SteelGradeCategoryMappingConfiguration(categoryAttributeName, patterns, exclusions)"
            };
            if (forbiddenFeatureTokens.Any(token => feature.IndexOf(token, StringComparison.Ordinal) >= 0))
                throw new InvalidOperationException("CR-04 v1.5 Form-mode feature wiring must not depend on ModelTitle category patterns.");

            string composition = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "FeatureComposition.cs"));
            string[] requiredCompositionTokens =
            {
                "DesignOrderFormProfile cr04FormProfile = SrideviQrDg02Rev04Profile.Create()",
                "new ExcelDesignOrderFormReader()",
                "new CimatronAssemblyBodyAttributeReader()",
                "new CimatronBomMaterialTableReader(cr04TabularReader)",
                "new CimatronPartDocumentPropertyReader()",
                "new SteelGradeDesignOrderValidation(",
                "cr04FormProfile"
            };
            if (requiredCompositionTokens.Any(token => composition.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 composition lost Table/Form production wiring.");

            string config = File.ReadAllText(Path.Combine(repositoryRoot, "config", "CimatronCustomization.config.xml"));
            string[] requiredConfigTokens =
            {
                "name=\"DesignOrderFormat\" value=\"Form\"",
                "name=\"DesignOrderProfile\" value=\"Sridevi_QR-DG-02_REV04\"",
                "name=\"SteelGradeSource\" value=\"PartMaterial\"",
                "name=\"ComponentCategorySource\" value=\"PartType\"",
                "name=\"SteelGradeRepresentation\" value=\"Strict\"",
                "name=\"CompareGradeTokenOnly\" value=\"false\""
            };
            if (requiredConfigTokens.Any(token => config.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 production configuration lost an approved native Part-property policy value.");
            if (config.IndexOf("name=\"ComponentCategoryPatterns\"", StringComparison.Ordinal) >= 0)
                throw new InvalidOperationException("CR-04 v1.5 production configuration must not retain ModelTitle category patterns.");
        }

        private static void Cr04PartMaterialProductionSourceMustRemainGuarded(string repositoryRoot)
        {
            string nativeReaderPath = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration", "CimatronPartDocumentPropertyReader.cs");
            string nativeReader = File.ReadAllText(nativeReaderPath);
            string[] requiredNativeTokens =
            {
                "GetPdm()",
                "RetriveDocAttribute(modelPid, ref rawAttributes, string.Empty)",
                "TMPL::Part_Type",
                "TMPL::Material",
                "interop.CimBaseAPI.IDocAttribute",
                "PartDocumentPropertyResult.Succeeded("
            };
            if (requiredNativeTokens.Any(token => nativeReader.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 native Part-property adapter lost the runtime-verified PDM read contract.");

            string[] forbiddenNativeTokens =
            {
                "UpdateDocAttribute", "UpdateLinkAttribute", ".Save(", "SaveAs(", "SetAttribute", ".Attach(", "GetAttributeFactory", "CreateEntity"
            };
            if (forbiddenNativeTokens.Any(token => nativeReader.IndexOf(token, StringComparison.Ordinal) >= 0))
                throw new InvalidOperationException("CR-04 native Part-property adapter must remain strictly read-only.");

            string bomReader = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration", "CimatronBomMaterialTableReader.cs"));
            if (bomReader.IndexOf("assembly.GetBomManager()", StringComparison.Ordinal) < 0 || bomReader.IndexOf("IBOM.Export(cmNoFiltering)", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 Table-mode BOM material route must remain available and unchanged.");

            string config = File.ReadAllText(Path.Combine(repositoryRoot, "config", "CimatronCustomization.config.xml"));
            if (config.IndexOf("name=\"SteelGradeSource\" value=\"PartMaterial\"", StringComparison.Ordinal) < 0 ||
                config.IndexOf("STEEL_GRADE", StringComparison.Ordinal) >= 0)
                throw new InvalidOperationException("CR-04 production config must use native Part Material and must not depend on STEEL_GRADE.");

            string applicationProject = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Application", "CimatronCustomization.Application.csproj"));
            string integrationProject = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration", "CimatronCustomization.CimatronIntegration.csproj"));
            if (applicationProject.IndexOf("<Compile Include=\"IPartDocumentPropertyReader.cs\" />", StringComparison.Ordinal) < 0 ||
                applicationProject.IndexOf("<Compile Include=\"PartDocumentPropertyResult.cs\" />", StringComparison.Ordinal) < 0 ||
                integrationProject.IndexOf("<Compile Include=\"CimatronPartDocumentPropertyReader.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 native Part-property source files must remain explicitly compiled by old-style projects.");
            }
        }

        private static void Cr04V15Slice4CategoryContractMustRemainGuarded(string repositoryRoot)
        {
            string profile = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Infrastructure", "SrideviQrDg02Rev04Profile.cs"));
            string[] approvedCategoryTokens =
            {
                "Category(\"Cavity\", \"Cavity\", \"Cavity\"",
                "Category(\"Core\", \"Core\", \"Core\"",
                "Category(\"CavityInsert\", \"Cavity Insert\", \"Cavity Insert\"",
                "Category(\"CoreInsert\", \"Core Insert\", \"Core Insert\"",
                "Category(\"MovingCore\", \"Moving Core\", \"Moving Core\"",
                "Category(\"AngularLifter\", \"Angular Lifter\", \"Angular Lifter\"",
                "Category(\"PressurePad\", \"Pressuer Pad\", \"Pressure Pad\"",
                "Category(\"WearPad\", \"Wear Pad\", \"Wear Pad\"",
                "Category(\"MouldBase\", \"Mould Base\", \"Mould Base\"",
                "new DesignOrderFormMaterialFamilyDefinition(\"P-20\", 2)",
                "new DesignOrderFormMaterialFamilyDefinition(\"AL\", 3)",
                "new DesignOrderFormMaterialFamilyDefinition(\"CK-45\", 4)",
                "new DesignOrderFormMaterialFamilyDefinition(\"BE-CU\", 5)",
                "new DesignOrderFormMaterialFamilyDefinition(\"Hardened\", 6)",
                "new DesignOrderFormMaterialFamilyDefinition(\"Nitrided\", 7)"
            };
            if (approvedCategoryTokens.Any(token => profile.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 lost an approved Sridevi Part Type/category/material-family contract.");

            string formReader = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Infrastructure", "ExcelDesignOrderFormReader.cs"));
            string[] requiredReaderTokens =
            {
                "string marker =",
                "StringComparison.OrdinalIgnoreCase",
                "FORM_MATERIAL_SELECTION_MULTIPLE",
                "FORM_REMARK_REQUIRED",
                "FORM_MATERIAL_SELECTION_REQUIRED",
                "rawRemark",
                "remark = rawRemark.Trim()",
                "string.Equals(rowLabel, expectedLabel, StringComparison.OrdinalIgnoreCase)",
                "CountNormalizedLabel"
            };
            if (requiredReaderTokens.Any(token => formReader.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 v1.5 lost Design-Order X/Remark trimming and fail-closed validation.");

            string resolver = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Application", "PartTypeCategoryResolver.cs"));
            if (resolver.IndexOf("NormalizeCategoryText", StringComparison.Ordinal) < 0 ||
                resolver.IndexOf("StringComparison.OrdinalIgnoreCase", StringComparison.Ordinal) < 0 ||
                resolver.IndexOf("char.IsWhiteSpace", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Part Type mapping must trim/collapse whitespace and compare case-insensitively.");
            }

            string config = File.ReadAllText(Path.Combine(repositoryRoot, "config", "CimatronCustomization.config.xml"));
            if (config.IndexOf("ComponentCategoryPatterns", StringComparison.Ordinal) >= 0 || config.IndexOf("ModelTitleWithOptionalAttributeOverride", StringComparison.Ordinal) >= 0)
                throw new InvalidOperationException("CR-04 v1.5 production config must not retain the superseded ModelTitle mapping contract.");
        }

        private static void ResultReportCsvExportMustRemainGuarded(string repositoryRoot)
        {
            string window = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "FindingReportWindow.cs"));
            string exporter = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "ResultReportCsvExporter.cs"));
            string pluginProject = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "CimatronCustomization.Plugin.csproj"));

            string[] requiredWindowTokens =
            {
                "Text = \"Export Results\"",
                "SaveFileDialog",
                "CSV files (*.csv)|*.csv",
                "foreach (ResultRow row in rows)",
                "List<ResultReportCsvRow> exportRows = BuildCsvRows()",
                "ResultReportCsvExporter.Export(dialog.FileName, exportRows, correlationId, BuildCsvSummary(exportRows))",
                "finding.ComponentContexts",
                "context.OccurrenceOrder",
                "viewportEntityHighlighter.RestoreSelection()"
            };
            if (requiredWindowTokens.Any(token => window.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("Result Report CSV export lost its approved unfiltered export or selection-restoration contract.");

            string[] requiredExporterTokens =
            {
                "ComponentTitle,OccurrencePath,InstanceId,PartType,MoldPartMaterial,ValidationStatus,FindingCode,Feature,Requirement,Message,Measured,Limit,CorrelationId",
                "new UTF8Encoding(true)",
                "private static readonly char[] CsvSpecialCharacters",
                "text.IndexOfAny(CsvSpecialCharacters)",
                "text.Replace(\"\\\"\", \"\\\"\\\"\")",
                "ExtractFindingCode",
                "ClassifyStatus",
                "DO_COMPONENT_NOT_FOUND",
                "CAD_NON_PART_SKIPPED",
                "CAD_SYNTHETIC_ROOT_SKIPPED",
                "ACTION REQUIRED",
                ".OrderBy(row => row.OccurrenceOrder.HasValue ? 0 : 1)",
                "WriteSummaryRow(writer, \"PASS\"",
                "WriteSummaryRow(writer, \"NOT FOUND\"",
                "WriteSummaryRow(writer, \"Overall Status\""
            };
            if (requiredExporterTokens.Any(token => exporter.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("Result Report CSV exporter lost approved escaping, encoding, columns, or summary behavior.");

            if (pluginProject.IndexOf("<Compile Include=\"ResultReportCsvExporter.cs\" />", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("Result Report CSV exporter must remain explicitly compiled by the Plugin project.");

            string launcher = File.ReadAllText(Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin", "FeatureLauncherWindow.cs"));
            if (launcher.IndexOf("Excel workbooks (*.xlsx;*.xls)|*.xlsx;*.xls", StringComparison.Ordinal) < 0 ||
                launcher.IndexOf("*.csv", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                throw new InvalidOperationException("CSV export output must not broaden CR-04 Design Order input beyond .xlsx/.xls.");
            }
        }

        private static void Cr04TargetComponentReadDiagnosticMustRemainGuarded(string repositoryRoot)
        {
            string pluginDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin");
            string diagnostic = File.ReadAllText(Path.Combine(pluginDirectory, "Diagnostics", "Cr04TargetComponentReadDiagnostic.cs"));
            string request = File.ReadAllText(Path.Combine(pluginDirectory, "Diagnostics", "Cr04TargetComponentReadDiagnosticRequest.cs"));
            string command = File.ReadAllText(Path.Combine(pluginDirectory, "CimatronCommandExecution.cs"));
            string pluginProject = File.ReadAllText(Path.Combine(pluginDirectory, "CimatronCustomization.Plugin.csproj"));
            string script = File.ReadAllText(Path.Combine(repositoryRoot, "tools", "Request-Cr04TargetComponentReadDiagnostic.ps1"));

            string[] requiredDiagnosticTokens =
            {
                "new CimatronAssemblyBodyAttributeReader()",
                "reader.ReadNamedAttributes(",
                "SteelGradeCategoryResolver.Resolve(",
                "STEEL_GRADE",
                "OccurrencePath|InstanceId|ModelTitle|ModelPID|BodyEntityId|STEEL_GRADE status|STEEL_GRADE value|Category resolution",
                "READ_ONLY_DIAGNOSTIC_COMPLETED"
            };
            if (requiredDiagnosticTokens.Any(token => diagnostic.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 target-component diagnostic lost required production-reader/category-resolution evidence behavior.");

            string[] forbiddenDiagnosticTokens =
            {
                ".Attach(",
                "GetAttributeFactory",
                ".Save(",
                ".SaveAs(",
                "SetAttribute",
                "Selection =",
                "Delete(",
                "CreateEntity"
            };
            foreach (string token in forbiddenDiagnosticTokens)
            {
                if (diagnostic.IndexOf(token, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("CR-04 target-component diagnostic must remain read-only; forbidden token: " + token);
            }

            string[] requiredRequestTokens =
            {
                "RequestVersion = \"0.37.0\"",
                "cr04-target-component-read-diagnostic.request",
                "MaximumRequestAge = TimeSpan.FromMinutes(30)",
                "File.Move(requestPath, consumingPath)",
                "File.Delete(consumingPath)"
            };
            if (requiredRequestTokens.Any(token => request.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 target-component diagnostic request lost its versioned one-shot/expiry guard.");

            if (command.IndexOf("Cr04TargetComponentReadDiagnostic.TryRunRequested(out cr04TargetDiagnosticResult)", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 target-component diagnostic must remain an explicit one-shot Plugin command interception.");

            if (pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04TargetComponentReadDiagnosticRequest.cs\" />", StringComparison.Ordinal) < 0 ||
                pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04TargetComponentReadDiagnostic.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 target-component diagnostic files must remain explicitly compiled by the Plugin project.");
            }

            if (script.IndexOf("Version=0.37.0", StringComparison.Ordinal) < 0 ||
                script.IndexOf("does not launch Cimatron or modify/save the model", StringComparison.Ordinal) < 0 ||
                script.IndexOf("cr04-target-component-read-diagnostic.request", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 target-component diagnostic request script must remain versioned, read-only, and developer-controlled.");
            }
        }

        private static void Cr04PartMaterialCorrelationDiagnosticMustRemainGuarded(string repositoryRoot)
        {
            string pluginDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin");
            string diagnostic = File.ReadAllText(Path.Combine(pluginDirectory, "Diagnostics", "Cr04PartMaterialCorrelationDiagnostic.cs"));
            string request = File.ReadAllText(Path.Combine(pluginDirectory, "Diagnostics", "Cr04PartMaterialCorrelationDiagnosticRequest.cs"));
            string command = File.ReadAllText(Path.Combine(pluginDirectory, "CimatronCommandExecution.cs"));
            string pluginProject = File.ReadAllText(Path.Combine(pluginDirectory, "CimatronCustomization.Plugin.csproj"));
            string script = File.ReadAllText(Path.Combine(repositoryRoot, "tools", "Request-Cr04PartMaterialCorrelationDiagnostic.ps1"));

            string[] requiredDiagnosticTokens =
            {
                "new CimatronAssemblyBodyAttributeReader()",
                "new CimatronBomMaterialTableReader(new ExcelTabularDataReader())",
                "SteelGradeCategoryResolver.Resolve(",
                "OrdinalIgnoreCase(ModelTitle, BOM Standard Number)",
                "OccurrencePath|InstanceId|ModelTitle|BOM Standard Number|BOM Material|Category resolution|Correlation result",
                "BOM SNAPSHOT",
                "READ_ONLY_CORRELATION_DIAGNOSTIC_COMPLETED"
            };
            if (requiredDiagnosticTokens.Any(token => diagnostic.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 Part Material correlation diagnostic lost required production-reader/category/correlation evidence behavior.");

            string[] forbiddenDiagnosticTokens =
            {
                ".Attach(",
                "GetAttributeFactory",
                ".Save(",
                ".SaveAs(",
                "SetAttribute",
                "Selection =",
                "Delete(",
                "CreateEntity"
            };
            foreach (string token in forbiddenDiagnosticTokens)
            {
                if (diagnostic.IndexOf(token, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("CR-04 Part Material correlation diagnostic must remain read-only; forbidden token: " + token);
            }

            string[] requiredRequestTokens =
            {
                "RequestVersion = \"0.38.3\"",
                "cr04-part-material-correlation-diagnostic.request",
                "MaximumRequestAge = TimeSpan.FromMinutes(30)",
                "File.Move(requestPath, consumingPath)",
                "File.Delete(consumingPath)"
            };
            if (requiredRequestTokens.Any(token => request.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 Part Material correlation diagnostic request lost its versioned one-shot/expiry guard.");

            if (command.IndexOf("Cr04PartMaterialCorrelationDiagnostic.TryRunRequested(out cr04PartMaterialCorrelationDiagnosticResult)", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 Part Material correlation diagnostic must remain an explicit one-shot Plugin command interception.");

            if (pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04PartMaterialCorrelationDiagnosticRequest.cs\" />", StringComparison.Ordinal) < 0 ||
                pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04PartMaterialCorrelationDiagnostic.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Part Material correlation diagnostic files must remain explicitly compiled by the Plugin project.");
            }

            if (script.IndexOf("Version=0.38.3", StringComparison.Ordinal) < 0 ||
                script.IndexOf("does not launch Cimatron or modify/save the model or Design Order", StringComparison.Ordinal) < 0 ||
                script.IndexOf("cr04-part-material-correlation-diagnostic.request", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Part Material correlation diagnostic request script must remain versioned, read-only, and developer-controlled.");
            }
        }

        private static void Cr04PartPropertyDiscoveryDiagnosticMustRemainGuarded(string repositoryRoot)
        {
            string pluginDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.Plugin");
            string diagnostic = File.ReadAllText(Path.Combine(pluginDirectory, "Diagnostics", "Cr04PartPropertyDiscoveryDiagnostic.cs"));
            string request = File.ReadAllText(Path.Combine(pluginDirectory, "Diagnostics", "Cr04PartPropertyDiscoveryDiagnosticRequest.cs"));
            string command = File.ReadAllText(Path.Combine(pluginDirectory, "CimatronCommandExecution.cs"));
            string pluginProject = File.ReadAllText(Path.Combine(pluginDirectory, "CimatronCustomization.Plugin.csproj"));
            string script = File.ReadAllText(Path.Combine(repositoryRoot, "tools", "Request-Cr04PartPropertyDiscoveryDiagnostic.ps1"));

            string[] requiredDiagnosticTokens =
            {
                "new CimatronAssemblyBodyAttributeReader()",
                "GetPdm()",
                "object rawAttributes = null;",
                "RetriveDocAttribute(occurrence.ModelPid, ref rawAttributes, string.Empty)",
                "interop.CimBaseAPI.IDocAttribute",
                ".Name",
                ".Value",
                "ReadOnlyDiagnostic=true",
                "ApiRoute=GetPdm -> RetriveDocAttribute",
                "AttributeNameGuessing=false",
                "PartTypeAttributeIdentity=NOT VERIFIED",
                "PartMaterialAttributeIdentity=NOT VERIFIED",
                "RemarkAttributeIdentity=NOT VERIFIED",
                "DocumentModifiedBefore=",
                "DocumentModifiedAfter=",
                "ModificationStateChanged=",
                "Cavity block",
                "Core block",
                "main insert",
                "Insert#2",
                "Main Core insert",
                "core fix insert-01",
                "Slider-01",
                "Lifter-01",
                "READ_ONLY_PART_PROPERTY_DISCOVERY_COMPLETED"
            };
            if (requiredDiagnosticTokens.Any(token => diagnostic.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 Part property discovery diagnostic lost required read-only PDM/document-attribute evidence behavior.");

            string[] forbiddenDiagnosticTokens =
            {
                "UpdateDocAttribute",
                "UpdateLinkAttribute",
                ".Save(",
                ".SaveAs(",
                "MakeDirty",
                ".Attach(",
                "GetAttributeFactory",
                "SetAttribute",
                "CreateDocument",
                "CreateModel",
                "OpenDocument",
                "RenameDocument",
                "DeleteDocument",
                "CreateEntity",
                "cmAccessModeWrite"
            };
            foreach (string token in forbiddenDiagnosticTokens)
            {
                if (diagnostic.IndexOf(token, StringComparison.Ordinal) >= 0)
                    throw new InvalidOperationException("CR-04 Part property discovery diagnostic must remain read-only; forbidden token: " + token);
            }

            string[] requiredRequestTokens =
            {
                "RequestVersion = \"0.38.5\"",
                "cr04-part-property-discovery-diagnostic.request",
                "MaximumRequestAge = TimeSpan.FromMinutes(30)",
                "File.Move(requestPath, consumingPath)",
                "File.Delete(consumingPath)"
            };
            if (requiredRequestTokens.Any(token => request.IndexOf(token, StringComparison.Ordinal) < 0))
                throw new InvalidOperationException("CR-04 Part property discovery request lost its versioned one-shot/expiry guard.");

            if (command.IndexOf("Cr04PartPropertyDiscoveryDiagnostic.TryRunRequested(out cr04PartPropertyDiscoveryDiagnosticResult)", StringComparison.Ordinal) < 0)
                throw new InvalidOperationException("CR-04 Part property discovery diagnostic must remain an explicit one-shot Plugin command interception.");

            if (pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04PartPropertyDiscoveryDiagnosticRequest.cs\" />", StringComparison.Ordinal) < 0 ||
                pluginProject.IndexOf("<Compile Include=\"Diagnostics\\Cr04PartPropertyDiscoveryDiagnostic.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Part property discovery diagnostic files must remain explicitly compiled by the Plugin project.");
            }

            if (script.IndexOf("Version=0.38.5", StringComparison.Ordinal) < 0 ||
                script.IndexOf("does not launch Cimatron or modify/save the model or Design Order", StringComparison.Ordinal) < 0 ||
                script.IndexOf("cr04-part-property-discovery-diagnostic.request", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("CR-04 Part property discovery request script must remain versioned, read-only, and developer-controlled.");
            }
        }

        private static string ComputeSha256(string path)
        {
            using (SHA256 sha256 = SHA256.Create())
            using (FileStream stream = File.OpenRead(path))
            {
                byte[] hash = sha256.ComputeHash(stream);
                return string.Concat(hash.Select(value => value.ToString("x2")));
            }
        }

        private static int CountOccurrences(string source, string value)
        {
            int count = 0;
            int index = 0;
            while ((index = source.IndexOf(value, index, StringComparison.Ordinal)) >= 0)
            {
                count++;
                index += value.Length;
            }

            return count;
        }

        private static string GetProjectPath(string repositoryRoot, string projectName)
        {
            return Path.Combine(repositoryRoot, "src", projectName, projectName + ".csproj");
        }

        private static string FindRepositoryRoot()
        {
            DirectoryInfo current = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);

            while (current != null)
            {
                if (File.Exists(Path.Combine(current.FullName, "CimatronCustomization.sln")) &&
                    File.Exists(Path.Combine(current.FullName, "AGENTS.md")))
                {
                    return current.FullName;
                }

                current = current.Parent;
            }

            throw new InvalidOperationException("Unable to locate the cimatron-customization repository root.");
        }
    }
}
