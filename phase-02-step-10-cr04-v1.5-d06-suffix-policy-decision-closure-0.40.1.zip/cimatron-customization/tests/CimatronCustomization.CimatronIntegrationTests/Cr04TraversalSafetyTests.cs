using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;

namespace CimatronCustomization.CimatronIntegrationTests
{
    internal static class Cr04TraversalSafetyTests
    {
        internal static void RunAll()
        {
            ExactHighlighterTraversalContractIsProtected();
            TemporaryHighlightSelectionLifecycleIsProtected();
            Cr04VerifierDispatchesOnDedicatedMtaThread();
            Cr04DoesNotUseSelfInstanceHeuristics();
            Cr04TraversalMatchesHighlighterEquivalentFakeTraversal();
            AllOccurrencesRemainEligibleForBusinessEvidence();
            SuppressedOccurrencesStillParticipateInCollisionScope();
            DepthLimitMatchesProductionHighlighter();
            ProductionAssemblyBodyAttributeAdapterContractIsProtected();
            ProductionPartMaterialAdapterContractIsProtected();
            RunWrongTypeAdapterSmokeWhenExplicitlyRequested();
        }

        private static void ExactHighlighterTraversalContractIsProtected()
        {
            string root = FindRepositoryRoot();
            string path = Path.Combine(root, "src", "CimatronCustomization.CimatronIntegration", "CimatronViewportEntityHighlighter.cs");
            string source = File.ReadAllText(path);

            AssertContains(source, "if (depth > 16)", "Production highlighter depth limit must remain 16.");
            AssertContains(source, "if (instance.ID == instanceId)", "Production highlighter must check the current instance ID before descent.");
            AssertContains(source, "instance.get_SubInstances(1, 0)", "Production highlighter must use get_SubInstances(1, 0).");
            AssertContains(source, "subInstances != null && subInstances.Length > 0 && instance.Model != null", "Production highlighter must require a non-empty sub-instance list before descent.");
            AssertContains(source, "string.Equals(instance.Model.Type.ToString(), \"cmAssembly\", StringComparison.Ordinal)", "Production highlighter must descend only through assembly models.");
        }

        private static void TemporaryHighlightSelectionLifecycleIsProtected()
        {
            string root = FindRepositoryRoot();
            string highlighterPath = Path.Combine(root, "src", "CimatronCustomization.CimatronIntegration", "CimatronViewportEntityHighlighter.cs");
            string highlighterSource = File.ReadAllText(highlighterPath);
            AssertContains(highlighterSource, "previousSelection = selection.Selection", "The highlighter must capture the pre-highlight Cimatron selection.");
            AssertContains(highlighterSource, "CaptureSelectionIfNeeded(selection);", "Selection capture must occur before the temporary highlight assignment.");
            AssertContains(highlighterSource, "capturedSelection.Selection = restore;", "The highlighter must restore the captured selection through the same verified ISelection.Selection boundary.");
            AssertContains(highlighterSource, "new interop.CimBaseAPI.CimEntityList()", "An originally empty selection must restore through an explicit empty entity list.");

            string reportPath = Path.Combine(root, "src", "CimatronCustomization.Plugin", "FindingReportWindow.cs");
            string reportSource = File.ReadAllText(reportPath);
            AssertContains(reportSource, "protected override void OnFormClosed(FormClosedEventArgs e)", "Result Report closure must own temporary-highlight restoration.");
            AssertContains(reportSource, "viewportEntityHighlighter.RestoreSelection();", "Result Report close must restore the pre-highlight selection.");
        }

        private static void Cr04VerifierDispatchesOnDedicatedMtaThread()
        {
            string root = FindRepositoryRoot();
            string path = Path.Combine(root, "tools", "CimatronCustomization.ApiCapabilityVerification", "Program.cs");
            string source = File.ReadAllText(path);

            AssertContains(source, "[STAThread]", "Existing verifier entry point must remain STA so previously validated diagnostic modes are not globally changed.");
            AssertContains(source, "internal const string ToolVersion = \"0.24.4\";", "CR-04 corrective package must display the current verifier version instead of the stale 0.24.2 banner.");
            AssertContains(source, "if (EqualsArg(args[0], \"--verify-cr04-capabilities\")) return RunCr04OnMtaThread(VerificationArguments.Parse(args));", "Only the CR-04 capability mode must dispatch through the dedicated MTA path.");
            AssertContains(source, "worker.SetApartmentState(ApartmentState.MTA);", "CR-04 verifier worker must explicitly use MTA before COM attachment.");
            AssertContains(source, "exitCode = Cr04CapabilityVerification.Run(args);", "CR-04 runtime verification must execute on the dedicated MTA worker.");
            AssertContains(source, "worker.Join();", "The command must wait for the CR-04 worker and preserve synchronous CLI behavior.");
            AssertContains(source, "ExceptionDispatchInfo.Capture(workerException).Throw();", "Worker exceptions must propagate to the existing top-level error boundary instead of being swallowed.");
        }

        private static void Cr04DoesNotUseSelfInstanceHeuristics()
        {
            string root = FindRepositoryRoot();
            string path = Path.Combine(root, "tools", "CimatronCustomization.ApiCapabilityVerification", "Cr04CapabilityVerification.cs");
            string source = File.ReadAllText(path);

            AssertContains(source, "no self-instance heuristic", "CR-04 capability verification must state the approved no-self-instance-heuristic identity rule.");
            AssertNotContains(source, "AttributeOccurrence.SkipSelf", "CR-04 must not skip occurrence body evidence through a self-instance heuristic.");
            AssertNotContains(source, "IsSelfInstance", "CR-04 occurrence observations must not carry a self-instance classification.");
            AssertNotContains(source, "GetRootInstance()", "CR-04 business/identity traversal must not depend on GetRootInstance for occurrence filtering.");
            AssertNotContains(source, "AssRootInstance", "CR-04 must not use AssRootInstance as a business/identity filter.");
            AssertNotContains(source, "AssParentInstance", "CR-04 must not use AssParentInstance as a business/identity filter.");
            AssertNotContains(source, "Root.elt", "CR-04 must not hard-code Root.elt as an occurrence classification rule.");
        }

        private static void Cr04TraversalMatchesHighlighterEquivalentFakeTraversal()
        {
            FakeAssembly nested = new FakeAssembly("nested");
            nested.Instances.Add(new FakeInstance(30, "part-c", false, null));
            FakeAssembly root = new FakeAssembly("root");
            root.Instances.Add(new FakeInstance(10, "part-a", false, null));
            root.Instances.Add(new FakeInstance(20, "nested", true, nested));

            IReadOnlyList<FakeObservation> highlighter = TraverseHighlighterEquivalent(root, 0);
            IReadOnlyList<FakeObservation> cr04 = TraverseCr04Safety(root, 0);
            AssertSequence(highlighter.Select(item => item.Instance.Id), cr04.Select(item => item.Instance.Id), "CR-04 traversal must remain equivalent to production FindInstance search scope.");
        }

        private static void AllOccurrencesRemainEligibleForBusinessEvidence()
        {
            FakeAssembly nested = new FakeAssembly("nested-pid");
            nested.Instances.Add(new FakeInstance(3, "nested-pid", false, null));
            nested.Instances.Add(new FakeInstance(42, "part-pid", false, null));
            FakeAssembly root = new FakeAssembly("root-pid");
            root.Instances.Add(new FakeInstance(3, "root-pid", false, null));
            root.Instances.Add(new FakeInstance(42, "nested-pid", true, nested));

            IReadOnlyList<FakeObservation> scope = TraverseCr04Safety(root, 0);
            AssertEqual(4, scope.Count, "Every highlighter-scope occurrence must remain available for D-15 and body evidence; no PID-based self filtering is allowed.");
            AssertTrue(scope.GroupBy(item => item.Instance.Id).Any(group => group.Key == 3 && group.Count() == 2), "Repeated local InstanceId values must remain visible to collision analysis regardless of model PID equality.");
        }

        private static void SuppressedOccurrencesStillParticipateInCollisionScope()
        {
            FakeAssembly root = new FakeAssembly("root");
            root.Instances.Add(new FakeInstance(77, "part-a", false, null));
            root.Instances.Add(new FakeInstance(77, "part-b", false, null) { Suppressed = true });

            IReadOnlyList<FakeObservation> scope = TraverseCr04Safety(root, 0);
            AssertEqual(2, scope.Count(item => item.Instance.Id == 77), "Suppressed/excluded colliders must not be removed from D-15 uniqueness scope.");
            AssertTrue(scope.Any(item => item.Instance.Id == 77 && item.Instance.Suppressed), "The suppressed collision control must remain in the traversal result.");
        }

        private static void DepthLimitMatchesProductionHighlighter()
        {
            FakeAssembly root = new FakeAssembly("d0");
            FakeAssembly current = root;
            for (int depth = 0; depth < 18; depth++)
            {
                FakeAssembly next = new FakeAssembly("d" + (depth + 1));
                current.Instances.Add(new FakeInstance(100 + depth, next.Pid, true, next));
                current = next;
            }
            current.Instances.Add(new FakeInstance(999, "too-deep", false, null));

            IReadOnlyList<FakeObservation> scope = TraverseCr04Safety(root, 0);
            AssertFalse(scope.Any(item => item.Instance.Id == 999), "CR-04 safety traversal must stop beyond depth 16 exactly like FindInstance.");
        }

        private static void ProductionAssemblyBodyAttributeAdapterContractIsProtected()
        {
            string root = FindRepositoryRoot();
            string path = Path.Combine(root, "src", "CimatronCustomization.CimatronIntegration", "CimatronAssemblyBodyAttributeReader.cs");
            string source = File.ReadAllText(path);

            AssertContains(source, "assembly.GetInstances()", "CR-04 production adapter must enumerate the full top-level highlighter scope.");
            AssertContains(source, "instance.get_SubInstances(1, 0)", "CR-04 production adapter must preserve the approved nested include-suppressed/exclude-assist call.");
            AssertContains(source, "if (depth > MaximumTraversalDepth)", "CR-04 production adapter must retain the highlighter-equivalent depth stop.");
            AssertContains(source, "private const int MaximumTraversalDepth = 16;", "CR-04 production adapter depth limit must remain 16.");
            AssertContains(source, "instance.GetAllEntities()", "CR-04 production adapter must obtain occurrence bodies through the verified GetAllEntities route.");
            AssertContains(source, "string.Equals(entity.Type.ToString(), \"cmBody\", StringComparison.Ordinal)", "CR-04 production adapter must keep cmBody entities only.");
            AssertContains(source, "sink.GetAttribute(\n                    interop.CimBaseAPI.AttributeEnumType.cmAttString,", "CR-04 production adapter must use exact named cmAttString lookup.");
            AssertContains(source, "parentEffectivelySuppressed || directlySuppressed", "CR-04 production adapter must propagate inherited suppression without pre-filtering the occurrence.");
            AssertContains(source, "output.Add(new AssemblyBodyAttributeOccurrence", "CR-04 production adapter must retain occurrences before nested descent/business filtering.");
            AssertContains(source, "model.Type.ToString()", "CR-04 production adapter must preserve each occurrence model type so Form validation can distinguish Parts from nested assemblies without filtering traversal.");
            AssertContains(source, "CreateEntityReference(instance.ID, modelPid, entity.ID)", "CR-04 production adapter must emit the existing highlighter-compatible current-session entity reference shape.");

            AssertNotContains(source, "GetEntityById", "CR-04 production adapter must not resolve occurrence bodies through model GetEntityById.");
            AssertNotContains(source, "GetAttributes()", "CR-04 production adapter must not enumerate attributes or depend on returned IAttribute.Name.");
            AssertNotContains(source, ".Name", "CR-04 production adapter must not inspect returned IAttribute.Name.");
            AssertNotContains(source, "AttributeEnumType.cmAttInteger", "CR-04 production adapter must not probe alternate attribute types.");
            AssertNotContains(source, "SetAttribute", "CR-04 production adapter must remain read-only.");
            AssertNotContains(source, ".Attach(", "CR-04 production adapter must remain read-only.");
            AssertNotContains(source, ".Save", "CR-04 production adapter must remain read-only.");
        }

        private static void ProductionPartMaterialAdapterContractIsProtected()
        {
            string root = FindRepositoryRoot();
            string path = Path.Combine(root, "src", "CimatronCustomization.CimatronIntegration", "CimatronBomMaterialTableReader.cs");
            string source = File.ReadAllText(path);

            AssertContains(source, "assembly.GetBomManager()", "CR-04 Part Material adapter must use the verified BOM manager route.");
            AssertContains(source, "interop.CimMdlrAPI.ComponentsFilterOption.cmNoFiltering", "CR-04 Part Material adapter must retain the verified cmNoFiltering export route.");
            AssertContains(source, "new TabularColumnDefinition(\"Material\", \"Material\"", "CR-04 Part Material adapter must read the native BOM Material column.");
            AssertContains(source, "new TabularColumnDefinition(\"ModelTitle\", \"Standard Number\"", "CR-04 Part Material adapter must correlate BOM rows by the verified Standard Number/model-title field.");
            AssertContains(source, "TabularReadResult read = tabularDataReader.Read(source);", "CR-04 Part Material adapter must parse the single exported BOM snapshot in one tabular read without a separate expected-header/discovery contract.");
            AssertNotContains(source, "ExpectedBomHeaders", "CR-04 Part Material adapter must not maintain a second hard-coded BOM header snapshot that can diverge from the exported file.");
            AssertNotContains(source, "Read(source, ExpectedBomHeaders)", "CR-04 Part Material adapter must not perform the former expected-header read path.");
            AssertNotContains(source, ".Save(", "CR-04 Part Material adapter must remain read-only.");
            AssertNotContains(source, "SaveAs(", "CR-04 Part Material adapter must remain read-only.");
        }

        private static void RunWrongTypeAdapterSmokeWhenExplicitlyRequested()
        {
            const string optInVariable = "CIMATRON_DEV_ENABLE_CR04_SLICE3_WRONG_TYPE_SMOKE";
            if (!string.Equals(Environment.GetEnvironmentVariable(optInVariable), "1", StringComparison.Ordinal))
                return;

            string targetModelTitle = Environment.GetEnvironmentVariable("CIMATRON_DEV_CR04_WRONG_TYPE_MODEL_TITLE");
            if (string.IsNullOrWhiteSpace(targetModelTitle))
                throw new InvalidOperationException("Wrong-type smoke requires CIMATRON_DEV_CR04_WRONG_TYPE_MODEL_TITLE.");

            MutationObservation before = MutationObservation.Capture();
            CimatronAssemblyBodyAttributeReader reader = new CimatronAssemblyBodyAttributeReader();
            AssemblyBodyAttributeSnapshot snapshot = reader.ReadNamedAttributes("CR04_WRONG_TYPE_CONTROL", null);
            MutationObservation after = MutationObservation.Capture();

            if (!snapshot.IsSuccess)
                throw new InvalidOperationException("CR-04 wrong-type adapter smoke returned traversal ReadError: " + snapshot.ErrorMessage);

            AssemblyBodyAttributeOccurrence[] targetOccurrences = snapshot.Occurrences
                .Where(item => string.Equals(item.ModelTitle, targetModelTitle, StringComparison.Ordinal))
                .ToArray();
            if (targetOccurrences.Length == 0)
                throw new InvalidOperationException("CR-04 wrong-type adapter smoke did not find the controlled model occurrence.");

            BodyAttributeObservation[] controlBodies = targetOccurrences
                .SelectMany(item => item.Bodies)
                .Where(body => body.BodyReference.Value.EndsWith("|4", StringComparison.Ordinal))
                .ToArray();
            if (controlBodies.Length == 0)
                throw new InvalidOperationException("CR-04 wrong-type adapter smoke did not find controlled body entity 4.");

            int present = controlBodies.Count(body => body.SteelGradeStatus == AttributeObservationStatus.Present);
            int absent = controlBodies.Count(body => body.SteelGradeStatus == AttributeObservationStatus.Absent);
            int readError = controlBodies.Count(body => body.SteelGradeStatus == AttributeObservationStatus.ReadError);

            Console.WriteLine("CR04_SLICE3_WRONG_TYPE_SMOKE TargetOccurrences=" + targetOccurrences.Length);
            Console.WriteLine("CR04_SLICE3_WRONG_TYPE_SMOKE Body4Observations=" + controlBodies.Length);
            Console.WriteLine("CR04_SLICE3_WRONG_TYPE_SMOKE Present=" + present + ";Absent=" + absent + ";ReadError=" + readError);
            Console.WriteLine("CR04_SLICE3_WRONG_TYPE_SMOKE NoMutation=" + (before.IsEquivalentTo(after) ? "PASS" : "FAIL"));

            if (!before.IsEquivalentTo(after))
                throw new InvalidOperationException("CR-04 wrong-type adapter smoke changed active-document mutation evidence.");
            if (present > 0)
                throw new InvalidOperationException("HARD STOP: a genuine cmAttInteger control queried as cmAttString returned a conforming-looking Present value. Slice 3 adapter acceptance requires a user decision.");
            if (readError > 0)
            {
                Console.WriteLine("CR04_SLICE3_WRONG_TYPE_SMOKE Result=FAIL_SAFE_READ_ERROR_OBSERVED");
                return;
            }
            if (absent == controlBodies.Length)
            {
                Console.WriteLine("CR04_SLICE3_WRONG_TYPE_SMOKE Result=PROVISIONAL_ABSENT_OBSERVED");
                return;
            }

            throw new InvalidOperationException("CR-04 wrong-type adapter smoke produced an unclassified observation state.");
        }

        private sealed class MutationObservation
        {
            private MutationObservation(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            private string Path { get; }
            private bool Modified { get; }
            private DateTime? LastWriteUtc { get; }
            private long? Length { get; }

            internal static MutationObservation Capture()
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                object applicationObject = provider.GetApplication();
                interop.CimatronE.IApplication application = applicationObject as interop.CimatronE.IApplication;
                if (application == null)
                    throw new InvalidOperationException("Cimatron is not running or unavailable for wrong-type smoke.");
                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                if (document == null)
                    throw new InvalidOperationException("Cimatron has no active document for wrong-type smoke.");

                string path = document.GetPath() ?? string.Empty;
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo info = new FileInfo(path);
                    lastWriteUtc = info.LastWriteTimeUtc;
                    length = info.Length;
                }

                return new MutationObservation(path, document.IsModified(), lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(MutationObservation other)
            {
                return other != null &&
                    !string.IsNullOrWhiteSpace(Path) &&
                    LastWriteUtc.HasValue && Length.HasValue &&
                    other.LastWriteUtc.HasValue && other.Length.HasValue &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }

        private static List<FakeObservation> TraverseHighlighterEquivalent(FakeAssembly assembly, int depth)
        {
            List<FakeObservation> result = new List<FakeObservation>();
            Traverse(assembly, depth, result);
            return result;
        }

        private static List<FakeObservation> TraverseCr04Safety(FakeAssembly assembly, int depth)
        {
            List<FakeObservation> result = new List<FakeObservation>();
            Traverse(assembly, depth, result);
            return result;
        }

        private static void Traverse(FakeAssembly assembly, int depth, ICollection<FakeObservation> output)
        {
            if (depth > 16)
                return;

            foreach (FakeInstance instance in assembly.Instances)
            {
                output.Add(new FakeObservation(instance));
                if (instance.HasSubInstances && instance.IsAssembly && instance.NestedAssembly != null)
                    Traverse(instance.NestedAssembly, depth + 1, output);
            }
        }

        private static string FindRepositoryRoot()
        {
            DirectoryInfo directory = new DirectoryInfo(Directory.GetCurrentDirectory());
            while (directory != null)
            {
                if (File.Exists(Path.Combine(directory.FullName, "CimatronCustomization.sln")))
                    return directory.FullName;
                directory = directory.Parent;
            }
            throw new InvalidOperationException("Repository root containing CimatronCustomization.sln was not found.");
        }

        private static void AssertSequence(IEnumerable<int> expected, IEnumerable<int> actual, string message)
        {
            if (!expected.SequenceEqual(actual))
                throw new InvalidOperationException(message);
        }

        private static void AssertContains(string value, string expected, string message)
        {
            if (value.IndexOf(expected, StringComparison.Ordinal) < 0)
                throw new InvalidOperationException(message);
        }

        private static void AssertNotContains(string value, string unexpected, string message)
        {
            if (value.IndexOf(unexpected, StringComparison.Ordinal) >= 0)
                throw new InvalidOperationException(message);
        }

        private static void AssertEqual<T>(T expected, T actual, string message)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(message + " Expected=" + expected + "; Actual=" + actual + ".");
        }

        private static void AssertTrue(bool condition, string message)
        {
            if (!condition)
                throw new InvalidOperationException(message);
        }

        private static void AssertFalse(bool condition, string message)
        {
            if (condition)
                throw new InvalidOperationException(message);
        }

        private sealed class FakeAssembly
        {
            internal FakeAssembly(string pid)
            {
                Pid = pid;
                Instances = new List<FakeInstance>();
            }

            internal string Pid { get; }
            internal List<FakeInstance> Instances { get; }
        }

        private sealed class FakeInstance
        {
            internal FakeInstance(int id, string modelPid, bool isAssembly, FakeAssembly nestedAssembly)
            {
                Id = id;
                ModelPid = modelPid;
                IsAssembly = isAssembly;
                NestedAssembly = nestedAssembly;
            }

            internal int Id { get; }
            internal string ModelPid { get; }
            internal bool IsAssembly { get; }
            internal FakeAssembly NestedAssembly { get; }
            internal bool HasSubInstances => NestedAssembly != null && NestedAssembly.Instances.Count > 0;
            internal bool Suppressed { get; set; }
        }

        private sealed class FakeObservation
        {
            internal FakeObservation(FakeInstance instance)
            {
                Instance = instance;
            }

            internal FakeInstance Instance { get; }
        }
    }
}
