using System;

namespace CimatronCustomization.CimatronIntegrationTests
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                ViewportPickStateTests.RunAll();
                Cr04TraversalSafetyTests.RunAll();
                Console.WriteLine("CIMATRON INTEGRATION TESTS: PASS");
                return 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("CIMATRON INTEGRATION TESTS: FAIL");
                Console.Error.WriteLine(exception);
                return 1;
            }
        }
    }
}
