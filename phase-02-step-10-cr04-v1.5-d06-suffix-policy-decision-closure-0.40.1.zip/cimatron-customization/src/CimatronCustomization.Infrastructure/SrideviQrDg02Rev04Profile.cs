using CimatronCustomization.Application;

namespace CimatronCustomization.Infrastructure
{
    public static class SrideviQrDg02Rev04Profile
    {
        public const string ProfileId = "Sridevi_QR-DG-02_REV04";

        public static DesignOrderFormProfile Create()
        {
            return new DesignOrderFormProfile(
                ProfileId,
                "Sheet1",
                39,
                0,
                "QR/DG/02 REV 04 03/12/2021",
                5,
                14,
                new[]
                {
                    Category("Cavity", "Cavity", "Cavity", 18, "CC", 14, 26),
                    Category("Core", "Core", "Core", 19, "CC", 14, 26),
                    Category("CavityInsert", "Cavity Insert", "Cavity Insert", 20, "CC", 14, 26),
                    Category("CoreInsert", "Core Insert", "Core Insert", 21, "CC", 14, 26),
                    Category("MovingCore", "Moving Core", "Moving Core", 22, "CC", 14, 26),
                    Category("AngularLifter", "Angular Lifter", "Angular Lifter", 23, "CC", 14, 26),
                    Category("PressurePad", "Pressuer Pad", "Pressure Pad", 24, "CB", 29, 31),
                    Category("WearPad", "Wear Pad", "Wear Pad", 25, "CC", 32, 39),
                    Category("MouldBase", "Mould Base", "Mould Base", 26, "CC", 32, 39)
                },
                new[]
                {
                    new DesignOrderFormMaterialFamilyDefinition("P-20", 2),
                    new DesignOrderFormMaterialFamilyDefinition("AL", 3),
                    new DesignOrderFormMaterialFamilyDefinition("CK-45", 4),
                    new DesignOrderFormMaterialFamilyDefinition("BE-CU", 5),
                    new DesignOrderFormMaterialFamilyDefinition("Hardened", 6),
                    new DesignOrderFormMaterialFamilyDefinition("Nitrided", 7)
                });
        }

        private static DesignOrderFormCategoryDefinition Category(
            string key,
            string label,
            string partType,
            int row,
            string vocabularyColumn,
            int vocabularyStartRow,
            int vocabularyEndRow)
        {
            return new DesignOrderFormCategoryDefinition(
                key,
                label,
                partType,
                row,
                0,
                8,
                vocabularyColumn,
                vocabularyStartRow,
                vocabularyEndRow);
        }
    }
}
