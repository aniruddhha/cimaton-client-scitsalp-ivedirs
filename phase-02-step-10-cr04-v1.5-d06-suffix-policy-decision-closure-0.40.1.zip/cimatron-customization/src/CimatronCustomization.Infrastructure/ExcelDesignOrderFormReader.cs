using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CimatronCustomization.Application;
using ExcelDataReader;

namespace CimatronCustomization.Infrastructure
{
    public sealed class ExcelDesignOrderFormReader : IDesignOrderFormReader
    {
        public const long DefaultMaximumFileBytes = 25L * 1024L * 1024L;

        private readonly long maximumFileBytes;

        public ExcelDesignOrderFormReader() : this(DefaultMaximumFileBytes) { }

        public ExcelDesignOrderFormReader(long maximumFileBytes)
        {
            if (maximumFileBytes < 1) throw new ArgumentOutOfRangeException(nameof(maximumFileBytes));
            this.maximumFileBytes = maximumFileBytes;
        }

        public DesignOrderFormReadResult Read(string filePath, DesignOrderFormProfile profile)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentException("A Design-Order file path is required.", nameof(filePath));
            if (profile == null) throw new ArgumentNullException(nameof(profile));

            string extension;
            DesignOrderFormReadResult validationError = ValidateFile(filePath, out extension);
            if (validationError != null) return validationError;

            try
            {
                using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (IExcelDataReader reader = CreateReader(stream, extension))
                {
                    if (!MoveToWorksheet(reader, profile.WorksheetName))
                        return Error("FORM_WORKSHEET_NOT_FOUND", "The configured Design-Order Form worksheet was not found.");

                    return ReadProfile(ReadRows(reader), profile);
                }
            }
            catch (IOException)
            {
                return Error("FORM_FILE_READ_ERROR", "The Design-Order Form file could not be read. Verify that the file is accessible and try again.");
            }
            catch (UnauthorizedAccessException)
            {
                return Error("FORM_FILE_READ_ERROR", "The Design-Order Form file could not be read because access was denied.");
            }
            catch (Exception exception) when (IsReaderFormatException(exception))
            {
                return Error("FORM_FILE_READ_ERROR", "The Design-Order Form file could not be parsed as the selected Excel format.");
            }
        }

        private DesignOrderFormReadResult ValidateFile(string filePath, out string extension)
        {
            extension = Path.GetExtension(filePath);
            if (!File.Exists(filePath)) return Error("FORM_FILE_NOT_FOUND", "The selected Design-Order Form file does not exist.");
            if (!IsSupportedExtension(extension)) return Error("FORM_UNSUPPORTED_FORMAT", "The Design-Order Form file must use .xlsx or .xls format.");
            if (new FileInfo(filePath).Length > maximumFileBytes) return Error("FORM_FILE_TOO_LARGE", "The Design-Order Form file exceeds the configured maximum file size.");
            return null;
        }

        private static DesignOrderFormReadResult ReadProfile(IReadOnlyList<object[]> rows, DesignOrderFormProfile profile)
        {
            string normalizedGuard = NormalizeWhitespace(ReadText(rows, profile.TemplateGuardRow, profile.TemplateGuardColumnIndex));
            if (!string.Equals(normalizedGuard, profile.ExpectedNormalizedTemplateGuard, StringComparison.Ordinal))
                return Error("FORM_TEMPLATE_GUARD_MISMATCH", "The selected workbook does not match the configured Design-Order Form template guard.");

            string mouldNumber = ReadText(rows, profile.MouldNumberRow, profile.MouldNumberColumnIndex).Trim();
            List<DesignOrderFormCategoryRecord> categories = new List<DesignOrderFormCategoryRecord>();

            foreach (DesignOrderFormCategoryDefinition definition in profile.Categories)
            {
                string expectedLabel = NormalizeWhitespace(definition.ProductionLabel);
                string rowLabel = NormalizeWhitespace(ReadText(rows, definition.SourceRowNumber, definition.LabelColumnIndex));
                int labelCount = CountNormalizedLabel(rows, definition.LabelColumnIndex, expectedLabel);
                if (labelCount == 0 || !string.Equals(rowLabel, expectedLabel, StringComparison.OrdinalIgnoreCase))
                    return Error("FORM_LABEL_NOT_FOUND", "Required Design-Order Form label '" + definition.ProductionLabel + "' was not found at its configured anchor.");
                if (labelCount > 1)
                    return Error("FORM_LABEL_DUPLICATE", "Required Design-Order Form label '" + definition.ProductionLabel + "' was found more than once.");

                string rawRemark = ReadText(rows, definition.SourceRowNumber, definition.RemarkColumnIndex);
                string remark = rawRemark.Trim();
                string selectedFamily = string.Empty;

                if (profile.MaterialFamilies.Count > 0)
                {
                    List<string> selectedFamilies = new List<string>();
                    foreach (DesignOrderFormMaterialFamilyDefinition family in profile.MaterialFamilies)
                    {
                        string marker = ReadText(rows, definition.SourceRowNumber, family.ColumnIndex).Trim();
                        if (marker.Length == 0) continue;
                        if (!string.Equals(marker, "X", StringComparison.OrdinalIgnoreCase))
                            return Error("FORM_MATERIAL_SELECTION_MARKER_INVALID", "Design-Order category '" + definition.CategoryKey + "' contains an invalid material-selection marker '" + marker + "'. Expected X or blank.");
                        selectedFamilies.Add(family.FamilyName);
                    }

                    if (selectedFamilies.Count > 1)
                        return Error("FORM_MATERIAL_SELECTION_MULTIPLE", "Design-Order category '" + definition.CategoryKey + "' selects more than one material family.");
                    if (selectedFamilies.Count == 1 && remark.Length == 0)
                        return Error("FORM_REMARK_REQUIRED", "Design-Order category '" + definition.CategoryKey + "' selects material family '" + selectedFamilies[0] + "' but Remark is blank.");
                    if (selectedFamilies.Count == 0 && remark.Length > 0)
                        return Error("FORM_MATERIAL_SELECTION_REQUIRED", "Design-Order category '" + definition.CategoryKey + "' contains Remark '" + remark + "' but no material family is selected.");

                    selectedFamily = selectedFamilies.Count == 1 ? selectedFamilies[0] : string.Empty;
                }
                else
                {
                    // Backward-compatible reader contract for non-production test/profile users that do not define X columns.
                    selectedFamily = remark.Length == 0 ? string.Empty : "LEGACY_UNSPECIFIED";
                }

                int vocabularyColumnIndex = ColumnNameToZeroBasedIndex(definition.VocabularyColumnName);
                List<string> permittedGrades = new List<string>();
                for (int sourceRow = definition.VocabularyStartRow; sourceRow <= definition.VocabularyEndRow; sourceRow++)
                {
                    string value = ReadText(rows, sourceRow, vocabularyColumnIndex).Trim();
                    if (value.Length > 0 && !permittedGrades.Contains(value, StringComparer.Ordinal)) permittedGrades.Add(value);
                }

                categories.Add(new DesignOrderFormCategoryRecord(
                    definition.CategoryKey,
                    rowLabel,
                    definition.SourceRowNumber,
                    selectedFamily,
                    rawRemark,
                    remark,
                    permittedGrades));
            }

            return DesignOrderFormReadResult.Succeeded(profile.ProfileId, normalizedGuard, mouldNumber, categories);
        }

        private static List<object[]> ReadRows(IExcelDataReader reader)
        {
            List<object[]> rows = new List<object[]>();
            while (reader.Read())
            {
                object[] values = new object[reader.FieldCount];
                for (int index = 0; index < reader.FieldCount; index++) values[index] = reader.GetValue(index);
                rows.Add(values);
            }
            return rows;
        }

        private static string ReadText(IReadOnlyList<object[]> rows, int oneBasedRow, int zeroBasedColumn)
        {
            int rowIndex = oneBasedRow - 1;
            if (rowIndex < 0 || rowIndex >= rows.Count) return string.Empty;
            object[] row = rows[rowIndex];
            if (row == null || zeroBasedColumn < 0 || zeroBasedColumn >= row.Length) return string.Empty;
            return Convert.ToString(row[zeroBasedColumn], CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static int CountNormalizedLabel(IReadOnlyList<object[]> rows, int columnIndex, string expectedLabel)
        {
            int count = 0;
            for (int sourceRow = 1; sourceRow <= rows.Count; sourceRow++)
                if (string.Equals(NormalizeWhitespace(ReadText(rows, sourceRow, columnIndex)), expectedLabel, StringComparison.OrdinalIgnoreCase)) count++;
            return count;
        }

        internal static string NormalizeWhitespace(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            StringBuilder builder = new StringBuilder(value.Length);
            bool pendingSpace = false;
            foreach (char character in value.Trim())
            {
                if (char.IsWhiteSpace(character)) { pendingSpace = builder.Length > 0; continue; }
                if (pendingSpace) builder.Append(' ');
                builder.Append(character);
                pendingSpace = false;
            }
            return builder.ToString();
        }

        private static int ColumnNameToZeroBasedIndex(string columnName)
        {
            int result = 0;
            foreach (char character in columnName.Trim().ToUpperInvariant())
            {
                if (character < 'A' || character > 'Z') throw new ArgumentException("Vocabulary column names must contain only A-Z letters.", nameof(columnName));
                result = checked((result * 26) + (character - 'A' + 1));
            }
            return result - 1;
        }

        private static IExcelDataReader CreateReader(Stream stream, string extension)
        {
            return string.Equals(extension, ".xls", StringComparison.OrdinalIgnoreCase)
                ? ExcelReaderFactory.CreateBinaryReader(stream)
                : ExcelReaderFactory.CreateOpenXmlReader(stream);
        }

        private static bool MoveToWorksheet(IExcelDataReader reader, string worksheetName)
        {
            do
            {
                if (string.Equals(reader.Name, worksheetName, StringComparison.Ordinal)) return true;
            }
            while (reader.NextResult());
            return false;
        }

        private static bool IsSupportedExtension(string extension)
        {
            return string.Equals(extension, ".xlsx", StringComparison.OrdinalIgnoreCase)
                || string.Equals(extension, ".xls", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsReaderFormatException(Exception exception)
        {
            return exception is InvalidDataException
                || exception is NotSupportedException
                || exception is ArgumentException;
        }

        private static DesignOrderFormReadResult Error(string code, string message)
        {
            return DesignOrderFormReadResult.Error(code, message);
        }
    }
}
