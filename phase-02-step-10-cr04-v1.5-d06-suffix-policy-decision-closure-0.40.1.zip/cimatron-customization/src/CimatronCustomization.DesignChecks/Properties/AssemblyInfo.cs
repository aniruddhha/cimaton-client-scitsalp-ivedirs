using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.DesignChecks")]
[assembly: AssemblyDescription("Cimatron Customization hexagonal architecture foundation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("9601716c-8a91-47b8-85ec-670c541c7e36")]
[assembly: InternalsVisibleTo("CimatronCustomization.Application.Tests")]
[assembly: AssemblyVersion("0.39.6.0")]
[assembly: AssemblyFileVersion("0.39.6.0")]
