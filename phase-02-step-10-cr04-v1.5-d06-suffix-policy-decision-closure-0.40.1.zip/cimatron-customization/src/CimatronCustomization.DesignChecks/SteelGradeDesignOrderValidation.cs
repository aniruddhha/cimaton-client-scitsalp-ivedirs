using System;
using System.Collections.Generic;
using System.Linq;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.DesignChecks
{
    /// <summary>
    /// CR-04 read-only feature wrapper. Customer-specific values come from validated
    /// rule parameters; the Design Order workbook path is supplied only as a per-run launcher input.
    /// </summary>
    public sealed class SteelGradeDesignOrderValidation : IApplicationFeature
    {
        public const string FeatureId = "STEEL-GRADE-DESIGN-ORDER-VALIDATION";

        public const string DesignOrderPathRunInput = "DesignOrderPath";
        public const string DesignOrderFormatParameter = "DesignOrderFormat";
        public const string DesignOrderProfileParameter = "DesignOrderProfile";
        public const string DesignOrderWorksheetNameParameter = "DesignOrderWorksheetName";
        public const string DesignOrderHeaderRowParameter = "DesignOrderHeaderRow";
        public const string DesignOrderComponentKeyHeaderParameter = "DesignOrderComponentKeyHeader";
        public const string DesignOrderSteelGradeHeaderParameter = "DesignOrderSteelGradeHeader";
        public const string SteelGradeSourceParameter = "SteelGradeSource";
        public const string SteelGradeAttributeNameParameter = "SteelGradeAttributeName";
        public const string ComponentKeySourceParameter = "ComponentKeySource";
        public const string ComponentKeyAttributeNameParameter = "ComponentKeyAttributeName";
        public const string ComponentCategorySourceParameter = "ComponentCategorySource";
        public const string ComponentCategoryAttributeNameParameter = "ComponentCategoryAttributeName";
        public const string ComponentCategoryPatternsParameter = "ComponentCategoryPatterns";
        public const string ComponentExclusionPatternsParameter = "ComponentExclusionPatterns";
        public const string SteelGradeRepresentationParameter = "SteelGradeRepresentation";
        public const string CompareGradeTokenOnlyParameter = "CompareGradeTokenOnly";

        private const string ApprovedCategorySource = "PartType";
        private const string TraversalOnlyAttributeName = "__CR04_PART_MATERIAL_TRAVERSAL_ONLY__";
        private static readonly char[] ListSeparators = { ';' };

        private static readonly FeatureDefinition definition = new FeatureDefinition(
            FeatureId,
            "Steel Grade Design-Order Validation",
            FeatureKind.Validation,
            new[] { "CR-04" },
            "Design Checks",
            DocumentContextRequirement.Assembly,
            true,
            new FeatureTraceability(
                "Compare each non-suppressed assembly component's native Part Material with the matching Design-Order requirement selected by native Part Type.",
                "For a valid Assembly and approved configuration, CR-04 reports grade matches, mismatches and coverage/data errors without modifying the Cimatron model.",
                "Active Assembly plus a runtime-selected Design-Order workbook, configured Table/Form profile, native Part Type mapping, and CR-04 comparison parameters.",
                "CR-04 findings with safe current-session highlight references only when D-15 identity rules permit them.",
                "VerifySteelGradeAgainstDesignOrder, IAssemblyBodyAttributeReader, IPartDocumentPropertyReader, ReadMappedTabularData/IDesignOrderFormReader and DesignOrderInputPathResolver.",
                "Cimatron 2026 read-only assembly traversal plus the runtime-verified GetPdm()/RetriveDocAttribute route for TMPL::Part_Type and TMPL::Material; Result Report/highlight uses the existing verified platform path.",
                "Feature id STEEL-GRADE-DESIGN-ORDER-VALIDATION. D-09(c) supplies the workbook as a runtime launcher input. Form classification uses only approved native Part Type mappings; optional exclusions remain explicit configuration.",
                "Configuration/input/CAD failures produce Error; Part context is NotApplicable; business mismatches alone produce Failed.",
                "Application/DesignChecks feature tests, architecture tests, workstation quality gate, then controlled live read-only Cimatron validation.",
                "0.39.0",
                "v1.5 supports Table and Sridevi Form modes. Form mode uses native TMPL::Part_Type for category selection and TMPL::Material for actual steel grade; the Design-Order selected-family X plus Remark defines the requirement."),
            new[]
            {
                new RuleParameterDefinition(DesignOrderFormatParameter, RuleParameterType.String, string.Empty, null, null, true),
                new RuleParameterDefinition(DesignOrderProfileParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(DesignOrderWorksheetNameParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(DesignOrderHeaderRowParameter, RuleParameterType.Integer, "row", 1m, null, false),
                new RuleParameterDefinition(DesignOrderComponentKeyHeaderParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(DesignOrderSteelGradeHeaderParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(SteelGradeSourceParameter, RuleParameterType.String, string.Empty, null, null, true),
                new RuleParameterDefinition(SteelGradeAttributeNameParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(ComponentKeySourceParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(ComponentKeyAttributeNameParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(ComponentCategorySourceParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(ComponentCategoryAttributeNameParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(ComponentCategoryPatternsParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(ComponentExclusionPatternsParameter, RuleParameterType.String, string.Empty, null, null, false),
                new RuleParameterDefinition(SteelGradeRepresentationParameter, RuleParameterType.String, string.Empty, null, null, true),
                new RuleParameterDefinition(CompareGradeTokenOnlyParameter, RuleParameterType.Boolean, string.Empty, null, null, true)
            });

        private readonly Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>> executeValidation;
        private readonly DesignOrderFormProfile formProfile;

        public SteelGradeDesignOrderValidation(VerifySteelGradeAgainstDesignOrder validation)
            : this(validation, null)
        {
        }

        public SteelGradeDesignOrderValidation(
            VerifySteelGradeAgainstDesignOrder validation,
            DesignOrderFormProfile formProfile)
            : this(
                validation == null
                    ? throw new ArgumentNullException(nameof(validation))
                    : new Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>>(validation.Execute),
                formProfile)
        {
        }

        internal SteelGradeDesignOrderValidation(
            Func<VerifySteelGradeAgainstDesignOrderRequest, IReadOnlyList<Finding>> executeValidation,
            DesignOrderFormProfile formProfile = null)
        {
            this.executeValidation = executeValidation ?? throw new ArgumentNullException(nameof(executeValidation));
            this.formProfile = formProfile;
        }

        public FeatureDefinition Definition => definition;

        public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            if (!TryCreateRequest(context, formProfile, out VerifySteelGradeAgainstDesignOrderRequest request, out Finding configurationError))
                return ErrorOutcome(configurationError);

            IReadOnlyList<Finding> findings = executeValidation(request);
            if (findings == null)
                throw new InvalidOperationException("CR-04 application validation returned no findings collection.");

            ResultStatus status = FindingAggregation.Aggregate(findings, ResultStatus.Passed);
            string message = "CR-04 steel-grade validation completed with " + findings.Count + " finding(s).";
            return new FeatureExecutionOutcome(status, message, findings);
        }

        private static bool TryCreateRequest(
            FeatureExecutionContext context,
            DesignOrderFormProfile formProfile,
            out VerifySteelGradeAgainstDesignOrderRequest request,
            out Finding configurationError)
        {
            request = null;
            configurationError = null;

            if (!context.RunInputs.Values.TryGetValue(DesignOrderPathRunInput, out object designOrderPathValue) ||
                !(designOrderPathValue is string designOrderPath) ||
                string.IsNullOrWhiteSpace(designOrderPath))
            {
                configurationError = RuntimeInputError(
                    DesignOrderPathRunInput,
                    "must be supplied by the CR-04 Design Order browse/select dialog.");
                return false;
            }

            RuleParameterSet parameters = context.RuleParameters;
            string steelGradeSource = parameters.GetRequired(SteelGradeSourceParameter).AsString();
            if (!string.Equals(steelGradeSource, "PartMaterial", StringComparison.OrdinalIgnoreCase))
            {
                configurationError = ConfigurationError(
                    SteelGradeSourceParameter,
                    "must be 'PartMaterial'. CR-04 production steel grade is read from Cimatron native Part Material through the verified PDM document-attribute route.");
                return false;
            }

            if (!TryParseComparisonPolicy(parameters, out SteelGradeComparisonPolicy comparisonPolicy, out configurationError))
                return false;

            string format = parameters.GetRequired(DesignOrderFormatParameter).AsString();
            if (string.Equals(format, "Table", StringComparison.OrdinalIgnoreCase))
            {
                return TryCreateTableRequest(
                    designOrderPath,
                    parameters,
                    comparisonPolicy,
                    out request,
                    out configurationError);
            }

            if (string.Equals(format, "Form", StringComparison.OrdinalIgnoreCase))
            {
                return TryCreateFormRequest(
                    designOrderPath,
                    parameters,
                    comparisonPolicy,
                    formProfile,
                    out request,
                    out configurationError);
            }

            configurationError = ConfigurationError(DesignOrderFormatParameter, "must be 'Table' or 'Form'.");
            return false;
        }

        private static bool TryCreateTableRequest(
            string designOrderPath,
            RuleParameterSet parameters,
            SteelGradeComparisonPolicy comparisonPolicy,
            out VerifySteelGradeAgainstDesignOrderRequest request,
            out Finding configurationError)
        {
            request = null;
            configurationError = null;

            if (!TryGetRequiredString(parameters, DesignOrderWorksheetNameParameter, out string worksheetName, out configurationError) ||
                !TryGetRequiredInteger(parameters, DesignOrderHeaderRowParameter, out int headerRow, out configurationError) ||
                !TryGetRequiredString(parameters, DesignOrderComponentKeyHeaderParameter, out string componentKeyHeader, out configurationError) ||
                !TryGetRequiredString(parameters, DesignOrderSteelGradeHeaderParameter, out string steelGradeHeader, out configurationError) ||
                !TryGetRequiredString(parameters, ComponentKeySourceParameter, out string componentKeySourceText, out configurationError))
            {
                return false;
            }

            SteelGradeComponentKeySource componentKeySource;
            if (string.Equals(componentKeySourceText, "ModelTitle", StringComparison.OrdinalIgnoreCase))
            {
                componentKeySource = SteelGradeComponentKeySource.ModelTitle;
            }
            else if (string.Equals(componentKeySourceText, "Attribute", StringComparison.OrdinalIgnoreCase))
            {
                componentKeySource = SteelGradeComponentKeySource.BodyAttribute;
            }
            else
            {
                configurationError = ConfigurationError(
                    ComponentKeySourceParameter,
                    "must be 'ModelTitle' or 'Attribute' for Table mode.");
                return false;
            }

            string componentKeyAttributeName = TryGetOptionalString(parameters, ComponentKeyAttributeNameParameter);
            if (componentKeySource == SteelGradeComponentKeySource.BodyAttribute && string.IsNullOrWhiteSpace(componentKeyAttributeName))
            {
                configurationError = ConfigurationError(
                    ComponentKeyAttributeNameParameter,
                    "is required when ComponentKeySource is 'Attribute'.");
                return false;
            }

            request = new VerifySteelGradeAgainstDesignOrderRequest(
                designOrderPath,
                worksheetName,
                headerRow,
                componentKeyHeader,
                steelGradeHeader,
                TraversalOnlyAttributeName,
                componentKeySource,
                componentKeyAttributeName,
                comparisonPolicy);
            return true;
        }

        private static bool TryCreateFormRequest(
            string designOrderPath,
            RuleParameterSet parameters,
            SteelGradeComparisonPolicy comparisonPolicy,
            DesignOrderFormProfile formProfile,
            out VerifySteelGradeAgainstDesignOrderRequest request,
            out Finding configurationError)
        {
            request = null;
            configurationError = null;

            if (formProfile == null)
            {
                configurationError = ConfigurationError(
                    DesignOrderProfileParameter,
                    "cannot be used because no Form profile is composed for this feature.");
                return false;
            }

            if (!TryGetRequiredString(parameters, DesignOrderProfileParameter, out string profileId, out configurationError))
                return false;
            if (!string.Equals(profileId, formProfile.ProfileId, StringComparison.Ordinal))
            {
                configurationError = ConfigurationError(
                    DesignOrderProfileParameter,
                    "must exactly match the composed approved profile '" + formProfile.ProfileId + "'.");
                return false;
            }

            if (!TryGetRequiredString(parameters, ComponentCategorySourceParameter, out string categorySource, out configurationError))
                return false;
            if (!string.Equals(categorySource, ApprovedCategorySource, StringComparison.Ordinal))
            {
                configurationError = ConfigurationError(
                    ComponentCategorySourceParameter,
                    "must be '" + ApprovedCategorySource + "'.");
                return false;
            }

            string exclusionText = TryGetOptionalString(parameters, ComponentExclusionPatternsParameter);
            IReadOnlyList<string> exclusions = ParseExclusionPatterns(exclusionText);

            request = new VerifySteelGradeAgainstDesignOrderRequest(
                designOrderPath,
                TraversalOnlyAttributeName,
                comparisonPolicy,
                formProfile,
                exclusions);
            return true;
        }

        private static bool TryParseComparisonPolicy(
            RuleParameterSet parameters,
            out SteelGradeComparisonPolicy comparisonPolicy,
            out Finding configurationError)
        {
            comparisonPolicy = null;
            configurationError = null;

            string representationText = parameters.GetRequired(SteelGradeRepresentationParameter).AsString();
            SteelGradeRepresentation representation;
            if (string.Equals(representationText, "Strict", StringComparison.OrdinalIgnoreCase))
            {
                representation = SteelGradeRepresentation.Strict;
            }
            else if (string.Equals(representationText, "WerkstoffCanonical", StringComparison.OrdinalIgnoreCase))
            {
                representation = SteelGradeRepresentation.WerkstoffCanonical;
            }
            else
            {
                configurationError = ConfigurationError(
                    SteelGradeRepresentationParameter,
                    "must be 'Strict' or 'WerkstoffCanonical'.");
                return false;
            }

            comparisonPolicy = new SteelGradeComparisonPolicy(
                representation,
                parameters.GetRequired(CompareGradeTokenOnlyParameter).AsBoolean());
            return true;
        }

        private static string[] ParseExclusionPatterns(string raw)
        {
            return string.IsNullOrWhiteSpace(raw)
                ? Array.Empty<string>()
                : SplitList(raw).ToArray();
        }

        private static IEnumerable<string> SplitList(string raw)
        {
            return (raw ?? string.Empty)
                .Split(ListSeparators, StringSplitOptions.RemoveEmptyEntries)
                .Select(value => value.Trim())
                .Where(value => value.Length > 0);
        }

        private static bool TryGetRequiredString(
            RuleParameterSet parameters,
            string parameterName,
            out string value,
            out Finding configurationError)
        {
            value = null;
            configurationError = null;
            if (!parameters.TryGet(parameterName, out RuleParameterValue parameter) || string.IsNullOrWhiteSpace(parameter.AsString()))
            {
                configurationError = ConfigurationError(parameterName, "is required for the selected DesignOrderFormat.");
                return false;
            }

            value = parameter.AsString();
            return true;
        }

        private static bool TryGetRequiredInteger(
            RuleParameterSet parameters,
            string parameterName,
            out int value,
            out Finding configurationError)
        {
            value = 0;
            configurationError = null;
            if (!parameters.TryGet(parameterName, out RuleParameterValue parameter))
            {
                configurationError = ConfigurationError(parameterName, "is required for the selected DesignOrderFormat.");
                return false;
            }

            value = parameter.AsInteger();
            return true;
        }

        private static string TryGetOptionalString(RuleParameterSet parameters, string parameterName)
        {
            return parameters.TryGet(parameterName, out RuleParameterValue parameter)
                ? parameter.AsString()
                : null;
        }

        private static FeatureExecutionOutcome ErrorOutcome(Finding finding)
        {
            return new FeatureExecutionOutcome(ResultStatus.Error, finding.Message, new[] { finding });
        }

        private static Finding ConfigurationError(string parameterName, string detail)
        {
            return new Finding(
                "CR-04",
                ResultStatus.Error,
                "[CR04_CONFIGURATION_ERROR] Rule parameter '" + parameterName + "' " + detail);
        }

        private static Finding RuntimeInputError(string inputName, string detail)
        {
            return new Finding(
                "CR-04",
                ResultStatus.Error,
                "[CR04_RUNTIME_INPUT_ERROR] Run input '" + inputName + "' " + detail);
        }
    }
}
