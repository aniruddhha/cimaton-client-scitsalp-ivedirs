using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.DesignChecks
{
    /// <summary>
    /// CR-04 Slice 2A developer diagnostic. The finding only prepares a safe target; visual highlight confirmation remains a user action.
    /// </summary>
    public sealed class TopLevelHighlightDiagnosticFeature : IApplicationFeature
    {
        public const string FeatureId = "CR04-SLICE2A-TOPLEVEL-HIGHLIGHT-DIAGNOSTIC";
        // known-answer diagnostic value; removed with this diagnostic before client packaging
        public const string KnownAssemblyTitle = "KA-ASM-1";
        // known-answer diagnostic value; removed with this diagnostic before client packaging
        public const string KnownModelTitle = "KA-PART-1";
        // known-answer diagnostic value; removed with this diagnostic before client packaging
        public const string KnownAttributeName = "STEP07_B1_TEST_ATTRIBUTE";
        // known-answer diagnostic value; removed with this diagnostic before client packaging
        public const string KnownAttributeValue = "KNOWN_ANSWER_07C3";
        // known-answer diagnostic value; removed with this diagnostic before client packaging
        public const string KnownAttributeType = "cmAttString";

        private static readonly FeatureDefinition definition = new FeatureDefinition(
            FeatureId,
            "CR-04 Slice 2A Top-Level Highlight Diagnostic",
            FeatureKind.Validation,
            new[] { "CR-04", "D-15" },
            "Developer Diagnostics",
            DocumentContextRequirement.Assembly,
            true,
            new FeatureTraceability(
                "CR-04 Slice 2A diagnostic for one D-15(a)-safe top-level occurrence through the production Result Report highlight path.",
                "Runtime-select one globally unique top-level KA-PART-1 occurrence and exactly one governed known-attribute body; user must then visually confirm Highlight.",
                "Active KA-ASM-1; runtime occurrence traversal; known-answer diagnostic title and body attribute.",
                "One Passed target-ready finding with a current-session ModelEntityReference, or one Error finding with no reference.",
                "ITopLevelHighlightDiagnosticReader and production Result Report/IViewportEntityHighlighter path.",
                "IAssemblyModel.GetInstances, IAssInstance.get_SubInstances(1,0), IAssInstance.GetAllEntities, IAttributeSink.GetAttribute(cmAttString,name).",
                "Opt-in only via a one-shot request file created by tools/Request-TopLevelHighlightDiagnostic.ps1; consumed at Feature Launcher registry creation and valid for 30 minutes.",
                "No safe candidate, non-unique body, unexpected attribute shape, API/runtime error, or mutation evidence => Error with no reference.",
                "Pure selector tests, feature fake-reader tests, architecture guards, quality gate, then exactly one governed live user run.",
                "0.26.4",
                "Developer-only diagnostic. Registration, all eight diagnostic source files, the request script and the two diagnostic test files MUST be removed under a separately approved change before any client package is built."));

        private readonly ITopLevelHighlightDiagnosticReader reader;

        public TopLevelHighlightDiagnosticFeature(ITopLevelHighlightDiagnosticReader reader)
        {
            this.reader = reader ?? throw new ArgumentNullException(nameof(reader));
        }

        public FeatureDefinition Definition => definition;

        public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));
            TopLevelHighlightDiagnosticResult result = reader.Read(KnownAssemblyTitle, KnownModelTitle, KnownAttributeName, KnownAttributeValue, KnownAttributeType);
            string evidence = " SelectedInstanceId=" + (result.SelectedInstanceId.HasValue ? result.SelectedInstanceId.Value.ToString(CultureInfo.InvariantCulture) : "none") +
                "; CandidateInstanceIds=" + FormatIds(result.CandidateInstanceIds) +
                "; RepeatedInstanceIds=" + FormatIds(result.RepeatedInstanceIds) +
                "; TotalOccurrences=" + result.TotalOccurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; ProgrammaticNoMutation=" + FormatNoMutationState(result.NoMutationState) + ".";

            if (result.Status != ResultStatus.Passed || result.Reference == null || result.NoMutationState != TopLevelHighlightNoMutationState.Unchanged)
            {
                string message = "[TOPLEVEL_HIGHLIGHT_CONTRACT_ERROR] diagnostic result did not satisfy the target-ready contract. " + result.Message + evidence;
                Finding error = new Finding(FeatureId, ResultStatus.Error, message);
                return new FeatureExecutionOutcome(ResultStatus.Error, message, new[] { error });
            }

            string success = "[TOPLEVEL_HIGHLIGHT_TARGET_READY] D-15-safe top-level target selected and exactly one known-attribute body resolved." + evidence +
                " Highlight is NOT confirmed by this finding; user visual confirmation is required.";
            Finding finding = new Finding(FeatureId, ResultStatus.Passed, success, entityReferences: new[] { result.Reference });
            return new FeatureExecutionOutcome(ResultStatus.Passed, success, new[] { finding });
        }

        private static string FormatNoMutationState(TopLevelHighlightNoMutationState state)
        {
            switch (state)
            {
                case TopLevelHighlightNoMutationState.Unchanged:
                    return "PASS";
                case TopLevelHighlightNoMutationState.Changed:
                    return "CHANGED";
                default:
                    return "NOT_EVALUATED";
            }
        }

        private static string FormatIds(IEnumerable<int> ids)
        {
            return ids == null ? "[]" : "[" + string.Join(",", ids.Select(id => id.ToString(CultureInfo.InvariantCulture))) + "]";
        }
    }
}
