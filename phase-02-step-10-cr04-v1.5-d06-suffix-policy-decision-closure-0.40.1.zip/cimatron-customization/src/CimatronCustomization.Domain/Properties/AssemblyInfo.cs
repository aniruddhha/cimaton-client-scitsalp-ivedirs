using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.Domain")]
[assembly: AssemblyDescription("Cimatron Customization hexagonal architecture foundation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("42657013-bc99-429e-ad06-689afa7f2179")]
[assembly: AssemblyVersion("0.40.1.0")]
[assembly: AssemblyFileVersion("0.40.1.0")]
