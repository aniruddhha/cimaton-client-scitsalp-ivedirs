using System;

namespace CimatronCustomization.Domain
{
    public sealed class DesignOrderSteelGradeEntry
    {
        public DesignOrderSteelGradeEntry(string componentKey, string steelGrade, int sourceRowNumber)
        {
            if (string.IsNullOrWhiteSpace(componentKey))
            {
                throw new ArgumentException("A Design-Order component key is required.", nameof(componentKey));
            }

            if (sourceRowNumber < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(sourceRowNumber));
            }

            ComponentKey = componentKey;
            SteelGrade = steelGrade;
            SourceRowNumber = sourceRowNumber;
        }

        public string ComponentKey { get; }
        public string SteelGrade { get; }
        public int SourceRowNumber { get; }
    }
}
