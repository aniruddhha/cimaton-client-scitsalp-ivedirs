using System;

namespace CimatronCustomization.Domain
{
    public sealed class NormalizedSteelGrade
    {
        public NormalizedSteelGrade(string originalText, string comparisonKey)
        {
            if (string.IsNullOrWhiteSpace(originalText))
            {
                throw new ArgumentException("Original steel-grade text is required.", nameof(originalText));
            }

            if (string.IsNullOrWhiteSpace(comparisonKey))
            {
                throw new ArgumentException("A steel-grade comparison key is required.", nameof(comparisonKey));
            }

            OriginalText = originalText;
            ComparisonKey = comparisonKey;
        }

        public string OriginalText { get; }
        public string ComparisonKey { get; }

        public bool EqualsGrade(NormalizedSteelGrade other)
        {
            return other != null &&
                string.Equals(ComparisonKey, other.ComparisonKey, StringComparison.OrdinalIgnoreCase);
        }
    }

    public sealed class SteelGradeNormalizationResult
    {
        private SteelGradeNormalizationResult(
            NormalizedSteelGrade grade,
            bool isAbsent,
            bool isAmbiguousNumeric)
        {
            Grade = grade;
            IsAbsent = isAbsent;
            IsAmbiguousNumeric = isAmbiguousNumeric;
        }

        public NormalizedSteelGrade Grade { get; }
        public bool IsAbsent { get; }
        public bool IsAmbiguousNumeric { get; }

        public static SteelGradeNormalizationResult Absent()
        {
            return new SteelGradeNormalizationResult(null, true, false);
        }

        public static SteelGradeNormalizationResult AmbiguousNumeric()
        {
            return new SteelGradeNormalizationResult(null, false, true);
        }

        public static SteelGradeNormalizationResult Success(NormalizedSteelGrade grade)
        {
            if (grade == null)
            {
                throw new ArgumentNullException(nameof(grade));
            }

            return new SteelGradeNormalizationResult(grade, false, false);
        }
    }
}
