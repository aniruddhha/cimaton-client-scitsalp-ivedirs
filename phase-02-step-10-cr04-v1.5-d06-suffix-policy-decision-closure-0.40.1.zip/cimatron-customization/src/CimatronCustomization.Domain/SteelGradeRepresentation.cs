namespace CimatronCustomization.Domain
{
    public enum SteelGradeRepresentation
    {
        Strict = 0,
        WerkstoffCanonical = 1
    }
}
