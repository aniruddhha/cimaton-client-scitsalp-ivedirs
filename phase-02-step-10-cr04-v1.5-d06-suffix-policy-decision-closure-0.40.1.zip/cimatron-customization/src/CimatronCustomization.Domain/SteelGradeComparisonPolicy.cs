namespace CimatronCustomization.Domain
{
    public sealed class SteelGradeComparisonPolicy
    {
        public SteelGradeComparisonPolicy(
            SteelGradeRepresentation representation,
            bool compareGradeTokenOnly)
        {
            Representation = representation;
            CompareGradeTokenOnly = compareGradeTokenOnly;
        }

        public SteelGradeRepresentation Representation { get; }
        public bool CompareGradeTokenOnly { get; }
    }
}
