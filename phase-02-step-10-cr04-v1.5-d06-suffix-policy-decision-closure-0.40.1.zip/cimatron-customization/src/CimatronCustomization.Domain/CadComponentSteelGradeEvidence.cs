using System;
using System.Collections.Generic;

namespace CimatronCustomization.Domain
{
    public sealed class CadComponentSteelGradeEvidence
    {
        private readonly string[] attributeGradeValues;
        private readonly string[] bomMaterialValues;
        private readonly string[] placementDescriptions;
        private readonly ModelEntityReference[] entityReferences;
        private readonly FindingComponentContext[] componentContexts;

        public CadComponentSteelGradeEvidence(
            string componentKey,
            string originalKey,
            IEnumerable<string> attributeGradeValues,
            int bodyCount,
            IEnumerable<string> placementDescriptions,
            IEnumerable<ModelEntityReference> entityReferences,
            IEnumerable<string> bomMaterialValues = null,
            bool attributeTypeUnsupported = false,
            IEnumerable<FindingComponentContext> componentContexts = null)
        {
            if (string.IsNullOrWhiteSpace(componentKey))
            {
                throw new ArgumentException("A CAD component key is required.", nameof(componentKey));
            }

            if (bodyCount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(bodyCount));
            }

            ComponentKey = componentKey;
            OriginalKey = string.IsNullOrWhiteSpace(originalKey) ? componentKey : originalKey;
            this.attributeGradeValues = CopyStrings(attributeGradeValues);
            this.bomMaterialValues = CopyStrings(bomMaterialValues);
            BodyCount = bodyCount;
            this.placementDescriptions = CopyStrings(placementDescriptions);
            this.entityReferences = CopyReferences(entityReferences);
            AttributeTypeUnsupported = attributeTypeUnsupported;
            this.componentContexts = CopyContexts(componentContexts);
        }

        public string ComponentKey { get; }
        public string OriginalKey { get; }
        public IReadOnlyList<string> AttributeGradeValues => attributeGradeValues;
        public IReadOnlyList<string> BomMaterialValues => bomMaterialValues;
        public int BodyCount { get; }
        public IReadOnlyList<string> PlacementDescriptions => placementDescriptions;
        public IReadOnlyList<ModelEntityReference> EntityReferences => entityReferences;
        public bool AttributeTypeUnsupported { get; }
        public bool HasBomEvidence => bomMaterialValues.Length > 0;
        public IReadOnlyList<FindingComponentContext> ComponentContexts => componentContexts;

        private static string[] CopyStrings(IEnumerable<string> source)
        {
            return source == null ? Array.Empty<string>() : new List<string>(source).ToArray();
        }

        private static FindingComponentContext[] CopyContexts(IEnumerable<FindingComponentContext> source)
        {
            if (source == null)
            {
                return Array.Empty<FindingComponentContext>();
            }

            List<FindingComponentContext> copy = new List<FindingComponentContext>();
            foreach (FindingComponentContext context in source)
            {
                if (context == null)
                {
                    throw new ArgumentException("Component-context collections cannot contain null entries.", nameof(source));
                }

                copy.Add(context);
            }

            return copy.ToArray();
        }

        private static ModelEntityReference[] CopyReferences(IEnumerable<ModelEntityReference> source)
        {
            if (source == null)
            {
                return Array.Empty<ModelEntityReference>();
            }

            List<ModelEntityReference> copy = new List<ModelEntityReference>();
            foreach (ModelEntityReference reference in source)
            {
                if (reference == null)
                {
                    throw new ArgumentException("Entity-reference collections cannot contain null entries.", nameof(source));
                }

                copy.Add(reference);
            }

            return copy.ToArray();
        }
    }
}
