using System;
using System.Collections.Generic;

namespace CimatronCustomization.Domain
{
    public sealed class Finding
    {
        private readonly ModelEntityReference[] entityReferences;
        private readonly FindingComponentContext[] componentContexts;

        public Finding(
            string requirementId,
            ResultStatus status,
            string message,
            Measurement measuredValue = null,
            Measurement limit = null,
            IEnumerable<ModelEntityReference> entityReferences = null,
            Point3? location = null,
            IEnumerable<FindingComponentContext> componentContexts = null)
        {
            if (string.IsNullOrWhiteSpace(requirementId))
            {
                throw new ArgumentException("A finding requirement id is required.", nameof(requirementId));
            }

            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("A finding message is required.", nameof(message));
            }

            if (measuredValue != null && limit != null &&
                !string.Equals(measuredValue.Unit, limit.Unit, StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Measured value and limit must use the same unit.");
            }

            RequirementId = requirementId;
            Status = status;
            Message = message;
            MeasuredValue = measuredValue;
            Limit = limit;
            this.entityReferences = entityReferences == null
                ? Array.Empty<ModelEntityReference>()
                : new List<ModelEntityReference>(entityReferences).ToArray();
            Location = location;
            this.componentContexts = CopyComponentContexts(componentContexts);
        }

        public string RequirementId { get; }
        public ResultStatus Status { get; }
        public string Message { get; }
        public Measurement MeasuredValue { get; }
        public Measurement Limit { get; }
        public IReadOnlyList<ModelEntityReference> EntityReferences => entityReferences;
        public Point3? Location { get; }
        public IReadOnlyList<FindingComponentContext> ComponentContexts => componentContexts;

        private static FindingComponentContext[] CopyComponentContexts(IEnumerable<FindingComponentContext> source)
        {
            if (source == null)
            {
                return Array.Empty<FindingComponentContext>();
            }

            List<FindingComponentContext> copy = new List<FindingComponentContext>();
            foreach (FindingComponentContext context in source)
            {
                if (context == null)
                {
                    throw new ArgumentException("Component-context collections cannot contain null entries.", nameof(source));
                }

                copy.Add(context);
            }

            return copy.ToArray();
        }
    }

    public sealed class FindingComponentContext
    {
        public FindingComponentContext(
            string componentTitle,
            string occurrencePath,
            int instanceId,
            int occurrenceOrder,
            string partType,
            string partMaterial)
        {
            if (occurrenceOrder < 0) throw new ArgumentOutOfRangeException(nameof(occurrenceOrder));

            ComponentTitle = componentTitle ?? string.Empty;
            OccurrencePath = occurrencePath ?? string.Empty;
            InstanceId = instanceId;
            OccurrenceOrder = occurrenceOrder;
            PartType = partType ?? string.Empty;
            PartMaterial = partMaterial ?? string.Empty;
        }

        public string ComponentTitle { get; }
        public string OccurrencePath { get; }
        public int InstanceId { get; }
        public int OccurrenceOrder { get; }
        public string PartType { get; }
        public string PartMaterial { get; }
    }
}
