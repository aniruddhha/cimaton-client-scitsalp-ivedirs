namespace CimatronCustomization.Domain
{
    public enum ResultStatus
    {
        Passed,
        Succeeded,
        Failed,
        Warning,
        Info,
        Error,
        NotApplicable,
        Skipped,
        Unsupported
    }
}
