using System;
using System.Text;
using System.Text.RegularExpressions;

namespace CimatronCustomization.Domain
{
    public static class SteelGradeNormalizer
    {
        private static readonly Regex StrictDesignOrderAmbiguity =
            new Regex(@"^\d\.\d{1,3}$", RegexOptions.CultureInvariant);

        private static readonly Regex WerkstoffNumber =
            new Regex(@"^\d\.\d{1,4}$", RegexOptions.CultureInvariant);

        public static SteelGradeNormalizationResult NormalizeDesignOrder(
            string value,
            SteelGradeComparisonPolicy policy)
        {
            return Normalize(value, policy, true);
        }

        public static SteelGradeNormalizationResult NormalizeCad(
            string value,
            SteelGradeComparisonPolicy policy)
        {
            return Normalize(value, policy, false);
        }

        private static SteelGradeNormalizationResult Normalize(
            string value,
            SteelGradeComparisonPolicy policy,
            bool applyDesignOrderAmbiguityGuard)
        {
            if (policy == null)
            {
                throw new ArgumentNullException(nameof(policy));
            }

            string collapsed = CollapseWhitespace(value);
            if (collapsed.Length == 0)
            {
                return SteelGradeNormalizationResult.Absent();
            }

            string comparisonText = policy.CompareGradeTokenOnly
                ? FirstToken(collapsed)
                : collapsed;

            if (applyDesignOrderAmbiguityGuard &&
                policy.Representation == SteelGradeRepresentation.Strict &&
                StrictDesignOrderAmbiguity.IsMatch(comparisonText))
            {
                return SteelGradeNormalizationResult.AmbiguousNumeric();
            }

            if (policy.Representation == SteelGradeRepresentation.WerkstoffCanonical &&
                WerkstoffNumber.IsMatch(comparisonText))
            {
                int separator = comparisonText.IndexOf('.');
                string decimals = comparisonText.Substring(separator + 1);
                comparisonText = comparisonText.Substring(0, separator + 1) + decimals.PadRight(4, '0');
            }

            return SteelGradeNormalizationResult.Success(
                new NormalizedSteelGrade(value, comparisonText));
        }

        private static string CollapseWhitespace(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder(value.Length);
            bool pendingSpace = false;

            foreach (char character in value.Trim())
            {
                if (char.IsWhiteSpace(character) || character == '\u00A0')
                {
                    pendingSpace = builder.Length > 0;
                    continue;
                }

                if (pendingSpace)
                {
                    builder.Append(' ');
                    pendingSpace = false;
                }

                builder.Append(character);
            }

            return builder.ToString();
        }

        private static string FirstToken(string value)
        {
            int space = value.IndexOf(' ');
            return space < 0 ? value : value.Substring(0, space);
        }
    }
}
