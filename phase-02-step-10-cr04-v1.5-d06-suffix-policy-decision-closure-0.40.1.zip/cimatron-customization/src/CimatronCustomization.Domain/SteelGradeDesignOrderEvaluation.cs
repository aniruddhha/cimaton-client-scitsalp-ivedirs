using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Domain
{
    public static class SteelGradeDesignOrderEvaluation
    {
        private const string RequirementId = "CR-04";

        public static IReadOnlyList<Finding> Evaluate(
            IEnumerable<DesignOrderSteelGradeEntry> entries,
            IEnumerable<CadComponentSteelGradeEvidence> evidence,
            SteelGradeComparisonPolicy policy)
        {
            if (entries == null)
            {
                throw new ArgumentNullException(nameof(entries));
            }

            if (evidence == null)
            {
                throw new ArgumentNullException(nameof(evidence));
            }

            if (policy == null)
            {
                throw new ArgumentNullException(nameof(policy));
            }

            DesignOrderSteelGradeEntry[] entryArray = entries.ToArray();
            CadComponentSteelGradeEvidence[] evidenceArray = evidence.ToArray();
            RejectNullItems(entryArray, nameof(entries));
            RejectNullItems(evidenceArray, nameof(evidence));

            if (entryArray.Length == 0)
            {
                return new[] { Error("NO_DO_ROWS", "The Design-Order contains no data rows.") };
            }

            List<Finding> inputErrors = ValidateDesignOrder(entryArray, policy);
            if (inputErrors.Count > 0)
            {
                return inputErrors;
            }

            Dictionary<string, DesignOrderSteelGradeEntry> entriesByKey = entryArray.ToDictionary(
                item => ComponentKeyNormalizer.Normalize(item.ComponentKey),
                item => item,
                StringComparer.OrdinalIgnoreCase);

            Dictionary<string, List<CadComponentSteelGradeEvidence>> evidenceByKey = GroupEvidence(evidenceArray);
            List<Finding> findings = new List<Finding>();

            foreach (KeyValuePair<string, DesignOrderSteelGradeEntry> entryPair in entriesByKey)
            {
                if (!evidenceByKey.TryGetValue(entryPair.Key, out List<CadComponentSteelGradeEvidence> componentEvidence))
                {
                    findings.Add(Failed(
                        "DO_COMPONENT_NOT_FOUND",
                        $"Design-Order component '{entryPair.Value.ComponentKey}' was not found in the evaluated CAD components."));
                    continue;
                }

                findings.Add(EvaluateMatchedComponent(entryPair.Value, componentEvidence, policy));
            }

            foreach (KeyValuePair<string, List<CadComponentSteelGradeEvidence>> cadPair in evidenceByKey)
            {
                if (entriesByKey.ContainsKey(cadPair.Key))
                {
                    continue;
                }

                if (CarriesGradeValue(cadPair.Value, policy))
                {
                    CadComponentSteelGradeEvidence first = cadPair.Value[0];
                    findings.Add(new Finding(
                        RequirementId,
                        ResultStatus.Warning,
                        $"[CAD_COMPONENT_NOT_IN_DO] CAD component '{first.OriginalKey}' carries a steel-grade value but is not present in the Design-Order.",
                        entityReferences: CollectReferences(cadPair.Value),
                        componentContexts: CollectContexts(cadPair.Value)));
                }
            }

            return findings;
        }

        private static List<Finding> ValidateDesignOrder(
            IReadOnlyList<DesignOrderSteelGradeEntry> entries,
            SteelGradeComparisonPolicy policy)
        {
            List<Finding> errors = new List<Finding>();
            HashSet<string> seenKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (DesignOrderSteelGradeEntry entry in entries)
            {
                string normalizedKey = ComponentKeyNormalizer.Normalize(entry.ComponentKey);
                if (!seenKeys.Add(normalizedKey))
                {
                    errors.Add(Error(
                        "DO_DUPLICATE_COMPONENT_KEY",
                        $"Design-Order component key '{entry.ComponentKey}' is duplicated after normalization."));
                    continue;
                }

                SteelGradeNormalizationResult normalized = SteelGradeNormalizer.NormalizeDesignOrder(entry.SteelGrade, policy);
                if (normalized.IsAbsent)
                {
                    errors.Add(Error(
                        "DO_GRADE_MISSING",
                        $"Design-Order component '{entry.ComponentKey}' has no steel grade."));
                }
                else if (normalized.IsAmbiguousNumeric)
                {
                    errors.Add(Error(
                        "DO_GRADE_AMBIGUOUS_NUMERIC",
                        $"Design-Order steel grade '{entry.SteelGrade}' for component '{entry.ComponentKey}' is ambiguous under Strict text comparison."));
                }
            }

            return errors;
        }

        private static Finding EvaluateMatchedComponent(
            DesignOrderSteelGradeEntry entry,
            IReadOnlyList<CadComponentSteelGradeEvidence> evidence,
            SteelGradeComparisonPolicy policy)
        {
            IReadOnlyList<ModelEntityReference> references = CollectReferences(evidence);
            if (evidence.Any(item => item.AttributeTypeUnsupported))
            {
                return new Finding(
                    RequirementId,
                    ResultStatus.Unsupported,
                    $"[STEEL_GRADE_ATTRIBUTE_TYPE_UNSUPPORTED] Component '{entry.ComponentKey}' exposes the requested steel-grade attribute in an unsupported runtime type.",
                    entityReferences: references,
                    componentContexts: CollectContexts(evidence));
            }

            if (HasSourceDisagreement(evidence, policy))
            {
                return new Finding(
                    RequirementId,
                    ResultStatus.Failed,
                    $"[STEEL_GRADE_SOURCE_DISAGREEMENT] Component '{entry.ComponentKey}' has different body-attribute and BOM steel-grade evidence.",
                    entityReferences: references,
                    componentContexts: CollectContexts(evidence));
            }

            List<NormalizedSteelGrade> cadGrades = CollectDistinctCadGrades(evidence, policy);
            if (cadGrades.Count == 0)
            {
                return new Finding(
                    RequirementId,
                    ResultStatus.Failed,
                    $"[STEEL_GRADE_ATTRIBUTE_MISSING] Component '{entry.ComponentKey}' has no steel-grade value.",
                    entityReferences: references,
                    componentContexts: CollectContexts(evidence));
            }

            if (cadGrades.Count > 1)
            {
                return new Finding(
                    RequirementId,
                    ResultStatus.Failed,
                    $"[STEEL_GRADE_ATTRIBUTE_AMBIGUOUS] Component '{entry.ComponentKey}' has more than one distinct steel-grade value.",
                    entityReferences: references,
                    componentContexts: CollectContexts(evidence));
            }

            SteelGradeNormalizationResult designOrder = SteelGradeNormalizer.NormalizeDesignOrder(entry.SteelGrade, policy);
            bool matches = designOrder.Grade != null && cadGrades[0].EqualsGrade(designOrder.Grade);
            return new Finding(
                RequirementId,
                matches ? ResultStatus.Passed : ResultStatus.Failed,
                matches
                    ? $"[STEEL_GRADE_MATCH] Component '{entry.ComponentKey}' steel grade matches the Design-Order value '{entry.SteelGrade}'."
                    : $"[STEEL_GRADE_MISMATCH] Component '{entry.ComponentKey}' CAD steel grade '{cadGrades[0].OriginalText}' does not match Design-Order value '{entry.SteelGrade}'.",
                entityReferences: references,
                componentContexts: CollectContexts(evidence));
        }

        private static bool HasSourceDisagreement(
            IEnumerable<CadComponentSteelGradeEvidence> evidence,
            SteelGradeComparisonPolicy policy)
        {
            List<NormalizedSteelGrade> attributeGrades = DistinctGrades(
                evidence.SelectMany(item => item.AttributeGradeValues),
                policy);
            List<NormalizedSteelGrade> bomGrades = DistinctGrades(
                evidence.SelectMany(item => item.BomMaterialValues),
                policy);

            if (attributeGrades.Count == 0 || bomGrades.Count == 0)
            {
                return false;
            }

            if (attributeGrades.Count != bomGrades.Count)
            {
                return true;
            }

            return attributeGrades.Any(
                attribute => !bomGrades.Any(bom => attribute.EqualsGrade(bom)));
        }

        private static List<NormalizedSteelGrade> CollectDistinctCadGrades(
            IEnumerable<CadComponentSteelGradeEvidence> evidence,
            SteelGradeComparisonPolicy policy)
        {
            return DistinctGrades(
                evidence.SelectMany(item => item.AttributeGradeValues.Concat(item.BomMaterialValues)),
                policy);
        }

        private static List<NormalizedSteelGrade> DistinctGrades(
            IEnumerable<string> values,
            SteelGradeComparisonPolicy policy)
        {
            List<NormalizedSteelGrade> distinct = new List<NormalizedSteelGrade>();
            foreach (string value in values)
            {
                SteelGradeNormalizationResult normalized = SteelGradeNormalizer.NormalizeCad(value, policy);
                if (normalized.IsAbsent)
                {
                    continue;
                }

                if (!distinct.Any(existing => existing.EqualsGrade(normalized.Grade)))
                {
                    distinct.Add(normalized.Grade);
                }
            }

            return distinct;
        }

        private static bool CarriesGradeValue(
            IEnumerable<CadComponentSteelGradeEvidence> evidence,
            SteelGradeComparisonPolicy policy)
        {
            return CollectDistinctCadGrades(evidence, policy).Count > 0;
        }

        private static Dictionary<string, List<CadComponentSteelGradeEvidence>> GroupEvidence(
            IEnumerable<CadComponentSteelGradeEvidence> evidence)
        {
            Dictionary<string, List<CadComponentSteelGradeEvidence>> result =
                new Dictionary<string, List<CadComponentSteelGradeEvidence>>(StringComparer.OrdinalIgnoreCase);

            foreach (CadComponentSteelGradeEvidence item in evidence)
            {
                string key = ComponentKeyNormalizer.Normalize(item.ComponentKey);
                if (!result.TryGetValue(key, out List<CadComponentSteelGradeEvidence> group))
                {
                    group = new List<CadComponentSteelGradeEvidence>();
                    result.Add(key, group);
                }

                group.Add(item);
            }

            return result;
        }


        private static List<FindingComponentContext> CollectContexts(
            IEnumerable<CadComponentSteelGradeEvidence> evidence)
        {
            List<FindingComponentContext> contexts = new List<FindingComponentContext>();
            HashSet<int> seenOrders = new HashSet<int>();

            foreach (CadComponentSteelGradeEvidence item in evidence)
            {
                foreach (FindingComponentContext context in item.ComponentContexts)
                {
                    if (seenOrders.Add(context.OccurrenceOrder))
                    {
                        contexts.Add(context);
                    }
                }
            }

            contexts.Sort((left, right) => left.OccurrenceOrder.CompareTo(right.OccurrenceOrder));
            return contexts;
        }

        private static List<ModelEntityReference> CollectReferences(
            IEnumerable<CadComponentSteelGradeEvidence> evidence)
        {
            List<ModelEntityReference> references = new List<ModelEntityReference>();
            HashSet<string> seen = new HashSet<string>(StringComparer.Ordinal);

            foreach (CadComponentSteelGradeEvidence item in evidence)
            {
                foreach (ModelEntityReference reference in item.EntityReferences)
                {
                    if (seen.Add(reference.Value))
                    {
                        references.Add(reference);
                    }
                }
            }

            return references;
        }

        private static Finding Error(string code, string message)
        {
            return new Finding(RequirementId, ResultStatus.Error, $"[{code}] {message}");
        }

        private static Finding Failed(string code, string message)
        {
            return new Finding(RequirementId, ResultStatus.Failed, $"[{code}] {message}");
        }

        private static void RejectNullItems<T>(IEnumerable<T> items, string parameterName)
            where T : class
        {
            if (items.Any(item => item == null))
            {
                throw new ArgumentException("The collection cannot contain null entries.", parameterName);
            }
        }
    }
}
