using System;

namespace CimatronCustomization.Application
{
    public enum SteelGradeCategoryResolutionKind
    {
        Mapped = 0,
        Excluded = 1,
        Unmapped = 2,
        Ambiguous = 3,
        UnknownAttributeCategory = 4
    }

    public sealed class SteelGradeCategoryResolution
    {
        private SteelGradeCategoryResolution(
            SteelGradeCategoryResolutionKind kind,
            string categoryKey,
            string detail)
        {
            Kind = kind;
            CategoryKey = categoryKey;
            Detail = detail ?? string.Empty;
        }

        public SteelGradeCategoryResolutionKind Kind { get; }
        public string CategoryKey { get; }
        public string Detail { get; }

        public static SteelGradeCategoryResolution Mapped(string categoryKey)
        {
            if (string.IsNullOrWhiteSpace(categoryKey))
                throw new ArgumentException("A mapped category key is required.", nameof(categoryKey));
            return new SteelGradeCategoryResolution(SteelGradeCategoryResolutionKind.Mapped, categoryKey, string.Empty);
        }

        public static SteelGradeCategoryResolution NotMapped(
            SteelGradeCategoryResolutionKind kind,
            string detail)
        {
            if (kind == SteelGradeCategoryResolutionKind.Mapped)
                throw new ArgumentException("Use Mapped(...) for a mapped category.", nameof(kind));
            if (string.IsNullOrWhiteSpace(detail))
                throw new ArgumentException("A non-mapped resolution requires detail.", nameof(detail));
            return new SteelGradeCategoryResolution(kind, null, detail);
        }
    }
}
