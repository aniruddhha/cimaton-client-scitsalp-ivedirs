using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Selects a globally unique, unsuppressed, top-level occurrence without any known-answer constants.
    /// </summary>
    public static class TopLevelHighlightTargetSelector
    {
        public static TopLevelHighlightTargetSelection Select(
            IReadOnlyList<TopLevelHighlightCandidateOccurrence> occurrences,
            string expectedModelTitle)
        {
            if (occurrences == null) throw new ArgumentNullException(nameof(occurrences));
            if (string.IsNullOrWhiteSpace(expectedModelTitle)) throw new ArgumentException("Expected model title is required.", nameof(expectedModelTitle));

            Dictionary<int, int> counts = new Dictionary<int, int>();
            foreach (TopLevelHighlightCandidateOccurrence occurrence in occurrences)
            {
                if (occurrence == null) throw new ArgumentException("Occurrences cannot contain null values.", nameof(occurrences));
                int count;
                counts.TryGetValue(occurrence.InstanceId, out count);
                counts[occurrence.InstanceId] = count + 1;
            }

            int[] candidateIds = occurrences
                .Where(o => o.Depth == 0 && !o.IsSuppressed && string.Equals(o.ModelTitle, expectedModelTitle, StringComparison.Ordinal))
                .Select(o => o.InstanceId)
                .OrderBy(id => id)
                .ToArray();

            int[] repeatedIds = counts
                .Where(pair => pair.Value > 1)
                .Select(pair => pair.Key)
                .OrderBy(id => id)
                .ToArray();

            int? selectedId = candidateIds
                .Where(id => counts[id] == 1)
                .Select(id => (int?)id)
                .FirstOrDefault();

            string failure = selectedId.HasValue
                ? string.Empty
                : "[TOPLEVEL_HIGHLIGHT_NO_SAFE_CANDIDATE] no D-15(a)-safe top-level " + expectedModelTitle + " occurrence.";

            return new TopLevelHighlightTargetSelection(occurrences.Count, candidateIds, repeatedIds, selectedId, failure);
        }
    }
}
