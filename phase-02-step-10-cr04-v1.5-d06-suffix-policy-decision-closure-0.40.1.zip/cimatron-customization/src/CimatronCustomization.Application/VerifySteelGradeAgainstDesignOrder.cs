using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class VerifySteelGradeAgainstDesignOrder
    {
        private const string RequirementId = "CR-04";
        private const string ComponentKeyLogicalName = "ComponentKey";
        private const string SteelGradeLogicalName = "SteelGrade";

        private readonly ReadMappedTabularData readMappedTabularData;
        private readonly IDesignOrderFormReader formReader;
        private readonly IAssemblyBodyAttributeReader assemblyReader;
        private readonly IBomMaterialTableReader bomMaterialReader;
        private readonly IPartDocumentPropertyReader partDocumentPropertyReader;
        private readonly DesignOrderInputPathResolver pathResolver;

        public VerifySteelGradeAgainstDesignOrder(
            ReadMappedTabularData readMappedTabularData,
            IAssemblyBodyAttributeReader assemblyReader,
            IBomMaterialTableReader bomMaterialReader,
            DesignOrderInputPathResolver pathResolver)
            : this(readMappedTabularData, null, assemblyReader, bomMaterialReader, null, pathResolver)
        {
        }

        public VerifySteelGradeAgainstDesignOrder(
            ReadMappedTabularData readMappedTabularData,
            IDesignOrderFormReader formReader,
            IAssemblyBodyAttributeReader assemblyReader,
            IBomMaterialTableReader bomMaterialReader,
            IPartDocumentPropertyReader partDocumentPropertyReader,
            DesignOrderInputPathResolver pathResolver)
        {
            this.readMappedTabularData = readMappedTabularData ?? throw new ArgumentNullException(nameof(readMappedTabularData));
            this.formReader = formReader;
            this.assemblyReader = assemblyReader ?? throw new ArgumentNullException(nameof(assemblyReader));
            this.bomMaterialReader = bomMaterialReader ?? throw new ArgumentNullException(nameof(bomMaterialReader));
            this.partDocumentPropertyReader = partDocumentPropertyReader;
            this.pathResolver = pathResolver ?? throw new ArgumentNullException(nameof(pathResolver));
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "The CR-04 application boundary converts CAD-port runtime failures into Error findings; programming defects outside the CAD port still propagate.")]
        public IReadOnlyList<Finding> Execute(VerifySteelGradeAgainstDesignOrderRequest request)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            return request.DesignOrderFormat == DesignOrderFormat.Form
                ? ExecuteForm(request)
                : ExecuteTable(request);
        }

        private IReadOnlyList<Finding> ExecuteTable(VerifySteelGradeAgainstDesignOrderRequest request)
        {
            string inputPath = pathResolver.ResolveAbsolutePath(request.DesignOrderFilePath);
            ReadMappedTabularDataResult tabularResult = readMappedTabularData.Execute(
                new TabularHeaderSourceDefinition(inputPath, request.WorksheetName, request.HeaderRowNumber),
                CreateMapping(request));

            if (!tabularResult.IsSuccess)
                return SingleError(tabularResult.ErrorCode, tabularResult.ErrorMessage);

            if (!tabularResult.Table.Source.Columns.Any(
                column => string.Equals(column.LogicalName, SteelGradeLogicalName, StringComparison.OrdinalIgnoreCase)))
            {
                return SingleError(
                    "TABULAR_MAPPING_REQUIRED_HEADER_MISSING",
                    "The configured Design-Order steel-grade header was not found.");
            }

            List<DesignOrderSteelGradeEntry> entries = CreateDesignOrderEntries(tabularResult.Table.Rows);
            IReadOnlyList<Finding> inputValidation = SteelGradeDesignOrderEvaluation.Evaluate(
                entries,
                Array.Empty<CadComponentSteelGradeEvidence>(),
                request.ComparisonPolicy);
            Finding[] inputErrors = inputValidation.Where(finding => finding.Status == ResultStatus.Error).ToArray();
            if (inputErrors.Length > 0)
                return inputErrors;

            AssemblyBodyAttributeSnapshot snapshot = ReadAssembly(
                request.SteelGradeAttributeName,
                request.ComponentKeySource == SteelGradeComponentKeySource.BodyAttribute
                    ? request.ComponentKeyAttributeName
                    : null,
                out Finding readError);
            if (readError != null)
                return new[] { readError };

            Finding attributeReadError = FindCategoryAttributeReadError(
                snapshot,
                request.ComponentKeySource == SteelGradeComponentKeySource.BodyAttribute);
            if (attributeReadError != null)
                return new[] { attributeReadError };

            BomMaterialTableResult materialTable = ReadPartMaterials(out Finding materialReadError);
            if (materialReadError != null)
                return new[] { materialReadError };

            List<CadComponentSteelGradeEvidence> evidence = new List<CadComponentSteelGradeEvidence>();
            int tableOccurrenceOrder = 0;
            foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences)
            {
                int currentOccurrenceOrder = tableOccurrenceOrder++;
                if (occurrence.IsEffectivelySuppressed)
                    continue;

                if (!TryResolveComponentKey(occurrence, request.ComponentKeySource, out string componentKey, out Finding keyError))
                {
                    if (keyError != null)
                        return new[] { keyError };
                    continue;
                }

                string[] partMaterialValues = GetPartMaterialValues(materialTable, occurrence.ModelTitle);
                evidence.Add(CreateEvidence(componentKey, componentKey, occurrence, partMaterialValues, currentOccurrenceOrder, string.Empty));
            }

            IReadOnlyList<Finding> findings = SteelGradeDesignOrderEvaluation.Evaluate(
                entries,
                evidence,
                request.ComparisonPolicy);
            return SteelGradeOccurrenceHighlightSafety.Apply(findings, snapshot);
        }

        private IReadOnlyList<Finding> ExecuteForm(VerifySteelGradeAgainstDesignOrderRequest request)
        {
            if (formReader == null)
                throw new InvalidOperationException("A Design-Order Form reader is required for Form mode.");
            if (partDocumentPropertyReader == null)
                throw new InvalidOperationException("A native Part-property reader is required for Form mode.");
            if (request.FormProfile == null)
                throw new InvalidOperationException("Form mode requires a Form profile.");

            string inputPath = pathResolver.ResolveAbsolutePath(request.DesignOrderFilePath);
            DesignOrderFormReadResult formResult = formReader.Read(inputPath, request.FormProfile);
            if (formResult == null)
                throw new InvalidOperationException("The Design-Order Form reader returned a null result.");
            if (!formResult.IsSuccess)
                return SingleError(formResult.ErrorCode, formResult.ErrorMessage);

            AssemblyBodyAttributeSnapshot snapshot = ReadAssembly(
                request.SteelGradeAttributeName,
                null,
                out Finding readError);
            if (readError != null)
                return new[] { readError };

            Dictionary<string, List<PartMappedOccurrence>> mappedOccurrences =
                new Dictionary<string, List<PartMappedOccurrence>>(StringComparer.OrdinalIgnoreCase);
            List<Finding> findings = new List<Finding>();
            int formOccurrenceOrder = 0;

            foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences)
            {
                int currentOccurrenceOrder = formOccurrenceOrder++;
                if (occurrence.IsEffectivelySuppressed)
                    continue;

                if (request.ComponentExclusionPatterns.Any(pattern => SteelGradeCategoryResolver.MatchesPattern(occurrence.ModelTitle, pattern)))
                {
                    findings.Add(new Finding(
                        RequirementId,
                        ResultStatus.Info,
                        $"[CAD_COMPONENT_EXCLUDED] CAD component '{occurrence.ModelTitle}' is excluded from CR-04 validation.",
                        entityReferences: CollectReferences(new[] { occurrence }),
                        componentContexts: OneContext(occurrence, currentOccurrenceOrder, string.Empty, string.Empty)));
                    continue;
                }

                if (!string.Equals(occurrence.ModelType, "cmPart", StringComparison.Ordinal))
                {
                    findings.Add(new Finding(
                        RequirementId,
                        ResultStatus.Info,
                        $"[CAD_NON_PART_SKIPPED] CAD occurrence '{occurrence.ModelTitle}' has model type '{occurrence.ModelType}' and is outside CR-04 native Part-property validation.",
                        entityReferences: CollectReferences(new[] { occurrence }),
                        componentContexts: OneContext(occurrence, currentOccurrenceOrder, string.Empty, string.Empty)));
                    continue;
                }

                if (string.Equals(occurrence.ModelPid, @"\\5\Root.elt", StringComparison.OrdinalIgnoreCase))
                {
                    findings.Add(new Finding(
                        RequirementId,
                        ResultStatus.Info,
                        $"[CAD_SYNTHETIC_ROOT_SKIPPED] CAD occurrence '{occurrence.ModelTitle}' is Cimatron internal Root.elt and is outside CR-04 native Part-property validation.",
                        entityReferences: CollectReferences(new[] { occurrence }),
                        componentContexts: OneContext(occurrence, currentOccurrenceOrder, string.Empty, string.Empty)));
                    continue;
                }

                PartDocumentPropertyResult properties = partDocumentPropertyReader.Read(occurrence.ModelPid);
                if (properties == null)
                    throw new InvalidOperationException("The native Part-property reader returned a null result.");
                if (!properties.IsSuccess)
                {
                    findings.Add(new Finding(
                        RequirementId,
                        ResultStatus.Error,
                        $"[{properties.ErrorCode}] CAD component '{occurrence.ModelTitle}' native Part properties could not be read. {properties.ErrorMessage}",
                        entityReferences: CollectReferences(new[] { occurrence }),
                        componentContexts: OneContext(occurrence, currentOccurrenceOrder, string.Empty, string.Empty)));
                    continue;
                }

                if (!PartTypeCategoryResolver.TryResolve(
                    properties.RawPartType,
                    request.FormProfile.Categories,
                    out string categoryKey,
                    out string normalizedPartType))
                {
                    string code = normalizedPartType.Length == 0 ? "CAD_PART_TYPE_MISSING" : "CAD_PART_TYPE_UNSUPPORTED";
                    string detail = normalizedPartType.Length == 0
                        ? "Part Type is blank."
                        : "Part Type '" + normalizedPartType + "' is not one of the approved Design-Order categories.";
                    findings.Add(new Finding(
                        RequirementId,
                        ResultStatus.Warning,
                        $"[{code}] CAD component '{occurrence.ModelTitle}' was not mapped to a Design-Order category because {detail}",
                        entityReferences: CollectReferences(new[] { occurrence }),
                        componentContexts: OneContext(occurrence, currentOccurrenceOrder, normalizedPartType, properties.RawPartMaterial)));
                    continue;
                }

                if (!mappedOccurrences.TryGetValue(categoryKey, out List<PartMappedOccurrence> group))
                {
                    group = new List<PartMappedOccurrence>();
                    mappedOccurrences.Add(categoryKey, group);
                }

                group.Add(new PartMappedOccurrence(occurrence, properties.RawPartType, properties.RawPartMaterial, currentOccurrenceOrder));
            }

            List<DesignOrderSteelGradeEntry> entries = new List<DesignOrderSteelGradeEntry>();
            List<CadComponentSteelGradeEvidence> evidence = new List<CadComponentSteelGradeEvidence>();

            foreach (DesignOrderFormCategoryRecord category in formResult.Categories)
            {
                mappedOccurrences.TryGetValue(category.CategoryKey, out List<PartMappedOccurrence> categoryOccurrences);
                categoryOccurrences = categoryOccurrences ?? new List<PartMappedOccurrence>();

                if (!category.HasMaterialRequirement)
                    continue;

                if (!SteelGradeVocabularyValidation.IsKnownDesignOrderValue(
                    category.SteelGrade,
                    category.PermittedGrades,
                    request.ComparisonPolicy))
                {
                    findings.Add(new Finding(
                        RequirementId,
                        ResultStatus.Warning,
                        $"[DO_GRADE_UNKNOWN] Design-Order category '{category.CategoryKey}' contains Remark steel grade '{category.SteelGrade}' outside the approved closed vocabulary.",
                        entityReferences: CollectReferences(categoryOccurrences.Select(item => item.Occurrence)),
                        componentContexts: categoryOccurrences.Select(item => CreateContext(item.Occurrence, item.OccurrenceOrder, item.RawPartType, item.RawPartMaterial))));
                    continue;
                }

                bool invalidCadValue = false;
                foreach (PartMappedOccurrence mapped in categoryOccurrences)
                {
                    string normalizedMaterial = (mapped.RawPartMaterial ?? string.Empty).Trim();
                    if (normalizedMaterial.Length == 0)
                    {
                        invalidCadValue = true;
                        findings.Add(new Finding(
                            RequirementId,
                            ResultStatus.Error,
                            $"[CAD_PART_MATERIAL_MISSING] CAD component '{mapped.Occurrence.ModelTitle}' mapped by Part Type '{PartTypeCategoryResolver.NormalizeCategoryText(mapped.RawPartType)}' to category '{category.CategoryKey}' has blank Part Material.",
                            entityReferences: CollectReferences(new[] { mapped.Occurrence }),
                            componentContexts: OneContext(mapped.Occurrence, mapped.OccurrenceOrder, mapped.RawPartType, mapped.RawPartMaterial)));
                        continue;
                    }

                    if (!SteelGradeVocabularyValidation.IsKnownCadValue(
                        normalizedMaterial,
                        category.PermittedGrades,
                        request.ComparisonPolicy))
                    {
                        invalidCadValue = true;
                        findings.Add(new Finding(
                            RequirementId,
                            ResultStatus.Warning,
                            $"[CAD_GRADE_UNKNOWN] CAD component '{mapped.Occurrence.ModelTitle}' mapped to category '{category.CategoryKey}' contains Part Material '{normalizedMaterial}' outside the approved closed vocabulary.",
                            entityReferences: CollectReferences(new[] { mapped.Occurrence }),
                            componentContexts: OneContext(mapped.Occurrence, mapped.OccurrenceOrder, mapped.RawPartType, mapped.RawPartMaterial)));
                    }
                }

                if (invalidCadValue)
                    continue;

                entries.Add(new DesignOrderSteelGradeEntry(category.CategoryKey, category.SteelGrade, category.SourceRowNumber));
                foreach (PartMappedOccurrence mapped in categoryOccurrences)
                {
                    evidence.Add(CreateEvidence(
                        category.CategoryKey,
                        mapped.Occurrence.ModelTitle,
                        mapped.Occurrence,
                        new[] { (mapped.RawPartMaterial ?? string.Empty).Trim() },
                        mapped.OccurrenceOrder,
                        mapped.RawPartType));
                }
            }

            if (entries.Count > 0)
            {
                IReadOnlyList<Finding> comparisonFindings = SteelGradeDesignOrderEvaluation.Evaluate(entries, evidence, request.ComparisonPolicy);
                findings.AddRange(comparisonFindings);
            }

            findings.Add(new Finding(
                RequirementId,
                ResultStatus.Info,
                $"[MOULD_NUMBER_CHECK_NOT_PERFORMED] Design-Order mould number '{formResult.MouldNumber}' was read, but no approved Cimatron mould-identity source is available for comparison."));

            return SteelGradeOccurrenceHighlightSafety.Apply(findings, snapshot);
        }

        private sealed class PartMappedOccurrence
        {
            internal PartMappedOccurrence(AssemblyBodyAttributeOccurrence occurrence, string rawPartType, string rawPartMaterial, int occurrenceOrder)
            {
                Occurrence = occurrence ?? throw new ArgumentNullException(nameof(occurrence));
                RawPartType = rawPartType ?? string.Empty;
                RawPartMaterial = rawPartMaterial ?? string.Empty;
                OccurrenceOrder = occurrenceOrder;
            }

            internal AssemblyBodyAttributeOccurrence Occurrence { get; }
            internal string RawPartType { get; }
            internal string RawPartMaterial { get; }
            internal int OccurrenceOrder { get; }
        }

        private AssemblyBodyAttributeSnapshot ReadAssembly(
            string steelGradeAttributeName,
            string categoryAttributeName,
            out Finding error)
        {
            error = null;
            AssemblyBodyAttributeSnapshot snapshot;
            try
            {
                snapshot = assemblyReader.ReadNamedAttributes(steelGradeAttributeName, categoryAttributeName);
            }
            catch (Exception)
            {
                error = Error(
                    "CAD_READ_ERROR",
                    "The active assembly could not be read through the configured CAD evidence port.");
                return null;
            }

            if (snapshot == null)
                throw new InvalidOperationException("The assembly body-attribute reader returned a null snapshot.");
            if (!snapshot.IsSuccess)
            {
                error = Error("CAD_READ_ERROR", snapshot.ErrorMessage);
                return null;
            }

            return snapshot;
        }

        private static Finding CreateCategoryResolutionFinding(
            AssemblyBodyAttributeOccurrence occurrence,
            SteelGradeCategoryResolution resolution)
        {
            IReadOnlyList<ModelEntityReference> references = CollectReferences(new[] { occurrence });
            switch (resolution.Kind)
            {
                case SteelGradeCategoryResolutionKind.Excluded:
                    return new Finding(
                        RequirementId,
                        ResultStatus.Info,
                        $"[CAD_COMPONENT_EXCLUDED] CAD component '{occurrence.ModelTitle}' is excluded from CR-04 validation. {resolution.Detail}",
                        entityReferences: references);
                case SteelGradeCategoryResolutionKind.Unmapped:
                    return new Finding(
                        RequirementId,
                        ResultStatus.Warning,
                        $"[CAD_COMPONENT_CATEGORY_UNMAPPED] CAD component '{occurrence.ModelTitle}' could not be mapped to a Design-Order category. {resolution.Detail}",
                        entityReferences: references);
                case SteelGradeCategoryResolutionKind.Ambiguous:
                    return new Finding(
                        RequirementId,
                        ResultStatus.Warning,
                        $"[CAD_COMPONENT_CATEGORY_AMBIGUOUS] CAD component '{occurrence.ModelTitle}' was not validated because its category mapping is ambiguous. {resolution.Detail}",
                        entityReferences: references);
                case SteelGradeCategoryResolutionKind.UnknownAttributeCategory:
                    return new Finding(
                        RequirementId,
                        ResultStatus.Warning,
                        $"[CAD_CATEGORY_ATTRIBUTE_UNKNOWN] CAD component '{occurrence.ModelTitle}' was not validated because the configured category attribute names an unknown category. {resolution.Detail}",
                        entityReferences: references);
                default:
                    throw new InvalidOperationException("A mapped category must not be converted to a non-mapped finding.");
            }
        }

        private static CadComponentSteelGradeEvidence CreateEvidence(
            string componentKey,
            string originalKey,
            AssemblyBodyAttributeOccurrence occurrence,
            IEnumerable<string> partMaterialValues,
            int occurrenceOrder,
            string partType)
        {
            string[] materialValues = partMaterialValues == null
                ? Array.Empty<string>()
                : partMaterialValues.Where(value => !string.IsNullOrWhiteSpace(value)).ToArray();
            string partMaterial = materialValues.Length == 0 ? string.Empty : materialValues[0].Trim();
            return new CadComponentSteelGradeEvidence(
                componentKey,
                originalKey,
                Array.Empty<string>(),
                occurrence.Bodies.Count,
                new[] { occurrence.OccurrencePath },
                occurrence.Bodies.Select(body => body.BodyReference),
                bomMaterialValues: materialValues,
                attributeTypeUnsupported: false,
                componentContexts: OneContext(occurrence, occurrenceOrder, partType, partMaterial));
        }

        private static FindingComponentContext[] OneContext(
            AssemblyBodyAttributeOccurrence occurrence,
            int occurrenceOrder,
            string partType,
            string partMaterial)
        {
            return new[] { CreateContext(occurrence, occurrenceOrder, partType, partMaterial) };
        }

        private static FindingComponentContext CreateContext(
            AssemblyBodyAttributeOccurrence occurrence,
            int occurrenceOrder,
            string partType,
            string partMaterial)
        {
            return new FindingComponentContext(
                occurrence.ModelTitle,
                occurrence.OccurrencePath,
                occurrence.InstanceId,
                occurrenceOrder,
                PartTypeCategoryResolver.NormalizeCategoryText(partType),
                (partMaterial ?? string.Empty).Trim());
        }

        private static ModelEntityReference[] CollectReferences(
            IEnumerable<AssemblyBodyAttributeOccurrence> occurrences)
        {
            return occurrences
                .SelectMany(occurrence => occurrence.Bodies)
                .Select(body => body.BodyReference)
                .GroupBy(reference => reference.Value, StringComparer.Ordinal)
                .Select(group => group.First())
                .ToArray();
        }

        private static TabularMappingDefinition CreateMapping(VerifySteelGradeAgainstDesignOrderRequest request)
        {
            return new TabularMappingDefinition(
                "CR04DesignOrder",
                new[]
                {
                    new TabularFieldMappingDefinition(
                        ComponentKeyLogicalName,
                        new[] { request.ComponentKeyHeader },
                        TabularValueType.Text,
                        true),
                    new TabularFieldMappingDefinition(
                        SteelGradeLogicalName,
                        new[] { request.SteelGradeHeader },
                        TabularValueType.Text,
                        false)
                });
        }

        private static List<DesignOrderSteelGradeEntry> CreateDesignOrderEntries(
            IEnumerable<TabularRow> rows)
        {
            List<DesignOrderSteelGradeEntry> entries = new List<DesignOrderSteelGradeEntry>();
            foreach (TabularRow row in rows)
            {
                string componentKey = row.GetRequired(ComponentKeyLogicalName).TextValue;
                string steelGrade = row.TryGetValue(SteelGradeLogicalName, out TabularValue value)
                    ? value.TextValue
                    : string.Empty;
                entries.Add(new DesignOrderSteelGradeEntry(componentKey, steelGrade, row.SourceRowNumber));
            }
            return entries;
        }

        private BomMaterialTableResult ReadPartMaterials(out Finding error)
        {
            error = null;
            BomMaterialTableResult result;
            try
            {
                result = bomMaterialReader.ReadMaterialTable();
            }
            catch (Exception)
            {
                error = Error(
                    "CAD_PART_MATERIAL_READ_ERROR",
                    "The active assembly Part Material values could not be read through the configured CAD evidence port.");
                return null;
            }

            if (result == null)
                throw new InvalidOperationException("The BOM Part Material reader returned a null result.");
            if (!result.IsSuccess)
            {
                error = Error("CAD_PART_MATERIAL_READ_ERROR", result.ErrorMessage);
                return null;
            }

            return result;
        }

        private static string[] GetPartMaterialValues(BomMaterialTableResult materialTable, string modelTitle)
        {
            if (materialTable == null)
                throw new ArgumentNullException(nameof(materialTable));

            return materialTable.Rows
                .Where(row => string.Equals(row.ModelTitle, modelTitle, StringComparison.OrdinalIgnoreCase))
                .Select(row => row.Material)
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .Distinct(StringComparer.Ordinal)
                .ToArray();
        }

        private static Finding FindCategoryAttributeReadError(
            AssemblyBodyAttributeSnapshot snapshot,
            bool categoryAttributeRequested)
        {
            if (!categoryAttributeRequested)
                return null;

            foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences)
            {
                foreach (BodyAttributeObservation body in occurrence.Bodies)
                {
                    if (body.ComponentKeyStatus == AttributeObservationStatus.ReadError)
                    {
                        return Error(
                            "CAD_ATTRIBUTE_READ_ERROR",
                            "A configured category/component-key body attribute could not be read from the active assembly.");
                    }
                }
            }
            return null;
        }

        private static bool TryResolveComponentKey(
            AssemblyBodyAttributeOccurrence occurrence,
            SteelGradeComponentKeySource componentKeySource,
            out string componentKey,
            out Finding error)
        {
            error = null;
            if (componentKeySource == SteelGradeComponentKeySource.ModelTitle)
            {
                componentKey = occurrence.ModelTitle;
                return true;
            }

            string[] distinctKeys = occurrence.Bodies
                .Where(body => body.ComponentKeyStatus == AttributeObservationStatus.Present)
                .Select(body => body.ComponentKeyValue)
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (distinctKeys.Length == 0)
            {
                componentKey = null;
                error = Error(
                    "CAD_COMPONENT_KEY_MISSING",
                    "A non-suppressed occurrence has no configured component-key attribute value.");
                return false;
            }

            if (distinctKeys.Length > 1)
            {
                componentKey = null;
                error = Error(
                    "CAD_COMPONENT_KEY_AMBIGUOUS",
                    "A non-suppressed occurrence has more than one distinct configured component-key attribute value.");
                return false;
            }

            componentKey = distinctKeys[0];
            return true;
        }

        private static Finding[] SingleError(string code, string message)
        {
            return new[] { Error(code, message) };
        }

        private static Finding Error(string code, string message)
        {
            return new Finding(
                RequirementId,
                ResultStatus.Error,
                "[" + code + "] " + (string.IsNullOrWhiteSpace(message) ? "The operation could not be completed." : message));
        }
    }
}
