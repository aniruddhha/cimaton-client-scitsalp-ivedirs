using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    /// <summary>Application boundary for highlighting current-session model entities in the active Cimatron viewport.</summary>
    public interface IViewportEntityHighlighter
    {
        ViewportHighlightResult Highlight(IReadOnlyList<string> entityReferenceValues);

        /// <summary>Restores the selection captured before the first temporary highlight assignment.</summary>
        void RestoreSelection();
    }
}
