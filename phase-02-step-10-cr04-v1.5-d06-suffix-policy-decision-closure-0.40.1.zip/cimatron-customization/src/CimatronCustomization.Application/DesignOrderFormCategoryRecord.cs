using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class DesignOrderFormCategoryRecord
    {
        public DesignOrderFormCategoryRecord(
            string categoryKey,
            string productionLabel,
            int sourceRowNumber,
            string steelGrade,
            IEnumerable<string> permittedGrades)
            : this(categoryKey, productionLabel, sourceRowNumber, null, steelGrade, steelGrade, permittedGrades)
        {
        }

        public DesignOrderFormCategoryRecord(
            string categoryKey,
            string productionLabel,
            int sourceRowNumber,
            string selectedMaterialFamily,
            string rawRemark,
            string normalizedRemark,
            IEnumerable<string> permittedGrades)
        {
            if (string.IsNullOrWhiteSpace(categoryKey)) throw new ArgumentException("A category key is required.", nameof(categoryKey));
            if (string.IsNullOrWhiteSpace(productionLabel)) throw new ArgumentException("A production label is required.", nameof(productionLabel));
            if (sourceRowNumber < 1) throw new ArgumentOutOfRangeException(nameof(sourceRowNumber));
            if (permittedGrades == null) throw new ArgumentNullException(nameof(permittedGrades));

            CategoryKey = categoryKey;
            ProductionLabel = productionLabel;
            SourceRowNumber = sourceRowNumber;
            SelectedMaterialFamily = selectedMaterialFamily ?? string.Empty;
            RawRemark = rawRemark ?? string.Empty;
            SteelGrade = normalizedRemark ?? string.Empty;
            PermittedGrades = Array.AsReadOnly(permittedGrades.ToArray());
        }

        public string CategoryKey { get; }
        public string ProductionLabel { get; }
        public int SourceRowNumber { get; }
        public string SelectedMaterialFamily { get; }
        public string RawRemark { get; }
        public string SteelGrade { get; }
        public IReadOnlyList<string> PermittedGrades { get; }
        public bool HasMaterialRequirement => SelectedMaterialFamily.Length > 0 && SteelGrade.Length > 0;
    }
}
