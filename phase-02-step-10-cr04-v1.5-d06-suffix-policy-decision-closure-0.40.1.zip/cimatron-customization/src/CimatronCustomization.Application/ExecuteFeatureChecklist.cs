using System;
using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    /// <summary>Executes a selected set of registered features sequentially on the caller/UI thread.</summary>
    public sealed class ExecuteFeatureChecklist
    {
        private readonly ExecuteRegisteredFeature featureExecutor;

        public ExecuteFeatureChecklist(ExecuteRegisteredFeature featureExecutor)
        {
            this.featureExecutor = featureExecutor ?? throw new ArgumentNullException(nameof(featureExecutor));
        }

        public FeatureChecklistReport Execute(
            IEnumerable<string> featureIds,
            CimatronSessionSnapshot session,
            string cimatronVersion,
            string correlationId)
        {
            return Execute(featureIds, session, cimatronVersion, correlationId, null);
        }

        public FeatureChecklistReport Execute(
            IEnumerable<string> featureIds,
            CimatronSessionSnapshot session,
            string cimatronVersion,
            string correlationId,
            FeatureRunInputs runInputs)
        {
            if (featureIds == null) throw new ArgumentNullException(nameof(featureIds));
            if (session == null) throw new ArgumentNullException(nameof(session));
            if (string.IsNullOrWhiteSpace(correlationId)) throw new ArgumentException("A correlation id is required.", nameof(correlationId));

            List<string> ids = new List<string>();
            foreach (string featureId in featureIds)
            {
                if (string.IsNullOrWhiteSpace(featureId)) throw new ArgumentException("Feature ids cannot contain blank values.", nameof(featureIds));
                ids.Add(featureId);
            }
            if (ids.Count == 0) throw new ArgumentException("At least one feature id must be selected.", nameof(featureIds));

            FeatureExecutionContext context = new FeatureExecutionContext(correlationId, session, null, runInputs);
            List<FeatureExecutionReport> reports = new List<FeatureExecutionReport>();
            foreach (string featureId in ids)
            {
                reports.Add(featureExecutor.Execute(featureId, context, cimatronVersion));
            }

            return new FeatureChecklistReport(correlationId, reports);
        }
    }
}
