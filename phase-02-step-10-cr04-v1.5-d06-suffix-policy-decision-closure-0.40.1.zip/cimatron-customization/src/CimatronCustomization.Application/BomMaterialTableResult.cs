using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class BomMaterialTableResult
    {
        private readonly BomMaterialRow[] rows;

        private BomMaterialTableResult(bool isSuccess, IEnumerable<BomMaterialRow> rows, string errorMessage)
        {
            this.rows = (rows ?? Enumerable.Empty<BomMaterialRow>()).ToArray();
            if (this.rows.Any(row => row == null))
                throw new ArgumentException("BOM material rows cannot contain null entries.", nameof(rows));

            IsSuccess = isSuccess;
            ErrorMessage = errorMessage ?? string.Empty;
        }

        public bool IsSuccess { get; }
        public IReadOnlyList<BomMaterialRow> Rows => rows;
        public string ErrorMessage { get; }

        public static BomMaterialTableResult Succeeded(IEnumerable<BomMaterialRow> rows)
        {
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            return new BomMaterialTableResult(true, rows, null);
        }

        public static BomMaterialTableResult ReadError(string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(errorMessage))
                throw new ArgumentException("A BOM material read error requires an actionable message.", nameof(errorMessage));
            return new BomMaterialTableResult(false, null, errorMessage);
        }
    }
}
