using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Full read-only traversal snapshot used by CR-04. Success snapshots contain every occurrence
    /// in the production-highlighter-equivalent search scope, including suppressed and zero-body rows.
    /// </summary>
    public sealed class AssemblyBodyAttributeSnapshot
    {
        private readonly AssemblyBodyAttributeOccurrence[] occurrences;

        private AssemblyBodyAttributeSnapshot(
            bool isSuccess,
            IEnumerable<AssemblyBodyAttributeOccurrence> occurrences,
            string errorMessage)
        {
            this.occurrences = (occurrences ?? Enumerable.Empty<AssemblyBodyAttributeOccurrence>()).ToArray();
            if (this.occurrences.Any(occurrence => occurrence == null))
                throw new ArgumentException("Occurrence snapshots cannot contain null entries.", nameof(occurrences));

            IsSuccess = isSuccess;
            ErrorMessage = errorMessage ?? string.Empty;
        }

        public bool IsSuccess { get; }
        public IReadOnlyList<AssemblyBodyAttributeOccurrence> Occurrences => occurrences;
        public string ErrorMessage { get; }

        public static AssemblyBodyAttributeSnapshot Succeeded(
            IEnumerable<AssemblyBodyAttributeOccurrence> occurrences)
        {
            if (occurrences == null)
                throw new ArgumentNullException(nameof(occurrences));
            return new AssemblyBodyAttributeSnapshot(true, occurrences, null);
        }

        public static AssemblyBodyAttributeSnapshot ReadError(string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(errorMessage))
                throw new ArgumentException("A traversal read error requires an actionable message.", nameof(errorMessage));
            return new AssemblyBodyAttributeSnapshot(false, null, errorMessage);
        }
    }
}
