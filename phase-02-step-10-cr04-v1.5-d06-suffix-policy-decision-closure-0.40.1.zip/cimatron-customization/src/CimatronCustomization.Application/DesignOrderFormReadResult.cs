using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class DesignOrderFormReadResult
    {
        private DesignOrderFormReadResult(
            bool isSuccess,
            string profileId,
            string normalizedTemplateGuard,
            string mouldNumber,
            IEnumerable<DesignOrderFormCategoryRecord> categories,
            string errorCode,
            string errorMessage)
        {
            IsSuccess = isSuccess;
            ProfileId = profileId;
            NormalizedTemplateGuard = normalizedTemplateGuard;
            MouldNumber = mouldNumber;
            Categories = Array.AsReadOnly((categories ?? Array.Empty<DesignOrderFormCategoryRecord>()).ToArray());
            ErrorCode = errorCode;
            ErrorMessage = errorMessage;
        }

        public bool IsSuccess { get; }
        public string ProfileId { get; }
        public string NormalizedTemplateGuard { get; }
        public string MouldNumber { get; }
        public IReadOnlyList<DesignOrderFormCategoryRecord> Categories { get; }
        public string ErrorCode { get; }
        public string ErrorMessage { get; }

        public static DesignOrderFormReadResult Succeeded(
            string profileId,
            string normalizedTemplateGuard,
            string mouldNumber,
            IEnumerable<DesignOrderFormCategoryRecord> categories)
        {
            return new DesignOrderFormReadResult(true, profileId, normalizedTemplateGuard, mouldNumber, categories, null, null);
        }

        public static DesignOrderFormReadResult Error(string errorCode, string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(errorCode)) throw new ArgumentException("An error code is required.", nameof(errorCode));
            if (string.IsNullOrWhiteSpace(errorMessage)) throw new ArgumentException("An error message is required.", nameof(errorMessage));
            return new DesignOrderFormReadResult(false, null, null, null, null, errorCode, errorMessage);
        }
    }
}
