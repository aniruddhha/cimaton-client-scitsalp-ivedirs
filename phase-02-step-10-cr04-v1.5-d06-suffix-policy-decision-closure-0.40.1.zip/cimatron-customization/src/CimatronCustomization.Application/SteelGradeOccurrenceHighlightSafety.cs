using System;
using System.Collections.Generic;
using System.Linq;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public static class SteelGradeOccurrenceHighlightSafety
    {
        private const string Explanation =
            " [HIGHLIGHT_UNAVAILABLE] One or more occurrence references were omitted because InstanceId is ambiguous in the full highlighter-equivalent traversal; highlight unavailable for those placements.";

        public static IReadOnlyList<Finding> Apply(
            IEnumerable<Finding> findings,
            AssemblyBodyAttributeSnapshot snapshot)
        {
            if (findings == null)
                throw new ArgumentNullException(nameof(findings));
            if (snapshot == null)
                throw new ArgumentNullException(nameof(snapshot));
            if (!snapshot.IsSuccess)
                throw new ArgumentException("Highlight safety requires a successful traversal snapshot.", nameof(snapshot));

            Finding[] materialized = findings.ToArray();
            if (materialized.Any(finding => finding == null))
                throw new ArgumentException("Findings cannot contain null entries.", nameof(findings));

            HashSet<int> ambiguousInstanceIds = new HashSet<int>(
                snapshot.Occurrences
                    .GroupBy(occurrence => occurrence.InstanceId)
                    .Where(group => group.Count() > 1)
                    .Select(group => group.Key));

            HashSet<string> unsafeReferenceValues = new HashSet<string>(StringComparer.Ordinal);
            foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences)
            {
                if (!ambiguousInstanceIds.Contains(occurrence.InstanceId))
                    continue;

                foreach (BodyAttributeObservation body in occurrence.Bodies)
                    unsafeReferenceValues.Add(body.BodyReference.Value);
            }

            List<Finding> result = new List<Finding>(materialized.Length);
            foreach (Finding finding in materialized)
                result.Add(FilterFinding(finding, unsafeReferenceValues));
            return result;
        }

        private static Finding FilterFinding(Finding finding, HashSet<string> unsafeReferenceValues)
        {
            List<ModelEntityReference> safeReferences = finding.EntityReferences
                .Where(reference => !unsafeReferenceValues.Contains(reference.Value))
                .ToList();
            bool removedAny = safeReferences.Count != finding.EntityReferences.Count;
            if (!removedAny)
                return finding;

            return new Finding(
                finding.RequirementId,
                finding.Status,
                finding.Message + Explanation,
                finding.MeasuredValue,
                finding.Limit,
                safeReferences,
                finding.Location,
                finding.ComponentContexts);
        }
    }
}
