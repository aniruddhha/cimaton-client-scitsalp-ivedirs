namespace CimatronCustomization.Application
{
    /// <summary>
    /// Read-only application boundary for Cimatron native Part Material values exported through the
    /// verified BOM Material column route. Implementations must not save or modify the active model.
    /// </summary>
    public interface IBomMaterialTableReader
    {
        BomMaterialTableResult ReadMaterialTable();
    }
}
