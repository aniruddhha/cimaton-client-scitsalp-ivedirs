using System;

namespace CimatronCustomization.Application
{
    public sealed class BomMaterialRow
    {
        public BomMaterialRow(string modelTitle, string material, int sourceRowNumber)
        {
            if (string.IsNullOrWhiteSpace(modelTitle))
                throw new ArgumentException("A BOM model title is required.", nameof(modelTitle));
            if (sourceRowNumber < 1)
                throw new ArgumentOutOfRangeException(nameof(sourceRowNumber));

            ModelTitle = modelTitle.Trim();
            Material = material == null ? string.Empty : material.Trim();
            SourceRowNumber = sourceRowNumber;
        }

        public string ModelTitle { get; }
        public string Material { get; }
        public int SourceRowNumber { get; }
    }
}
