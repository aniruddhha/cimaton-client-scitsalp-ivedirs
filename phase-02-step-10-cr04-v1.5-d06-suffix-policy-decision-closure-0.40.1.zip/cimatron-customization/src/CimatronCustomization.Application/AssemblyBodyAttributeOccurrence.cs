using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// One occurrence from the complete highlighter-equivalent traversal. Occurrences must not be
    /// pre-filtered by CR-04 candidacy, suppression, body count or business relevance.
    /// </summary>
    public sealed class AssemblyBodyAttributeOccurrence
    {
        private readonly BodyAttributeObservation[] bodies;

        public AssemblyBodyAttributeOccurrence(
            string occurrencePath,
            int instanceId,
            string modelTitle,
            string modelPid,
            bool directSuppressionObserved,
            bool isEffectivelySuppressed,
            IEnumerable<BodyAttributeObservation> bodies)
            : this(
                occurrencePath,
                instanceId,
                modelTitle,
                modelPid,
                "cmPart",
                directSuppressionObserved,
                isEffectivelySuppressed,
                bodies)
        {
        }

        public AssemblyBodyAttributeOccurrence(
            string occurrencePath,
            int instanceId,
            string modelTitle,
            string modelPid,
            string modelType,
            bool directSuppressionObserved,
            bool isEffectivelySuppressed,
            IEnumerable<BodyAttributeObservation> bodies)
        {
            if (string.IsNullOrWhiteSpace(occurrencePath))
                throw new ArgumentException("An occurrence path is required.", nameof(occurrencePath));
            if (string.IsNullOrWhiteSpace(modelTitle))
                throw new ArgumentException("A model title is required.", nameof(modelTitle));
            if (string.IsNullOrWhiteSpace(modelType))
                throw new ArgumentException("A model type is required.", nameof(modelType));
            if (bodies == null)
                throw new ArgumentNullException(nameof(bodies));

            this.bodies = bodies.ToArray();
            if (this.bodies.Any(body => body == null))
                throw new ArgumentException("Body observations cannot contain null entries.", nameof(bodies));

            OccurrencePath = occurrencePath;
            InstanceId = instanceId;
            ModelTitle = modelTitle;
            ModelPid = modelPid ?? string.Empty;
            ModelType = modelType;
            DirectSuppressionObserved = directSuppressionObserved;
            IsEffectivelySuppressed = isEffectivelySuppressed;
        }

        public string OccurrencePath { get; }
        public int InstanceId { get; }
        public string ModelTitle { get; }
        public string ModelPid { get; }
        public string ModelType { get; }
        public bool DirectSuppressionObserved { get; }
        public bool IsEffectivelySuppressed { get; }
        public IReadOnlyList<BodyAttributeObservation> Bodies => bodies;
    }
}
