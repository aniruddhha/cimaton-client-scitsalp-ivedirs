namespace CimatronCustomization.Application
{
    public interface IAssemblyBodyAttributeReader
    {
        /// <summary>
        /// Returns the complete highlighter-equivalent occurrence traversal. Implementations must not
        /// pre-filter suppressed, zero-body, non-CR-04 or otherwise business-irrelevant occurrences,
        /// because Application owns D-15 InstanceId uniqueness and effective-suppression decisions.
        /// </summary>
        AssemblyBodyAttributeSnapshot ReadNamedAttributes(
            string steelGradeAttributeName,
            string componentKeyAttributeName);
    }
}
