namespace CimatronCustomization.Application
{
    /// <summary>
    /// Read-only live diagnostic boundary for CR-04 Slice 2A top-level highlight preparation.
    /// </summary>
    public interface ITopLevelHighlightDiagnosticReader
    {
        TopLevelHighlightDiagnosticResult Read(
            string expectedAssemblyTitle,
            string expectedModelTitle,
            string attributeName,
            string attributeValue,
            string expectedAttributeType);
    }
}
