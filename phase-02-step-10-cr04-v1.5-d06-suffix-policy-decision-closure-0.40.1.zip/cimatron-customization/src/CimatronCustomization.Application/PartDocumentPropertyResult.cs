using System;

namespace CimatronCustomization.Application
{
    public sealed class PartDocumentPropertyResult
    {
        private PartDocumentPropertyResult(
            bool isSuccess,
            string rawPartType,
            string rawPartMaterial,
            string errorCode,
            string errorMessage)
        {
            IsSuccess = isSuccess;
            RawPartType = rawPartType ?? string.Empty;
            RawPartMaterial = rawPartMaterial ?? string.Empty;
            ErrorCode = errorCode;
            ErrorMessage = errorMessage;
        }

        public bool IsSuccess { get; }
        public string RawPartType { get; }
        public string RawPartMaterial { get; }
        public string ErrorCode { get; }
        public string ErrorMessage { get; }

        public static PartDocumentPropertyResult Succeeded(string rawPartType, string rawPartMaterial)
        {
            return new PartDocumentPropertyResult(true, rawPartType, rawPartMaterial, null, null);
        }

        public static PartDocumentPropertyResult Error(string errorCode, string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(errorCode)) throw new ArgumentException("An error code is required.", nameof(errorCode));
            if (string.IsNullOrWhiteSpace(errorMessage)) throw new ArgumentException("An error message is required.", nameof(errorMessage));
            return new PartDocumentPropertyResult(false, null, null, errorCode, errorMessage);
        }
    }
}
