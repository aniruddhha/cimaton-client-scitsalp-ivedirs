using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public enum TopLevelHighlightNoMutationState
    {
        NotEvaluated = 0,
        Unchanged = 1,
        Changed = 2
    }

    /// <summary>
    /// Live read-only evidence used by the top-level highlight diagnostic feature.
    /// </summary>
    public sealed class TopLevelHighlightDiagnosticResult
    {
        public TopLevelHighlightDiagnosticResult(
            ResultStatus status,
            string message,
            int totalOccurrenceCount,
            IEnumerable<int> candidateInstanceIds,
            IEnumerable<int> repeatedInstanceIds,
            int? selectedInstanceId,
            ModelEntityReference reference,
            TopLevelHighlightNoMutationState noMutationState)
        {
            if (string.IsNullOrWhiteSpace(message)) throw new ArgumentException("Diagnostic message is required.", nameof(message));
            Status = status;
            Message = message;
            TotalOccurrenceCount = totalOccurrenceCount;
            CandidateInstanceIds = candidateInstanceIds == null ? Array.Empty<int>() : new List<int>(candidateInstanceIds).ToArray();
            RepeatedInstanceIds = repeatedInstanceIds == null ? Array.Empty<int>() : new List<int>(repeatedInstanceIds).ToArray();
            SelectedInstanceId = selectedInstanceId;
            Reference = reference;
            NoMutationState = noMutationState;
        }

        public ResultStatus Status { get; }
        public string Message { get; }
        public int TotalOccurrenceCount { get; }
        public IReadOnlyList<int> CandidateInstanceIds { get; }
        public IReadOnlyList<int> RepeatedInstanceIds { get; }
        public int? SelectedInstanceId { get; }
        public ModelEntityReference Reference { get; }
        public TopLevelHighlightNoMutationState NoMutationState { get; }
    }
}
