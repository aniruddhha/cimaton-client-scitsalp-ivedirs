using System;
using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Pure result of top-level occurrence safety selection.
    /// </summary>
    public sealed class TopLevelHighlightTargetSelection
    {
        public TopLevelHighlightTargetSelection(
            int totalOccurrenceCount,
            IEnumerable<int> candidateInstanceIds,
            IEnumerable<int> repeatedInstanceIds,
            int? selectedInstanceId,
            string failureMessage)
        {
            if (totalOccurrenceCount < 0) throw new ArgumentOutOfRangeException(nameof(totalOccurrenceCount));
            TotalOccurrenceCount = totalOccurrenceCount;
            CandidateInstanceIds = Copy(candidateInstanceIds);
            RepeatedInstanceIds = Copy(repeatedInstanceIds);
            SelectedInstanceId = selectedInstanceId;
            FailureMessage = failureMessage ?? string.Empty;
        }

        public int TotalOccurrenceCount { get; }
        public IReadOnlyList<int> CandidateInstanceIds { get; }
        public IReadOnlyList<int> RepeatedInstanceIds { get; }
        public int? SelectedInstanceId { get; }
        public string FailureMessage { get; }
        public bool IsSelected => SelectedInstanceId.HasValue;

        private static int[] Copy(IEnumerable<int> values)
        {
            return values == null ? Array.Empty<int>() : new List<int>(values).ToArray();
        }
    }
}
