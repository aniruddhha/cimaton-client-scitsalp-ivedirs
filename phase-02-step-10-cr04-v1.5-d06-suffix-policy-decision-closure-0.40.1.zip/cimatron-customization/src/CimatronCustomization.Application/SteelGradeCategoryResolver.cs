using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public static class SteelGradeCategoryResolver
    {
        public static SteelGradeCategoryResolution Resolve(
            AssemblyBodyAttributeOccurrence occurrence,
            SteelGradeCategoryMappingConfiguration configuration,
            IEnumerable<string> knownCategoryKeys)
        {
            if (occurrence == null)
                throw new ArgumentNullException(nameof(occurrence));
            if (configuration == null)
                throw new ArgumentNullException(nameof(configuration));
            if (knownCategoryKeys == null)
                throw new ArgumentNullException(nameof(knownCategoryKeys));

            HashSet<string> knownCategories = new HashSet<string>(
                knownCategoryKeys.Where(value => !string.IsNullOrWhiteSpace(value)),
                StringComparer.OrdinalIgnoreCase);

            if (!string.IsNullOrWhiteSpace(configuration.CategoryAttributeName))
            {
                string[] attributeCategories = occurrence.Bodies
                    .Where(body => body.ComponentKeyStatus == AttributeObservationStatus.Present)
                    .Select(body => body.ComponentKeyValue)
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();

                if (attributeCategories.Length > 1)
                {
                    return SteelGradeCategoryResolution.NotMapped(
                        SteelGradeCategoryResolutionKind.Ambiguous,
                        "The configured category attribute has more than one distinct value on the occurrence.");
                }

                if (attributeCategories.Length == 1)
                {
                    string category = attributeCategories[0];
                    if (!knownCategories.Contains(category))
                    {
                        return SteelGradeCategoryResolution.NotMapped(
                            SteelGradeCategoryResolutionKind.UnknownAttributeCategory,
                            "The configured category attribute names an unknown Design-Order category.");
                    }

                    return SteelGradeCategoryResolution.Mapped(
                        knownCategories.First(value => string.Equals(value, category, StringComparison.OrdinalIgnoreCase)));
                }
            }

            if (configuration.ExcludedModelTitlePatterns.Any(pattern => MatchesPattern(occurrence.ModelTitle, pattern)))
            {
                return SteelGradeCategoryResolution.NotMapped(
                    SteelGradeCategoryResolutionKind.Excluded,
                    "The occurrence ModelTitle matches the configured exclusion list.");
            }

            string[] matchedCategories = configuration.Patterns
                .Where(pattern => MatchesPattern(occurrence.ModelTitle, pattern.ModelTitlePattern))
                .Select(pattern => pattern.CategoryKey)
                .Where(knownCategories.Contains)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (matchedCategories.Length == 0)
            {
                return SteelGradeCategoryResolution.NotMapped(
                    SteelGradeCategoryResolutionKind.Unmapped,
                    "The occurrence ModelTitle does not match a configured Design-Order category pattern.");
            }

            if (matchedCategories.Length > 1)
            {
                return SteelGradeCategoryResolution.NotMapped(
                    SteelGradeCategoryResolutionKind.Ambiguous,
                    "The occurrence ModelTitle matches more than one configured Design-Order category.");
            }

            string matched = matchedCategories[0];
            return SteelGradeCategoryResolution.Mapped(
                knownCategories.First(value => string.Equals(value, matched, StringComparison.OrdinalIgnoreCase)));
        }

        internal static bool MatchesPattern(string value, string pattern)
        {
            if (value == null || pattern == null)
                return false;

            int valueIndex = 0;
            int patternIndex = 0;
            int starIndex = -1;
            int backtrackValueIndex = -1;

            while (valueIndex < value.Length)
            {
                if (patternIndex < pattern.Length &&
                    (pattern[patternIndex] == '?' || pattern[patternIndex] == value[valueIndex]))
                {
                    valueIndex++;
                    patternIndex++;
                    continue;
                }

                if (patternIndex < pattern.Length && pattern[patternIndex] == '*')
                {
                    starIndex = patternIndex++;
                    backtrackValueIndex = valueIndex;
                    continue;
                }

                if (starIndex >= 0)
                {
                    patternIndex = starIndex + 1;
                    valueIndex = ++backtrackValueIndex;
                    continue;
                }

                return false;
            }

            while (patternIndex < pattern.Length && pattern[patternIndex] == '*')
                patternIndex++;

            return patternIndex == pattern.Length;
        }
    }
}
