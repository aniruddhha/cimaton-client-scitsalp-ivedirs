namespace CimatronCustomization.Application
{
    public interface IDesignOrderFormReader
    {
        DesignOrderFormReadResult Read(string filePath, DesignOrderFormProfile profile);
    }
}
