using System;

namespace CimatronCustomization.Application
{
    public sealed class DesignOrderFormMaterialFamilyDefinition
    {
        public DesignOrderFormMaterialFamilyDefinition(string familyName, int columnIndex)
        {
            if (string.IsNullOrWhiteSpace(familyName)) throw new ArgumentException("A material-family name is required.", nameof(familyName));
            if (columnIndex < 0) throw new ArgumentOutOfRangeException(nameof(columnIndex));

            FamilyName = familyName.Trim();
            ColumnIndex = columnIndex;
        }

        public string FamilyName { get; }
        public int ColumnIndex { get; }
    }
}
