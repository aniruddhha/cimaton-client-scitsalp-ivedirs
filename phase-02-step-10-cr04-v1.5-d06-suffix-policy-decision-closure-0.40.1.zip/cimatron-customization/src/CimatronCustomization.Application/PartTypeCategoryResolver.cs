using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CimatronCustomization.Application
{
    public static class PartTypeCategoryResolver
    {
        public static bool TryResolve(
            string rawPartType,
            IEnumerable<DesignOrderFormCategoryDefinition> categories,
            out string categoryKey,
            out string normalizedPartType)
        {
            if (categories == null) throw new ArgumentNullException(nameof(categories));

            string normalized = NormalizeCategoryText(rawPartType);
            normalizedPartType = normalized;
            categoryKey = null;
            if (normalized.Length == 0)
                return false;

            DesignOrderFormCategoryDefinition[] matches = categories
                .Where(category => category != null)
                .Where(category => string.Equals(
                    NormalizeCategoryText(category.PartType),
                    normalized,
                    StringComparison.OrdinalIgnoreCase))
                .ToArray();

            if (matches.Length != 1)
                return false;

            categoryKey = matches[0].CategoryKey;
            return true;
        }

        public static string NormalizeCategoryText(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            StringBuilder builder = new StringBuilder(value.Length);
            bool pendingSpace = false;
            foreach (char character in value.Trim())
            {
                if (char.IsWhiteSpace(character))
                {
                    pendingSpace = builder.Length > 0;
                    continue;
                }

                if (pendingSpace)
                    builder.Append(' ');
                builder.Append(character);
                pendingSpace = false;
            }
            return builder.ToString();
        }
    }
}
