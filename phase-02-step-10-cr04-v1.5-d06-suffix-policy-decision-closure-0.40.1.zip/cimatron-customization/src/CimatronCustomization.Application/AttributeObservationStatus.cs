namespace CimatronCustomization.Application
{
    /// <summary>
    /// Runtime observation state for one requested body attribute.
    /// Slice 2 intentionally has no UnsupportedType value because a genuine stored-as-wrong-type
    /// Cimatron control has not yet proved that state distinguishable from a missing-name lookup.
    /// </summary>
    public enum AttributeObservationStatus
    {
        Present = 0,
        Absent = 1,
        ReadError = 2
    }
}
