using System;
using System.Collections.Generic;
using System.Linq;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public enum SteelGradeComponentKeySource
    {
        ModelTitle = 0,
        BodyAttribute = 1
    }

    public sealed class VerifySteelGradeAgainstDesignOrderRequest
    {
        public VerifySteelGradeAgainstDesignOrderRequest(
            string designOrderFilePath,
            string worksheetName,
            int headerRowNumber,
            string componentKeyHeader,
            string steelGradeHeader,
            string steelGradeAttributeName,
            SteelGradeComponentKeySource componentKeySource,
            string componentKeyAttributeName,
            SteelGradeComparisonPolicy comparisonPolicy)
        {
            if (string.IsNullOrWhiteSpace(designOrderFilePath)) throw new ArgumentException("A Design-Order file path is required.", nameof(designOrderFilePath));
            if (string.IsNullOrWhiteSpace(worksheetName)) throw new ArgumentException("A worksheet name is required.", nameof(worksheetName));
            if (headerRowNumber < 1) throw new ArgumentOutOfRangeException(nameof(headerRowNumber));
            if (string.IsNullOrWhiteSpace(componentKeyHeader)) throw new ArgumentException("A Design-Order component-key header is required.", nameof(componentKeyHeader));
            if (string.IsNullOrWhiteSpace(steelGradeHeader)) throw new ArgumentException("A Design-Order steel-grade header is required.", nameof(steelGradeHeader));
            if (string.IsNullOrWhiteSpace(steelGradeAttributeName)) throw new ArgumentException("A non-empty traversal compatibility attribute name is required by the protected assembly traversal adapter.", nameof(steelGradeAttributeName));
            if (!Enum.IsDefined(typeof(SteelGradeComponentKeySource), componentKeySource)) throw new ArgumentOutOfRangeException(nameof(componentKeySource));
            if (componentKeySource == SteelGradeComponentKeySource.BodyAttribute && string.IsNullOrWhiteSpace(componentKeyAttributeName)) throw new ArgumentException("A component-key attribute name is required when the key source is BodyAttribute.", nameof(componentKeyAttributeName));

            DesignOrderFilePath = designOrderFilePath;
            DesignOrderFormat = DesignOrderFormat.Table;
            WorksheetName = worksheetName;
            HeaderRowNumber = headerRowNumber;
            ComponentKeyHeader = componentKeyHeader;
            SteelGradeHeader = steelGradeHeader;
            SteelGradeAttributeName = steelGradeAttributeName;
            ComponentKeySource = componentKeySource;
            ComponentKeyAttributeName = componentKeyAttributeName;
            ComparisonPolicy = comparisonPolicy ?? throw new ArgumentNullException(nameof(comparisonPolicy));
            ComponentExclusionPatterns = Array.Empty<string>();
        }

        public VerifySteelGradeAgainstDesignOrderRequest(
            string designOrderFilePath,
            string steelGradeAttributeName,
            SteelGradeComparisonPolicy comparisonPolicy,
            DesignOrderFormProfile formProfile,
            IEnumerable<string> componentExclusionPatterns)
        {
            if (string.IsNullOrWhiteSpace(designOrderFilePath)) throw new ArgumentException("A Design-Order file path is required.", nameof(designOrderFilePath));
            if (string.IsNullOrWhiteSpace(steelGradeAttributeName)) throw new ArgumentException("A non-empty traversal compatibility attribute name is required by the protected assembly traversal adapter.", nameof(steelGradeAttributeName));
            if (componentExclusionPatterns == null) throw new ArgumentNullException(nameof(componentExclusionPatterns));

            string[] exclusions = componentExclusionPatterns.Select(value => value == null ? string.Empty : value.Trim()).ToArray();
            if (exclusions.Any(string.IsNullOrWhiteSpace)) throw new ArgumentException("Component exclusion patterns cannot contain blank values.", nameof(componentExclusionPatterns));

            DesignOrderFilePath = designOrderFilePath;
            DesignOrderFormat = DesignOrderFormat.Form;
            SteelGradeAttributeName = steelGradeAttributeName;
            ComparisonPolicy = comparisonPolicy ?? throw new ArgumentNullException(nameof(comparisonPolicy));
            FormProfile = formProfile ?? throw new ArgumentNullException(nameof(formProfile));
            ComponentExclusionPatterns = Array.AsReadOnly(exclusions);
            ComponentKeySource = SteelGradeComponentKeySource.ModelTitle;
        }

        public string DesignOrderFilePath { get; }
        public DesignOrderFormat DesignOrderFormat { get; }
        public string WorksheetName { get; }
        public int HeaderRowNumber { get; }
        public string ComponentKeyHeader { get; }
        public string SteelGradeHeader { get; }
        public string SteelGradeAttributeName { get; }
        public SteelGradeComponentKeySource ComponentKeySource { get; }
        public string ComponentKeyAttributeName { get; }
        public SteelGradeComparisonPolicy ComparisonPolicy { get; }
        public DesignOrderFormProfile FormProfile { get; }
        public IReadOnlyList<string> ComponentExclusionPatterns { get; }
    }
}
