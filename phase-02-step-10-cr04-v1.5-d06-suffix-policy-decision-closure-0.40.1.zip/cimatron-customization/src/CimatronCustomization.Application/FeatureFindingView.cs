using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>Presentation-safe projection of a Domain finding for Plugin/UI consumers.</summary>
    public sealed class FeatureFindingView
    {
        private readonly string[] entityReferenceValues;
        private readonly FeatureFindingComponentContextView[] componentContexts;

        internal FeatureFindingView(Finding finding)
        {
            if (finding == null) throw new ArgumentNullException(nameof(finding));

            RequirementId = finding.RequirementId;
            StatusText = finding.Status.ToString();
            Message = finding.Message;
            MeasuredValueText = FormatMeasurement(finding.MeasuredValue);
            LimitText = FormatMeasurement(finding.Limit);

            List<string> referenceValues = new List<string>();
            foreach (ModelEntityReference reference in finding.EntityReferences)
            {
                if (reference != null)
                {
                    referenceValues.Add(reference.Value);
                }
            }
            entityReferenceValues = referenceValues.ToArray();

            List<FeatureFindingComponentContextView> contextViews = new List<FeatureFindingComponentContextView>();
            foreach (FindingComponentContext context in finding.ComponentContexts)
            {
                contextViews.Add(new FeatureFindingComponentContextView(context));
            }
            componentContexts = contextViews.ToArray();
        }

        public string RequirementId { get; }
        public string StatusText { get; }
        public string Message { get; }
        public string MeasuredValueText { get; }
        public string LimitText { get; }
        public string[] EntityReferenceValues => (string[])entityReferenceValues.Clone();
        public FeatureFindingComponentContextView[] ComponentContexts => (FeatureFindingComponentContextView[])componentContexts.Clone();

        private static string FormatMeasurement(Measurement measurement)
        {
            return measurement == null
                ? string.Empty
                : measurement.Value.ToString(System.Globalization.CultureInfo.InvariantCulture) + " " + measurement.Unit;
        }
    }

    public sealed class FeatureFindingComponentContextView
    {
        internal FeatureFindingComponentContextView(FindingComponentContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            ComponentTitle = context.ComponentTitle;
            OccurrencePath = context.OccurrencePath;
            InstanceId = context.InstanceId;
            OccurrenceOrder = context.OccurrenceOrder;
            PartType = context.PartType;
            PartMaterial = context.PartMaterial;
        }

        public string ComponentTitle { get; }
        public string OccurrencePath { get; }
        public int InstanceId { get; }
        public int OccurrenceOrder { get; }
        public string PartType { get; }
        public string PartMaterial { get; }
    }
}
