using System;

namespace CimatronCustomization.Application
{
    public sealed class DesignOrderFormCategoryDefinition
    {
        public DesignOrderFormCategoryDefinition(
            string categoryKey,
            string productionLabel,
            int sourceRowNumber,
            int labelColumnIndex,
            int gradeColumnIndex,
            string vocabularyColumnName,
            int vocabularyStartRow,
            int vocabularyEndRow)
            : this(
                categoryKey,
                productionLabel,
                categoryKey,
                sourceRowNumber,
                labelColumnIndex,
                gradeColumnIndex,
                vocabularyColumnName,
                vocabularyStartRow,
                vocabularyEndRow)
        {
        }

        public DesignOrderFormCategoryDefinition(
            string categoryKey,
            string productionLabel,
            string partType,
            int sourceRowNumber,
            int labelColumnIndex,
            int remarkColumnIndex,
            string vocabularyColumnName,
            int vocabularyStartRow,
            int vocabularyEndRow)
        {
            if (string.IsNullOrWhiteSpace(categoryKey)) throw new ArgumentException("A category key is required.", nameof(categoryKey));
            if (string.IsNullOrWhiteSpace(productionLabel)) throw new ArgumentException("A production label is required.", nameof(productionLabel));
            if (string.IsNullOrWhiteSpace(partType)) throw new ArgumentException("A Cimatron Part Type is required.", nameof(partType));
            if (sourceRowNumber < 1) throw new ArgumentOutOfRangeException(nameof(sourceRowNumber));
            if (labelColumnIndex < 0) throw new ArgumentOutOfRangeException(nameof(labelColumnIndex));
            if (remarkColumnIndex < 0) throw new ArgumentOutOfRangeException(nameof(remarkColumnIndex));
            if (string.IsNullOrWhiteSpace(vocabularyColumnName)) throw new ArgumentException("A vocabulary column is required.", nameof(vocabularyColumnName));
            if (vocabularyStartRow < 1) throw new ArgumentOutOfRangeException(nameof(vocabularyStartRow));
            if (vocabularyEndRow < vocabularyStartRow) throw new ArgumentOutOfRangeException(nameof(vocabularyEndRow));

            CategoryKey = categoryKey.Trim();
            ProductionLabel = productionLabel;
            PartType = PartTypeCategoryResolver.NormalizeCategoryText(partType);
            SourceRowNumber = sourceRowNumber;
            LabelColumnIndex = labelColumnIndex;
            RemarkColumnIndex = remarkColumnIndex;
            VocabularyColumnName = vocabularyColumnName;
            VocabularyStartRow = vocabularyStartRow;
            VocabularyEndRow = vocabularyEndRow;
        }

        public string CategoryKey { get; }
        public string ProductionLabel { get; }
        public string PartType { get; }
        public int SourceRowNumber { get; }
        public int LabelColumnIndex { get; }
        public int RemarkColumnIndex { get; }
        public int GradeColumnIndex => RemarkColumnIndex;
        public string VocabularyColumnName { get; }
        public int VocabularyStartRow { get; }
        public int VocabularyEndRow { get; }
    }
}
