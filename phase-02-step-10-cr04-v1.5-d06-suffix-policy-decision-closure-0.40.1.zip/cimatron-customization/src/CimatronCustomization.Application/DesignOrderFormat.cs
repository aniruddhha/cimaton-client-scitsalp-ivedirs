namespace CimatronCustomization.Application
{
    public enum DesignOrderFormat
    {
        Table = 0,
        Form = 1
    }
}
