using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class BodyAttributeObservation
    {
        public BodyAttributeObservation(
            ModelEntityReference bodyReference,
            AttributeObservationStatus steelGradeStatus,
            string steelGradeValue,
            string steelGradeErrorMessage,
            AttributeObservationStatus componentKeyStatus,
            string componentKeyValue,
            string componentKeyErrorMessage)
        {
            BodyReference = bodyReference ?? throw new ArgumentNullException(nameof(bodyReference));
            ValidateStatus(steelGradeStatus, nameof(steelGradeStatus));
            ValidateStatus(componentKeyStatus, nameof(componentKeyStatus));
            ValidateErrorState(steelGradeStatus, steelGradeErrorMessage, nameof(steelGradeErrorMessage));
            ValidateErrorState(componentKeyStatus, componentKeyErrorMessage, nameof(componentKeyErrorMessage));

            SteelGradeStatus = steelGradeStatus;
            SteelGradeValue = steelGradeValue;
            SteelGradeErrorMessage = steelGradeErrorMessage ?? string.Empty;
            ComponentKeyStatus = componentKeyStatus;
            ComponentKeyValue = componentKeyValue;
            ComponentKeyErrorMessage = componentKeyErrorMessage ?? string.Empty;
        }

        public ModelEntityReference BodyReference { get; }
        public AttributeObservationStatus SteelGradeStatus { get; }
        public string SteelGradeValue { get; }
        public string SteelGradeErrorMessage { get; }
        public AttributeObservationStatus ComponentKeyStatus { get; }
        public string ComponentKeyValue { get; }
        public string ComponentKeyErrorMessage { get; }


        private static void ValidateStatus(AttributeObservationStatus status, string parameterName)
        {
            if (!Enum.IsDefined(typeof(AttributeObservationStatus), status))
                throw new ArgumentOutOfRangeException(parameterName);
        }

        private static void ValidateErrorState(
            AttributeObservationStatus status,
            string errorMessage,
            string parameterName)
        {
            if (status == AttributeObservationStatus.ReadError && string.IsNullOrWhiteSpace(errorMessage))
                throw new ArgumentException("A read-error observation requires an actionable error message.", parameterName);
        }
    }
}
