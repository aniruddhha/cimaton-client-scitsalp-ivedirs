using System;
using System.IO;
using System.Diagnostics.CodeAnalysis;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// CR-04 Slice 2 supports D-09(a) only. Assembly-title/folder tokens remain deferred until a
    /// read-only assembly-identity API route is separately verified.
    /// </summary>
    public sealed class DesignOrderInputPathResolver
    {
        [SuppressMessage("Performance", "CA1822:Mark members as static", Justification = "The resolver is an application service dependency and intentionally keeps an instance API for orchestration/testing.")]
        public string ResolveAbsolutePath(string configuredPath)
        {
            if (string.IsNullOrWhiteSpace(configuredPath))
                throw new ArgumentException("A Design-Order input path is required.", nameof(configuredPath));

            if (configuredPath.IndexOf('{') >= 0 || configuredPath.IndexOf('}') >= 0)
                throw new ArgumentException("Assembly path tokens are not supported by D-09(a).", nameof(configuredPath));

            if (configuredPath.IndexOfAny(Path.GetInvalidPathChars()) >= 0)
                throw new ArgumentException("The Design-Order input path contains invalid path characters.", nameof(configuredPath));

            if (!Path.IsPathRooted(configuredPath))
                throw new ArgumentException("The Design-Order input path must be absolute for D-09(a).", nameof(configuredPath));

            return configuredPath;
        }
    }
}
