using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class DesignOrderFormProfile
    {
        public DesignOrderFormProfile(
            string profileId,
            string worksheetName,
            int templateGuardRow,
            int templateGuardColumnIndex,
            string expectedNormalizedTemplateGuard,
            int mouldNumberRow,
            int mouldNumberColumnIndex,
            IEnumerable<DesignOrderFormCategoryDefinition> categories)
            : this(
                profileId,
                worksheetName,
                templateGuardRow,
                templateGuardColumnIndex,
                expectedNormalizedTemplateGuard,
                mouldNumberRow,
                mouldNumberColumnIndex,
                categories,
                Array.Empty<DesignOrderFormMaterialFamilyDefinition>())
        {
        }

        public DesignOrderFormProfile(
            string profileId,
            string worksheetName,
            int templateGuardRow,
            int templateGuardColumnIndex,
            string expectedNormalizedTemplateGuard,
            int mouldNumberRow,
            int mouldNumberColumnIndex,
            IEnumerable<DesignOrderFormCategoryDefinition> categories,
            IEnumerable<DesignOrderFormMaterialFamilyDefinition> materialFamilies)
        {
            if (string.IsNullOrWhiteSpace(profileId)) throw new ArgumentException("A Form profile id is required.", nameof(profileId));
            if (string.IsNullOrWhiteSpace(worksheetName)) throw new ArgumentException("A Form worksheet is required.", nameof(worksheetName));
            if (templateGuardRow < 1) throw new ArgumentOutOfRangeException(nameof(templateGuardRow));
            if (templateGuardColumnIndex < 0) throw new ArgumentOutOfRangeException(nameof(templateGuardColumnIndex));
            if (string.IsNullOrWhiteSpace(expectedNormalizedTemplateGuard)) throw new ArgumentException("An expected template guard is required.", nameof(expectedNormalizedTemplateGuard));
            if (mouldNumberRow < 1) throw new ArgumentOutOfRangeException(nameof(mouldNumberRow));
            if (mouldNumberColumnIndex < 0) throw new ArgumentOutOfRangeException(nameof(mouldNumberColumnIndex));
            if (categories == null) throw new ArgumentNullException(nameof(categories));
            if (materialFamilies == null) throw new ArgumentNullException(nameof(materialFamilies));

            DesignOrderFormCategoryDefinition[] categoryArray = categories.ToArray();
            if (categoryArray.Length == 0) throw new ArgumentException("At least one Form category is required.", nameof(categories));
            if (categoryArray.Any(category => category == null)) throw new ArgumentException("Form categories cannot contain null entries.", nameof(categories));

            DesignOrderFormMaterialFamilyDefinition[] familyArray = materialFamilies.ToArray();
            if (familyArray.Any(family => family == null)) throw new ArgumentException("Material families cannot contain null entries.", nameof(materialFamilies));
            if (familyArray.GroupBy(family => family.FamilyName, StringComparer.OrdinalIgnoreCase).Any(group => group.Count() > 1))
                throw new ArgumentException("Material-family names must be unique after case-insensitive normalization.", nameof(materialFamilies));
            if (familyArray.GroupBy(family => family.ColumnIndex).Any(group => group.Count() > 1))
                throw new ArgumentException("Material-family columns must be unique.", nameof(materialFamilies));
            if (categoryArray.GroupBy(category => PartTypeCategoryResolver.NormalizeCategoryText(category.PartType), StringComparer.OrdinalIgnoreCase).Any(group => group.Count() > 1))
                throw new ArgumentException("Part Type mappings must be unique after whitespace and case normalization.", nameof(categories));

            ProfileId = profileId;
            WorksheetName = worksheetName;
            TemplateGuardRow = templateGuardRow;
            TemplateGuardColumnIndex = templateGuardColumnIndex;
            ExpectedNormalizedTemplateGuard = expectedNormalizedTemplateGuard;
            MouldNumberRow = mouldNumberRow;
            MouldNumberColumnIndex = mouldNumberColumnIndex;
            Categories = Array.AsReadOnly(categoryArray);
            MaterialFamilies = Array.AsReadOnly(familyArray);
        }

        public string ProfileId { get; }
        public string WorksheetName { get; }
        public int TemplateGuardRow { get; }
        public int TemplateGuardColumnIndex { get; }
        public string ExpectedNormalizedTemplateGuard { get; }
        public int MouldNumberRow { get; }
        public int MouldNumberColumnIndex { get; }
        public IReadOnlyList<DesignOrderFormCategoryDefinition> Categories { get; }
        public IReadOnlyList<DesignOrderFormMaterialFamilyDefinition> MaterialFamilies { get; }
    }
}
