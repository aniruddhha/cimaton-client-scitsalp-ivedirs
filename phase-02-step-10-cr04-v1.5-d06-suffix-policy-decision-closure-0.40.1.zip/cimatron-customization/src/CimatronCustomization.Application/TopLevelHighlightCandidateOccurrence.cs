using System;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Pure occurrence input used to choose a D-15(a)-safe top-level highlight target.
    /// CR-04 Slice 2A traceability is recorded in feature metadata and governance records.
    /// </summary>
    public sealed class TopLevelHighlightCandidateOccurrence
    {
        public TopLevelHighlightCandidateOccurrence(int instanceId, int depth, string modelTitle, bool isSuppressed)
        {
            if (instanceId < 0) throw new ArgumentOutOfRangeException(nameof(instanceId));
            if (depth < 0) throw new ArgumentOutOfRangeException(nameof(depth));
            InstanceId = instanceId;
            Depth = depth;
            ModelTitle = modelTitle ?? string.Empty;
            IsSuppressed = isSuppressed;
        }

        public int InstanceId { get; }
        public int Depth { get; }
        public string ModelTitle { get; }
        public bool IsSuppressed { get; }
    }
}
