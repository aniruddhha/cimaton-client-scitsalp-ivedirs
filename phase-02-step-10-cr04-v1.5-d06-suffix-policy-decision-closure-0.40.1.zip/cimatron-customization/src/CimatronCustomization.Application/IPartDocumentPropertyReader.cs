namespace CimatronCustomization.Application
{
    public interface IPartDocumentPropertyReader
    {
        PartDocumentPropertyResult Read(string modelPid);
    }
}
