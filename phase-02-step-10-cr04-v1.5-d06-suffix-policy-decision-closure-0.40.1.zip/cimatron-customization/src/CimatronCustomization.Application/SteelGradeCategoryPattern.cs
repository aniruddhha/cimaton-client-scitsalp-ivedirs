using System;

namespace CimatronCustomization.Application
{
    public sealed class SteelGradeCategoryPattern
    {
        public SteelGradeCategoryPattern(string categoryKey, string modelTitlePattern)
        {
            if (string.IsNullOrWhiteSpace(categoryKey))
                throw new ArgumentException("A category key is required.", nameof(categoryKey));
            if (string.IsNullOrWhiteSpace(modelTitlePattern))
                throw new ArgumentException("A ModelTitle pattern is required.", nameof(modelTitlePattern));

            CategoryKey = categoryKey;
            ModelTitlePattern = modelTitlePattern;
        }

        public string CategoryKey { get; }
        public string ModelTitlePattern { get; }
    }
}
