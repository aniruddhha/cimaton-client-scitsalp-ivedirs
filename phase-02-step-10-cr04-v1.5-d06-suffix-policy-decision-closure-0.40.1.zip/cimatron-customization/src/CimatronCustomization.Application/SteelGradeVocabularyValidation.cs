using System;
using System.Collections.Generic;
using System.Linq;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public static class SteelGradeVocabularyValidation
    {
        public static bool IsKnownDesignOrderValue(
            string value,
            IEnumerable<string> permittedGrades,
            SteelGradeComparisonPolicy policy)
        {
            return IsKnown(value, permittedGrades, policy, true);
        }

        public static bool IsKnownCadValue(
            string value,
            IEnumerable<string> permittedGrades,
            SteelGradeComparisonPolicy policy)
        {
            return IsKnown(value, permittedGrades, policy, false);
        }

        private static bool IsKnown(
            string value,
            IEnumerable<string> permittedGrades,
            SteelGradeComparisonPolicy policy,
            bool designOrder)
        {
            if (permittedGrades == null)
                throw new ArgumentNullException(nameof(permittedGrades));
            if (policy == null)
                throw new ArgumentNullException(nameof(policy));

            SteelGradeNormalizationResult candidate = designOrder
                ? SteelGradeNormalizer.NormalizeDesignOrder(value, policy)
                : SteelGradeNormalizer.NormalizeCad(value, policy);
            if (candidate.IsAbsent || candidate.IsAmbiguousNumeric || candidate.Grade == null)
                return false;

            foreach (string permitted in permittedGrades.Where(item => !string.IsNullOrWhiteSpace(item)))
            {
                SteelGradeNormalizationResult normalizedPermitted = SteelGradeNormalizer.NormalizeCad(permitted, policy);
                if (!normalizedPermitted.IsAbsent &&
                    normalizedPermitted.Grade != null &&
                    candidate.Grade.EqualsGrade(normalizedPermitted.Grade))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
