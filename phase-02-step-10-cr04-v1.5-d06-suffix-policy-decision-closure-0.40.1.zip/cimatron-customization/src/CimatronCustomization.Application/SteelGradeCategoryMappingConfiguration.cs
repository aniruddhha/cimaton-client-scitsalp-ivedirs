using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class SteelGradeCategoryMappingConfiguration
    {
        private readonly SteelGradeCategoryPattern[] patterns;
        private readonly string[] excludedModelTitlePatterns;

        public SteelGradeCategoryMappingConfiguration(
            string categoryAttributeName,
            IEnumerable<SteelGradeCategoryPattern> patterns,
            IEnumerable<string> excludedModelTitlePatterns)
        {
            if (patterns == null)
                throw new ArgumentNullException(nameof(patterns));
            if (excludedModelTitlePatterns == null)
                throw new ArgumentNullException(nameof(excludedModelTitlePatterns));

            this.patterns = patterns.ToArray();
            if (this.patterns.Any(pattern => pattern == null))
                throw new ArgumentException("Category patterns cannot contain null entries.", nameof(patterns));

            this.excludedModelTitlePatterns = excludedModelTitlePatterns.ToArray();
            if (this.excludedModelTitlePatterns.Any(string.IsNullOrWhiteSpace))
                throw new ArgumentException("Exclusion patterns cannot contain blank entries.", nameof(excludedModelTitlePatterns));

            CategoryAttributeName = string.IsNullOrWhiteSpace(categoryAttributeName)
                ? null
                : categoryAttributeName;
        }

        public string CategoryAttributeName { get; }
        public IReadOnlyList<SteelGradeCategoryPattern> Patterns => patterns;
        public IReadOnlyList<string> ExcludedModelTitlePatterns => excludedModelTitlePatterns;
    }
}
