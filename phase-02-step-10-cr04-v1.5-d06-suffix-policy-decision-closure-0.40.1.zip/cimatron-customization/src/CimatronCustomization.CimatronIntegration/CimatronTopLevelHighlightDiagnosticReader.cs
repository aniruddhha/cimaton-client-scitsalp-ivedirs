using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Read-only Cimatron 2026 adapter for the CR-04 Slice 2A top-level highlight diagnostic.
    /// </summary>
    public sealed class CimatronTopLevelHighlightDiagnosticReader : ITopLevelHighlightDiagnosticReader
    {
        private const string EntityReferencePrefix = "entity";

        public TopLevelHighlightDiagnosticResult Read(
            string expectedAssemblyTitle,
            string expectedModelTitle,
            string attributeName,
            string attributeValue,
            string expectedAttributeType)
        {
            if (string.IsNullOrWhiteSpace(expectedAssemblyTitle)) throw new ArgumentException("Expected assembly title is required.", nameof(expectedAssemblyTitle));
            if (string.IsNullOrWhiteSpace(expectedModelTitle)) throw new ArgumentException("Expected model title is required.", nameof(expectedModelTitle));
            if (string.IsNullOrWhiteSpace(attributeName)) throw new ArgumentException("Attribute name is required.", nameof(attributeName));
            if (attributeValue == null) throw new ArgumentNullException(nameof(attributeValue));
            if (string.IsNullOrWhiteSpace(expectedAttributeType)) throw new ArgumentException("Expected attribute type is required.", nameof(expectedAttributeType));

            try
            {
                interop.CimatronE.IApplication application = GetApplication();
                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                MutationSnapshot before = MutationSnapshot.Capture(document);

                if (document == null)
                    return Error("[TOPLEVEL_HIGHLIGHT_NO_ACTIVE_DOCUMENT] no active Cimatron document.");

                interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IAssemblyModel assembly = container == null ? null : container.Model as interop.CimMdlrAPI.IAssemblyModel;
                interop.CimMdlrAPI.IModel assemblyModel = assembly as interop.CimMdlrAPI.IModel;
                if (assembly == null || assemblyModel == null || !string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    return WithMutation(document, before, Error("[TOPLEVEL_HIGHLIGHT_WRONG_CONTEXT] active document is not an Assembly."));

                string observedAssemblyTitle = assemblyModel.Title ?? string.Empty;
                if (!string.Equals(observedAssemblyTitle, expectedAssemblyTitle, StringComparison.OrdinalIgnoreCase))
                    return WithMutation(document, before, Error("[TOPLEVEL_HIGHLIGHT_WRONG_MODEL] active Assembly title '" + observedAssemblyTitle + "' does not match the governed known-answer assembly."));

                List<OccurrenceObservation> observations = new List<OccurrenceObservation>();
                Traverse(assembly, observations, 0);
                TopLevelHighlightTargetSelection selection = TopLevelHighlightTargetSelector.Select(
                    observations.Select(o => new TopLevelHighlightCandidateOccurrence(o.Instance.ID, o.Depth, o.ModelTitle, o.Instance.IsSuppressed != 0)).ToArray(),
                    expectedModelTitle);

                if (!selection.IsSelected)
                    return WithMutation(document, before, Error(selection.FailureMessage, selection));

                int selectedId = selection.SelectedInstanceId.Value;
                OccurrenceObservation selected = observations.Single(o => o.Instance.ID == selectedId);
                interop.CimMdlrAPI.ICimEntityList entities = selected.Instance.GetAllEntities();
                if (entities == null)
                    return WithMutation(document, before, Error("[TOPLEVEL_HIGHLIGHT_BODY_NOT_UNIQUE] selected occurrence returned no entity collection.", selection));

                List<interop.CimMdlrAPI.ICimEntity> matchingBodies = new List<interop.CimMdlrAPI.ICimEntity>();
                for (int index = 1; index <= entities.Count; index++)
                {
                    interop.CimMdlrAPI.ICimEntity entity = entities[index] as interop.CimMdlrAPI.ICimEntity;
                    if (entity == null || !string.Equals(entity.Type.ToString(), "cmBody", StringComparison.Ordinal))
                        continue;
                    interop.CimBaseAPI.IAttributeSink sink = entity as interop.CimBaseAPI.IAttributeSink;
                    if (sink == null)
                        continue;
                    interop.CimBaseAPI.IAttribute attribute = sink.GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttString, attributeName);
                    if (attribute == null)
                        continue;
                    if (!string.Equals(attribute.Type.ToString(), expectedAttributeType, StringComparison.Ordinal))
                        return WithMutation(document, before, Error("[TOPLEVEL_HIGHLIGHT_ATTRIBUTE_SHAPE_ERROR] known-answer attribute returned an unexpected type.", selection));
                    string value = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                    if (string.Equals(value, attributeValue, StringComparison.Ordinal))
                        matchingBodies.Add(entity);
                }

                if (matchingBodies.Count != 1)
                    return WithMutation(document, before, Error("[TOPLEVEL_HIGHLIGHT_BODY_NOT_UNIQUE] selected occurrence must contain exactly one body with the governed known-answer attribute value; matches=" + matchingBodies.Count.ToString(CultureInfo.InvariantCulture) + ".", selection));

                interop.CimMdlrAPI.IModel ownerModel = selected.Instance.Model as interop.CimMdlrAPI.IModel;
                if (ownerModel == null)
                    return WithMutation(document, before, Error("[TOPLEVEL_HIGHLIGHT_REFERENCE_ERROR] selected occurrence has no model for the current-session reference.", selection));

                ModelEntityReference reference = CreateEntityReference(selectedId, ownerModel.PID ?? string.Empty, matchingBodies[0].ID);
                TopLevelHighlightNoMutationState mutationState = GetMutationState(document, before);
                if (mutationState == TopLevelHighlightNoMutationState.Changed)
                {
                    return new TopLevelHighlightDiagnosticResult(
                        ResultStatus.Error,
                        "[TOPLEVEL_HIGHLIGHT_MUTATION_DETECTED] programmatic no-mutation evidence changed during diagnostic execution.",
                        selection.TotalOccurrenceCount,
                        selection.CandidateInstanceIds,
                        selection.RepeatedInstanceIds,
                        selectedId,
                        null,
                        TopLevelHighlightNoMutationState.Changed);
                }

                return new TopLevelHighlightDiagnosticResult(
                    ResultStatus.Passed,
                    "Top-level target resolved safely.",
                    selection.TotalOccurrenceCount,
                    selection.CandidateInstanceIds,
                    selection.RepeatedInstanceIds,
                    selectedId,
                    reference,
                    mutationState);
            }
            catch (Exception exception)
            {
                return new TopLevelHighlightDiagnosticResult(
                    ResultStatus.Error,
                    "[TOPLEVEL_HIGHLIGHT_API_ERROR] unexpected Cimatron API/runtime failure: " + exception.GetType().Name + ".",
                    0,
                    Array.Empty<int>(),
                    Array.Empty<int>(),
                    null,
                    null,
                    TopLevelHighlightNoMutationState.NotEvaluated);
            }
        }

        private static TopLevelHighlightDiagnosticResult WithMutation(interop.CimatronE.ICimDocument document, MutationSnapshot before, TopLevelHighlightDiagnosticResult result)
        {
            TopLevelHighlightNoMutationState mutationState = GetMutationState(document, before);
            if (mutationState == TopLevelHighlightNoMutationState.Changed)
            {
                return new TopLevelHighlightDiagnosticResult(
                    ResultStatus.Error,
                    "[TOPLEVEL_HIGHLIGHT_MUTATION_DETECTED] programmatic no-mutation evidence changed during diagnostic execution.",
                    result.TotalOccurrenceCount,
                    result.CandidateInstanceIds,
                    result.RepeatedInstanceIds,
                    result.SelectedInstanceId,
                    null,
                    TopLevelHighlightNoMutationState.Changed);
            }

            return new TopLevelHighlightDiagnosticResult(
                result.Status,
                result.Message,
                result.TotalOccurrenceCount,
                result.CandidateInstanceIds,
                result.RepeatedInstanceIds,
                result.SelectedInstanceId,
                result.Reference,
                mutationState);
        }

        private static TopLevelHighlightNoMutationState GetMutationState(interop.CimatronE.ICimDocument document, MutationSnapshot before)
        {
            return before.IsEquivalentTo(MutationSnapshot.Capture(document))
                ? TopLevelHighlightNoMutationState.Unchanged
                : TopLevelHighlightNoMutationState.Changed;
        }

        private static TopLevelHighlightDiagnosticResult Error(string message, TopLevelHighlightTargetSelection selection = null)
        {
            return new TopLevelHighlightDiagnosticResult(
                ResultStatus.Error,
                message,
                selection == null ? 0 : selection.TotalOccurrenceCount,
                selection == null ? Array.Empty<int>() : selection.CandidateInstanceIds,
                selection == null ? Array.Empty<int>() : selection.RepeatedInstanceIds,
                selection == null ? (int?)null : selection.SelectedInstanceId,
                null,
                TopLevelHighlightNoMutationState.NotEvaluated);
        }

        private static void Traverse(interop.CimMdlrAPI.IAssemblyModel assembly, ICollection<OccurrenceObservation> output, int depth)
        {
            if (depth > 16) throw new InvalidOperationException("Assembly traversal depth exceeded 16.");
            object[] rawInstances = assembly.GetInstances();
            if (rawInstances == null) return;
            foreach (object raw in rawInstances)
            {
                interop.CimMdlrAPI.IAssInstance instance = raw as interop.CimMdlrAPI.IAssInstance;
                if (instance == null) continue;
                output.Add(new OccurrenceObservation(instance, depth));
                object[] subInstances = instance.get_SubInstances(1, 0) as object[];
                if (subInstances != null && subInstances.Length > 0 && instance.Model != null &&
                    string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    Traverse((interop.CimMdlrAPI.IAssemblyModel)instance.Model, output, depth + 1);
                }
            }
        }

        private static ModelEntityReference CreateEntityReference(int instanceId, string modelPid, int entityId)
        {
            string encodedPid = Convert.ToBase64String(Encoding.UTF8.GetBytes(modelPid ?? string.Empty));
            return new ModelEntityReference(EntityReferencePrefix + "|" + instanceId.ToString(CultureInfo.InvariantCulture) + "|" + encodedPid + "|" + entityId.ToString(CultureInfo.InvariantCulture));
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null) throw new InvalidOperationException("Cimatron application is not available.");
            return application;
        }

        private sealed class OccurrenceObservation
        {
            internal OccurrenceObservation(interop.CimMdlrAPI.IAssInstance instance, int depth)
            {
                Instance = instance ?? throw new ArgumentNullException(nameof(instance));
                Depth = depth;
                ModelTitle = instance.Model == null ? string.Empty : instance.Model.Title ?? string.Empty;
            }

            internal interop.CimMdlrAPI.IAssInstance Instance { get; }
            internal int Depth { get; }
            internal string ModelTitle { get; }
        }

        private sealed class MutationSnapshot
        {
            private MutationSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path ?? string.Empty;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            internal string Path { get; }
            internal bool Modified { get; }
            internal DateTime? LastWriteUtc { get; }
            internal long? Length { get; }

            internal static MutationSnapshot Capture(interop.CimatronE.ICimDocument document)
            {
                string path = document == null ? string.Empty : document.GetPath() ?? string.Empty;
                bool modified = document != null && document.IsModified();
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo info = new FileInfo(path);
                    lastWriteUtc = info.LastWriteTimeUtc;
                    length = info.Length;
                }

                return new MutationSnapshot(path, modified, lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(MutationSnapshot other)
            {
                return other != null &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }
    }
}
