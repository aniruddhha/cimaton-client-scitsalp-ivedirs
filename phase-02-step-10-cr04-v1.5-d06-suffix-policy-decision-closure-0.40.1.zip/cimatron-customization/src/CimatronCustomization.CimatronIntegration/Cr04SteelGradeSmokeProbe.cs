using System;
using System.Collections.Generic;
using System.Globalization;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Developer-only CR-04 positive-conformance smoke boundary. Calls the production
    /// body-attribute reader and exposes primitive known-answer evidence to the Plugin.
    /// </summary>
    public sealed class Cr04SteelGradeSmokeProbe
    {
        private const string TargetModelTitle = "KA-PART-1-CR04-WRONG-TYPE";
        private const int TargetBodyEntityId = 4;
        private const string ExpectedValue = "P-20-2311";

        private readonly CimatronAssemblyBodyAttributeReader reader = new CimatronAssemblyBodyAttributeReader();

        public Cr04SteelGradeSmokeProbeResult Read()
        {
            AssemblyBodyAttributeSnapshot snapshot = reader.ReadNamedAttributes("STEEL_GRADE", null);
            if (!snapshot.IsSuccess)
                return Cr04SteelGradeSmokeProbeResult.Failure("Production adapter traversal returned ReadError: " + snapshot.ErrorMessage);

            List<string> bodyEvidence = new List<string>();
            List<BodyAttributeObservation> targetBodies = new List<BodyAttributeObservation>();
            int targetOccurrenceCount = 0;
            int totalBodyCount = 0;
            int readErrorCount = 0;

            foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences)
            {
                bool targetOccurrence = string.Equals(occurrence.ModelTitle, TargetModelTitle, StringComparison.Ordinal);
                if (targetOccurrence)
                    targetOccurrenceCount++;

                foreach (BodyAttributeObservation body in occurrence.Bodies)
                {
                    totalBodyCount++;
                    int entityId = ParseEntityId(body);
                    if (body.SteelGradeStatus == AttributeObservationStatus.ReadError)
                        readErrorCount++;

                    bodyEvidence.Add(
                        "BodyObservation=" + occurrence.OccurrencePath +
                        ";InstanceId=" + occurrence.InstanceId.ToString(CultureInfo.InvariantCulture) +
                        ";ModelTitle=" + occurrence.ModelTitle +
                        ";EntityId=" + entityId.ToString(CultureInfo.InvariantCulture) +
                        ";Status=" + body.SteelGradeStatus.ToString() +
                        ";Value=" + (body.SteelGradeValue ?? string.Empty) +
                        ";Error=" + (body.SteelGradeErrorMessage ?? string.Empty));

                    if (targetOccurrence && entityId == TargetBodyEntityId)
                        targetBodies.Add(body);
                }
            }

            if (targetOccurrenceCount != 1)
                return Cr04SteelGradeSmokeProbeResult.FailureWithEvidence("Expected exactly one controlled Part occurrence but found " + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture) + ".", targetOccurrenceCount, targetBodies.Count, totalBodyCount, readErrorCount, bodyEvidence);

            if (targetBodies.Count != 1)
                return Cr04SteelGradeSmokeProbeResult.FailureWithEvidence("Expected exactly one body entity 4 observation on the controlled Part occurrence but found " + targetBodies.Count.ToString(CultureInfo.InvariantCulture) + ".", targetOccurrenceCount, targetBodies.Count, totalBodyCount, readErrorCount, bodyEvidence);

            BodyAttributeObservation target = targetBodies[0];
            if (target.SteelGradeStatus != AttributeObservationStatus.Present)
                return Cr04SteelGradeSmokeProbeResult.FailureWithEvidence("Controlled body entity 4 did not return Present for the exact string lookup.", targetOccurrenceCount, targetBodies.Count, totalBodyCount, readErrorCount, bodyEvidence);

            if (!string.Equals(target.SteelGradeValue, ExpectedValue, StringComparison.Ordinal))
                return Cr04SteelGradeSmokeProbeResult.FailureWithEvidence("Controlled body entity 4 returned an unexpected steel-grade value.", targetOccurrenceCount, targetBodies.Count, totalBodyCount, readErrorCount, bodyEvidence);

            if (readErrorCount != 0)
                return Cr04SteelGradeSmokeProbeResult.FailureWithEvidence("At least one body observation returned ReadError during the controlled production-reader smoke.", targetOccurrenceCount, targetBodies.Count, totalBodyCount, readErrorCount, bodyEvidence);

            return Cr04SteelGradeSmokeProbeResult.Success(targetOccurrenceCount, targetBodies.Count, totalBodyCount, readErrorCount, bodyEvidence);
        }

        private static int ParseEntityId(BodyAttributeObservation body)
        {
            if (body == null || body.BodyReference == null || string.IsNullOrWhiteSpace(body.BodyReference.Value))
                return -1;

            int separator = body.BodyReference.Value.LastIndexOf('|');
            int entityId;
            return separator >= 0 && int.TryParse(body.BodyReference.Value.Substring(separator + 1), NumberStyles.Integer, CultureInfo.InvariantCulture, out entityId)
                ? entityId
                : -1;
        }
    }

    public sealed class Cr04SteelGradeSmokeProbeResult
    {
        private Cr04SteelGradeSmokeProbeResult(
            bool isSuccess,
            string errorMessage,
            int targetOccurrenceCount,
            int targetBodyObservationCount,
            int totalBodyObservationCount,
            int readErrorCount,
            IReadOnlyList<string> bodyEvidence)
        {
            IsSuccess = isSuccess;
            ErrorMessage = errorMessage ?? string.Empty;
            TargetOccurrenceCount = targetOccurrenceCount;
            TargetBodyObservationCount = targetBodyObservationCount;
            TotalBodyObservationCount = totalBodyObservationCount;
            ReadErrorCount = readErrorCount;
            BodyEvidence = bodyEvidence ?? Array.Empty<string>();
        }

        public bool IsSuccess { get; }
        public string ErrorMessage { get; }
        public int TargetOccurrenceCount { get; }
        public int TargetBodyObservationCount { get; }
        public int TotalBodyObservationCount { get; }
        public int ReadErrorCount { get; }
        public IReadOnlyList<string> BodyEvidence { get; }

        internal static Cr04SteelGradeSmokeProbeResult Success(int targetOccurrenceCount, int targetBodyObservationCount, int totalBodyObservationCount, int readErrorCount, IReadOnlyList<string> bodyEvidence)
        {
            return new Cr04SteelGradeSmokeProbeResult(true, string.Empty, targetOccurrenceCount, targetBodyObservationCount, totalBodyObservationCount, readErrorCount, bodyEvidence);
        }

        internal static Cr04SteelGradeSmokeProbeResult Failure(string errorMessage)
        {
            return new Cr04SteelGradeSmokeProbeResult(false, errorMessage, 0, 0, 0, 0, Array.Empty<string>());
        }

        internal static Cr04SteelGradeSmokeProbeResult FailureWithEvidence(string errorMessage, int targetOccurrenceCount, int targetBodyObservationCount, int totalBodyObservationCount, int readErrorCount, IReadOnlyList<string> bodyEvidence)
        {
            return new Cr04SteelGradeSmokeProbeResult(false, errorMessage, targetOccurrenceCount, targetBodyObservationCount, totalBodyObservationCount, readErrorCount, bodyEvidence);
        }
    }
}
