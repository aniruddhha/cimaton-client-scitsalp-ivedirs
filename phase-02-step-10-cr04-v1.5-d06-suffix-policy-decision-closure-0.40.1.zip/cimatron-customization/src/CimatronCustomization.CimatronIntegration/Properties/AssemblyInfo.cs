using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("CimatronCustomization.CimatronIntegration")]
[assembly: AssemblyDescription("Cimatron Customization hexagonal architecture foundation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("7fd54a77-5732-409e-8d58-a6eabe6d7081")]
[assembly: InternalsVisibleTo("CimatronCustomization.CimatronIntegrationTests")]
[assembly: AssemblyVersion("0.39.7.0")]
[assembly: AssemblyFileVersion("0.39.7.0")]
