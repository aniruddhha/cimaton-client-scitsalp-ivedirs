using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// CR-04 read-only adapter for Cimatron native Part Material. It reuses the in-process verified
    /// IAssemblyModel.GetBomManager()/IBOM.Export(cmNoFiltering) route and reads Standard Number +
    /// Material from the temporary BOM CSV. The active model is never saved or modified.
    /// </summary>
    public sealed class CimatronBomMaterialTableReader : IBomMaterialTableReader
    {
        private readonly ITabularDataReader tabularDataReader;

        public CimatronBomMaterialTableReader(ITabularDataReader tabularDataReader)
        {
            this.tabularDataReader = tabularDataReader ?? throw new ArgumentNullException(nameof(tabularDataReader));
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "The CAD-port boundary converts unexpected Cimatron/runtime failures into a controlled read-error result.")]
        public BomMaterialTableResult ReadMaterialTable()
        {
            string runDirectory = string.Empty;
            try
            {
                interop.CimatronE.IApplication application = GetApplication();
                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                if (document == null)
                    return BomMaterialTableResult.ReadError("No active Cimatron document is available.");
                if (!string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    return BomMaterialTableResult.ReadError("CR-04 Part Material reading requires an active Assembly document.");

                interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IAssemblyModel assembly = container == null
                    ? null
                    : container.Model as interop.CimMdlrAPI.IAssemblyModel;
                if (assembly == null)
                    return BomMaterialTableResult.ReadError("The active Assembly does not expose IAssemblyModel through IModelContainer.");

                interop.CimMdlrAPI.IBOM bom;
                try
                {
                    bom = assembly.GetBomManager();
                }
                catch (COMException exception)
                {
                    return BomMaterialTableResult.ReadError(ReadError("GetBomManager", exception));
                }

                if (bom == null)
                    return BomMaterialTableResult.ReadError("READ_ERROR GetBomManager returned no BOM manager.");

                runDirectory = CreateRunDirectory();
                string stem = Path.Combine(runDirectory, "cr04-part-material");
                try
                {
                    bom.Export(
                        stem,
                        interop.CimMdlrAPI.BOMTemplateType.cmCSV,
                        (interop.CimMdlrAPI.BOMExportOptions)0,
                        string.Empty,
                        interop.CimMdlrAPI.BOMReportFormat.cmNotReq,
                        interop.CimMdlrAPI.ComponentsFilterOption.cmNoFiltering,
                        Array.Empty<string>());
                }
                catch (COMException exception)
                {
                    return BomMaterialTableResult.ReadError(ReadError("IBOM.Export(cmNoFiltering)", exception));
                }

                string[] csvFiles = Directory.GetFiles(runDirectory, "cr04-part-material*.csv", SearchOption.TopDirectoryOnly);
                if (csvFiles.Length != 1)
                {
                    return BomMaterialTableResult.ReadError(
                        "READ_ERROR Expected exactly one cmNoFiltering BOM CSV; observed " +
                        csvFiles.Length.ToString(CultureInfo.InvariantCulture) + ".");
                }

                TabularSourceDefinition source = new TabularSourceDefinition(
                    csvFiles[0],
                    "CSV",
                    1,
                    new[]
                    {
                        new TabularColumnDefinition("ModelTitle", "Standard Number", TabularValueType.Text, true),
                        new TabularColumnDefinition("Material", "Material", TabularValueType.Text, false)
                    });

                TabularReadResult read = tabularDataReader.Read(source);
                if (!read.IsSuccess)
                {
                    return BomMaterialTableResult.ReadError(
                        "READ_ERROR " + read.ErrorCode + ": " + read.ErrorMessage);
                }

                List<BomMaterialRow> rows = new List<BomMaterialRow>();
                foreach (TabularRow row in read.Table.Rows)
                {
                    string modelTitle = row.GetRequired("ModelTitle").TextValue ?? string.Empty;
                    if (string.IsNullOrWhiteSpace(modelTitle))
                        continue;

                    string material = row.TryGetValue("Material", out TabularValue observedMaterial) && observedMaterial != null
                        ? observedMaterial.TextValue ?? string.Empty
                        : string.Empty;
                    rows.Add(new BomMaterialRow(modelTitle, material, row.SourceRowNumber));
                }

                return BomMaterialTableResult.Succeeded(rows);
            }
            catch (Exception)
            {
                return BomMaterialTableResult.ReadError(
                    "The active Cimatron assembly Part Material table could not be read through the verified BOM route.");
            }
            finally
            {
                DeleteRunDirectory(runDirectory);
            }
        }

        private static string ReadError(string operation, COMException exception)
        {
            return "READ_ERROR " + operation + " failed with HRESULT=0x" +
                exception.HResult.ToString("X8", CultureInfo.InvariantCulture) + ": " + exception.Message;
        }

        private static string CreateRunDirectory()
        {
            string root = Path.Combine(Path.GetTempPath(), "CimatronCustomization", "CR04PartMaterial");
            Directory.CreateDirectory(root);
            string timestamp = DateTime.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture);
            string run = Path.Combine(root, timestamp);
            int suffix = 1;
            while (Directory.Exists(run))
            {
                run = Path.Combine(root, timestamp + "-" + suffix.ToString(CultureInfo.InvariantCulture));
                suffix++;
            }
            Directory.CreateDirectory(run);
            return run;
        }

        private static void DeleteRunDirectory(string runDirectory)
        {
            if (string.IsNullOrWhiteSpace(runDirectory) || !Directory.Exists(runDirectory))
                return;

            string root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "CimatronCustomization", "CR04PartMaterial"))
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string candidate = Path.GetFullPath(runDirectory)
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!candidate.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("CR-04 Part Material cleanup refused to delete outside the governed temporary root.");

            Directory.Delete(runDirectory, true);
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
                throw new InvalidOperationException("Cimatron application is not available.");
            return application;
        }
    }
}
