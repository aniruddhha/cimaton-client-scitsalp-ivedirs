using System;
using System.Collections.Generic;
using System.Globalization;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    public sealed class CimatronPartDocumentPropertyReader : IPartDocumentPropertyReader
    {
        private const string PartTypeAttributeName = "TMPL::Part_Type";
        private const string PartMaterialAttributeName = "TMPL::Material";

        public PartDocumentPropertyResult Read(string modelPid)
        {
            if (string.IsNullOrWhiteSpace(modelPid))
                return PartDocumentPropertyResult.Error("CAD_PART_MODEL_PID_MISSING", "The assembly occurrence does not expose a Part ModelPid for native Part-property reading.");

            try
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application == null)
                    return PartDocumentPropertyResult.Error("CAD_APPLICATION_UNAVAILABLE", "Cimatron application is not available for native Part-property reading.");

                interop.CimatronE.IPdm pdm = application.GetPdm();
                if (pdm == null)
                    return PartDocumentPropertyResult.Error("CAD_PDM_UNAVAILABLE", "Cimatron PDM manager is not available through IApplication.GetPdm().");

                object rawAttributes = null;
                pdm.RetriveDocAttribute(modelPid, ref rawAttributes, string.Empty);
                Array attributes = rawAttributes as Array;
                if (attributes == null)
                    return PartDocumentPropertyResult.Error("CAD_PART_PROPERTY_CONTAINER_INVALID", "Cimatron did not return a document-attribute array for the requested Part.");

                List<string> partTypes = new List<string>();
                List<string> partMaterials = new List<string>();
                foreach (object rawAttribute in attributes)
                {
                    interop.CimBaseAPI.IDocAttribute attribute = rawAttribute as interop.CimBaseAPI.IDocAttribute;
                    if (attribute == null) continue;

                    string name = attribute.Name ?? string.Empty;
                    object value = attribute.Value;
                    string text = Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
                    if (string.Equals(name, PartTypeAttributeName, StringComparison.Ordinal)) partTypes.Add(text);
                    if (string.Equals(name, PartMaterialAttributeName, StringComparison.Ordinal)) partMaterials.Add(text);
                }

                if (HasConflictingValues(partTypes) || HasConflictingValues(partMaterials))
                    return PartDocumentPropertyResult.Error("CAD_PART_PROPERTY_AMBIGUOUS", "Cimatron returned more than one distinct value for a required native Part property.");

                return PartDocumentPropertyResult.Succeeded(FirstOrEmpty(partTypes), FirstOrEmpty(partMaterials));
            }
            catch (Exception exception)
            {
                return PartDocumentPropertyResult.Error("CAD_PART_PROPERTY_READ_ERROR", "Native Cimatron Part properties could not be read: " + exception.Message);
            }
        }

        private static bool HasConflictingValues(IEnumerable<string> values)
        {
            HashSet<string> distinct = new HashSet<string>(StringComparer.Ordinal);
            foreach (string value in values) distinct.Add(value ?? string.Empty);
            return distinct.Count > 1;
        }

        private static string FirstOrEmpty(IEnumerable<string> values)
        {
            foreach (string value in values) return value ?? string.Empty;
            return string.Empty;
        }
    }
}
