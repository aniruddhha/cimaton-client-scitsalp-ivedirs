using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Developer-only CR-04 Slice 3 smoke interpretation boundary. Keeps Domain-backed
    /// adapter observations inside CimatronIntegration and exposes only primitive evidence
    /// to the Plugin entry point.
    /// </summary>
    public sealed class Cr04WrongTypeSmokeProbe
    {
        private readonly CimatronAssemblyBodyAttributeReader _reader = new CimatronAssemblyBodyAttributeReader();

        public Cr04WrongTypeSmokeProbeResult Read(string targetModelTitle, string attributeName, int targetBodyEntityId)
        {
            if (string.IsNullOrWhiteSpace(targetModelTitle))
                throw new ArgumentException("Target model title is required.", nameof(targetModelTitle));
            if (string.IsNullOrWhiteSpace(attributeName))
                throw new ArgumentException("Attribute name is required.", nameof(attributeName));
            if (targetBodyEntityId <= 0)
                throw new ArgumentOutOfRangeException(nameof(targetBodyEntityId));

            AssemblyBodyAttributeSnapshot snapshot = _reader.ReadNamedAttributes(attributeName, null);
            if (!snapshot.IsSuccess)
                return Cr04WrongTypeSmokeProbeResult.Failure("Production adapter traversal returned ReadError: " + snapshot.ErrorMessage);

            AssemblyBodyAttributeOccurrence[] targetOccurrences = snapshot.Occurrences
                .Where(item => string.Equals(item.ModelTitle, targetModelTitle, StringComparison.Ordinal))
                .ToArray();
            if (targetOccurrences.Length == 0)
                return Cr04WrongTypeSmokeProbeResult.Failure("The approved wrong-type Part occurrence was not found in the active disposable Assembly.");

            string[] occurrenceEvidence = targetOccurrences
                .Select(occurrence =>
                    "TargetOccurrence=" + occurrence.OccurrencePath +
                    ";InstanceId=" + occurrence.InstanceId.ToString(CultureInfo.InvariantCulture) +
                    ";Suppressed=" + occurrence.IsEffectivelySuppressed.ToString())
                .ToArray();

            BodyAttributeObservation[] controlBodies = targetOccurrences
                .SelectMany(item => item.Bodies)
                .Where(body => HasEntityId(body, targetBodyEntityId))
                .ToArray();
            if (controlBodies.Length == 0)
                return Cr04WrongTypeSmokeProbeResult.Failure("Controlled body entity " + targetBodyEntityId.ToString(CultureInfo.InvariantCulture) + " was not found on the approved wrong-type Part occurrence.");

            int present = controlBodies.Count(body => body.SteelGradeStatus == AttributeObservationStatus.Present);
            int absent = controlBodies.Count(body => body.SteelGradeStatus == AttributeObservationStatus.Absent);
            int readError = controlBodies.Count(body => body.SteelGradeStatus == AttributeObservationStatus.ReadError);

            return Cr04WrongTypeSmokeProbeResult.Success(
                targetOccurrences.Length,
                controlBodies.Length,
                present,
                absent,
                readError,
                occurrenceEvidence);
        }

        private static bool HasEntityId(BodyAttributeObservation body, int entityId)
        {
            if (body == null || body.BodyReference == null || string.IsNullOrWhiteSpace(body.BodyReference.Value))
                return false;

            return body.BodyReference.Value.EndsWith(
                "|" + entityId.ToString(CultureInfo.InvariantCulture),
                StringComparison.Ordinal);
        }
    }

    public sealed class Cr04WrongTypeSmokeProbeResult
    {
        private Cr04WrongTypeSmokeProbeResult(
            bool isSuccess,
            string errorMessage,
            int targetOccurrenceCount,
            int bodyObservationCount,
            int present,
            int absent,
            int readError,
            IReadOnlyList<string> occurrenceEvidence)
        {
            IsSuccess = isSuccess;
            ErrorMessage = errorMessage ?? string.Empty;
            TargetOccurrenceCount = targetOccurrenceCount;
            BodyObservationCount = bodyObservationCount;
            Present = present;
            Absent = absent;
            ReadError = readError;
            OccurrenceEvidence = occurrenceEvidence ?? Array.Empty<string>();
        }

        public bool IsSuccess { get; }
        public string ErrorMessage { get; }
        public int TargetOccurrenceCount { get; }
        public int BodyObservationCount { get; }
        public int Present { get; }
        public int Absent { get; }
        public int ReadError { get; }
        public IReadOnlyList<string> OccurrenceEvidence { get; }

        internal static Cr04WrongTypeSmokeProbeResult Success(
            int targetOccurrenceCount,
            int bodyObservationCount,
            int present,
            int absent,
            int readError,
            IReadOnlyList<string> occurrenceEvidence)
        {
            return new Cr04WrongTypeSmokeProbeResult(
                true,
                string.Empty,
                targetOccurrenceCount,
                bodyObservationCount,
                present,
                absent,
                readError,
                occurrenceEvidence);
        }

        internal static Cr04WrongTypeSmokeProbeResult Failure(string errorMessage)
        {
            return new Cr04WrongTypeSmokeProbeResult(
                false,
                errorMessage,
                0,
                0,
                0,
                0,
                0,
                Array.Empty<string>());
        }
    }
}
