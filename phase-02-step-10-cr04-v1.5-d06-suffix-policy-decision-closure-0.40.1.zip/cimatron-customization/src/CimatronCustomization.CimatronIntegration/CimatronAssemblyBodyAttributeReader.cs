using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// CR-04 read-only adapter over the Cimatron 2026 occurrence/body attribute route proven by
    /// Step 08B and Slice 2A. IAssInstance.GetAllEntities() is installed-Interop/runtime evidence
    /// only; it is not present in the authoritative SDK documentation index used by this project.
    /// </summary>
    public sealed class CimatronAssemblyBodyAttributeReader : IAssemblyBodyAttributeReader
    {
        private const string EntityReferencePrefix = "entity";
        private const int MaximumTraversalDepth = 16;

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "This CAD-port boundary converts unexpected Cimatron/runtime failures into the approved fail-safe read-error snapshot.")]
        public AssemblyBodyAttributeSnapshot ReadNamedAttributes(
            string steelGradeAttributeName,
            string componentKeyAttributeName)
        {
            if (string.IsNullOrWhiteSpace(steelGradeAttributeName))
                throw new ArgumentException("A steel-grade attribute name is required.", nameof(steelGradeAttributeName));

            try
            {
                interop.CimatronE.IApplication application = GetApplication();
                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                if (document == null)
                    return AssemblyBodyAttributeSnapshot.ReadError("No active Cimatron document is available.");
                if (!string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    return AssemblyBodyAttributeSnapshot.ReadError("CR-04 body-attribute reading requires an active Assembly document.");

                interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IAssemblyModel assembly = container == null
                    ? null
                    : container.Model as interop.CimMdlrAPI.IAssemblyModel;
                if (assembly == null)
                    return AssemblyBodyAttributeSnapshot.ReadError("The active Assembly does not expose IAssemblyModel through IModelContainer.");

                List<AssemblyBodyAttributeOccurrence> occurrences = new List<AssemblyBodyAttributeOccurrence>();
                Traverse(
                    assembly,
                    occurrences,
                    0,
                    "root",
                    parentEffectivelySuppressed: false,
                    steelGradeAttributeName,
                    componentKeyAttributeName);

                return AssemblyBodyAttributeSnapshot.Succeeded(occurrences);
            }
            catch (Exception)
            {
                return AssemblyBodyAttributeSnapshot.ReadError(
                    "The active Cimatron assembly could not be read through the CR-04 body-attribute adapter.");
            }
        }

        private static void Traverse(
            interop.CimMdlrAPI.IAssemblyModel assembly,
            ICollection<AssemblyBodyAttributeOccurrence> output,
            int depth,
            string parentPath,
            bool parentEffectivelySuppressed,
            string steelGradeAttributeName,
            string componentKeyAttributeName)
        {
            if (assembly == null)
                throw new ArgumentNullException(nameof(assembly));
            if (output == null)
                throw new ArgumentNullException(nameof(output));
            if (depth > MaximumTraversalDepth)
                return;

            object[] rawInstances = assembly.GetInstances();
            if (rawInstances == null)
                return;

            foreach (object raw in rawInstances)
            {
                interop.CimMdlrAPI.IAssInstance instance = raw as interop.CimMdlrAPI.IAssInstance;
                if (instance == null)
                    continue;

                interop.CimMdlrAPI.IModel model = instance.Model as interop.CimMdlrAPI.IModel;
                if (model == null)
                    throw new InvalidOperationException("An assembly occurrence does not expose IModel.");
                if (string.IsNullOrWhiteSpace(model.Title))
                    throw new InvalidOperationException("An assembly occurrence returned an empty model title.");

                bool directlySuppressed = instance.IsSuppressed != 0;
                bool effectivelySuppressed = parentEffectivelySuppressed || directlySuppressed;
                string occurrencePath = parentPath + "/" + depth.ToString(CultureInfo.InvariantCulture) + ":" + instance.ID.ToString(CultureInfo.InvariantCulture);

                output.Add(new AssemblyBodyAttributeOccurrence(
                    occurrencePath,
                    instance.ID,
                    model.Title,
                    model.PID ?? string.Empty,
                    model.Type.ToString(),
                    directlySuppressed,
                    effectivelySuppressed,
                    ReadBodies(instance, model.PID ?? string.Empty, steelGradeAttributeName, componentKeyAttributeName)));

                object rawSubInstances = instance.get_SubInstances(1, 0);
                object[] subInstances = rawSubInstances as object[];
                if (subInstances != null && subInstances.Length > 0 && instance.Model != null &&
                    string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    Traverse(
                        (interop.CimMdlrAPI.IAssemblyModel)instance.Model,
                        output,
                        depth + 1,
                        occurrencePath,
                        effectivelySuppressed,
                        steelGradeAttributeName,
                        componentKeyAttributeName);
                }
            }
        }

        private static List<BodyAttributeObservation> ReadBodies(
            interop.CimMdlrAPI.IAssInstance instance,
            string modelPid,
            string steelGradeAttributeName,
            string componentKeyAttributeName)
        {
            interop.CimMdlrAPI.ICimEntityList entities = instance.GetAllEntities();
            if (entities == null)
                throw new InvalidOperationException("IAssInstance.GetAllEntities() returned null.");

            List<BodyAttributeObservation> bodies = new List<BodyAttributeObservation>();
            for (int index = 1; index <= entities.Count; index++)
            {
                interop.CimMdlrAPI.ICimEntity entity = entities[index] as interop.CimMdlrAPI.ICimEntity;
                if (entity == null || !string.Equals(entity.Type.ToString(), "cmBody", StringComparison.Ordinal))
                    continue;

                interop.CimBaseAPI.IAttributeSink sink = entity as interop.CimBaseAPI.IAttributeSink;
                AttributeRead steelGrade = ReadStringAttribute(sink, steelGradeAttributeName);
                AttributeRead componentKey = string.IsNullOrWhiteSpace(componentKeyAttributeName)
                    ? AttributeRead.Absent()
                    : ReadStringAttribute(sink, componentKeyAttributeName);

                bodies.Add(new BodyAttributeObservation(
                    CreateEntityReference(instance.ID, modelPid, entity.ID),
                    steelGrade.Status,
                    steelGrade.Value,
                    steelGrade.ErrorMessage,
                    componentKey.Status,
                    componentKey.Value,
                    componentKey.ErrorMessage));
            }

            return bodies;
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Wrong-type/unreadable Cimatron attribute behavior is intentionally converted to the approved fail-safe ReadError observation at this CAD-port boundary.")]
        private static AttributeRead ReadStringAttribute(
            interop.CimBaseAPI.IAttributeSink sink,
            string attributeName)
        {
            if (sink == null)
                return AttributeRead.ReadError("The occurrence body does not expose IAttributeSink.");

            try
            {
                interop.CimBaseAPI.IAttribute attribute = sink.GetAttribute(
                    interop.CimBaseAPI.AttributeEnumType.cmAttString,
                    attributeName);
                if (attribute == null)
                    return AttributeRead.Absent();

                if (!string.Equals(attribute.Type.ToString(), "cmAttString", StringComparison.Ordinal))
                    return AttributeRead.ReadError("The named attribute lookup returned an unexpected runtime type.");

                string value;
                try
                {
                    value = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                }
                catch (Exception)
                {
                    return AttributeRead.ReadError("The named string attribute value could not be converted to text.");
                }

                return AttributeRead.Present(value);
            }
            catch (Exception)
            {
                return AttributeRead.ReadError("The named string attribute could not be read through the verified Cimatron API route.");
            }
        }

        private static ModelEntityReference CreateEntityReference(int instanceId, string modelPid, int entityId)
        {
            string encodedPid = Convert.ToBase64String(Encoding.UTF8.GetBytes(modelPid ?? string.Empty));
            return new ModelEntityReference(
                EntityReferencePrefix + "|" +
                instanceId.ToString(CultureInfo.InvariantCulture) + "|" +
                encodedPid + "|" +
                entityId.ToString(CultureInfo.InvariantCulture));
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
                throw new InvalidOperationException("Cimatron application is not available.");
            return application;
        }

        private sealed class AttributeRead
        {
            private AttributeRead(AttributeObservationStatus status, string value, string errorMessage)
            {
                Status = status;
                Value = value;
                ErrorMessage = errorMessage;
            }

            internal AttributeObservationStatus Status { get; }
            internal string Value { get; }
            internal string ErrorMessage { get; }

            internal static AttributeRead Present(string value)
            {
                return new AttributeRead(AttributeObservationStatus.Present, value ?? string.Empty, string.Empty);
            }

            internal static AttributeRead Absent()
            {
                return new AttributeRead(AttributeObservationStatus.Absent, null, string.Empty);
            }

            internal static AttributeRead ReadError(string message)
            {
                return new AttributeRead(AttributeObservationStatus.ReadError, null, message);
            }
        }
    }
}
