using System.Collections.Generic;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;
using CimatronCustomization.DesignChecks;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Explicit composition root for registered features. No reflection or assembly scanning is used.
    /// </summary>
    internal static class FeatureComposition
    {
        internal static FeatureRegistry CreateRegistry()
        {
            IApplicationFeature readinessFeature = new ActivePartReadinessFeature(
                new CheckActivePartReadiness(new CimatronSessionAdapter()));
            IApplicationFeature ruleParameterProbe = new RuleParameterProbeFeature();

            CimatronModelInspectionAdapter modelInspectionAdapter = new CimatronModelInspectionAdapter();
            IApplicationFeature modelInspectionProbe = new ModelInspectionProbeFeature(
                modelInspectionAdapter,
                modelInspectionAdapter,
                modelInspectionAdapter,
                modelInspectionAdapter);
            IApplicationFeature u1InProcessConfirmation = new U1InProcessGeometryConfirmationFeature(
                new CimatronBodyGeometryMetricsReader());
            IApplicationFeature step08BInProcessConfirmation = new Step08BInProcessConfirmationFeature(
                new CimatronOccurrenceEntityAttributeReader(),
                new CimatronAssemblyEntityMapper(),
                new CimatronBomMaterialExporter(new ExcelTabularDataReader()));

            ExcelTabularDataReader cr04TabularReader = new ExcelTabularDataReader();
            DesignOrderFormProfile cr04FormProfile = SrideviQrDg02Rev04Profile.Create();
            VerifySteelGradeAgainstDesignOrder cr04UseCase = new VerifySteelGradeAgainstDesignOrder(
                new ReadMappedTabularData(cr04TabularReader, cr04TabularReader, new TabularMappingEngine()),
                new ExcelDesignOrderFormReader(),
                new CimatronAssemblyBodyAttributeReader(),
                new CimatronBomMaterialTableReader(cr04TabularReader),
                new CimatronPartDocumentPropertyReader(),
                new DesignOrderInputPathResolver());
            IApplicationFeature steelGradeDesignOrderValidation = new SteelGradeDesignOrderValidation(
                cr04UseCase,
                cr04FormProfile);

            List<IApplicationFeature> features = new List<IApplicationFeature>
            {
                readinessFeature,
                ruleParameterProbe,
                modelInspectionProbe,
                u1InProcessConfirmation,
                step08BInProcessConfirmation,
                steelGradeDesignOrderValidation
            };

            if (TopLevelHighlightDiagnosticRequest.TryConsume())
            {
                features.Add(new TopLevelHighlightDiagnosticFeature(new CimatronTopLevelHighlightDiagnosticReader()));
            }

            return new FeatureRegistry(features);
        }

        internal static IViewportEntityHighlighter CreateViewportEntityHighlighter()
        {
            return new CimatronViewportEntityHighlighter();
        }

        internal static IViewportEntityPicker CreateViewportEntityPicker(
            IApplicationLogger logger,
            string applicationVersion,
            string cimatronVersion)
        {
            return new CimatronViewportEntityPicker(logger, applicationVersion, cimatronVersion);
        }
    }
}
