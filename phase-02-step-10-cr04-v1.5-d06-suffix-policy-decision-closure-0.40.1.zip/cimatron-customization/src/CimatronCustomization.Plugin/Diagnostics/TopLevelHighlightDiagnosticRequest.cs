using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Consumes the one-shot developer request that enables the CR-04 Slice 2A top-level highlight diagnostic.
    /// </summary>
    internal static class TopLevelHighlightDiagnosticRequest
    {
        private const string RequestVersion = "0.26.4";
        private const string RequestFileName = "cr04-slice2a-toplevel-highlight-diagnostic.request";
        private static readonly TimeSpan MaximumRequestAge = TimeSpan.FromMinutes(30);

        internal static bool TryConsume()
        {
            string requestDirectory = Path.Combine(Path.GetTempPath(), "CimatronCustomization");
            string requestPath = Path.Combine(requestDirectory, RequestFileName);
            if (!File.Exists(requestPath))
                return false;

            string consumingPath = requestPath + ".consuming-" + Process.GetCurrentProcess().Id.ToString(CultureInfo.InvariantCulture);
            try
            {
                if (File.Exists(consumingPath)) File.Delete(consumingPath);
                File.Move(requestPath, consumingPath);
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                ShowNotRegisteredWarning("The diagnostic request could not be consumed: " + exception.Message);
                return false;
            }

            try
            {
                string version = null;
                string requestedUtc = null;
                foreach (string line in File.ReadAllLines(consumingPath))
                {
                    int separator = line.IndexOf('=');
                    if (separator <= 0) continue;
                    string key = line.Substring(0, separator).Trim();
                    string value = line.Substring(separator + 1).Trim();
                    if (string.Equals(key, "Version", StringComparison.Ordinal)) version = value;
                    else if (string.Equals(key, "RequestedUtc", StringComparison.Ordinal)) requestedUtc = value;
                }

                if (!string.Equals(version, RequestVersion, StringComparison.Ordinal))
                {
                    ShowNotRegisteredWarning("The request version is invalid.");
                    return false;
                }

                DateTimeOffset requested;
                if (!DateTimeOffset.TryParseExact(requestedUtc, "O", CultureInfo.InvariantCulture, DateTimeStyles.None, out requested))
                {
                    ShowNotRegisteredWarning("RequestedUtc is missing or invalid.");
                    return false;
                }

                TimeSpan age = DateTimeOffset.UtcNow - requested.ToUniversalTime();
                if (age < TimeSpan.Zero || age > MaximumRequestAge)
                {
                    ShowNotRegisteredWarning("The request is outside the 30-minute validity window.");
                    return false;
                }

                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                ShowNotRegisteredWarning("The diagnostic request could not be read: " + exception.Message);
                return false;
            }
            finally
            {
                try { if (File.Exists(consumingPath)) File.Delete(consumingPath); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        private static void ShowNotRegisteredWarning(string detail)
        {
            MessageBox.Show(
                detail + Environment.NewLine + "The diagnostic is NOT registered.",
                "Cimatron Customization — CR-04 Slice 2A Diagnostic",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }
}
