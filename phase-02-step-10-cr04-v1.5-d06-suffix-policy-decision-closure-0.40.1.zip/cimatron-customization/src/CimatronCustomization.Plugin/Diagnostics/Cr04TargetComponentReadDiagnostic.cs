using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Developer-only, one-shot, read-only CR-04 diagnostic. It reuses the production
    /// CimatronAssemblyBodyAttributeReader and the production category resolver against the
    /// deployed CR-04 mapping configuration. It never writes to the Cimatron model or workbook.
    /// </summary>
    internal static class Cr04TargetComponentReadDiagnostic
    {
        private const string SteelGradeAttributeName = "STEEL_GRADE";
        private const string FeatureId = "STEEL-GRADE-DESIGN-ORDER-VALIDATION";
        private const string CategoryPatternsParameter = "ComponentCategoryPatterns";
        private const string CategoryExclusionsParameter = "ComponentExclusionPatterns";
        private const string CategoryAttributeNameParameter = "ComponentCategoryAttributeName";
        private static readonly char[] ListSeparators = { ';' };

        internal static bool TryRunRequested(out bool commandResult)
        {
            Cr04TargetComponentReadDiagnosticRequest request;
            string requestError;
            if (!Cr04TargetComponentReadDiagnosticRequest.TryConsume(out request, out requestError))
            {
                commandResult = false;
                return false;
            }

            if (request == null)
            {
                commandResult = false;
                ShowResult("CR-04 target-component diagnostic request rejected.", requestError, MessageBoxIcon.Error);
                return true;
            }

            commandResult = Run(request);
            return true;
        }

        private static bool Run(Cr04TargetComponentReadDiagnosticRequest request)
        {
            StringBuilder evidence = new StringBuilder();
            evidence.AppendLine("CR-04 TARGET COMPONENT READ DIAGNOSTIC");
            evidence.AppendLine("TimestampUtc=" + DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            evidence.AppendLine("ExecutionContext=IN_PROCESS_PLUGIN");
            evidence.AppendLine("ReadOnlyDiagnostic=true");
            evidence.AppendLine("ProductionReader=CimatronAssemblyBodyAttributeReader");
            evidence.AppendLine("SteelGradeAttributeName=" + SteelGradeAttributeName);
            evidence.AppendLine("BodyEntityIdSource=UNAVAILABLE_AT_PLUGIN_BOUNDARY");

            string result = "ERROR";
            string detail = string.Empty;
            int occurrenceCount = 0;
            int bodyCount = 0;

            try
            {
                string configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CimatronCustomization.config.xml");
                SteelGradeCategoryMappingConfiguration categoryConfiguration = LoadCategoryConfiguration(configPath);
                string[] categoryKeys = SrideviQrDg02Rev04Profile.Create().Categories
                    .Select(category => category.CategoryKey)
                    .ToArray();

                CimatronAssemblyBodyAttributeReader reader = new CimatronAssemblyBodyAttributeReader();
                AssemblyBodyAttributeSnapshot snapshot = reader.ReadNamedAttributes(
                    SteelGradeAttributeName,
                    categoryConfiguration.CategoryAttributeName);

                if (!snapshot.IsSuccess)
                    throw new InvalidOperationException(snapshot.ErrorMessage);

                evidence.AppendLine("OccurrencePath|InstanceId|ModelTitle|ModelPID|BodyEntityId|STEEL_GRADE status|STEEL_GRADE value|Category resolution");
                foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences)
                {
                    occurrenceCount++;
                    SteelGradeCategoryResolution resolution = SteelGradeCategoryResolver.Resolve(
                        occurrence,
                        categoryConfiguration,
                        categoryKeys);
                    string categoryText = resolution.Kind == SteelGradeCategoryResolutionKind.Mapped
                        ? "Mapped:" + resolution.CategoryKey
                        : resolution.Kind + ":" + resolution.Detail;

                    if (occurrence.Bodies.Count == 0)
                    {
                        evidence.AppendLine(JoinFields(
                            occurrence.OccurrencePath,
                            occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                            occurrence.ModelTitle,
                            occurrence.ModelPid,
                            string.Empty,
                            "NO_BODY",
                            string.Empty,
                            categoryText));
                        continue;
                    }

                    foreach (BodyAttributeObservation body in occurrence.Bodies)
                    {
                        bodyCount++;
                        evidence.AppendLine(JoinFields(
                            occurrence.OccurrencePath,
                            occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                            occurrence.ModelTitle,
                            occurrence.ModelPid,
                            "UNAVAILABLE_AT_PLUGIN_BOUNDARY",
                            body.SteelGradeStatus.ToString(),
                            body.SteelGradeValue ?? string.Empty,
                            categoryText));
                    }
                }

                result = "READ_ONLY_DIAGNOSTIC_COMPLETED";
                detail = "Production CR-04 traversal, STEEL_GRADE observation, and category resolution were captured without model mutation.";
            }
            catch (Exception exception)
            {
                result = "READ_ONLY_DIAGNOSTIC_FAILED";
                detail = exception.Message;
            }

            evidence.AppendLine("Occurrences=" + occurrenceCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("Bodies=" + bodyCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("Result=" + result);
            if (!string.IsNullOrWhiteSpace(detail))
                evidence.AppendLine("Detail=" + Sanitize(detail));

            bool written = WriteEvidence(request.EvidenceFile, evidence.ToString());
            bool passed = written && string.Equals(result, "READ_ONLY_DIAGNOSTIC_COMPLETED", StringComparison.Ordinal);
            ShowResult(
                passed ? "CR-04 target-component read diagnostic completed." : "CR-04 target-component read diagnostic stopped safely.",
                "Occurrences=" + occurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; Bodies=" + bodyCount.ToString(CultureInfo.InvariantCulture) +
                Environment.NewLine + "Result=" + result +
                Environment.NewLine + Environment.NewLine + "Evidence: " + request.EvidenceFile,
                passed ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            return passed;
        }

        private static SteelGradeCategoryMappingConfiguration LoadCategoryConfiguration(string configPath)
        {
            if (!File.Exists(configPath))
                throw new FileNotFoundException("Cimatron customization configuration was not found.", configPath);

            XDocument document = XDocument.Load(configPath, LoadOptions.None);
            XElement feature = document.Root?
                .Element("features")?
                .Elements("feature")
                .SingleOrDefault(element => string.Equals((string)element.Attribute("id"), FeatureId, StringComparison.OrdinalIgnoreCase));
            if (feature == null)
                throw new InvalidDataException("CR-04 feature configuration was not found.");

            XElement parameters = feature.Element("parameters");
            string rawPatterns = ReadParameter(parameters, CategoryPatternsParameter);
            string rawExclusions = ReadParameter(parameters, CategoryExclusionsParameter);
            string categoryAttributeName = ReadParameter(parameters, CategoryAttributeNameParameter);

            List<SteelGradeCategoryPattern> patterns = new List<SteelGradeCategoryPattern>();
            foreach (string item in SplitList(rawPatterns))
            {
                int separator = item.IndexOf('=');
                if (separator <= 0 || separator >= item.Length - 1)
                    throw new InvalidDataException("CR-04 category pattern configuration is malformed: " + item);
                patterns.Add(new SteelGradeCategoryPattern(
                    item.Substring(0, separator).Trim(),
                    item.Substring(separator + 1).Trim()));
            }

            return new SteelGradeCategoryMappingConfiguration(
                categoryAttributeName,
                patterns,
                SplitList(rawExclusions));
        }

        private static string ReadParameter(XElement parameters, string name)
        {
            if (parameters == null)
                return string.Empty;

            XElement match = parameters.Elements("parameter")
                .SingleOrDefault(element => string.Equals((string)element.Attribute("name"), name, StringComparison.OrdinalIgnoreCase));
            return match == null ? string.Empty : ((string)match.Attribute("value") ?? string.Empty);
        }

        private static string[] SplitList(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw))
                return Array.Empty<string>();

            return raw.Split(ListSeparators, StringSplitOptions.RemoveEmptyEntries)
                .Select(value => value.Trim())
                .Where(value => value.Length > 0)
                .ToArray();
        }

        private static string JoinFields(params string[] fields)
        {
            return string.Join("|", fields.Select(Sanitize));
        }

        private static string Sanitize(string value)
        {
            return (value ?? string.Empty)
                .Replace('|', '/')
                .Replace('\r', ' ')
                .Replace('\n', ' ');
        }

        private static bool WriteEvidence(string evidencePath, string content)
        {
            try
            {
                string directory = Path.GetDirectoryName(evidencePath);
                if (!string.IsNullOrWhiteSpace(directory))
                    Directory.CreateDirectory(directory);
                using (FileStream stream = new FileStream(evidencePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                using (StreamWriter writer = new StreamWriter(stream, new UTF8Encoding(false)))
                {
                    writer.Write(content);
                }
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                ShowResult(
                    "The CR-04 target-component diagnostic ran, but its evidence file could not be written.",
                    exception.Message,
                    MessageBoxIcon.Error);
                return false;
            }
        }

        private static void ShowResult(string heading, string detail, MessageBoxIcon icon)
        {
            MessageBox.Show(
                heading + Environment.NewLine + Environment.NewLine + detail,
                "Cimatron Customization — CR-04 Target Component Diagnostic",
                MessageBoxButtons.OK,
                icon);
        }
    }
}
