using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using CimatronCustomization.CimatronIntegration;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Developer-only, one-shot CR-04 Slice 3 live smoke. It runs inside the already-running
    /// Cimatron plugin process and calls the real production body-attribute adapter read-only.
    /// </summary>
    internal static class Cr04Slice3WrongTypeInProcessSmoke
    {
        private const string ExpectedAssemblyTitle = "KA-ASM-1-CR04-WRONG-TYPE-SMOKE";
        private const string TargetModelTitle = "KA-PART-1-CR04-WRONG-TYPE";
        private const string AttributeName = "CR04_WRONG_TYPE_CONTROL";
        private const int TargetBodyEntityId = 4;

        internal static bool TryRunRequested(out bool commandResult)
        {
            Cr04Slice3WrongTypeInProcessSmokeRequest request;
            string requestError;
            if (!Cr04Slice3WrongTypeInProcessSmokeRequest.TryConsume(out request, out requestError))
            {
                commandResult = false;
                return false;
            }

            if (request == null)
            {
                commandResult = false;
                ShowResult("CR-04 Slice 3 smoke request rejected.", requestError, MessageBoxIcon.Error);
                return true;
            }

            commandResult = Run(request);
            return true;
        }

        private static bool Run(Cr04Slice3WrongTypeInProcessSmokeRequest request)
        {
            interop.CimatronE.ICimDocument activeDocument = null;
            StringBuilder evidence = new StringBuilder();
            evidence.AppendLine("CR-04 SLICE 3 WRONG-TYPE IN-PROCESS PLUGIN SMOKE");
            evidence.AppendLine("TimestampUtc=" + DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            evidence.AppendLine("PluginVersion=" + Assembly.GetExecutingAssembly().GetName().Version.ToString(3));
            evidence.AppendLine("ExecutionContext=IN_PROCESS_PLUGIN");
            evidence.AppendLine("ExpectedAssemblyTitle=" + ExpectedAssemblyTitle);
            evidence.AppendLine("TargetModelTitle=" + TargetModelTitle);
            evidence.AppendLine("TargetBodyEntityId=" + TargetBodyEntityId.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("AttributeName=" + AttributeName);

            MutationSnapshot before = null;
            MutationSnapshot after = null;
            string result = "ERROR";
            string detail = string.Empty;
            int present = 0;
            int absent = 0;
            int readError = 0;
            int targetOccurrenceCount = 0;
            int bodyObservationCount = 0;

            try
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application == null)
                    throw new InvalidOperationException("The in-process Cimatron application is not available.");

                activeDocument = application.GetActiveDoc();
                if (activeDocument == null)
                    throw new InvalidOperationException("No active Cimatron document is available.");
                if (!string.Equals(activeDocument.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    throw new InvalidOperationException("The active document is not an Assembly.");

                interop.CimMdlrAPI.IModelContainer container = activeDocument as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IModel activeModel = container == null ? null : container.Model as interop.CimMdlrAPI.IModel;
                string activeAssemblyTitle = activeModel == null ? string.Empty : activeModel.Title ?? string.Empty;
                evidence.AppendLine("ActiveAssemblyTitle=" + activeAssemblyTitle);
                if (!string.Equals(activeAssemblyTitle, ExpectedAssemblyTitle, StringComparison.Ordinal))
                    throw new InvalidOperationException("HARD STOP: open only the approved disposable smoke Assembly before running this request.");

                before = MutationSnapshot.Capture(activeDocument);
                if (!before.IsComplete)
                    throw new InvalidOperationException("No-mutation evidence cannot be established because the active Assembly is not a saved file with file metadata.");

                Cr04WrongTypeSmokeProbe probe = new Cr04WrongTypeSmokeProbe();
                Cr04WrongTypeSmokeProbeResult probeResult = probe.Read(TargetModelTitle, AttributeName, TargetBodyEntityId);
                if (!probeResult.IsSuccess)
                    throw new InvalidOperationException(probeResult.ErrorMessage);

                targetOccurrenceCount = probeResult.TargetOccurrenceCount;
                bodyObservationCount = probeResult.BodyObservationCount;
                present = probeResult.Present;
                absent = probeResult.Absent;
                readError = probeResult.ReadError;
                foreach (string occurrenceEvidence in probeResult.OccurrenceEvidence)
                    evidence.AppendLine(occurrenceEvidence);

                after = MutationSnapshot.Capture(activeDocument);
                bool noMutation = before.IsEquivalentTo(after);

                if (present > 0)
                {
                    result = "HARD_STOP_PRESENT_OBSERVED";
                    detail = "A genuine cmAttInteger control queried through the production cmAttString route returned Present evidence.";
                }
                else if (!noMutation)
                {
                    result = "HARD_STOP_MUTATION_EVIDENCE_CHANGED";
                    detail = "Active-document/file mutation evidence changed during the read-only smoke.";
                }
                else if (readError >= 1)
                {
                    result = "FAIL_SAFE_READ_ERROR_OBSERVED";
                    detail = "Expected fail-safe wrong-type behavior was observed through the real production adapter.";
                }
                else
                {
                    result = "UNEXPECTED_OBSERVATION_STATE";
                    detail = "The wrong-type control did not produce the required ReadError evidence.";
                }
            }
            catch (Exception exception)
            {
                detail = exception.Message;
                if (result == "ERROR")
                    result = "HARD_STOP_SMOKE_FAILED";
            }
            finally
            {
                if (before != null && after == null && activeDocument != null)
                {
                    try { after = MutationSnapshot.Capture(activeDocument); }
                    catch (Exception) { }
                }
                AppendEvidence(evidence, before, after, targetOccurrenceCount, bodyObservationCount, present, absent, readError, result, detail);
            }

            bool evidenceWritten = WriteEvidence(request.EvidenceFile, evidence.ToString());
            bool passed = evidenceWritten && string.Equals(result, "FAIL_SAFE_READ_ERROR_OBSERVED", StringComparison.Ordinal);
            if (!evidenceWritten)
                result = "HARD_STOP_EVIDENCE_WRITE_FAILED";
            string summary =
                "Present=" + present.ToString(CultureInfo.InvariantCulture) +
                "; Absent=" + absent.ToString(CultureInfo.InvariantCulture) +
                "; ReadError=" + readError.ToString(CultureInfo.InvariantCulture) +
                "; NoMutation=" + (before != null && after != null && before.IsEquivalentTo(after) ? "PASS" : "FAIL") +
                Environment.NewLine + "Result=" + result +
                Environment.NewLine + Environment.NewLine + "Evidence: " + request.EvidenceFile;

            ShowResult(
                passed ? "CR-04 Slice 3 in-process smoke completed." : "CR-04 Slice 3 in-process smoke stopped safely.",
                summary,
                passed ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            return passed;
        }

        private static void AppendEvidence(
            StringBuilder evidence,
            MutationSnapshot before,
            MutationSnapshot after,
            int targetOccurrenceCount,
            int bodyObservationCount,
            int present,
            int absent,
            int readError,
            string result,
            string detail)
        {
            evidence.AppendLine("TargetOccurrences=" + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("Body4Observations=" + bodyObservationCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("Present=" + present.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("Absent=" + absent.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("ReadError=" + readError.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("NoMutationBefore=" + FormatMutation(before));
            evidence.AppendLine("NoMutationAfter=" + FormatMutation(after));
            evidence.AppendLine("NoMutation=" + (before != null && after != null && before.IsEquivalentTo(after) ? "PASS" : "FAIL"));
            evidence.AppendLine("Result=" + result);
            if (!string.IsNullOrWhiteSpace(detail))
                evidence.AppendLine("Detail=" + detail.Replace('\r', ' ').Replace('\n', ' '));
        }

        private static string FormatMutation(MutationSnapshot snapshot)
        {
            if (snapshot == null)
                return "NOT_CAPTURED";

            return
                "PathPresent=" + (!string.IsNullOrWhiteSpace(snapshot.Path)).ToString() +
                ";Modified=" + snapshot.Modified.ToString() +
                ";LastWriteUtc=" + (snapshot.LastWriteUtc.HasValue ? snapshot.LastWriteUtc.Value.ToString("O", CultureInfo.InvariantCulture) : "N/A") +
                ";Length=" + (snapshot.Length.HasValue ? snapshot.Length.Value.ToString(CultureInfo.InvariantCulture) : "N/A");
        }

        private static bool WriteEvidence(string evidencePath, string content)
        {
            try
            {
                string directory = Path.GetDirectoryName(evidencePath);
                if (!string.IsNullOrWhiteSpace(directory))
                    Directory.CreateDirectory(directory);
                using (FileStream stream = new FileStream(evidencePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                using (StreamWriter writer = new StreamWriter(stream, new UTF8Encoding(false)))
                {
                    writer.Write(content);
                }
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                MessageBox.Show(
                    "The CR-04 smoke ran, but its evidence file could not be written." + Environment.NewLine + exception.Message,
                    "Cimatron Customization — CR-04 Slice 3 Smoke",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
        }

        private static void ShowResult(string heading, string detail, MessageBoxIcon icon)
        {
            MessageBox.Show(
                heading + Environment.NewLine + Environment.NewLine + detail,
                "Cimatron Customization — CR-04 Slice 3 Smoke",
                MessageBoxButtons.OK,
                icon);
        }

        private sealed class MutationSnapshot
        {
            private MutationSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path ?? string.Empty;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            internal string Path { get; }
            internal bool Modified { get; }
            internal DateTime? LastWriteUtc { get; }
            internal long? Length { get; }
            internal bool IsComplete => !string.IsNullOrWhiteSpace(Path) && LastWriteUtc.HasValue && Length.HasValue;

            internal static MutationSnapshot Capture(interop.CimatronE.ICimDocument document)
            {
                if (document == null)
                    throw new ArgumentNullException(nameof(document));

                string path = document.GetPath() ?? string.Empty;
                bool modified = document.IsModified();
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo file = new FileInfo(path);
                    lastWriteUtc = file.LastWriteTimeUtc;
                    length = file.Length;
                }

                return new MutationSnapshot(path, modified, lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(MutationSnapshot other)
            {
                return IsComplete && other != null && other.IsComplete &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }
    }
}
