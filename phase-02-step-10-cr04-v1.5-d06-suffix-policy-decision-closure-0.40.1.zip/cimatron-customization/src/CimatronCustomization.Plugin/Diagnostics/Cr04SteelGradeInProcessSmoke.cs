using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using CimatronCustomization.CimatronIntegration;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Developer-only, one-shot positive-conformance smoke for the production CR-04 body reader.
    /// </summary>
    internal static class Cr04SteelGradeInProcessSmoke
    {
        private const string ExpectedAssemblyTitle = "KA-ASM-1-CR04-WRONG-TYPE-SMOKE";
        private const string TargetModelTitle = "KA-PART-1-CR04-WRONG-TYPE";
        private const int TargetBodyEntityId = 4;
        private const string AttributeName = "STEEL_GRADE";
        private const string ExpectedValue = "P-20-2311";

        internal static bool TryRunRequested(out bool commandResult)
        {
            Cr04SteelGradeInProcessSmokeRequest request;
            string requestError;
            if (!Cr04SteelGradeInProcessSmokeRequest.TryConsume(out request, out requestError))
            {
                commandResult = false;
                return false;
            }

            if (request == null)
            {
                commandResult = false;
                ShowResult("CR-04 steel-grade smoke request rejected.", requestError, MessageBoxIcon.Error);
                return true;
            }

            commandResult = Run(request);
            return true;
        }

        private static bool Run(Cr04SteelGradeInProcessSmokeRequest request)
        {
            interop.CimatronE.ICimDocument activeDocument = null;
            StringBuilder evidence = new StringBuilder();
            evidence.AppendLine("CR-04 STEEL-GRADE PRODUCTION-READER IN-PROCESS SMOKE");
            evidence.AppendLine("TimestampUtc=" + DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            evidence.AppendLine("PluginVersion=" + Assembly.GetExecutingAssembly().GetName().Version.ToString(3));
            evidence.AppendLine("ExecutionContext=IN_PROCESS_PLUGIN");
            evidence.AppendLine("Scope=CONTROLLED_MODEL_PRODUCTION_READER_PATH_ONLY");
            evidence.AppendLine("ExpectedAssemblyTitle=" + ExpectedAssemblyTitle);
            evidence.AppendLine("TargetModelTitle=" + TargetModelTitle);
            evidence.AppendLine("TargetBodyEntityId=" + TargetBodyEntityId.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("AttributeName=" + AttributeName);
            evidence.AppendLine("ExpectedValue=" + ExpectedValue);
            evidence.AppendLine("PartFile=" + request.PartFile);

            DocumentSnapshot assemblyBefore = null;
            DocumentSnapshot assemblyAfter = null;
            FileSnapshot partBefore = null;
            FileSnapshot partAfter = null;
            string result = "ERROR";
            string detail = string.Empty;
            int targetOccurrenceCount = 0;
            int targetBodyObservationCount = 0;
            int totalBodyObservationCount = 0;
            int readErrorCount = 0;

            try
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application == null)
                    throw new InvalidOperationException("The in-process Cimatron application is not available.");

                activeDocument = application.GetActiveDoc();
                if (activeDocument == null)
                    throw new InvalidOperationException("No active Cimatron document is available.");
                if (!string.Equals(activeDocument.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    throw new InvalidOperationException("The active document is not an Assembly.");

                interop.CimMdlrAPI.IModelContainer container = activeDocument as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IModel activeModel = container == null ? null : container.Model as interop.CimMdlrAPI.IModel;
                string activeAssemblyTitle = activeModel == null ? string.Empty : activeModel.Title ?? string.Empty;
                evidence.AppendLine("ActiveAssemblyTitle=" + activeAssemblyTitle);
                if (!string.Equals(activeAssemblyTitle, ExpectedAssemblyTitle, StringComparison.Ordinal))
                    throw new InvalidOperationException("HARD STOP: open only the approved disposable smoke Assembly before running this request.");

                if (Path.GetFileNameWithoutExtension(request.PartFile).IndexOf(TargetModelTitle, StringComparison.OrdinalIgnoreCase) < 0)
                    throw new InvalidOperationException("HARD STOP: PartFile does not identify the approved disposable Part name.");

                assemblyBefore = DocumentSnapshot.Capture(activeDocument);
                if (!assemblyBefore.IsComplete)
                    throw new InvalidOperationException("No-mutation evidence cannot be established because the active Assembly is not a saved file with file metadata.");
                partBefore = FileSnapshot.Capture(request.PartFile);
                if (!partBefore.IsComplete)
                    throw new InvalidOperationException("No-mutation evidence cannot be established for the saved disposable Part file.");

                Cr04SteelGradeSmokeProbe probe = new Cr04SteelGradeSmokeProbe();
                Cr04SteelGradeSmokeProbeResult probeResult = probe.Read();
                targetOccurrenceCount = probeResult.TargetOccurrenceCount;
                targetBodyObservationCount = probeResult.TargetBodyObservationCount;
                totalBodyObservationCount = probeResult.TotalBodyObservationCount;
                readErrorCount = probeResult.ReadErrorCount;
                foreach (string bodyEvidence in probeResult.BodyEvidence)
                    evidence.AppendLine(bodyEvidence);

                assemblyAfter = DocumentSnapshot.Capture(activeDocument);
                partAfter = FileSnapshot.Capture(request.PartFile);
                bool assemblyUnchanged = assemblyBefore.IsEquivalentTo(assemblyAfter);
                bool partUnchanged = partBefore.IsEquivalentTo(partAfter);

                if (!probeResult.IsSuccess)
                {
                    result = "HARD_STOP_KNOWN_ANSWER_MISMATCH";
                    detail = probeResult.ErrorMessage;
                }
                else if (!assemblyUnchanged || !partUnchanged)
                {
                    result = "HARD_STOP_MUTATION_EVIDENCE_CHANGED";
                    detail = "Assembly or disposable Part file evidence changed during the read-only smoke.";
                }
                else
                {
                    result = "PRODUCTION_READER_STEEL_GRADE_OBSERVED";
                    detail = "The controlled positive STEEL_GRADE value was observed through the actual production reader path.";
                }
            }
            catch (Exception exception)
            {
                detail = exception.Message;
                if (result == "ERROR")
                    result = "HARD_STOP_SMOKE_FAILED";
            }
            finally
            {
                if (assemblyBefore != null && assemblyAfter == null && activeDocument != null)
                {
                    try { assemblyAfter = DocumentSnapshot.Capture(activeDocument); }
                    catch (Exception) { }
                }
                if (partBefore != null && partAfter == null)
                {
                    try { partAfter = FileSnapshot.Capture(request.PartFile); }
                    catch (Exception) { }
                }

                AppendEvidence(evidence, assemblyBefore, assemblyAfter, partBefore, partAfter, targetOccurrenceCount, targetBodyObservationCount, totalBodyObservationCount, readErrorCount, result, detail);
            }

            bool evidenceWritten = WriteEvidence(request.EvidenceFile, evidence.ToString());
            bool passed = evidenceWritten && string.Equals(result, "PRODUCTION_READER_STEEL_GRADE_OBSERVED", StringComparison.Ordinal);
            if (!evidenceWritten)
                result = "HARD_STOP_EVIDENCE_WRITE_FAILED";

            string summary =
                "TargetOccurrences=" + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; TargetBodyObservations=" + targetBodyObservationCount.ToString(CultureInfo.InvariantCulture) +
                "; TotalBodyObservations=" + totalBodyObservationCount.ToString(CultureInfo.InvariantCulture) +
                "; ReadError=" + readErrorCount.ToString(CultureInfo.InvariantCulture) +
                "; AssemblyNoMutation=" + (assemblyBefore != null && assemblyAfter != null && assemblyBefore.IsEquivalentTo(assemblyAfter) ? "PASS" : "FAIL") +
                "; PartFileNoMutation=" + (partBefore != null && partAfter != null && partBefore.IsEquivalentTo(partAfter) ? "PASS" : "FAIL") +
                Environment.NewLine + "Result=" + result +
                Environment.NewLine + Environment.NewLine + "Evidence: " + request.EvidenceFile;

            ShowResult(
                passed ? "CR-04 steel-grade production-reader smoke completed." : "CR-04 steel-grade production-reader smoke stopped safely.",
                summary,
                passed ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            return passed;
        }

        private static void AppendEvidence(
            StringBuilder evidence,
            DocumentSnapshot assemblyBefore,
            DocumentSnapshot assemblyAfter,
            FileSnapshot partBefore,
            FileSnapshot partAfter,
            int targetOccurrenceCount,
            int targetBodyObservationCount,
            int totalBodyObservationCount,
            int readErrorCount,
            string result,
            string detail)
        {
            evidence.AppendLine("TargetOccurrences=" + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("TargetBodyObservations=" + targetBodyObservationCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("TotalBodyObservations=" + totalBodyObservationCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("ReadErrorCount=" + readErrorCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("AssemblyBefore=" + Describe(assemblyBefore));
            evidence.AppendLine("AssemblyAfter=" + Describe(assemblyAfter));
            evidence.AppendLine("AssemblyNoMutation=" + (assemblyBefore != null && assemblyAfter != null && assemblyBefore.IsEquivalentTo(assemblyAfter) ? "PASS" : "FAIL"));
            evidence.AppendLine("PartBefore=" + Describe(partBefore));
            evidence.AppendLine("PartAfter=" + Describe(partAfter));
            evidence.AppendLine("PartFileNoMutation=" + (partBefore != null && partAfter != null && partBefore.IsEquivalentTo(partAfter) ? "PASS" : "FAIL"));
            evidence.AppendLine("Result=" + result);
            evidence.AppendLine("Detail=" + detail);
        }

        private static string Describe(DocumentSnapshot snapshot)
        {
            if (snapshot == null)
                return "NOT_CAPTURED";

            return "PathPresent=" + (!string.IsNullOrWhiteSpace(snapshot.Path)).ToString() +
                ";Modified=" + snapshot.Modified.ToString() +
                ";LastWriteUtc=" + (snapshot.LastWriteUtc.HasValue ? snapshot.LastWriteUtc.Value.ToString("O", CultureInfo.InvariantCulture) : "N/A") +
                ";Length=" + (snapshot.Length.HasValue ? snapshot.Length.Value.ToString(CultureInfo.InvariantCulture) : "N/A");
        }

        private static string Describe(FileSnapshot snapshot)
        {
            if (snapshot == null)
                return "NOT_CAPTURED";

            return "Path=" + snapshot.Path +
                ";LastWriteUtc=" + (snapshot.LastWriteUtc.HasValue ? snapshot.LastWriteUtc.Value.ToString("O", CultureInfo.InvariantCulture) : "N/A") +
                ";Length=" + (snapshot.Length.HasValue ? snapshot.Length.Value.ToString(CultureInfo.InvariantCulture) : "N/A");
        }

        private static bool WriteEvidence(string evidencePath, string content)
        {
            try
            {
                string directory = Path.GetDirectoryName(evidencePath);
                if (!string.IsNullOrWhiteSpace(directory))
                    Directory.CreateDirectory(directory);
                using (FileStream stream = new FileStream(evidencePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                using (StreamWriter writer = new StreamWriter(stream, new UTF8Encoding(false)))
                {
                    writer.Write(content);
                }
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                MessageBox.Show(
                    "The CR-04 smoke ran, but its evidence file could not be written." + Environment.NewLine + exception.Message,
                    "Cimatron Customization — CR-04 Steel-Grade Smoke",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
        }

        private static void ShowResult(string heading, string detail, MessageBoxIcon icon)
        {
            MessageBox.Show(
                heading + Environment.NewLine + Environment.NewLine + detail,
                "Cimatron Customization — CR-04 Steel-Grade Smoke",
                MessageBoxButtons.OK,
                icon);
        }

        private sealed class DocumentSnapshot
        {
            private DocumentSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path ?? string.Empty;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            internal string Path { get; }
            internal bool Modified { get; }
            internal DateTime? LastWriteUtc { get; }
            internal long? Length { get; }
            internal bool IsComplete => !string.IsNullOrWhiteSpace(Path) && LastWriteUtc.HasValue && Length.HasValue;

            internal static DocumentSnapshot Capture(interop.CimatronE.ICimDocument document)
            {
                if (document == null)
                    throw new ArgumentNullException(nameof(document));

                string path = document.GetPath() ?? string.Empty;
                bool modified = document.IsModified();
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo file = new FileInfo(path);
                    lastWriteUtc = file.LastWriteTimeUtc;
                    length = file.Length;
                }

                return new DocumentSnapshot(path, modified, lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(DocumentSnapshot other)
            {
                return IsComplete && other != null && other.IsComplete &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }

        private sealed class FileSnapshot
        {
            private FileSnapshot(string path, DateTime? lastWriteUtc, long? length)
            {
                Path = path ?? string.Empty;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            internal string Path { get; }
            internal DateTime? LastWriteUtc { get; }
            internal long? Length { get; }
            internal bool IsComplete => !string.IsNullOrWhiteSpace(Path) && LastWriteUtc.HasValue && Length.HasValue;

            internal static FileSnapshot Capture(string path)
            {
                if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
                    return new FileSnapshot(path, null, null);

                FileInfo file = new FileInfo(path);
                return new FileSnapshot(file.FullName, file.LastWriteTimeUtc, file.Length);
            }

            internal bool IsEquivalentTo(FileSnapshot other)
            {
                return IsComplete && other != null && other.IsComplete &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }
    }
}
