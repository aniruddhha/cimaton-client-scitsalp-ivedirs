using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Developer-only, one-shot, read-only CR-04 diagnostic that discovers the document
    /// attributes exposed for approved Part occurrences. The evidence is used to identify,
    /// without guessing, the internal Cimatron fields corresponding to Part Type,
    /// Part Material and Remark. No production CR-04 source selection is changed here.
    /// </summary>
    internal static class Cr04PartPropertyDiscoveryDiagnostic
    {
        private const string UnusedBodyAttributeName = "CR04_PART_PROPERTY_DISCOVERY_UNUSED";
        private static readonly string[] TargetModelTitles =
        {
            "Cavity block",
            "Core block",
            "main insert",
            "Insert#2",
            "Main Core insert",
            "core fix insert-01",
            "Slider-01",
            "Lifter-01"
        };

        internal static bool TryRunRequested(out bool commandResult)
        {
            if (!Cr04PartPropertyDiscoveryDiagnosticRequest.TryConsume(out Cr04PartPropertyDiscoveryDiagnosticRequest request, out string requestError))
            {
                commandResult = false;
                return false;
            }

            if (request == null)
            {
                commandResult = false;
                ShowResult("CR-04 Part property discovery diagnostic request rejected.", requestError, MessageBoxIcon.Error);
                return true;
            }

            commandResult = Run(request);
            return true;
        }

        private static bool Run(Cr04PartPropertyDiscoveryDiagnosticRequest request)
        {
            StringBuilder evidence = new StringBuilder();
            evidence.AppendLine("CR-04 PART PROPERTY DISCOVERY DIAGNOSTIC");
            evidence.AppendLine("DiagnosticVersion=0.38.6");
            evidence.AppendLine("TimestampUtc=" + DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            evidence.AppendLine("ExecutionContext=IN_PROCESS_PLUGIN");
            evidence.AppendLine("ReadOnlyDiagnostic=true");
            evidence.AppendLine("ApiRoute=GetPdm -> RetriveDocAttribute");
            evidence.AppendLine("AttributeNameGuessing=false");
            evidence.AppendLine("PartTypeAttributeIdentity=NOT VERIFIED");
            evidence.AppendLine("PartMaterialAttributeIdentity=NOT VERIFIED");
            evidence.AppendLine("RemarkAttributeIdentity=NOT VERIFIED");
            evidence.AppendLine("OccurrenceSource=CimatronAssemblyBodyAttributeReader.ModelPid");
            evidence.AppendLine("Targets=" + string.Join(";", TargetModelTitles));

            string result = "ERROR";
            string detail = string.Empty;
            int targetOccurrenceCount = 0;
            int successfulTargetReads = 0;
            int attributeRowCount = 0;
            bool? modifiedBefore = null;
            bool? modifiedAfter = null;

            try
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application == null)
                    throw new InvalidOperationException("Cimatron application is not available.");

                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                if (document == null)
                    throw new InvalidOperationException("No active Cimatron document is available.");
                if (!string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    throw new InvalidOperationException("CR-04 Part property discovery requires an active Assembly document.");

                modifiedBefore = document.IsModified();
                evidence.AppendLine("DocumentModifiedBefore=" + modifiedBefore.Value.ToString(CultureInfo.InvariantCulture));

                interop.CimatronE.IPdm pdm = application.GetPdm();
                if (pdm == null)
                    throw new InvalidOperationException("Cimatron PDM manager is not available through IApplication.GetPdm().");

                CimatronAssemblyBodyAttributeReader occurrenceReader = new CimatronAssemblyBodyAttributeReader();
                AssemblyBodyAttributeSnapshot snapshot = occurrenceReader.ReadNamedAttributes(UnusedBodyAttributeName, string.Empty);
                if (!snapshot.IsSuccess)
                    throw new InvalidOperationException(snapshot.ErrorMessage);

                evidence.AppendLine("DOCUMENT ATTRIBUTES");
                evidence.AppendLine("OccurrencePath|InstanceId|ModelTitle|ModelPid|ReadStatus|AttributeName|ValueType|Value");

                foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences.Where(IsTargetOccurrence))
                {
                    targetOccurrenceCount++;
                    if (string.IsNullOrWhiteSpace(occurrence.ModelPid))
                    {
                        evidence.AppendLine(JoinFields(
                            occurrence.OccurrencePath,
                            occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                            occurrence.ModelTitle,
                            occurrence.ModelPid,
                            "MODEL_PID_MISSING",
                            string.Empty,
                            string.Empty,
                            string.Empty));
                        continue;
                    }

                    try
                    {
                        object rawAttributes = null;
                        pdm.RetriveDocAttribute(occurrence.ModelPid, ref rawAttributes, string.Empty);
                        Array attributes = rawAttributes as Array;
                        if (attributes == null)
                        {
                            evidence.AppendLine(JoinFields(
                                occurrence.OccurrencePath,
                                occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                                occurrence.ModelTitle,
                                occurrence.ModelPid,
                                rawAttributes == null ? "NO_ATTRIBUTES" : "UNEXPECTED_ATTRIBUTE_CONTAINER",
                                string.Empty,
                                rawAttributes == null ? string.Empty : rawAttributes.GetType().FullName,
                                string.Empty));
                            successfulTargetReads++;
                            continue;
                        }

                        successfulTargetReads++;
                        if (attributes.Length == 0)
                        {
                            evidence.AppendLine(JoinFields(
                                occurrence.OccurrencePath,
                                occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                                occurrence.ModelTitle,
                                occurrence.ModelPid,
                                "NO_ATTRIBUTES",
                                string.Empty,
                                string.Empty,
                                string.Empty));
                            continue;
                        }

                        foreach (object rawAttribute in attributes)
                        {
                            interop.CimBaseAPI.IDocAttribute attribute = rawAttribute as interop.CimBaseAPI.IDocAttribute;
                            if (attribute == null)
                            {
                                evidence.AppendLine(JoinFields(
                                    occurrence.OccurrencePath,
                                    occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                                    occurrence.ModelTitle,
                                    occurrence.ModelPid,
                                    "UNEXPECTED_ATTRIBUTE_ITEM",
                                    string.Empty,
                                    rawAttribute == null ? string.Empty : rawAttribute.GetType().FullName,
                                    string.Empty));
                                continue;
                            }

                            string attributeName;
                            object attributeValue;
                            try
                            {
                                attributeName = attribute.Name ?? string.Empty;
                                attributeValue = attribute.Value;
                            }
                            catch (Exception exception)
                            {
                                evidence.AppendLine(JoinFields(
                                    occurrence.OccurrencePath,
                                    occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                                    occurrence.ModelTitle,
                                    occurrence.ModelPid,
                                    "ATTRIBUTE_READ_ERROR",
                                    string.Empty,
                                    string.Empty,
                                    exception.Message));
                                continue;
                            }

                            attributeRowCount++;
                            evidence.AppendLine(JoinFields(
                                occurrence.OccurrencePath,
                                occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                                occurrence.ModelTitle,
                                occurrence.ModelPid,
                                "READ",
                                attributeName,
                                attributeValue == null ? "<null>" : attributeValue.GetType().FullName,
                                FormatValue(attributeValue)));
                        }
                    }
                    catch (Exception exception)
                    {
                        evidence.AppendLine(JoinFields(
                            occurrence.OccurrencePath,
                            occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                            occurrence.ModelTitle,
                            occurrence.ModelPid,
                            "PDM_READ_ERROR",
                            string.Empty,
                            string.Empty,
                            exception.Message));
                    }
                }

                modifiedAfter = document.IsModified();
                evidence.AppendLine("DocumentModifiedAfter=" + modifiedAfter.Value.ToString(CultureInfo.InvariantCulture));
                bool modificationStateChanged = modifiedBefore.Value != modifiedAfter.Value;
                evidence.AppendLine("ModificationStateChanged=" + modificationStateChanged.ToString(CultureInfo.InvariantCulture));

                if (modificationStateChanged)
                    throw new InvalidOperationException("The active document modification state changed during the read-only diagnostic.");
                if (targetOccurrenceCount == 0)
                    throw new InvalidOperationException("None of the approved CR-04 target occurrences were found in the active Assembly.");
                if (successfulTargetReads == 0)
                    throw new InvalidOperationException("Document attributes could not be retrieved for any approved CR-04 target occurrence.");

                result = "READ_ONLY_PART_PROPERTY_DISCOVERY_COMPLETED";
                detail = "Document attributes were captured through the installed PDM read route without changing the active document modification state. Attribute identities remain unassigned pending evidence review.";
            }
            catch (Exception exception)
            {
                result = "READ_ONLY_PART_PROPERTY_DISCOVERY_FAILED";
                detail = exception.Message;

                if (!modifiedAfter.HasValue)
                {
                    try
                    {
                        interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                        interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                        interop.CimatronE.ICimDocument document = application == null ? null : application.GetActiveDoc();
                        if (document != null)
                        {
                            modifiedAfter = document.IsModified();
                            evidence.AppendLine("DocumentModifiedAfter=" + modifiedAfter.Value.ToString(CultureInfo.InvariantCulture));
                            if (modifiedBefore.HasValue)
                                evidence.AppendLine("ModificationStateChanged=" + (modifiedBefore.Value != modifiedAfter.Value).ToString(CultureInfo.InvariantCulture));
                        }
                    }
                    catch (Exception stateException)
                    {
                        evidence.AppendLine("DocumentModifiedAfterReadError=" + Sanitize(stateException.Message));
                    }
                }
            }

            evidence.AppendLine("TargetOccurrences=" + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("SuccessfulTargetReads=" + successfulTargetReads.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("AttributeRows=" + attributeRowCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("Result=" + result);
            if (!string.IsNullOrWhiteSpace(detail))
                evidence.AppendLine("Detail=" + Sanitize(detail));

            bool written = WriteEvidence(request.EvidenceFile, evidence.ToString());
            bool passed = written && string.Equals(result, "READ_ONLY_PART_PROPERTY_DISCOVERY_COMPLETED", StringComparison.Ordinal);
            ShowResult(
                passed ? "CR-04 Part property discovery diagnostic completed." : "CR-04 Part property discovery diagnostic stopped safely.",
                "TargetOccurrences=" + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; SuccessfulTargetReads=" + successfulTargetReads.ToString(CultureInfo.InvariantCulture) +
                "; AttributeRows=" + attributeRowCount.ToString(CultureInfo.InvariantCulture) +
                Environment.NewLine + "Result=" + result +
                Environment.NewLine + Environment.NewLine + "Evidence: " + request.EvidenceFile,
                passed ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            return passed;
        }

        private static bool IsTargetOccurrence(AssemblyBodyAttributeOccurrence occurrence)
        {
            return occurrence != null && TargetModelTitles.Any(target =>
                string.Equals(target, occurrence.ModelTitle, StringComparison.OrdinalIgnoreCase));
        }

        private static string FormatValue(object value)
        {
            if (value == null)
                return "<null>";

            Array array = value as Array;
            if (array != null)
            {
                List<string> items = new List<string>();
                foreach (object item in array)
                    items.Add(Convert.ToString(item, CultureInfo.InvariantCulture) ?? string.Empty);
                return "[" + string.Join(",", items) + "]";
            }

            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string JoinFields(params string[] fields)
        {
            return string.Join("|", fields.Select(Sanitize));
        }

        private static string Sanitize(string value)
        {
            return (value ?? string.Empty)
                .Replace("\r", " ")
                .Replace("\n", " ")
                .Replace("|", "/");
        }

        private static bool WriteEvidence(string path, string text)
        {
            try
            {
                string directory = Path.GetDirectoryName(path);
                if (!string.IsNullOrWhiteSpace(directory))
                    Directory.CreateDirectory(directory);
                File.WriteAllText(path, text, new UTF8Encoding(false));
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                ShowResult("CR-04 Part property discovery evidence could not be written.", exception.Message, MessageBoxIcon.Error);
                return false;
            }
        }

        private static void ShowResult(string title, string message, MessageBoxIcon icon)
        {
            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
        }
    }
}
