using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Developer-only, one-shot, read-only CR-04 diagnostic. It captures the production
    /// occurrence ModelTitle, BOM Standard Number/Material evidence, category resolution,
    /// and exact production correlation result for the approved target components.
    /// It never writes to the Cimatron model or Design Order workbook.
    /// </summary>
    internal static class Cr04PartMaterialCorrelationDiagnostic
    {
        private const string FeatureId = "STEEL-GRADE-DESIGN-ORDER-VALIDATION";
        private const string CategoryPatternsParameter = "ComponentCategoryPatterns";
        private const string CategoryExclusionsParameter = "ComponentExclusionPatterns";
        private const string CategoryAttributeNameParameter = "ComponentCategoryAttributeName";
        private static readonly char[] ListSeparators = { ';' };
        private static readonly string[] TargetModelTitles =
        {
            "Cavity block",
            "Core block",
            "main insert",
            "Insert#2",
            "Main Core insert",
            "core fix insert-01",
            "Slider-01",
            "Lifter-01"
        };

        internal static bool TryRunRequested(out bool commandResult)
        {
            if (!Cr04PartMaterialCorrelationDiagnosticRequest.TryConsume(out Cr04PartMaterialCorrelationDiagnosticRequest request, out string requestError))
            {
                commandResult = false;
                return false;
            }

            if (request == null)
            {
                commandResult = false;
                ShowResult("CR-04 Part Material correlation diagnostic request rejected.", requestError, MessageBoxIcon.Error);
                return true;
            }

            commandResult = Run(request);
            return true;
        }

        private static bool Run(Cr04PartMaterialCorrelationDiagnosticRequest request)
        {
            StringBuilder evidence = new StringBuilder();
            evidence.AppendLine("CR-04 PART MATERIAL CORRELATION DIAGNOSTIC");
            evidence.AppendLine("TimestampUtc=" + DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            evidence.AppendLine("ExecutionContext=IN_PROCESS_PLUGIN");
            evidence.AppendLine("ReadOnlyDiagnostic=true");
            evidence.AppendLine("OccurrenceReader=CimatronAssemblyBodyAttributeReader");
            evidence.AppendLine("PartMaterialReader=CimatronBomMaterialTableReader");
            evidence.AppendLine("ProductionCorrelation=OrdinalIgnoreCase(ModelTitle, BOM Standard Number)");
            evidence.AppendLine("Targets=" + string.Join(";", TargetModelTitles));

            string result = "ERROR";
            string detail = string.Empty;
            int targetOccurrenceCount = 0;
            int bomRowCount = 0;

            try
            {
                string configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CimatronCustomization.config.xml");
                SteelGradeCategoryMappingConfiguration categoryConfiguration = LoadCategoryConfiguration(configPath);
                string[] categoryKeys = SrideviQrDg02Rev04Profile.Create().Categories
                    .Select(category => category.CategoryKey)
                    .ToArray();

                CimatronAssemblyBodyAttributeReader occurrenceReader = new CimatronAssemblyBodyAttributeReader();
                AssemblyBodyAttributeSnapshot snapshot = occurrenceReader.ReadNamedAttributes("STEEL_GRADE", categoryConfiguration.CategoryAttributeName);
                if (!snapshot.IsSuccess)
                    throw new InvalidOperationException(snapshot.ErrorMessage);

                CimatronBomMaterialTableReader materialReader = new CimatronBomMaterialTableReader(new ExcelTabularDataReader());
                BomMaterialTableResult materialTable = materialReader.ReadMaterialTable();
                if (!materialTable.IsSuccess)
                    throw new InvalidOperationException(materialTable.ErrorMessage);

                bomRowCount = materialTable.Rows.Count;
                evidence.AppendLine("TARGET OCCURRENCES");
                evidence.AppendLine("OccurrencePath|InstanceId|ModelTitle|BOM Standard Number|BOM Material|Category resolution|Correlation result");

                foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences.Where(IsTargetOccurrence))
                {
                    targetOccurrenceCount++;
                    SteelGradeCategoryResolution resolution = SteelGradeCategoryResolver.Resolve(
                        occurrence,
                        categoryConfiguration,
                        categoryKeys);
                    string categoryText = resolution.Kind == SteelGradeCategoryResolutionKind.Mapped
                        ? "Mapped:" + resolution.CategoryKey
                        : resolution.Kind + ":" + resolution.Detail;

                    BomMaterialRow[] matchingRows = materialTable.Rows
                        .Where(row => string.Equals(row.ModelTitle, occurrence.ModelTitle, StringComparison.OrdinalIgnoreCase))
                        .ToArray();

                    if (matchingRows.Length == 0)
                    {
                        evidence.AppendLine(JoinFields(
                            occurrence.OccurrencePath,
                            occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                            occurrence.ModelTitle,
                            "<none>",
                            string.Empty,
                            categoryText,
                            "NO_EXACT_BOM_STANDARD_NUMBER_MATCH"));
                        continue;
                    }

                    foreach (BomMaterialRow row in matchingRows)
                    {
                        evidence.AppendLine(JoinFields(
                            occurrence.OccurrencePath,
                            occurrence.InstanceId.ToString(CultureInfo.InvariantCulture),
                            occurrence.ModelTitle,
                            row.ModelTitle,
                            row.Material,
                            categoryText,
                            string.IsNullOrWhiteSpace(row.Material) ? "MATCHED_BOM_ROW_MATERIAL_BLANK" : "MATCHED_BOM_ROW"));
                    }
                }

                evidence.AppendLine("BOM SNAPSHOT");
                evidence.AppendLine("SourceRow|Standard Number|Material");
                foreach (BomMaterialRow row in materialTable.Rows)
                {
                    evidence.AppendLine(JoinFields(
                        row.SourceRowNumber.ToString(CultureInfo.InvariantCulture),
                        row.ModelTitle,
                        row.Material));
                }

                result = "READ_ONLY_CORRELATION_DIAGNOSTIC_COMPLETED";
                detail = "Target occurrence/category resolution and the complete production BOM Standard Number/Material snapshot were captured without mutation.";
            }
            catch (Exception exception)
            {
                result = "READ_ONLY_CORRELATION_DIAGNOSTIC_FAILED";
                detail = exception.Message;
            }

            evidence.AppendLine("TargetOccurrences=" + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("BomRows=" + bomRowCount.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("Result=" + result);
            if (!string.IsNullOrWhiteSpace(detail))
                evidence.AppendLine("Detail=" + Sanitize(detail));

            bool written = WriteEvidence(request.EvidenceFile, evidence.ToString());
            bool passed = written && string.Equals(result, "READ_ONLY_CORRELATION_DIAGNOSTIC_COMPLETED", StringComparison.Ordinal);
            ShowResult(
                passed ? "CR-04 Part Material correlation diagnostic completed." : "CR-04 Part Material correlation diagnostic stopped safely.",
                "TargetOccurrences=" + targetOccurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; BomRows=" + bomRowCount.ToString(CultureInfo.InvariantCulture) +
                Environment.NewLine + "Result=" + result +
                Environment.NewLine + Environment.NewLine + "Evidence: " + request.EvidenceFile,
                passed ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            return passed;
        }

        private static bool IsTargetOccurrence(AssemblyBodyAttributeOccurrence occurrence)
        {
            return occurrence != null && TargetModelTitles.Any(target =>
                string.Equals(target, occurrence.ModelTitle, StringComparison.OrdinalIgnoreCase));
        }

        private static SteelGradeCategoryMappingConfiguration LoadCategoryConfiguration(string configPath)
        {
            if (!File.Exists(configPath))
                throw new FileNotFoundException("Cimatron customization configuration was not found.", configPath);

            XDocument document = XDocument.Load(configPath, LoadOptions.None);
            XElement feature = document.Root?
                .Element("features")?
                .Elements("feature")
                .SingleOrDefault(element => string.Equals((string)element.Attribute("id"), FeatureId, StringComparison.OrdinalIgnoreCase));
            if (feature == null)
                throw new InvalidDataException("CR-04 feature configuration was not found.");

            XElement parameters = feature.Element("parameters");
            string rawPatterns = ReadParameter(parameters, CategoryPatternsParameter);
            string rawExclusions = ReadParameter(parameters, CategoryExclusionsParameter);
            string categoryAttributeName = ReadParameter(parameters, CategoryAttributeNameParameter);

            List<SteelGradeCategoryPattern> patterns = new List<SteelGradeCategoryPattern>();
            foreach (string item in SplitList(rawPatterns))
            {
                int separator = item.IndexOf('=');
                if (separator <= 0 || separator >= item.Length - 1)
                    throw new InvalidDataException("CR-04 category pattern configuration is malformed: " + item);
                patterns.Add(new SteelGradeCategoryPattern(
                    item.Substring(0, separator).Trim(),
                    item.Substring(separator + 1).Trim()));
            }

            return new SteelGradeCategoryMappingConfiguration(categoryAttributeName, patterns, SplitList(rawExclusions));
        }

        private static string ReadParameter(XElement parameters, string name)
        {
            if (parameters == null)
                return string.Empty;

            XElement match = parameters.Elements("parameter")
                .SingleOrDefault(element => string.Equals((string)element.Attribute("name"), name, StringComparison.OrdinalIgnoreCase));
            return match == null ? string.Empty : ((string)match.Attribute("value") ?? string.Empty);
        }

        private static string[] SplitList(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw))
                return Array.Empty<string>();

            return raw.Split(ListSeparators, StringSplitOptions.RemoveEmptyEntries)
                .Select(value => value.Trim())
                .Where(value => value.Length > 0)
                .ToArray();
        }

        private static string JoinFields(params string[] fields)
        {
            return string.Join("|", fields.Select(Sanitize));
        }

        private static string Sanitize(string value)
        {
            return (value ?? string.Empty)
                .Replace("\r", " ")
                .Replace("\n", " ")
                .Replace("|", "/");
        }

        private static bool WriteEvidence(string path, string text)
        {
            try
            {
                string directory = Path.GetDirectoryName(path);
                if (!string.IsNullOrWhiteSpace(directory))
                    Directory.CreateDirectory(directory);
                File.WriteAllText(path, text, new UTF8Encoding(false));
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                ShowResult("CR-04 Part Material correlation diagnostic evidence could not be written.", exception.Message, MessageBoxIcon.Error);
                return false;
            }
        }

        private static void ShowResult(string message, string detail, MessageBoxIcon icon)
        {
            MessageBox.Show(
                message + Environment.NewLine + Environment.NewLine + detail,
                "Cimatron Customization",
                MessageBoxButtons.OK,
                icon);
        }
    }
}
