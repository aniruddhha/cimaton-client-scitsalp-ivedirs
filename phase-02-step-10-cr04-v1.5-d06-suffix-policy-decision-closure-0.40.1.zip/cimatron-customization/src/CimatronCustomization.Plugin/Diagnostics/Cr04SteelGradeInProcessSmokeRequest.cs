using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;

namespace CimatronCustomizationPlugin
{
    internal sealed class Cr04SteelGradeInProcessSmokeRequest
    {
        private const string RequestVersion = "0.30.1";
        private const string RequestFileName = "cr04-steel-grade-in-process-smoke.request";
        private static readonly TimeSpan MaximumRequestAge = TimeSpan.FromMinutes(30);

        private Cr04SteelGradeInProcessSmokeRequest(string evidenceFile, string partFile)
        {
            EvidenceFile = evidenceFile;
            PartFile = partFile;
        }

        internal string EvidenceFile { get; }
        internal string PartFile { get; }

        internal static bool TryConsume(out Cr04SteelGradeInProcessSmokeRequest request, out string error)
        {
            request = null;
            error = string.Empty;

            string requestDirectory = Path.Combine(Path.GetTempPath(), "CimatronCustomization");
            string requestPath = Path.Combine(requestDirectory, RequestFileName);
            if (!File.Exists(requestPath))
                return false;

            string consumingPath = requestPath + ".consuming-" + Process.GetCurrentProcess().Id.ToString(CultureInfo.InvariantCulture);
            try
            {
                if (File.Exists(consumingPath))
                    File.Delete(consumingPath);
                File.Move(requestPath, consumingPath);
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                error = "The CR-04 steel-grade smoke request could not be consumed: " + exception.Message;
                return true;
            }

            try
            {
                string version = null;
                string requestedUtc = null;
                string evidenceFile = null;
                string partFile = null;

                foreach (string line in File.ReadAllLines(consumingPath))
                {
                    int separator = line.IndexOf('=');
                    if (separator <= 0)
                        continue;

                    string key = line.Substring(0, separator).Trim();
                    string value = line.Substring(separator + 1).Trim();
                    if (string.Equals(key, "Version", StringComparison.Ordinal))
                        version = value;
                    else if (string.Equals(key, "RequestedUtc", StringComparison.Ordinal))
                        requestedUtc = value;
                    else if (string.Equals(key, "EvidenceFile", StringComparison.Ordinal))
                        evidenceFile = value;
                    else if (string.Equals(key, "PartFile", StringComparison.Ordinal))
                        partFile = value;
                }

                if (!string.Equals(version, RequestVersion, StringComparison.Ordinal))
                {
                    error = "The request version is invalid.";
                    return true;
                }

                DateTimeOffset requestedUtcValue;
                if (!DateTimeOffset.TryParseExact(requestedUtc, "O", CultureInfo.InvariantCulture, DateTimeStyles.None, out requestedUtcValue))
                {
                    error = "RequestedUtc is missing or invalid.";
                    return true;
                }

                TimeSpan age = DateTimeOffset.UtcNow - requestedUtcValue.ToUniversalTime();
                if (age < TimeSpan.Zero || age > MaximumRequestAge)
                {
                    error = "The request is outside the 30-minute validity window.";
                    return true;
                }

                if (string.IsNullOrWhiteSpace(evidenceFile) || !Path.IsPathRooted(evidenceFile))
                {
                    error = "EvidenceFile must be an absolute path.";
                    return true;
                }

                if (string.IsNullOrWhiteSpace(partFile) || !Path.IsPathRooted(partFile) || !File.Exists(partFile))
                {
                    error = "PartFile must be an absolute path to the existing saved disposable Part file.";
                    return true;
                }

                request = new Cr04SteelGradeInProcessSmokeRequest(evidenceFile, partFile);
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                error = "The CR-04 steel-grade smoke request could not be read: " + exception.Message;
                return true;
            }
            finally
            {
                try
                {
                    if (File.Exists(consumingPath))
                        File.Delete(consumingPath);
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }
}
