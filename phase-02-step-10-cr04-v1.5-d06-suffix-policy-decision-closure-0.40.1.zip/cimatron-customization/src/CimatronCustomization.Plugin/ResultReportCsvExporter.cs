using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace CimatronCustomizationPlugin
{
    internal static class ResultReportCsvExporter
    {
        private static readonly char[] CsvSpecialCharacters = { ',', '"', '\r', '\n' };

        internal static void Export(
            string filePath,
            IEnumerable<ResultReportCsvRow> rows,
            string correlationId,
            ResultReportCsvSummary summary)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentException("CSV export path is required.", nameof(filePath));
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            if (summary == null) throw new ArgumentNullException(nameof(summary));

            string safeCorrelationId = correlationId ?? string.Empty;
            ResultReportCsvRow[] orderedRows = OrderRows(rows);
            using (StreamWriter writer = new StreamWriter(filePath, false, new UTF8Encoding(true)))
            {
                writer.WriteLine("ComponentTitle,OccurrencePath,InstanceId,PartType,MoldPartMaterial,ValidationStatus,FindingCode,Feature,Requirement,Message,Measured,Limit,CorrelationId");
                foreach (ResultReportCsvRow row in orderedRows)
                {
                    WriteRow(writer, row, safeCorrelationId);
                }

                writer.WriteLine();
                WriteSummaryRow(writer, "Total", summary.Total.ToString(CultureInfo.InvariantCulture), safeCorrelationId);
                WriteSummaryRow(writer, "PASS", summary.Passed.ToString(CultureInfo.InvariantCulture), safeCorrelationId);
                WriteSummaryRow(writer, "FAIL", summary.Failed.ToString(CultureInfo.InvariantCulture), safeCorrelationId);
                WriteSummaryRow(writer, "WARNING", summary.Warning.ToString(CultureInfo.InvariantCulture), safeCorrelationId);
                WriteSummaryRow(writer, "NOT FOUND", summary.NotFound.ToString(CultureInfo.InvariantCulture), safeCorrelationId);
                WriteSummaryRow(writer, "SKIPPED", summary.Skipped.ToString(CultureInfo.InvariantCulture), safeCorrelationId);
                WriteSummaryRow(writer, "INFO", summary.Info.ToString(CultureInfo.InvariantCulture), safeCorrelationId);
                WriteSummaryRow(writer, "Overall Status", summary.OverallStatus, safeCorrelationId);
            }
        }

        internal static string ExtractFindingCode(string message)
        {
            string text = message ?? string.Empty;
            if (text.Length < 3 || text[0] != '[')
            {
                return string.Empty;
            }

            int closing = text.IndexOf(']');
            return closing > 1 ? text.Substring(1, closing - 1) : string.Empty;
        }

        internal static string ClassifyStatus(string status, string findingCode)
        {
            if (string.Equals(findingCode, "DO_COMPONENT_NOT_FOUND", StringComparison.OrdinalIgnoreCase))
            {
                return "NOT FOUND";
            }

            if (string.Equals(findingCode, "CAD_NON_PART_SKIPPED", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(findingCode, "CAD_SYNTHETIC_ROOT_SKIPPED", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(findingCode, "CAD_COMPONENT_EXCLUDED", StringComparison.OrdinalIgnoreCase))
            {
                return "SKIPPED";
            }

            if (string.Equals(status, "Passed", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(status, "Succeeded", StringComparison.OrdinalIgnoreCase))
            {
                return "PASS";
            }

            if (string.Equals(status, "Failed", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(status, "Error", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(status, "Unsupported", StringComparison.OrdinalIgnoreCase))
            {
                return "FAIL";
            }

            if (string.Equals(status, "Warning", StringComparison.OrdinalIgnoreCase))
            {
                return "WARNING";
            }

            if (string.Equals(status, "Skipped", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(status, "NotApplicable", StringComparison.OrdinalIgnoreCase))
            {
                return "SKIPPED";
            }

            return "INFO";
        }

        internal static string Escape(string value)
        {
            string text = value ?? string.Empty;
            if (text.IndexOfAny(CsvSpecialCharacters) < 0)
            {
                return text;
            }

            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }

        private static ResultReportCsvRow[] OrderRows(IEnumerable<ResultReportCsvRow> rows)
        {
            ResultReportCsvRow[] materialized = rows.Where(row => row != null).ToArray();
            return materialized
                .OrderBy(row => row.OccurrenceOrder.HasValue ? 0 : 1)
                .ThenBy(row => row.OccurrenceOrder ?? int.MaxValue)
                .ThenBy(row => row.OriginalOrder)
                .ToArray();
        }

        private static void WriteRow(StreamWriter writer, ResultReportCsvRow row, string correlationId)
        {
            writer.Write(Escape(row.ComponentTitle));
            writer.Write(',');
            writer.Write(Escape(row.OccurrencePath));
            writer.Write(',');
            writer.Write(Escape(row.InstanceId));
            writer.Write(',');
            writer.Write(Escape(row.PartType));
            writer.Write(',');
            writer.Write(Escape(row.MoldPartMaterial));
            writer.Write(',');
            writer.Write(Escape(row.ValidationStatus));
            writer.Write(',');
            writer.Write(Escape(row.FindingCode));
            writer.Write(',');
            writer.Write(Escape(row.Feature));
            writer.Write(',');
            writer.Write(Escape(row.RequirementId));
            writer.Write(',');
            writer.Write(Escape(row.Message));
            writer.Write(',');
            writer.Write(Escape(row.Measured));
            writer.Write(',');
            writer.Write(Escape(row.Limit));
            writer.Write(',');
            writer.WriteLine(Escape(correlationId));
        }

        private static void WriteSummaryRow(StreamWriter writer, string name, string value, string correlationId)
        {
            writer.Write("Summary,,,,,");
            writer.Write(Escape(name));
            writer.Write(',');
            writer.Write(Escape(value));
            writer.Write(",,,,,");
            writer.WriteLine(Escape(correlationId));
        }
    }

    internal sealed class ResultReportCsvRow
    {
        internal ResultReportCsvRow(
            string componentTitle,
            string occurrencePath,
            string instanceId,
            string partType,
            string moldPartMaterial,
            string validationStatus,
            string findingCode,
            string feature,
            string requirementId,
            string message,
            string measured,
            string limit,
            int? occurrenceOrder,
            int originalOrder)
        {
            ComponentTitle = componentTitle ?? string.Empty;
            OccurrencePath = occurrencePath ?? string.Empty;
            InstanceId = instanceId ?? string.Empty;
            PartType = partType ?? string.Empty;
            MoldPartMaterial = moldPartMaterial ?? string.Empty;
            ValidationStatus = validationStatus ?? string.Empty;
            FindingCode = findingCode ?? string.Empty;
            Feature = feature ?? string.Empty;
            RequirementId = requirementId ?? string.Empty;
            Message = message ?? string.Empty;
            Measured = measured ?? string.Empty;
            Limit = limit ?? string.Empty;
            OccurrenceOrder = occurrenceOrder;
            OriginalOrder = originalOrder;
        }

        internal string ComponentTitle { get; }
        internal string OccurrencePath { get; }
        internal string InstanceId { get; }
        internal string PartType { get; }
        internal string MoldPartMaterial { get; }
        internal string ValidationStatus { get; }
        internal string FindingCode { get; }
        internal string Feature { get; }
        internal string RequirementId { get; }
        internal string Message { get; }
        internal string Measured { get; }
        internal string Limit { get; }
        internal int? OccurrenceOrder { get; }
        internal int OriginalOrder { get; }
    }

    internal sealed class ResultReportCsvSummary
    {
        internal ResultReportCsvSummary(
            int total,
            int passed,
            int failed,
            int warning,
            int notFound,
            int skipped,
            int info)
        {
            Total = total;
            Passed = passed;
            Failed = failed;
            Warning = warning;
            NotFound = notFound;
            Skipped = skipped;
            Info = info;
            OverallStatus = failed > 0 || warning > 0 || notFound > 0 ? "ACTION REQUIRED" : "PASS";
        }

        internal int Total { get; }
        internal int Passed { get; }
        internal int Failed { get; }
        internal int Warning { get; }
        internal int NotFound { get; }
        internal int Skipped { get; }
        internal int Info { get; }
        internal string OverallStatus { get; }
    }
}
