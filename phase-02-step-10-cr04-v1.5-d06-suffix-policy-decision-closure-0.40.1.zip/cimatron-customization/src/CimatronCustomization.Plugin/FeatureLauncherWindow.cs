using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using CimatronCustomization.Application;
using CimatronCustomization.DesignChecks;

namespace CimatronCustomizationPlugin
{
    internal sealed class FeatureLauncherWindow : Form
    {
        private readonly ExecuteFeatureChecklist checklistExecutor;
        private readonly StartupDiagnosticsReport diagnostics;
        private readonly CimatronSessionSnapshot session;
        private readonly string cimatronVersion;
        private readonly IViewportEntityHighlighter viewportEntityHighlighter;
        private readonly IViewportEntityPicker viewportEntityPicker;
        private CancellationTokenSource pickCancellation;
        private readonly IntPtr cimatronWindowHandle;
        private readonly System.Windows.Forms.Timer foregroundMonitor;
        private readonly TreeView featureTree;
        private readonly Label detailsLabel;
        private bool isClosing;
        private bool cimatronWasForeground;

        internal FeatureLauncherWindow(
            FeatureAvailability[] features,
            ExecuteFeatureChecklist checklistExecutor,
            StartupDiagnosticsReport diagnostics,
            CimatronSessionSnapshot session,
            string cimatronVersion,
            IViewportEntityHighlighter viewportEntityHighlighter,
            IViewportEntityPicker viewportEntityPicker,
            IntPtr cimatronWindowHandle)
        {
            if (features == null) throw new ArgumentNullException(nameof(features));
            this.checklistExecutor = checklistExecutor ?? throw new ArgumentNullException(nameof(checklistExecutor));
            this.diagnostics = diagnostics ?? throw new ArgumentNullException(nameof(diagnostics));
            this.session = session ?? throw new ArgumentNullException(nameof(session));
            this.cimatronVersion = cimatronVersion ?? string.Empty;
            this.viewportEntityHighlighter = viewportEntityHighlighter ?? throw new ArgumentNullException(nameof(viewportEntityHighlighter));
            this.viewportEntityPicker = viewportEntityPicker ?? throw new ArgumentNullException(nameof(viewportEntityPicker));
            this.cimatronWindowHandle = cimatronWindowHandle;

            foregroundMonitor = new System.Windows.Forms.Timer { Interval = 250 };
            foregroundMonitor.Tick += ForegroundMonitorTick;

            Text = "Cimatron Customization — Feature Launcher";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(760, 520);
            Size = new Size(860, 600);
            Font = SystemFonts.MessageBoxFont;

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(10)
            };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(root);

            Label heading = new Label
            {
                AutoSize = true,
                Text = "Select one feature or check several features to run as a checklist.",
                Margin = new Padding(3, 3, 3, 10)
            };
            root.Controls.Add(heading, 0, 0);

            featureTree = new TreeView
            {
                Dock = DockStyle.Fill,
                CheckBoxes = true,
                HideSelection = false
            };
            featureTree.BeforeCheck += FeatureTreeBeforeCheck;
            featureTree.AfterCheck += FeatureTreeAfterCheck;
            featureTree.AfterSelect += FeatureTreeAfterSelect;
            featureTree.NodeMouseDoubleClick += FeatureTreeNodeMouseDoubleClick;
            root.Controls.Add(featureTree, 0, 1);

            detailsLabel = new Label
            {
                AutoSize = true,
                MaximumSize = new Size(800, 0),
                Text = "Select a feature to see requirement and applicability details.",
                Margin = new Padding(3, 8, 3, 8)
            };
            root.Controls.Add(detailsLabel, 0, 2);

            FlowLayoutPanel buttons = new FlowLayoutPanel
            {
                AutoSize = true,
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false
            };
            Button close = new Button { Text = "Close", AutoSize = true };
            close.Click += delegate { Close(); };
            Button runSelected = new Button { Text = "Run Selected", AutoSize = true };
            runSelected.Click += delegate { RunCheckedFeatures(); };
            Button runFeature = new Button { Text = "Run Feature", AutoSize = true };
            runFeature.Click += delegate { RunCurrentFeature(); };
            Button startup = new Button { Text = "Startup Diagnostics", AutoSize = true };
            startup.Click += delegate { ShowStartupDiagnostics(); };
            Button pickEntity = new Button { Text = "Pick Entity (Part)", AutoSize = true };
            pickEntity.Click += delegate { StartPartPick(); };
            buttons.Controls.Add(close);
            buttons.Controls.Add(runSelected);
            buttons.Controls.Add(runFeature);
            buttons.Controls.Add(startup);
            buttons.Controls.Add(pickEntity);
            root.Controls.Add(buttons, 0, 3);

            PopulateTree(features);
            FormClosing += delegate { isClosing = true; CancelPickForOwnerClose(); };
            FormClosed += delegate { foregroundMonitor.Stop(); foregroundMonitor.Dispose(); };
        }

        internal void ShowOwnedByCimatron()
        {
            if (cimatronWindowHandle != IntPtr.Zero)
            {
                Show(new WindowHandleOwner(cimatronWindowHandle));
            }
            else
            {
                Show();
            }

            cimatronWasForeground = IsCurrentProcessForeground();
            foregroundMonitor.Start();
        }

        internal void RestoreToFront()
        {
            if (isClosing || IsDisposed)
            {
                return;
            }

            if (!Visible)
            {
                Show();
            }
            if (WindowState == FormWindowState.Minimized)
            {
                WindowState = FormWindowState.Normal;
            }

            BringToFront();
            Activate();
        }

        private void ForegroundMonitorTick(object sender, EventArgs e)
        {
            bool currentProcessForeground = IsCurrentProcessForeground();
            if (currentProcessForeground && !cimatronWasForeground && Visible && Enabled && !viewportEntityPicker.IsActive)
            {
                RestoreToFront();
            }
            cimatronWasForeground = currentProcessForeground;
        }

        private static bool IsCurrentProcessForeground()
        {
            IntPtr foregroundWindow = GetForegroundWindow();
            if (foregroundWindow == IntPtr.Zero)
            {
                return false;
            }

            uint processId;
            uint foregroundThreadId = GetWindowThreadProcessId(foregroundWindow, out processId);
            if (foregroundThreadId == 0)
            {
                return false;
            }

            return processId == (uint)Process.GetCurrentProcess().Id;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        private void PopulateTree(IEnumerable<FeatureAvailability> features)
        {
            Dictionary<string, TreeNode> kindNodes = new Dictionary<string, TreeNode>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, TreeNode> groupNodes = new Dictionary<string, TreeNode>(StringComparer.OrdinalIgnoreCase);

            foreach (FeatureAvailability feature in features)
            {
                string kindKey = feature.Kind.ToString();
                TreeNode kindNode;
                if (!kindNodes.TryGetValue(kindKey, out kindNode))
                {
                    kindNode = new TreeNode(kindKey);
                    kindNodes.Add(kindKey, kindNode);
                    featureTree.Nodes.Add(kindNode);
                }

                string groupKey = kindKey + "|" + feature.FunctionalGroup;
                TreeNode groupNode;
                if (!groupNodes.TryGetValue(groupKey, out groupNode))
                {
                    groupNode = new TreeNode(feature.FunctionalGroup);
                    groupNodes.Add(groupKey, groupNode);
                    kindNode.Nodes.Add(groupNode);
                }

                TreeNode featureNode = new TreeNode(feature.Name + "  [" + feature.RequirementIdsText + "]")
                {
                    Tag = feature,
                    ForeColor = feature.IsApplicable ? SystemColors.WindowText : SystemColors.GrayText
                };
                groupNode.Nodes.Add(featureNode);
            }

            featureTree.ExpandAll();
        }

        private void FeatureTreeBeforeCheck(object sender, TreeViewCancelEventArgs e)
        {
            FeatureAvailability feature = e.Node.Tag as FeatureAvailability;
            if (feature == null || !feature.IsApplicable)
            {
                e.Cancel = true;
            }
        }

        private void FeatureTreeAfterCheck(object sender, TreeViewEventArgs e)
        {
            FeatureAvailability feature = e.Node.Tag as FeatureAvailability;
            if (feature != null)
            {
                featureTree.SelectedNode = e.Node;
            }
        }

        private void FeatureTreeAfterSelect(object sender, TreeViewEventArgs e)
        {
            FeatureAvailability feature = e.Node.Tag as FeatureAvailability;
            if (feature == null)
            {
                detailsLabel.Text = "Select a feature to see requirement and applicability details.";
                return;
            }

            detailsLabel.Text =
                "Requirements: " + feature.RequirementIdsText + Environment.NewLine +
                "Document context: " + feature.RequiredDocumentContextText + Environment.NewLine +
                "Availability: " + feature.Reason;
        }

        private void FeatureTreeNodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            FeatureAvailability feature = e.Node.Tag as FeatureAvailability;
            if (feature != null && feature.IsApplicable)
            {
                RunFeatures(new[] { feature.FeatureId });
            }
        }

        private void RunCurrentFeature()
        {
            FeatureAvailability feature = featureTree.SelectedNode == null ? null : featureTree.SelectedNode.Tag as FeatureAvailability;
            if (feature == null)
            {
                MessageBox.Show(this, "Select a feature first.", "Cimatron Customization", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!feature.IsApplicable)
            {
                MessageBox.Show(this, feature.Reason, "Feature Not Applicable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            RunFeatures(new[] { feature.FeatureId });
        }

        private void RunCheckedFeatures()
        {
            List<string> ids = new List<string>();
            foreach (TreeNode kindNode in featureTree.Nodes)
            {
                foreach (TreeNode groupNode in kindNode.Nodes)
                {
                    foreach (TreeNode featureNode in groupNode.Nodes)
                    {
                        FeatureAvailability feature = featureNode.Tag as FeatureAvailability;
                        if (feature != null && feature.IsApplicable && featureNode.Checked)
                        {
                            ids.Add(feature.FeatureId);
                        }
                    }
                }
            }

            if (ids.Count == 0)
            {
                MessageBox.Show(this, "Check one or more applicable features first.", "Cimatron Customization", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            RunFeatures(ids);
        }

        private void RunFeatures(IEnumerable<string> featureIds)
        {
            List<string> selectedFeatureIds = new List<string>(featureIds);
            FeatureRunInputs runInputs = null;
            if (selectedFeatureIds.Contains(SteelGradeDesignOrderValidation.FeatureId))
            {
                string designOrderPath;
                if (!TrySelectCr04DesignOrder(out designOrderPath))
                {
                    return;
                }

                runInputs = new FeatureRunInputs(new Dictionary<string, object>
                {
                    { SteelGradeDesignOrderValidation.DesignOrderPathRunInput, designOrderPath }
                });
            }

            string correlationId = Guid.NewGuid().ToString("N");
            FeatureChecklistReport checklist = checklistExecutor.Execute(
                selectedFeatureIds,
                session,
                cimatronVersion,
                correlationId,
                runInputs);
            using (FindingReportWindow reportWindow = new FindingReportWindow(checklist, viewportEntityHighlighter))
            {
                reportWindow.ShowDialog(this);
            }
        }

        private bool TrySelectCr04DesignOrder(out string designOrderPath)
        {
            designOrderPath = null;
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Select CR-04 Design Order Excel File";
                dialog.Filter = "Excel workbooks (*.xlsx;*.xls)|*.xlsx;*.xls";
                dialog.CheckFileExists = true;
                dialog.CheckPathExists = true;
                dialog.Multiselect = false;
                dialog.RestoreDirectory = true;

                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return false;
                }

                designOrderPath = dialog.FileName;
                return !string.IsNullOrWhiteSpace(designOrderPath);
            }
        }


        private void StartPartPick()
        {
            ViewportPickRequest request = new ViewportPickRequest(new[]
            {
                ViewportEntityType.Body,
                ViewportEntityType.Face,
                ViewportEntityType.Edge
            });

            if (viewportEntityPicker.IsActive)
            {
                viewportEntityPicker.BeginPick(request, CancellationToken.None, PresentPickResult);
                return;
            }

            if (pickCancellation != null)
            {
                pickCancellation.Dispose();
            }

            pickCancellation = new CancellationTokenSource();
            Hide();
            try
            {
                viewportEntityPicker.BeginPick(request, pickCancellation.Token, OnPrimaryViewportPickCompleted);
            }
            catch (Exception exception)
            {
                pickCancellation.Dispose();
                pickCancellation = null;
                Show();
                Activate();
                MessageBox.Show(
                    this,
                    "The production Part Pick could not be started safely." + Environment.NewLine + Environment.NewLine + exception.Message,
                    "Part Pick",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void OnPrimaryViewportPickCompleted(ViewportPickResult result)
        {
            CancellationTokenSource completedCancellation = pickCancellation;
            pickCancellation = null;
            if (completedCancellation != null)
            {
                completedCancellation.Dispose();
            }

            PresentPickResult(result);
        }

        private void PresentPickResult(ViewportPickResult result)
        {
            if (isClosing || IsDisposed || !IsHandleCreated)
            {
                return;
            }

            BeginInvoke((MethodInvoker)delegate
            {
                if (isClosing || IsDisposed)
                {
                    return;
                }

                RestoreToFront();
                ViewportPickResult validated = viewportEntityPicker.ValidateForCurrentDocument(result);
                string entityText = validated.EntityId.HasValue
                    ? Environment.NewLine + "Entity ID (source document/session only): " + validated.EntityId.Value +
                      Environment.NewLine + "Entity type: " + validated.EntityType
                    : string.Empty;
                string documentText = validated.SourceDocument == null
                    ? string.Empty
                    : Environment.NewLine + "Source document token: " + validated.SourceDocument.SessionDocumentToken +
                      (string.IsNullOrWhiteSpace(validated.SourceDocument.Title) ? string.Empty : Environment.NewLine + "Document: " + validated.SourceDocument.Title);
                string occurrenceText = validated.OccurrencePath.Count == 0
                    ? string.Empty
                    : Environment.NewLine + "Occurrence path: " + string.Join(" / ", validated.OccurrencePath);

                PickResultDialog.ShowResult(
                    this,
                    "Part Pick — " + validated.Outcome,
                    validated.Message + entityText + documentText + occurrenceText +
                    Environment.NewLine + "Reason: " + validated.ReasonCode +
                    Environment.NewLine + "Correlation: " + validated.CorrelationId,
                    validated.Outcome == ViewportPickOutcome.Failed);

                RestoreCimatronAndLauncherFocus();
            });
        }

        private void CancelPickForOwnerClose()
        {
            CancellationTokenSource cancellation = pickCancellation;
            if (cancellation != null && !cancellation.IsCancellationRequested)
            {
                cancellation.Cancel();
            }
        }

        private void RestoreCimatronAndLauncherFocus()
        {
            if (isClosing || IsDisposed)
            {
                return;
            }

            if (cimatronWindowHandle != IntPtr.Zero)
            {
                SetForegroundWindow(cimatronWindowHandle);
            }

            RestoreToFront();
        }

        private void ShowStartupDiagnostics()
        {
            string message =
                "STARTUP DIAGNOSTICS" + Environment.NewLine + "---------------------------" + Environment.NewLine +
                "Product : " + diagnostics.Runtime.ProductName + Environment.NewLine +
                "Version : " + diagnostics.Runtime.Version + Environment.NewLine +
                "Config  : Schema " + diagnostics.ConfigurationSchemaVersion + Environment.NewLine +
                "Context : " + diagnostics.Runtime.Session.ActiveDocumentContext;
            MessageBox.Show(this, message, "Startup Diagnostics", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private sealed class WindowHandleOwner : IWin32Window
        {
            internal WindowHandleOwner(IntPtr handle)
            {
                Handle = handle;
            }

            public IntPtr Handle { get; private set; }
        }

        private sealed class PickResultDialog : Form
        {
            private PickResultDialog(string title, string message, bool isError)
            {
                Text = title;
                Icon = isError ? SystemIcons.Error : SystemIcons.Information;
                StartPosition = FormStartPosition.CenterParent;
                FormBorderStyle = FormBorderStyle.FixedDialog;
                MaximizeBox = false;
                MinimizeBox = false;
                ShowInTaskbar = false;
                TopMost = true;
                AutoScaleMode = AutoScaleMode.Font;
                Font = SystemFonts.MessageBoxFont;
                ClientSize = new Size(560, 260);

                Label messageLabel = new Label
                {
                    AutoSize = false,
                    Location = new Point(24, 24),
                    Size = new Size(506, 170),
                    Text = message
                };

                Button okButton = new Button
                {
                    Text = "OK",
                    DialogResult = DialogResult.OK,
                    Size = new Size(90, 30),
                    Location = new Point(440, 216)
                };

                AcceptButton = okButton;
                CancelButton = okButton;
                Controls.Add(messageLabel);
                Controls.Add(okButton);
            }

            public static void ShowResult(IWin32Window owner, string title, string message, bool isError)
            {
                using (PickResultDialog dialog = new PickResultDialog(title, message, isError))
                {
                    dialog.ShowDialog(owner);
                }
            }
        }

    }
}
