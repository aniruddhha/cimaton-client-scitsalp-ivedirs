using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.Plugin")]
[assembly: AssemblyDescription("Official-template-compatible Cimatron plugin baseline")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a12403f0-bf2b-4ce2-903d-e8625e3f1272")]
[assembly: AssemblyVersion("0.40.0.0")]
[assembly: AssemblyFileVersion("0.40.0.0")]
