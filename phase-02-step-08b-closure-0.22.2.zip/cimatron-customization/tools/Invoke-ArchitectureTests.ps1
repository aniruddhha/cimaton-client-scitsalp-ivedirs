Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$exe = Join-Path $repoRoot 'tests\CimatronCustomization.ArchitectureTests\bin\x64\Release\CimatronCustomization.ArchitectureTests.exe'
if (-not (Test-Path $exe)) {
    throw "ArchitectureTests Release executable was not found: $exe. Run the Release x64 build first."
}

& $exe
if ($LASTEXITCODE -ne 0) {
    throw "ArchitectureTests failed with exit code $LASTEXITCODE."
}
