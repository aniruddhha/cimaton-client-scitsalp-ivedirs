using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    /// <summary>
    /// Step 05C2 development-only controlled validation of the exact native
    /// Cimatron "Display / Zoom Selection" command discovered in Step 05C1.
    /// This is not production Zoom-to-result behavior.
    /// </summary>
    internal static class ZoomSelectionValidation
    {
        private const string ZoomCategoryName = "&Display";
        private const string ZoomCommandName = "Zoom Selection";

        internal static int Run(string expectedContext, int entityId)
        {
            object appAccessObject = null;
            object applicationObject = null;
            object activeDocumentObject = null;
            object previousSelectionObject = null;
            object validationSelectionObject = null;
            object poolCommandsObject = null;
            object commandObject = null;

            try
            {
                appAccessObject = new interop.CimAppAccess.AppAccess();
                applicationObject = ((interop.CimAppAccess.AppAccess)appAccessObject).GetApplication();
                if (applicationObject == null)
                {
                    Console.Error.WriteLine("ZOOM SELECTION VALIDATION: Cimatron is not running or is unavailable.");
                    return 2;
                }

                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)applicationObject;
                activeDocumentObject = application.GetActiveDoc();
                if (activeDocumentObject == null)
                {
                    Console.Error.WriteLine("ZOOM SELECTION VALIDATION: Cimatron has no active document.");
                    return 4;
                }

                interop.CimatronE.ICimDocument activeDocument = (interop.CimatronE.ICimDocument)activeDocumentObject;
                string documentType = activeDocument.Type.ToString();
                string normalizedContext = NormalizeDocumentContext(documentType);
                if (!string.Equals(expectedContext, normalizedContext, StringComparison.OrdinalIgnoreCase))
                {
                    Console.Error.WriteLine(
                        "ZOOM SELECTION VALIDATION: active document context is " + normalizedContext +
                        ", expected " + expectedContext + ".");
                    return 4;
                }

                interop.CimMdlrAPI.ISelection selection = activeDocument as interop.CimMdlrAPI.ISelection;
                if (selection == null)
                {
                    Console.Error.WriteLine("ZOOM SELECTION VALIDATION: active document does not expose ISelection.");
                    return 4;
                }

                interop.CimMdlrAPI.IModelContainer container = activeDocument as interop.CimMdlrAPI.IModelContainer;
                if (container == null)
                {
                    Console.Error.WriteLine("ZOOM SELECTION VALIDATION: active document does not expose IModelContainer.");
                    return 4;
                }

                interop.CimMdlrAPI.IModel model = container.Model as interop.CimMdlrAPI.IModel;
                if (model == null)
                {
                    Console.Error.WriteLine("ZOOM SELECTION VALIDATION: active document does not expose an active model.");
                    return 4;
                }

                interop.CimMdlrAPI.ICimEntity entity = model.GetEntityById(entityId, model);
                if (entity == null)
                {
                    Console.Error.WriteLine(
                        "ZOOM SELECTION VALIDATION: entity " + entityId.ToString(CultureInfo.InvariantCulture) +
                        " is not available in the active model.");
                    return 4;
                }

                previousSelectionObject = selection.Selection;
                interop.CimMdlrAPI.ICimEntityList validationSelection =
                    (interop.CimMdlrAPI.ICimEntityList)new interop.CimBaseAPI.CimEntityList();
                validationSelectionObject = validationSelection;
                validationSelection.Add(entity);
                selection.Selection = validationSelection;

                poolCommandsObject = application.GetPoolCommands();
                if (poolCommandsObject == null)
                {
                    Console.Error.WriteLine("ZOOM SELECTION VALIDATION: GetPoolCommands returned null.");
                    return 4;
                }

                interop.CimBaseAPI.IPoolCommands poolCommands = (interop.CimBaseAPI.IPoolCommands)poolCommandsObject;
                commandObject = poolCommands.GetCommand(ZoomCategoryName, ZoomCommandName);
                if (commandObject == null)
                {
                    Console.Error.WriteLine(
                        "ZOOM SELECTION VALIDATION: native command was not resolved: " +
                        ZoomCategoryName + "," + ZoomCommandName + ".");
                    return 4;
                }

                interop.CimBaseAPI.ICimCommand zoomSelectionCommand = (interop.CimBaseAPI.ICimCommand)commandObject;
                zoomSelectionCommand.Execute();

                StringBuilder output = new StringBuilder();
                output.AppendLine("CIMATRON CONTROLLED ZOOM SELECTION VALIDATION");
                output.AppendLine("ToolVersion: 0.15.10");
                output.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O"));
                output.AppendLine("CimatronProduct: " + Safe(application.ProductName));
                output.AppendLine("CimatronVersion: " + Safe(application.Version));
                output.AppendLine("ActiveDocumentType: " + documentType);
                output.AppendLine("ActiveContext: " + normalizedContext);
                output.AppendLine("ModelPID: " + Safe(model.PID));
                output.AppendLine("EntityId: " + entityId.ToString(CultureInfo.InvariantCulture));
                output.AppendLine("CommandCategory: " + ZoomCategoryName);
                output.AppendLine("CommandName: " + ZoomCommandName);
                output.AppendLine("CommandExecutionReturned: TRUE");
                output.AppendLine("ProductionIntegration: FALSE");
                output.AppendLine("VisualResult: AWAITING USER OBSERVATION");

                string evidencePath = EvidenceWriter.Write(
                    "zoom-selection-validation-" + normalizedContext.ToLowerInvariant(),
                    output.ToString());

                Console.WriteLine("ZOOM SELECTION VALIDATION: COMMAND RETURNED");
                Console.WriteLine("Active context: " + normalizedContext + " (" + documentType + ")");
                Console.WriteLine("Entity ID: " + entityId.ToString(CultureInfo.InvariantCulture));
                Console.WriteLine("Executed: " + ZoomCategoryName + "," + ZoomCommandName);
                Console.WriteLine("Evidence file: " + evidencePath);
                Console.WriteLine("Observe Cimatron now and report whether the selected entity was visibly framed/zoomed.");
                return 0;
            }
            catch (COMException exception)
            {
                Console.Error.WriteLine("ZOOM SELECTION VALIDATION: standalone attach/COM failure.");
                Console.Error.WriteLine(exception);
                return 3;
            }
            catch (InvalidCastException exception)
            {
                Console.Error.WriteLine("ZOOM SELECTION VALIDATION: installed Interop contract mismatch.");
                Console.Error.WriteLine(exception);
                return 4;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("ZOOM SELECTION VALIDATION: unexpected failure.");
                Console.Error.WriteLine(exception);
                return 1;
            }
            finally
            {
                try
                {
                    RestorePreviousSelection(activeDocumentObject, previousSelectionObject);
                }
                finally
                {
                    ReleaseComObject(commandObject);
                    ReleaseComObject(poolCommandsObject);
                    ReleaseComObject(validationSelectionObject);
                    ReleaseComObject(previousSelectionObject);
                    ReleaseComObject(activeDocumentObject);
                    ReleaseComObject(applicationObject);
                    ReleaseComObject(appAccessObject);
                }
            }
        }

        private static void RestorePreviousSelection(object activeDocumentObject, object previousSelectionObject)
        {
            if (activeDocumentObject == null)
            {
                return;
            }

            interop.CimMdlrAPI.ISelection selection = activeDocumentObject as interop.CimMdlrAPI.ISelection;
            if (selection == null)
            {
                return;
            }

            if (previousSelectionObject != null)
            {
                selection.Selection = (interop.CimMdlrAPI.ICimEntityList)previousSelectionObject;
                return;
            }

            interop.CimMdlrAPI.ICimEntityList emptySelection =
                (interop.CimMdlrAPI.ICimEntityList)new interop.CimBaseAPI.CimEntityList();
            selection.Selection = emptySelection;
            ReleaseComObject(emptySelection);
        }

        private static string NormalizeDocumentContext(string documentType)
        {
            if (string.Equals(documentType, "cmPart", StringComparison.Ordinal)) return "Part";
            if (string.Equals(documentType, "cmAssembly", StringComparison.Ordinal)) return "Assembly";
            if (string.Equals(documentType, "cmNc", StringComparison.Ordinal)) return "Nc";
            return "Unsupported";
        }

        private static string Safe(string value)
        {
            return value ?? string.Empty;
        }

        private static void ReleaseComObject(object value)
        {
            if (value != null && Marshal.IsComObject(value))
            {
                Marshal.FinalReleaseComObject(value);
            }
        }
    }
}
