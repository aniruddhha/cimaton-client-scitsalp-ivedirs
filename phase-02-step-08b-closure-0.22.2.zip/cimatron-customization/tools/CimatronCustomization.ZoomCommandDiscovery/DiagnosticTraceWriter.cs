using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Security.Principal;
using System.Threading;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    /// <summary>
    /// Development-only durable trace used to isolate standalone diagnostic startup/dispatch hangs.
    /// Each record is append-written with write-through and the file is closed before control returns.
    /// </summary>
    internal static class DiagnosticTraceWriter
    {
        private const int HeartbeatIntervalMilliseconds = 3000;
        private static readonly object SyncRoot = new object();
        private static readonly ManualResetEvent HeartbeatStop = new ManualResetEvent(false);
        private static string tracePath;
        private static string lastCheckpoint = "none";
        private static Thread heartbeatThread;

        internal static string TracePath
        {
            get { return tracePath ?? string.Empty; }
        }

        internal static bool IsCurrentProcessElevated
        {
            get { return IsElevated(); }
        }

        internal static void Initialize()
        {
            string root = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string directory = Path.Combine(root, "CimatronCustomization", "diagnostics");
            Directory.CreateDirectory(directory);

            int processId = Process.GetCurrentProcess().Id;
            string fileName = "zoom-discovery-" +
                DateTimeOffset.Now.ToString("yyyyMMdd-HHmmssfff", CultureInfo.InvariantCulture) +
                "-pid" + processId.ToString(CultureInfo.InvariantCulture) + ".log";
            tracePath = Path.Combine(directory, fileName);

            WriteLine("Main entered");
            WriteLine("Trace initialized: " + tracePath);
            WriteLine("ProcessId: " + processId.ToString(CultureInfo.InvariantCulture));
            WriteLine("CommandLine: " + Environment.CommandLine);
            WriteLine("Elevated: " + IsElevated().ToString());
            WriteLine("ApartmentState: " + Thread.CurrentThread.GetApartmentState());
        }

        internal static void StartHeartbeat()
        {
            lock (SyncRoot)
            {
                if (heartbeatThread != null)
                {
                    return;
                }

                heartbeatThread = new Thread(HeartbeatLoop);
                heartbeatThread.IsBackground = true;
                heartbeatThread.Name = "ZoomDiscoveryDiagnosticHeartbeat";
                heartbeatThread.Start();
            }
        }

        internal static void StopHeartbeat()
        {
            HeartbeatStop.Set();
            Thread thread;
            lock (SyncRoot)
            {
                thread = heartbeatThread;
            }

            if (thread != null && thread.IsAlive)
            {
                thread.Join(1000);
            }
        }

        internal static void SetLastCheckpoint(string checkpoint)
        {
            lock (SyncRoot)
            {
                lastCheckpoint = checkpoint ?? string.Empty;
            }
        }

        internal static void WriteLine(string message)
        {
            if (string.IsNullOrEmpty(tracePath))
            {
                return;
            }

            string record = DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture) +
                " [pid=" + Process.GetCurrentProcess().Id.ToString(CultureInfo.InvariantCulture) + "] " +
                (message ?? string.Empty) + Environment.NewLine;
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(record);

            lock (SyncRoot)
            {
                using (FileStream stream = new FileStream(
                    tracePath,
                    FileMode.Append,
                    FileAccess.Write,
                    FileShare.ReadWrite,
                    4096,
                    FileOptions.WriteThrough))
                {
                    stream.Write(bytes, 0, bytes.Length);
                    stream.Flush(true);
                }
            }
        }

        private static void HeartbeatLoop()
        {
            while (!HeartbeatStop.WaitOne(HeartbeatIntervalMilliseconds))
            {
                try
                {
                    string checkpoint;
                    lock (SyncRoot)
                    {
                        checkpoint = lastCheckpoint;
                    }

                    WriteLine("HEARTBEAT alive; lastCheckpoint=" + checkpoint);
                }
                catch (Exception exception)
                {
                    Console.Error.WriteLine("ZOOM COMMAND DISCOVERY TRACE: heartbeat write failed: " + exception.Message);
                    return;
                }
            }
        }

        private static bool IsElevated()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }
    }
}
