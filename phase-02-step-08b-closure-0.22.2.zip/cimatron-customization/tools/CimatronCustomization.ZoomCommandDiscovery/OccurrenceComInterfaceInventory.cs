using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    /// <summary>
    /// Step 05C2-B final hidden-state diagnostic.
    /// Enumerates installed Interop COM interface IIDs, asks three known-answer occurrence RCWs
    /// which IIDs they support via Marshal.QueryInterface, and immediately releases every
    /// successful QueryInterface pointer. Newly discovered interface members are reflected only;
    /// no member discovered by this diagnostic is invoked.
    /// </summary>
    internal static class OccurrenceComInterfaceInventory
    {
        private const string ToolVersion = "0.15.36";
        private const int S_OK = 0;
        private static readonly string[] VisibilityTerms =
        {
            "Show", "Visible", "Visibility", "Hidden", "Hide", "Blank", "Display", "State"
        };

        [ComImport]
        [Guid("B196B283-BAB4-101A-B69C-00AA00341D07")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IProvideClassInfo
        {
            void GetClassInfo(out ITypeInfo typeInfo);
        }

        [ComImport]
        [Guid("00020400-0000-0000-C000-000000000046")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDispatchTypeInfo
        {
            [PreserveSig]
            int GetTypeInfoCount(out uint count);

            [PreserveSig]
            int GetTypeInfo(uint index, uint lcid, out ITypeInfo typeInfo);
        }

        internal static int Run()
        {
            object appAccessObject = null;
            object applicationObject = null;
            object activeDocumentObject = null;

            try
            {
                string programDirectory = AppDomain.CurrentDomain.BaseDirectory;
                List<InterfaceDescriptor> interfaces = CollectInstalledInterfaceDescriptors(programDirectory);
                if (interfaces.Count == 0)
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: no COM interface IIDs were found in installed interop.Cim*.dll files.");
                    return 1;
                }

                appAccessObject = new interop.CimAppAccess.AppAccess();
                applicationObject = ((interop.CimAppAccess.AppAccess)appAccessObject).GetApplication();
                if (applicationObject == null)
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: Cimatron is not running or is unavailable.");
                    return 2;
                }

                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)applicationObject;
                activeDocumentObject = application.GetActiveDoc();
                if (activeDocumentObject == null)
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: Cimatron has no active document.");
                    return 4;
                }

                interop.CimatronE.ICimDocument activeDocument = (interop.CimatronE.ICimDocument)activeDocumentObject;
                if (!string.Equals(activeDocument.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: active document must be cmAssembly.");
                    return 4;
                }

                MutationSnapshot before = CaptureSnapshot(activeDocument);
                interop.CimMdlrAPI.IModelContainer container = activeDocument as interop.CimMdlrAPI.IModelContainer;
                if (container == null)
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: active Assembly does not expose IModelContainer.");
                    return 4;
                }

                interop.CimMdlrAPI.IAssemblyModel assemblyModel = container.Model as interop.CimMdlrAPI.IAssemblyModel;
                if (assemblyModel == null)
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: active Assembly does not expose IAssemblyModel.");
                    return 4;
                }

                interop.CimMdlrAPI.AssInstance root = assemblyModel.GetRootInstance();
                if (root == null)
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: GetRootInstance returned null.");
                    return 4;
                }

                List<TargetOccurrence> targets = LocateKnownAnswerTargets((interop.CimMdlrAPI.IAssInstance)root);
                if (targets.Count != 3)
                {
                    Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: required known-answer targets were not all found with expected suppression states.");
                    foreach (TargetOccurrence target in targets)
                    {
                        Console.Error.WriteLine("  Found: " + target.Label + " at " + target.Path);
                    }
                    return 4;
                }

                foreach (TargetOccurrence target in targets)
                {
                    target.ComClassEvidence = ReadComClassEvidence(target.RuntimeObject);
                    ProbeInterfaces(target, interfaces);
                }

                MutationSnapshot after = CaptureSnapshot(activeDocument);
                bool unchanged = MutationSnapshot.IsEquivalent(before, after);
                string evidence = BuildEvidence(programDirectory, interfaces, targets, before, after, unchanged);
                string evidencePath = EvidenceWriter.Write("occurrence-com-interface-matrix", evidence);

                int newlyMissedSupported = CountSupportedInterfacesMissedByNameSearch(interfaces, targets);
                bool identicalSets = HaveIdenticalSupportedSets(targets);

                Console.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: SUCCESS");
                Console.WriteLine("ToolVersion: " + ToolVersion);
                Console.WriteLine("Unique interface IIDs queried per object: " + interfaces.Count.ToString(CultureInfo.InvariantCulture));
                Console.WriteLine("Known-answer objects: 3");
                Console.WriteLine("Interface sets identical: " + identicalSets.ToString());
                Console.WriteLine("Supported interfaces missed by prior visibility name search: " + newlyMissedSupported.ToString(CultureInfo.InvariantCulture));
                Console.WriteLine("No-mutation evidence: " + (unchanged ? "UNCHANGED" : "CHANGED/UNVERIFIED"));
                Console.WriteLine("Findings file: " + evidencePath);
                return unchanged ? 0 : 8;
            }
            catch (COMException exception)
            {
                Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: COM failure.");
                Console.Error.WriteLine(exception);
                return 3;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("OCCURRENCE COM INTERFACE INVENTORY: unexpected failure.");
                Console.Error.WriteLine(exception);
                return 1;
            }
            finally
            {
                ReleaseComObject(activeDocumentObject);
                ReleaseComObject(applicationObject);
                ReleaseComObject(appAccessObject);
            }
        }

        private static List<InterfaceDescriptor> CollectInstalledInterfaceDescriptors(string programDirectory)
        {
            string[] paths = Directory.GetFiles(programDirectory, "interop.Cim*.dll")
                .OrderBy(value => value, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            ResolveEventHandler resolver = (sender, args) => ResolveReflectionOnlyAssembly(programDirectory, args.Name);
            AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += resolver;
            try
            {
                Dictionary<Guid, InterfaceDescriptor> byIid = new Dictionary<Guid, InterfaceDescriptor>();
                foreach (string path in paths)
                {
                    Assembly assembly = Assembly.ReflectionOnlyLoadFrom(path);
                    foreach (Type type in SafeGetTypes(assembly)
                        .Where(value => value.IsInterface)
                        .OrderBy(value => value.FullName, StringComparer.OrdinalIgnoreCase))
                    {
                        Guid iid = type.GUID;
                        if (iid == Guid.Empty)
                        {
                            continue;
                        }

                        InterfaceDescriptor descriptor;
                        if (!byIid.TryGetValue(iid, out descriptor))
                        {
                            descriptor = new InterfaceDescriptor(iid);
                            byIid.Add(iid, descriptor);
                        }

                        descriptor.Aliases.Add(new InterfaceAlias(
                            Path.GetFileName(path),
                            type.FullName ?? type.Name,
                            TypeMatchesPreviousVisibilityNameSearch(type)));

                        if (descriptor.ReflectedMembers.Count == 0)
                        {
                            foreach (string member in ReflectMemberClassifications(type))
                            {
                                descriptor.ReflectedMembers.Add(member);
                            }
                        }
                    }
                }

                return byIid.Values.OrderBy(value => value.Iid).ToList();
            }
            finally
            {
                AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve -= resolver;
            }
        }

        private static void ProbeInterfaces(TargetOccurrence target, IEnumerable<InterfaceDescriptor> interfaces)
        {
            IntPtr unknown = IntPtr.Zero;
            try
            {
                unknown = Marshal.GetIUnknownForObject(target.RuntimeObject);
                foreach (InterfaceDescriptor descriptor in interfaces)
                {
                    IntPtr supportedPointer = IntPtr.Zero;
                    int hresult = Marshal.QueryInterface(unknown, ref descriptor.IidForQuery, out supportedPointer);
                    bool supported = hresult == S_OK && supportedPointer != IntPtr.Zero;
                    target.Support[descriptor.Iid] = new InterfaceProbeResult(supported, hresult);
                    if (supportedPointer != IntPtr.Zero)
                    {
                        Marshal.Release(supportedPointer);
                    }
                }
            }
            finally
            {
                if (unknown != IntPtr.Zero)
                {
                    Marshal.Release(unknown);
                }
            }
        }

        private static List<TargetOccurrence> LocateKnownAnswerTargets(interop.CimMdlrAPI.IAssInstance root)
        {
            List<TargetOccurrence> targets = new List<TargetOccurrence>();
            TraverseForTargets(root, "root", 0, targets);

            TargetOccurrence visibleBlock = targets.FirstOrDefault(value =>
                string.Equals(value.ModelTitle, "Block_A", StringComparison.Ordinal) && value.Suppressed == 0);
            TargetOccurrence hiddenTarget = targets.FirstOrDefault(value =>
                string.Equals(value.ModelTitle, "Known_Pocket_Body", StringComparison.Ordinal) && value.Suppressed == 0);
            TargetOccurrence suppressedBlock = targets.FirstOrDefault(value =>
                string.Equals(value.ModelTitle, "Block_B", StringComparison.Ordinal) && value.Suppressed == 1);

            List<TargetOccurrence> selected = new List<TargetOccurrence>();
            if (visibleBlock != null)
            {
                visibleBlock.Label = "VISIBLE_Block_A";
                selected.Add(visibleBlock);
            }

            if (hiddenTarget != null)
            {
                hiddenTarget.Label = "HIDDEN_NOT_SUPPRESSED_Known_Pocket_Body";
                selected.Add(hiddenTarget);
            }

            if (suppressedBlock != null)
            {
                suppressedBlock.Label = "SUPPRESSED_Block_B";
                selected.Add(suppressedBlock);
            }

            return selected;
        }

        private static void TraverseForTargets(
            interop.CimMdlrAPI.IAssInstance instance,
            string path,
            int depth,
            ICollection<TargetOccurrence> targets)
        {
            if (depth > 16 || targets.Count > 2000)
            {
                return;
            }

            int id = instance.ID;
            int suppressed = instance.IsSuppressed;
            interop.CimMdlrAPI.IModel model = instance.Model;
            string title = model == null ? string.Empty : Safe(model.Title);
            targets.Add(new TargetOccurrence(path + ":" + id.ToString(CultureInfo.InvariantCulture), title, suppressed, instance));

            object rawChildren = instance.SubInstances[1, 0];
            Array children = rawChildren as Array;
            if (children == null)
            {
                return;
            }

            for (int index = 0; index < children.Length; index++)
            {
                interop.CimMdlrAPI.IAssInstance child = children.GetValue(index) as interop.CimMdlrAPI.IAssInstance;
                if (child == null)
                {
                    continue;
                }

                TraverseForTargets(
                    child,
                    path + "/ordinal-" + (index + 1).ToString(CultureInfo.InvariantCulture),
                    depth + 1,
                    targets);
            }
        }

        private static string ReadComClassEvidence(object runtimeObject)
        {
            List<string> evidence = new List<string>();

            try
            {
                IProvideClassInfo provideClassInfo = runtimeObject as IProvideClassInfo;
                if (provideClassInfo != null)
                {
                    ITypeInfo typeInfo;
                    provideClassInfo.GetClassInfo(out typeInfo);
                    evidence.Add("IProvideClassInfo=" + ReadTypeInfoName(typeInfo));
                    ReleaseComObject(typeInfo);
                }
                else
                {
                    evidence.Add("IProvideClassInfo=UNSUPPORTED");
                }
            }
            catch (Exception exception)
            {
                evidence.Add("IProvideClassInfo=ERROR " + FormatException(exception));
            }

            try
            {
                IDispatchTypeInfo dispatch = runtimeObject as IDispatchTypeInfo;
                if (dispatch == null)
                {
                    evidence.Add("IDispatch=UNSUPPORTED");
                }
                else
                {
                    uint count;
                    int countResult = dispatch.GetTypeInfoCount(out count);
                    if (countResult != S_OK || count == 0)
                    {
                        evidence.Add("IDispatch.GetTypeInfo=UNAVAILABLE HRESULT=" + FormatHResult(countResult) + " Count=" + count.ToString(CultureInfo.InvariantCulture));
                    }
                    else
                    {
                        ITypeInfo typeInfo;
                        int getResult = dispatch.GetTypeInfo(0, 0, out typeInfo);
                        if (getResult == S_OK && typeInfo != null)
                        {
                            evidence.Add("IDispatch.GetTypeInfo=" + ReadTypeInfoName(typeInfo));
                            ReleaseComObject(typeInfo);
                        }
                        else
                        {
                            evidence.Add("IDispatch.GetTypeInfo=ERROR HRESULT=" + FormatHResult(getResult));
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                evidence.Add("IDispatch=ERROR " + FormatException(exception));
            }

            return string.Join("; ", evidence);
        }

        private static string ReadTypeInfoName(ITypeInfo typeInfo)
        {
            if (typeInfo == null)
            {
                return "<null>";
            }

            string name;
            string documentation;
            int helpContext;
            string helpFile;
            typeInfo.GetDocumentation(-1, out name, out documentation, out helpContext, out helpFile);
            return string.IsNullOrEmpty(name) ? "<unnamed>" : name;
        }

        private static string BuildEvidence(
            string programDirectory,
            IList<InterfaceDescriptor> interfaces,
            IList<TargetOccurrence> targets,
            MutationSnapshot before,
            MutationSnapshot after,
            bool unchanged)
        {
            StringBuilder output = new StringBuilder();
            output.AppendLine("CIMATRON STEP 05C2-B FINAL OCCURRENCE COM INTERFACE DIAGNOSTIC");
            output.AppendLine("ToolVersion: " + ToolVersion);
            output.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O"));
            output.AppendLine("InteropDirectory: " + programDirectory);
            output.AppendLine("Method: enumerate all installed interop.Cim*.dll COM interface IIDs; Marshal.QueryInterface each unique IID once per known-answer occurrence; Marshal.Release each successful interface pointer immediately.");
            output.AppendLine("ClassIdentityMethod: IProvideClassInfo.GetClassInfo and IDispatch.GetTypeInfo where supported.");
            output.AppendLine("NewlyDiscoveredMemberInvocation: PROHIBITED / NOT CALLED");
            output.AppendLine("RuntimeMutation: PROHIBITED / NOT CALLED");
            output.AppendLine("EXPECTED: visible/hidden/suppressed occurrences likely expose identical COM interface sets because hidden state is normally data rather than interface identity.");
            output.AppendLine("StoppingRule: if this run exposes no new supported interface/member path, end reflection-based hidden-state discovery and record FR-021 as suppressed supported / hidden BLOCKED pending Cimatron guidance.");
            output.AppendLine("ScopeDecision: suppressed-only initial shipping, if required, is a client/product scope decision and is not made by this diagnostic.");
            output.AppendLine();

            output.AppendLine("NO-MUTATION EVIDENCE");
            output.AppendLine("Before: " + before);
            output.AppendLine("After : " + after);
            output.AppendLine("Result: " + (unchanged ? "UNCHANGED" : "CHANGED/UNVERIFIED"));
            output.AppendLine();

            output.AppendLine("KNOWN-ANSWER OBJECTS");
            foreach (TargetOccurrence target in targets)
            {
                output.AppendLine(target.Label + " | Path=" + target.Path + " | ModelTitle=" + target.ModelTitle + " | Suppressed=" + target.Suppressed.ToString(CultureInfo.InvariantCulture) + " | COMClass=" + target.ComClassEvidence);
            }
            output.AppendLine();

            output.AppendLine("INTERFACE IID CATALOG");
            output.AppendLine("IID | Aliases | PriorVisibilityNameSearchMatch");
            foreach (InterfaceDescriptor descriptor in interfaces)
            {
                output.AppendLine(descriptor.Iid.ToString("D") + " | " + descriptor.FormatAliases() + " | " + descriptor.MatchedPreviousVisibilityNameSearch.ToString());
            }
            output.AppendLine();

            output.AppendLine("INTERFACE x OBJECT SUPPORT MATRIX");
            output.Append("IID | Aliases");
            foreach (TargetOccurrence target in targets)
            {
                output.Append(" | " + target.Label);
            }
            output.AppendLine();

            foreach (InterfaceDescriptor descriptor in interfaces)
            {
                output.Append(descriptor.Iid.ToString("D") + " | " + descriptor.FormatAliases());
                foreach (TargetOccurrence target in targets)
                {
                    InterfaceProbeResult result = target.Support[descriptor.Iid];
                    output.Append(" | " + (result.Supported ? "SUPPORTED" : "NO") + "(" + FormatHResult(result.HResult) + ")");
                }
                output.AppendLine();
            }
            output.AppendLine();

            bool identicalSets = HaveIdenticalSupportedSets(targets);
            output.AppendLine("COMPARISON");
            output.AppendLine("InterfaceSetComparison: " + (identicalSets ? "IDENTICAL" : "DIFFERENT"));
            output.AppendLine("ExpectedOutcomeWasIdentical: True");
            output.AppendLine("SupportedInterfacesMissedByPriorVisibilityNameSearch: " + CountSupportedInterfacesMissedByNameSearch(interfaces, targets).ToString(CultureInfo.InvariantCulture));
            output.AppendLine();

            output.AppendLine("SUPPORTED INTERFACES MISSED BY PRIOR VISIBILITY NAME SEARCH — REFLECTION ONLY");
            foreach (InterfaceDescriptor descriptor in interfaces.Where(value =>
                !value.MatchedPreviousVisibilityNameSearch && targets.Any(target => target.Support[value.Iid].Supported)))
            {
                output.AppendLine("INTERFACE: IID=" + descriptor.Iid.ToString("D") + "; Aliases=" + descriptor.FormatAliases());
                foreach (string member in descriptor.ReflectedMembers)
                {
                    output.AppendLine("  " + member);
                }
            }
            output.AppendLine();

            output.AppendLine("ACCEPTANCE / STOP RULE");
            output.AppendLine("FR021SuppressedState: SUPPORTED by existing IsSuppressed evidence.");
            output.AppendLine("FR021HiddenState: remains OPEN for this diagnostic; do not infer hidden state from interface identity alone.");
            output.AppendLine("IfNoNewPathAfterAnalysis: STOP reflection search; record 'suppressed: supported; hidden: BLOCKED — pending Cimatron guidance'; propose Step 05C2-B closure with documented exception.");
            return output.ToString();
        }

        private static IEnumerable<string> ReflectMemberClassifications(Type type)
        {
            if (type == null)
            {
                yield return "ReflectionType=UNAVAILABLE";
                yield break;
            }

            foreach (MemberInfo member in type.GetMembers(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                .OrderBy(value => value.Name, StringComparer.OrdinalIgnoreCase)
                .ThenBy(value => value.MemberType.ToString(), StringComparer.OrdinalIgnoreCase))
            {
                yield return "Access=" + ClassifyMemberAccess(member) + "; Kind=" + member.MemberType + "; Signature=" + FormatMember(member);
            }
        }

        private static string ClassifyMemberAccess(MemberInfo member)
        {
            PropertyInfo property = member as PropertyInfo;
            if (property != null)
            {
                bool canRead = property.GetGetMethod() != null;
                bool canWrite = property.GetSetMethod() != null;
                if (canRead && canWrite)
                {
                    return "PROPERTY_GET+SET";
                }

                return canRead ? "PROPERTY_GET" : "PROPERTY_SET";
            }

            MethodInfo method = member as MethodInfo;
            if (method != null)
            {
                if (method.IsSpecialName && method.Name.StartsWith("get_", StringComparison.Ordinal))
                {
                    return "PROPERTY_GET_ACCESSOR";
                }

                if (method.IsSpecialName && method.Name.StartsWith("set_", StringComparison.Ordinal))
                {
                    return "PROPERTY_SET_ACCESSOR";
                }

                return "METHOD";
            }

            return member.MemberType.ToString().ToUpperInvariant();
        }

        private static string FormatMember(MemberInfo member)
        {
            PropertyInfo property = member as PropertyInfo;
            if (property != null)
            {
                return property.PropertyType.FullName + " " + property.Name + " { " +
                       (property.GetGetMethod() != null ? "get;" : string.Empty) +
                       (property.GetSetMethod() != null ? "set;" : string.Empty) + " }";
            }

            MethodInfo method = member as MethodInfo;
            if (method != null)
            {
                return (method.ReturnType == null ? "System.Void" : method.ReturnType.FullName) + " " + method.Name + "(" +
                       string.Join(", ", method.GetParameters().Select(value => value.ParameterType.FullName + " " + value.Name)) + ")";
            }

            return member.Name;
        }

        private static bool TypeMatchesPreviousVisibilityNameSearch(Type type)
        {
            if (MatchesTerms(type.FullName ?? type.Name))
            {
                return true;
            }

            return type.GetMembers(BindingFlags.Public | BindingFlags.Instance)
                .Any(member => MatchesTerms(member.Name));
        }

        private static bool MatchesTerms(string value)
        {
            return VisibilityTerms.Any(term => value.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static int CountSupportedInterfacesMissedByNameSearch(
            IEnumerable<InterfaceDescriptor> interfaces,
            IEnumerable<TargetOccurrence> targets)
        {
            return interfaces.Count(descriptor =>
                !descriptor.MatchedPreviousVisibilityNameSearch &&
                targets.Any(target => target.Support[descriptor.Iid].Supported));
        }

        private static bool HaveIdenticalSupportedSets(IList<TargetOccurrence> targets)
        {
            if (targets.Count < 2)
            {
                return true;
            }

            HashSet<Guid> first = new HashSet<Guid>(targets[0].Support.Where(value => value.Value.Supported).Select(value => value.Key));
            for (int index = 1; index < targets.Count; index++)
            {
                HashSet<Guid> current = new HashSet<Guid>(targets[index].Support.Where(value => value.Value.Supported).Select(value => value.Key));
                if (!first.SetEquals(current))
                {
                    return false;
                }
            }

            return true;
        }

        private static MutationSnapshot CaptureSnapshot(interop.CimatronE.ICimDocument activeDocument)
        {
            string path = Safe(activeDocument.GetPath());
            bool modified = activeDocument.IsModified();
            DateTime lastWriteUtc = DateTime.MinValue;
            long length = -1;
            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                FileInfo info = new FileInfo(path);
                lastWriteUtc = info.LastWriteTimeUtc;
                length = info.Length;
            }

            return new MutationSnapshot(path, modified, lastWriteUtc, length);
        }

        private static Assembly ResolveReflectionOnlyAssembly(string directory, string requestedName)
        {
            AssemblyName name = new AssemblyName(requestedName);
            string candidate = Path.Combine(directory, name.Name + ".dll");
            return File.Exists(candidate) ? Assembly.ReflectionOnlyLoadFrom(candidate) : null;
        }

        private static IEnumerable<Type> SafeGetTypes(Assembly assembly)
        {
            try
            {
                return assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException exception)
            {
                return exception.Types.Where(value => value != null);
            }
        }

        private static void ReleaseComObject(object value)
        {
            if (value != null && Marshal.IsComObject(value))
            {
                Marshal.ReleaseComObject(value);
            }
        }

        private static string Safe(string value)
        {
            return value ?? string.Empty;
        }

        private static string FormatException(Exception exception)
        {
            return exception.GetType().FullName + " HRESULT=" + FormatHResult(exception.HResult);
        }

        private static string FormatHResult(int value)
        {
            return "0x" + unchecked((uint)value).ToString("X8", CultureInfo.InvariantCulture);
        }

        private sealed class InterfaceDescriptor
        {
            internal InterfaceDescriptor(Guid iid)
            {
                Iid = iid;
                IidForQuery = iid;
                Aliases = new List<InterfaceAlias>();
            }

            internal Guid Iid { get; private set; }
            internal Guid IidForQuery;
            internal List<InterfaceAlias> Aliases { get; private set; }
            internal List<string> ReflectedMembers { get; private set; } = new List<string>();
            internal bool MatchedPreviousVisibilityNameSearch
            {
                get { return Aliases.Any(value => value.MatchedPreviousVisibilityNameSearch); }
            }

            internal string FormatAliases()
            {
                return string.Join("; ", Aliases.Select(value => value.AssemblyName + ":" + value.TypeName));
            }
        }

        private sealed class InterfaceAlias
        {
            internal InterfaceAlias(string assemblyName, string typeName, bool matchedPreviousVisibilityNameSearch)
            {
                AssemblyName = assemblyName;
                TypeName = typeName;
                MatchedPreviousVisibilityNameSearch = matchedPreviousVisibilityNameSearch;
            }

            internal string AssemblyName { get; private set; }
            internal string TypeName { get; private set; }
            internal bool MatchedPreviousVisibilityNameSearch { get; private set; }
        }

        private sealed class InterfaceProbeResult
        {
            internal InterfaceProbeResult(bool supported, int hResult)
            {
                Supported = supported;
                HResult = hResult;
            }

            internal bool Supported { get; private set; }
            internal int HResult { get; private set; }
        }

        private sealed class TargetOccurrence
        {
            internal TargetOccurrence(string path, string modelTitle, int suppressed, interop.CimMdlrAPI.IAssInstance runtimeObject)
            {
                Path = path;
                ModelTitle = modelTitle;
                Suppressed = suppressed;
                RuntimeObject = runtimeObject;
                Support = new Dictionary<Guid, InterfaceProbeResult>();
                Label = modelTitle;
            }

            internal string Label { get; set; }
            internal string Path { get; private set; }
            internal string ModelTitle { get; private set; }
            internal int Suppressed { get; private set; }
            internal object RuntimeObject { get; private set; }
            internal string ComClassEvidence { get; set; }
            internal Dictionary<Guid, InterfaceProbeResult> Support { get; private set; }
        }

        private sealed class MutationSnapshot
        {
            internal MutationSnapshot(string path, bool modified, DateTime lastWriteUtc, long length)
            {
                Path = path;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            internal string Path { get; private set; }
            internal bool Modified { get; private set; }
            internal DateTime LastWriteUtc { get; private set; }
            internal long Length { get; private set; }

            internal static bool IsEquivalent(MutationSnapshot left, MutationSnapshot right)
            {
                return left != null && right != null &&
                       string.Equals(left.Path, right.Path, StringComparison.OrdinalIgnoreCase) &&
                       left.Modified == right.Modified &&
                       left.LastWriteUtc == right.LastWriteUtc &&
                       left.Length == right.Length;
            }

            public override string ToString()
            {
                return "Path=" + Path + "; Modified=" + Modified.ToString() + "; LastWriteUtc=" + LastWriteUtc.ToString("O") + "; Length=" + Length.ToString(CultureInfo.InvariantCulture);
            }
        }
    }
}
