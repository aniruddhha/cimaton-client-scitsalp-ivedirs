using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    internal static class InteropReflectionInventory
    {
        private const string ToolVersion = "0.15.33";

        private static readonly string[] ZoomTerms = { "Zoom", "Fit", "View", "Frame", "Camera" };
        private static readonly string[] AssemblyApiTerms =
        {
            "Assembly", "Instance", "Occurrence", "Component", "Model", "Body", "Face", "Entity",
            "Transform", "Matrix", "Position", "Attribute", "Pocket", "Cooling", "Hidden", "Hide",
            "Suppress", "Visible", "Modified", "Document", "Container"
        };
        private static readonly string[] VisibilityTerms =
        {
            "Show", "Visible", "Visibility", "Hidden", "Hide", "Blank", "Display", "State"
        };
        private static readonly string[] OccurrenceContextTerms =
        {
            "AssInstance", "AssemblyInstance", "Occurrence", "Component", "Instance"
        };
        private static readonly string[] VisibilityAttributeNames = { "cmAttVisibility", "cmAttBlankLevel" };

        internal static int Run()
        {
            return RunInventory(
                "CIMATRON ZOOM/VIEW INTEROP REFLECTION FINDINGS",
                "zoom-interop-reflection",
                ZoomTerms,
                includeInheritedInterfaces: false);
        }

        internal static int RunAssemblyApi()
        {
            return RunInventory(
                "CIMATRON ASSEMBLY API SURFACE REFLECTION FINDINGS",
                "assembly-api-interop-reflection",
                AssemblyApiTerms,
                includeInheritedInterfaces: true);
        }

        internal static int RunVisibilityApi()
        {
            string programDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string[] assemblyPaths = GetInteropAssemblyPaths(programDirectory);
            if (assemblyPaths.Length == 0)
            {
                Console.Error.WriteLine("VISIBILITY INTEROP REFLECTION: no interop.Cim*.dll files were found beside the diagnostic executable.");
                return 1;
            }

            ResolveEventHandler resolver = (sender, args) => ResolveReflectionOnlyAssembly(programDirectory, args.Name);
            AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += resolver;
            try
            {
                StringBuilder output = new StringBuilder();
                output.AppendLine("CIMATRON OCCURRENCE / ENTITY VISIBILITY INTEROP REFLECTION FINDINGS");
                output.AppendLine("ToolVersion: " + ToolVersion);
                output.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O"));
                output.AppendLine("InteropDirectory: " + programDirectory);
                output.AppendLine("Terms: " + string.Join(", ", VisibilityTerms));
                output.AppendLine("RuntimeCalls: NONE (reflection-only installed-Interop inventory)");
                output.AppendLine("NewlyDiscoveredMemberInvocation: PROHIBITED / NOT CALLED");
                output.AppendLine("KnownAnswerHiddenTarget: Known_Pocket_Body is intended as a hidden-but-not-suppressed assembly component occurrence in the approved copy model; FR-021 requires occurrence-level evidence, not body-only visibility.");
                output.AppendLine("ClosedRuntimeRoute: interop.CimMdlrAPI._IAssInstance / get_Show_ is CLOSED by user-validated 0.15.29 evidence; every tested occurrence rejected the explicit cast with InvalidCastException / HRESULT 0x80004002 (E_NOINTERFACE).");
                output.AppendLine("CurrentCastTarget: interop.CimMdlrAPI._IAssInstance");
                output.AppendLine("CurrentCastMechanism: C# 'as' cast");
                output.AppendLine("CurrentCastExceptionType: NONE");
                output.AppendLine("CurrentCastHRESULT: N/A");
                output.AppendLine("ValidatedCompatibleCandidates: user-validated 0.15.30 evidence showed IAssInstance.IgnoreInShowOperations=0 and cmAttVisibility/cmAttBlankLevel ABSENT for visible Block_A, suppressed Block_B, and hidden-not-suppressed Known_Pocket_Body; those candidates did not discriminate hidden state.");
                output.AppendLine("FR021Status: OPEN — reflection inventory only; no newly discovered member is invoked in this package.");
                output.AppendLine("OccurrenceContextTerms: " + string.Join(", ", OccurrenceContextTerms));
                output.AppendLine();

                int assInstanceCopyCount = 0;
                int visibilityInterfaceCount = 0;
                int visibilityMemberCount = 0;
                int occurrenceContextInterfaceCount = 0;
                int occurrenceGetterCandidateCount = 0;
                int attributeCandidateCount = 0;

                output.AppendLine("_IASSINSTANCE COPIES");
                foreach (string path in assemblyPaths)
                {
                    Assembly assembly = Assembly.ReflectionOnlyLoadFrom(path);
                    foreach (Type type in SafeGetTypes(assembly)
                        .Where(value => value.IsInterface && string.Equals(value.Name, "_IAssInstance", StringComparison.Ordinal))
                        .OrderBy(value => value.FullName, StringComparer.OrdinalIgnoreCase))
                    {
                        assInstanceCopyCount++;
                        output.AppendLine("COPY: Assembly=" + Path.GetFileName(path) +
                                          "; AssemblyVersion=" + assembly.GetName().Version +
                                          "; Interface=" + type.FullName +
                                          "; Guid=" + FormatGuidMetadata(type) +
                                          "; BaseInterfaces=" + FormatBaseInterfaces(type));
                        foreach (MemberInfo member in EnumerateDeclaredMembers(type)
                            .OrderBy(value => value.Name, StringComparer.OrdinalIgnoreCase)
                            .ThenBy(value => value.MemberType.ToString(), StringComparer.OrdinalIgnoreCase))
                        {
                            output.AppendLine("  MEMBER: Access=" + ClassifyMemberAccess(member) +
                                              "; Safety=" + ClassifyVisibilitySafety(member) +
                                              "; Kind=" + member.MemberType +
                                              "; Signature=" + FormatMemberSignature(member));
                        }
                    }
                }

                output.AppendLine();
                output.AppendLine("VISIBILITY-RELATED INTERFACE MEMBERS");
                foreach (string path in assemblyPaths)
                {
                    Assembly assembly = Assembly.ReflectionOnlyLoadFrom(path);
                    foreach (Type type in SafeGetTypes(assembly)
                        .Where(value => value.IsInterface)
                        .OrderBy(value => value.FullName, StringComparer.OrdinalIgnoreCase))
                    {
                        List<ReflectedMember> matches = FindMatchingMembers(type, VisibilityTerms, includeInheritedInterfaces: true).ToList();
                        bool typeNameMatches = Matches(type.FullName ?? type.Name, VisibilityTerms);
                        if (!typeNameMatches && matches.Count == 0)
                        {
                            continue;
                        }

                        visibilityInterfaceCount++;
                        output.AppendLine("INTERFACE: Assembly=" + Path.GetFileName(path) +
                                          "; Interface=" + type.FullName +
                                          "; Guid=" + FormatGuidMetadata(type) +
                                          "; BaseInterfaces=" + FormatBaseInterfaces(type));

                        IEnumerable<ReflectedMember> membersToWrite = matches;
                        if (typeNameMatches && matches.Count == 0)
                        {
                            membersToWrite = EnumerateDeclaredMembers(type)
                                .Select(member => new ReflectedMember(type, member));
                        }

                        foreach (ReflectedMember reflectedMember in membersToWrite
                            .OrderBy(value => value.DeclaringInterface.FullName, StringComparer.OrdinalIgnoreCase)
                            .ThenBy(value => value.Member.Name, StringComparer.OrdinalIgnoreCase)
                            .ThenBy(value => value.Member.MemberType.ToString(), StringComparer.OrdinalIgnoreCase))
                        {
                            output.AppendLine("  MEMBER: DeclaringInterface=" + reflectedMember.DeclaringInterface.FullName +
                                              "; Access=" + ClassifyMemberAccess(reflectedMember.Member) +
                                              "; Safety=" + ClassifyVisibilitySafety(reflectedMember.Member) +
                                              "; Kind=" + reflectedMember.Member.MemberType +
                                              "; Signature=" + FormatMemberSignature(reflectedMember.Member));
                            visibilityMemberCount++;
                        }
                    }
                }

                output.AppendLine();
                output.AppendLine("OCCURRENCE / COMPONENT READ-ONLY VISIBILITY CANDIDATES");
                output.AppendLine("Selection rule: interface name matches an occurrence/component context term and member name matches a visibility/display term; getters are metadata candidates only and are NOT invoked.");
                foreach (string path in assemblyPaths)
                {
                    Assembly assembly = Assembly.ReflectionOnlyLoadFrom(path);
                    foreach (Type type in SafeGetTypes(assembly)
                        .Where(value => value.IsInterface && Matches(value.FullName ?? value.Name, OccurrenceContextTerms))
                        .OrderBy(value => value.FullName, StringComparer.OrdinalIgnoreCase))
                    {
                        List<ReflectedMember> matches = FindMatchingMembers(type, VisibilityTerms, includeInheritedInterfaces: true)
                            .Where(value => Matches(value.Member.Name, VisibilityTerms) && IsReadOnlyGetter(value.Member))
                            .ToList();
                        if (matches.Count == 0)
                        {
                            continue;
                        }

                        occurrenceContextInterfaceCount++;
                        output.AppendLine("INTERFACE: Assembly=" + Path.GetFileName(path) +
                                          "; Interface=" + type.FullName +
                                          "; Guid=" + FormatGuidMetadata(type) +
                                          "; BaseInterfaces=" + FormatBaseInterfaces(type));

                        foreach (ReflectedMember reflectedMember in matches
                            .OrderBy(value => value.DeclaringInterface.FullName, StringComparer.OrdinalIgnoreCase)
                            .ThenBy(value => value.Member.Name, StringComparer.OrdinalIgnoreCase)
                            .ThenBy(value => value.Member.MemberType.ToString(), StringComparer.OrdinalIgnoreCase))
                        {
                            occurrenceGetterCandidateCount++;
                            output.AppendLine("  CANDIDATE: DeclaringInterface=" + reflectedMember.DeclaringInterface.FullName +
                                              "; Access=" + ClassifyMemberAccess(reflectedMember.Member) +
                                              "; Safety=READ_ONLY_GETTER_CANDIDATE_NOT_INVOKED" +
                                              "; Kind=" + reflectedMember.Member.MemberType +
                                              "; Signature=" + FormatMemberSignature(reflectedMember.Member));
                        }
                    }
                }

                output.AppendLine();
                output.AppendLine("ATTRIBUTE ENUM VISIBILITY CANDIDATES");
                output.AppendLine("Classification: BODY/ENTITY-LEVEL CANDIDATES ONLY unless separate evidence proves occurrence semantics.");
                foreach (string path in assemblyPaths)
                {
                    Assembly assembly = Assembly.ReflectionOnlyLoadFrom(path);
                    foreach (Type type in SafeGetTypes(assembly)
                        .Where(value => value.IsEnum && string.Equals(value.Name, "AttributeEnumType", StringComparison.Ordinal))
                        .OrderBy(value => value.FullName, StringComparer.OrdinalIgnoreCase))
                    {
                        foreach (FieldInfo field in type.GetFields(BindingFlags.Public | BindingFlags.Static)
                            .Where(value => VisibilityAttributeNames.Contains(value.Name, StringComparer.Ordinal))
                            .OrderBy(value => value.Name, StringComparer.OrdinalIgnoreCase))
                        {
                            attributeCandidateCount++;
                            output.AppendLine("CANDIDATE: Assembly=" + Path.GetFileName(path) +
                                              "; Enum=" + type.FullName +
                                              "; Name=" + field.Name +
                                              "; Value=" + FormatRawConstant(field) +
                                              "; AccessPathCandidate=IAttributeSink.GetAttribute (already proven read-only path; occurrence semantics NOT PROVEN)");
                        }
                    }
                }

                output.AppendLine();
                output.AppendLine("SAFETY / ACCEPTANCE NOTES");
                output.AppendLine("- PropertyGet/get_* findings are read-only getter candidates only; they are not invoked by this discovery mode.");
                output.AppendLine("- PropertySet/set_* findings are mutating and are not candidates for FR-021 read-only detection.");
                output.AppendLine("- Ordinary methods named Show/Hide/Display/State remain ambiguous and are not invoked merely because their names match.");
                output.AppendLine("- _IAssInstance/get_Show_ is closed by 0.15.29 E_NOINTERFACE runtime evidence and is not revived by reflection metadata alone.");
                output.AppendLine("- IAssInstance.IgnoreInShowOperations plus occurrence cmAttVisibility/cmAttBlankLevel were non-discriminating in the user-validated 0.15.30 known-answer run.");
                output.AppendLine("- Attribute enum entries remain metadata only; reflection does not establish occurrence semantics.");
                output.AppendLine("- FR-021 remains OPEN until a newly discovered supported occurrence-level read-only signal is separately approved and verified against the known-answer hidden component occurrence.");
                output.AppendLine();
                output.AppendLine("AssInstanceInterfaceCopyCount: " + assInstanceCopyCount);
                output.AppendLine("VisibilityMatchedInterfaceCount: " + visibilityInterfaceCount);
                output.AppendLine("VisibilityMatchedMemberCount: " + visibilityMemberCount);
                output.AppendLine("OccurrenceContextInterfaceCount: " + occurrenceContextInterfaceCount);
                output.AppendLine("OccurrenceReadOnlyGetterCandidateCount: " + occurrenceGetterCandidateCount);
                output.AppendLine("VisibilityAttributeCandidateCount: " + attributeCandidateCount);

                string pathWritten = EvidenceWriter.Write("visibility-api-interop-reflection", output.ToString());
                Console.WriteLine("VISIBILITY INTEROP REFLECTION: SUCCESS");
                Console.WriteLine("Assemblies scanned: " + assemblyPaths.Length);
                Console.WriteLine("_IAssInstance copies: " + assInstanceCopyCount);
                Console.WriteLine("Visibility matching interfaces: " + visibilityInterfaceCount);
                Console.WriteLine("Visibility matching members: " + visibilityMemberCount);
                Console.WriteLine("Occurrence-context interfaces with read-only visibility candidates: " + occurrenceContextInterfaceCount);
                Console.WriteLine("Occurrence-context read-only getter candidates: " + occurrenceGetterCandidateCount);
                Console.WriteLine("Visibility attribute candidates: " + attributeCandidateCount);
                Console.WriteLine("Findings file: " + pathWritten);
                return 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("VISIBILITY INTEROP REFLECTION: FAILED");
                Console.Error.WriteLine(exception);
                return 1;
            }
            finally
            {
                AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve -= resolver;
            }
        }

        private static int RunInventory(
            string heading,
            string evidencePrefix,
            string[] terms,
            bool includeInheritedInterfaces)
        {
            string programDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string[] assemblyPaths = GetInteropAssemblyPaths(programDirectory);

            if (assemblyPaths.Length == 0)
            {
                Console.Error.WriteLine("INTEROP REFLECTION: no interop.Cim*.dll files were found beside the diagnostic executable.");
                return 1;
            }

            ResolveEventHandler resolver = (sender, args) => ResolveReflectionOnlyAssembly(programDirectory, args.Name);
            AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += resolver;
            try
            {
                StringBuilder output = new StringBuilder();
                output.AppendLine(heading);
                output.AppendLine("ToolVersion: " + ToolVersion);
                output.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O"));
                output.AppendLine("InteropDirectory: " + programDirectory);
                output.AppendLine("Terms: " + string.Join(", ", terms));
                output.AppendLine("RuntimeCalls: NONE (reflection-only installed-Interop inventory)");
                output.AppendLine("InheritedInterfaceScan: " + (includeInheritedInterfaces ? "ENABLED" : "DISABLED"));
                output.AppendLine();

                int typeCount = 0;
                int memberCount = 0;
                foreach (string path in assemblyPaths)
                {
                    Assembly assembly = Assembly.ReflectionOnlyLoadFrom(path);
                    output.AppendLine("ASSEMBLY: " + Path.GetFileName(path));
                    output.AppendLine("  Version: " + assembly.GetName().Version);

                    foreach (Type type in SafeGetTypes(assembly)
                        .Where(value => value.IsInterface)
                        .OrderBy(value => value.FullName, StringComparer.OrdinalIgnoreCase))
                    {
                        List<ReflectedMember> matches = FindMatchingMembers(type, terms, includeInheritedInterfaces).ToList();
                        bool typeNameMatches = Matches(type.FullName ?? type.Name, terms);
                        if (!typeNameMatches && matches.Count == 0)
                        {
                            continue;
                        }

                        typeCount++;
                        output.AppendLine("  INTERFACE: " + type.FullName);
                        output.AppendLine("    BaseInterfaces: " + FormatBaseInterfaces(type));

                        IEnumerable<ReflectedMember> membersToWrite = matches;
                        if (typeNameMatches && matches.Count == 0)
                        {
                            membersToWrite = EnumerateDeclaredMembers(type)
                                .Select(member => new ReflectedMember(type, member));
                        }

                        foreach (ReflectedMember reflectedMember in membersToWrite
                            .OrderBy(value => value.DeclaringInterface.FullName, StringComparer.OrdinalIgnoreCase)
                            .ThenBy(value => value.Member.Name, StringComparer.OrdinalIgnoreCase)
                            .ThenBy(value => value.Member.MemberType.ToString(), StringComparer.OrdinalIgnoreCase))
                        {
                            output.AppendLine(
                                "    MEMBER: DeclaringInterface=" + reflectedMember.DeclaringInterface.FullName +
                                "; Kind=" + reflectedMember.Member.MemberType +
                                "; Signature=" + FormatMemberSignature(reflectedMember.Member));
                            memberCount++;
                        }
                    }

                    output.AppendLine();
                }

                output.AppendLine("MatchedInterfaceCount: " + typeCount);
                output.AppendLine("MatchedMemberCount: " + memberCount);
                string pathWritten = EvidenceWriter.Write(evidencePrefix, output.ToString());
                Console.WriteLine("INTEROP REFLECTION: SUCCESS");
                Console.WriteLine("Assemblies scanned: " + assemblyPaths.Length);
                Console.WriteLine("Matching interfaces: " + typeCount);
                Console.WriteLine("Matching members: " + memberCount);
                Console.WriteLine("Findings file: " + pathWritten);
                return 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("INTEROP REFLECTION: FAILED");
                Console.Error.WriteLine(exception);
                return 1;
            }
            finally
            {
                AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve -= resolver;
            }
        }

        private static string[] GetInteropAssemblyPaths(string programDirectory)
        {
            return Directory.GetFiles(programDirectory, "interop.Cim*.dll", SearchOption.TopDirectoryOnly)
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        private static IEnumerable<ReflectedMember> FindMatchingMembers(
            Type rootInterface,
            string[] terms,
            bool includeInheritedInterfaces)
        {
            IEnumerable<Type> interfaces = includeInheritedInterfaces
                ? new[] { rootInterface }.Concat(rootInterface.GetInterfaces())
                : new[] { rootInterface };

            HashSet<string> seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (Type currentInterface in interfaces)
            {
                foreach (MemberInfo member in EnumerateDeclaredMembers(currentInterface))
                {
                    if (!Matches(member.Name, terms) && !Matches(currentInterface.FullName ?? currentInterface.Name, terms))
                    {
                        continue;
                    }

                    string identity = currentInterface.FullName + "|" + member.MemberType + "|" + FormatMemberSignature(member);
                    if (seen.Add(identity))
                    {
                        yield return new ReflectedMember(currentInterface, member);
                    }
                }
            }
        }

        private static MemberInfo[] EnumerateDeclaredMembers(Type type)
        {
            return type.GetMembers(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);
        }

        private static string FormatBaseInterfaces(Type type)
        {
            string[] names = type.GetInterfaces()
                .Select(value => value.FullName)
                .Where(value => !string.IsNullOrEmpty(value))
                .OrderBy(value => value, StringComparer.OrdinalIgnoreCase)
                .ToArray();
            return names.Length == 0 ? "(none)" : string.Join(", ", names);
        }

        private static string FormatGuidMetadata(Type type)
        {
            try
            {
                CustomAttributeData guidAttribute = type.GetCustomAttributesData()
                    .FirstOrDefault(value => string.Equals(
                        value.AttributeType.FullName,
                        "System.Runtime.InteropServices.GuidAttribute",
                        StringComparison.Ordinal));
                if (guidAttribute == null || guidAttribute.ConstructorArguments.Count == 0)
                {
                    return "(none)";
                }

                object guidValue = guidAttribute.ConstructorArguments[0].Value;
                return guidValue == null ? "(none)" : guidValue.ToString();
            }
            catch (Exception exception)
            {
                return "UNAVAILABLE(" + exception.GetType().Name + ")";
            }
        }

        private static string FormatRawConstant(FieldInfo field)
        {
            try
            {
                object value = field.GetRawConstantValue();
                return value == null ? "<null>" : Convert.ToString(value, System.Globalization.CultureInfo.InvariantCulture);
            }
            catch (Exception exception)
            {
                return "UNAVAILABLE(" + exception.GetType().Name + ")";
            }
        }

        private static bool IsReadOnlyGetter(MemberInfo member)
        {
            string access = ClassifyMemberAccess(member);
            return access == "PROPERTY_GET" || access == "PROPERTY_GET_ACCESSOR";
        }

        private static string ClassifyMemberAccess(MemberInfo member)
        {
            PropertyInfo property = member as PropertyInfo;
            if (property != null)
            {
                if (property.CanRead && property.CanWrite)
                {
                    return "PROPERTY_GET+SET";
                }

                if (property.CanRead)
                {
                    return "PROPERTY_GET";
                }

                if (property.CanWrite)
                {
                    return "PROPERTY_SET";
                }

                return "PROPERTY_NO_ACCESSOR";
            }

            MethodInfo method = member as MethodInfo;
            if (method != null)
            {
                if (method.IsSpecialName && method.Name.StartsWith("get_", StringComparison.Ordinal))
                {
                    return "PROPERTY_GET_ACCESSOR";
                }

                if (method.IsSpecialName && method.Name.StartsWith("set_", StringComparison.Ordinal))
                {
                    return "PROPERTY_SET_ACCESSOR";
                }

                return "METHOD";
            }

            return member.MemberType.ToString().ToUpperInvariant();
        }

        private static string ClassifyVisibilitySafety(MemberInfo member)
        {
            string access = ClassifyMemberAccess(member);
            if (access == "PROPERTY_GET" || access == "PROPERTY_GET_ACCESSOR")
            {
                return "READ_ONLY_GETTER_CANDIDATE_NOT_INVOKED";
            }

            if (access == "PROPERTY_SET" || access == "PROPERTY_SET_ACCESSOR" || access == "PROPERTY_GET+SET")
            {
                return "MUTATING_OR_MIXED_ACCESS_NOT_INVOKED";
            }

            if (access == "METHOD")
            {
                return "AMBIGUOUS_METHOD_NOT_INVOKED";
            }

            return "METADATA_ONLY";
        }

        private static string FormatMemberSignature(MemberInfo member)
        {
            MethodInfo method = member as MethodInfo;
            if (method != null)
            {
                return FormatTypeName(method.ReturnType) + " " + method.Name + "(" +
                       string.Join(", ", method.GetParameters().Select(FormatParameter)) + ")";
            }

            PropertyInfo property = member as PropertyInfo;
            if (property != null)
            {
                string accessors = (property.CanRead ? "get;" : string.Empty) + (property.CanWrite ? "set;" : string.Empty);
                ParameterInfo[] indexParameters = property.GetIndexParameters();
                string indexer = indexParameters.Length == 0
                    ? string.Empty
                    : "[" + string.Join(", ", indexParameters.Select(FormatParameter)) + "]";
                return FormatTypeName(property.PropertyType) + " " + property.Name + indexer + " { " + accessors + " }";
            }

            EventInfo eventInfo = member as EventInfo;
            if (eventInfo != null)
            {
                return "event " + FormatTypeName(eventInfo.EventHandlerType) + " " + eventInfo.Name;
            }

            FieldInfo field = member as FieldInfo;
            if (field != null)
            {
                return FormatTypeName(field.FieldType) + " " + field.Name;
            }

            return member.Name;
        }

        private static string FormatParameter(ParameterInfo parameter)
        {
            string prefix = parameter.IsOut ? "out " : parameter.ParameterType.IsByRef ? "ref " : string.Empty;
            Type parameterType = parameter.ParameterType.IsByRef
                ? parameter.ParameterType.GetElementType()
                : parameter.ParameterType;
            string optional = parameter.IsOptional ? " = <optional>" : string.Empty;
            return prefix + FormatTypeName(parameterType) + " " + parameter.Name + optional;
        }

        private static string FormatTypeName(Type type)
        {
            if (type == null)
            {
                return "<null>";
            }

            if (type.IsByRef)
            {
                return FormatTypeName(type.GetElementType()) + "&";
            }

            if (type.IsArray)
            {
                return FormatTypeName(type.GetElementType()) + "[]";
            }

            return type.FullName ?? type.Name;
        }

        private static Assembly ResolveReflectionOnlyAssembly(string programDirectory, string assemblyName)
        {
            AssemblyName requested = new AssemblyName(assemblyName);
            string candidate = Path.Combine(programDirectory, requested.Name + ".dll");
            return File.Exists(candidate) ? Assembly.ReflectionOnlyLoadFrom(candidate) : null;
        }

        private static IEnumerable<Type> SafeGetTypes(Assembly assembly)
        {
            try
            {
                return assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException exception)
            {
                return exception.Types.Where(type => type != null);
            }
        }

        private static bool Matches(string value, IEnumerable<string> terms)
        {
            return !string.IsNullOrEmpty(value) &&
                   terms.Any(term => value.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private sealed class ReflectedMember
        {
            internal ReflectedMember(Type declaringInterface, MemberInfo member)
            {
                DeclaringInterface = declaringInterface;
                Member = member;
            }

            internal Type DeclaringInterface { get; private set; }

            internal MemberInfo Member { get; private set; }
        }
    }
}
