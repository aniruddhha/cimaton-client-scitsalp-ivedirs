using System;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    internal static class Program
    {
        private const int AttachTimeoutMilliseconds = 30000;
        private const int AttachElevationMismatchExitCode = 6;
        private const uint TokenQuery = 0x0008;
        private const int TokenElevationInformationClass = 20;

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool OpenProcessToken(IntPtr processHandle, uint desiredAccess, out IntPtr tokenHandle);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool GetTokenInformation(
            IntPtr tokenHandle,
            int tokenInformationClass,
            out int tokenInformation,
            int tokenInformationLength,
            out int returnLength);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr handle);

        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                DiagnosticTraceWriter.Initialize();
                DiagnosticTraceWriter.StartHeartbeat();
                DiagnosticTraceWriter.WriteLine("Dispatch evaluation started");
                if (args == null || args.Length == 0 || IsHelp(args[0]))
                {
                    PrintUsage();
                    return args == null || args.Length == 0 ? 1 : 0;
                }

                if (string.Equals(args[0], "--reflect", StringComparison.OrdinalIgnoreCase) && args.Length == 1)
                {
                    return InteropReflectionInventory.Run();
                }

                if (string.Equals(args[0], "--reflect-assembly-api", StringComparison.OrdinalIgnoreCase) && args.Length == 1)
                {
                    DiagnosticTraceWriter.WriteLine("Dispatch: reflect-assembly-api");
                    return InteropReflectionInventory.RunAssemblyApi();
                }

                if (string.Equals(args[0], "--reflect-visibility-api", StringComparison.OrdinalIgnoreCase) && args.Length == 1)
                {
                    DiagnosticTraceWriter.WriteLine("Dispatch: reflect-visibility-api");
                    return InteropReflectionInventory.RunVisibilityApi();
                }

                if (string.Equals(args[0], "--probe-occurrence-interfaces", StringComparison.OrdinalIgnoreCase) && args.Length == 1)
                {
                    DiagnosticTraceWriter.WriteLine("Dispatch: probe-occurrence-interfaces");
                    return OccurrenceComInterfaceInventory.Run();
                }

                if (string.Equals(args[0], "--assembly-entities", StringComparison.OrdinalIgnoreCase))
                {
                    bool occurrenceOnly;
                    if (!TryParseAssemblyEntityMode(args, out occurrenceOnly))
                    {
                        PrintUsage();
                        return 1;
                    }

                    DiagnosticTraceWriter.WriteLine(
                        occurrenceOnly ? "Dispatch: assembly-entities occurrence-only" : "Dispatch: assembly-entities");
                    return AssemblyEntityInventory.Run(!occurrenceOnly);
                }

                if (string.Equals(args[0], "--trace-selftest", StringComparison.OrdinalIgnoreCase) && args.Length == 1)
                {
                    DiagnosticTraceWriter.WriteLine("Dispatch: trace-selftest");
                    DiagnosticTraceWriter.WriteLine("TRACE SELFTEST checkpoint 1");
                    DiagnosticTraceWriter.SetLastCheckpoint("TRACE SELFTEST checkpoint 1");
                    DiagnosticTraceWriter.WriteLine("TRACE SELFTEST checkpoint 2");
                    DiagnosticTraceWriter.SetLastCheckpoint("TRACE SELFTEST checkpoint 2");
                    DiagnosticTraceWriter.WriteLine("TRACE SELFTEST completed");
                    Console.WriteLine("TRACE SELFTEST: PASS");
                    Console.WriteLine("Trace: " + DiagnosticTraceWriter.TracePath);
                    return 0;
                }

                if (string.Equals(args[0], "--attach-only", StringComparison.OrdinalIgnoreCase))
                {
                    ApartmentState apartmentState;
                    if (!TryParseApartment(args, out apartmentState))
                    {
                        PrintUsage();
                        return 1;
                    }

                    return RunAttachOnly(apartmentState);
                }

                if (string.Equals(args[0], "--validate-zoom-selection", StringComparison.OrdinalIgnoreCase))
                {
                    string expectedContext;
                    int entityId;
                    if (!TryParseValidationArguments(args, out expectedContext, out entityId))
                    {
                        PrintUsage();
                        return 1;
                    }

                    return ZoomSelectionValidation.Run(expectedContext, entityId);
                }

                if (string.Equals(args[0], "--commands", StringComparison.OrdinalIgnoreCase))
                {
                    string expectedContext = ParseExpectedContext(args);
                    if (expectedContext == null && args.Length > 1)
                    {
                        PrintUsage();
                        return 1;
                    }

                    return CommandPoolInventory.Run(expectedContext ?? string.Empty);
                }

                PrintUsage();
                return 1;
            }
            catch (Exception exception)
            {
                try
                {
                    DiagnosticTraceWriter.WriteLine("Unexpected failure: " + exception);
                }
                catch (Exception traceException)
                {
                    Console.Error.WriteLine("ZOOM COMMAND DISCOVERY TRACE: failure recording exception: " + traceException.Message);
                }

                Console.Error.WriteLine("ZOOM COMMAND DISCOVERY: unexpected failure.");
                Console.Error.WriteLine(exception);
                return 1;
            }
            finally
            {
                try
                {
                    DiagnosticTraceWriter.WriteLine("Main exiting");
                    DiagnosticTraceWriter.StopHeartbeat();
                }
                catch (Exception traceException)
                {
                    Console.Error.WriteLine("ZOOM COMMAND DISCOVERY TRACE: shutdown write failed: " + traceException.Message);
                }
            }
        }

        private static int RunAttachOnly(ApartmentState requestedApartment)
        {
            DiagnosticTraceWriter.WriteLine("Dispatch: attach-only");
            DiagnosticTraceWriter.WriteLine("Attach requested apartment: " + requestedApartment);
            WriteAttachSignature();
            CimatronProcessEvidence processEvidence = WriteCimatronProcessEvidence();
            WriteRunPreconditionChecklist(processEvidence);
            if (processEvidence.HasConfirmedElevationMismatch)
            {
                DiagnosticTraceWriter.WriteLine("ATTACH PRECONDITION FAILED: confirmed elevation mismatch between tool and CimatronE.exe; attach was not attempted.");
                Console.Error.WriteLine("ATTACH ONLY: elevation mismatch. Run this diagnostic at the same elevation level as CimatronE.exe. ExitCode=6.");
                Console.Error.WriteLine("Trace: " + DiagnosticTraceWriter.TracePath);
                return AttachElevationMismatchExitCode;
            }

            ManualResetEvent completed = new ManualResetEvent(false);
            int workerExitCode = 1;
            Thread worker = new Thread(delegate()
            {
                object appAccessObject = null;
                object applicationObject = null;
                try
                {
                    DiagnosticTraceWriter.SetLastCheckpoint("ATTACH worker entered");
                    DiagnosticTraceWriter.WriteLine("ATTACH worker entered; apartment=" + Thread.CurrentThread.GetApartmentState());
                    DiagnosticTraceWriter.WriteLine("ATTACH CHECKPOINT A1: creating AppAccess");
                    DiagnosticTraceWriter.SetLastCheckpoint("ATTACH CHECKPOINT A1");
                    appAccessObject = new interop.CimAppAccess.AppAccess();
                    DiagnosticTraceWriter.WriteLine("ATTACH CHECKPOINT A2: AppAccess created; immediately before GetApplication()");
                    DiagnosticTraceWriter.SetLastCheckpoint("ATTACH CHECKPOINT A2");
                    applicationObject = ((interop.CimAppAccess.AppAccess)appAccessObject).GetApplication();
                    DiagnosticTraceWriter.WriteLine("ATTACH CHECKPOINT A3: GetApplication() returned");
                    DiagnosticTraceWriter.SetLastCheckpoint("ATTACH CHECKPOINT A3");

                    if (applicationObject == null)
                    {
                        Console.Error.WriteLine("ATTACH ONLY: Cimatron is unavailable or GetApplication returned null.");
                        workerExitCode = 2;
                        return;
                    }

                    Console.WriteLine("ATTACH ONLY: PASS (" + requestedApartment + ")");
                    Console.WriteLine("Trace: " + DiagnosticTraceWriter.TracePath);
                    workerExitCode = 0;
                }
                catch (COMException exception)
                {
                    DiagnosticTraceWriter.WriteLine("ATTACH COM failure: " + exception);
                    Console.Error.WriteLine("ATTACH ONLY: COM failure.");
                    Console.Error.WriteLine(exception);
                    workerExitCode = 3;
                }
                catch (Exception exception)
                {
                    DiagnosticTraceWriter.WriteLine("ATTACH unexpected failure: " + exception);
                    Console.Error.WriteLine("ATTACH ONLY: unexpected failure.");
                    Console.Error.WriteLine(exception);
                    workerExitCode = 1;
                }
                finally
                {
                    ReleaseComObject(applicationObject);
                    ReleaseComObject(appAccessObject);
                    completed.Set();
                }
            });

            worker.IsBackground = true;
            worker.Name = "ZoomDiscoveryAttachOnly";
            worker.SetApartmentState(requestedApartment);
            worker.Start();

            if (!completed.WaitOne(AttachTimeoutMilliseconds))
            {
                DiagnosticTraceWriter.WriteLine(
                    "ATTACH TIMEOUT after " + AttachTimeoutMilliseconds.ToString(CultureInfo.InvariantCulture) +
                    " ms; requestedApartment=" + requestedApartment +
                    "; worker remains blocked/background and is not force-aborted.");
                DiagnosticTraceWriter.SetLastCheckpoint("ATTACH TIMEOUT");
                Console.Error.WriteLine("ATTACH ONLY: TIMEOUT after 30 seconds. ExitCode=5.");
                Console.Error.WriteLine("Trace: " + DiagnosticTraceWriter.TracePath);
                return 5;
            }

            DiagnosticTraceWriter.WriteLine("ATTACH worker completed; ExitCode=" + workerExitCode.ToString(CultureInfo.InvariantCulture));
            return workerExitCode;
        }

        private static void WriteAttachSignature()
        {
            Type appAccessType = typeof(interop.CimAppAccess.AppAccess);
            MethodInfo method = FindParameterlessMethod(appAccessType, "GetApplication");
            if (method == null)
            {
                DiagnosticTraceWriter.WriteLine("GetApplication reflection signature: NOT FOUND after scanning type and inherited interfaces");
                return;
            }

            ParameterInfo[] parameters = method.GetParameters();
            DiagnosticTraceWriter.WriteLine(
                "GetApplication reflection signature: DeclaringType=" + method.DeclaringType.FullName +
                "; ReturnType=" + method.ReturnType.FullName +
                "; Method=" + method.Name +
                "(); ParameterCount=" + parameters.Length.ToString(CultureInfo.InvariantCulture));
        }

        private static MethodInfo FindParameterlessMethod(Type type, string methodName)
        {
            MethodInfo method = type.GetMethod(methodName, Type.EmptyTypes);
            if (method != null)
            {
                return method;
            }

            Type[] interfaces = type.GetInterfaces();
            Array.Sort(interfaces, delegate(Type left, Type right)
            {
                return string.Compare(left.FullName, right.FullName, StringComparison.Ordinal);
            });

            foreach (Type inheritedInterface in interfaces)
            {
                method = inheritedInterface.GetMethod(methodName, Type.EmptyTypes);
                if (method != null)
                {
                    return method;
                }
            }

            return null;
        }

        private static CimatronProcessEvidence WriteCimatronProcessEvidence()
        {
            bool toolElevated = DiagnosticTraceWriter.IsCurrentProcessElevated;
            int currentSessionId = Process.GetCurrentProcess().SessionId;
            int count = 0;
            bool hasConfirmedMismatch = false;
            Process[] processes = Process.GetProcessesByName("CimatronE");
            Array.Sort(processes, delegate(Process left, Process right) { return left.Id.CompareTo(right.Id); });
            foreach (Process process in processes)
            {
                try
                {
                    count++;
                    bool? processElevated = TryGetProcessElevation(process);
                    if (processElevated.HasValue && processElevated.Value != toolElevated)
                    {
                        hasConfirmedMismatch = true;
                    }

                    DiagnosticTraceWriter.WriteLine(
                        "CimatronProcess: Name=" + process.ProcessName +
                        "; PID=" + process.Id.ToString(CultureInfo.InvariantCulture) +
                        "; SessionId=" + process.SessionId.ToString(CultureInfo.InvariantCulture) +
                        "; Elevated=" + FormatNullableBoolean(processElevated) +
                        "; SameSessionAsTool=" + (process.SessionId == currentSessionId ? "True" : "False"));
                }
                catch (InvalidOperationException)
                {
                    DiagnosticTraceWriter.WriteLine("CimatronProcess: process exited while evidence was being collected");
                }
                finally
                {
                    process.Dispose();
                }
            }

            DiagnosticTraceWriter.WriteLine("CimatronProcessCount: " + count.ToString(CultureInfo.InvariantCulture));
            DiagnosticTraceWriter.WriteLine("Precondition single CimatronE instance: " + (count == 1 ? "PASS" : "REVIEW REQUIRED"));
            if (count == 0)
            {
                DiagnosticTraceWriter.WriteLine("Precondition Cimatron visibility: FAILED; no CimatronE.exe process was visible to the diagnostic process");
            }

            DiagnosticTraceWriter.WriteLine(
                "Precondition matching Cimatron/tool elevation: " +
                (hasConfirmedMismatch ? "FAIL" : (count == 0 ? "UNKNOWN" : "NO CONFIRMED MISMATCH")) +
                "; ToolElevated=" + toolElevated.ToString());

            return new CimatronProcessEvidence(count, hasConfirmedMismatch);
        }

        private static bool? TryGetProcessElevation(Process process)
        {
            IntPtr tokenHandle = IntPtr.Zero;
            try
            {
                if (!OpenProcessToken(process.Handle, TokenQuery, out tokenHandle))
                {
                    DiagnosticTraceWriter.WriteLine(
                        "CimatronProcessElevation: PID=" + process.Id.ToString(CultureInfo.InvariantCulture) +
                        "; UNKNOWN; OpenProcessToken Win32Error=" + Marshal.GetLastWin32Error().ToString(CultureInfo.InvariantCulture));
                    return null;
                }

                int elevation;
                int returnLength;
                if (!GetTokenInformation(tokenHandle, TokenElevationInformationClass, out elevation, sizeof(int), out returnLength))
                {
                    DiagnosticTraceWriter.WriteLine(
                        "CimatronProcessElevation: PID=" + process.Id.ToString(CultureInfo.InvariantCulture) +
                        "; UNKNOWN; GetTokenInformation Win32Error=" + Marshal.GetLastWin32Error().ToString(CultureInfo.InvariantCulture));
                    return null;
                }

                return elevation != 0;
            }
            catch (Exception exception)
            {
                DiagnosticTraceWriter.WriteLine(
                    "CimatronProcessElevation: PID=" + process.Id.ToString(CultureInfo.InvariantCulture) +
                    "; UNKNOWN; Exception=" + exception.GetType().FullName + ": " + exception.Message);
                return null;
            }
            finally
            {
                if (tokenHandle != IntPtr.Zero)
                {
                    CloseHandle(tokenHandle);
                }
            }
        }

        private static string FormatNullableBoolean(bool? value)
        {
            return value.HasValue ? value.Value.ToString() : "UNKNOWN";
        }

        private static void WriteRunPreconditionChecklist(CimatronProcessEvidence processEvidence)
        {
            DiagnosticTraceWriter.WriteLine("Precondition no open Cimatron dialog: OPERATOR_CONFIRMATION_REQUIRED");
            DiagnosticTraceWriter.WriteLine("Precondition no active Cimatron command: OPERATOR_CONFIRMATION_REQUIRED");
            DiagnosticTraceWriter.WriteLine(
                "Precondition process inventory summary: CimatronECount=" + processEvidence.Count.ToString(CultureInfo.InvariantCulture) +
                "; ConfirmedElevationMismatch=" + processEvidence.HasConfirmedElevationMismatch.ToString());
        }

        private sealed class CimatronProcessEvidence
        {
            internal CimatronProcessEvidence(int count, bool hasConfirmedElevationMismatch)
            {
                Count = count;
                HasConfirmedElevationMismatch = hasConfirmedElevationMismatch;
            }

            internal int Count { get; private set; }

            internal bool HasConfirmedElevationMismatch { get; private set; }
        }

        private static bool TryParseApartment(string[] args, out ApartmentState apartmentState)
        {
            apartmentState = ApartmentState.Unknown;
            if (args == null || args.Length != 2 || args[1] == null ||
                !args[1].StartsWith("--apartment=", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            string value = args[1].Substring("--apartment=".Length);
            if (string.Equals(value, "STA", StringComparison.OrdinalIgnoreCase))
            {
                apartmentState = ApartmentState.STA;
                return true;
            }

            if (string.Equals(value, "MTA", StringComparison.OrdinalIgnoreCase))
            {
                apartmentState = ApartmentState.MTA;
                return true;
            }

            return false;
        }

        private static void ReleaseComObject(object value)
        {
            if (value != null && Marshal.IsComObject(value))
            {
                Marshal.FinalReleaseComObject(value);
            }
        }

        private static bool TryParseAssemblyEntityMode(string[] args, out bool occurrenceOnly)
        {
            occurrenceOnly = false;
            if (args.Length == 1)
            {
                return true;
            }

            if (args.Length == 2 && string.Equals(args[1], "--occurrence-only", StringComparison.OrdinalIgnoreCase))
            {
                occurrenceOnly = true;
                return true;
            }

            return false;
        }

        private static bool TryParseValidationArguments(string[] args, out string expectedContext, out int entityId)
        {
            expectedContext = string.Empty;
            entityId = 0;

            if (args.Length != 5 ||
                !string.Equals(args[1], "--expect", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(args[3], "--entity-id", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            if (string.Equals(args[2], "Part", StringComparison.OrdinalIgnoreCase))
            {
                expectedContext = "Part";
            }
            else if (string.Equals(args[2], "Assembly", StringComparison.OrdinalIgnoreCase))
            {
                expectedContext = "Assembly";
            }
            else
            {
                return false;
            }

            return int.TryParse(args[4], out entityId) && entityId > 0;
        }

        private static string ParseExpectedContext(string[] args)
        {
            if (args.Length == 1) return string.Empty;
            if (args.Length != 3 || !string.Equals(args[1], "--expect", StringComparison.OrdinalIgnoreCase)) return null;
            if (string.Equals(args[2], "Part", StringComparison.OrdinalIgnoreCase)) return "Part";
            if (string.Equals(args[2], "Assembly", StringComparison.OrdinalIgnoreCase)) return "Assembly";
            return null;
        }

        private static bool IsHelp(string value)
        {
            return string.Equals(value, "--help", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(value, "-h", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(value, "/?", StringComparison.OrdinalIgnoreCase);
        }

        private static void PrintUsage()
        {
            Console.WriteLine("CimatronCustomization.ZoomCommandDiscovery 0.15.36");
            Console.WriteLine("Step 05C developer diagnostic. Discovery modes are read-only; the approved 05C2 validation mode temporarily selects one entity and executes only Display / Zoom Selection.");
            Console.WriteLine();
            Console.WriteLine("Usage:");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --reflect");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --reflect-assembly-api");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --reflect-visibility-api");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --probe-occurrence-interfaces");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --commands --expect Part");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --commands --expect Assembly");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --assembly-entities");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --assembly-entities --occurrence-only");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --trace-selftest");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --attach-only --apartment=STA");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --attach-only --apartment=MTA");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --validate-zoom-selection --expect Part --entity-id <id>");
            Console.WriteLine("  CimatronCustomization.ZoomCommandDiscovery.exe --validate-zoom-selection --expect Assembly --entity-id <id>");
            Console.WriteLine();
            Console.WriteLine("Exit codes: 0 success; 1 unexpected/usage/reflection failure; 2 Cimatron unavailable; 3 attach/manifest/COM activation failure; 4 API/context enumeration failure; 5 attach timeout; 6 confirmed elevation mismatch.");
        }
    }
}
