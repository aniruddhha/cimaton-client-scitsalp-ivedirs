using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.ZoomCommandDiscovery")]
[assembly: AssemblyDescription("Cimatron 2026 zoom/view discovery and controlled Zoom Selection validation diagnostic")]
[assembly: AssemblyCompany("flux10x AI Systems")]
[assembly: AssemblyProduct("CimatronCustomization.ZoomCommandDiscovery")]
[assembly: ComVisible(false)]
[assembly: Guid("89a447e8-d97b-4477-a16b-ef4a91d07eef")]
[assembly: AssemblyVersion("0.15.30.0")]
[assembly: AssemblyFileVersion("0.15.30.0")]
