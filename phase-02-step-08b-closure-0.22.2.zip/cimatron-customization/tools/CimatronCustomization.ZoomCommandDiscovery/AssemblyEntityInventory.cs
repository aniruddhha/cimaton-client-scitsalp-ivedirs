using System;
using System.Collections.Generic;
using System.Globalization;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    /// <summary>
    /// Step 05C2-B development-only, read-only Assembly occurrence/entity diagnostic.
    /// Traversal is restricted to the installed-Interop allow-list approved after 0.15.20 reflection.
    /// It does not open/load/activate component documents and does not mutate model, selection, or view state.
    /// </summary>
    internal static class AssemblyEntityInventory
    {
        private const int ApiCallTimeoutMilliseconds = 15000;
        private const int ApiCallTimeoutExitCode = 7;
        private const int MaximumDepth = 16;
        private const int MaximumOccurrences = 2000;
        private const int MaximumEntityInspections = 2000;
        private const string PocketAttributeName = "MbPocket";
        private const string CoolingAttributeName = "MbCooling";

        internal static int Run(bool inspectEntities)
        {
            Stopwatch runTimer = Stopwatch.StartNew();
            object appAccessObject = null;
            object applicationObject = null;
            object activeDocumentObject = null;

            try
            {
                int checkpointNumber = 0;
                string activeCall = string.Empty;
                WriteCheckpoint(
                    ref checkpointNumber,
                    "Starting controlled Step 05C2-B Assembly diagnostic; EntityInspection=" +
                    (inspectEntities ? "ENABLED" : "DISABLED_OCCURRENCE_ONLY"));

                appAccessObject = RunApiCall(
                    "AppAccess constructor",
                    () => (object)new interop.CimAppAccess.AppAccess(),
                    ref checkpointNumber,
                    ref activeCall);

                applicationObject = RunApiCall(
                    "AppAccess.GetApplication",
                    () => (object)((interop.CimAppAccess.AppAccess)appAccessObject).GetApplication(),
                    ref checkpointNumber,
                    ref activeCall);
                if (applicationObject == null)
                {
                    Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: Cimatron is not running or is unavailable.");
                    return 2;
                }

                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)applicationObject;
                activeDocumentObject = RunApiCall(
                    "IApplication.GetActiveDoc",
                    () => (object)application.GetActiveDoc(),
                    ref checkpointNumber,
                    ref activeCall);
                if (activeDocumentObject == null)
                {
                    Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: Cimatron has no active document.");
                    return 4;
                }

                interop.CimatronE.ICimDocument activeDocument = (interop.CimatronE.ICimDocument)activeDocumentObject;
                string documentType = RunApiCall(
                    "ICimDocument.Type",
                    () => activeDocument.Type.ToString(),
                    ref checkpointNumber,
                    ref activeCall);
                if (!string.Equals(documentType, "cmAssembly", StringComparison.Ordinal))
                {
                    Console.Error.WriteLine(
                        "ASSEMBLY ENTITY INVENTORY: active document is " + documentType + ", expected cmAssembly.");
                    return 4;
                }

                NoMutationSnapshot beforeSnapshot = CaptureNoMutationSnapshot(
                    activeDocument,
                    "BEFORE",
                    ref checkpointNumber,
                    ref activeCall);

                interop.CimMdlrAPI.IModelContainer container = activeDocument as interop.CimMdlrAPI.IModelContainer;
                if (container == null)
                {
                    Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: active Assembly does not expose IModelContainer.");
                    return 4;
                }

                interop.CimMdlrAPI.IAssemblyModel assemblyModel = RunApiCall(
                    "IModelContainer.Model -> IAssemblyModel",
                    () => container.Model as interop.CimMdlrAPI.IAssemblyModel,
                    ref checkpointNumber,
                    ref activeCall);
                if (assemblyModel == null)
                {
                    Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: active Assembly does not expose IAssemblyModel.");
                    return 4;
                }

                interop.CimMdlrAPI.AssInstance rootInstance = RunApiCall(
                    "IAssemblyModel.GetRootInstance",
                    () => assemblyModel.GetRootInstance(),
                    ref checkpointNumber,
                    ref activeCall);
                if (rootInstance == null)
                {
                    Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: GetRootInstance returned null.");
                    return 4;
                }

                TraversalState state = new TraversalState();
                List<OccurrenceEvidence> occurrences = new List<OccurrenceEvidence>();
                List<BodyAttributeEvidence> bodyAttributes = new List<BodyAttributeEvidence>();

                int rootId = RunApiCall(
                    "IAssInstance.get_ID(root)",
                    () => ((interop.CimMdlrAPI.IAssInstance)rootInstance).ID,
                    ref checkpointNumber,
                    ref activeCall);
                string rootPath = "root:" + rootId.ToString(CultureInfo.InvariantCulture);

                TraverseOccurrence(
                    (interop.CimMdlrAPI.IAssInstance)rootInstance,
                    rootPath,
                    0,
                    true,
                    state,
                    occurrences,
                    bodyAttributes,
                    inspectEntities,
                    new HashSet<string>(StringComparer.OrdinalIgnoreCase),
                    ref checkpointNumber,
                    ref activeCall);

                NoMutationSnapshot afterSnapshot = CaptureNoMutationSnapshot(
                    activeDocument,
                    "AFTER",
                    ref checkpointNumber,
                    ref activeCall);

                bool noMutationObserved = NoMutationSnapshot.IsEquivalent(beforeSnapshot, afterSnapshot);
                StringBuilder evidence = BuildEvidence(
                    application,
                    documentType,
                    beforeSnapshot,
                    afterSnapshot,
                    noMutationObserved,
                    state,
                    occurrences,
                    bodyAttributes,
                    inspectEntities,
                    runTimer.Elapsed);
                string evidencePath = EvidenceWriter.Write("assembly-occurrence-entity-diagnostic", evidence.ToString());

                Console.WriteLine("ASSEMBLY ENTITY INVENTORY: SUCCESS");
                Console.WriteLine("Occurrences: " + occurrences.Count.ToString(CultureInfo.InvariantCulture));
                Console.WriteLine("Occurrence-reached body attribute checks: " + bodyAttributes.Count.ToString(CultureInfo.InvariantCulture));
                Console.WriteLine("Entity items inspected: " + state.EntityItemsInspected.ToString(CultureInfo.InvariantCulture));
                Console.WriteLine("Occurrence limit reached: " + state.OccurrenceLimitReached.ToString());
                Console.WriteLine("Entity inspection limit reached: " + state.EntityInspectionLimitReached.ToString());
                Console.WriteLine("Total runtime: " + FormatElapsed(runTimer.Elapsed));
                Console.WriteLine("No-mutation evidence: " + (noMutationObserved ? "UNCHANGED" : "CHANGED/UNVERIFIED"));
                Console.WriteLine("Evidence file: " + evidencePath);
                Console.WriteLine("Trace: " + DiagnosticTraceWriter.TracePath);
                return noMutationObserved ? 0 : 8;
            }
            catch (ApiCallException exception)
            {
                Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: API call failed.");
                Console.Error.WriteLine(exception.Message);
                Console.Error.WriteLine("ExceptionType: " + exception.InnerException.GetType().FullName);
                Console.Error.WriteLine("HRESULT: " + FormatHResult(exception.InnerException));
                Console.Error.WriteLine("Trace: " + DiagnosticTraceWriter.TracePath);
                return 3;
            }
            catch (InvalidCastException exception)
            {
                DiagnosticTraceWriter.WriteLine("ASSEMBLY ENTITY INVENTORY interop cast failure: " + FormatException(exception));
                Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: installed Interop contract mismatch.");
                Console.Error.WriteLine(exception);
                return 4;
            }
            catch (Exception exception)
            {
                DiagnosticTraceWriter.WriteLine("ASSEMBLY ENTITY INVENTORY unexpected failure: " + FormatException(exception));
                Console.Error.WriteLine("ASSEMBLY ENTITY INVENTORY: unexpected failure.");
                Console.Error.WriteLine(exception);
                return 1;
            }
            finally
            {
                ReleaseComObject(activeDocumentObject);
                ReleaseComObject(applicationObject);
                ReleaseComObject(appAccessObject);
            }
        }

        private static void TraverseOccurrence(
            interop.CimMdlrAPI.IAssInstance instance,
            string occurrencePath,
            int depth,
            bool isRoot,
            TraversalState state,
            ICollection<OccurrenceEvidence> occurrences,
            ICollection<BodyAttributeEvidence> bodyAttributes,
            bool inspectEntities,
            ISet<string> ancestorAssemblyDefinitions,
            ref int checkpointNumber,
            ref string activeCall)
        {
            if (depth > MaximumDepth)
            {
                state.DepthLimitReached = true;
                DiagnosticTraceWriter.WriteLine("TRAVERSAL LIMIT: maximum depth reached at " + occurrencePath);
                return;
            }

            if (!TryConsumeOccurrence(state, occurrencePath))
            {
                return;
            }

            int instanceId = RunApiCall(
                "IAssInstance.get_ID " + occurrencePath,
                () => instance.ID,
                ref checkpointNumber,
                ref activeCall);

            interop.CimMdlrAPI.AssInstance parent = null;
            string parentId = "ROOT/N/A";
            if (!isRoot)
            {
                parent = RunApiCall(
                    "IAssInstance.get_AssParentInstance " + occurrencePath,
                    () => instance.AssParentInstance,
                    ref checkpointNumber,
                    ref activeCall);
                parentId = parent == null
                    ? "<null>"
                    : RunApiCall(
                        "IAssInstance.get_ID(parent) " + occurrencePath,
                        () => ((interop.CimMdlrAPI.IAssInstance)parent).ID,
                        ref checkpointNumber,
                        ref activeCall).ToString(CultureInfo.InvariantCulture);
            }

            interop.CimMdlrAPI.AssInstance root = RunApiCall(
                "IAssInstance.get_AssRootInstance " + occurrencePath,
                () => instance.AssRootInstance,
                ref checkpointNumber,
                ref activeCall);
            int rootId = root == null ? 0 : RunApiCall(
                "IAssInstance.get_ID(root-ref) " + occurrencePath,
                () => ((interop.CimMdlrAPI.IAssInstance)root).ID,
                ref checkpointNumber,
                ref activeCall);
            int suppressed = RunApiCall(
                "IAssInstance.get_IsSuppressed " + occurrencePath,
                () => instance.IsSuppressed,
                ref checkpointNumber,
                ref activeCall);

            string ignoreInShowOperations = ReadIgnoreInShowOperations(
                instance,
                occurrencePath,
                ref checkpointNumber,
                ref activeCall);
            string visibilityAttribute = ReadOccurrenceVisibilityAttribute(
                instance,
                occurrencePath,
                interop.CimMdlrAPI.AttributeEnumType.cmAttVisibility,
                "cmAttVisibility",
                ref checkpointNumber,
                ref activeCall);
            string blankLevelAttribute = ReadOccurrenceVisibilityAttribute(
                instance,
                occurrencePath,
                interop.CimMdlrAPI.AttributeEnumType.cmAttBlankLevel,
                "cmAttBlankLevel",
                ref checkpointNumber,
                ref activeCall);
            string localTransform = ReadTransformation(instance, occurrencePath, 0, ref checkpointNumber, ref activeCall);
            string rootTransform = ReadTransformation(instance, occurrencePath, 1, ref checkpointNumber, ref activeCall);

            interop.CimMdlrAPI.IModel model = RunApiCall(
                "IAssInstance.get_Model " + occurrencePath,
                () => instance.Model,
                ref checkpointNumber,
                ref activeCall);
            string modelType = model == null ? "<null>" : RunApiCall(
                "IModel.get_Type " + occurrencePath,
                () => model.Type.ToString(),
                ref checkpointNumber,
                ref activeCall);
            string modelTitle = model == null ? string.Empty : RunApiCall(
                "IModel.get_Title " + occurrencePath,
                () => Safe(model.Title),
                ref checkpointNumber,
                ref activeCall);
            string modelPid = model == null ? string.Empty : RunApiCall(
                "IModel.get_PID " + occurrencePath,
                () => Safe(model.PID),
                ref checkpointNumber,
                ref activeCall);

            bool isAssemblyDefinition = string.Equals(modelType, "cmAssembly", StringComparison.Ordinal);
            bool definitionIdentityAvailable = isAssemblyDefinition && !string.IsNullOrEmpty(modelPid);
            bool definitionCycleDetected = definitionIdentityAvailable && ancestorAssemblyDefinitions.Contains(modelPid);

            OccurrenceEvidence occurrenceEvidence = new OccurrenceEvidence(
                occurrencePath,
                depth,
                instanceId,
                parentId,
                rootId,
                suppressed,
                ignoreInShowOperations,
                visibilityAttribute,
                blankLevelAttribute,
                modelType,
                modelTitle,
                modelPid,
                localTransform,
                rootTransform,
                isRoot);
            occurrences.Add(occurrenceEvidence);

            if (definitionCycleDetected)
            {
                state.RevisitCount++;
                occurrenceEvidence.EntityInspectionStatus = "SKIPPED_DEFINITION_CYCLE_GUARD";
                DiagnosticTraceWriter.WriteLine(
                    "TRAVERSAL DEFINITION CYCLE BLOCKED: ModelPID=" + modelPid + "; Path=" + occurrencePath);
                return;
            }

            occurrenceEvidence.EntityInspectionStatus = InspectOccurrenceBodies(
                instance,
                occurrencePath,
                state,
                bodyAttributes,
                inspectEntities,
                ref checkpointNumber,
                ref activeCall);

            object rawChildren = RunApiCall(
                "IAssInstance.get_SubInstances " + occurrencePath,
                () => instance.SubInstances[1, 0],
                ref checkpointNumber,
                ref activeCall);
            Array children = rawChildren as Array;
            if (rawChildren != null && children == null)
            {
                throw new InvalidOperationException(
                    "IAssInstance.get_SubInstances returned unsupported runtime type " + rawChildren.GetType().FullName + ".");
            }

            if (children == null)
            {
                return;
            }

            ISet<string> childAncestorAssemblyDefinitions = ancestorAssemblyDefinitions;
            if (definitionIdentityAvailable)
            {
                childAncestorAssemblyDefinitions = new HashSet<string>(
                    ancestorAssemblyDefinitions,
                    StringComparer.OrdinalIgnoreCase);
                childAncestorAssemblyDefinitions.Add(modelPid);
            }

            for (int index = 0; index < children.Length; index++)
            {
                interop.CimMdlrAPI.IAssInstance child = children.GetValue(index) as interop.CimMdlrAPI.IAssInstance;
                if (child == null)
                {
                    continue;
                }

                int childId = RunApiCall(
                    "IAssInstance.get_ID(child) " + occurrencePath,
                    () => child.ID,
                    ref checkpointNumber,
                    ref activeCall);
                string childSegment =
                    (childId > 0 ? childId.ToString(CultureInfo.InvariantCulture) : "no-id") +
                    "@ordinal-" + (index + 1).ToString(CultureInfo.InvariantCulture);
                string childPath = occurrencePath + "/" + childSegment;

                TraverseOccurrence(
                    child,
                    childPath,
                    depth + 1,
                    false,
                    state,
                    occurrences,
                    bodyAttributes,
                    inspectEntities,
                    childAncestorAssemblyDefinitions,
                    ref checkpointNumber,
                    ref activeCall);

                if (state.OccurrenceLimitReached)
                {
                    return;
                }
            }
        }

        private static string InspectOccurrenceBodies(
            interop.CimMdlrAPI.IAssInstance instance,
            string occurrencePath,
            TraversalState state,
            ICollection<BodyAttributeEvidence> bodyAttributes,
            bool inspectEntities,
            ref int checkpointNumber,
            ref string activeCall)
        {
            if (!inspectEntities)
            {
                return "DISABLED_OCCURRENCE_ONLY";
            }

            if (state.EntityInspectionLimitReached || state.EntityItemsInspected >= MaximumEntityInspections)
            {
                state.EntityInspectionLimitReached = true;
                return "ENTITIES_NOT_INSPECTED_ENTITY_BUDGET_EXHAUSTED";
            }

            interop.CimMdlrAPI.ICimEntityList entities = RunApiCall(
                "IAssInstance.GetAllEntities " + occurrencePath,
                () => instance.GetAllEntities(),
                ref checkpointNumber,
                ref activeCall);
            if (entities == null)
            {
                return "COMPLETE_NO_ENTITY_LIST";
            }

            int count = RunApiCall(
                "ICimEntityList.get_Count " + occurrencePath,
                () => entities.Count,
                ref checkpointNumber,
                ref activeCall);

            for (int index = 1; index <= count; index++)
            {
                if (!TryConsumeEntityInspection(
                    state,
                    occurrencePath + "/entity:" + index.ToString(CultureInfo.InvariantCulture)))
                {
                    return index == 1
                        ? "ENTITIES_NOT_INSPECTED_ENTITY_BUDGET_EXHAUSTED"
                        : "PARTIAL_ENTITY_INSPECTION_BUDGET_EXHAUSTED";
                }

                object rawEntity = RunApiCall(
                    "ICimEntityList.get_Item " + occurrencePath + " index=" + index.ToString(CultureInfo.InvariantCulture),
                    () => entities[index],
                    ref checkpointNumber,
                    ref activeCall);
                interop.CimMdlrAPI.ICimEntity entity = rawEntity as interop.CimMdlrAPI.ICimEntity;
                if (entity == null)
                {
                    continue;
                }

                string entityType = RunApiCall(
                    "ICimEntity.get_Type " + occurrencePath + " index=" + index.ToString(CultureInfo.InvariantCulture),
                    () => entity.Type.ToString(),
                    ref checkpointNumber,
                    ref activeCall);
                if (!string.Equals(entityType, "cmBody", StringComparison.Ordinal))
                {
                    continue;
                }

                int entityId = RunApiCall(
                    "ICimEntity.get_ID " + occurrencePath + " body-index=" + index.ToString(CultureInfo.InvariantCulture),
                    () => entity.ID,
                    ref checkpointNumber,
                    ref activeCall);

                interop.CimBaseAPI.IAttributeSink attributeSink = rawEntity as interop.CimBaseAPI.IAttributeSink;
                if (attributeSink == null)
                {
                    bodyAttributes.Add(new BodyAttributeEvidence(
                        occurrencePath,
                        entityId,
                        "IAttributeSink unavailable",
                        "IAttributeSink unavailable"));
                    continue;
                }

                string pocket = ReadNamedIntegerAttribute(
                    attributeSink,
                    PocketAttributeName,
                    occurrencePath,
                    entityId,
                    ref checkpointNumber,
                    ref activeCall);
                string cooling = ReadNamedIntegerAttribute(
                    attributeSink,
                    CoolingAttributeName,
                    occurrencePath,
                    entityId,
                    ref checkpointNumber,
                    ref activeCall);
                bodyAttributes.Add(new BodyAttributeEvidence(occurrencePath, entityId, pocket, cooling));
            }

            return "COMPLETE";
        }

        private static string ReadNamedIntegerAttribute(
            interop.CimBaseAPI.IAttributeSink attributeSink,
            string attributeName,
            string occurrencePath,
            int entityId,
            ref int checkpointNumber,
            ref string activeCall)
        {
            interop.CimBaseAPI.IAttribute attribute = RunApiCall(
                "IAttributeSink.GetAttribute(cmAttInteger, " + attributeName + ") " + occurrencePath +
                " body=" + entityId.ToString(CultureInfo.InvariantCulture),
                () => attributeSink.GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttInteger, attributeName),
                ref checkpointNumber,
                ref activeCall);
            if (attribute == null)
            {
                return "ABSENT";
            }

            object value = RunApiCall(
                "IAttribute.get_Value " + attributeName + " " + occurrencePath,
                () => attribute.Value,
                ref checkpointNumber,
                ref activeCall);
            return "PRESENT value=" + Convert.ToString(value, CultureInfo.InvariantCulture);
        }

        private static string ReadIgnoreInShowOperations(
            interop.CimMdlrAPI.IAssInstance instance,
            string occurrencePath,
            ref int checkpointNumber,
            ref string activeCall)
        {
            try
            {
                int value = RunApiCall(
                    "IAssInstance.get_IgnoreInShowOperations GETTER_ONLY " + occurrencePath,
                    () => instance.IgnoreInShowOperations,
                    ref checkpointNumber,
                    ref activeCall);
                return "PRESENT value=" + value.ToString(CultureInfo.InvariantCulture);
            }
            catch (ApiCallException exception)
            {
                string failure =
                    "READ_ERROR Exception=" + exception.InnerException.GetType().FullName +
                    " HRESULT=" + FormatHResult(exception.InnerException);
                DiagnosticTraceWriter.WriteLine(
                    "IgnoreInShowOperations READ FAILURE: Path=" + occurrencePath + "; " + failure);
                return failure;
            }
        }

        private static string ReadOccurrenceVisibilityAttribute(
            interop.CimMdlrAPI.IAssInstance instance,
            string occurrencePath,
            interop.CimMdlrAPI.AttributeEnumType attributeType,
            string attributeLabel,
            ref int checkpointNumber,
            ref string activeCall)
        {
            try
            {
                interop.CimMdlrAPI.IAttribute attribute = RunApiCall(
                    "IAssInstance.GetAttribute(" + attributeLabel + ", empty-name) GETTER_ONLY " + occurrencePath,
                    () => instance.GetAttribute(attributeType, string.Empty),
                    ref checkpointNumber,
                    ref activeCall);
                if (attribute == null)
                {
                    return "ABSENT";
                }

                object value = RunApiCall(
                    "IAttribute.get_Value " + attributeLabel + " OCCURRENCE_ONLY " + occurrencePath,
                    () => attribute.Value,
                    ref checkpointNumber,
                    ref activeCall);
                return "PRESENT value=" + Convert.ToString(value, CultureInfo.InvariantCulture);
            }
            catch (ApiCallException exception)
            {
                string failure =
                    "READ_ERROR Exception=" + exception.InnerException.GetType().FullName +
                    " HRESULT=" + FormatHResult(exception.InnerException);
                DiagnosticTraceWriter.WriteLine(
                    attributeLabel + " OCCURRENCE READ FAILURE: Path=" + occurrencePath + "; " + failure);
                return failure;
            }
        }

        private static string ReadTransformation(
            interop.CimMdlrAPI.IAssInstance instance,
            string occurrencePath,
            int rootParent,
            ref int checkpointNumber,
            ref string activeCall)
        {
            interop.CimMdlrAPI.ModelTransformation transformation = RunApiCall(
                "IAssInstance.get_Transformation(" + rootParent.ToString(CultureInfo.InvariantCulture) + ") " + occurrencePath,
                () => instance.Transformation[rootParent],
                ref checkpointNumber,
                ref activeCall);
            if (transformation == null)
            {
                return "<null>";
            }

            object matrix = RunApiCall(
                "IModelTransformation.get_Matrix " + occurrencePath,
                () => ((interop.CimMdlrAPI.IModelTransformation)transformation).Matrix,
                ref checkpointNumber,
                ref activeCall);
            object vector = RunApiCall(
                "IModelTransformation.get_Vector " + occurrencePath,
                () => ((interop.CimMdlrAPI.IModelTransformation)transformation).Vector,
                ref checkpointNumber,
                ref activeCall);
            return "Matrix=" + FormatObject(matrix) + "; Vector=" + FormatObject(vector);
        }

        private static NoMutationSnapshot CaptureNoMutationSnapshot(
            interop.CimatronE.ICimDocument document,
            string label,
            ref int checkpointNumber,
            ref string activeCall)
        {
            bool modified = RunApiCall(
                "ICimDocument.IsModified " + label,
                () => document.IsModified(),
                ref checkpointNumber,
                ref activeCall);
            string path = RunApiCall(
                "ICimDocument.GetPath " + label,
                () => Safe(document.GetPath()),
                ref checkpointNumber,
                ref activeCall);

            DateTime? lastWriteUtc = null;
            long? length = null;
            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                FileInfo info = new FileInfo(path);
                lastWriteUtc = info.LastWriteTimeUtc;
                length = info.Length;
            }

            DiagnosticTraceWriter.WriteLine(
                "NO-MUTATION " + label + ": Modified=" + modified.ToString() +
                "; Path=" + path +
                "; LastWriteUtc=" + FormatNullableDateTime(lastWriteUtc) +
                "; Length=" + FormatNullableLong(length));
            return new NoMutationSnapshot(path, modified, lastWriteUtc, length);
        }

        private static T RunApiCall<T>(
            string label,
            Func<T> call,
            ref int checkpointNumber,
            ref string activeCall)
        {
            activeCall = label;
            WriteCheckpoint(ref checkpointNumber, "BEGIN API " + label);
            using (ApiCallWatchdog watchdog = new ApiCallWatchdog(label))
            {
                try
                {
                    T value = call();
                    watchdog.Complete();
                    WriteCheckpoint(ref checkpointNumber, "END API " + label);
                    activeCall = string.Empty;
                    return value;
                }
                catch (Exception exception)
                {
                    watchdog.Complete();
                    DiagnosticTraceWriter.WriteLine(
                        "API FAILURE: " + label + "; " + FormatException(exception));
                    throw new ApiCallException(label, exception);
                }
            }
        }

        private static bool TryConsumeOccurrence(TraversalState state, string location)
        {
            if (state.OccurrencesObserved >= MaximumOccurrences)
            {
                state.OccurrenceLimitReached = true;
                DiagnosticTraceWriter.WriteLine(
                    "TRAVERSAL LIMIT: maximum occurrence count " + MaximumOccurrences.ToString(CultureInfo.InvariantCulture) +
                    " reached at " + location);
                return false;
            }

            state.OccurrencesObserved++;
            return true;
        }

        private static bool TryConsumeEntityInspection(TraversalState state, string location)
        {
            if (state.EntityItemsInspected >= MaximumEntityInspections)
            {
                state.EntityInspectionLimitReached = true;
                DiagnosticTraceWriter.WriteLine(
                    "ENTITY INSPECTION LIMIT: maximum entity item count " +
                    MaximumEntityInspections.ToString(CultureInfo.InvariantCulture) +
                    " reached at " + location);
                return false;
            }

            state.EntityItemsInspected++;
            return true;
        }

        private static StringBuilder BuildEvidence(
            interop.CimatronE.IApplication application,
            string documentType,
            NoMutationSnapshot beforeSnapshot,
            NoMutationSnapshot afterSnapshot,
            bool noMutationObserved,
            TraversalState state,
            IEnumerable<OccurrenceEvidence> occurrences,
            IEnumerable<BodyAttributeEvidence> bodyAttributes,
            bool inspectEntities,
            TimeSpan elapsed)
        {
            StringBuilder evidence = new StringBuilder();
            evidence.AppendLine("CIMATRON STEP 05C2-B CONTROLLED ASSEMBLY OCCURRENCE / ENTITY DIAGNOSTIC");
            evidence.AppendLine("ToolVersion: 0.15.30");
            evidence.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture));
            evidence.AppendLine("CimatronProduct: " + Safe(application.ProductName));
            evidence.AppendLine("CimatronVersion: " + Safe(application.Version));
            evidence.AppendLine("ActiveDocumentType: " + documentType);
            evidence.AppendLine("Mode: " + (inspectEntities ? "READ_ONLY_ALLOW_LIST" : "READ_ONLY_OCCURRENCE_ONLY"));
            evidence.AppendLine("EntityInspectionEnabled: " + inspectEntities.ToString());
            evidence.AppendLine("TotalRunTime: " + FormatElapsed(elapsed));
            evidence.AppendLine("ApiCallTimeoutMilliseconds: " + ApiCallTimeoutMilliseconds.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("ApiCallTimeoutExitCode: " + ApiCallTimeoutExitCode.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("MaximumDepth: " + MaximumDepth.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("MaximumOccurrences: " + MaximumOccurrences.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("MaximumEntityInspections: " + MaximumEntityInspections.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("OccurrenceIdentity: full traversal path with sibling ordinal; InstanceId is evidence only and is not occurrence identity");
            evidence.AppendLine("CycleGuard: ancestor assembly definition ModelPID only; missing ModelPID falls back to depth/occurrence limits");
            evidence.AppendLine("CycleGuardRuntimeStatus: recursive self-assembly cycle not exercised in live Cimatron validation");
            evidence.AppendLine("LegacyShowProbe: CLOSED BY USER-VALIDATED 0.15.29 RUN — _IAssInstance compatibility failed for every occurrence with InvalidCastException / HRESULT 0x80004002 (E_NOINTERFACE)");
            evidence.AppendLine("OccurrenceVisibilityProbe: compatible IAssInstance getter/attribute comparison only — IgnoreInShowOperations, cmAttVisibility, cmAttBlankLevel");
            evidence.AppendLine("OccurrenceVisibilityMutation: PROHIBITED / NOT CALLED");
            evidence.AppendLine("OccurrenceVisibilitySemantics: raw candidate values are evidence only until compared against known visible, hidden-not-suppressed, and suppressed occurrences");
            evidence.AppendLine("OpenLoadActivateComponentDocuments: PROHIBITED / NOT CALLED");
            evidence.AppendLine("MutationCalls: PROHIBITED / NOT CALLED");
            evidence.AppendLine();
            evidence.AppendLine("NO-MUTATION EVIDENCE");
            evidence.AppendLine("Before: " + beforeSnapshot.ToEvidenceLine());
            evidence.AppendLine("After : " + afterSnapshot.ToEvidenceLine());
            evidence.AppendLine("Result: " + (noMutationObserved ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
            evidence.AppendLine();
            evidence.AppendLine("TRAVERSAL / INSPECTION GUARDS");
            evidence.AppendLine("OccurrencesObserved: " + state.OccurrencesObserved.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("EntityItemsInspected: " + state.EntityItemsInspected.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("RevisitCount: " + state.RevisitCount.ToString(CultureInfo.InvariantCulture) + " (definition-cycle blocks only)");
            evidence.AppendLine("DepthLimitReached: " + state.DepthLimitReached.ToString());
            evidence.AppendLine("OccurrenceLimitReached: " + state.OccurrenceLimitReached.ToString());
            evidence.AppendLine("EntityInspectionLimitReached: " + state.EntityInspectionLimitReached.ToString());
            evidence.AppendLine();
            evidence.AppendLine("OCCURRENCES");
            evidence.AppendLine("Path | Depth | InstanceId | ParentId | RootId | Suppressed | IgnoreInShowOperations | cmAttVisibility(occurrence) | cmAttBlankLevel(occurrence) | ModelType | ModelTitle | ModelPID | Transform(0) | Transform(1) | RootPseudoInstance | EntityInspectionStatus");
            foreach (OccurrenceEvidence occurrence in occurrences)
            {
                evidence.AppendLine(occurrence.ToEvidenceLine());
            }

            evidence.AppendLine();
            evidence.AppendLine("VALIDATION FINDINGS / ACCEPTANCE STATUS");
            evidence.AppendLine("MbCoolingViaOccurrence: PROVEN BY USER-VALIDATED 0.15.23 RUN (body under occurrence root:-1/8/137, MbCooling value=1)");
            evidence.AppendLine("MbPocketViaOccurrence: PROVEN BY USER-VALIDATED 0.15.24 KNOWN-ANSWER RUN (real Mold Pocket body, cmAttInteger MbPocket value=1)");
            evidence.AppendLine("SuppressedOccurrenceDetection: PROVEN BY USER-VALIDATED 0.15.24 KNOWN-ANSWER RUN (Block_B Suppressed=1)");
            evidence.AppendLine("OccurrenceIdentityFinding: InstanceId is not authoritative placed-occurrence identity; occurrence path is authoritative for CR-11 FR-020 reporting");
            evidence.AppendLine("HiddenStateDetection: RUNTIME CANDIDATE COMPARISON PENDING — compare raw IAssInstance IgnoreInShowOperations/cmAttVisibility/cmAttBlankLevel evidence for visible Block_A, hidden-not-suppressed Known_Pocket_Body, and suppressed Block_B before assigning semantics");
            evidence.AppendLine("KnownAnswer05C2B: REPEATED-OCCURRENCE PORTION PROVEN BY USER-VALIDATED 0.15.25 RUN; legacy _IAssInstance Show_ route closed by 0.15.29 E_NOINTERFACE evidence; FR-021 remains open pending this 0.15.30 compatible-IAssInstance comparison");
            evidence.AppendLine("FalseNegativeRule: an occurrence marked ENTITIES_NOT_INSPECTED/PARTIAL/DISABLED must not be interpreted as absence of MbPocket or MbCooling");
            evidence.AppendLine();
            evidence.AppendLine("OCCURRENCE-REACHED BODY ATTRIBUTE CHECKS");
            evidence.AppendLine("Path | BodyEntityId | MbPocket(cmAttInteger) | MbCooling(cmAttInteger)");
            foreach (BodyAttributeEvidence bodyAttribute in bodyAttributes)
            {
                evidence.AppendLine(bodyAttribute.ToEvidenceLine());
            }

            return evidence;
        }

        private static void WriteCheckpoint(ref int checkpointNumber, string message)
        {
            checkpointNumber++;
            string checkpoint =
                "CHECKPOINT " + checkpointNumber.ToString("D3", CultureInfo.InvariantCulture) +
                " [" + DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture) + "]: " +
                message;
            DiagnosticTraceWriter.WriteLine(checkpoint);
            DiagnosticTraceWriter.SetLastCheckpoint(
                "CHECKPOINT " + checkpointNumber.ToString("D3", CultureInfo.InvariantCulture) + " " + message);
            Console.WriteLine(checkpoint);
            Console.Out.Flush();
        }

        private static string FormatObject(object value)
        {
            if (value == null)
            {
                return "<null>";
            }

            Array array = value as Array;
            if (array == null)
            {
                return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
            }

            StringBuilder builder = new StringBuilder("[");
            for (int index = 0; index < array.Length; index++)
            {
                if (index > 0)
                {
                    builder.Append(',');
                }

                builder.Append(Convert.ToString(array.GetValue(index), CultureInfo.InvariantCulture));
            }

            builder.Append(']');
            return builder.ToString();
        }

        private static string FormatElapsed(TimeSpan elapsed)
        {
            return elapsed.TotalMilliseconds.ToString("0", CultureInfo.InvariantCulture) + " ms";
        }

        private static string FormatException(Exception exception)
        {
            return "ExceptionType=" + exception.GetType().FullName +
                "; HRESULT=" + FormatHResult(exception) +
                "; Message=" + exception.Message;
        }

        private static string FormatHResult(Exception exception)
        {
            return "0x" + Marshal.GetHRForException(exception).ToString("X8", CultureInfo.InvariantCulture);
        }

        private static string FormatNullableDateTime(DateTime? value)
        {
            return value.HasValue ? value.Value.ToString("O", CultureInfo.InvariantCulture) : "N/A";
        }

        private static string FormatNullableLong(long? value)
        {
            return value.HasValue ? value.Value.ToString(CultureInfo.InvariantCulture) : "N/A";
        }

        private static string Safe(string value)
        {
            return value ?? string.Empty;
        }

        private static void ReleaseComObject(object value)
        {
            if (value != null && Marshal.IsComObject(value))
            {
                Marshal.FinalReleaseComObject(value);
            }
        }

        private sealed class ApiCallWatchdog : IDisposable
        {
            private readonly ManualResetEvent completed = new ManualResetEvent(false);
            private readonly Thread watcher;
            private bool disposed;

            internal ApiCallWatchdog(string label)
            {
                watcher = new Thread(delegate()
                {
                    if (completed.WaitOne(ApiCallTimeoutMilliseconds))
                    {
                        return;
                    }

                    string message =
                        "API TIMEOUT: " + label + "; TimeoutMs=" +
                        ApiCallTimeoutMilliseconds.ToString(CultureInfo.InvariantCulture) +
                        "; ExitCode=" + ApiCallTimeoutExitCode.ToString(CultureInfo.InvariantCulture);
                    DiagnosticTraceWriter.SetLastCheckpoint("TIMEOUT " + label);
                    DiagnosticTraceWriter.WriteLine(message);
                    Console.Error.WriteLine(message);
                    Console.Error.WriteLine("Trace: " + DiagnosticTraceWriter.TracePath);
                    Console.Error.Flush();
                    Environment.Exit(ApiCallTimeoutExitCode);
                });
                watcher.IsBackground = true;
                watcher.Name = "AssemblyApiCallWatchdog";
                watcher.Start();
            }

            internal void Complete()
            {
                completed.Set();
            }

            public void Dispose()
            {
                if (disposed)
                {
                    return;
                }

                disposed = true;
                completed.Set();
                watcher.Join(250);
                completed.Dispose();
            }
        }

        private sealed class ApiCallException : Exception
        {
            internal ApiCallException(string label, Exception innerException)
                : base("Call=" + label + "; " + FormatException(innerException), innerException)
            {
            }
        }

        private sealed class TraversalState
        {
            internal int OccurrencesObserved { get; set; }
            internal int EntityItemsInspected { get; set; }
            internal int RevisitCount { get; set; }
            internal bool DepthLimitReached { get; set; }
            internal bool OccurrenceLimitReached { get; set; }
            internal bool EntityInspectionLimitReached { get; set; }
        }

        private sealed class NoMutationSnapshot
        {
            internal NoMutationSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            private string Path { get; }
            private bool Modified { get; }
            private DateTime? LastWriteUtc { get; }
            private long? Length { get; }

            internal string ToEvidenceLine()
            {
                return "Path=" + Path +
                    "; Modified=" + Modified.ToString() +
                    "; LastWriteUtc=" + FormatNullableDateTime(LastWriteUtc) +
                    "; Length=" + FormatNullableLong(Length);
            }

            internal static bool IsEquivalent(NoMutationSnapshot before, NoMutationSnapshot after)
            {
                bool fileEvidenceAvailable =
                    !string.IsNullOrEmpty(before.Path) &&
                    before.LastWriteUtc.HasValue &&
                    before.Length.HasValue &&
                    after.LastWriteUtc.HasValue &&
                    after.Length.HasValue;
                return fileEvidenceAvailable &&
                    string.Equals(before.Path, after.Path, StringComparison.OrdinalIgnoreCase) &&
                    before.Modified == after.Modified &&
                    before.LastWriteUtc == after.LastWriteUtc &&
                    before.Length == after.Length;
            }
        }

        private sealed class OccurrenceEvidence
        {
            internal OccurrenceEvidence(
                string path,
                int depth,
                int instanceId,
                string parentId,
                int rootId,
                int suppressed,
                string ignoreInShowOperations,
                string visibilityAttribute,
                string blankLevelAttribute,
                string modelType,
                string modelTitle,
                string modelPid,
                string localTransform,
                string rootTransform,
                bool rootPseudoInstance)
            {
                Path = path;
                Depth = depth;
                InstanceId = instanceId;
                ParentId = parentId;
                RootId = rootId;
                Suppressed = suppressed;
                IgnoreInShowOperations = ignoreInShowOperations;
                VisibilityAttribute = visibilityAttribute;
                BlankLevelAttribute = blankLevelAttribute;
                ModelType = modelType;
                ModelTitle = modelTitle;
                ModelPid = modelPid;
                LocalTransform = localTransform;
                RootTransform = rootTransform;
                RootPseudoInstance = rootPseudoInstance;
            }

            private string Path { get; }
            private int Depth { get; }
            private int InstanceId { get; }
            private string ParentId { get; }
            private int RootId { get; }
            private int Suppressed { get; }
            private string IgnoreInShowOperations { get; }
            private string VisibilityAttribute { get; }
            private string BlankLevelAttribute { get; }
            private string ModelType { get; }
            private string ModelTitle { get; }
            private string ModelPid { get; }
            private string LocalTransform { get; }
            private string RootTransform { get; }
            private bool RootPseudoInstance { get; }
            internal string EntityInspectionStatus { get; set; }

            internal string ToEvidenceLine()
            {
                return Path + " | " +
                    Depth.ToString(CultureInfo.InvariantCulture) + " | " +
                    InstanceId.ToString(CultureInfo.InvariantCulture) + " | " +
                    ParentId + " | " +
                    RootId.ToString(CultureInfo.InvariantCulture) + " | " +
                    Suppressed.ToString(CultureInfo.InvariantCulture) + " | " +
                    IgnoreInShowOperations + " | " + VisibilityAttribute + " | " + BlankLevelAttribute + " | " +
                    ModelType + " | " + ModelTitle + " | " + ModelPid + " | " +
                    LocalTransform + " | " + RootTransform + " | " + RootPseudoInstance.ToString() + " | " +
                    (string.IsNullOrEmpty(EntityInspectionStatus) ? "NOT_RECORDED" : EntityInspectionStatus);
            }
        }

        private sealed class BodyAttributeEvidence
        {
            internal BodyAttributeEvidence(string path, int entityId, string pocket, string cooling)
            {
                Path = path;
                EntityId = entityId;
                Pocket = pocket;
                Cooling = cooling;
            }

            private string Path { get; }
            private int EntityId { get; }
            private string Pocket { get; }
            private string Cooling { get; }

            internal string ToEvidenceLine()
            {
                return Path + " | " +
                    EntityId.ToString(CultureInfo.InvariantCulture) + " | " +
                    Pocket + " | " + Cooling;
            }
        }
    }
}
