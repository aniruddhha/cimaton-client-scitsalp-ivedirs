using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    internal static class CommandPoolInventory
    {
        private static readonly string[] CandidateTerms =
        {
            "zoom", "fit", "view", "frame", "camera", "selection", "selected", "window"
        };

        internal static int Run(string expectedContext)
        {
            object appAccess = null;
            object applicationObject = null;
            object activeDocumentObject = null;
            object poolCommandsObject = null;

            try
            {
                appAccess = new interop.CimAppAccess.AppAccess();
                applicationObject = ((interop.CimAppAccess.AppAccess)appAccess).GetApplication();
                if (applicationObject == null)
                {
                    Console.Error.WriteLine("COMMAND INVENTORY: Cimatron is not running or is unavailable.");
                    return 2;
                }

                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)applicationObject;
                activeDocumentObject = application.GetActiveDoc();
                if (activeDocumentObject == null)
                {
                    Console.Error.WriteLine("COMMAND INVENTORY: Cimatron has no active document.");
                    return 4;
                }

                interop.CimatronE.ICimDocument activeDocument = (interop.CimatronE.ICimDocument)activeDocumentObject;
                string documentType = activeDocument.Type.ToString();
                string normalizedContext = NormalizeDocumentContext(documentType);
                if (!string.IsNullOrWhiteSpace(expectedContext) &&
                    !string.Equals(expectedContext, normalizedContext, StringComparison.OrdinalIgnoreCase))
                {
                    Console.Error.WriteLine("COMMAND INVENTORY: active document context is " + normalizedContext + ", expected " + expectedContext + ".");
                    return 4;
                }

                poolCommandsObject = application.GetPoolCommands();
                if (poolCommandsObject == null)
                {
                    Console.Error.WriteLine("COMMAND INVENTORY: GetPoolCommands returned null.");
                    return 4;
                }

                interop.CimBaseAPI.IPoolCommands commands = (interop.CimBaseAPI.IPoolCommands)poolCommandsObject;
                string[] allCommands = commands.GetCommandsNames() ?? Array.Empty<string>();
                string[] orderedCommands = allCommands
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .OrderBy(value => value, StringComparer.OrdinalIgnoreCase)
                    .ToArray();

                StringBuilder output = new StringBuilder();
                output.AppendLine("CIMATRON NATIVE COMMAND POOL INVENTORY");
                output.AppendLine("ToolVersion: 0.15.9");
                output.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O"));
                output.AppendLine("CimatronProduct: " + Safe(application.ProductName));
                output.AppendLine("CimatronVersion: " + Safe(application.Version));
                output.AppendLine("ActiveDocumentType: " + documentType);
                output.AppendLine("ActiveContext: " + normalizedContext);
                output.AppendLine("CommandCount: " + orderedCommands.Length);
                output.AppendLine("ReadOnly: TRUE");
                output.AppendLine();
                output.AppendLine("COMMANDS");
                foreach (string command in orderedCommands)
                {
                    output.AppendLine(command);
                }

                string evidencePath = EvidenceWriter.Write(
                    "zoom-command-pool-" + normalizedContext.ToLowerInvariant(),
                    output.ToString());

                string[] candidates = orderedCommands.Where(IsCandidate).ToArray();
                Console.WriteLine("COMMAND INVENTORY: SUCCESS");
                Console.WriteLine("Cimatron: " + Safe(application.ProductName) + " " + Safe(application.Version));
                Console.WriteLine("Active context: " + normalizedContext + " (" + documentType + ")");
                Console.WriteLine("Commands: " + orderedCommands.Length);
                Console.WriteLine("Candidate commands: " + candidates.Length);
                Console.WriteLine();
                foreach (string candidate in candidates)
                {
                    Console.WriteLine(candidate);
                }
                Console.WriteLine();
                Console.WriteLine("Evidence file: " + evidencePath);
                Console.WriteLine("READ-ONLY: no Cimatron command was executed and no selection/model/view state was modified.");
                return 0;
            }
            catch (COMException exception)
            {
                Console.Error.WriteLine("COMMAND INVENTORY: standalone attach/COM activation failure.");
                Console.Error.WriteLine(exception);
                return 3;
            }
            catch (InvalidCastException exception)
            {
                Console.Error.WriteLine("COMMAND INVENTORY: installed Interop contract mismatch.");
                Console.Error.WriteLine(exception);
                return 4;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("COMMAND INVENTORY: unexpected failure.");
                Console.Error.WriteLine(exception);
                return 1;
            }
            finally
            {
                ReleaseComObject(poolCommandsObject);
                ReleaseComObject(activeDocumentObject);
                ReleaseComObject(applicationObject);
                ReleaseComObject(appAccess);
            }
        }

        private static string NormalizeDocumentContext(string documentType)
        {
            if (string.Equals(documentType, "cmPart", StringComparison.Ordinal)) return "Part";
            if (string.Equals(documentType, "cmAssembly", StringComparison.Ordinal)) return "Assembly";
            if (string.Equals(documentType, "cmNc", StringComparison.Ordinal)) return "Nc";
            return "Unsupported";
        }

        private static bool IsCandidate(string command)
        {
            return CandidateTerms.Any(term => command.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static string Safe(string value)
        {
            return value ?? string.Empty;
        }

        private static void ReleaseComObject(object value)
        {
            if (value != null && Marshal.IsComObject(value))
            {
                Marshal.FinalReleaseComObject(value);
            }
        }
    }
}
