using System;
using System.IO;
using System.Text;

namespace CimatronCustomization.ZoomCommandDiscovery
{
    internal static class EvidenceWriter
    {
        internal static string Write(string fileStem, string content)
        {
            string directory = Path.Combine(Environment.CurrentDirectory, "artifacts", "diagnostics");
            Directory.CreateDirectory(directory);
            string timestamp = DateTimeOffset.Now.ToString("yyyyMMdd-HHmmss");
            string path = Path.Combine(directory, fileStem + "-" + timestamp + ".txt");
            File.WriteAllText(path, content, new UTF8Encoding(false));
            return Path.GetFullPath(path);
        }
    }
}
