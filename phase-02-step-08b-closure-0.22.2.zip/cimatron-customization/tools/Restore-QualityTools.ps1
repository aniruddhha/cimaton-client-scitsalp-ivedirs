Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
Push-Location $repoRoot
try {
    dotnet --info | Out-Null
    if ($LASTEXITCODE -ne 0) { throw '.NET SDK is required to restore local quality tools.' }

    dotnet tool restore
    if ($LASTEXITCODE -ne 0) { throw 'dotnet tool restore failed.' }

    Write-Host 'QUALITY TOOLS RESTORE: PASS'
}
finally {
    Pop-Location
}
