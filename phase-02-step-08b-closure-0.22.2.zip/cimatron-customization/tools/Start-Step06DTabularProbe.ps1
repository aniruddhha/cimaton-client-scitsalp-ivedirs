param(
    [string]$InputFile,
    [string]$EvidenceFile
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$requestDirectory = Join-Path $env:TEMP 'CimatronCustomization'
$requestFile = Join-Path $requestDirectory 'step06d-tabular-probe.request'

if ([string]::IsNullOrWhiteSpace($InputFile)) {
    $InputFile = Join-Path $repoRoot 'tests\CimatronCustomization.Infrastructure.Tests\TestData\Step06\LegacyInput.xls'
}
if ([string]::IsNullOrWhiteSpace($EvidenceFile)) {
    $EvidenceFile = Join-Path $repoRoot ('artifacts\console-captures\step06d-tabular-probe-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
}

if (-not (Test-Path -LiteralPath $InputFile -PathType Leaf)) { throw "Probe input fixture not found: $InputFile" }

$evidenceDirectory = Split-Path -Parent $EvidenceFile
if (-not (Test-Path -LiteralPath $evidenceDirectory)) { New-Item -ItemType Directory -Path $evidenceDirectory -Force | Out-Null }
if (-not (Test-Path -LiteralPath $requestDirectory)) { New-Item -ItemType Directory -Path $requestDirectory -Force | Out-Null }

$resolvedInput = (Resolve-Path -LiteralPath $InputFile).Path
$resolvedEvidence = [System.IO.Path]::GetFullPath($EvidenceFile)
$requestedUtc = [DateTimeOffset]::UtcNow.ToString('O')
$lines = @(
    'Version=0.19.0',
    ('RequestedUtc=' + $requestedUtc),
    ('InputFile=' + $resolvedInput),
    ('EvidenceFile=' + $resolvedEvidence)
)
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($requestFile, $lines, $utf8NoBom)

Write-Host 'STEP 06D CIMATRON MAPPED TABULAR PROBE PREPARATION'
Write-Host "RequestFile: $requestFile"
Write-Host "InputFile: $resolvedInput"
Write-Host "EvidenceFile: $resolvedEvidence"
Write-Host "RequestedUtc: $requestedUtc"
Write-Host ''
Write-Host 'Probe request prepared. This script does NOT launch Cimatron.'
Write-Host 'Start Cimatron normally, open a disposable Part/Assembly document if needed, then click Cimatron Customization once.'
Write-Host 'The plugin will execute ReadMappedTabularData through the real ExcelDataReader adapter and write one-shot evidence.'
