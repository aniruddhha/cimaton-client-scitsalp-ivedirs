using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace CimatronCustomization.KnownAnswerModelSetup
{
    internal static class Program
    {
        internal const string ToolVersion = "0.20.22";
        private const string RequiredAttributeName = "STEP07_B1_TEST_ATTRIBUTE";
        private const string RequiredAttributeValue = "KNOWN_ANSWER_07C3";

        private static int Main(string[] args)
        {
            try
            {
                Arguments parsed = Arguments.Parse(args);
                if (!parsed.Apply)
                    throw new ArgumentException("Mutation is disabled unless --apply is supplied explicitly.");
                if (!string.Equals(parsed.ExpectedContext, "Part", StringComparison.OrdinalIgnoreCase))
                    throw new ArgumentException("Known-answer setup requires --expect Part.");
                if (!string.Equals(parsed.ModelTitle, "KA-PART-1", StringComparison.Ordinal))
                    throw new ArgumentException("Known-answer setup is restricted to --model-title KA-PART-1.");
                if (parsed.EntityId != 4)
                    throw new ArgumentException("Known-answer setup is restricted to --entity-id 4.");
                if (!string.Equals(parsed.AttributeName, RequiredAttributeName, StringComparison.Ordinal))
                    throw new ArgumentException("Known-answer setup requires --attribute-name " + RequiredAttributeName + ".");
                if (!string.Equals(parsed.AttributeValue, RequiredAttributeValue, StringComparison.Ordinal))
                    throw new ArgumentException("Known-answer setup requires --attribute-value " + RequiredAttributeValue + ".");

                return Apply(parsed);
            }
            catch (Exception ex)
            {
                Exception raw = Unwrap(ex);
                Console.Error.WriteLine("KNOWN-ANSWER SETUP FAILED: " + raw.GetType().FullName + ": " + raw.Message);
                return 1;
            }
        }

        private static int Apply(Arguments args)
        {
            StringBuilder evidence = new StringBuilder();
            object appAccessObject = null;
            object applicationObject = null;
            object documentObject = null;
            try
            {
                evidence.AppendLine("CIMATRON STEP 07 KNOWN-ANSWER MODEL SETUP");
                evidence.AppendLine("ToolVersion: " + ToolVersion);
                evidence.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture));
                evidence.AppendLine("Operation: CONTROLLED_MODEL_MUTATION");
                evidence.AppendLine("AutoSave: DISABLED");

                appAccessObject = new interop.CimAppAccess.AppAccess();
                applicationObject = ((interop.CimAppAccess.AppAccess)appAccessObject).GetApplication();
                if (applicationObject == null) throw new InvalidOperationException("Cimatron is not running or unavailable.");
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)applicationObject;

                documentObject = application.GetActiveDoc();
                if (documentObject == null) throw new InvalidOperationException("Cimatron has no active document.");
                interop.CimatronE.ICimDocument document = (interop.CimatronE.ICimDocument)documentObject;
                if (!string.Equals(document.Type.ToString(), "cmPart", StringComparison.Ordinal))
                    throw new InvalidOperationException("Active document must be a Part; observed " + document.Type + ".");

                interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
                if (container == null) throw new InvalidOperationException("Active Part does not expose IModelContainer.");
                interop.CimMdlrAPI.IModel model = container.Model as interop.CimMdlrAPI.IModel;
                if (model == null) throw new InvalidOperationException("Active Part does not expose IModel.");
                if (!string.Equals(model.Title, args.ModelTitle, StringComparison.Ordinal))
                    throw new InvalidOperationException("Active model title is '" + model.Title + "', expected '" + args.ModelTitle + "'.");

                interop.CimMdlrAPI.ICimEntity entity = model.GetEntityById(args.EntityId, model);
                if (entity == null) throw new InvalidOperationException("Entity " + args.EntityId.ToString(CultureInfo.InvariantCulture) + " was not found.");
                if (!string.Equals(entity.Type.ToString(), "cmBody", StringComparison.Ordinal))
                    throw new InvalidOperationException("Entity " + args.EntityId.ToString(CultureInfo.InvariantCulture) + " must be cmBody; observed " + entity.Type + ".");

                interop.CimBaseAPI.IAttributeSink sink = entity as interop.CimBaseAPI.IAttributeSink;
                if (sink == null) throw new InvalidOperationException("B1 body does not expose IAttributeSink.");

                evidence.AppendLine("ActiveContext: Part");
                evidence.AppendLine("ModelTitle: " + model.Title);
                evidence.AppendLine("EntityId: " + args.EntityId.ToString(CultureInfo.InvariantCulture));
                evidence.AppendLine("EntityType: " + entity.Type);
                evidence.AppendLine("AttributeType: cmAttString");
                evidence.AppendLine("AttributeName: " + args.AttributeName);
                evidence.AppendLine("AttributeValue: " + args.AttributeValue);

                ExistingAttributeState state = InspectExisting(sink, args.AttributeName, args.AttributeValue, evidence);
                if (state == ExistingAttributeState.AlreadyPresent)
                {
                    evidence.AppendLine("Result: ALREADY_PRESENT");
                    evidence.AppendLine("MutationPerformed: NO");
                    WriteEvidence(evidence);
                    Console.WriteLine(evidence.ToString());
                    return 0;
                }
                if (state == ExistingAttributeState.Conflict)
                    throw new InvalidOperationException("An attribute with the requested name already exists with a different type or value; overwrite is prohibited.");

                interop.CimBaseAPI.IAttributeFactory factory = (interop.CimBaseAPI.IAttributeFactory)application.GetAttributeFactory();
                if (factory == null) throw new InvalidOperationException("IApplication.GetAttributeFactory() returned null.");
                interop.CimBaseAPI.IAttribute attribute = factory.Create(interop.CimBaseAPI.AttributeEnumType.cmAttString, args.AttributeName);
                if (attribute == null) throw new InvalidOperationException("IAttributeFactory.Create(cmAttString, name) returned null.");
                attribute.Value = args.AttributeValue;
                sink.Attach(attribute);

                interop.CimBaseAPI.IAttribute readBack = sink.GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttString, args.AttributeName);
                if (readBack == null) throw new InvalidOperationException("Exact attribute read-back returned null after Attach().");
                string readBackValue = Convert.ToString(readBack.Value, CultureInfo.InvariantCulture);
                string readBackNameLine = "ReadBack.Name: " + readBack.Name;
                string readBackTypeLine = "ReadBack.Type: " + readBack.Type;
                string readBackValueLine = "ReadBack.Value: " + readBackValue;
                evidence.AppendLine(readBackNameLine);
                evidence.AppendLine(readBackTypeLine);
                evidence.AppendLine(readBackValueLine);
                Console.WriteLine(readBackNameLine);
                Console.WriteLine(readBackTypeLine);
                Console.WriteLine(readBackValueLine);

                if (!string.Equals(readBack.Type.ToString(), "cmAttString", StringComparison.Ordinal) ||
                    !string.Equals(readBackValue, args.AttributeValue, StringComparison.Ordinal))
                    throw new InvalidOperationException("Exact named attribute read-back did not match the requested type/value.");
                evidence.AppendLine("Result: ATTACHED_AND_READ_BACK");
                evidence.AppendLine("MutationPerformed: YES");
                evidence.AppendLine("MODEL MUTATED IN MEMORY - MANUAL SAVE REQUIRED");
                evidence.AppendLine("DO NOT CONTINUE TO 07C-3 UNTIL KA-PART-1 IS SAVED AND KA-ASM-1 IS REOPENED/RELOADED.");

                WriteEvidence(evidence);
                Console.WriteLine(evidence.ToString());
                return 0;
            }
            finally
            {
                Release(documentObject);
                Release(applicationObject);
                Release(appAccessObject);
            }
        }

        private static ExistingAttributeState InspectExisting(interop.CimBaseAPI.IAttributeSink sink, string name, string value, StringBuilder evidence)
        {
            object[] attributes = sink.GetAttributes();
            evidence.AppendLine("ExistingAttributeCount: " + (attributes == null ? 0 : attributes.Length).ToString(CultureInfo.InvariantCulture));
            if (attributes == null) return ExistingAttributeState.Absent;

            foreach (object item in attributes)
            {
                interop.CimBaseAPI.IAttribute attribute = item as interop.CimBaseAPI.IAttribute;
                if (attribute == null || !string.Equals(attribute.Name, name, StringComparison.Ordinal)) continue;
                string existingValue = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture);
                evidence.AppendLine("ExistingMatch.Name: " + attribute.Name);
                evidence.AppendLine("ExistingMatch.Type: " + attribute.Type);
                evidence.AppendLine("ExistingMatch.Value: " + existingValue);
                return string.Equals(attribute.Type.ToString(), "cmAttString", StringComparison.Ordinal) &&
                       string.Equals(existingValue, value, StringComparison.Ordinal)
                    ? ExistingAttributeState.AlreadyPresent
                    : ExistingAttributeState.Conflict;
            }

            return ExistingAttributeState.Absent;
        }

        private static void WriteEvidence(StringBuilder evidence)
        {
            string directory = Path.Combine(Environment.CurrentDirectory, "artifacts", "diagnostics");
            Directory.CreateDirectory(directory);
            string path = Path.Combine(directory, "known-answer-body-attribute-setup-" + DateTimeOffset.Now.ToString("yyyyMMdd-HHmmss") + ".txt");
            File.WriteAllText(path, evidence.ToString(), new UTF8Encoding(false));
            Console.WriteLine("EvidenceFile: " + Path.GetFullPath(path));
        }

        private static Exception Unwrap(Exception ex)
        {
            return ex is System.Reflection.TargetInvocationException && ex.InnerException != null ? ex.InnerException : ex;
        }

        private static void Release(object value)
        {
            if (value != null && Marshal.IsComObject(value)) Marshal.FinalReleaseComObject(value);
        }

        private enum ExistingAttributeState { Absent, AlreadyPresent, Conflict }

        private sealed class Arguments
        {
            internal string ExpectedContext { get; private set; }
            internal string ModelTitle { get; private set; }
            internal int EntityId { get; private set; }
            internal string AttributeName { get; private set; }
            internal string AttributeValue { get; private set; }
            internal bool Apply { get; private set; }

            internal static Arguments Parse(string[] args)
            {
                Arguments parsed = new Arguments();
                for (int index = 0; index < args.Length; index++)
                {
                    string key = args[index];
                    if (string.Equals(key, "--apply", StringComparison.OrdinalIgnoreCase)) { parsed.Apply = true; continue; }
                    if (index + 1 >= args.Length) throw new ArgumentException("Missing value for " + key + ".");
                    string value = args[++index];
                    if (string.Equals(key, "--expect", StringComparison.OrdinalIgnoreCase)) parsed.ExpectedContext = value;
                    else if (string.Equals(key, "--model-title", StringComparison.OrdinalIgnoreCase)) parsed.ModelTitle = value;
                    else if (string.Equals(key, "--entity-id", StringComparison.OrdinalIgnoreCase)) parsed.EntityId = ParseInt(key, value);
                    else if (string.Equals(key, "--attribute-name", StringComparison.OrdinalIgnoreCase)) parsed.AttributeName = value;
                    else if (string.Equals(key, "--attribute-value", StringComparison.OrdinalIgnoreCase)) parsed.AttributeValue = value;
                    else throw new ArgumentException("Unknown argument " + key + ".");
                }
                return parsed;
            }

            private static int ParseInt(string key, string value)
            {
                int result;
                if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result))
                    throw new ArgumentException(key + " requires an integer.");
                return result;
            }
        }
    }
}
