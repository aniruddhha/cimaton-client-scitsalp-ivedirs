param(
    [Parameter(Mandatory = $true)][string]$ProjectKey,
    [Parameter(Mandatory = $true)][string]$HostUrl,
    [Parameter(Mandatory = $true)][string]$Token
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$solution = Join-Path $repoRoot 'CimatronCustomization.sln'
$coverageXml = Join-Path $repoRoot 'artifacts\coverage\coverage.xml'
$msbuild = & (Join-Path $PSScriptRoot 'Get-MSBuildPath.ps1')

if (Get-Process -Name 'CimatronE' -ErrorAction SilentlyContinue) {
    throw 'Close Cimatron before SonarQube analysis because the build may need to replace the plugin DLL.'
}

Push-Location $repoRoot
try {
    dotnet tool restore
    if ($LASTEXITCODE -ne 0) { throw 'dotnet tool restore failed.' }

    $beginArgs = @(
        'tool', 'run', 'dotnet-sonarscanner', 'begin',
        "/k:$ProjectKey",
        "/d:sonar.host.url=$HostUrl",
        "/d:sonar.token=$Token"
    )
    if (Test-Path $coverageXml) {
        $beginArgs += "/d:sonar.cs.vscoveragexml.reportsPaths=$coverageXml"
    }

    & dotnet @beginArgs
    if ($LASTEXITCODE -ne 0) { throw 'SonarScanner begin step failed.' }

    & $msbuild $solution /restore /t:Rebuild /p:Configuration=Release /p:Platform=x64 /m
    if ($LASTEXITCODE -ne 0) { throw 'Build inside SonarQube analysis failed.' }

    dotnet tool run dotnet-sonarscanner end "/d:sonar.token=$Token"
    if ($LASTEXITCODE -ne 0) { throw 'SonarScanner end step failed.' }

    Write-Host 'SONARQUBE ANALYSIS: SUBMITTED'
}
finally {
    Pop-Location
}
