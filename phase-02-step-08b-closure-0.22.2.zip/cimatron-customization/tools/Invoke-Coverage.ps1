Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$coverageDir = Join-Path $repoRoot 'artifacts\coverage'
New-Item -ItemType Directory -Force -Path $coverageDir | Out-Null

$domainExe = Join-Path $repoRoot 'tests\CimatronCustomization.Domain.Tests\bin\x64\Release\CimatronCustomization.Domain.Tests.exe'
$appExe = Join-Path $repoRoot 'tests\CimatronCustomization.Application.Tests\bin\x64\Release\CimatronCustomization.Application.Tests.exe'
$infraExe = Join-Path $repoRoot 'tests\CimatronCustomization.Infrastructure.Tests\bin\x64\Release\CimatronCustomization.Infrastructure.Tests.exe'
$cimatronIntegrationExe = Join-Path $repoRoot 'tests\CimatronCustomization.CimatronIntegrationTests\bin\x64\Release\CimatronCustomization.CimatronIntegrationTests.exe'

if (-not (Test-Path $domainExe)) { throw "Release Domain.Tests executable not found: $domainExe" }
if (-not (Test-Path $appExe)) { throw "Release Application.Tests executable not found: $appExe" }
if (-not (Test-Path $infraExe)) { throw "Release Infrastructure.Tests executable not found: $infraExe" }
if (-not (Test-Path $cimatronIntegrationExe)) { throw "Release CimatronIntegrationTests executable not found: $cimatronIntegrationExe" }

Push-Location $repoRoot
try {
    dotnet tool restore
    if ($LASTEXITCODE -ne 0) { throw 'dotnet tool restore failed.' }

    $settings = Join-Path $repoRoot 'coverage.settings.xml'
    $domain = Join-Path $coverageDir 'domain.coverage.xml'
    $app = Join-Path $coverageDir 'application.coverage.xml'
    $infra = Join-Path $coverageDir 'infrastructure.coverage.xml'
    $cimatronIntegration = Join-Path $coverageDir 'cimatron-integration.coverage.xml'
    $merged = Join-Path $coverageDir 'coverage.cobertura.xml'

    dotnet tool run dotnet-coverage collect --settings $settings --output-format cobertura --output $domain ('"' + $domainExe + '"')
    if ($LASTEXITCODE -ne 0) { throw 'Domain coverage collection failed.' }

    dotnet tool run dotnet-coverage collect --settings $settings --output-format cobertura --output $app ('"' + $appExe + '"')
    if ($LASTEXITCODE -ne 0) { throw 'Application coverage collection failed.' }

    dotnet tool run dotnet-coverage collect --settings $settings --output-format cobertura --output $infra ('"' + $infraExe + '"')
    if ($LASTEXITCODE -ne 0) { throw 'Infrastructure coverage collection failed.' }

    dotnet tool run dotnet-coverage collect --settings $settings --output-format cobertura --output $cimatronIntegration ('"' + $cimatronIntegrationExe + '"')
    if ($LASTEXITCODE -ne 0) { throw 'CimatronIntegration coverage collection failed.' }

    dotnet tool run dotnet-coverage merge $domain $app $infra $cimatronIntegration --output-format cobertura --output $merged
    if ($LASTEXITCODE -ne 0) { throw 'Coverage merge failed.' }

    Write-Host 'COVERAGE COLLECTION: PASS'
    Write-Host "Cobertura: $merged"
}
finally {
    Pop-Location
}
