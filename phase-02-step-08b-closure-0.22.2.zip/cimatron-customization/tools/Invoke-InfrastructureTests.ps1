Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$testExe = Join-Path $repoRoot 'tests\CimatronCustomization.Infrastructure.Tests\bin\x64\Release\CimatronCustomization.Infrastructure.Tests.exe'
if (-not (Test-Path $testExe)) { throw "Release Infrastructure.Tests executable not found: $testExe" }
& $testExe
if ($LASTEXITCODE -ne 0) { throw "INFRASTRUCTURE TESTS: FAIL (exit code $LASTEXITCODE)" }
