Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$solution = Join-Path $repoRoot 'CimatronCustomization.sln'

$cimatron = Get-Process -Name 'CimatronE' -ErrorAction SilentlyContinue
if ($null -ne $cimatron) {
    throw 'CimatronE.exe is running and can lock the plugin DLL. Close Cimatron completely before the Release build.'
}

$msbuild = & (Join-Path $PSScriptRoot 'Get-MSBuildPath.ps1')
Write-Host "MSBuild: $msbuild"

& $msbuild $solution /restore /t:Rebuild /p:Configuration=Release /p:Platform=x64 /m
if ($LASTEXITCODE -ne 0) {
    throw "Release x64 build failed with exit code $LASTEXITCODE."
}

Write-Host 'RELEASE X64 BUILD: PASS'
