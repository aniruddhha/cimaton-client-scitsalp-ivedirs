Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$testExe = Join-Path $repoRoot 'tests\CimatronCustomization.Domain.Tests\bin\x64\Release\CimatronCustomization.Domain.Tests.exe'

if (-not (Test-Path $testExe)) {
    throw "Release Domain.Tests executable not found: $testExe"
}

& $testExe
if ($LASTEXITCODE -ne 0) {
    throw "Domain tests failed with exit code $LASTEXITCODE."
}
