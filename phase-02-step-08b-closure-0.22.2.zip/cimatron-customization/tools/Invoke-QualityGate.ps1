param(
    [switch]$SkipCoverage
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
Write-Host '----------------------------------------'
Write-Host 'CIMATRON CUSTOMIZATION QUALITY GATE'
Write-Host '----------------------------------------'

& (Join-Path $PSScriptRoot 'Restore-QualityTools.ps1')
& (Join-Path $PSScriptRoot 'Invoke-ReleaseBuild.ps1')
& (Join-Path $PSScriptRoot 'Invoke-ArchitectureTests.ps1')
& (Join-Path $PSScriptRoot 'Invoke-DomainTests.ps1')
& (Join-Path $PSScriptRoot 'Invoke-ApplicationTests.ps1')
& (Join-Path $PSScriptRoot 'Invoke-CimatronIntegrationTests.ps1')
& (Join-Path $PSScriptRoot 'Invoke-InfrastructureTests.ps1')

if (-not $SkipCoverage) {
    & (Join-Path $PSScriptRoot 'Invoke-Coverage.ps1')
    & (Join-Path $PSScriptRoot 'Test-CoverageGate.ps1') -AllowFoundationNoGovernedCode
}
else {
    Write-Host 'COVERAGE: SKIPPED BY USER OPTION'
}

Write-Host 'LOCAL QUALITY GATE: PASS'
Write-Host 'SonarQube remains a separate server-side gate and requires Invoke-SonarQube.ps1 with approved server credentials.'
