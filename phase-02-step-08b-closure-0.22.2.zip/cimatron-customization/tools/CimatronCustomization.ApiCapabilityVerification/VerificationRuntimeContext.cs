using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal sealed class VerificationRuntimeContext : IDisposable
    {
        private object appAccessObject;
        private object applicationObject;
        private object documentObject;

        private VerificationRuntimeContext() { Evidence = new StringBuilder(); }
        internal interop.CimatronE.IApplication Application { get; private set; }
        internal interop.CimatronE.ICimDocument Document { get; private set; }
        internal interop.CimMdlrAPI.IModel Model { get; private set; }
        internal StringBuilder Evidence { get; }

        internal static VerificationRuntimeContext Attach(string expectedContext, string mode)
        {
            if (string.IsNullOrWhiteSpace(expectedContext)) throw new ArgumentException(mode + " requires --expect Part|Assembly.");
            VerificationRuntimeContext context = new VerificationRuntimeContext();
            context.appAccessObject = new interop.CimAppAccess.AppAccess();
            context.applicationObject = ((interop.CimAppAccess.AppAccess)context.appAccessObject).GetApplication();
            if (context.applicationObject == null) throw new InvalidOperationException("Cimatron is not running or unavailable.");
            context.Application = (interop.CimatronE.IApplication)context.applicationObject;
            context.documentObject = context.Application.GetActiveDoc();
            if (context.documentObject == null) throw new InvalidOperationException("Cimatron has no active document.");
            context.Document = (interop.CimatronE.ICimDocument)context.documentObject;
            string actual = NormalizeContext(context.Document.Type.ToString());
            if (!string.Equals(actual, expectedContext, StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Active context is " + actual + ", expected " + expectedContext + ".");
            interop.CimMdlrAPI.IModelContainer container = context.Document as interop.CimMdlrAPI.IModelContainer;
            if (container == null) throw new InvalidOperationException("Active document does not expose IModelContainer.");
            context.Model = container.Model as interop.CimMdlrAPI.IModel;
            if (context.Model == null) throw new InvalidOperationException("Active document does not expose IModel.");
            context.Evidence.AppendLine("CIMATRON STEP 07 LIVE CAPABILITY VERIFICATION"); context.Evidence.AppendLine("ToolVersion: " + Program.ToolVersion); context.Evidence.AppendLine("Mode: " + mode);
            context.Evidence.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O", CultureInfo.InvariantCulture)); context.Evidence.AppendLine("CimatronProduct: " + context.Application.ProductName); context.Evidence.AppendLine("CimatronVersion: " + context.Application.Version);
            context.Evidence.AppendLine("ActiveDocumentType: " + context.Document.Type); context.Evidence.AppendLine("ActiveContext: " + actual); context.Evidence.AppendLine("Unit: " + context.Document.Unit); context.Evidence.AppendLine("ModelPID: " + context.Model.PID);
            return context;
        }

        internal T Observe<T>(string label, Func<T> call)
        {
            try { T value = call(); Evidence.AppendLine(label + ": PRESENT value=" + Format(value)); return value; }
            catch (Exception ex) { Exception raw = Unwrap(ex); Evidence.AppendLine(label + ": READ_ERROR type=" + raw.GetType().FullName + " HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) + " message=" + raw.Message); throw; }
        }

        internal bool TryObserve<T>(string label, Func<T> call, out T value)
        {
            try { value = call(); Evidence.AppendLine(label + ": PRESENT value=" + Format(value)); return true; }
            catch (Exception ex) { Exception raw = Unwrap(ex); Evidence.AppendLine(label + ": READ_ERROR type=" + raw.GetType().FullName + " HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) + " message=" + raw.Message); value = default(T); return false; }
        }

        internal interop.CimMdlrAPI.ICimEntity GetEntity(int id) => Model.GetEntityById(id, Model);
        internal static string Format(object value)
        {
            if (value == null) return "<null>"; Array array = value as Array; if (array != null) { List<string> values = new List<string>(); foreach (object item in array) values.Add(Format(item)); return "[" + string.Join(",", values) + "]"; } return Convert.ToString(value, CultureInfo.InvariantCulture);
        }
        internal static string NormalizeContext(string type) { if (string.Equals(type, "cmPart", StringComparison.Ordinal)) return "Part"; if (string.Equals(type, "cmAssembly", StringComparison.Ordinal)) return "Assembly"; return "Unsupported"; }
        internal static Exception Unwrap(Exception ex) => ex is System.Reflection.TargetInvocationException && ex.InnerException != null ? ex.InnerException : ex;
        public void Dispose() { Release(documentObject); Release(applicationObject); Release(appAccessObject); documentObject = null; applicationObject = null; appAccessObject = null; }
        internal static void Release(object value) { if (value != null && Marshal.IsComObject(value)) Marshal.FinalReleaseComObject(value); }
    }
}
