using System;
using System.IO;
using System.Text;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class VerificationEvidenceWriter
    {
        internal static string Write(string stem, string content)
        {
            string directory = Path.Combine(Environment.CurrentDirectory, "artifacts", "diagnostics");
            Directory.CreateDirectory(directory);
            string path = Path.Combine(directory, stem + "-" + DateTimeOffset.Now.ToString("yyyyMMdd-HHmmss") + ".txt");
            File.WriteAllText(path, content, new UTF8Encoding(false));
            return Path.GetFullPath(path);
        }
    }
}
