using System;
using System.Collections.Generic;
using System.Globalization;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class GeometryKnownAnswerDiscovery
    {
        internal static int Run(VerificationArguments args)
        {
            using (VerificationRuntimeContext context = VerificationRuntimeContext.Attach(args.ExpectedContext, "07C-1A GEOMETRY KNOWN-ANSWER DISCOVERY"))
            {
                NoMutationEvidence before = NoMutationEvidence.Capture(context.Document);
                try
                {
                    context.Evidence.AppendLine("Purpose: Record actual KA-PART-1 model/body/face/edge/UCS identifiers and read-only geometry values before 07C-1 verification.");
                    context.Evidence.AppendLine("SelectionPolicy: ENUMERATE_ONLY; no body/face/edge/UCS role is inferred from index or ID.");
                    context.Evidence.AppendLine("ModelTitle: " + context.Model.Title);

                    interop.CimMdlrAPI.IMdlrModel mdlrModel = (interop.CimMdlrAPI.IMdlrModel)context.Model;
                    interop.CimServicesAPI.IGeomServices geometry = context.Observe("GetGeomServicesObj", () => (interop.CimServicesAPI.IGeomServices)mdlrModel.GetGeomServicesObj());

                    interop.CimMdlrAPI.ICimEntityList bodies = SelectByEntityType(context, interop.CimBaseAPI.EntityEnumType.cmBody, "Bodies");
                    int bodyCount = bodies == null ? 0 : bodies.Count;
                    context.Evidence.AppendLine("Bodies.Count: " + bodyCount.ToString(CultureInfo.InvariantCulture));

                    interop.CimServicesAPI.IUcs activeUcs = ResolveActiveUcs(context);
                    RecordBodies(context, geometry, bodies, activeUcs);
                    RecordBodyPairDistance(context, geometry, bodies);
                    RecordEntities(context, interop.CimBaseAPI.EntityEnumType.cmFace, "Faces", null);
                    RecordEntities(context, interop.CimBaseAPI.EntityEnumType.cmEdge, "Edges", geometry);
                    RecordUcsCandidates(context, geometry, bodies, activeUcs);
                }
                finally
                {
                    NoMutationEvidence after = NoMutationEvidence.Capture(context.Document);
                    bool unchanged = before.IsEquivalentTo(after);
                    context.Evidence.AppendLine("NoMutationBefore: " + before);
                    context.Evidence.AppendLine("NoMutationAfter: " + after);
                    context.Evidence.AppendLine("No-mutation evidence: " + (unchanged ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
                    context.Evidence.AppendLine("InterpretationBoundary: User must map enumerated IDs to B1/B2/test face/convex edge/concave edge/KA_UCS_90Z from known-answer evidence; the tool does not guess roles.");
                    string path = VerificationEvidenceWriter.Write("api-capability-geometry-known-answer-discovery", context.Evidence.ToString());
                    Console.WriteLine("Evidence file: " + path);
                    if (!unchanged) Environment.ExitCode = 8;
                }
                return Environment.ExitCode == 8 ? 8 : 0;
            }
        }

        private static interop.CimMdlrAPI.ICimEntityList SelectByEntityType(VerificationRuntimeContext context, interop.CimBaseAPI.EntityEnumType type, string label)
        {
            try
            {
                interop.CimMdlrAPI.IEntityQuery query = (interop.CimMdlrAPI.IEntityQuery)context.Model;
                interop.CimMdlrAPI.IEntityFilter rawFilter = query.CreateFilter(interop.CimMdlrAPI.EFilterEnumType.cmFilterEntityType);
                interop.CimBaseAPI.FilterType typeFilter = (interop.CimBaseAPI.FilterType)rawFilter;
                typeFilter.Add(type);
                query.SetFilter(rawFilter);
                interop.CimMdlrAPI.ICimEntityList result = query.Select();
                context.Evidence.AppendLine(label + ".Enumeration: PRESENT count=" + result.Count.ToString(CultureInfo.InvariantCulture));
                return result;
            }
            catch (Exception ex)
            {
                WriteError(context, label + ".Enumeration", ex);
                return null;
            }
        }

        private static interop.CimServicesAPI.IUcs ResolveActiveUcs(VerificationRuntimeContext context)
        {
            object activeUcsObject;
            if (!context.TryObserve("ActivateUcs.GET", () => ((interop.CimMdlrAPI.IMdlrModel)context.Model).ActivateUcs, out activeUcsObject) || activeUcsObject == null)
            {
                context.Evidence.AppendLine("ActiveUcs.Entity: ABSENT reason=ActivateUcs returned null/error");
                return null;
            }

            interop.CimMdlrAPI.ICimEntity activeEntity = activeUcsObject as interop.CimMdlrAPI.ICimEntity;
            if (activeEntity != null)
            {
                context.Evidence.AppendLine("ActiveUcs.Entity: PRESENT id=" + activeEntity.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + activeEntity.Type);
            }
            else
            {
                context.Evidence.AppendLine("ActiveUcs.Entity: ID_UNAVAILABLE reason=active UCS does not expose ICimEntity through installed runtime interface");
            }

            return activeUcsObject as interop.CimServicesAPI.IUcs;
        }

        private static void RecordBodies(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, interop.CimMdlrAPI.ICimEntityList bodies, interop.CimServicesAPI.IUcs activeUcs)
        {
            if (bodies == null) return;
            for (int i = 1; i <= bodies.Count; i++)
            {
                interop.CimMdlrAPI.ICimEntity body = (interop.CimMdlrAPI.ICimEntity)bodies[i];
                context.Evidence.AppendLine("Body[" + i.ToString(CultureInfo.InvariantCulture) + "]: id=" + body.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + body.Type);

                interop.CimBaseAPI.CimEntityList singleBase = new interop.CimBaseAPI.CimEntityList();
                interop.CimServicesAPI.ICimEntityList single = (interop.CimServicesAPI.ICimEntityList)singleBase;
                single.Add((interop.CimServicesAPI.ICimEntity)body);

                context.TryObserve("Body[" + i + "].Volume", () => geometry.BodiesVolume(single), out double _);
                context.TryObserve("Body[" + i + "].Center", () => (double[])geometry.BodiesCenter(single), out double[] _);
                context.TryObserve("Body[" + i + "].SurfaceArea", () => geometry.BodiesSurfArea(single), out double _);
                if (activeUcs != null)
                {
                    context.TryObserve("Body[" + i + "].BoundingBox.ActiveUcs", () => (double[])geometry.GetBoundingBoxByUCS(single, activeUcs), out double[] _);
                }
            }
        }

        private static void RecordBodyPairDistance(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, interop.CimMdlrAPI.ICimEntityList bodies)
        {
            if (bodies == null || bodies.Count != 2)
            {
                context.Evidence.AppendLine("BodyPair.MinDistance: NOT_RUN reason=expected exactly 2 enumerated bodies for KA-PART-1, actual=" + (bodies == null ? "0" : bodies.Count.ToString(CultureInfo.InvariantCulture)));
                return;
            }

            interop.CimServicesAPI.ICimEntity first = bodies[1] as interop.CimServicesAPI.ICimEntity;
            interop.CimServicesAPI.ICimEntity second = bodies[2] as interop.CimServicesAPI.ICimEntity;
            if (first == null || second == null)
            {
                context.Evidence.AppendLine("BodyPair.MinDistance: NOT_RUN reason=body service-interface cast failed");
                return;
            }

            try
            {
                interop.CimServicesAPI.IPointData firstPoint;
                interop.CimServicesAPI.IPointData secondPoint;
                double distance = geometry.MinDistancePos(first, second, out firstPoint, out secondPoint);
                context.Evidence.AppendLine("BodyPair.MinDistance: PRESENT bodyA=" + ((interop.CimMdlrAPI.ICimEntity)bodies[1]).ID.ToString(CultureInfo.InvariantCulture) + "; bodyB=" + ((interop.CimMdlrAPI.ICimEntity)bodies[2]).ID.ToString(CultureInfo.InvariantCulture) + "; distance=" + distance.ToString("R", CultureInfo.InvariantCulture) + "; pointA=" + FormatPoint(firstPoint) + "; pointB=" + FormatPoint(secondPoint));
            }
            catch (Exception ex)
            {
                WriteError(context, "BodyPair.MinDistance", ex);
            }
        }

        private static void RecordEntities(VerificationRuntimeContext context, interop.CimBaseAPI.EntityEnumType type, string label, interop.CimServicesAPI.IGeomServices geometry)
        {
            interop.CimMdlrAPI.ICimEntityList entities = SelectByEntityType(context, type, label);
            if (entities == null) return;
            for (int i = 1; i <= entities.Count; i++)
            {
                interop.CimMdlrAPI.ICimEntity entity = (interop.CimMdlrAPI.ICimEntity)entities[i];
                string prefix = label.TrimEnd('s') + "[" + i.ToString(CultureInfo.InvariantCulture) + "]";
                context.Evidence.AppendLine(prefix + ": id=" + entity.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + entity.Type);
                if (geometry != null)
                {
                    interop.CimServicesAPI.ICimEntity serviceEntity = entity as interop.CimServicesAPI.ICimEntity;
                    if (serviceEntity == null)
                    {
                        context.Evidence.AppendLine(prefix + ".Convexity@0.5: NOT_RUN reason=service-interface cast failed");
                    }
                    else
                    {
                        context.TryObserve(prefix + ".Convexity@0.5", () => geometry.GetEdgeConvexity(serviceEntity, 0.5d), out interop.CimServicesAPI.EdgeConvexityType _);
                    }
                }
            }
        }

        private static void RecordUcsCandidates(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, interop.CimMdlrAPI.ICimEntityList bodies, interop.CimServicesAPI.IUcs activeUcs)
        {
            List<string> ucsEnumNames = new List<string>();
            foreach (string name in Enum.GetNames(typeof(interop.CimBaseAPI.EntityEnumType)))
            {
                if (name.IndexOf("ucs", StringComparison.OrdinalIgnoreCase) >= 0) ucsEnumNames.Add(name);
            }
            context.Evidence.AppendLine("UcsEntityEnumCandidates: " + (ucsEnumNames.Count == 0 ? "NONE" : string.Join(",", ucsEnumNames.ToArray())));

            foreach (string enumName in ucsEnumNames)
            {
                interop.CimBaseAPI.EntityEnumType enumValue = (interop.CimBaseAPI.EntityEnumType)Enum.Parse(typeof(interop.CimBaseAPI.EntityEnumType), enumName, false);
                interop.CimMdlrAPI.ICimEntityList candidates = SelectByEntityType(context, enumValue, "UcsCandidates." + enumName);
                if (candidates == null) continue;
                for (int i = 1; i <= candidates.Count; i++)
                {
                    interop.CimMdlrAPI.ICimEntity entity = (interop.CimMdlrAPI.ICimEntity)candidates[i];
                    interop.CimServicesAPI.IUcs ucs = entity as interop.CimServicesAPI.IUcs;
                    context.Evidence.AppendLine("UcsCandidate[" + enumName + "," + i.ToString(CultureInfo.InvariantCulture) + "]: id=" + entity.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + entity.Type + "; serviceUcs=" + (ucs == null ? "NO" : "YES"));
                    if (ucs != null && bodies != null)
                    {
                        interop.CimServicesAPI.ICimEntityList serviceBodies = bodies as interop.CimServicesAPI.ICimEntityList;
                        if (serviceBodies != null) context.TryObserve("UcsCandidate[" + enumName + "," + i + "].AllBodiesBoundingBox", () => (double[])geometry.GetBoundingBoxByUCS(serviceBodies, ucs), out double[] _);
                    }
                }
            }

            if (activeUcs == null)
            {
                context.Evidence.AppendLine("KnownAnswerUcsInstruction: Activate KA_UCS_90Z in Cimatron and rerun if its ID cannot be unambiguously mapped from UcsCandidate evidence.");
            }
            else
            {
                context.Evidence.AppendLine("KnownAnswerUcsInstruction: Confirm the active UCS was KA_UCS_90Z when this run was captured before recording ActiveUcs.Entity as the known-answer UCS ID.");
            }
        }

        private static string FormatPoint(interop.CimServicesAPI.IPointData point)
        {
            interop.CimServicesAPI.IGeom3DPoint p = point as interop.CimServicesAPI.IGeom3DPoint;
            return p == null ? VerificationRuntimeContext.Format(point) : p.X.ToString("R", CultureInfo.InvariantCulture) + "," + p.Y.ToString("R", CultureInfo.InvariantCulture) + "," + p.Z.ToString("R", CultureInfo.InvariantCulture);
        }

        private static void WriteError(VerificationRuntimeContext context, string label, Exception ex)
        {
            Exception raw = VerificationRuntimeContext.Unwrap(ex);
            context.Evidence.AppendLine(label + ": READ_ERROR type=" + raw.GetType().FullName + " HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) + " message=" + raw.Message);
        }
    }
}
