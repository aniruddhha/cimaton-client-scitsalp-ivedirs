using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class ComponentPropertySourceVerification
    {
        internal static int Run(VerificationArguments args)
        {
            if (string.IsNullOrWhiteSpace(args.ModelTitle) || !args.EntityId.HasValue)
                throw new ArgumentException("Component-property mode requires --model-title and --entity-id.");
            if (string.IsNullOrWhiteSpace(args.KnownAttributeName) || string.IsNullOrWhiteSpace(args.KnownAttributeValue))
                throw new ArgumentException("Component-property mode requires --known-attribute-name and --known-attribute-value.");
            if (string.IsNullOrWhiteSpace(args.KnownMaterial))
                throw new ArgumentException("Component-property mode requires --known-material.");

            using (VerificationRuntimeContext context = VerificationRuntimeContext.Attach(args.ExpectedContext, "07C-3 COMPONENT PROPERTY SOURCES"))
            {
                NoMutationEvidence before = NoMutationEvidence.Capture(context.Document);
                FolderSnapshot folderBefore = FolderSnapshot.Capture(before.Path);
                bool unchanged = false;
                bool folderUnchanged = false;
                try
                {
                    context.Evidence.AppendLine("KnownAnswer.ModelTitle: " + args.ModelTitle);
                    context.Evidence.AppendLine("KnownAnswer.EntityId: " + args.EntityId.Value.ToString(CultureInfo.InvariantCulture));
                    context.Evidence.AppendLine("KnownAnswer.AttributeName: " + args.KnownAttributeName);
                    context.Evidence.AppendLine("KnownAnswer.AttributeValue: " + args.KnownAttributeValue);
                    context.Evidence.AppendLine("KnownAnswer.Material: " + args.KnownMaterial);
                    context.Evidence.AppendLine("07C-4.HiddenStateInterpretation: OUT_OF_SCOPE");
                    context.Evidence.AppendLine("U17.ModelPropertyGetter: NOT_AVAILABLE_FROM_RETAINED_07A_EVIDENCE; no new reflection or speculative invocation performed");

                    interop.CimMdlrAPI.IAssemblyModel assembly = (interop.CimMdlrAPI.IAssemblyModel)context.Model;
                    interop.CimMdlrAPI.IAssInstance instance = FindInstance(assembly, args.ModelTitle);
                    if (instance == null)
                        throw new InvalidOperationException("No instance matches model title " + args.ModelTitle + ".");

                    interop.CimMdlrAPI.ICimEntity partEntity = FindBodyEntityOnOccurrence(context, instance, args.EntityId.Value);
                    context.Evidence.AppendLine("PartModelEntity.Type: " + partEntity.Type);

                    interop.CimMdlrAPI.ICimEntity assemblyEntity = assembly.GetAssemblyEntity(partEntity, (interop.CimMdlrAPI.AssInstance)instance);
                    AttributeObservation partAttributes = WriteAttributes(context, "PartModelEntity", partEntity, args.KnownAttributeName, args.KnownAttributeValue);
                    AttributeObservation assemblyAttributes = WriteAttributes(context, "AssemblyContextEntity", assemblyEntity, args.KnownAttributeName, args.KnownAttributeValue);
                    context.Evidence.AppendLine("U13.KnownBodyAttribute.PartModelEntity: " + partAttributes);
                    context.Evidence.AppendLine("U13.KnownBodyAttribute.AssemblyContextEntity: " + assemblyAttributes);
                    context.Evidence.AppendLine("U14.InstanceAttributeGetter: NOT_AVAILABLE; retained 07A evidence shows IAssInstance.Attribute SET-ONLY; no getter invoked");

                    string tempFolder = CreateTempFolder();
                    context.Evidence.AppendLine("BOM.TempFolder: " + tempFolder);
                    interop.CimMdlrAPI.IBOM bom = context.Observe("GetBomManager", () => assembly.GetBomManager());
                    ExportAndSummarize(context, bom, Path.Combine(tempFolder, "bom-all"), interop.CimMdlrAPI.ComponentsFilterOption.cmNoFiltering, args.ModelTitle, args.KnownMaterial);
                    ExportAndSummarize(context, bom, Path.Combine(tempFolder, "bom-visible"), interop.CimMdlrAPI.ComponentsFilterOption.cmVisibleOnly, args.ModelTitle, args.KnownMaterial);
                    context.Evidence.AppendLine("U15.VisibilityDifferenceInterpretation: NOT_PERFORMED; reserved for separately approved 07C-4");
                }
                finally
                {
                    NoMutationEvidence after = NoMutationEvidence.Capture(context.Document);
                    FolderSnapshot folderAfter = FolderSnapshot.Capture(after.Path);
                    unchanged = before.IsEquivalentTo(after);
                    folderUnchanged = folderBefore.IsEquivalentTo(folderAfter);
                    context.Evidence.AppendLine("NoMutationBefore: " + before);
                    context.Evidence.AppendLine("NoMutationAfter: " + after);
                    context.Evidence.AppendLine("No-mutation evidence: " + (unchanged ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
                    context.Evidence.AppendLine("ModelFolderBefore: " + folderBefore);
                    context.Evidence.AppendLine("ModelFolderAfter: " + folderAfter);
                    context.Evidence.AppendLine("Model-folder listing evidence: " + (folderUnchanged ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
                    if (!folderUnchanged)
                        context.Evidence.AppendLine("Model-folder guard note: report observed changes; do not automatically classify unrelated Cimatron-generated files as model mutation.");
                    string path = VerificationEvidenceWriter.Write("api-capability-component-properties", context.Evidence.ToString());
                    Console.WriteLine("Evidence file: " + path);
                }

                return unchanged && folderUnchanged ? 0 : 8;
            }
        }

        internal static void ExportAndSummarize(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IBOM bom,
            string stem,
            interop.CimMdlrAPI.ComponentsFilterOption filter)
        {
            ExportAndSummarize(context, bom, stem, filter, null, null);
        }

        internal static void ExportAndSummarize(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IBOM bom,
            string stem,
            interop.CimMdlrAPI.ComponentsFilterOption filter,
            string modelTitle,
            string knownMaterial)
        {
            bom.Export(stem,
                interop.CimMdlrAPI.BOMTemplateType.cmCSV,
                (interop.CimMdlrAPI.BOMExportOptions)0,
                string.Empty,
                interop.CimMdlrAPI.BOMReportFormat.cmNotReq,
                filter,
                Array.Empty<string>());

            string folder = Path.GetDirectoryName(stem);
            string[] candidates = Directory.GetFiles(folder, Path.GetFileName(stem) + "*");
            context.Evidence.AppendLine("BOM.Export." + filter + ": PRESENT files=" + string.Join(",", candidates.Select(Path.GetFileName)));
            context.Evidence.AppendLine("BOM.Export." + filter + ".OutputRoot=" + folder);

            foreach (string file in candidates.Where(f => string.Equals(Path.GetExtension(f), ".csv", StringComparison.OrdinalIgnoreCase)))
            {
                string[] lines = File.ReadAllLines(file);
                context.Evidence.AppendLine("BOM.CSV." + filter + ".File=" + Path.GetFileName(file));
                context.Evidence.AppendLine("BOM.CSV." + filter + ".Header=" + (lines.Length == 0 ? string.Empty : lines[0]));
                context.Evidence.AppendLine("BOM.CSV." + filter + ".DataRowCount=" + Math.Max(0, lines.Length - 1).ToString(CultureInfo.InvariantCulture));
                if (!string.IsNullOrWhiteSpace(modelTitle) && !string.IsNullOrWhiteSpace(knownMaterial))
                    SummarizeKnownAnswerRows(context, filter, lines, modelTitle, knownMaterial);
            }
        }

        private static void SummarizeKnownAnswerRows(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.ComponentsFilterOption filter,
            string[] lines,
            string modelTitle,
            string knownMaterial)
        {
            if (lines.Length == 0)
            {
                context.Evidence.AppendLine("BOM.CSV." + filter + ".KnownAnswerRows=0");
                context.Evidence.AppendLine("BOM.CSV." + filter + ".MaterialColumnPresent=NO");
                context.Evidence.AppendLine("BOM.CSV." + filter + ".KnownMaterialInMaterialColumn=NO");
                return;
            }

            char delimiter = DetectDelimiter(lines[0]);
            List<string> header = ParseDelimitedLine(lines[0], delimiter);
            List<int> materialColumns = new List<int>();
            for (int i = 0; i < header.Count; i++)
            {
                if (header[i].IndexOf("material", StringComparison.OrdinalIgnoreCase) >= 0)
                    materialColumns.Add(i);
            }

            context.Evidence.AppendLine("BOM.CSV." + filter + ".Delimiter=" + DelimiterLabel(delimiter));
            context.Evidence.AppendLine("BOM.CSV." + filter + ".MaterialColumnPresent=" + (materialColumns.Count > 0 ? "YES" : "NO"));
            context.Evidence.AppendLine("BOM.CSV." + filter + ".MaterialColumns=" +
                (materialColumns.Count == 0 ? "<none>" : string.Join(" | ", materialColumns.Select(index => index.ToString(CultureInfo.InvariantCulture) + ":" + header[index]))));

            int knownRows = 0;
            bool knownMaterialFound = false;
            for (int lineIndex = 1; lineIndex < lines.Length; lineIndex++)
            {
                List<string> row = ParseDelimitedLine(lines[lineIndex], delimiter);
                if (!row.Any(cell => string.Equals(cell.Trim(), modelTitle, StringComparison.OrdinalIgnoreCase) || cell.IndexOf(modelTitle, StringComparison.OrdinalIgnoreCase) >= 0))
                    continue;

                knownRows++;
                List<string> materialValues = new List<string>();
                foreach (int column in materialColumns)
                {
                    string value = column < row.Count ? row[column] : string.Empty;
                    materialValues.Add(header[column] + "=" + value);
                    if (string.Equals(value.Trim(), knownMaterial, StringComparison.OrdinalIgnoreCase) || value.IndexOf(knownMaterial, StringComparison.OrdinalIgnoreCase) >= 0)
                        knownMaterialFound = true;
                }

                context.Evidence.AppendLine("BOM.CSV." + filter + ".KnownAnswerRow[" + knownRows.ToString(CultureInfo.InvariantCulture) + "].Model=" + modelTitle + "; MaterialValues=" + (materialValues.Count == 0 ? "<no-material-column>" : string.Join(" | ", materialValues)));
            }

            context.Evidence.AppendLine("BOM.CSV." + filter + ".KnownAnswerRows=" + knownRows.ToString(CultureInfo.InvariantCulture));
            context.Evidence.AppendLine("BOM.CSV." + filter + ".KnownMaterialInMaterialColumn=" + (knownMaterialFound ? "YES" : "NO"));
        }

        private static AttributeObservation WriteAttributes(
            VerificationRuntimeContext context,
            string label,
            object entity,
            string knownAttributeName,
            string knownAttributeValue)
        {
            interop.CimBaseAPI.IAttributeSink sink = entity as interop.CimBaseAPI.IAttributeSink;
            if (sink == null)
            {
                context.Evidence.AppendLine(label + ".GetAttributes: ABSENT");
                return AttributeObservation.Absent;
            }

            try
            {
                object[] attributes = sink.GetAttributes();
                context.Evidence.AppendLine(label + ".GetAttributes: PRESENT count=" + (attributes == null ? 0 : attributes.Length));
                if (attributes != null)
                {
                    foreach (object raw in attributes)
                    {
                        interop.CimBaseAPI.IAttribute attribute = raw as interop.CimBaseAPI.IAttribute;
                        if (attribute == null)
                            continue;

                        string value = VerificationRuntimeContext.Format(attribute.Value);
                        context.Evidence.AppendLine(label + ".Attribute name=" + attribute.Name + "; type=" + attribute.Type + "; value=" + value);
                    }
                }

                interop.CimBaseAPI.IAttribute named = sink.GetAttribute(
                    interop.CimBaseAPI.AttributeEnumType.cmAttString,
                    knownAttributeName);
                if (named == null)
                {
                    context.Evidence.AppendLine(label + ".NamedAttributeLookup: ABSENT name=" + knownAttributeName + "; type=cmAttString");
                    return AttributeObservation.NotMatched;
                }

                string namedValue = Convert.ToString(named.Value, CultureInfo.InvariantCulture);
                context.Evidence.AppendLine(
                    label + ".NamedAttributeLookup: PRESENT requestedName=" + knownAttributeName +
                    "; returnedName=" + named.Name +
                    "; type=" + named.Type +
                    "; value=" + namedValue);

                bool matched =
                    string.Equals(named.Type.ToString(), "cmAttString", StringComparison.Ordinal) &&
                    string.Equals(namedValue, knownAttributeValue, StringComparison.Ordinal);
                return matched ? AttributeObservation.Matched : AttributeObservation.NotMatched;
            }
            catch (Exception ex)
            {
                Exception raw = VerificationRuntimeContext.Unwrap(ex);
                context.Evidence.AppendLine(label + ".GetAttributes: READ_ERROR type=" + raw.GetType().FullName + " HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) + " message=" + raw.Message);
                return AttributeObservation.ReadError;
            }
        }

        private static interop.CimMdlrAPI.ICimEntity FindBodyEntityOnOccurrence(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IAssInstance instance,
            int entityId)
        {
            interop.CimMdlrAPI.ICimEntityList entities = instance.GetAllEntities();
            if (entities == null)
                throw new InvalidOperationException("IAssInstance.GetAllEntities() returned null for " + instance.Model.Title + ".");

            context.Evidence.AppendLine("OccurrenceEntityList.Count: " + entities.Count.ToString(CultureInfo.InvariantCulture));
            interop.CimMdlrAPI.ICimEntity match = null;
            for (int index = 1; index <= entities.Count; index++)
            {
                interop.CimMdlrAPI.ICimEntity entity = entities[index] as interop.CimMdlrAPI.ICimEntity;
                if (entity == null || entity.ID != entityId)
                    continue;

                context.Evidence.AppendLine(
                    "OccurrenceEntityList.Match: index=" + index.ToString(CultureInfo.InvariantCulture) +
                    "; id=" + entity.ID.ToString(CultureInfo.InvariantCulture) +
                    "; type=" + entity.Type);

                if (!string.Equals(entity.Type.ToString(), "cmBody", StringComparison.Ordinal))
                    throw new InvalidOperationException(
                        "Known-answer entity " + entityId.ToString(CultureInfo.InvariantCulture) +
                        " resolved through IAssInstance.GetAllEntities() but is not a body; observed " + entity.Type + ".");
                if (match != null)
                    throw new InvalidOperationException(
                        "IAssInstance.GetAllEntities() returned more than one cmBody with entity ID " +
                        entityId.ToString(CultureInfo.InvariantCulture) + ".");

                match = entity;
            }

            if (match == null)
                throw new InvalidOperationException(
                    "Body entity " + entityId.ToString(CultureInfo.InvariantCulture) +
                    " was not found through IAssInstance.GetAllEntities() for model " + instance.Model.Title + ".");

            return match;
        }

        private static interop.CimMdlrAPI.IAssInstance FindInstance(interop.CimMdlrAPI.IAssemblyModel assembly, string title)
        {
            object[] raw = (object[])assembly.GetInstances();
            foreach (object item in raw)
            {
                interop.CimMdlrAPI.IAssInstance instance = item as interop.CimMdlrAPI.IAssInstance;
                if (instance == null)
                    continue;
                if (instance.Model != null && string.Equals(instance.Model.Title, title, StringComparison.OrdinalIgnoreCase))
                    return instance;
                if (instance.Model != null && string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    interop.CimMdlrAPI.IAssInstance nested = FindInstance((interop.CimMdlrAPI.IAssemblyModel)instance.Model, title);
                    if (nested != null)
                        return nested;
                }
            }
            return null;
        }

        private static char DetectDelimiter(string header)
        {
            char[] candidates = { ',', ';', '\t' };
            return candidates.OrderByDescending(delimiter => ParseDelimitedLine(header, delimiter).Count).First();
        }

        private static string DelimiterLabel(char delimiter)
        {
            if (delimiter == '\t') return "TAB";
            if (delimiter == ';') return "SEMICOLON";
            return "COMMA";
        }

        private static List<string> ParseDelimitedLine(string line, char delimiter)
        {
            List<string> fields = new List<string>();
            StringBuilder field = new StringBuilder();
            bool quoted = false;
            for (int i = 0; i < line.Length; i++)
            {
                char current = line[i];
                if (current == '"')
                {
                    if (quoted && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        field.Append('"');
                        i++;
                    }
                    else
                    {
                        quoted = !quoted;
                    }
                }
                else if (current == delimiter && !quoted)
                {
                    fields.Add(field.ToString());
                    field.Clear();
                }
                else
                {
                    field.Append(current);
                }
            }
            fields.Add(field.ToString());
            return fields;
        }

        internal static string CreateTempFolder()
        {
            string folder = Path.Combine(Path.GetTempPath(), "CimatronCustomization", "Step07", DateTimeOffset.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture));
            Directory.CreateDirectory(folder);
            return folder;
        }

        private enum AttributeObservation
        {
            Absent,
            Matched,
            NotMatched,
            ReadError
        }

        private sealed class FolderSnapshot
        {
            private readonly string folder;
            private readonly string[] entries;

            private FolderSnapshot(string folder, string[] entries)
            {
                this.folder = folder;
                this.entries = entries;
            }

            internal static FolderSnapshot Capture(string modelPath)
            {
                if (string.IsNullOrWhiteSpace(modelPath))
                    return new FolderSnapshot(string.Empty, Array.Empty<string>());

                string directory = Directory.Exists(modelPath) ? modelPath : Path.GetDirectoryName(modelPath);
                if (string.IsNullOrWhiteSpace(directory) || !Directory.Exists(directory))
                    return new FolderSnapshot(directory ?? string.Empty, Array.Empty<string>());

                string[] snapshot = Directory.GetFiles(directory)
                    .Select(path =>
                    {
                        FileInfo info = new FileInfo(path);
                        return info.Name + "|" + info.Length.ToString(CultureInfo.InvariantCulture) + "|" + info.LastWriteTimeUtc.ToString("O", CultureInfo.InvariantCulture);
                    })
                    .OrderBy(value => value, StringComparer.OrdinalIgnoreCase)
                    .ToArray();
                return new FolderSnapshot(directory, snapshot);
            }

            internal bool IsEquivalentTo(FolderSnapshot other)
            {
                return other != null &&
                    string.Equals(folder, other.folder, StringComparison.OrdinalIgnoreCase) &&
                    entries.SequenceEqual(other.entries, StringComparer.OrdinalIgnoreCase);
            }

            public override string ToString()
            {
                return "Folder=" + folder + "; Entries=[" + string.Join(",", entries) + "]";
            }
        }
    }
}
