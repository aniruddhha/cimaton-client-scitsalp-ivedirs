using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class HiddenStateCandidateVerification
    {
        internal static int Run(VerificationArguments args)
        {
            using (VerificationRuntimeContext context = VerificationRuntimeContext.Attach(args.ExpectedContext, "07C-4 HIDDEN STATE CANDIDATES"))
            {
                NoMutationEvidence before = NoMutationEvidence.Capture(context.Document);
                try
                {
                    context.Evidence.AppendLine("U16.ICimEntity.Show.Access: GETTER_ONLY; retained 07A reflection evidence records Int32 Show getter/setter; this verifier reads only the getter");
                    context.Evidence.AppendLine("U16.SemanticsPreassigned: FALSE");
                    context.Evidence.AppendLine("U16.KnownAnswerControls: visible occurrence/body; hidden-not-suppressed occurrence; visible occurrence with hidden body; suppressed occurrence");

                    interop.CimMdlrAPI.IAssemblyModel assembly = (interop.CimMdlrAPI.IAssemblyModel)context.Model;
                    object[] raw = (object[])assembly.GetInstances();
                    foreach (object item in raw)
                        RecordInstance(context, assembly, item as interop.CimMdlrAPI.IAssInstance, 0);

                    string folder = ComponentPropertySourceVerification.CreateTempFolder();
                    context.Evidence.AppendLine("BOM.TempFolder: " + folder);
                    interop.CimMdlrAPI.IBOM bom;
                    if (context.TryObserve("GetBomManager", () => assembly.GetBomManager(), out bom) && bom != null)
                    {
                        string allStem = Path.Combine(folder, "hidden-all");
                        string visibleStem = Path.Combine(folder, "hidden-visible");
                        ComponentPropertySourceVerification.ExportAndSummarize(context, bom, allStem, interop.CimMdlrAPI.ComponentsFilterOption.cmNoFiltering);
                        ComponentPropertySourceVerification.ExportAndSummarize(context, bom, visibleStem, interop.CimMdlrAPI.ComponentsFilterOption.cmVisibleOnly);

                        List<string> allRows = RecordBomMembership(context, allStem, interop.CimMdlrAPI.ComponentsFilterOption.cmNoFiltering);
                        List<string> visibleRows = RecordBomMembership(context, visibleStem, interop.CimMdlrAPI.ComponentsFilterOption.cmVisibleOnly);
                        RecordBomDifference(context, allRows, visibleRows);
                    }
                    else
                    {
                        context.Evidence.AppendLine("BOM.Stage: SKIPPED_AFTER_READ_ERROR; hidden-state body/occurrence observations remain valid; BOM route remains unresolved for this run");
                        context.Evidence.AppendLine("BOMMembership.SemanticsAssignedInCode=FALSE");
                    }

                    context.Evidence.AppendLine("SemanticsAssignedInCode: FALSE");
                    context.Evidence.AppendLine("StoppingRule: SINGLE RUN; classify Show separately for occurrence-hidden versus body-hidden controls and classify whether cmVisibleOnly BOM membership distinguishes the hidden occurrence. If neither route discriminates the known hidden occurrence, FR-021 remains BLOCKED — pending Cimatron guidance.");
                }
                finally
                {
                    NoMutationEvidence after = NoMutationEvidence.Capture(context.Document);
                    bool unchanged = before.IsEquivalentTo(after);
                    context.Evidence.AppendLine("NoMutationBefore: " + before);
                    context.Evidence.AppendLine("NoMutationAfter: " + after);
                    context.Evidence.AppendLine("No-mutation evidence: " + (unchanged ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
                    string path = VerificationEvidenceWriter.Write("api-capability-hidden-state-candidates", context.Evidence.ToString());
                    Console.WriteLine("Evidence file: " + path);
                    if (!unchanged)
                        Environment.ExitCode = 8;
                }

                return Environment.ExitCode == 8 ? 8 : 0;
            }
        }

        private static void RecordInstance(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IAssemblyModel parentAssembly,
            interop.CimMdlrAPI.IAssInstance instance,
            int depth)
        {
            if (instance == null || depth > 16)
                return;

            string title = instance.Model == null ? "<null>" : instance.Model.Title;
            context.Evidence.AppendLine(
                "Occurrence depth=" + depth.ToString(CultureInfo.InvariantCulture) +
                "; id=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                "; title=" + title +
                "; suppressed=" + instance.IsSuppressed);

            if (instance.Model != null && string.Equals(instance.Model.Type.ToString(), "cmPart", StringComparison.Ordinal))
            {
                RecordOccurrenceBodies(context, parentAssembly, instance, depth, title);
            }
            else if (instance.Model != null && string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
            {
                object[] nested = (object[])((interop.CimMdlrAPI.IAssemblyModel)instance.Model).GetInstances();
                foreach (object item in nested)
                    RecordInstance(context, (interop.CimMdlrAPI.IAssemblyModel)instance.Model, item as interop.CimMdlrAPI.IAssInstance, depth + 1);
            }
        }

        private static void RecordOccurrenceBodies(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IAssemblyModel parentAssembly,
            interop.CimMdlrAPI.IAssInstance instance,
            int depth,
            string title)
        {
            interop.CimMdlrAPI.ICimEntityList entities = instance.GetAllEntities();
            if (entities == null)
            {
                context.Evidence.AppendLine("HiddenCandidate occurrence=" + instance.ID.ToString(CultureInfo.InvariantCulture) + "; title=" + title + "; GetAllEntities=NULL");
                return;
            }

            int bodyCount = 0;
            for (int i = 1; i <= entities.Count; i++)
            {
                interop.CimMdlrAPI.ICimEntity partBody = entities[i] as interop.CimMdlrAPI.ICimEntity;
                if (partBody == null || !string.Equals(partBody.Type.ToString(), "cmBody", StringComparison.Ordinal))
                    continue;

                bodyCount++;
                try
                {
                    interop.CimMdlrAPI.ICimEntity assemblyBody = parentAssembly.GetAssemblyEntity(partBody, (interop.CimMdlrAPI.AssInstance)instance);
                    interop.CimBaseAPI.ICimEntity visibleEntity = assemblyBody as interop.CimBaseAPI.ICimEntity;
                    int showValue = visibleEntity == null
                        ? int.MinValue
                        : Convert.ToInt32(visibleEntity.Show, CultureInfo.InvariantCulture);
                    context.Evidence.AppendLine(
                        "HiddenCandidate depth=" + depth.ToString(CultureInfo.InvariantCulture) +
                        "; occurrence=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                        "; title=" + title +
                        "; partBody=" + partBody.ID.ToString(CultureInfo.InvariantCulture) +
                        "; assemblyBody=" + assemblyBody.ID.ToString(CultureInfo.InvariantCulture) +
                        "; Show.GET=" + showValue.ToString(CultureInfo.InvariantCulture));
                }
                catch (Exception ex)
                {
                    Exception rawEx = VerificationRuntimeContext.Unwrap(ex);
                    context.Evidence.AppendLine(
                        "HiddenCandidate depth=" + depth.ToString(CultureInfo.InvariantCulture) +
                        "; occurrence=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                        "; title=" + title +
                        "; partBody=" + partBody.ID.ToString(CultureInfo.InvariantCulture) +
                        "; Show.GET READ_ERROR type=" + rawEx.GetType().FullName +
                        " HRESULT=0x" + rawEx.HResult.ToString("X8", CultureInfo.InvariantCulture) +
                        " message=" + rawEx.Message);
                }
            }

            context.Evidence.AppendLine(
                "HiddenCandidateSummary depth=" + depth.ToString(CultureInfo.InvariantCulture) +
                "; occurrence=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                "; title=" + title +
                "; suppressed=" + instance.IsSuppressed +
                "; bodyCountFromGetAllEntities=" + bodyCount.ToString(CultureInfo.InvariantCulture));
        }

        private static List<string> RecordBomMembership(
            VerificationRuntimeContext context,
            string stem,
            interop.CimMdlrAPI.ComponentsFilterOption filter)
        {
            string folder = Path.GetDirectoryName(stem);
            string prefix = Path.GetFileName(stem);
            string[] csvFiles = Directory.GetFiles(folder, prefix + "*.csv");
            List<string> rows = new List<string>();

            foreach (string file in csvFiles.OrderBy(path => path, StringComparer.OrdinalIgnoreCase))
            {
                string[] lines = File.ReadAllLines(file);
                context.Evidence.AppendLine("BOMMembership." + filter + ".File=" + Path.GetFileName(file));
                for (int i = 1; i < lines.Length; i++)
                {
                    string row = lines[i].Trim();
                    if (row.Length == 0)
                        continue;

                    string normalized = NormalizeBomRowForComparison(row);
                    rows.Add(normalized);
                    context.Evidence.AppendLine(
                        "BOMMembership." + filter + ".Row[" + rows.Count.ToString(CultureInfo.InvariantCulture) + "].Raw=" + row);
                    context.Evidence.AppendLine(
                        "BOMMembership." + filter + ".Row[" + rows.Count.ToString(CultureInfo.InvariantCulture) + "].Comparable=" + normalized);
                }
            }

            context.Evidence.AppendLine("BOMMembership." + filter + ".Rows=" + rows.Count.ToString(CultureInfo.InvariantCulture));
            return rows;
        }

        private static string NormalizeBomRowForComparison(string row)
        {
            bool quoted = false;
            for (int i = 0; i < row.Length; i++)
            {
                char current = row[i];
                if (current == '"')
                {
                    if (quoted && i + 1 < row.Length && row[i + 1] == '"')
                    {
                        i++;
                        continue;
                    }

                    quoted = !quoted;
                    continue;
                }

                if (current == ',' && !quoted)
                    return row.Substring(i + 1).Trim();
            }

            return row;
        }

        private static void RecordBomDifference(
            VerificationRuntimeContext context,
            List<string> allRows,
            List<string> visibleRows)
        {
            List<string> remainingVisible = new List<string>(visibleRows);
            List<string> onlyInAll = new List<string>();
            foreach (string row in allRows)
            {
                int match = remainingVisible.FindIndex(candidate => string.Equals(candidate, row, StringComparison.Ordinal));
                if (match >= 0)
                    remainingVisible.RemoveAt(match);
                else
                    onlyInAll.Add(row);
            }

            context.Evidence.AppendLine("BOMMembership.Difference.OnlyInNoFiltering.Count=" + onlyInAll.Count.ToString(CultureInfo.InvariantCulture));
            for (int i = 0; i < onlyInAll.Count; i++)
            {
                context.Evidence.AppendLine(
                    "BOMMembership.Difference.OnlyInNoFiltering[" + (i + 1).ToString(CultureInfo.InvariantCulture) + "]=" + onlyInAll[i]);
            }

            context.Evidence.AppendLine("BOMMembership.Difference.OnlyInVisibleOnly.Count=" + remainingVisible.Count.ToString(CultureInfo.InvariantCulture));
            for (int i = 0; i < remainingVisible.Count; i++)
            {
                context.Evidence.AppendLine(
                    "BOMMembership.Difference.OnlyInVisibleOnly[" + (i + 1).ToString(CultureInfo.InvariantCulture) + "]=" + remainingVisible[i]);
            }

            context.Evidence.AppendLine("BOMMembership.SemanticsAssignedInCode=FALSE");
        }
    }
}
