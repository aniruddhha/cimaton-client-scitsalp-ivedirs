using System;
using System.IO;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal sealed class NoMutationEvidence
    {
        private NoMutationEvidence(string path, bool modified, DateTime? lastWriteUtc, long? length)
        { Path = path; Modified = modified; LastWriteUtc = lastWriteUtc; Length = length; }
        internal string Path { get; }
        internal bool Modified { get; }
        internal DateTime? LastWriteUtc { get; }
        internal long? Length { get; }

        internal static NoMutationEvidence Capture(interop.CimatronE.ICimDocument document)
        {
            bool modified = document.IsModified();
            string path = document.GetPath() ?? string.Empty;
            DateTime? lastWriteUtc = null; long? length = null;
            if (!string.IsNullOrWhiteSpace(path) && File.Exists(path)) { FileInfo info = new FileInfo(path); lastWriteUtc = info.LastWriteTimeUtc; length = info.Length; }
            return new NoMutationEvidence(path, modified, lastWriteUtc, length);
        }

        internal bool IsEquivalentTo(NoMutationEvidence other)
        {
            return other != null && !string.IsNullOrWhiteSpace(Path) && LastWriteUtc.HasValue && Length.HasValue && other.LastWriteUtc.HasValue && other.Length.HasValue &&
                string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) && Modified == other.Modified && LastWriteUtc == other.LastWriteUtc && Length == other.Length;
        }

        public override string ToString() => "Path=" + Path + "; Modified=" + Modified + "; LastWriteUtc=" + (LastWriteUtc.HasValue ? LastWriteUtc.Value.ToString("O") : "N/A") + "; Length=" + (Length.HasValue ? Length.Value.ToString() : "N/A");
    }
}
