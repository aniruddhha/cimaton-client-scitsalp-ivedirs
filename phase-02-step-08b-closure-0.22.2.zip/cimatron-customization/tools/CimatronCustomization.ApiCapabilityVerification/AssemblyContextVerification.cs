using System;
using System.Collections.Generic;
using System.Globalization;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class AssemblyContextVerification
    {
        private sealed class InstanceObservation
        {
            internal InstanceObservation(interop.CimMdlrAPI.IAssInstance instance, int depth)
            {
                Instance = instance;
                Depth = depth;
            }

            internal interop.CimMdlrAPI.IAssInstance Instance { get; }
            internal int Depth { get; }
        }

        private sealed class AssemblyEntityObservation
        {
            internal AssemblyEntityObservation(InstanceObservation occurrence, interop.CimMdlrAPI.ICimEntity entity)
            {
                Occurrence = occurrence;
                Entity = entity;
            }

            internal InstanceObservation Occurrence { get; }
            internal interop.CimMdlrAPI.ICimEntity Entity { get; }
        }

        internal static int Run(VerificationArguments args)
        {
            if (string.IsNullOrWhiteSpace(args.ModelTitle) || !args.EntityId.HasValue)
                throw new ArgumentException("Assembly-context mode requires --model-title and --entity-id.");

            using (VerificationRuntimeContext context = VerificationRuntimeContext.Attach(args.ExpectedContext, "07C-2 ASSEMBLY CONTEXT"))
            {
                NoMutationEvidence before = NoMutationEvidence.Capture(context.Document);
                object previousSelection = null;
                bool selectionCaptured = false;

                try
                {
                    interop.CimMdlrAPI.IAssemblyModel assembly = (interop.CimMdlrAPI.IAssemblyModel)context.Model;
                    List<InstanceObservation> instances = new List<InstanceObservation>();
                    Traverse(assembly, instances, context, 0);

                    List<InstanceObservation> matching = instances.FindAll(
                        item => item.Instance.Model != null &&
                            string.Equals(item.Instance.Model.Title, args.ModelTitle, StringComparison.OrdinalIgnoreCase));
                    context.Evidence.AppendLine("TargetModelInstances.TraversalCount: " + matching.Count.ToString(CultureInfo.InvariantCulture));
                    if (matching.Count == 0)
                        throw new InvalidOperationException("No instance matches model title " + args.ModelTitle + ".");

                    interop.CimMdlrAPI.IModel partModel = (interop.CimMdlrAPI.IModel)matching[0].Instance.Model;
                    object byModel = context.Observe("GetInstancesByModel", () => assembly.GetInstancesByModel(partModel));
                    context.Evidence.AppendLine("GetInstancesByModel.Raw: " + VerificationRuntimeContext.Format(byModel));

                    interop.CimMdlrAPI.ICimEntity partEntity = partModel.GetEntityById(args.EntityId.Value, partModel);
                    if (partEntity == null)
                        throw new InvalidOperationException("--entity-id " + args.EntityId.Value.ToString(CultureInfo.InvariantCulture) + " did not resolve in model " + args.ModelTitle + ".");
                    context.Evidence.AppendLine("TargetPartEntity: id=" + partEntity.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + partEntity.Type);

                    List<AssemblyEntityObservation> assemblyEntities = new List<AssemblyEntityObservation>();
                    for (int i = 0; i < matching.Count; i++)
                    {
                        InstanceObservation occurrence = matching[i];
                        interop.CimMdlrAPI.IAssInstance instance = occurrence.Instance;
                        RecordTransformation(context, instance, occurrence.Depth);

                        interop.CimMdlrAPI.AssInstance concrete = (interop.CimMdlrAPI.AssInstance)instance;
                        interop.CimMdlrAPI.ICimEntity assemblyEntity = context.Observe(
                            "GetAssemblyEntity.Match" + (i + 1).ToString(CultureInfo.InvariantCulture),
                            () => assembly.GetAssemblyEntity(partEntity, concrete));
                        assemblyEntities.Add(new AssemblyEntityObservation(occurrence, assemblyEntity));
                        context.Evidence.AppendLine(
                            "AssemblyEntity match=" + (i + 1).ToString(CultureInfo.InvariantCulture) +
                            "; depth=" + occurrence.Depth.ToString(CultureInfo.InvariantCulture) +
                            "; instance=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                            "; id=" + assemblyEntity.ID.ToString(CultureInfo.InvariantCulture) +
                            "; type=" + assemblyEntity.Type);

                        int reverseInstanceId;
                        if (context.TryObserve(
                            "InstanceByAssemblyEnt.Match" + (i + 1).ToString(CultureInfo.InvariantCulture),
                            () => assembly.InstanceByAssemblyEnt[assemblyEntity].ID,
                            out reverseInstanceId))
                        {
                            context.Evidence.AppendLine(
                                "InstanceByAssemblyEnt.Comparison match=" + (i + 1).ToString(CultureInfo.InvariantCulture) +
                                "; originInstanceId=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                                "; reverseInstanceId=" + reverseInstanceId.ToString(CultureInfo.InvariantCulture) +
                                "; result=" + (reverseInstanceId == instance.ID ? "MATCH" : "MISMATCH"));
                        }

                        int lockValue;
                        context.TryObserve(
                            "IAssInstance.Lock.Match" + (i + 1).ToString(CultureInfo.InvariantCulture),
                            () => instance.Lock,
                            out lockValue);
                    }

                    interop.CimServicesAPI.IUcs ucs = ResolveUcs(context, assembly, args.UcsId);
                    interop.CimServicesAPI.IGeomServices geometry = (interop.CimServicesAPI.IGeomServices)assembly.GetGeomServicesObj();
                    if (ucs != null)
                    {
                        context.TryObserve(
                            "GetAssemblyBoundingBox",
                            () => (double[])geometry.GetAssemblyBoundingBox((interop.CimServicesAPI.IModel)context.Model, ucs),
                            out double[] _);
                    }
                    else
                    {
                        context.Evidence.AppendLine("GetAssemblyBoundingBox: NOT_TESTED reason=no assembly UCS resolved");
                    }

                    RecordCrossComponentDistances(context, geometry, assemblyEntities);

                    if (args.Highlight && assemblyEntities.Count > 0)
                    {
                        interop.CimMdlrAPI.ISelection selection = (interop.CimMdlrAPI.ISelection)context.Document;
                        previousSelection = selection.Selection;
                        selectionCaptured = true;
                        HighlightForUser(context, selection, assemblyEntities);
                    }
                }
                finally
                {
                    if (args.Highlight && selectionCaptured)
                        RestoreSelection(context, previousSelection);

                    NoMutationEvidence after = NoMutationEvidence.Capture(context.Document);
                    bool unchanged = before.IsEquivalentTo(after);
                    context.Evidence.AppendLine("NoMutationBefore: " + before);
                    context.Evidence.AppendLine("NoMutationAfter: " + after);
                    context.Evidence.AppendLine("No-mutation evidence: " + (unchanged ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
                    string path = VerificationEvidenceWriter.Write("api-capability-assembly-context", context.Evidence.ToString());
                    Console.WriteLine("Evidence file: " + path);
                    if (!unchanged) Environment.ExitCode = 8;
                }

                return Environment.ExitCode == 8 ? 8 : 0;
            }
        }

        private static void Traverse(
            interop.CimMdlrAPI.IAssemblyModel assembly,
            ICollection<InstanceObservation> output,
            VerificationRuntimeContext context,
            int depth)
        {
            if (depth > 16) throw new InvalidOperationException("Assembly traversal depth exceeded 16.");
            object[] raw = (object[])assembly.GetInstances();
            foreach (object item in raw)
            {
                interop.CimMdlrAPI.IAssInstance instance = item as interop.CimMdlrAPI.IAssInstance;
                if (instance == null) continue;

                output.Add(new InstanceObservation(instance, depth));
                string modelTitle = instance.Model == null ? "<null>" : instance.Model.Title;
                context.Evidence.AppendLine(
                    "Instance depth=" + depth.ToString(CultureInfo.InvariantCulture) +
                    "; id=" + instance.ID.ToString(CultureInfo.InvariantCulture) +
                    "; model=" + modelTitle);

                int suppressed;
                context.TryObserve(
                    "IAssInstance.IsSuppressed.Depth" + depth.ToString(CultureInfo.InvariantCulture) + ".Instance" + instance.ID.ToString(CultureInfo.InvariantCulture),
                    () => instance.IsSuppressed,
                    out suppressed);
                int lockValue;
                context.TryObserve(
                    "IAssInstance.Lock.Depth" + depth.ToString(CultureInfo.InvariantCulture) + ".Instance" + instance.ID.ToString(CultureInfo.InvariantCulture),
                    () => instance.Lock,
                    out lockValue);

                object sub = null;
                context.TryObserve<object>(
                    "SubInstances.Depth" + depth.ToString(CultureInfo.InvariantCulture) + ".Instance" + instance.ID.ToString(CultureInfo.InvariantCulture),
                    () => (object)instance.get_SubInstances(1, 0),
                    out sub);
                object[] subItems = sub as object[];
                if (subItems != null && subItems.Length > 0 && instance.Model != null && string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    Traverse((interop.CimMdlrAPI.IAssemblyModel)instance.Model, output, context, depth + 1);
            }
        }

        private static void RecordTransformation(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IAssInstance instance,
            int depth)
        {
            RecordTransformation(context, instance, depth, 0, "Local");
            RecordTransformation(context, instance, depth, 1, "Root");
        }

        private static void RecordTransformation(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IAssInstance instance,
            int depth,
            int rootParent,
            string label)
        {
            interop.CimMdlrAPI.ModelTransformation transformation;
            if (!context.TryObserve(
                "IAssInstance.Transformation." + label + ".Depth" + depth.ToString(CultureInfo.InvariantCulture) + ".Instance" + instance.ID.ToString(CultureInfo.InvariantCulture),
                () => instance.Transformation[rootParent],
                out transformation) || transformation == null)
                return;

            interop.CimMdlrAPI.IModelTransformation modelTransformation = (interop.CimMdlrAPI.IModelTransformation)transformation;
            context.TryObserve<object>(
                "IModelTransformation.Matrix." + label + ".Instance" + instance.ID.ToString(CultureInfo.InvariantCulture),
                () => modelTransformation.Matrix,
                out object _);
            context.TryObserve<object>(
                "IModelTransformation.Vector." + label + ".Instance" + instance.ID.ToString(CultureInfo.InvariantCulture),
                () => modelTransformation.Vector,
                out object _);
        }

        private static interop.CimServicesAPI.IUcs ResolveUcs(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.IAssemblyModel assembly,
            int? ucsId)
        {
            object source = null;
            if (ucsId.HasValue)
            {
                try
                {
                    source = context.GetEntity(ucsId.Value);
                    interop.CimMdlrAPI.ICimEntity entity = source as interop.CimMdlrAPI.ICimEntity;
                    context.Evidence.AppendLine(
                        "AssemblyUcs.Source: --ucs-id " + ucsId.Value.ToString(CultureInfo.InvariantCulture) +
                        (entity == null ? string.Empty : "; type=" + entity.Type));
                }
                catch (Exception ex)
                {
                    WriteError(context, "AssemblyUcs.ById", ex);
                    return null;
                }
            }
            else
            {
                context.TryObserve("IAssemblyModel.ActivateUcs.GET", () => assembly.ActivateUcs, out source);
                context.Evidence.AppendLine("AssemblyUcs.Source: active UCS (--ucs-id not supplied)");
            }

            interop.CimServicesAPI.IUcs ucs = source as interop.CimServicesAPI.IUcs;
            context.Evidence.AppendLine("AssemblyUcs.Resolve: " + (ucs == null ? "BLOCKED" : "RESOLVED"));
            return ucs;
        }

        private static void RecordCrossComponentDistances(
            VerificationRuntimeContext context,
            interop.CimServicesAPI.IGeomServices geometry,
            IList<AssemblyEntityObservation> entities)
        {
            if (entities.Count < 2)
            {
                context.Evidence.AppendLine("CrossComponent.MinDistancePos: NOT_TESTED reason=fewer than two matching assembly entities");
                return;
            }

            for (int i = 0; i < entities.Count - 1; i++)
            {
                for (int j = i + 1; j < entities.Count; j++)
                {
                    AssemblyEntityObservation first = entities[i];
                    AssemblyEntityObservation second = entities[j];
                    string label =
                        "CrossComponent.MinDistancePos pair=" + (i + 1).ToString(CultureInfo.InvariantCulture) + "-" + (j + 1).ToString(CultureInfo.InvariantCulture) +
                        "; instanceA=" + first.Occurrence.Instance.ID.ToString(CultureInfo.InvariantCulture) +
                        "; depthA=" + first.Occurrence.Depth.ToString(CultureInfo.InvariantCulture) +
                        "; instanceB=" + second.Occurrence.Instance.ID.ToString(CultureInfo.InvariantCulture) +
                        "; depthB=" + second.Occurrence.Depth.ToString(CultureInfo.InvariantCulture);
                    try
                    {
                        interop.CimServicesAPI.IPointData pointA;
                        interop.CimServicesAPI.IPointData pointB;
                        double distance = geometry.MinDistancePos(
                            (interop.CimServicesAPI.ICimEntity)first.Entity,
                            (interop.CimServicesAPI.ICimEntity)second.Entity,
                            out pointA,
                            out pointB);
                        context.Evidence.AppendLine(
                            label +
                            "; PRESENT distance=" + distance.ToString("R", CultureInfo.InvariantCulture) +
                            "; pointA=" + FormatPoint(pointA) +
                            "; pointB=" + FormatPoint(pointB));
                    }
                    catch (Exception ex)
                    {
                        WriteError(context, label, ex);
                    }
                }
            }
        }

        private static void HighlightForUser(
            VerificationRuntimeContext context,
            interop.CimMdlrAPI.ISelection selection,
            IList<AssemblyEntityObservation> entities)
        {
            for (int i = 0; i < entities.Count; i++)
            {
                AssemblyEntityObservation item = entities[i];
                interop.CimMdlrAPI.ICimEntityList highlightList = (interop.CimMdlrAPI.ICimEntityList)new interop.CimBaseAPI.CimEntityList();
                highlightList.Add(item.Entity);
                selection.Selection = highlightList;
                context.Evidence.AppendLine(
                    "Highlight.Match" + (i + 1).ToString(CultureInfo.InvariantCulture) +
                    ": PENDING USER CONFIRMATION; instance=" + item.Occurrence.Instance.ID.ToString(CultureInfo.InvariantCulture) +
                    "; depth=" + item.Occurrence.Depth.ToString(CultureInfo.InvariantCulture) +
                    "; assemblyEntityId=" + item.Entity.ID.ToString(CultureInfo.InvariantCulture));
                Console.WriteLine(
                    "Observe highlighted match " + (i + 1).ToString(CultureInfo.InvariantCulture) + "/" + entities.Count.ToString(CultureInfo.InvariantCulture) +
                    " (instance " + item.Occurrence.Instance.ID.ToString(CultureInfo.InvariantCulture) +
                    ", depth " + item.Occurrence.Depth.ToString(CultureInfo.InvariantCulture) + "). Press Enter after observing it.");
                Console.ReadLine();
                context.Evidence.AppendLine("Highlight.Match" + (i + 1).ToString(CultureInfo.InvariantCulture) + ": OBSERVATION_PAUSE_COMPLETED");
            }
        }

        private static void RestoreSelection(
            VerificationRuntimeContext context,
            object previousSelection)
        {
            try
            {
                interop.CimMdlrAPI.ISelection selection = context.Document as interop.CimMdlrAPI.ISelection;
                if (selection == null)
                {
                    context.Evidence.AppendLine("SelectionRestore: BLOCKED reason=document no longer exposes ISelection");
                    return;
                }

                interop.CimMdlrAPI.ICimEntityList restore = previousSelection as interop.CimMdlrAPI.ICimEntityList;
                if (restore == null)
                    restore = (interop.CimMdlrAPI.ICimEntityList)new interop.CimBaseAPI.CimEntityList();
                selection.Selection = restore;
                context.Evidence.AppendLine("SelectionRestore: COMPLETED previousSelection=" + (previousSelection == null ? "EMPTY" : "CAPTURED"));
            }
            catch (Exception ex)
            {
                WriteError(context, "SelectionRestore", ex);
            }
        }

        private static string FormatPoint(interop.CimServicesAPI.IPointData point)
        {
            interop.CimServicesAPI.IGeom3DPoint p = point as interop.CimServicesAPI.IGeom3DPoint;
            return p == null
                ? VerificationRuntimeContext.Format(point)
                : p.X.ToString("R", CultureInfo.InvariantCulture) + "," +
                    p.Y.ToString("R", CultureInfo.InvariantCulture) + "," +
                    p.Z.ToString("R", CultureInfo.InvariantCulture);
        }

        private static void WriteError(VerificationRuntimeContext context, string label, Exception ex)
        {
            Exception raw = VerificationRuntimeContext.Unwrap(ex);
            context.Evidence.AppendLine(
                label + ": READ_ERROR type=" + raw.GetType().FullName +
                " HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) +
                " message=" + raw.Message);
        }
    }
}
