using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class CapabilityApiReflectionInventory
    {
        private static readonly string[] TargetInterfaces = { "IGeomServices", "IAssemblyModel", "IMdlrModel", "IAssInstance", "ICimEntity", "IModel", "IBOM", "IUcs", "IPointData", "ICimEntityList", "IAttributeSink", "IAttribute", "ISelection" };
        private static readonly string[] TargetEnums = { "BOMTemplateType", "BOMExportOptions", "BOMReportFormat", "ComponentsFilterOption", "EdgeConvexityType", "EPointType", "EntityEnumType" };

        internal static int Run()
        {
            string program = AppDomain.CurrentDomain.BaseDirectory;
            StringBuilder output = new StringBuilder();
            output.AppendLine("CIMATRON STEP 07A INSTALLED-INTEROP CAPABILITY INVENTORY");
            output.AppendLine("ToolVersion: 0.20.5"); output.AppendLine("Timestamp: " + DateTimeOffset.Now.ToString("O")); output.AppendLine("InteropDirectory: " + program);
            List<Assembly> assemblies = new List<Assembly>();
            foreach (string path in Directory.GetFiles(program, "interop.*.dll").OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
            {
                try { assemblies.Add(Assembly.ReflectionOnlyLoadFrom(path)); output.AppendLine("ASSEMBLY PRESENT: " + Path.GetFileName(path)); }
                catch (Exception ex) { output.AppendLine("ASSEMBLY READ_ERROR: " + Path.GetFileName(path) + " | " + ex.GetType().FullName + " | " + ex.Message); }
            }
            foreach (string target in TargetInterfaces) WriteTarget(output, assemblies, target, false);
            foreach (string target in TargetEnums) WriteTarget(output, assemblies, target, true);
            output.AppendLine("RuntimeCalls: NONE (reflection-only installed-Interop inventory)");
            string evidence = VerificationEvidenceWriter.Write("api-capability-reflection", output.ToString());
            Console.WriteLine("STEP 07A REFLECTION INVENTORY: COMPLETE"); Console.WriteLine("Evidence file: " + evidence); return 0;
        }

        private static void WriteTarget(StringBuilder output, IEnumerable<Assembly> assemblies, string simpleName, bool enumTarget)
        {
            List<Type> matches = new List<Type>();
            foreach (Assembly assembly in assemblies)
            {
                try { matches.AddRange(assembly.GetTypes().Where(t => string.Equals(t.Name, simpleName, StringComparison.Ordinal) && (!enumTarget || t.IsEnum))); }
                catch (ReflectionTypeLoadException ex) { matches.AddRange(ex.Types.Where(t => t != null && string.Equals(t.Name, simpleName, StringComparison.Ordinal) && (!enumTarget || t.IsEnum))); }
            }
            output.AppendLine(); output.AppendLine("TARGET: " + simpleName);
            if (matches.Count == 0) { output.AppendLine("NOT_FOUND"); return; }
            foreach (Type type in matches.OrderBy(t => t.Assembly.GetName().Name).ThenBy(t => t.FullName))
            {
                output.AppendLine("FOUND assembly=" + type.Assembly.GetName().Name + "; fullName=" + type.FullName + "; guid=" + type.GUID);
                output.AppendLine("BASE_INTERFACES: " + string.Join(", ", type.GetInterfaces().Select(t => t.FullName).OrderBy(v => v)));
                if (type.IsEnum)
                {
                    foreach (FieldInfo field in type.GetFields(BindingFlags.Public | BindingFlags.Static).OrderBy(f => f.Name))
                    {
                        object rawValue = field.GetRawConstantValue();
                        output.AppendLine("ENUM " + field.Name + "=" + Convert.ToString(rawValue, CultureInfo.InvariantCulture));
                    }
                    continue;
                }
                foreach (PropertyInfo property in type.GetProperties().OrderBy(p => p.Name))
                {
                    if (property.GetGetMethod() != null) output.AppendLine("PROPERTY_GET " + FormatType(property.PropertyType) + " " + property.Name + FormatIndex(property));
                    if (property.GetSetMethod() != null) output.AppendLine("PROPERTY_SET " + FormatType(property.PropertyType) + " " + property.Name + FormatIndex(property));
                }
                foreach (MethodInfo method in type.GetMethods().Where(m => !m.IsSpecialName).OrderBy(m => m.Name).ThenBy(m => m.GetParameters().Length)) output.AppendLine("METHOD " + FormatMethod(method));
            }
        }
        private static string FormatMethod(MethodInfo method) => FormatType(method.ReturnType) + " " + method.Name + "(" + string.Join(", ", method.GetParameters().Select(FormatParameter)) + ")";
        private static string FormatParameter(ParameterInfo p) => (p.IsOut ? "out " : p.ParameterType.IsByRef ? "ref " : string.Empty) + FormatType(p.ParameterType.IsByRef ? p.ParameterType.GetElementType() : p.ParameterType) + " " + p.Name;
        private static string FormatIndex(PropertyInfo p) => p.GetIndexParameters().Length == 0 ? string.Empty : "[" + string.Join(", ", p.GetIndexParameters().Select(FormatParameter)) + "]";
        private static string FormatType(Type type) => type == null ? "<null>" : type.FullName ?? type.Name;
    }
}
