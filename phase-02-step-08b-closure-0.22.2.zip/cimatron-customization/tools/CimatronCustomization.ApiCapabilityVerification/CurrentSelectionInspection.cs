using System;
using System.Globalization;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class CurrentSelectionInspection
    {
        internal static int Run(VerificationArguments args)
        {
            using (VerificationRuntimeContext context = VerificationRuntimeContext.Attach(args.ExpectedContext, "07C-1C CURRENT SELECTION INSPECTION"))
            {
                NoMutationEvidence before = NoMutationEvidence.Capture(context.Document);
                try
                {
                    context.Evidence.AppendLine("Purpose: Record the actual IDs/types of the entities currently selected by the user without changing selection or model state.");
                    context.Evidence.AppendLine("SelectionPolicy: READ_CURRENT_SELECTION_ONLY; this mode never assigns Selection and never infers semantic roles.");
                    context.Evidence.AppendLine("ModelTitle: " + context.Model.Title);

                    interop.CimMdlrAPI.ISelection selection = context.Document as interop.CimMdlrAPI.ISelection;
                    if (selection == null) throw new InvalidOperationException("Active document does not expose ISelection.");

                    interop.CimMdlrAPI.ICimEntityList selected = selection.Selection;
                    if (selected == null)
                    {
                        context.Evidence.AppendLine("SelectedEntities.Count: 0");
                        context.Evidence.AppendLine("SelectionResult: EMPTY");
                    }
                    else
                    {
                        context.Evidence.AppendLine("SelectedEntities.Count: " + selected.Count.ToString(CultureInfo.InvariantCulture));
                        interop.CimServicesAPI.IGeomServices geometry = null;
                        for (int i = 1; i <= selected.Count; i++)
                        {
                            interop.CimMdlrAPI.ICimEntity entity = (interop.CimMdlrAPI.ICimEntity)selected[i];
                            context.Evidence.AppendLine("SelectedEntity[" + i.ToString(CultureInfo.InvariantCulture) + "]: id=" + entity.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + entity.Type);

                            if (string.Equals(entity.Type.ToString(), "cmEdge", StringComparison.Ordinal))
                            {
                                if (geometry == null) geometry = (interop.CimServicesAPI.IGeomServices)((interop.CimMdlrAPI.IMdlrModel)context.Model).GetGeomServicesObj();
                                interop.CimServicesAPI.ICimEntity serviceEntity = entity as interop.CimServicesAPI.ICimEntity;
                                if (serviceEntity == null)
                                {
                                    context.Evidence.AppendLine("SelectedEntity[" + i.ToString(CultureInfo.InvariantCulture) + "].Convexity@0.5: ID_TYPE_MISMATCH reason=selected edge does not expose CimServicesAPI.ICimEntity");
                                }
                                else
                                {
                                    context.TryObserve("SelectedEntity[" + i.ToString(CultureInfo.InvariantCulture) + "].Convexity@0.5", () => geometry.GetEdgeConvexity(serviceEntity, 0.5d), out interop.CimServicesAPI.EdgeConvexityType _);
                                }
                            }
                        }
                        context.Evidence.AppendLine(selected.Count == 1 ? "SelectionResult: SINGLE_ENTITY" : "SelectionResult: MULTIPLE_ENTITIES");
                    }
                }
                finally
                {
                    NoMutationEvidence after = NoMutationEvidence.Capture(context.Document);
                    bool unchanged = before.IsEquivalentTo(after);
                    context.Evidence.AppendLine("NoMutationBefore: " + before);
                    context.Evidence.AppendLine("NoMutationAfter: " + after);
                    context.Evidence.AppendLine("No-mutation evidence: " + (unchanged ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
                    string path = VerificationEvidenceWriter.Write("api-capability-current-selection", context.Evidence.ToString());
                    Console.WriteLine("Evidence file: " + path);
                    if (!unchanged) Environment.ExitCode = 8;
                }
                return Environment.ExitCode == 8 ? 8 : 0;
            }
        }
    }
}
