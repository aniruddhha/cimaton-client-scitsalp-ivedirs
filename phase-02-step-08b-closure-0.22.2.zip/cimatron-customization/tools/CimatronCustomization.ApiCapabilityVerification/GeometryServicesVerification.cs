﻿using System;
using System.Globalization;
using System.Reflection;

namespace CimatronCustomization.ApiCapabilityVerification
{
    internal static class GeometryServicesVerification
    {
        internal static int Run(VerificationArguments args)
        {
            using (VerificationRuntimeContext context = VerificationRuntimeContext.Attach(args.ExpectedContext, "07C-1 GEOMETRY"))
            {
                NoMutationEvidence before = NoMutationEvidence.Capture(context.Document);
                try
                {
                    interop.CimMdlrAPI.IMdlrModel mdlrModel = (interop.CimMdlrAPI.IMdlrModel)context.Model;
                    interop.CimServicesAPI.IGeomServices geometry = context.Observe("GetGeomServicesObj", () => (interop.CimServicesAPI.IGeomServices)mdlrModel.GetGeomServicesObj());
                    interop.CimMdlrAPI.IEntityQuery query = (interop.CimMdlrAPI.IEntityQuery)context.Model;
                    interop.CimMdlrAPI.IEntityFilter rawFilter = query.CreateFilter(interop.CimMdlrAPI.EFilterEnumType.cmFilterEntityType);
                    interop.CimBaseAPI.FilterType bodyFilter = (interop.CimBaseAPI.FilterType)rawFilter;
                    bodyFilter.Add(interop.CimBaseAPI.EntityEnumType.cmBody);
                    query.SetFilter(rawFilter);
                    interop.CimMdlrAPI.ICimEntityList bodies = context.Observe("BodyEnumeration", () => query.Select());
                    int bodyCount = context.Observe("BodyCount", () => bodies.Count);
                    for (int i = 1; i <= bodyCount; i++)
                    {
                        int index = i;
                        interop.CimMdlrAPI.ICimEntity body = (interop.CimMdlrAPI.ICimEntity)bodies[index];
                        interop.CimServicesAPI.ICimEntityList single = CreateServiceList(body);
                        context.TryObserve("Body[" + index + "].BodiesVolume", () => geometry.BodiesVolume(single), out double _);
                        context.TryObserve("Body[" + index + "].BodiesCenter", () => (double[])geometry.BodiesCenter(single), out double[] _);
                        context.TryObserve("Body[" + index + "].BodiesSurfArea", () => geometry.BodiesSurfArea(single), out double _);
                    }

                    interop.CimServicesAPI.ICimEntityList serviceBodies = (interop.CimServicesAPI.ICimEntityList)bodies;
                    context.TryObserve("AllBodies.BodiesVolume", () => geometry.BodiesVolume(serviceBodies), out double _);
                    context.TryObserve("AllBodies.BodiesCenter", () => (double[])geometry.BodiesCenter(serviceBodies), out double[] _);
                    context.TryObserve("AllBodies.BodiesSurfArea", () => geometry.BodiesSurfArea(serviceBodies), out double _);

                    interop.CimServicesAPI.IUcs primaryUcs = ResolveUcs(context, args.UcsId, "PrimaryUcs");
                    interop.CimServicesAPI.IUcs referenceUcs = ResolveUcs(context, args.ReferenceUcsId, "ReferenceUcs");
                    interop.CimBaseAPI.ICimEntityList b1FacesBase = ResolveBodyFaces(context, args.EntityA, bodies);
                    interop.CimServicesAPI.ICimEntityList b1Faces = b1FacesBase == null ? null : (interop.CimServicesAPI.ICimEntityList)b1FacesBase;

                    if (primaryUcs != null)
                    {
                        context.TryObserve("GetBoundingBoxByUCS.Bodies.Primary", () => (double[])geometry.GetBoundingBoxByUCS(serviceBodies, primaryUcs), out double[] _);
                        if (b1Faces != null) context.TryObserve("GetBoundingBoxByUCS.B1Faces.Primary", () => (double[])geometry.GetBoundingBoxByUCS(b1Faces, primaryUcs), out double[] _);
                    }
                    else context.Evidence.AppendLine("GetBoundingBoxByUCS.Primary: NOT_TESTED reason=no primary UCS resolved");

                    if (referenceUcs != null)
                    {
                        context.TryObserve("GetBoundingBoxByUCS.Bodies.Reference", () => (double[])geometry.GetBoundingBoxByUCS(serviceBodies, referenceUcs), out double[] _);
                        if (b1Faces != null) context.TryObserve("GetBoundingBoxByUCS.B1Faces.Reference", () => (double[])geometry.GetBoundingBoxByUCS(b1Faces, referenceUcs), out double[] _);
                    }
                    else context.Evidence.AppendLine("GetBoundingBoxByUCS.Reference: NOT_TESTED reason=--reference-ucs-id not supplied/resolved");

                    if (args.EntityA.HasValue && args.EntityB.HasValue)
                    {
                        interop.CimServicesAPI.ICimEntity a = context.GetEntity(args.EntityA.Value) as interop.CimServicesAPI.ICimEntity;
                        interop.CimServicesAPI.ICimEntity b = context.GetEntity(args.EntityB.Value) as interop.CimServicesAPI.ICimEntity;
                        try
                        {
                            interop.CimServicesAPI.IPointData pa;
                            interop.CimServicesAPI.IPointData pb;
                            double distance = geometry.MinDistancePos(a, b, out pa, out pb);
                            context.Evidence.AppendLine("MinDistancePos: PRESENT distance=" + distance.ToString("R", CultureInfo.InvariantCulture) + "; pointA=" + FormatPoint(pa) + "; pointB=" + FormatPoint(pb));
                        }
                        catch (Exception ex) { WriteError(context, "MinDistancePos", ex); }
                    }
                    else context.Evidence.AppendLine("MinDistancePos: NOT_TESTED reason=--entity-a and --entity-b are both required");

                    VerifyFace(context, geometry, args, primaryUcs, referenceUcs);

                    VerifyPiercingPoints(context, geometry, args, serviceBodies);

                    if (args.EdgeId.HasValue)
                    {
                        interop.CimServicesAPI.ICimEntity edge = context.GetEntity(args.EdgeId.Value) as interop.CimServicesAPI.ICimEntity;
                        context.TryObserve("GetEdgeConvexity", () => geometry.GetEdgeConvexity(edge, 0.5d), out interop.CimServicesAPI.EdgeConvexityType _);
                    }
                    else context.Evidence.AppendLine("GetEdgeConvexity: NOT_TESTED reason=--edge-id not supplied");

                    VerifyEntityPointDistances(context, geometry, args);
                }
                finally
                {
                    NoMutationEvidence after = NoMutationEvidence.Capture(context.Document);
                    bool unchanged = before.IsEquivalentTo(after);
                    context.Evidence.AppendLine("NoMutationBefore: " + before);
                    context.Evidence.AppendLine("NoMutationAfter: " + after);
                    context.Evidence.AppendLine("No-mutation evidence: " + (unchanged ? "UNCHANGED" : "CHANGED_OR_UNVERIFIED"));
                    string path = VerificationEvidenceWriter.Write("api-capability-geometry", context.Evidence.ToString());
                    Console.WriteLine("Evidence file: " + path);
                    if (!unchanged) Environment.ExitCode = 8;
                }
                return Environment.ExitCode == 8 ? 8 : 0;
            }
        }


        private static void VerifyPiercingPoints(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, VerificationArguments args, interop.CimServicesAPI.ICimEntityList serviceBodies)
        {
            if (args.RayOrigins.Count == 0)
            {
                context.Evidence.AppendLine("GetPiercingPoints: NOT_TESTED reason=known-answer --ray-origin/--ray-direction not supplied");
                return;
            }

            interop.CimServicesAPI.ICimEntityList targets = serviceBodies;
            string targetLabel = "all bodies";
            if (args.FaceId.HasValue)
            {
                interop.CimMdlrAPI.ICimEntity face = context.GetEntity(args.FaceId.Value);
                if (face == null || !string.Equals(face.Type.ToString(), "cmFace", StringComparison.Ordinal))
                {
                    context.Evidence.AppendLine("GetPiercingPoints: BLOCKED reason=--face-id did not resolve to cmFace");
                    return;
                }
                targets = CreateServiceList(face);
                targetLabel = "face " + args.FaceId.Value.ToString(CultureInfo.InvariantCulture);
            }

            context.Evidence.AppendLine("GetPiercingPoints.Target: " + targetLabel);
            for (int i = 0; i < args.RayOrigins.Count; i++)
            {
                int caseNumber = i + 1;
                double[] basePosition = args.RayOrigins[i];
                double[] direction = args.RayDirections[i];
                InspectPiercingReturn(context, geometry, targets, basePosition, direction, caseNumber);
            }
        }


        private static void InspectPiercingReturn(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, interop.CimServicesAPI.ICimEntityList targets, double[] basePosition, double[] direction, int caseNumber)
        {
            string label = "GetPiercingPoints[" + caseNumber.ToString(CultureInfo.InvariantCulture) + "]";
            try
            {
                context.Evidence.AppendLine(label + ".Input: direction=" + SafeFormat(direction) + "; basePosition=" + SafeFormat(basePosition));
                object value = geometry.GetPiercingPoints(direction, basePosition, targets);
                context.Evidence.AppendLine(label + ": PRESENT returnType=" + RuntimeTypeName(value) + "; value=" + SafeFormat(value));

                Array array = value as Array;
                if (array == null)
                {
                    context.Evidence.AppendLine(label + ".Shape: NOT_ARRAY");
                    return;
                }

                context.Evidence.AppendLine(label + ".Shape: arrayType=" + array.GetType().FullName + "; rank=" + array.Rank.ToString(CultureInfo.InvariantCulture) + "; length=" + array.Length.ToString(CultureInfo.InvariantCulture));
                int itemIndex = 0;
                foreach (object item in array)
                {
                    context.Evidence.AppendLine(label + ".Item[" + itemIndex.ToString(CultureInfo.InvariantCulture) + "]: type=" + RuntimeTypeName(item) + "; value=" + SafeFormat(item));
                    itemIndex++;
                }
            }
            catch (Exception ex)
            {
                WriteError(context, label, ex);
            }
        }


        private static string RuntimeTypeName(object value)
        {
            return value == null ? "<null>" : value.GetType().FullName;
        }


        private static string SafeFormat(object value)
        {
            try { return VerificationRuntimeContext.Format(value); }
            catch (Exception ex) { return "<format-error type=" + ex.GetType().FullName + "; message=" + ex.Message + ">"; }
        }

        private static void VerifyEntityPointDistances(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, VerificationArguments args)
        {
            if (!args.EntityId.HasValue || args.Points.Count == 0)
            {
                context.Evidence.AppendLine("GetEntityPointDistance: NOT_TESTED reason=known-answer --entity-id/--point pair not supplied");
                return;
            }

            interop.CimServicesAPI.ICimEntity entity = context.GetEntity(args.EntityId.Value) as interop.CimServicesAPI.ICimEntity;
            for (int i = 0; i < args.Points.Count; i++)
            {
                int caseNumber = i + 1;
                try
                {
                    interop.CimServicesAPI.IPointData nearestPoint;
                    double distance = geometry.GetEntityPointDistance(entity, args.Points[i], out nearestPoint);
                    context.Evidence.AppendLine("GetEntityPointDistance[" + caseNumber.ToString(CultureInfo.InvariantCulture) + "]: PRESENT distance=" + distance.ToString("R", CultureInfo.InvariantCulture) + "; point=" + FormatPoint(nearestPoint));
                }
                catch (Exception ex) { WriteError(context, "GetEntityPointDistance[" + caseNumber.ToString(CultureInfo.InvariantCulture) + "]", ex); }
            }
        }

        private static void VerifyFace(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, VerificationArguments args, interop.CimServicesAPI.IUcs primaryUcs, interop.CimServicesAPI.IUcs referenceUcs)
        {
            if (!args.FaceId.HasValue)
            {
                context.Evidence.AppendLine("FaceVerification: NOT_TESTED reason=--face-id not supplied");
                return;
            }

            interop.CimMdlrAPI.ICimEntity faceEntity;
            try { faceEntity = context.GetEntity(args.FaceId.Value); }
            catch (Exception ex) { WriteError(context, "FaceVerification.Resolve", ex); context.Evidence.AppendLine("FaceVerification: BLOCKED reason=face ID lookup failed"); return; }
            if (faceEntity == null)
            {
                context.Evidence.AppendLine("FaceVerification: BLOCKED reason=face ID did not resolve");
                return;
            }

            context.Evidence.AppendLine("FaceVerification.Resolve: id=" + faceEntity.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + faceEntity.Type);
            if (!string.Equals(faceEntity.Type.ToString(), "cmFace", StringComparison.Ordinal))
            {
                context.Evidence.AppendLine("FaceVerification: BLOCKED reason=resolved entity is not cmFace");
                return;
            }

            interop.CimServicesAPI.ICimEntityList faceList = CreateServiceList(faceEntity);
            ObserveSurfacesArea(context, geometry, faceList);
            if (primaryUcs != null) context.TryObserve("GetBoundingBoxByUCS.Face.Primary", () => (double[])geometry.GetBoundingBoxByUCS(faceList, primaryUcs), out double[] _);
            else context.Evidence.AppendLine("GetBoundingBoxByUCS.Face.Primary: NOT_TESTED reason=no primary UCS resolved");
            if (referenceUcs != null) context.TryObserve("GetBoundingBoxByUCS.Face.Reference", () => (double[])geometry.GetBoundingBoxByUCS(faceList, referenceUcs), out double[] _);
            else context.Evidence.AppendLine("GetBoundingBoxByUCS.Face.Reference: NOT_TESTED reason=--reference-ucs-id not supplied/resolved");
        }

        private static void ObserveSurfacesArea(VerificationRuntimeContext context, interop.CimServicesAPI.IGeomServices geometry, interop.CimServicesAPI.ICimEntityList faces)
        {
            MethodInfo method = null;
            foreach (MethodInfo candidate in typeof(interop.CimServicesAPI.IGeomServices).GetMethods())
            {
                if (string.Equals(candidate.Name, "SurfacesArea", StringComparison.Ordinal)) { method = candidate; break; }
            }
            if (method == null)
            {
                context.Evidence.AppendLine("SurfacesArea: NOT_AVAILABLE reason=installed IGeomServices contract has no SurfacesArea member");
                return;
            }

            try
            {
                object value = method.Invoke(geometry, new object[] { faces });
                context.Evidence.AppendLine("SurfacesArea: PRESENT value=" + VerificationRuntimeContext.Format(value));
            }
            catch (Exception ex) { WriteError(context, "SurfacesArea", ex); }
        }

        private static interop.CimServicesAPI.IUcs ResolveUcs(VerificationRuntimeContext context, int? id, string label)
        {
            object activeUcsObject = null;
            if (!id.HasValue && string.Equals(label, "PrimaryUcs", StringComparison.Ordinal))
                context.TryObserve("ActivateUcs.GET", () => ((interop.CimMdlrAPI.IMdlrModel)context.Model).ActivateUcs, out activeUcsObject);
            object source;
            try { source = id.HasValue ? context.GetEntity(id.Value) : activeUcsObject; }
            catch (Exception ex) { WriteError(context, label, ex); context.Evidence.AppendLine(label + ": BLOCKED reason=UCS ID lookup failed"); return null; }
            interop.CimServicesAPI.IUcs ucs = source as interop.CimServicesAPI.IUcs;
            if (source != null)
            {
                interop.CimMdlrAPI.ICimEntity entity = source as interop.CimMdlrAPI.ICimEntity;
                context.Evidence.AppendLine(label + ": " + (ucs == null ? "BLOCKED" : "RESOLVED") + (entity == null ? string.Empty : " id=" + entity.ID.ToString(CultureInfo.InvariantCulture) + "; type=" + entity.Type));
            }
            return ucs;
        }

        private static interop.CimBaseAPI.ICimEntityList ResolveBodyFaces(VerificationRuntimeContext context, int? bodyId, interop.CimMdlrAPI.ICimEntityList bodies)
        {
            interop.CimBaseAPI.IBody body = null;
            if (bodyId.HasValue) body = context.GetEntity(bodyId.Value) as interop.CimBaseAPI.IBody;
            else if (bodies != null && bodies.Count > 0) body = bodies[1] as interop.CimBaseAPI.IBody;
            if (body == null)
            {
                context.Evidence.AppendLine("B1Faces: BLOCKED reason=body entity could not be resolved as IBody");
                return null;
            }
            interop.CimBaseAPI.ICimEntityList faces = body.GetFaces();
            context.Evidence.AppendLine("B1Faces.Count: " + (faces == null ? "<null>" : faces.Count.ToString(CultureInfo.InvariantCulture)));
            return faces;
        }

        private static interop.CimServicesAPI.ICimEntityList CreateServiceList(interop.CimMdlrAPI.ICimEntity entity)
        {
            interop.CimBaseAPI.CimEntityList listBase = new interop.CimBaseAPI.CimEntityList();
            interop.CimServicesAPI.ICimEntityList list = (interop.CimServicesAPI.ICimEntityList)listBase;
            list.Add((interop.CimServicesAPI.ICimEntity)entity);
            return list;
        }

        private static string FormatPoint(interop.CimServicesAPI.IPointData point)
        {
            interop.CimServicesAPI.IGeom3DPoint p = point as interop.CimServicesAPI.IGeom3DPoint;
            return p == null ? VerificationRuntimeContext.Format(point) : p.X.ToString("R", CultureInfo.InvariantCulture) + "," + p.Y.ToString("R", CultureInfo.InvariantCulture) + "," + p.Z.ToString("R", CultureInfo.InvariantCulture);
        }

        private static void WriteError(VerificationRuntimeContext c, string label, Exception ex)
        {
            Exception raw = VerificationRuntimeContext.Unwrap(ex);
            c.Evidence.AppendLine(label + ": READ_ERROR type=" + raw.GetType().FullName + " HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) + " message=" + raw.Message);
        }
    }
}
