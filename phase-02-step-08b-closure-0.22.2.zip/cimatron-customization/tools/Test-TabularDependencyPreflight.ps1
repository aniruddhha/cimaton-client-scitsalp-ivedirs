param(
    [string]$CimatronProgram = "C:\Program Files\Cimatron\Cimatron\2026.0\Program"
)

$ErrorActionPreference = 'Stop'
$names = @('ExcelDataReader.dll', 'System.ValueTuple.dll')
Write-Host 'STEP 06B TABULAR DEPENDENCY PREFLIGHT'
Write-Host "CimatronProgram: $CimatronProgram"
foreach ($name in $names) {
    $path = Join-Path $CimatronProgram $name
    if (Test-Path -LiteralPath $path) {
        $item = Get-Item -LiteralPath $path
        $version = $item.VersionInfo.FileVersion
        $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash
        Write-Host "FOUND: $name"
        Write-Host "  Version: $version"
        Write-Host "  SHA256: $hash"
        Write-Host "  Path: $path"
    }
    else {
        Write-Host "NOT PRESENT: $name"
    }
}
