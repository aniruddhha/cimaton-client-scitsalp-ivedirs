Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$exe = Join-Path $repoRoot 'tests\CimatronCustomization.CimatronIntegrationTests\bin\x64\Release\CimatronCustomization.CimatronIntegrationTests.exe'
if (-not (Test-Path $exe)) {
    throw "CimatronIntegrationTests Release executable was not found: $exe. Run the Release x64 build first."
}

& $exe
if ($LASTEXITCODE -ne 0) {
    throw "CimatronIntegrationTests failed with exit code $LASTEXITCODE."
}
