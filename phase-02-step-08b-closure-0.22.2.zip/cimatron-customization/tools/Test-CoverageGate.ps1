param(
    [string]$CoverageFile = '',
    [switch]$AllowFoundationNoGovernedCode
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($CoverageFile)) {
    $CoverageFile = Join-Path $repoRoot 'artifacts\coverage\coverage.cobertura.xml'
}
if (-not (Test-Path $CoverageFile)) {
    throw "Coverage report not found: $CoverageFile"
}

$governed = @(
    @{ Name = 'CimatronCustomization.Domain'; Minimum = 0.90; Source = 'src\CimatronCustomization.Domain' },
    @{ Name = 'CimatronCustomization.Application'; Minimum = 0.90; Source = 'src\CimatronCustomization.Application' },
    @{ Name = 'CimatronCustomization.DesignChecks'; Minimum = 0.95; Source = 'src\CimatronCustomization.DesignChecks' },
    @{ Name = 'CimatronCustomization.Infrastructure'; Minimum = 0.80; Source = 'src\CimatronCustomization.Infrastructure' }
)

[xml]$coverage = Get-Content -LiteralPath $CoverageFile
$packages = @($coverage.coverage.packages.package)
$failures = New-Object System.Collections.Generic.List[string]
$evaluated = 0

foreach ($rule in $governed) {
    $sourceDir = Join-Path $repoRoot $rule.Source
    $substantiveSource = @(Get-ChildItem -LiteralPath $sourceDir -Recurse -Filter '*.cs' -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.FullName -notmatch '[\\/](bin|obj)[\\/]' -and
            $_.FullName -notmatch '[\\/]Properties[\\/]AssemblyInfo\.cs$'
        })

    $package = $packages | Where-Object { $_.name -eq $rule.Name } | Select-Object -First 1

    if ($null -eq $package) {
        if ($substantiveSource.Count -gt 0) {
            $failures.Add("$($rule.Name): substantive source exists but the package is missing from coverage.")
        }
        continue
    }

    $evaluated++
    $rate = [double]::Parse([string]$package.'line-rate', [Globalization.CultureInfo]::InvariantCulture)
    $percent = [Math]::Round($rate * 100, 2)
    $minimumPercent = [Math]::Round([double]$rule.Minimum * 100, 2)
    Write-Host "$($rule.Name): $percent% (minimum $minimumPercent%)"
    if ($rate -lt [double]$rule.Minimum) {
        $failures.Add("$($rule.Name): $percent% is below $minimumPercent%.")
    }
}


$integrationPackage = $packages | Where-Object { $_.name -eq 'CimatronCustomization.CimatronIntegration' } | Select-Object -First 1
if ($null -eq $integrationPackage) {
    $failures.Add('CimatronCustomization.CimatronIntegration: production adapter package is missing from coverage; Step 05B2 COM glue must not be silently excluded.')
}
else {
    $integrationRate = [double]::Parse([string]$integrationPackage.'line-rate', [Globalization.CultureInfo]::InvariantCulture)
    $integrationPercent = [Math]::Round($integrationRate * 100, 2)
    Write-Host "CimatronCustomization.CimatronIntegration: $integrationPercent% (measured; no threshold introduced in Step 05B2)"
}

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Error $_ }
    throw 'COVERAGE GATE: FAIL'
}

if ($evaluated -eq 0) {
    if ($AllowFoundationNoGovernedCode) {
        Write-Host 'COVERAGE GATE: NOT APPLICABLE — no substantive governed production code exists yet.'
        exit 0
    }
    throw 'No governed production package was evaluated. Coverage gate cannot pass.'
}

Write-Host 'COVERAGE GATE: PASS'
