Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$testExe = Join-Path $repoRoot 'tests\CimatronCustomization.Application.Tests\bin\x64\Release\CimatronCustomization.Application.Tests.exe'

if (-not (Test-Path $testExe)) {
    throw "Release Application.Tests executable not found: $testExe"
}

& $testExe
if ($LASTEXITCODE -ne 0) {
    throw "APPLICATION TESTS: FAIL (exit code $LASTEXITCODE)"
}
