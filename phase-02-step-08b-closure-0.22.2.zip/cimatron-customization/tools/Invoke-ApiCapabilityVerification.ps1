param(
    [Parameter(Mandatory=$true)][ValidateSet('reflect','geometry','assembly-context','component-properties','hidden-state')][string]$Mode,
    [Parameter(ValueFromRemainingArguments=$true)][string[]]$Arguments
)
$ErrorActionPreference = 'Stop'
$exe = 'C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe'
if (-not (Test-Path $exe)) { throw "Step 07 diagnostic executable not found: $exe" }
$map = @{
    'reflect'='--reflect-capability-api';
    'geometry'='--verify-geometry';
    'assembly-context'='--verify-assembly-context';
    'component-properties'='--verify-component-properties';
    'hidden-state'='--verify-hidden-state-candidates'
}
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outDir = Join-Path (Get-Location) 'artifacts\diagnostics'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$capture = Join-Path $outDir ("step07-{0}-{1}.txt" -f $Mode,$timestamp)
$allArgs = @($map[$Mode]) + @($Arguments)
& $exe @allArgs 2>&1 | Tee-Object -FilePath $capture
$exit = $LASTEXITCODE
Write-Host "Capture: $capture"
Write-Host "ExitCode: $exit"
exit $exit
