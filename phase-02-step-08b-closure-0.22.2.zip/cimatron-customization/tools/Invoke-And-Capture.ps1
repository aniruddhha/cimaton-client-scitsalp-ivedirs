[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('quality-gate', 'assembly-entities', 'trace-selftest')]
    [string]$Task
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repositoryRoot = Split-Path -Parent $PSScriptRoot
$captureDirectory = Join-Path $repositoryRoot 'artifacts\console-captures'
New-Item -ItemType Directory -Path $captureDirectory -Force | Out-Null

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$capturePath = Join-Path $captureDirectory ("{0}-{1}.txt" -f $Task, $timestamp)
$startedAt = Get-Date

switch ($Task) {
    'quality-gate' {
        $program = (Get-Command powershell.exe -ErrorAction Stop).Source
        $arguments = @('-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot 'Invoke-QualityGate.ps1'))
    }
    'assembly-entities' {
        $program = 'C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe'
        $arguments = @('--assembly-entities')
    }
    'trace-selftest' {
        $program = 'C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe'
        $arguments = @('--trace-selftest')
    }
    default {
        throw "Unsupported task: $Task"
    }
}

if (-not (Test-Path -LiteralPath $program)) {
    throw "Task executable not found: $program"
}

$displayCommand = '"{0}" {1}' -f $program, (($arguments | ForEach-Object {
    if ($_ -match '\s') { '"' + $_ + '"' } else { $_ }
}) -join ' ')

$header = @(
    'CIMATRON CUSTOMIZATION CONSOLE CAPTURE'
    "Task: $Task"
    "Timestamp: $($startedAt.ToString('o'))"
    "WorkingDirectory: $(Get-Location)"
    "Command: $displayCommand"
    '----------------------------------------'
)

$header | Set-Content -LiteralPath $capturePath -Encoding UTF8
$header | ForEach-Object { Write-Host $_ }

$capturedExitCode = 0
try {
    & $program @arguments 2>&1 | ForEach-Object {
        $line = $_ | Out-String
        $line = $line.TrimEnd()
        Write-Host $line
        Add-Content -LiteralPath $capturePath -Value $line -Encoding UTF8
    }
    $capturedExitCode = [int]$LASTEXITCODE
}
catch {
    $capturedExitCode = 1
    $errorText = $_ | Out-String
    $errorText = $errorText.TrimEnd()
    Write-Host $errorText
    Add-Content -LiteralPath $capturePath -Value $errorText -Encoding UTF8
}

$completedAt = Get-Date
$footer = @(
    '----------------------------------------'
    "Completed: $($completedAt.ToString('o'))"
    "ExitCode: $capturedExitCode"
    "CaptureFile: $capturePath"
)

$footer | Add-Content -LiteralPath $capturePath -Encoding UTF8
$footer | ForEach-Object { Write-Host $_ }

exit $capturedExitCode
