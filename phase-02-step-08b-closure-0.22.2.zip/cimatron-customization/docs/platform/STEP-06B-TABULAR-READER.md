# Step 06B — Tabular Reader Infrastructure

## Approved dependency decision

The user approved ExcelDataReader 3.9.0 on 2026-09-28, conditional on Cimatron 2026 in-process compatibility validation. The base package only is used; `ExcelDataReader.DataSet` is not added. `System.ValueTuple` 4.5.0 is pinned explicitly as part of the runtime dependency graph.

## Scope

`ExcelTabularDataReader` is an Infrastructure adapter for the Step 06A `ITabularDataReader` port. It supports `.xlsx`, `.xls`, and `.csv` and does not implement CR-04 or CR-22 business logic.

The customer workbook layout remains unknown. Worksheet name, header row, source headers, logical column names and value types come from `TabularSourceDefinition`.

## Read policy

- `.xlsx` and `.xls`: configured worksheet name is matched case-insensitively.
- `.csv`: one table only; worksheet name is ignored.
- headers: configured source headers are matched case-insensitively without inventing aliases.
- blank mapped rows are skipped.
- required blank values fail the complete read.
- `Text` uses invariant string conversion.
- `Decimal` accepts native numeric Excel values and invariant-culture numeric strings.
- no formula/date/locale/merged-cell/hidden-row semantics are claimed beyond what the low-level reader exposes; customer-specific behavior remains pending real customer files.

## Safety limits

- maximum file size: 25 MiB;
- maximum non-empty mapped data rows: 100,000;
- file open mode: read-only with `FileShare.ReadWrite`;
- no partial success result is returned after an error.

## Stable reader error codes

- `TABULAR_FILE_NOT_FOUND`
- `TABULAR_UNSUPPORTED_FORMAT`
- `TABULAR_FILE_TOO_LARGE`
- `TABULAR_FILE_READ_ERROR`
- `TABULAR_WORKSHEET_NOT_FOUND`
- `TABULAR_HEADER_ROW_MISSING`
- `TABULAR_COLUMN_NOT_FOUND`
- `TABULAR_REQUIRED_VALUE_MISSING`
- `TABULAR_VALUE_INVALID`
- `TABULAR_ROW_LIMIT_EXCEEDED`

## Tests prepared

Infrastructure tests cover CSV, generated minimal Open XML `.xlsx`, deterministic static BIFF8/CDF `.xls`, missing worksheet/column, invalid decimal, row limit and file-size limit. Per `AGENTS.md`, the AI agent does not execute these tests; workstation evidence is required.

## Cimatron host validation boundary

Before the first build/deploy of this dependency set, run `tools/Test-TabularDependencyPreflight.ps1` and return the output. Existing `ExcelDataReader.dll` or `System.ValueTuple.dll` in the Cimatron Program directory is a potential collision and must be reviewed before proceeding.

A clean filesystem preflight is not sufficient to close 06B. A later controlled in-process Cimatron read probe must prove the dependency can load and read a known-answer fixture in the real host process without binding errors or unintended process behavior.


## 0.17.2 legacy XLS fixture correction

User validation of 0.17.1 proved the compile/reference correction: Release x64 built cleanly. The remaining Infrastructure failure was isolated to the synthetic BIFF2 fixture, which did not expose the configured named worksheet. Version 0.17.2 replaces only that fixture path with a deterministic static BIFF8/CDF `.xls` workbook named `Input`; the production reader and approved dependency decision are unchanged. Cimatron in-process compatibility remains NOT VERIFIED.


## 0.17.4 Cimatron in-process runtime probe

User-run 0.17.2 validation is clean: Release x64 build, all required test suites, coverage gate and local quality gate passed with exit code 0. The subsequent filesystem preflight found `ExcelDataReader.dll` 3.9.0.0 and `System.ValueTuple.dll` in the Cimatron Program directory, but that evidence cannot establish whether the real Cimatron host can bind and execute the reader.

0.17.4 retains the diagnostic-only opt-in path, with the probe implementation located under `Plugin/Diagnostics/` so the established thin Plugin top-level boundary remains unchanged. `CimatronCommandExecution` checks `CIMATRON_STEP06B_TABULAR_PROBE_FILE` before the ordinary launcher flow. When the variable is absent, behavior is unchanged. When present, the command runs `TabularReaderRuntimeProbe`, reads the existing BIFF8 known-answer fixture through `ExcelTabularDataReader`, validates `Block_A / 1.2344 / 12.5`, captures loaded assembly versions/locations, writes evidence, reports PASS/FAIL, and returns without opening the ordinary Feature Launcher. The probe performs no Cimatron model access or mutation.

Use `tools/Start-Step06BTabularProbe.ps1` only after a clean 0.17.4 quality gate. Start Cimatron from that script, open a disposable supported document if required for command visibility, and click `Cimatron Customization` once. Return the generated evidence file. 06B remains open until that live evidence is reviewed.


## 0.17.5 normal-launch one-shot runtime probe

User-run 0.17.4 quality gate is clean. The first live-probe attempt exposed a validation-helper design issue: `Start-Step06BTabularProbe.ps1` directly launched `CimatronE.exe` solely so process-local environment variables would be inherited. On the workstation, direct `Start-Process` of that EXE exited with code 0 without showing Cimatron. The installed shortcut uses the same target and working directory, but the reason for the launch-behavior difference was not established and is outside Step 06B reader scope.

Version 0.17.5 removes Cimatron startup from the helper. The helper creates `%TEMP%\CimatronCustomization\step06b-tabular-probe.request` containing `Version`, `RequestedUtc`, `InputFile`, and `EvidenceFile`, then instructs the operator to start Cimatron normally. On the first `Cimatron Customization` click, the Plugin looks for that request. If absent, ordinary Feature Launcher behavior is unchanged. If present, it is moved to a process-specific consuming name, validated as version 0.17.5 and no older than 30 minutes, then consumed once. The existing read-only known-answer probe executes and the consumed request is deleted.

This avoids machine-specific `.lnk` dependencies and keeps live validation representative of real client startup behavior. It does not alter `ExcelTabularDataReader`, dependency versions, CR business logic, or Cimatron model state.

After a clean 0.17.5 quality gate, run `tools/Start-Step06BTabularProbe.ps1`, start Cimatron normally, open a disposable supported document if needed for command visibility, click `Cimatron Customization` once, and return the generated evidence file. 06B remains open until that evidence is reviewed.
