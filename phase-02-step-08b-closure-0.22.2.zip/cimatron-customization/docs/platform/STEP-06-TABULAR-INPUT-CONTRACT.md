# Step 06 — Tabular Input Contract

## Status

Step 06A defines the Application-layer contract only. It does not select an Excel library, parse `.xlsx`, or implement CR-04/CR-22 business logic.

## Requirement traceability

- Cross-cutting Sheet 1 requirement: the Design Order (DO) Excel Input Sheet is master data for Excel-to-CAD verification.
- CR-04: compare the CAD steel/material attribute with the expected steel grade from the DO Input Sheet.
- CR-22: compare finger-pin diameter with the customer slider-weight/diameter table. Slider weight itself is calculated later by CR-specific geometry logic.
- Sheet 2 SA references to Excel are not Step 06 consumers.

## Known limitation entering Step 06

The customer has not yet supplied the actual DO Input Sheet or slider-weight table layout. Worksheet names, header-row positions, column headers, formula behavior, hidden-row/sheet behavior, merged cells, locale rules, and other workbook-specific semantics are therefore unknown.

Step 06 must not invent those details.

## 06A contract

The Application layer owns the following dependency-neutral types:

- `ITabularDataReader`
- `TabularSourceDefinition`
- `TabularColumnDefinition`
- `TabularValueType`
- `TabularValue`
- `TabularRow`
- `TabularTable`
- `TabularReadResult`

`TabularSourceDefinition` carries the runtime file path plus configuration-driven worksheet name, header row, and source-header-to-logical-column mappings.

Only value types required by the currently named consumers are admitted in 06A:

- `Text` — identifiers and steel grade values used by CR-04.
- `Decimal` — slider weight and finger-pin diameter values used by CR-22.

Additional cell types are not introduced until a real requirement or customer workbook proves they are necessary.

## Failure contract

A reader implementation must be all-or-nothing. A successful result contains a complete `TabularTable`; an error result contains no table and requires both an actionable stable error code and actionable message.

Step 06B must map at least these requirement-level failure classes without silently returning partial data:

- missing input file;
- file cannot be read/locked in a way the selected reader cannot support;
- missing configured worksheet;
- missing configured source column;
- unparsable required value.

The exact implementation error-code catalogue is finalized with the 06B reader implementation.

## Data handling

Customer worksheet content must not be logged beyond necessary counts and non-sensitive identifiers. The contract deliberately carries data in-memory without introducing logging behavior.

## Temporary fixtures

`tests/TestData/Step06/` contains requirement-derived CSV fixtures. They are documentation/test fixtures only and are explicitly **not** customer layout assumptions.

## 06B approval boundary

Before implementing a runtime reader, Step 06B must separately present and obtain approval for:

1. reader-library choice or CSV-only alternative;
2. .NET Framework 4.8 compatibility;
3. exact pinned version/source/license;
4. Cimatron in-process dependency-conflict risk;
5. `.xlsx` / `.xls` / `.csv` supported-format scope;
6. shared-read behavior while a workbook is open;
7. size/row limits;
8. workbook-specific semantics that can only be decided from real customer data or an explicitly approved policy.

## 06D orchestration integration

Step 06D connects the approved generic reader and mapping contracts without introducing customer-specific workbook assumptions or CR-specific business rules.

The Application orchestration flow is:

```text
Header discovery
  -> mapping resolution
  -> mapped row read
  -> row validation
  -> complete validated table
```

The flow is fail-closed. The combined outcome uses the canonical `ResultStatus` model and records the failing processing stage as `Discovery`, `Mapping`, `Read`, or `Validation`. Step 06D does not introduce another success/failure status model.

### Source consistency

Header discovery and row reading intentionally remain two physical reads because moving raw workbook parsing/conversion into Application would broaden the approved contract and duplicate Infrastructure responsibilities.

To prevent a mapping resolved against stale workbook structure:

- discovery applies the same file-format and maximum-file-size checks as row reading;
- the complete ordered header snapshot discovered on pass one is supplied to pass two;
- pass two compares the actual header row with that snapshot before resolving any source columns or reading data rows;
- any difference returns `TABULAR_HEADERS_CHANGED` and no table is returned.

This protects against the source workbook being saved or structurally changed between discovery and data reading.

### Live integration probe

The Step 06D in-process probe invokes `ReadMappedTabularData` using the real `ExcelTabularDataReader` adapter and the known-answer Step 06 fixture. It therefore exercises discovery, mapping, consistent row reading, and validation inside the actual Cimatron process.

The probe remains diagnostic-only and does not add CR-04/CR-22 logic or change the normal Plugin UI.

## 06E — Live Validation & Closure

06E is the planned live-validation and closure activity after 06D. No further architecture expansion is introduced by 06E. Step 06 can close when user-supplied evidence confirms:

- generic `.xlsx` / `.xls` / `.csv` reader behavior;
- configuration-driven mapping;
- controlled failure modes including stale-header rejection;
- approved/pinned reader dependency and preflight controls;
- Application orchestration through the approved contracts;
- quality gate PASS;
- live Cimatron mapped-tabular probe PASS;
- complete documentation, time-ledger, and package integrity records.

CR-04/CR-22 business rules and real customer workbook layouts remain future consumer work.


### 06E final status

06E is **VALIDATED / CLOSED** at version `0.19.1`. The real sample-file probe ran in-process in Cimatron and the final closure-package quality gate passed. Historical probe filenames that say `06D` are retained for evidence integrity but are classified as 06E validation evidence.

### Deferred carry-forward

Non-blocking final-review findings are governed by `docs/platform/STEP-06-DEFERRED-FINDINGS.md`. Applicable IDs must be referenced during CR-04, CR-22 and D5/client-package planning until explicitly resolved/accepted/superseded.
