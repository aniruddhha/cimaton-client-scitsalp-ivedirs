# Cimatron 2026 Model Access Verification — Phase 02 Step 04

## Target runtime

- Validated project runtime baseline: Cimatron 2026.0 SP2P1 (`2026,0201,2064,662`).
- Step 04 uses only read-oriented getters/query methods.
- Official SDK pages under `https://api.cimatron.com/assets/docs/...` are the primary source.
- The installed target-version interop DLLs and user-run live probe remain the runtime signature/behavior gate.

## Verification register

| Item | Status for Step 04 | Verified surface used | Notes |
|---|---|---|---|
| U1 — assembly hierarchy / placement | VERIFIED for traversal, model title/path/type, instance id, suppression, color and root-relative transformation; runtime marshaling compatibility corrected in 0.14.10 | `IAssemblyModel.GetInstances()`, `IAssInstance.Model`, `ID`, `Color`, `IsSuppressed`, `get_Transformation(1)`, `IModelTransformation.Matrix` | Live Cimatron 2026 validation showed `GetInstances()` marshaled as `object[]` even though the embedded interop surface advertises `IAssInstance[]`. Version 0.14.10 removes dynamic dispatch and calls `GetInstances()` through the strongly typed `IAssemblyModel`; the returned `object[]` is consumed element-by-element and each value is cast to `IAssInstance`, matching the official Cimatron C# example pattern. Recursive traversal follows nested assembly models. |
| U2 — attributes | PARTIALLY VERIFIED | `IAttributeSink.GetAttributes()`, `IAttribute.Name`, `Type`, `Value` | Verified for model entities. A documented general attribute-sink contract for `IAssInstance` was not established, so instance/component attributes return controlled `Unsupported` rather than a guessed call. |
| U3 — colors | VERIFIED for assembly instances; VERIFIED for explicit entity color attribute | `IAssInstance.Color`; entity `IAttributeSink.GetAttributes()` with `AttributeEnumType.cmAttColor` | Entity color is reported only when an explicit `cmAttColor` attribute is present. Absence is `Unsupported`, not an invented default. |
| U4 — bodies/faces/type/area/normal/bounding box | PARTIALLY VERIFIED | `IEntityQuery.CreateFilter/SetFilter/Select`, `FilterType.Add(cmBody)`, 2026 topology `IBody.GetFaces()`, `IFace`, `IGeom3DSurface.SurfType`, `Area()`, `NormalFromPoint(x,y,z)` | Body/face enumeration, face surface type, area and normal-at-point signatures are verified. A supported general entity/face bounding-box signature was not established, so bounding boxes are explicitly `Unsupported`. |

## Official SDK references reviewed

- `IAssemblyModel::GetInstances`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/iassemblymodel/iassemblymodel__getinstances.htm`
- `IAssInstance::Transformation`
  - `https://api.cimatron.com/assets/docs/Cimatron_E_API/elite_api_interfaces/iassinstance/iassinstance__transformation.htm`
- `IModelTransformation::Matrix`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/imodeltransformation/imodeltransformation_matrix.htm`
- `IAssInstance::Color`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/iassinstance/iassinstance_color.htm`
- `IAssInstance::IsSuppressed`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/iassinstance/iassinstance__issuppressed.htm`
- `IAttributeSink`
  - `https://api.cimatron.com/assets/docs/Cimatron_E_API/elite_api_interfaces/iattributesink/iattributesink.htm`
- `AttributeEnumType`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_enum/attributeenumtype.htm`
- `IEntityQuery::CreateFilter`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/ientityquery/ientityquery__createfilter.htm`
- `IEntityQuery::SetFilter`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/ientityquery/ientityquery__setfilter.htm`
- `IEntityQuery::Select`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/ientityquery/ientityquery__select.htm`
- `IBody::GetFaces`
  - `https://api.cimatron.com/assets/docs/Cimatron_E_API/elite_api_interfaces/ibody/ibody_getfaces.htm`
- `IFace`
  - `https://api.cimatron.com/assets/docs/Cimatron_E_API/elite_api_interfaces/iface/iface.htm`
- `IGeom3DSurface`
  - `https://api.cimatron.com/assets/docs/Cimatron_E_API/elite_api_interfaces/igeom3dsurface/igeom3dsurface.htm`
- `IGeom3DSurface::Area`
  - `https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/igeom3dsurface/igeom3dsurface_area.htm`

## 0.14.10 live runtime compatibility evidence

- User-run live Model Inspection Probe on a representative mold Assembly reached the assembly reader but returned an Error finding with message beginning `Cannot implicitly convert type 'object[]' ...`.
- Inspection of the only three direct `IAssemblyModel.GetInstances()` call sites showed each assigning directly to `IAssInstance[]`.
- Version 0.14.10 centralizes those three paths (`AppendComponents`, `CollectPartInstances`, and `FindInstance`) through one runtime-normalization helper.
- The helper does not invent model data: null arrays produce no instances; non-array runtime values produce no instances; null/non-`IAssInstance` array entries are ignored.
- This is a COM marshaling compatibility correction only. It adds no write-capable Cimatron calls and changes no customer CR/SA business rule.
- Automated workstation tests cannot reproduce the live COM marshaling shape without a live Cimatron runtime; therefore the mandatory proof is the user-run in-process Model Inspection Probe after the normal local quality gate.

## Read-only boundary

The Step 04 adapter calls no save, move, recolor, attach/detach attribute, procedure-creation or model-modification API. Validation features receive only the four Application read ports. Cimatron COM types remain inside `CimatronCustomization.CimatronIntegration`.

`CimatronCustomization.CimatronIntegration` now explicitly references Domain as well as Application because the approved Application port contracts intentionally use Domain-owned session-only geometry value types (`ModelEntityReference`, `Point3`, `Direction3`). This is an inward dependency from an outer adapter and is encoded explicitly in the architecture test.

## Unsupported behavior

The adapter does not guess signatures. In Step 04:

- instance/component attribute access is `Unsupported` unless a verified interface is established later;
- general entity/face bounding boxes are `Unsupported`;
- an entity without an explicit `cmAttColor` attribute returns `Unsupported` for entity color;
- normal-at-point is exposed by the port, but live proof requires a known point/face pair and is not fabricated by the foundation probe.

## Performance expectation

The model inspection probe performs one assembly traversal and one topology traversal for the run, then resolves only representative references for attribute/color proof. The Step 04 live run should record duration through the existing execution log. The planning reference is the customer's approximately 15-second cooling-analysis expectation; any materially slower customer-size assembly result must be investigated before Step 04 closure.

## 0.14.10 live-diagnostic hardening

Two independent live Cimatron 2026 runs exposed runtime-only behavior that offline tests could not reproduce:

1. Assembly traversal: dynamic dispatch against `System.__ComObject` did not expose `GetInstances()`. Version 0.14.10 therefore calls `GetInstances()` through the typed `IAssemblyModel` interface and consumes the returned `object[]`, casting each element to `IAssInstance`.
2. A smaller/single-assembly topology run returned only `Value does not fall within the expected range.` Version 0.14.10 now labels each topology boundary stage: filter creation, filter population/application, selection, body-list access, `IBody.GetFaces`, face-list access, geometry, surface type, and area.

This is diagnostic/read-compatibility hardening only. It introduces no model mutation and no customer CR/SA behavior.

## 0.14.10 Part-entry diagnostic hardening

A live Part run on 0.14.10 still returned the generic COM message `Value does not fall within the expected range.` without one of the existing topology-stage labels. That proves the exception occurs outside the previously instrumented inner topology operations.

Version 0.14.10 therefore adds stage labels around:
- active-document to `IModelContainer` conversion;
- `IModelContainer.Model` retrieval for Part and Assembly documents;
- assembly-instance `Model` and `ID` reads;
- model `PID` reads;
- body entity `ID` reads;
- face entity `ID` reads;
- body/face `ModelEntityReference` construction.

No Cimatron write/model-mutation API is introduced. This remains read-only diagnostic hardening intended to identify the exact live runtime boundary before any compatibility correction is attempted.

## 0.14.10 pre-topology diagnostic hardening

The 0.14.10 live Part run still returned the unlabelled COM message `Value does not fall within the expected range.` This proves the exception occurs before the 0.14.10 model-container/model/reference stages.

Version 0.14.10 therefore wraps the only remaining pre-topology operations in `ReadCurrentTopology()`:
- Cimatron application retrieval;
- active-document retrieval;
- active-document type read.

No compatibility behavior is guessed in this patch. The purpose is solely to identify the exact failing live COM operation. The adapter remains read-only.

## 0.14.10 entity-attribute runtime compatibility

Live Cimatron 2026 evidence from application version 0.14.10 identified the exact failing call on a specific Part/entity as `interop.CimBaseAPI.IAttributeSink.GetAttributes()`. The persisted stack trace showed `System.ArgumentException: Value does not fall within the expected range.` originating in `CimatronModelInspectionAdapter.ReadAttributes(...)`.

Version 0.14.10 converts only that `ArgumentException` from `GetAttributes()` into `ModelReadResult.Unsupported` with an explicit entity-specific message. Other unexpected exception types continue to propagate to the existing application error/logging boundary. This keeps the adapter read-only and allows otherwise valid topology/surface inspection results to remain visible when a particular entity rejects attribute enumeration.
