# Cimatron 2026 Viewport Highlight Verification — Step 05A

## Scope

Version `0.15.0` implements only the verified viewport **Highlight** capability. Zoom and interactive Pick are intentionally not implemented in this step.

## Authoritative API evidence

Official Cimatron API documentation used for this implementation:

1. `ISelection` — represents UI selection/highlight behavior and exposes the `Selection` property.
   - https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/iselection/iselection.htm
2. `ISelection::Selection` — `ICimEntityList Selection { get; set; }`; documentation states that getting/setting selection entities shows the selected entities highlighted.
   - https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/iselection/iselection_selection.htm
3. `ICimEntityList` — documented entity container; a new `CimEntityList` may be created and populated with desired entities.
   - https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/ientitylist/ientitylist.htm
4. `ICimEntityList::Add` — adds an entity to the entity list.
   - https://api.cimatron.com/assets/docs/Cimatron_E_API/elite_api_interfaces/ientitylist/ientitylist_add.htm

The above interfaces are documented as compatible with Cimatron 2024 or later and therefore cover Cimatron 2026.

## Implemented behavior

- Application defines `IViewportEntityHighlighter`.
- Plugin passes only opaque current-session finding reference strings.
- CimatronIntegration resolves only `entity|0|<model-pid>|<entity-id>` references against the currently active model.
- The model PID must match the current active model before highlighting.
- Resolved entities are added to a Cimatron entity list and assigned to `ISelection.Selection`.
- A finding with no supported current-session entity reference returns controlled Unsupported.
- Nested assembly-instance references (`instanceId != 0`) are controlled Unsupported in Step 05A because live selection/highlight behavior for nested instance-model entities has not yet been verified.
- Unexpected Cimatron/Interop exceptions are not swallowed or converted to a business-rule failure.

## Deliberately not implemented

### Zoom

No authoritative direct "zoom to finding/entity" contract has been accepted for this step. No `IDisplayUtils`/display-transformation implementation is included.

### Pick

Interactive picking is not part of Step 05A. No `IPickTool`, `PushPickTool`, COM-registered pick-tool class, or pick event implementation is included.

## User validation completed

Validation evidence was supplied by the user from the real development/Cimatron workstation.

- Release x64 build: **PASS**, 0 warnings / 0 errors.
- Architecture, Domain, Application and Infrastructure tests: **PASS**.
- Coverage gate: **PASS**.
- Coverage: Domain 100%; Application 95.41%; DesignChecks 100%; Infrastructure 98.48%.
- Standalone Part: selecting a finding and invoking **Highlight** visibly highlighted the corresponding geometry in orange in the active Cimatron viewport; no error was shown.
- Mold assembly: invoking Highlight for a nested assembly-instance finding produced the intended controlled **Unsupported** message. The adapter did not attempt unverified nested-instance highlighting.
- **Zoom — Unsupported** and **Pick — Unsupported** remained disabled as designed.

Step 05A is therefore **CLOSED / VERIFIED** from user-supplied workstation and live-Cimatron evidence.
