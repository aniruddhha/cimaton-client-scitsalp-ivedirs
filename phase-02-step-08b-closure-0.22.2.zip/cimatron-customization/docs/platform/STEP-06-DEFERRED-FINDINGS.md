# Step 06 Deferred Findings / Carry-Forward Register

Status: **DEFERRED — NON-BLOCKING FOR STEP 06 CLOSURE**

These findings were raised in an external final code review supplied by the user and cross-checked against the Step 06 implementation. They do not reopen Step 06. They MUST remain visible in planning/handoffs until the owning CR or release-hardening decision explicitly resolves, accepts, or supersedes them. A later CR may not silently drop an item.

| ID | Finding | Risk / effect | Mandatory carry-forward owner | Closure condition |
|---|---|---|---|---|
| ST06-DF-01 | `ReadMappedTabularData` returns only the first mapping/validation error although lower-level validation can collect multiple errors. | Safe but inefficient workbook remediation; users may need repeated fix/re-run cycles. | Review in **CR-04 and CR-22 planning**, and in any earlier user-facing tabular workflow. | Explicit UX/API decision on first-error vs structured multi-error reporting, with tests if changed. |
| ST06-DF-02 | Decimal text parsing uses `NumberStyles.Number` with invariant culture; text such as `"1,5"` can be interpreted as `15` rather than rejected. | Potential silent numeric misinterpretation. | **CR-22 is mandatory**, because its planned inputs include decimal weight/diameter values. Also applies to any future decimal-text consumer. | Consumer-specific numeric-format policy is approved and tested; unsafe ambiguous text is rejected or interpreted only by an explicit locale policy. |
| ST06-DF-03 | Numeric Excel cells used as identifiers can lose display formatting/trailing zeros when converted to text (for example steel grade `1.2080` becoming `1.208`). | Identifier mismatch against CAD attributes. | **CR-04 mandatory carry-forward.** | CR-04 defines and tests the authoritative steel-grade representation and workbook-cell policy using representative/customer data. |
| ST06-DF-04 | Header matching is case-insensitive but does not trim leading/trailing whitespace. | Safe controlled failure, but common spreadsheet whitespace can cause a missing-header error. | Review in **CR-04 and CR-22** when real workbook layouts are known. | Explicit normalization policy (strict or trimmed) is approved from real workbook evidence and tested. |
| ST06-DF-05 | The one-shot tabular runtime probe is checked from the normal plugin command path when a temp request exists. | Low runtime risk today, but diagnostic behavior must not unintentionally ship as client-facing production behavior. | **D5 / client packaging-release gate** before any client package. | Explicit dev-only/hidden/removal decision implemented and validated before client distribution. |
| ST06-DF-06 | Reader format-error classification treats any `ArgumentException` as a file-format/read error. | A programming defect throwing `ArgumentException` inside the guarded path could be masked as a controlled format error. | Generic platform hardening; review at **CR-04/CR-22 integration (whichever consumes the path first)** and before first client production release. | Exception classification is narrowed or consciously accepted with tests proving intended masking boundaries. |

## Carry-forward rule

Every CR/session handoff that reaches one of the owners above must reference the applicable `ST06-DF-*` IDs. Resolution must be recorded in the CR documentation and this register must be updated to `RESOLVED`, `ACCEPTED`, or `SUPERSEDED` with evidence. Until then, the status remains `DEFERRED`.

## Step 06 closure relationship

These findings are deliberately deferred. The validated Step 06 definition of done remains satisfied: generic reader, configuration mapping, controlled fail-closed behavior, dependency/runtime approval, stale-header protection, canonical orchestration, quality gate, and live in-process probe all passed.
