# Cimatron 2026 Zoom / View Discovery — Step 05C1

## Step 05C2 — Controlled native Zoom Selection validation (0.15.9)

### Evidence entering this step

User-supplied 0.15.8 evidence established:

- local quality gate PASS with 0 warnings / 0 errors;
- installed Interop reflection SUCCESS: 13 assemblies scanned, 251 matching member names;
- no direct installed-Interop `ZoomToEntity` / `FitEntity` style viewport-framing API identified;
- Part command inventory SUCCESS: 1401 commands, 74 candidates;
- Assembly command inventory SUCCESS: 1401 commands, 74 candidates;
- both contexts contain the exact native command `&Display,Zoom Selection`.

### Approved controlled experiment

The development-only tool now supports:

```text
--validate-zoom-selection --expect Part --entity-id <id>
--validate-zoom-selection --expect Assembly --entity-id <id>
```

The validation mode:

1. attaches through standalone `AppAccess.GetApplication()`;
2. verifies the expected active document context;
3. resolves only the supplied entity id from the active model;
4. snapshots the current `ISelection.Selection`;
5. temporarily selects the resolved entity;
6. resolves exactly `GetCommand("&Display", "Zoom Selection")`;
7. invokes that command exactly once;
8. restores the prior selection in `finally`;
9. writes diagnostic evidence that the command returned;
10. leaves the visual Zoom result for explicit user observation.

This mode does **not** modify model geometry and does **not** constitute production Zoom-to-result implementation. Nested assembly occurrence/entity addressing remains deferred.

The existing `--reflect` and `--commands` discovery modes remain read-only.


## Purpose

Step 05C1 gathers evidence for CR-11 FR-014 Zoom-to-result. It does **not** implement production zoom behavior and does **not** execute native Cimatron commands.

## 0.15.6 diagnostic-path finding

The 0.15.6 source package was re-inspected before creating the replacement tool.

Concrete repository evidence:

- `CimatronCustomization.CimatronIntegrationTests.csproj` is a classic .NET Framework MSBuild project, not an SDK-style test project.
- It contains no `Microsoft.NET.Test.Sdk` reference.
- It explicitly compiles `Program.cs` and has `OutputType=Exe`.
- The normal local quality gate executes that EXE directly.

Therefore the proposed explanation that `Microsoft.NET.Test.Sdk` generated a replacement `Program` entry point is **not supported by the 0.15.6 repository configuration**. Packaged development ZIPs intentionally exclude `obj/`, so the exact workstation reason for the silent `--discover-zoom-commands` invocation cannot be proven from the package alone. The ambiguous hook is removed in 0.15.7 and must not be reused.

If exact workstation build-artifact confirmation is still required, inspect the generated files under `tests\CimatronCustomization.CimatronIntegrationTests\obj\` after the user-run build and retain that evidence separately. Do not infer an SDK-generated entry point without such evidence.

## Official standalone Cimatron boundary

The Cimatron SDK documents standalone application access through `interop.CimAppAccess.AppAccess.GetApplication()` and requires the Cimatron side-by-side application manifest. The 0.15.7 diagnostic project:

- targets x64;
- embeds `app.manifest` based on the official Cimatron C# manifest template;
- builds into `C:\Program Files\Cimatron\Cimatron\2026.0\Program` so native/Interop dependencies resolve from the Cimatron installation;
- must run at the same privilege level as the running Cimatron process.

## Approved API allow-list

Step 05C1 live command-pool mode calls only:

- `AppAccess.GetApplication()`;
- `IApplication.GetActiveDoc()`;
- read-only `IApplication.ProductName` and `IApplication.Version` metadata;
- read-only `ICimDocument.Type` metadata;
- `IApplication.GetPoolCommands()`;
- `IPoolCommands.GetCommandsNames()`.

Step 05C2 separately approved the controlled `Zoom Selection` validation path and the read-only Assembly entity inventory path. The latter may additionally use the project-established read-only assembly/model inspection calls: `IAssemblyModel.GetInstances`, `IAssInstance.Model/ID`, `IEntityQuery.CreateFilter/SetFilter/Select`, entity ID reads, and `IBody.GetFaces`.

Outside those approved modes, no additional Cimatron API call is approved for this tool.

Explicitly prohibited for discovery/inventory modes:

- native command execution (except the separately approved Step 05C2 controlled `&Display,Zoom Selection` validation mode);
- `ExecutePluginCommand()`;
- selection/highlight mutation;
- PickTool push/pop;
- viewport mutation;
- model mutation;
- native command execution of any kind.

## Diagnostic modes

The executable is:

`C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe`

### 1. Installed-Interop reflection

No running Cimatron is required.

From the repository root:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --reflect
```

This scans installed `interop.Cim*.dll` assemblies using reflection-only loading and records public **interface members** whose names contain:

- `Zoom`
- `Fit`
- `View`
- `Frame`
- `Camera`

The complete result is written under:

`artifacts\diagnostics\zoom-interop-reflection-<timestamp>.txt`

The file is evidence of the installed 2026 Interop surface. It does not select a production implementation route.

### 2. Full native command-pool inventory — Part

Run Cimatron with a **Part** active, then from the repository root:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --commands --expect Part
```

The complete command inventory is written to:

`artifacts\diagnostics\zoom-command-pool-part-<timestamp>.txt`

### 3. Full native command-pool inventory — Assembly

Run Cimatron with an **Assembly** active, then:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --commands --expect Assembly
```

The complete command inventory is written to:

`artifacts\diagnostics\zoom-command-pool-assembly-<timestamp>.txt`

Each live dump records:

- tool version;
- timestamp;
- Cimatron product/version;
- active Cimatron document type/context;
- complete `CategoryName,CommandName` list.

The console prints only likely candidates for convenience. Candidate filtering is **not** the evidence set; the complete file is.

Command IDs are not queried in 0.15.7. They may be added only if a documented read-only API is identified and separately approved.


### 4. Controlled Zoom Selection validation — Part/Assembly active-model entity

This separately approved Step 05C2 mode temporarily selects one explicit active-model entity, executes exactly `&Display,Zoom Selection`, and restores the previous selection. It is not production Zoom-to-result behavior.

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --validate-zoom-selection --expect Part --entity-id <id>
```

The Part path was live-validated in 0.15.9. Assembly occurrence/entity addressing remains separate.

### 5. Read-only Assembly entity inventory

With an Assembly active:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --assembly-entities
```

This mode enumerates up to 40 candidate Body/Face IDs reachable through Part instances in the active Assembly and prints/records:

- instance path;
- instance ID;
- model title;
- model PID;
- entity type;
- entity ID.

It is strictly read-only: no command execution, selection/highlight mutation, PickTool use, model mutation, or viewport mutation.

Starting with 0.15.14, this mode also writes timestamped `CHECKPOINT NN` lines immediately before and after the already-approved COM calls and flushes each line to stdout. These checkpoints are diagnostic-only and are intended to identify the last completed call if the standalone probe blocks. They do not add any new Cimatron API call or state mutation.

Evidence is written under `artifacts\diagnostics\zoom-assembly-entity-inventory-<timestamp>.txt` when enumeration completes. Starting with 0.15.16, startup/dispatch/checkpoint evidence is also written independently of stdout to:

`%LOCALAPPDATA%\CimatronCustomization\diagnostics\zoom-discovery-YYYYMMDD-HHmmssfff-pidNNNN.log`

Each trace record is append-written with `FileOptions.WriteThrough`, explicitly `Flush(true)`'d, and the file is closed before execution continues. The header records PID, full command line, elevation state, and the current thread COM apartment state. A background heartbeat writes every 3 seconds with the last persisted checkpoint. The existing `[STAThread]` on `Main` is preserved and is not changed by this diagnostic increment.

Use `--trace-selftest` first. It exercises managed `Main` entry, dispatch, durable writes, and normal exit without calling any Cimatron API. If the trace file does not contain `Main entered`, inspect Task Manager and Event Viewer → Windows Logs → Application for SideBySide, .NET Runtime, Application Error, and Windows Error Reporting evidence, and record the exact launch command/redirection and the elevation state of PowerShell and Cimatron.

## 0.15.17 attach-only apartment diagnostic

0.15.16 workstation evidence localizes the standalone Assembly diagnostic block to the parameterless `AppAccess.GetApplication()` call: `AppAccess` construction completed, `CHECKPOINT 02` was persisted, and the heartbeat continued for more than one minute without an after-call checkpoint.

Repository comparison for the discovery tool versus the user-supplied known-good `Cr11RuntimeProbe`:

| Attribute | Known-good probe (user-supplied evidence) | Discovery tool |
| --- | --- | --- |
| Thread apartment | MTA / no `[STAThread]` | Main is STA; 0.15.17 attach worker can be STA or MTA |
| Manifest | Cimatron template, embedded | embedded `app.manifest` |
| Output location | Cimatron Program folder | Cimatron Program folder |
| Target/platform | .NET Framework 4.8 / x64 | .NET Framework 4.8 / x64 |
| Invocation | Ctrl+F5 from elevated Visual Studio | PowerShell/elevated in latest evidence |
| `GetApplication` call | parameterless | parameterless |

The known-good probe source is not part of this package, so its row is explicitly user-supplied runtime evidence rather than repository-derived evidence.

Run only after confirming Cimatron has no open modal dialog, no command in progress, one intended Cimatron instance, and the tool/Cimatron privilege levels match:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --attach-only --apartment=STA
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --attach-only --apartment=MTA
```

Each run records the reflected parameterless `GetApplication()` signature, Cimatron process count/PID/Windows Session ID, requested/observed worker apartment, and pre/post attach checkpoints. A controller waits 30 seconds. If the worker remains blocked in unmanaged COM, the controller records `ATTACH TIMEOUT`, returns exit code `5`, and does not force-abort the worker. The worker is background-only so it is not intended to keep the diagnostic process alive after the controller returns; workstation behavior is still subject to validation.

`Invoke-And-Capture.ps1 -Task trace-selftest` is also supported in 0.15.17, correcting the missed 0.15.16 launcher condition.

## 0.15.18 elevation/precondition hardening

0.15.17 workstation evidence resolved the attach hang. `CimatronE.exe` was running non-elevated, while the failing Discovery STA/MTA tests were launched from Administrator PowerShell. Both elevated runs timed out at `GetApplication()` with exit code 5. In the same live Cimatron session, a normal non-elevated PowerShell successfully ran `Cr11RuntimeProbe.exe` (active document `cmAssembly`) and then successfully ran Discovery `--attach-only --apartment=MTA` with exit code 0. This is the verified reason for the observed timeout; apartment state alone is not the cause.

The 0.15.17 process inventory was also invalid: broad matching found `CimatronCustomization.ZoomCommandDiscovery` rather than the actual host. 0.15.18 inventories only exact `CimatronE.exe` processes, records PID, Windows Session ID, elevation, and whether the target shares the tool session. If a Cimatron/tool elevation mismatch is confirmed, attach-only exits **before** `GetApplication()` with exit code `6` and instructs the operator to launch the diagnostic at the same elevation level as Cimatron. No-elevation/unknown evidence is recorded without fabricating a mismatch.

The previous reflection miss was also diagnostic-only: COM methods may be declared on inherited interfaces. 0.15.18 searches the AppAccess type and all interfaces returned by `GetInterfaces()` before reporting the parameterless `GetApplication()` signature absent.

Operational rule for standalone diagnostics: **run the diagnostic at the same elevation level as the already-running `CimatronE.exe` process.** Do not elevate the shell merely because the executable resides in the Cimatron Program folder; build/deployment may require elevation, but attach execution must match the target Cimatron process.

## Exit codes

- `0` — success;
- `1` — unexpected/usage/reflection failure;
- `2` — Cimatron unavailable/not running;
- `3` — standalone attach / side-by-side manifest / COM activation failure;
- `4` — Cimatron API enumeration or requested Part/Assembly context failure;
- `5` — attach-only observation timeout;
- `6` — confirmed elevation mismatch between the diagnostic process and `CimatronE.exe` (attach is not attempted).

## Architecture / packaging boundary

`CimatronCustomization.ZoomCommandDiscovery` lives under `tools/` only. Production projects must not reference it. Architecture tests enforce its read-only source boundary and the removal of the obsolete 0.15.6 test-executable discovery hook.

The tool is an internal engineering diagnostic and must not be included in a production/client release deliverable.

## Decision boundary

After the user supplies:

1. the Interop reflection findings file;
2. the Part command-pool file;
3. the Assembly command-pool file;

review the evidence and obtain explicit user approval for the Step 05C implementation route. Do **not** automatically prefer the Interop/view route or the native-command route.

## Current status

0.15.18 elevation/precondition hardening is user-validated: quality gate PASS, matching-elevation non-admin MTA attach PASS / exit 0, and deliberate elevation mismatch fail-fast / exit 6. Step 05C2-A 0.15.19 now prepares reflection-only installed-Interop Assembly API surface evidence; no Assembly traversal implementation has been approved yet. Production Assembly Pick and production Zoom-to-result remain unchanged.


## 0.15.20 Step 05C2-A CA1859 warning cleanup

The user-run 0.15.19 quality gate passed all required build/test/coverage gates but emitted one CA1859 analyzer warning in `EnumerateDeclaredMembers`. 0.15.20 changes only that helper return type to `MemberInfo[]`, matching `Type.GetMembers(...)`; the reflection-only inventory behavior is otherwise unchanged. Run the quality gate again and require 0 warnings / 0 errors before executing `--reflect-assembly-api`.

## 0.15.19 Step 05C2-A installed-Interop Assembly API surface inventory

Before any new Assembly traversal implementation, run the dedicated installed-Interop inventory:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --reflect-assembly-api
```

This mode uses reflection-only loading of the installed `interop.Cim*.dll` assemblies. It does **not** attach to Cimatron and makes no Cimatron runtime call. It records installed assembly versions, matching interface names, inherited/base interfaces, declaring interfaces, member kinds, and exact reflected signatures for candidate Assembly/occurrence/model/entity/transform/attribute/visibility/document-state APIs.

The output is evidence for preparing the Step 05C2-B allow-list only. A reflected member being present does **not** prove that invoking it is read-only. Each proposed runtime call must later state the evidence basis for its safety; any member with unverified side effects is excluded or separately tested before traversal approval.

0.15.18 workstation validation is now complete: the quality gate passed with 0 warnings / 0 errors, non-elevated MTA attach passed with exit 0, and the deliberate elevated-shell/non-elevated-Cimatron mismatch failed immediately with exit 6 rather than entering the prior 30-second COM wait.
