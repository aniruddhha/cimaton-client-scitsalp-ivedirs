# Cimatron 2026 API Capability Verification Register

## Scope

Phase 02 Step 07 records installed-Interop and known-answer runtime evidence for selected Cimatron 2026 SP2P1 API surfaces. Step 07D finalizes the evidence-backed status register and the eligibility gate for Step 08. This register does not itself promote any capability into production. Every live Step 07 result is out-of-process only and requires in-process confirmation before any production port or first CR slice may use it.

## Status rule

Runtime status remains `NOT VERIFIED — AWAITING USER EXECUTION` until the corresponding 07C evidence is supplied. The `Verified signature` column may be populated from the user-supplied 07A reflection evidence. Allowed evidence-backed states are `VERIFIED`, `PARTIALLY VERIFIED`, `DOC-MISMATCH`, `BLOCKED`, `NOT AVAILABLE`, and `NOT TESTED`.

| Item | Status | Verified signature | Known-answer result | Context | CR consumers | Step 08 recommendation |
|---|---|---|---|---|---|---|
| U1 — `IGeomServices.BodiesVolume` / `BodiesCenter` / `BodiesSurfArea` | VERIFIED / IN-PROCESS VERIFIED | 07A PRESENT — `interop.CimMdlrAPI.IGeomServices`; Double/Object returns recorded | Step 07 values matched the locked B1/B2 baseline; final Step 08A live Plugin run also matched Volume `227576.68583480848`, Center `[50.000000000000007,30.000000000000004,20.000000000000032]`, Surface Area `26684.937182392918`, with no-mutation PASS | Part; out-of-process + registered Plugin in-process verified | CR-22 | STEP 08A CLOSED / USER VALIDATED — eligible for later CR-specific production use subject to normal CR approval and port boundaries |
| U2 — `IGeomServices.GetBoundingBoxByUCS` | PARTIALLY VERIFIED | 07A PRESENT — `Object GetBoundingBoxByUCS(ICimEntityList, IUcs)` | 0.20.9 live candidate comparison mapped UCS 251 to the +30° Z frame: B1 faces `[0,-50,0,116.602540378444,51.9615242270663,40]` versus reference UCS 2 `[0,0,0,100,60,40]`; face 90 likewise rotated. Body-list input still returns `[1,1,1,0,0,0]`, so consumers should use supported face/entity-list semantics. | Part; out-of-process only | CR-01, CR-25, CR-26 | NOT ELIGIBLE — PARTIALLY VERIFIED; resolve the unsupported/unresolved body-list consumer shape before reconsideration |
| U3 — `IGeomServices.MinDistancePos` | VERIFIED | 07A PRESENT — `Double MinDistancePos(ICimEntity, ICimEntity, out IPointData, out IPointData)` | B1↔B2 returned `25 mm`; closest points `100,50,40` and `125,50,40` | Part / Assembly; out-of-process only | CR-03, CR-08, CR-19, CR-20, CR-05 if extended | ELIGIBLE — VERIFIED; may enter Step 08 in-process confirmation |
| U4 — `IGeomServices.GetPiercingPoints` | VERIFIED | 07A PRESENT — `Object GetPiercingPoints(Object iDirection, Object iBasePositin, ICimEntityList)` | Final 0.20.13 live run: `(-1,0,0)` from `(150,30,20)` hit face 90 at `(100,30,20)`; same direction from `(150,70,20)` returned `null` (bounded-face miss); `(+1,0,0)` from `(150,30,20)` returned `null` (one-way ray, not infinite line); `(-2,0,0)` returned the same `(100,30,20)` intersection (direction magnitude did not change this known-answer result). Return shape is `Object[]` containing `Double[]` points for hits and `null` for misses. | Part; out-of-process only | CR-10, CR-16, CR-19 | ELIGIBLE — VERIFIED; may enter Step 08 in-process confirmation |
| U5 — `IGeomServices.GetEdgeConvexity` | VERIFIED | 07A PRESENT — returns `EdgeConvexityType` | edge 89 returned `cmConvex`; edge 95 returned `cmConcave`, both at parameter `0.5` | Part; out-of-process only | CR-02, CR-16 | ELIGIBLE — VERIFIED; may enter Step 08 in-process confirmation |
| U6 — `IGeomServices.GetEntityPointDistance` | VERIFIED | 07A PRESENT — `Double GetEntityPointDistance(ICimEntity, Object, out IPointData)` | 0.20.9 face 90: `(110,30,20)` -> `10 mm`, closest `(100,30,20)`; `(110,70,20)` -> `14.142135623730951 mm`, closest `(100,60,20)`, confirming bounded-face distance behavior. | Part; out-of-process only | Geometry consumers | ELIGIBLE — VERIFIED; may enter Step 08 in-process confirmation |
| U7 — `IAssemblyModel.GetAssemblyEntity` | VERIFIED / IN-PROCESS VERIFIED | 07A PRESENT — `ICimEntity GetAssemblyEntity(ICimEntity, AssInstance)` | Step 07 resolved B1 body ID 4 for nested/top-level occurrences; final Step 08B live Plugin rerun mapped the nested `KA-PART-1` body ID 4 into active Assembly context as `cmBody` | Assembly / nested; out-of-process + registered Plugin in-process verified | Assembly-level finding highlight | STEP 08B CLOSED / USER VALIDATED — eligible for later CR-specific production use subject to normal CR approval |
| U8 — `IAssemblyModel.GetInstancesByModel` / `IAssInstance.SubInstances` | VERIFIED / IN-PROCESS VERIFIED | 07A PRESENT — both installed; `SubInstances[int,int]` returns `Object` | Step 07 found three `KA-PART-1` occurrences total; final Step 08B live Plugin rerun reproduced 3 total, 2 top-level via `GetInstancesByModel`, 1 nested via recursive `SubInstances`; runtime IDs are evidence only | Assembly / nested; out-of-process + registered Plugin in-process verified | Assembly context | STEP 08B CLOSED / USER VALIDATED — eligible for later CR-specific production use subject to normal CR approval |
| U9 — `IAssemblyModel.InstanceByAssemblyEnt` | VERIFIED | 07A PRESENT — PROPERTY_GET | 0.20.17 reverse lookup matched origin IDs for all three targets: 6→6, 12→12, 13→13 | Assembly; out-of-process only | Assembly context | ELIGIBLE — VERIFIED; may enter Step 08 in-process confirmation |
| U10 — `IAssInstance.Lock` getter | VERIFIED | 07A PRESENT — `Int32 Lock` get/set; runtime probe getter-only | 0.20.17 getter read completed across the known-answer traversal and returned both locked/unlocked states without mutation | Assembly; out-of-process only | SA-14 feasibility | ELIGIBLE — VERIFIED; may enter Step 08 in-process confirmation |
| U11 — `IGeomServices.GetAssemblyBoundingBox` | PARTIALLY VERIFIED | 07A PRESENT — `Object GetAssemblyBoundingBox(IModel, IUcs)` | 0.20.17 active-UCS call returned `[-719.026050257381,-205.648390630546,-66.2097628198915,457.159126216771,322.749576652967,188.731287236117]`; UI overall assembly extents were unavailable, so absolute known-answer comparison is unresolved | Assembly; out-of-process only | CR-01, CR-25, CR-26 | NOT ELIGIBLE — PARTIALLY VERIFIED; obtain missing independent numeric confirmation before Step 08 production use |
| U12 — nested assembly-context temporary highlight | VERIFIED / IN-PROCESS VERIFIED | 07A confirms `ISelection.Selection` get/set; existing Step 05A precedent | Step 07 user-validated temporary highlighting; final Step 08B used the actual production Result Report `Highlight` path for the nested `KA-PART-1` reference, user visually confirmed the intended nested body, then confirmed highlight restoration and unmodified Assembly state | Assembly / nested; out-of-process + registered Plugin production-highlight path verified | All assembly-level findings | STEP 08B CLOSED / USER VALIDATED — production nested-highlight path in-process verified for approved scope |
| U13 — body/entity attribute read path | VERIFIED / IN-PROCESS VERIFIED | 07A PRESENT; Step 07 setup/read evidence; `IAssInstance.GetAllEntities()` remains installed-Interop + live-evidence only, not found in authoritative SDK index | Final Step 08B live Plugin rerun resolved nested `KA-PART-1` body ID 4 exactly once as `cmBody` and exact named lookup `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` returned `KNOWN_ANSWER_07C3`; returned `IAttribute.Name` remains evidence-only | Nested Part entity in Assembly context; out-of-process + registered Plugin in-process verified | CR-04, CR-22, CR-26, CR-03 support, CR-08 | STEP 08B CLOSED / USER VALIDATED — eligible for later CR-specific production use subject to normal CR approval |
| U14 — instance attribute getter | NOT AVAILABLE | 07A: `IAssInstance.Attribute` SET-ONLY in installed Interop; do not invoke getter | N/A until signature confirmed | Assembly; out-of-process only | Component-property source | NOT ELIGIBLE — NOT AVAILABLE; obtain authoritative readable API evidence before reconsideration |
| U15 — `IBOM.Export` `cmNoFiltering` / `cmVisibleOnly` | VERIFIED / IN-PROCESS VERIFIED FOR `cmNoFiltering` MATERIAL READ | 07A PRESENT — installed seven-parameter `IBOM.Export`; `cmNoFiltering=0`, `cmVisibleOnly=1` | Step 07 exported both filters; final Step 08B live Plugin rerun verified the approved `cmNoFiltering` material route through existing `ITabularDataReader`: exactly one target `Standard Number=KA-PART-1` row with `Material=1.2738`; unrelated blank Material rows are allowed, target-row Material remains mandatory. `cmVisibleOnly` visibility semantics were not newly confirmed in-process by Step 08B. | Assembly; out-of-process + registered Plugin in-process verified for `cmNoFiltering` material read | CR-04, CR-22, CR-26; FR-021 candidate | STEP 08B CLOSED / USER VALIDATED for `cmNoFiltering` material read; `cmVisibleOnly` visibility-filter in-process confirmation remains separate |
| U16 — `ICimEntity.Show` getter on assembly-context bodies | VERIFIED — BODY/ENTITY VISIBILITY VIA `Show`; OCCURRENCE-HIDDEN VIA `cmVisibleOnly` BOM MEMBERSHIP | 07A PRESENT — `Int32 Show` getter/setter; 07C-4 invokes getter only | Final 0.20.26 live evidence: within visible unsuppressed `Visible_Component_With_Hidden_Body`, visible bodies returned `Show.GET=1` and the hidden body returned `0`; hidden-not-suppressed `Known_Pocket_Body` returned `Show.GET=1`, proving `Show` is not occurrence visibility. `cmNoFiltering` included `Known_Pocket_Body`, `cmVisibleOnly` excluded it, and the visible occurrence containing the hidden body remained present. | Assembly; out-of-process only | CR-11 FR-021 | ELIGIBLE — VERIFIED; may enter Step 08 in-process confirmation; use `Show` only for body/entity visibility and BOM visibility filtering for hidden occurrence detection |
| U17 — model/Part material-property getter | NOT AVAILABLE FROM RETAINED 07A EVIDENCE | 0.20.17 handoff retains no evidence-backed readable getter on `IModel`, `IMdlrModel` or document for the observed Part material property; no new reflection run is approved | No speculative getter call; BOM path is tested separately under U15 | Evidence-only in 07C-3 | CR-04, CR-22, CR-26 | NOT ELIGIBLE — NOT AVAILABLE; revisit only with authoritative Cimatron/SDK evidence |

## 07D final verification register and Step 08 eligibility gate — 0.20.28

Step 07D applies the project rule that **only capabilities whose final Step 07 status is `VERIFIED` are eligible to enter Step 08 in-process confirmation and later production-port / first-CR-slice consideration**. Eligibility is not production promotion: Step 08 must still confirm the capability inside the real registered Cimatron Plugin process before production use.

### Step 08 eligibility whitelist

The following items are evidence-backed `VERIFIED` and are therefore eligible for Step 08 in-process confirmation:

- **U1** — `BodiesVolume` / `BodiesCenter` / `BodiesSurfArea`
- **U3** — `MinDistancePos`
- **U4** — `GetPiercingPoints`
- **U5** — `GetEdgeConvexity`
- **U6** — `GetEntityPointDistance`
- **U7** — `GetAssemblyEntity`
- **U8** — `GetInstancesByModel` / `SubInstances`
- **U9** — `InstanceByAssemblyEnt`
- **U10** — `IAssInstance.Lock` getter
- **U12** — nested assembly-context temporary highlight
- **U13** — body/entity attribute read path
- **U15** — `IBOM.Export` with `cmNoFiltering` / `cmVisibleOnly`
- **U16** — body/entity visibility via `ICimEntity.Show`; hidden occurrence detection via `cmVisibleOnly` BOM membership

### Excluded from Step 08 promotion eligibility

- **U2 — PARTIALLY VERIFIED.** Rotated face/entity-list `GetBoundingBoxByUCS` semantics are evidenced, but body-list input remains unresolved/unsupported for the intended consumer shape. It must not be used by a production port or first CR slice until the missing contract/usage decision is resolved and the capability reaches `VERIFIED`.
- **U11 — PARTIALLY VERIFIED.** `GetAssemblyBoundingBox` returned a six-value runtime box, but no independent UI overall-assembly extent was available for absolute known-answer comparison. It must not be used by a production port or first CR slice until independently confirmed and promoted to `VERIFIED`.
- **U14 — NOT AVAILABLE.** Retained installed-Interop evidence exposes `IAssInstance.Attribute` as SET-ONLY; no evidence-backed getter exists. No speculative production use is allowed.
- **U17 — NOT AVAILABLE FROM RETAINED 07A EVIDENCE.** No evidence-backed readable model/Part material getter is established. The verified BOM/material route under U15 remains the available evidence-backed path where applicable.

No Step 07 item is assigned `DOC-MISMATCH` or `BLOCKED` merely to fill a status category; those states are used only when supported by evidence. The final Step 07 statuses above are the authoritative promotion gate.

### Carry-forward

`ST06-DF-01` through `ST06-DF-06` remain **DEFERRED** exactly as recorded in `STEP-06-DEFERRED-FINDINGS.md`. Step 07D does not resolve, accept, or supersede any of them. Their owning CR/release-hardening steps must continue to carry them forward.

## Step 08A U1 in-process closure — 0.21.4

User workstation evidence completed the Step 08A gate. `quality-gate-20261001-023742.txt` is clean (Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gates PASS, exit code 0). The final registered-Plugin run against `KA-PART-1` matched the locked Step 07 Volume, Center and Surface Area values and preserved no-mutation evidence.

The retained diagnostic history includes an earlier zero-value observation and the later successful governed rerun of the same production diagnostic runtime. The project does not infer a root cause that the evidence does not prove. No runtime correction is introduced by the 0.21.4 closure package.

**Decision:** U1 is now `IN-PROCESS VERIFIED` for the approved Part-context scope. Step 08A is `CLOSED / USER VALIDATED`. This does not itself implement CR-22 or any other CR; later CR work still requires its own approved scope.

## Step 08B — U13/U15/U8/U7/U12 in-process preparation — 0.22.0

Step 08B is approved as an Assembly-context foundation diagnostic only. It does not change the Step 07 verification statuses yet; U7/U8/U12/U13/U15 remain out-of-process VERIFIED until the governed 0.22.0 live run succeeds and is reviewed.

- **U8 locked structure:** `KA-ASM-1` must expose 3 `KA-PART-1` occurrences total, 2 top-level via `GetInstancesByModel`, and 1 nested via recursive `SubInstances`. Runtime instance IDs are evidence only.
- **U13 locked nested body/attribute:** nested `KA-PART-1` body ID 4 must occur exactly once as `cmBody`; exact named `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` must return `KNOWN_ANSWER_07C3`. Returned `IAttribute.Name` is non-authoritative evidence only. `IAssInstance.GetAllEntities()` was not found in the authoritative Cimatron SDK documentation index and is therefore recorded as installed-Interop + governed runtime evidence only.
- **U7:** map the nested occurrence-owned body into the active Assembly with documented `IAssemblyModel.GetAssemblyEntity`.
- **U12:** verify through the real production Result Report Highlight path. The Step 08B finding carries the nested occurrence reference; `CimatronViewportEntityHighlighter` resolves and maps it into Assembly context before assigning the existing verified `ISelection.Selection`. Feature execution itself shows no UI and does not pause.
- **U15 locked BOM contract:** `cmNoFiltering` export; locked Step 07 header includes `No., Qty., Standard Number, Sub Category, Category, Visible Part Size, Material`; parse through existing `ITabularDataReader`; identify the known row by `Standard Number=KA-PART-1`; expected `Material=1.2738`. Visibility/row-set interpretation remains out of scope.
- **BOM error semantics:** `GetBomManager()`/export COM failure is recorded as `READ_ERROR` / Error and does not count as U15 confirmation. No retry/alternate API is authorized in the governed run.
- **No-mutation / temp:** document modified-state and saved file timestamp/length are programmatic guards; BOM additionally protects the model-folder listing. Export is restricted to `%TEMP%/CimatronCustomization/Step08B/<timestamp>/`; cleanup failure is Warning.
- **DF-05:** developer-visible diagnostic; gate/remove before D5 client packaging.
- **Stopping rule:** clean quality gate first, then exactly one `KA-ASM-1` feature execution and one Result Report Highlight action. Stop on any failure/error/read error/wrong highlight/no-mutation issue.

**Status:** IMPLEMENTATION PREPARED / AWAITING USER QUALITY GATE AND SINGLE GOVERNED LIVE RUN. No U7/U8/U12/U13/U15 in-process promotion is claimed by 0.22.0.


### Step 08B closure — 0.22.2

User workstation evidence closes the approved Step 08B Assembly-context foundation scope.

- `quality-gate-20261002-131500.txt`: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local gates PASS, exit code 0.
- Final governed `KA-ASM-1` live rerun: all nine Step 08B findings PASS.
- **U8:** 3 `KA-PART-1` occurrences total, 2 top-level via `GetInstancesByModel`, 1 nested via recursive `SubInstances`.
- **U13:** nested body ID 4 matched exactly once as `cmBody`; exact named `cmAttString` lookup returned `KNOWN_ANSWER_07C3`. `IAssInstance.GetAllEntities()` remains installed-Interop + governed runtime evidence only and is not represented as officially documented.
- **U7:** `GetAssemblyEntity` mapped the nested Part body into active Assembly context as `cmBody`.
- **U12:** the normal production Result Report `Highlight` action visibly highlighted the intended nested `KA-PART-1` body. The user then confirmed highlight restoration after closing and that `KA-ASM-1` remained unmodified.
- **U15:** `cmNoFiltering` BOM export/readback completed; the locked target key was `Standard Number=KA-PART-1`, matching rows = 1, `Material` column present, and `Material=1.2738`. This is the only U15 scope promoted in-process by Step 08B; `cmVisibleOnly` visibility semantics are not newly promoted here.
- Programmatic no-mutation evidence (document modified state, model file timestamp/length, model-folder listing) PASS.
- Governed Step08B temp run-directory cleanup PASS.
- Earlier 0.22.0 `TABULAR_REQUIRED_VALUE_MISSING` evidence and the approved 0.22.1 target-row corrective remain retained for audit traceability.

**Status:** **STEP 08B CLOSED / USER VALIDATED. U7, U8, U12, U13 and U15 (`cmNoFiltering` material-read scope) are IN-PROCESS VERIFIED for the approved scope.**

No CR-04 business logic is implemented by this closure. DF-05 remains active for the developer-visible diagnostic before D5 client packaging.

### Step 08B first live-run evidence and 0.22.1 corrective

User workstation `quality-gate-20261002-124744.txt` is clean: Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gate PASS, exit code 0. The first governed `KA-ASM-1` live run then produced:

- **U8:** PASS for the locked structure (3 `KA-PART-1` occurrences total, 2 top-level via `GetInstancesByModel`, 1 nested via `SubInstances`). This is valid in-process evidence, but formal Step 08B promotion remains pending closure.
- **U13:** PASS for nested body ID 4 exactly once as `cmBody` and exact named string attribute value `KNOWN_ANSWER_07C3`. This is valid in-process evidence, but formal Step 08B promotion remains pending closure.
- **U7:** PASS for `GetAssemblyEntity` mapping of the nested body into Assembly context. This is valid in-process evidence, but formal Step 08B promotion remains pending closure.
- **U12:** the production nested highlight reference was created successfully, but the Result Report Highlight action was **NOT EXECUTED** because U15 hit a stopping condition. U12 is therefore not yet in-process confirmed through the production highlight interaction.
- **U15:** `READ_ERROR TABULAR_REQUIRED_VALUE_MISSING` occurred because the Step 08B adapter required `Material` on every BOM row; the error occurred before target-row comparison. This does not prove absence or mismatch of `Material=1.2738` on `KA-PART-1`.
- **Safety:** programmatic no-mutation evidence PASS; Step08B temporary BOM run-directory cleanup PASS.

The separately approved 0.22.1 corrective keeps the validated `ITabularDataReader` and locked header, makes Material optional for unrelated rows, then requires non-blank Material specifically on target `Standard Number=KA-PART-1`. Missing target Material remains `READ_ERROR`. No alternate BOM API/filter/path is introduced.

**0.22.1 status:** CORRECTIVE PREPARED / AWAITING CLEAN QUALITY GATE. No new in-process promotion is claimed until the corrective gate and separately governed live rerun are reviewed.

### Production boundary

Step 07D is governance/documentation only. It changes no production `src/**`, Plugin behavior, configuration, installer, Cimatron model, diagnostic runtime, or CR/SA behavior.

## 07A documentation-conflict resolution

User evidence `api-capability-reflection-20260929-143432.txt` resolved the planned reflection questions:

- the Step 07 runtime implementation uses the installed `interop.CimMdlrAPI` surfaces; duplicate interface copies also exist in other Interop assemblies;
- `IAssInstance.Attribute` is SET-ONLY in the installed 2026 reflection evidence;
- `ICimEntity.Show` has a getter and setter; Step 07 may call the getter only;
- installed signatures for `MinDistancePos`, `GetPiercingPoints`, `GetBoundingBoxByUCS`, and `GetEntityPointDistance` are now recorded above;
- installed `IBOM.Export` is the seven-parameter signature observed by 07A.

07A reflection/signature discovery is complete. Runtime behavior remains subject to 07C.

## Safety state

No production port or adapter is created in Step 07. All live modes require no-mutation before/after evidence. Any `CHANGED_OR_UNVERIFIED` result fails that run. BOM output is permitted only under `%TEMP%\CimatronCustomization\Step07\<timestamp>\`.

## Step 06 deferred findings

`ST06-DF-01` through `ST06-DF-06` remain `DEFERRED` and are not changed or resolved by Step 07.

## 07C-1A known-answer target discovery — 0.20.3

A read-only pre-verification mode is added because the 0.20.2 `--verify-geometry` command consumes entity/UCS/edge IDs but does not establish them. Running verification with guessed IDs is prohibited.

Command:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --discover-geometry-targets --expect Part
```

The mode enumerates actual body/face/edge IDs, observes body metrics and pair distance, observes edge convexity at parameter `0.5`, and records active/runtime-discoverable UCS candidates. It records no-mutation evidence and does not modify the model. Semantic target selection remains a human/evidence mapping step; the diagnostic does not label an ID as B1/B2/test face/convex/concave/`KA_UCS_90Z` merely because of ordering.

Status remains **AWAITING USER EXECUTION**. Results from this discovery mode establish inputs for 07C-1; they do not by themselves promote U1-U6 to VERIFIED and do not authorize 07C-2.

## 07C-1A evidence received / 07C-1C selection inspection — 0.20.4

User workstation evidence closed the 0.20.3 implementation-validation prerequisite: `quality-gate-20260929-175613.txt` completed with exit code 0, and live discovery against standalone `KA-PART-1` completed with no-mutation evidence `UNCHANGED`.

The discovery recorded two bodies (IDs `4` and `5`), 25 mm minimum distance, face/edge enumerations, and active UCS entity ID `2` after the user explicitly activated `KA_UCS_90Z`. The user then visually confirmed B1/B2 roles and selected the intended test face. These facts establish targets but **do not promote U1-U6 to VERIFIED**; `--verify-geometry` has not yet been run against the complete known-answer argument set.

Version 0.20.4 adds:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --inspect-current-selection --expect Part
```

This mode reads `ISelection.Selection` only. It records current selected entity IDs/types and, for selected edges, read-only `GetEdgeConvexity(..., 0.5)` evidence. It does not assign/clear selection and does not infer semantic roles.

**Current gate:** capture the intended test-face ID, then one intended convex-edge ID and one intended concave-edge ID. 07C-2 remains blocked until 07C-1 is completed/approved.

## 07C-1D evidence received / 07C-1R resolution package — 0.20.6

User workstation `quality-gate-20260929-183753.txt` passed with exit code 0. Live 0.20.5 Geometry Services runs then established:

- B1/B2 body metrics matched the locked known-answer values;
- `MinDistancePos` returned the expected `25 mm`;
- edge 89 returned `cmConvex`; edge 95 returned `cmConcave`;
- every supplied geometry run recorded no-mutation evidence `UNCHANGED`;
- `GetBoundingBoxByUCS` returned `[1,1,1,0,0,0]` for the body list and `[0,0,0,100,60,40]` for the first-body face list under UCS ID 2.

The body-list value is **not** yet classified as an empty-box sentinel or documentation mismatch. Version 0.20.6 extends only the existing `--verify-geometry` mode so a controlled comparison can be made with B1 faces and face ID 90 under both an evidence-mapped main/reference UCS and `KA_UCS_90Z`.

`GetPiercingPoints` and `GetEntityPointDistance` were not exercised by the 0.20.5 commands. Their status is explicitly `NOT TESTED`, not silently folded into face verification. Known-answer ray and point inputs must be captured before interpreting those methods.

No 07C-2 work is authorized by 0.20.6.


## 07C-1R evidence alignment / session handoff — 0.20.8

User workstation 0.20.7 validation and live evidence establish the following:

- `quality-gate-20260929-190027.txt`: full local quality gate PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- `api-capability-geometry-known-answer-discovery-20260929-190407.txt`: Part/mm context; B1/B2 IDs 4/5 and known geometry unchanged; face 90 remains `cmFace`; edge 89 `cmConvex`; edge 95 `cmConcave`; UCS candidates 2 and 249; no mutation.
- `api-capability-geometry-20260929-191114.txt`: primary UCS 2 and reference candidate 249 both resolve. B1 face-list boxes are `[0,0,0,100,60,40]` in UCS 2 and `[-50,-60,0,50,0,40]` in UCS 249. Face 90 boxes are `[100,0,0,100,60,40]` and `[50,-60,0,50,0,40]`. Body-list boxes remain `[1,1,1,0,0,0]` in both frames.

### Interpretation corrections

1. **UCS 249 is not “Main UCS.”** It is retained only as a second/reference UCS candidate. The observed boxes show its axes parallel to UCS 2 and are consistent with a `(50,60,0)` translation. This evidence cannot distinguish a truly UCS-oriented bounding box from a world-axis box expressed in a translated parallel frame. Therefore U2 remains **PARTIALLY VERIFIED**, specifically for axis-parallel UCS frames only. A known-angle rotated UCS check is required before CR-01/CR-25 rely on orientation semantics.
2. **`SurfacesArea` is NOT AVAILABLE.** The installed Cimatron 2026 SP2P1 `IGeomServices` contract does not expose that member. It is not classified BLOCKED. Existing face-area evidence from the earlier topology reader and body surface-area evidence remain separate capabilities.
3. **`GetPiercingPoints` and `GetEntityPointDistance` remain NOT TESTED.** 0.20.7 correctly emitted explicit NOT_TESTED lines because the final known-answer ray/point inputs were not supplied in that run.

No 07C-2 work is authorized until 07C-1 is explicitly closed by the user.

## 0.20.9 — 07C-1R2 final-run preparation

The existing development-only `--verify-geometry` mode now accepts repeated ray-origin/direction pairs and repeated point arguments. When a guarded `--face-id` is supplied, `GetPiercingPoints` is executed against that face list rather than the all-body list; this makes the approved face-90 bounded-face and ray-vs-line checks meaningful. If no face ID is supplied, the prior all-body target behavior remains available.

The installed-contract absence of `IGeomServices.SurfacesArea` is emitted as `NOT_AVAILABLE`. This is a classification alignment only; no replacement API is invented.

Runtime capability statuses remain unchanged until the user supplies 0.20.9 live evidence. In particular, `GetPiercingPoints`, `GetEntityPointDistance`, and rotated-UCS `GetBoundingBoxByUCS` orientation semantics are still pending final evidence, and 07C-2 remains blocked.


## 0.20.10 — 07C-1R3 piercing-array corrective

The final 0.20.9 controlled run established the rotated-UCS and entity-point-distance evidence, but each approved `GetPiercingPoints` call returned a COM `object[]` that the diagnostic attempted to cast directly to `double[]`. Version 0.20.10 changes only that evidence conversion path and the stale diagnostic version label.

`GetPiercingPoints` remains `BLOCKED` until the user supplies a 0.20.10 rerun of the same three face-90 rays. No production promotion or 07C-2 work is authorized by this corrective.

## 0.20.11 — 07C-1R3 compile corrective

The user-run 0.20.10 quality gate exposed a compile-only CS0411 error at the `GetPiercingPoints` evidence observation call: `TryObserve<T>` could not infer `T` from the dynamic/COM expression. The approved 0.20.11 package specifies `double[]` explicitly.

This does not change the installed Cimatron API call, the object-array-to-double-array conversion, the guarded face-90 target, or any known-answer ray. `GetPiercingPoints` remains unresolved until the user obtains a clean quality gate and reruns the same three approved rays. 07C-2 remains blocked.
## 0.20.12 — 07C-1R4 piercing return-shape inspection

User workstation `quality-gate-20260930-003832.txt` validated the 0.20.11 compile corrective with Release x64 build PASS, 0 warnings / 0 errors, all governed tests PASS, coverage/local gates PASS, and exit code 0. The following live rerun `api-capability-geometry-20260930-004342.txt` reached all three approved face-90 `GetPiercingPoints` calls, but the development diagnostic then rejected at least one top-level return item as non-numeric.

Version 0.20.12 deliberately stops interpreting that return as a flat numeric array. It records the raw runtime type/value, then—when the return is an array—its array type/rank/length and every top-level item runtime type/value. The guarded face target, three approved rays, Cimatron API invocation, and read-only/no-mutation boundary remain unchanged.

`GetPiercingPoints` remains `BLOCKED` until the user supplies this return-shape evidence. No production promotion or 07C-2 work is authorized.



## 0.20.13 — 07C-1R5 final argument-order correction and stop rule

Before requesting another live run, the existing 07A reflection file and 0.20.12 piercing evidence were re-analysed together. Installed reflection gives the authoritative order:

```text
GetPiercingPoints(System.Object iDirection, System.Object iBasePositin, ICimEntityList iEntList)
```

The 0.20.12 diagnostic instead called `GetPiercingPoints(origin, direction, targets)`. Its three returned points are exactly consistent with that swapped reading:

- old case 1 actual base `(-1,0,0)`, direction `(150,30,20)` -> at X=100, `(100,20.2,13.4666666666667)`;
- old case 2 actual base `(-1,0,0)`, direction `(150,70,20)` -> `(100,47.1333333333333,13.4666666666667)`;
- old case 3 actual base `(1,0,0)`, direction `(150,30,20)` -> `(100,19.8,13.2)`.

All three intersections occur at positive line parameter `t`. Therefore the previously intended “miss” and “pointing away” scenarios were not actually those scenarios at the API boundary and do **not** resolve one-way-ray versus infinite-line behavior.

Version 0.20.13 maps `--ray-direction` to `iDirection` and `--ray-origin` to `iBasePositin`, and records both values in evidence. The one final 07C-1 runtime batch contains four piercing cases: `(150,30,20)/(-1,0,0)`, `(150,70,20)/(-1,0,0)`, `(150,30,20)/(+1,0,0)`, and `(150,30,20)/(-2,0,0)`. It also repeats the already-validated face-90 entity-point-distance cases and UCS 251/reference 2 rotated-UCS checks.

Per user instruction, no further 07C-1 runtime experiment is allowed after that final batch. Any remaining ambiguity is recorded as a known limitation with the evidence attached, and 07C-1 closes.


## 0.20.14 — 07C-1 closure

User workstation quality evidence `quality-gate-20260930-010629.txt` passed the governed local gate. The single final live run `api-capability-geometry-20260930-010854.txt` then completed under Cimatron 2026 SP2P1 with `ToolVersion: 0.20.13` and no-mutation evidence `UNCHANGED`.

Final evidence-backed 07C-1 conclusions:

- **U1 VERIFIED:** body volume/centre/surface-area results matched the locked known-answer geometry.
- **U2 PARTIALLY VERIFIED:** face/entity-list `GetBoundingBoxByUCS` is verified, including UCS 251 (+30° Z) versus reference UCS 2. Body-list input still returns `[1,1,1,0,0,0]`; this is a recorded limitation and consumers must not rely on body-list semantics.
- **U3 VERIFIED:** `MinDistancePos` returned the known 25 mm B1↔B2 gap and corresponding closest points.
- **U4 VERIFIED:** `GetPiercingPoints` uses installed argument order `(iDirection, iBasePositin, iEntList)`, behaves as a one-way ray for the known-answer face, respects the bounded face, returns `null` for the miss/pointing-away cases, and returned the same hit for direction magnitudes 1 and 2 in the tested direction.
- **U5 VERIFIED:** known convex and concave edges returned `cmConvex` and `cmConcave`.
- **U6 VERIFIED:** bounded-face `GetEntityPointDistance` returned the expected distances/closest points in the final run.
- **`SurfacesArea` NOT AVAILABLE:** the installed 2026 SP2P1 `IGeomServices` contract does not expose this member.

Per the user-approved stop rule, no further 07C-1 runtime experiment will be requested. Residual uncertainty is captured above as a limitation. **07C-1 is CLOSED.** This closure removes the prior procedural blocker on 07C-2; however, 07C-2 is **NOT STARTED** and still requires separate explicit user approval.
## 0.20.15 — 07C-2 Assembly Context verification preparation

The user approved 07C-2 with the known-answer expected values separated from the APIs under test. 07C-2A is therefore a user UI/Measure evidence step, not an API discovery run. The existing development-only `--verify-assembly-context` mode is corrected before the single live run so the run is not wasted on known diagnostic defects.

The 0.20.15 mode records guarded traversal state, local/root occurrence transformations, `GetInstancesByModel`, per-occurrence `GetAssemblyEntity`, explicit reverse `InstanceByAssemblyEnt` MATCH/MISMATCH, `IAssInstance.Lock`, assembly bounding box using an optional evidence-backed `--ucs-id`, and all matching-pair `MinDistancePos` values including both closest points. With `--highlight`, each matching assembly-context entity remains selected until the user presses Enter, after which the original selection is restored; an originally empty selection is restored to an empty list.

Example shape only — replace placeholders with the 07C-2A evidence-backed values:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-assembly-context --expect Assembly --model-title "<EXACT_MODEL_TITLE>" --entity-id <BODY_ENTITY_ID> --ucs-id <ASSEMBLY_UCS_ID> --highlight
```

If no independently mapped assembly UCS ID is available, omit `--ucs-id` and record which UCS is active in Cimatron before the run. U7-U12 remain **NOT VERIFIED — AWAITING USER EXECUTION** until the 0.20.15 quality gate and one live KA-ASM-1 evidence file are supplied. After that one run, unresolved semantics are limitations unless separately approved corrective work is necessary.



## 0.20.16 — 07C-2 compile corrective

The workstation quality gate `quality-gate-20260930-032936.txt` compiled the intended 0.20.15 source but failed before deployment/live validation with CS0411 at `AssemblyContextVerification.cs(214,21)` and `(218,21)`. The two matrix/vector observations now explicitly use `TryObserve<object>`. No API invocation, pair-selection, closest-point, highlight or restore semantics changed.

07C-2A manual UI known answers are complete. U7-U12 remain **NOT VERIFIED** until the 0.20.16 quality gate passes and the one approved live KA-ASM-1 run is returned. Earlier `ToolVersion: 0.20.13` assembly-context files are troubleshooting evidence only.

## 0.20.17 — 07C-2 architecture-guard alignment

The 0.20.16 workstation gate compiled successfully with 0 warnings / 0 errors but stopped at `ARCHITECTURE TESTS: FAIL`. The failure is a stale source-text guard: it required the old direct previous-selection assignment even though 0.20.15 intentionally moved restore behavior into `RestoreSelection(...)` so an originally empty selection is restored to an explicit empty entity list. 0.20.17 changes only that architecture guard; verifier runtime behavior is unchanged. U7-U12 remain **NOT VERIFIED** until the 0.20.17 quality gate passes and the one approved live KA-ASM-1 run is returned.

## 0.20.17 — 07C-2 closure / user validation

Workstation evidence `quality-gate-20260930-033812.txt` passed the governed quality gate with Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS and exit code 0. The single approved live run `api-capability-assembly-context-20260930-034145.txt` then executed with `ToolVersion: 0.20.17` against active `KA-ASM-1`.

The run found one nested and two top-level `KA-PART-1` occurrences. Local/root transformations were recorded, B1 assembly entities resolved for all three occurrences, every `InstanceByAssemblyEnt` reverse lookup matched the originating instance ID, `IAssInstance.Lock` was readable, the active assembly UCS resolved, and `GetAssemblyBoundingBox` returned a six-value box. The user visually confirmed all three paused highlights targeted the correct bodies, confirmed the final selection was empty, confirmed no unsaved-change indicator remained, and explicitly approved closure. File-level no-mutation evidence remained `UNCHANGED`.

`MinDistancePos` is a documented assembly-placement limitation in this context: every occurrence pair returned distance `0` with identical closest points despite different occurrence transforms and the independently measured top-level B1-to-B1 gap of `25.000 mm`. Per the approved stop rule, no additional 07C-2 probe is authorized or required. **07C-2 is CLOSED / USER VALIDATED.**

## 07C-3 component property / BOM preparation — 0.20.18

Approved 07C-3 scope is limited to U13, U14, U15 and the evidence-only U17 classification. Existing U16 remains reserved for separately approved 07C-4 hidden-state verification. The documented 07C-2 cross-occurrence `MinDistancePos` limitation is out of scope and is not reprobed.

Before the live run, create one deliberate custom manufacturing attribute on **B1 body entity 4** in disposable `KA-PART-1` using Cimatron UI. Record its exact name, type and value, save the Part, close/reopen or otherwise ensure the saved Part is reloaded through `KA-ASM-1`, and only then establish the no-mutation baseline. The existing Part/model material value `1.2738` is not proof of U13.

The 0.20.18 verifier requires the known-answer attribute name/value and material value as command arguments. It verifies that entity 4 resolves as `cmBody`, reads attributes on both the Part-model body and its assembly-context body, exports `cmNoFiltering` and `cmVisibleOnly` CSVs only under `%TEMP%\CimatronCustomization\Step07\<timestamp>`, and records CSV headers, row counts, material-column candidates, and material values only for rows matching the known-answer model title. It does **not** interpret row-count/row-membership differences between the two filters; that remains 07C-4 work.

The verifier also snapshots the model file (`IsModified`, timestamp, size) and its containing-folder file listing before/after. `CHANGED_OR_UNVERIFIED` in either guard fails the run and stops capability interpretation. Folder changes are reported as evidence and are not automatically labelled as model mutation without review.

U17 is evidence-only: the retained package does not contain evidence of a readable model/Part material getter, so the status is `NOT AVAILABLE FROM RETAINED 07A EVIDENCE`. No new reflection run or speculative API call is authorized.

One governed live run is the stopping rule. Any unresolved U13/U15 behavior after that run is recorded as a limitation unless a separate corrective is explicitly approved. Customer/Cimatron confirmation of which tagging mechanism designers actually use remains a requirements question separate from API capability proof.


## 07C-3 compile corrective — 0.20.19

User workstation quality gates `quality-gate-20260930-115502.txt` and `quality-gate-20260930-115729.txt` did not pass. The second capture exposed two `CS1061` compile errors in the 07C-3 verifier because `AttributeObservation` is an enum and two evidence lines referenced a nonexistent `.Status` property. Version 0.20.19 corrects only those two evidence expressions and advances verifier version metadata. U13/U14/U15/U17 capability states remain unchanged and unverified; no live 07C-3 evidence is accepted until the 0.20.19 quality gate passes. Separate access-denied deployment errors observed in the same capture remain a workstation/environment issue and are not treated as capability evidence.


## 07C-3 occurrence-entity / named-attribute corrective — 0.20.23

The 0.20.22 workstation quality gate passed. The controlled setup then succeeded on `KA-PART-1` body entity 4 and the user manually saved/reopened `KA-ASM-1`. The first governed read-only 07C-3 run nevertheless stopped before U13 because `instance.Model.GetEntityById(4, partModel)` returned Cimatron COM error `0x80040207`. This does not prove the body is absent. A separate read-only occurrence diagnostic immediately afterwards proved the loaded `KA-PART-1` occurrences expose `cmBody` entity 4 through `IAssInstance.GetAllEntities()` and recorded no mutation.

0.20.23 replaces only that failed body-resolution route inside `--verify-component-properties` with the already runtime-proven occurrence entity list. The requested ID must occur exactly once as `cmBody`; missing, duplicate or wrong-type matches fail closed. The verifier still records `GetAttributes()` enumeration, then confirms the known attribute with exact `GetAttribute(cmAttString, requestedName)`. Because the setup proof showed Cimatron returns blank `IAttribute.Name` after a successful named lookup, U13 matching is based on non-null + exact `cmAttString` type + exact value; returned name remains logged evidence only.

Architecture guards prevent regression to `partModel.GetEntityById(...)` or the returned-name equality check. Assembly-context conversion, BOM export to `%TEMP%`, no-mutation evidence, U14/U17 statuses, and the 07C-4 boundary are unchanged. U13/U15 remain **NOT VERIFIED** until the single governed 0.20.23 live rerun succeeds and its evidence is reviewed.


## 07C-3 closure — 0.20.24

User workstation quality gate `quality-gate-20260930-133008.txt` passed with Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local gates PASS, and exit code 0. The final governed live evidence `api-capability-component-properties-20260930-133403.txt` then completed against active `KA-ASM-1` using known-answer model `KA-PART-1`, body ID `4`, diagnostic attribute `STEP07_B1_TEST_ATTRIBUTE=KNOWN_ANSWER_07C3`, and material `1.2738`.

U13 is VERIFIED. `IAssInstance.GetAllEntities()` returned six entities and matched index 3 as body ID 4 / `cmBody`. `GetAttributes()` exposed four attributes on both Part-model and assembly-context entities, including the expected string value. Exact named lookup `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` was PRESENT on both entities with `cmAttString` and `KNOWN_ANSWER_07C3`. Cimatron returned blank `IAttribute.Name`; because the exact name is already supplied to the successful lookup, the returned name remains non-authoritative evidence only.

U15 is VERIFIED for the approved 07C-3 scope. Both `cmNoFiltering` and `cmVisibleOnly` BOM exports succeeded to the governed temp folder. The CSV header included `Material`; each export contained one known-answer `KA-PART-1` row with `Material=1.2738`. The observed row counts were 5 and 4 respectively, but 07C-3 intentionally performs no visibility-difference interpretation; that remains reserved for 07C-4.

U14 remains NOT AVAILABLE from retained 07A evidence because `IAssInstance.Attribute` is SET-ONLY. U17 remains NOT AVAILABLE FROM RETAINED 07A EVIDENCE; no new reflection or speculative getter call was performed. U16/hidden-state interpretation remains out of scope and untouched. File-level and model-folder no-mutation evidence were both UNCHANGED. **07C-3 is CLOSED / USER VALIDATED.**

## 07C-4 U16 hidden / visibility-state verification preparation — 0.20.25

Step 07C-4 is explicitly approved. The finalized copy model `KA-ASM-1-U16-HiddenBody-Control` contains four controlled states: a normal visible occurrence/body, hidden-not-suppressed `Known_Pocket_Body`, visible-not-suppressed `Visible_Component_With_Hidden_Body` containing one hidden body plus one visible anchor body, and suppressed `Block_B`. The original approved baseline remains preserved.

The development-only `--verify-hidden-state-candidates` mode is prepared for one governed run. It reads `IAssInstance.IsSuppressed`, enumerates occurrence-reached bodies through `IAssInstance.GetAllEntities()`, maps each body to assembly context, and reads only `ICimEntity.Show` getter. Retained 07A reflection evidence already establishes `Int32 Show` getter/setter; no `Show` setter is called.

The same run exports `IBOM.Export` with `cmNoFiltering` and `cmVisibleOnly` to the governed temporary Step07 folder and records all CSV data rows plus exact row-set differences. This makes BOM filtering an explicit candidate read-only route for FR-021 rather than background evidence.

The verifier deliberately does not classify semantics. After the user supplies the single-run evidence, U16 must state separately whether `Show` reflects occurrence-hidden state, body-hidden state, both, or neither; only occurrence-hidden discrimination supports the per-occurrence FR-021 need. The BOM route must also be classified separately by whether the known hidden occurrence is distinguishable under `cmVisibleOnly`. If neither route discriminates the known hidden occurrence, the stopping rule leaves FR-021 hidden-state support blocked pending Cimatron guidance.

Status: **AWAITING USER 0.20.25 WORKSTATION QUALITY GATE + ONE GOVERNED LIVE RUN**.

## 07C-4 U16 corrected-model evidence and BOM-read corrective — 0.20.26

User workstation 0.20.25 quality gate passed. The corrected single-Part/two-state control run then established the `ICimEntity.Show` semantics: visible bodies returned `1`, the deliberately hidden body returned `0`, and hidden-not-suppressed occurrence `Known_Pocket_Body` still returned `1`. Therefore `Show` is verified as body/entity visibility evidence and is not sufficient for per-occurrence hidden detection required by CR-11 FR-021.

The same corrected-model run could not re-confirm the BOM route because `IAssemblyModel.GetBomManager()` returned COM `E_FAIL (0x80004005)`. The model no-mutation evidence remained `UNCHANGED`.

0.20.26 changes only the development diagnostic boundary: `GetBomManager()` is now a non-fatal `TryObserve` call. When unavailable, the verifier records `READ_ERROR`, records `BOM.Stage: SKIPPED_AFTER_READ_ERROR`, leaves BOM semantics unresolved, and still completes the stopping-rule and no-mutation evidence. If the BOM manager is available on the controlled retry, the existing `cmNoFiltering` / `cmVisibleOnly` membership comparison runs unchanged.

Status: **U16 `Show` semantics VERIFIED; FR-021 BOM route AWAITING 0.20.26 CONTROLLED LIVE RETRY**.


## 07C-4 U16 closure / user validation — 0.20.27

User workstation evidence closes the approved 07C-4 question. The 0.20.26 quality gate completed with Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS, and exit code 0. An earlier quality-gate attempt was blocked only because Cimatron was still running; it did not represent a code or test failure.

Final runtime evidence `api-capability-hidden-state-candidates-20260930-173818.txt` used the corrected known-answer assembly and cleanly separates the two visibility meanings:

- normal visible `Block_A` body returned `Show.GET=1`;
- hidden-not-suppressed occurrence `Known_Pocket_Body` also returned `Show.GET=1`;
- visible, unsuppressed `Visible_Component_With_Hidden_Body` contained visible bodies returning `1` and the deliberately hidden body returning `0`;
- therefore `ICimEntity.Show` is verified for body/entity visibility and is **not** an occurrence-hidden getter;
- `cmNoFiltering` BOM contained `Known_Pocket_Body`; `cmVisibleOnly` omitted exactly that known hidden occurrence;
- the visible occurrence containing the hidden body remained present in `cmVisibleOnly`, so the BOM filter distinguishes occurrence-hidden from body-hidden state for this known answer;
- no-mutation evidence remained `UNCHANGED`.

**Classification:** U16 is **VERIFIED** for the approved 07C-4 scope. CR-11 FR-021 hidden-component detection has a supported read-only candidate route through `IBOM.Export(..., cmVisibleOnly, ...)` membership comparison. `ICimEntity.Show` must be treated only as body/entity visibility evidence. All results remain out-of-process and require Step 08 in-process confirmation before production promotion.

**Status: STEP 07C-4 CLOSED / USER VALIDATED.**

## Step 08A — U1 in-process confirmation status (0.21.0)

Step 07D is closed / user validated. U1 is the first approved whitelist item entering Step 08.

- **Step 07 status:** `VERIFIED` from the controlled external verifier.
- **Step 08A status:** `QUALITY-GATE CORRECTIVE PREPARED / AWAITING CLEAN USER QUALITY GATE AND LIVE IN-PROCESS VALIDATION`.
- **Production CR use:** **NOT YET AUTHORIZED**.
- **In-process route:** registered Plugin → DesignChecks `U1InProcessGeometryConfirmationFeature` → Application `IBodyGeometryMetricsReader` → CimatronIntegration `CimatronBodyGeometryMetricsReader` → `IMdlrModel.GetGeomServicesObj` / `IGeomServices`.
- **Known answer:** saved `KA-PART-1`, body ID `4`, volume `227576.685834808`, center `[50,30,20]`, surface area `26684.9371823929`.
- **No-mutation gate:** document modified-state and saved-file timestamp/length must remain unchanged.
- User workstation run `quality-gate-20261001-015133.txt` passed Release x64, governed tests, coverage, and local gate with exit code 0, but emitted one test-only `CA1806` warning; therefore it is not accepted as the required clean 0-warning gate.
- 0.21.1 corrects only that test warning. A clean user quality gate plus controlled live Plugin evidence are still required to promote U1 to `IN-PROCESS VERIFIED`; no other U-number is affected.

### Step 08A — 0.21.3 CA1861 quality-gate corrective

The user-run 0.21.2 quality gate (`quality-gate-20261001-023056.txt`) completed Release x64 build, all governed test suites, coverage and local quality gates successfully with exit code 0, but emitted one `CA1861` analyzer warning in the Application test fixture. Version 0.21.3 changes only that test fixture to reuse a `static readonly` diagnostic-evidence array. U1 capability status is unchanged: **Step 08A remains OPEN / NOT IN-PROCESS VERIFIED**. The 0.21.2 live diagnostic must not be run until a clean 0-warning quality gate is supplied.

