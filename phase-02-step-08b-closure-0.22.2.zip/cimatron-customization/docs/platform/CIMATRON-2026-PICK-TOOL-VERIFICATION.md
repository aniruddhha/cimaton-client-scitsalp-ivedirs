## Step 05B2 closure — VERIFIED 2026-09-26 (0.15.4)

User-supplied 0.15.4 evidence closes Step 05B2. Release x64 build passed with 0 warnings / 0 errors; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests passed; coverage collection/gate and local quality gate passed. Coverage was Domain 100%, Application 95.75%, DesignChecks 100%, Infrastructure 98.48%, and CimatronIntegration 4.57% measured with no Step 05B2 threshold.

Live 0.15.4 evidence:

- Same Part left active in Pick for several seconds: **PASS**; no false `SOURCE_DOCUMENT_CLOSED`.
- Second Pick request while first remained active: **PASS**; `Busy / PICK_ALREADY_ACTIVE`.
- Esc after Busy: **PASS**; `Cancelled / ESC`.
- Repeat Pick after Esc: **PASS**.
- Normal entity selection: **PASS**.
- Real source Part close during active Pick: **PASS**; `Cancelled / SOURCE_DOCUMENT_CLOSED`, launcher restored safely, no crash.
- Active-document switch: previously live-verified **PASS** as `Cancelled / CIMATRON_TOOL_POPPED`; 0.15.4 did not change that path.
- No duplicate popup after source close was explicitly demonstrated on 0.15.3; the exactly-once path is unchanged in 0.15.4, but the final 0.15.4 dialog dismissal was not separately reported.
- A matching 0.15.4 `ViewportPickCompleted` JSONL line was not separately supplied; do not infer a live log-entry PASS.

Step 05B2 is therefore **CLOSED / VERIFIED** by explicit user approval, with the log-line evidence limitation recorded above. Assembly/occurrence Pick, multi-select, NC Pick and Zoom remain deferred.

## 0.15.4 wrapper-identity regression correction

User evidence for 0.15.3: local quality gate PASS with 0 warnings / 0 errors; the first live source-document-close test returned exactly one `Cancelled` / `SOURCE_DOCUMENT_CLOSED` popup with no duplicate. A live regression then appeared: later `Pick Entity (Part)` starts could falsely report `SOURCE_DOCUMENT_CLOSED` while the Part remained open.

The 0.15.3 close watchdog compared a session token keyed to the managed COM document wrapper. That wrapper identity is not treated as a stable lifecycle identity. Version 0.15.4 keeps all COM probing on the captured STA/UI context but compares the source Part's already verified `IModel.PID` and document type instead. Re-observing the same model PID is current even when `GetActiveDoc()` exposes another managed wrapper.

A different active model remains a provisional mismatch only. Four consecutive 250 ms mismatch observations are still required, so the already verified normal active-document-switch `OnToolPoped` path retains priority. If the Pick remains active beyond that confirmation window, the existing exactly-once source-close completion path is used.

0.15.4 requires user-run quality gate and live regression validation; no PASS is claimed yet.


## 0.15.3 source-document-close lifecycle correction

The user approved the narrow Step 05B2 correction after the 0.15.2 live close-document failure. Version 0.15.3 adds an STA-marshalled lifecycle watchdog that uses the existing `IApplication.GetActiveDoc()` identity path. If the source token remains non-current for four consecutive 250 ms probes while the Pick is still active, the managed PickTool completes exactly once as `Cancelled` / `SOURCE_DOCUMENT_CLOSED` without calling `PopTool` against the disappeared source.

The session state now accepts completion exactly once and releases the strong PickTool reference on that first completion. Late COM completion is ignored at the adapter boundary. The confirmation window is deliberately subordinate to the already live-verified normal active-document-switch `OnToolPoped` path.

Pure state regression tests were added, but **0.15.3 build/tests/coverage/live behavior remain AWAITING USER EXECUTION**. The previous close-document FAIL remains the latest live evidence until the user re-tests this package.

# Cimatron 2026 Pick Tool Verification — Step 05B1 / Step 05B2

## Step 05B2 production integration — HISTORICAL 0.15.2 BASELINE

Version `0.15.2` promoted the verified Part-only PickTool behavior into the Application-owned production `IViewportEntityPicker` boundary. The following subsection preserves the historical 0.15.2 live-validation state that led to the 0.15.3/0.15.4 corrections; current closure status is recorded above.

### Reused authoritative API facts

- `IToolContainer.PushPickTool(Tool, IEntityFilter, IEntityFilter, int)` remains the push boundary verified against the installed 2026 Interop and live 0.15.1 behavior.
- The managed PickTool continues to implement `Tool`, `IToolEvents`, `IPickToolEvents`, and `IFigureEvent` and retains the 0.15.1 fixed GUID.
- No COM registration/RegAsm/CLSID activation is introduced.
- Official Cimatron `EntityEnumType` documents `cmBody`, `cmFace`, `cmEdge`, and `cmVertex`; `ICimEntity.Type` returns that enum. The 0.15.2 launcher requests Body/Face/Edge and the adapter enforces those values in the entity-type filter.
- `ICimDocument.Title` and `ICimDocument.GetPath()` are descriptive metadata only. Neither is used as the authority for entity-id validity.

### Production result/document identity

`ViewportPickResult` carries a session-scoped source-document token, optional title/path metadata, entity id, entity type, an optional occurrence path, reason code, and the exact outcome enum: `Picked`, `Cancelled`, `Unsupported`, `Failed`, `Busy`, `StaleResult`.

The session token is assigned when a document COM object is first observed. A newly observed/reopened document receives a new token. Entity ids may be consumed only while their source token is still the current source document. `ValidateForCurrentDocument` returns `StaleResult` and removes the entity id from the returned result when that check fails.

Occurrence path is intentionally empty for Part in 0.15.2. The field exists so later Assembly/occurrence support does not require a breaking Application contract.

### Threading and cancellation

- `BeginPick` is callback-based and returns without waiting for selection.
- Active Pick completion is delivered from the Cimatron PickTool COM event path on the Cimatron STA/UI thread.
- Live COM objects must not be used from thread-pool continuations.
- Caller cancellation uses a `CancellationToken`; the adapter posts cancellation to the synchronization context captured at `BeginPick`.
- If a cancellable request is started without a UI synchronization context, the request returns controlled `Failed` rather than performing cross-thread COM access.
- Esc and caller cancellation both pop the active tool and complete as `Cancelled`.
- A second request while one is active completes immediately as `Busy` and does not disturb the active Pick.

### Diagnostic spike disposition

The 0.15.1 diagnostic source/UI path is not shipped in the 0.15.2 Release production source tree. `CimatronPartPickSpike`, `CimatronDiagnosticPickTool`, `PartPickSpikeOutcome`, and `PartPickSpikeStartResult` are removed. The closed 0.15.1 package plus this verification/history record are the reference for the original spike.

### Coverage treatment

No 0.15.2 production file/member is excluded from coverage. Pure lifecycle/token state is exercised by `CimatronCustomization.CimatronIntegrationTests`; that test run is added to coverage collection so the CimatronIntegration package is measured and reported. Existing project thresholds are unchanged; no new percentage threshold was approved for CimatronIntegration in this step.

### Required live evidence for 0.15.2

1. Normal Part Body/Face/Edge Pick completes as `Picked` with entity type and source token.
2. Esc completes as `Cancelled`, then a new Pick can start.
3. Caller cancellation completes as `Cancelled` in a safe owning-workflow scenario.
4. A second request while one is active produces `Busy` without cancelling the first (where practical to expose live).
5. No active document returns controlled `Unsupported`, not a crash.
6. Switching the active document during Pick cleans up safely.
7. Closing the source document during Pick cleans up safely.
8. A previously picked result is rejected as `StaleResult` after its source document is no longer current.
9. Disallowed entity types are not normally selectable through the Cimatron filter.
10. Launcher/result focus lifecycle remains stable.
11. No crash/freeze and no second/unintended Cimatron process.
12. Cimatron exit during an active Pick: test only if safe. If not exercised, record `NOT TESTED — <reason>`, never PASS by inference.

### User-supplied Step 05B2 validation evidence

Latest local quality gate on the warning-corrected package:

- Release x64 build PASS with **0 warnings / 0 errors**.
- Architecture, Domain, Application, CimatronIntegration and Infrastructure tests PASS.
- Coverage collection/gate and local quality gate PASS.
- Coverage: Domain 100%; Application 95.75%; DesignChecks 100%; Infrastructure 98.48%; CimatronIntegration 3.44% measured with no Step 05B2 threshold.

Live Cimatron evidence:

- Normal Part Pick: **PASS**. A picked Face returned an entity ID, entity type, source-document token/metadata, `ENTITY_PICKED`, and correlation id.
- Esc cancellation: **PASS** with `Cancelled` / `ESC`.
- Repeat Pick after Esc: **PASS**.
- Active-document switch during Pick: **PASS** with controlled `Cancelled` / `CIMATRON_TOOL_POPPED`.
- Busy request through the current Feature Launcher: **NOT TESTED THROUGH CURRENT UI** because the launcher hides during active Pick. Automated state tests cover the Busy contract.
- Source document closed during active Pick: **FAIL / INCOMPLETE**. The document closed, but no result dialog appeared. The recent 0.15.2 JSONL entries contained no corresponding `ViewportPickCompleted` entry for that test, so `OnToolPoped` / normal completion cannot be claimed.

The next proposed change is narrowly scoped to source-document-close lifecycle detection and exactly-once cancellation (`SOURCE_DOCUMENT_CLOSED`). It requires explicit user approval before implementation. See the Step 05B2 session handoff in `docs/history/session-handoffs/phase-02-step-05b2-document-close-defect-session-handoff-0.15.2.md`.

### Deferred CR-11 dependencies

- Assembly/sub-assembly/component occurrence Pick.
- Multi-select required by CR-11 FR-003/FR-004.
- Zoom-to-result required by CR-11 FR-014.
- NC Pick.


## Step 05B1 closure — VERIFIED 2026-09-26

User-supplied workstation/live Cimatron evidence closes the 0.15.1 Part-only diagnostic Pick spike:

- direct managed-object `PushPickTool` activation without COM registration: PASS;
- Part face pick completion/current-session entity ID capture: PASS;
- Esc cancellation and tool pop/cleanup: PASS;
- modeless Feature Launcher lifecycle: PASS;
- dedicated owned result-dialog reachability after window toggles: PASS;
- launcher foreground restoration after returning to Cimatron: PASS;
- post-result focus return to Cimatron and launcher: PASS;
- active-document switching during Pick: PASS;
- final local quality gate: PASS with 0 warnings / 0 errors and all required test/coverage gates passing.

The verified boundary remains Part-only and diagnostic. Entity IDs are session-only. Assembly/NC Pick and Zoom remain Unsupported. Proper production Pick integration is deferred to Step 05B2.


## Purpose

Record the authoritative Cimatron 2026 PickTool facts used by the `0.15.1` Part-only diagnostic spike. This document exists so implementation does not guess COM interface signatures, push/pop behavior, filter types, or lifecycle semantics.

## Source priority used

1. Installed target-version Interop metadata supplied from the user's Cimatron workstation.
2. Official Cimatron API documentation.
3. Live runtime behavior — **NOT VERIFIED yet for 0.15.1**.

## Installed environment inspected

- Cimatron Program folder: `C:\Program Files\Cimatron\Cimatron\2026.0\Program`
- `interop.CimBaseAPI.dll`: `2026.201.2064.662`
- `interop.CimMdlrAPI.dll`: `2026.201.2064.662`
- Inspection date: 2026-09-25

## Installed interface signatures

### `interop.CimBaseAPI.ITool`

GUID: `24e46d84-f4e8-11d4-b7c4-00105accae9f`

```text
Int32 ToolLevel { get; set; }
Void OnToolPoped()
Void OnToolPushed(Object iToolHelper)
```

### `interop.CimBaseAPI.IToolEvents`

GUID: `afa33411-f4f5-11d4-b7c4-00105accae9f`

```text
Int32 OnBlockPop()
Void OnKeyboardEvent(Int32 iChar, Int32 iRepCnt, Int32 iFlags)
Void OnMouseEvent(MouseEventType iType, Int32 iXPos, Int32 iYPos)
stdole.IPicture OnSetCursor(Int32 iXPos, Int32 iYPos)
```

### `interop.CimBaseAPI.IPickToolEvents`

GUID: `068e77e1-faa4-11d4-b7c7-00105accae9f`

```text
Void OnClearSelection()
Void OnEntityDraged(ICimEntity iEntity, Int32 iXPos, Int32 iYPos)
Void OnEntityHighlighted(ICimEntity iEntity, Int32 iXPos, Int32 iYPos)
Void OnEntityPicked(ICimEntity iEntity)
Void OnEntityPressed(ICimEntity iEntity, Int32 iXPos, Int32 iYPos)
Void OnEntityReleased(ICimEntity iEntity, Int32 iXPos, Int32 iYPos)
Void OnNoEntityPicked(Int32 iXPos, Int32 iYPos)
```

The installed metadata resolves the event entity parameter as `interop.CimBaseAPI.ICimEntity`.

### `interop.CimBaseAPI.IFigureEvent`

GUID: `0f4b7141-f419-4d20-8f64-82218bbed40c`

```text
Void FigureChange(InteractionType iType, IInteraction oInteraction)
```

### `interop.CimBaseAPI.IToolContainer`

GUID: `2234aad2-b65c-11d4-b7ad-00105accae9f`

```text
Int32 GetTopToolLevel()
Void PopTool(interop.CimBaseAPI.Tool ITool)
Void PushPickTool(
    interop.CimBaseAPI.Tool ITool,
    interop.CimBaseAPI.IEntityFilter iActiveFilter,
    interop.CimBaseAPI.IEntityFilter iEnableFilter,
    Int32 iEnablePoints)
Void PushTool(interop.CimBaseAPI.Tool ITool)
```

### `interop.CimBaseAPI.Tool`

The installed `Tool` type is an imported **interface**, not a coclass. It inherits `interop.CimBaseAPI.ITool` and has the same GUID as `ITool`.

This resolves the documentation ambiguity: the runtime handoff boundary for the spike is `IToolContainer.PushPickTool`, and the managed diagnostic tool implements `interop.CimBaseAPI.Tool` plus the event interfaces.

### `interop.CimBaseAPI.IEntityFilter`

GUID: `6c27ed01-363e-11d4-b78c-00105accae9f`

```text
EFilterEnumType Type { get; set; }
Int32 Test(ICimEntity iEntity)
```

### Installed `interop.CimMdlrAPI.IPartDocument`

The inspected imported interface did **not** expose a `PushPickTool` member through reflection. Therefore `0.15.1` does not call `IPartDocument.PushPickTool`; it casts the active document to the verified installed `IToolContainer` interface instead.

## Official Cimatron documentation findings

The official Cimatron API documents:

- `IToolContainer.PushPickTool` as the API for activating a custom pick tool with active/enable entity filters and point-pick enablement.
- `IToolContainer.PopTool` as the API for deactivating a pushed tool.
- `IToolEvents.OnBlockPop`: returning `0` allows the normal pop event; returning `1` blocks it.
- `ITool.ToolLevel`: normal tool level is `1`.
- `IPickToolEvents` event order around entity picking and `OnEntityPicked` after entity release.
- `ICimEntity.ID` as a current Cimatron entity identifier usable with `IModel.GetEntityById`.
- The official sample obtains the helper passed to `OnToolPushed` as `interop.CimServicesAPI.IPickTool`.
- The official sample creates an entity-type filter from the active model query and passes it into `PushPickTool`.

Official reference entry points used during verification:

```text
https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/itoolcontainer/itoolcontainer_pushpicktool.htm
https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/itoolcontainer/itoolcontainer_poptool.htm
https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/itoolevents/itoolevents.htm
https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/itoolevents/itoolevents_onblockpop.htm
https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/ipicktoolevents/ipicktoolevents.htm
https://api.cimatron.com/assets/docs/cimatron_e_api/elite_api_interfaces/ientity/ientity__id.htm
```

## Step 05B1 decisions

- Scope is **Part documents only**.
- The spike is diagnostic/foundation behavior, not the final product Pick workflow.
- The launcher is the entry point. Live validation proved that hiding a modal `ShowDialog()` launcher terminates its lifetime and causes owner-shutdown cancellation. The corrected spike therefore keeps the Feature Launcher as a strongly retained **modeless** `Show()` window; it can be hidden before `PushPickTool` and restored after completion/cancellation without ending the launcher lifetime. No Result Report window is open for this flow.
- The push is asynchronous. No wait loop, `Sleep`, polling loop, or UI-thread blocking is introduced.
- The managed tool is held by a strong reference for the entire active pick lifetime.
- The first selected face completes the diagnostic pick and requests `PopTool`.
- Esc requests cancellation when delivered through `OnKeyboardEvent`.
- Normal Cimatron pop/MMB remains allowed through `OnBlockPop() == 0`; an unqualified pop is treated as cancellation.
- Active document/model identity is checked from event callbacks using the active Part model PID. If the active model changes, the spike requests cancellation. If Cimatron sends no further tool event after a document switch, immediate switch detection is not claimed and remains a live-validation question.
- Event handlers keep only a bounded in-memory trace; completion logging occurs when the tool is popped so high-frequency highlight/mouse events do not perform repeated file I/O.
- Picked entity IDs are explicitly **current-session diagnostic values only**. They are not persisted or reused as durable identifiers.
- The CimatronIntegration assembly remains `[assembly: ComVisible(false)]`. Only `CimatronDiagnosticPickTool` opts in with `[ComVisible(true)]`, a fixed `[Guid]`, and `ClassInterfaceType.None`.
- No `RegAsm`, registry write, installer registration, or CLSID activation is added in `0.15.1`. The managed object is instantiated directly and passed to Cimatron. Whether this works without COM registration is a required live-test question.
- Assembly and NC Pick remain Unsupported for this spike even though other Cimatron documentation may describe tool APIs for those document types; they are outside the approved live-validation scope.
- Zoom remains Unsupported.

## Live questions for 0.15.1

The user must validate these in real Cimatron before Step 05B1 can close:

1. Does direct managed-object handoff work without COM registration?
2. Does the launcher hide and leave the Cimatron viewport interactive?
3. Which tool/pick events are actually delivered?
4. Does selecting one Part face return a current-session entity ID and pop cleanly?
5. Does Esc cancel cleanly?
6. Does MMB/default tool pop cancel cleanly?
7. What happens when the active document is switched during the pick?
8. Does the launcher restore after completion/cancellation without a UI freeze or second Cimatron process?

## Live evidence and validation status

User-supplied local quality gate for the first 0.15.1 package passed with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests passed; coverage gate passed.

The first live Cimatron Pick spike established:

- direct managed-object handoff works without COM registration;
- Cimatron delivered `OnToolPushed`;
- the verified `IPickTool` helper was available;
- `OnToolPoped` was delivered;
- the original modal launcher lifecycle immediately cancelled the spike, with JSONL messages `Diagnostic pick cancelled because the launcher is closing. Events: OnToolPushed | PickToolHelperAvailable | OnToolPoped`;
- entity-pick and Esc behavior could not be evaluated because the tool was cancelled by the launcher lifecycle first.

The lifecycle correction changes `CimatronCommandExecution` from `launcher.ShowDialog()` to a strongly retained modeless `launcher.Show()` and adds architecture protection against regression.

User re-validation after the lifecycle correction established:

- local quality gate PASS with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS;
- a live Part face pick completed successfully without COM registration;
- the completion popup reported current-session entity ID `48`;
- the launcher restored after the pick and Cimatron remained responsive;
- temporary PickTool selection was cleared when the tool ended, which is accepted spike behavior and is not a persistent-highlight requirement.

A follow-up UI issue was observed: after window switching/toggling, the standard completion MessageBox could fall behind. That path was replaced by a dedicated owned nested `PickSpikeResultDialog` which remains TopMost while open. User re-validation of the architecture-compliant result-dialog package passed the local quality gate with 0 warnings / 0 errors, all local test suites passed, coverage gate/local quality gate passed, and the dedicated Esc cancellation result dialog remained reachable and behaved correctly.

A separate launcher-only z-order observation then remained: after switching away from Cimatron and back, the modeless Feature Launcher itself could stay behind. A control test confirmed that pressing Esc without clicking `Pick Spike (Part)` does not start a Pick session, so this is not duplicate Esc-driven Pick activation.

The current correction keeps the launcher modeless and strongly retained, but shows it as an owned window of the Cimatron main window. A lightweight WinForms timer compares the foreground window's process to the current Cimatron process and reacts only to a transition from an external process back to Cimatron. If the launcher is visible, enabled and no Pick is active, the existing restore/activate path runs once. The launcher is deliberately not made permanently TopMost.

User live validation confirmed the launcher-foreground correction works when switching away from Cimatron and back. The user also confirmed the active-document-switch Pick lifecycle behaved as expected. A package-specific local quality-gate transcript was not supplied for that launcher-foreground package.

A later live sequence exposed one remaining focus-return defect: `Pick Spike (Part)` -> Esc -> close the dedicated result dialog could cause Cimatron to drop behind another application. The focus-return correction leaves PickTool behavior unchanged and, after the owned result dialog closes, explicitly calls `SetForegroundWindow` on the captured Cimatron main-window handle before restoring/activating the Feature Launcher.

**FOCUS-RETURN CORRECTION NOT VERIFIED / AWAITING USER RE-VALIDATION.**

The AI agent did not run the focus-return-corrected build/tests or Cimatron validation.

### Focus-return quality-gate follow-up

User live validation confirmed the focus-return correction works: after Esc cancellation and closing the dedicated result dialog, Cimatron remains foreground and the Feature Launcher is restored. The subsequent full local quality gate passed Release x64, Architecture, Domain, Application, Infrastructure, coverage, and the local gate, but reported one analyzer warning: `CA1806` because `IsCurrentProcessForeground()` ignored the return value of `GetWindowThreadProcessId`.

The warning-only correction captures that returned thread ID and fails closed (`false`) when the return value is 0 before comparing the foreground process ID. This does not intentionally change the already validated foreground lifecycle. The corrected package still requires user quality-gate re-execution; no agent-side PASS is claimed.
