# Step 07 Known-Answer Models

## Purpose

Use only disposable working copies created specifically for Phase 02 Step 07. Do not run Step 07 live probes against customer models. The values recorded by the user in this document are authoritative; example dimensions below are not assumptions in code.

## KA-PART-1 — required construction

- B1: axis-aligned block, suggested 100 × 60 × 40 mm, at a known position.
- B2: second block with a known clear gap from B1 along one axis, suggested 25 mm.
- Through hole of known diameter in B1 along Z.
- At least one known convex edge and one known concave edge.
- User-defined UCS with known orientation different from main UCS.
- Body-level manufacturing attribute on B1 using a user-chosen name/type/value (example only: `MATERIAL = 1.2738`).

### KA-PART-1 known-answer sheet — user fills

| Item | User-recorded value |
|---|---|
| Working-copy filename | |
| Unit | |
| B1 entity id | |
| B1 dimensions | |
| B1 expected volume | |
| B1 expected centre | |
| B1 expected main-UCS bounding box | |
| B2 entity id | |
| B2 dimensions | |
| B2 expected volume | |
| B1↔B2 expected minimum distance | |
| Through-hole diameter | |
| Ray through hole: origin | |
| Ray through hole: direction | |
| Ray through solid: origin | |
| Ray through solid: direction | |
| Known convex edge id / parameter | |
| Known concave edge id / parameter | |
| Test face id | |
| Test point coordinates | |
| Expected face↔point distance | |
| User UCS entity id | |
| User UCS orientation | |
| Expected user-UCS bounding box | |
| Attribute entity id | |
| Attribute name | |
| Attribute type | |
| Attribute value | |

## KA-ASM-1 — required construction

Start from a copy of the validated `CR11_Smoke_Assembly_Prepared.elt` known-answer assembly and retain its visible repeated `Block_A`, suppressed `Block_B`, and hidden-not-suppressed `Known_Pocket_Body`. Extend only the working copy with:

- one KA-PART-1 instance inside a nested sub-assembly at a known transform;
- two KA-PART-1 instances (or two known parts) with a known clear cross-component gap;
- one instance locked through the Cimatron UI;
- enough normal visible components to make comparisons unambiguous.

### KA-ASM-1 known-answer sheet — user fills

| Item | User-recorded value |
|---|---|
| Working-copy filename | |
| Unit | |
| Root assembly title | |
| Nested sub-assembly title | |
| KA-PART-1 model title used by `--model-title` | |
| Target part-model entity id used by `--entity-id` | |
| Visible Block_A occurrence(s) / transforms | |
| Suppressed Block_B occurrence | |
| Hidden-not-suppressed Known_Pocket_Body occurrence | |
| Nested KA-PART-1 occurrence / transform | |
| Locked occurrence | |
| Expected locked state | |
| Cross-component pair | |
| Expected cross-component minimum distance | |
| Expected assembly bounding box in active UCS | |

### 07C-2A evidence-source rule — 0.20.15

Fill the KA-ASM-1 table from **independent Cimatron UI evidence before the live verifier run**:

- assembly tree / nesting: Cimatron assembly tree;
- occurrence positions/orientation: read-only Cimatron Measure observations of known B1 corner coordinates; do not open move/edit placement dialogs;
- suppressed occurrence: suppress state/icon in the UI;
- locked occurrence/state: lock state/icon in the UI;
- cross-component pair and expected minimum distance: Cimatron Measure tool;
- expected assembly bounding box and the UCS used for it: Cimatron UI/measurement evidence.

Do **not** populate those expected values from `IAssInstance.Transformation`, `IAssInstance.IsSuppressed`, `IAssInstance.Lock`, `MinDistancePos`, or `GetAssemblyBoundingBox`, because those are the APIs being verified. Entity IDs may come from prior API discovery where Cimatron UI does not expose an ID. For the validated `KA-PART-1`, body ID `4` is already evidence-backed from 07C-1 and is suitable only if the intended assembly gap is explicitly measured between that body in the chosen occurrences.

The final live command must use the exact UI/evidence-backed model title and target entity. Supply `--ucs-id` only after the assembly UCS ID is evidence-backed; otherwise the verifier records the active assembly UCS.


### 07C-2A manual known-answer capture — completed 2026-09-30

User completed the independent UI/Measure recording before the governed live run. Recorded summary supplied to the agent:

- assembly tree/state mapping: completed;
- nested KA-PART-1 B1 corner pair: recorded manually;
- first top-level KA-PART-1 B1 corner pair: recorded manually;
- second top-level KA-PART-1 B1 corner pair: recorded manually;
- exact model title: `KA-PART-1`;
- B1 body entity ID carried from 07C-1: `4`;
- top-level B1-to-B1 minimum distance: `25.000 mm`;
- measurement UCS: `UCS10_1`;
- assembly extents from UI: `not available`;
- closest faces: highlighted by Cimatron, but the UI exposed no face IDs/names.

The detailed tree/state and corner coordinate values remain user-recorded known-answer evidence; this package does not invent values that were not supplied in text.

## Session preparation status — 2026-09-29

The user confirmed that the Step 07 known-answer model work is ready to continue. During the session, KA-PART-1 was observed with two bodies, a through-hole, the user UCS `KA_UCS_90Z`, and part/model material property `1.2738`. The material property is not to be treated as proof of a B1 body-level custom attribute.

The user later stated that KA-ASM-1 is ready. For 07C-2, the final assembly tree/placements/suppress-lock states/gap/bounding-box expectations must be recorded independently from the user's Cimatron UI/Measure evidence before interpretation; identifiers may reuse prior evidence where the UI does not expose them. Missing IDs, transforms, states or measurements must not be guessed.

## Comparison tolerances approved for Step 07

- Linear measurements: absolute tolerance `1e-3 mm`.
- Volume measurements: absolute tolerance `1e-2 mm³`.
- Relative comparison tolerance: `1e-6`.

If the model unit reported by Cimatron is not millimetres, stop interpretation and record the actual unit before comparing values.

## Evidence return checklist

Return the filled known-answer tables together with the console captures and generated `api-capability-*.txt` evidence files. For `--highlight`, also report whether the visibly highlighted geometry was the intended nested assembly-context entity and provide a screenshot where practical.

## 07C-1A runtime discovery — 0.20.3

Before filling the remaining KA-PART-1 identifier fields, run the development-only read-only discovery mode against the active validated part:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --discover-geometry-targets --expect Part
```

Precondition: activate `KA_UCS_90Z` before the run if Cimatron permits it. The diagnostic records the active-UCS entity ID when exposed, and it also enumerates installed `EntityEnumType` names containing `UCS` instead of assuming an enum member.

Use the returned runtime evidence to populate the B1/B2 entity IDs, candidate face IDs, convex/concave edge IDs, user UCS ID, volume/centre/surface/bounding-box values, and B1↔B2 minimum distance. The diagnostic deliberately does **not** infer which enumerated body is B1/B2 or which face/edge is the intended known-answer target. Those mappings must be confirmed from the prepared model and evidence.

Do not start `--verify-geometry` until the required identifiers are recorded. Do not start 07C-2 from this discovery result.

## 07C-1 evidence update — 2026-09-29

User workstation evidence from 0.20.3 established the following actual runtime values for the validated standalone `KA-PART-1`:

| Item | Evidence-backed value / state |
|---|---|
| Working-copy title | `KA-PART-1` |
| Unit | `cmMillimeter` |
| ModelPID | `...\KA_PART_SOURCE\KA-PART-1.elt` (full path retained in runtime evidence) |
| Body entity IDs | `4`, `5` |
| B1 visual role | large complex left body; user-confirmed |
| B1 runtime mapping | Body ID `4`; volume `227576.685834808`; centre `[50,30,20]`; surface area `26684.9371823929` |
| B2 visual role | separate rectangular right body; user-confirmed |
| B2 runtime mapping | Body ID `5`; volume `64000`; centre `[145,30,20]`; surface area `9600` |
| B1↔B2 minimum distance | `25 mm`; closest points `100,50,40` and `125,50,40` |
| User UCS | `KA_UCS_90Z` |
| User UCS entity ID | `2`, recorded after the user explicitly activated `KA_UCS_90Z` before discovery |
| Intended test face | visually selected by user; actual entity ID still pending |
| Intended convex edge | pending user selection + ID inspection |
| Intended concave edge | pending user selection + ID inspection |
| Through-hole diameter / ray values | not yet evidence-backed in runtime record |
| Test point / expected face-point distance | not yet evidence-backed |

The raw 0.20.3 `GetBoundingBoxByUCS` values were `[1,1,1,0,0,0]`; they are retained as raw API observations and are **not** accepted here as the known-answer dimensions/bounding box without further interpretation.

### 07C-1C selected-entity ID capture — 0.20.4

Use the following read-only mode after selecting exactly one intended face or edge in Cimatron:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --inspect-current-selection --expect Part
```

For the test face, record the returned `SelectedEntity[1]` ID/type. For an intended edge, also require the returned convexity observation to match the user's intended convex/concave role. Do not choose an ID merely because it appears early in the 0.20.3 enumeration.

## 07C-1D locked role mapping — 0.20.5

User workstation 0.20.4 selection-inspection evidence completes the required semantic mapping without guessing:

| Item | Locked evidence-backed value |
|---|---|
| B1 entity id | `4` — large complex left body |
| B2 entity id | `5` — separate rectangular right body |
| B1↔B2 expected minimum distance | `25 mm` |
| Test face id | `90` (`cmFace`) |
| Known convex edge id / parameter | `89` / `0.5`; observed `cmConvex` |
| Known concave edge id / parameter | `95` / `0.5`; observed `cmConcave` |
| User UCS | `KA_UCS_90Z` |
| User UCS entity id | `2` after explicit activation before discovery |

The 0.20.4 quality gate passed with exit code 0. Selection-inspection evidence for the test face, convex edge and concave edge each recorded `No-mutation evidence: UNCHANGED`.

The following values remain deliberately unresolved and must not be inferred: through-hole diameter, ray origin/direction through the hole, ray origin/direction through solid, test point coordinates, expected face↔point distance, and interpreted user-UCS bounding-box dimensions. The raw API bounding-box value `[1,1,1,0,0,0]` remains an observation only.

### First 07C-1 Geometry Services verification commands

With standalone `KA-PART-1.elt` active as a Part document and `KA_UCS_90Z` active, run only evidence-backed arguments first:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-geometry --expect Part --ucs-id 2 --entity-a 4 --entity-b 5 --edge-id 89
```

Then verify the known concave edge separately:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-geometry --expect Part --ucs-id 2 --edge-id 95
```

Do not add `--ray-origin`, `--ray-direction`, `--entity-id 90`, or `--point` until their corresponding known-answer numeric values are explicitly captured. Do not start 07C-2.

## 07C-1R remaining-evidence resolution — 0.20.6

User live 0.20.5 evidence confirmed the locked body metrics, 25 mm minimum distance, convex edge 89, concave edge 95, and no-mutation behavior. It also exposed a controlled interpretation question: under `KA_UCS_90Z` (ID 2), `GetBoundingBoxByUCS` returned `[1,1,1,0,0,0]` for the body list but `[0,0,0,100,60,40]` for B1 faces. The body result remains raw evidence only until the face-list comparison is completed.

Before the final 07C-1R run, record these additional known answers without guessing:

| Item | Required evidence-backed value |
|---|---|
| Main/reference UCS entity ID | pending; map by activating main UCS and using existing discovery evidence |
| Test face physical role | pending explicit description of the selected physical face corresponding to ID `90` |
| Test face expected area | pending model/UI known answer |
| Test face expected plane/flat axis | pending model/UI known answer |
| Test face expected main-UCS box | pending model/UI known answer |
| Test point coordinates | pending model/UI known answer |
| Expected face↔point distance | pending model/UI known answer |
| Ray through hole: origin/direction | pending model/UI known answer |
| Ray through solid: origin/direction | pending model/UI known answer |

Version 0.20.6 adds only extra arguments to the existing geometry mode: `--face-id` and `--reference-ucs-id`. It guards the face ID as `cmFace`, records `Face.Area()`, attempts `SurfacesArea` only if the installed Interop actually exposes that member, records face-only and B1-face-list bounding boxes under both UCSs, and emits explicit `NOT_TESTED` lines when ray/point known answers are absent.

The final 07C-1R evidence for each remaining API must be interpreted as exactly one of: **VERIFIED**, **DOC-MISMATCH** with raw observed behavior, or **BLOCKED / NOT TESTED** with the raw reason. 07C-2 remains blocked until the user approves 07C-1 closure.


## 07C-1R final known-answer alignment — 0.20.8

### Evidence-backed Face 90 geometry in UCS 2

The 0.20.7 geometry run resolves face ID `90` as `cmFace` and returns a face bounding box `[100,0,0,100,60,40]` under UCS 2. For the remaining Step 07 checks, the authoritative test interpretation is therefore:

- face 90 lies on plane `x = 100`;
- bounded `y` range is `0..60`;
- bounded `z` range is `0..40`;
- B1 spans `[0,0,0]..[100,60,40]` in UCS 2.

### `GetEntityPointDistance` final inputs

| Entity / point in UCS 2 | Expected result | Interpretation purpose |
|---|---:|---|
| face 90, `(110,30,20)` | `10 mm` | verifies perpendicular distance and the coordinate frame used for input points |
| face 90, `(110,70,20)` | `sqrt(200) ≈ 14.1421356237 mm` if distance respects the bounded face; `10 mm` if it measures to the infinite support plane | distinguishes bounded-face vs infinite-plane semantics |

If the first point does not return 10 mm, record the raw result as a frame/contract finding; do not silently reinterpret coordinates.

### `GetPiercingPoints` final inputs

| Origin → direction in UCS 2 | Expected observation | Interpretation purpose |
|---|---|---|
| `(150,30,20) → (-1,0,0)` | hit at `(100,30,20)` | basic hit and returned-array layout |
| `(150,70,20) → (-1,0,0)` | no hit if bounded face edges are respected | bounded-face semantics |
| `(150,30,20) → (+1,0,0)` | empty for a one-way ray; hit at `x=100` if treated as an infinite line | ray-vs-line semantics relevant to CR-10 |

Raw returned arrays must be retained. One final run should end each item in an evidence-backed state; no mutation check remains mandatory.

### UCS orientation limitation

UCS 249 is **not** identified as Main/Default UCS. The 0.20.7 boxes indicate axes parallel to UCS 2 and are consistent with a `(50,60,0)` translation:

- B1 faces, UCS 2: `[0,0,0,100,60,40]`; UCS 249: `[-50,-60,0,50,0,40]`.
- Face 90, UCS 2: `[100,0,0,100,60,40]`; UCS 249: `[50,-60,0,50,0,40]`.

Because both frames are axis-parallel, orientation behavior of `GetBoundingBoxByUCS` remains unverified. The proposed next-session known answer is one additional UCS rotated by a known `30°` about Z, with its actual entity ID discovered after creation. This proposed model revision is **not implemented by 0.20.8** and requires explicit approval before creation/change.

`SurfacesArea` is **NOT AVAILABLE** in the installed 2026 SP2P1 `IGeomServices` Interop contract; do not treat absence as BLOCKED and do not invent a replacement API in Step 07.

## 07C-1R2 final execution preparation — 0.20.9

The approved final orientation known answer is a new disposable-model UCS named `KA_UCS_30Z`, created at the **same origin as UCS 2** and rotated exactly **+30° about Z**, with no intentional translation. The agent package does not contain or modify the `.elt`; create this UCS in Cimatron, save/reopen the known-answer model, activate it, and discover its actual entity ID with the existing read-only discovery mode. Never infer the ID from prior UCS numbering.

Version 0.20.9 keeps the existing `--verify-geometry` mode and allows repeated ray/point arguments so the final evidence can be captured in one invocation. With `--face-id 90`, piercing targets face 90 specifically.

After discovery, substitute the actual ID for `<ROTATED_UCS_ID>`:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-geometry --expect Part --ucs-id 2 --reference-ucs-id <ROTATED_UCS_ID> --entity-a 4 --entity-b 5 --face-id 90 --edge-id 89 --entity-id 90 --point 110,30,20 --point 110,70,20 --ray-origin 150,30,20 --ray-direction -1,0,0 --ray-origin 150,70,20 --ray-direction -1,0,0 --ray-origin 150,30,20 --ray-direction 1,0,0
```

Expected evidence ordering is `GetPiercingPoints[1..3]` followed by `GetEntityPointDistance[1..2]`; preserve all raw returned arrays/nearest points. `No-mutation evidence` must remain `UNCHANGED`. The rotated-UCS bounding boxes must be interpreted from the actual observed frame; do not force an orientation conclusion if the runtime output is ambiguous.

## 07C-2 closure comparison — 0.20.17

The single approved 0.20.17 live run used model title `KA-PART-1`, B1 entity ID `4`, active UCS `UCS10_1`, and no guessed `--ucs-id`. It traversed three target occurrences: nested instance 6 plus top-level instances 12 and 13. The user visually confirmed all three paused highlights mapped to the intended bodies and confirmed final empty selection / no unsaved-change indicator.

The independently measured top-level B1-to-B1 known answer remains `25.000 mm`. Direct `MinDistancePos` on the occurrence-derived assembly entities returned `0` for every pair with identical closest points; this is recorded as an assembly-placement limitation rather than replacing the independent UI/Measure known answer. UI overall assembly extents remained unavailable, so the returned API assembly box is operational evidence but not an independently validated numeric box.

## 07C-3 setup — component property / BOM known answer

0.20.20 provides a separate **developer-only controlled setup helper** so the read-only 07C-3 verifier remains read-only. The helper is restricted to disposable `KA-PART-1`, B1 body entity `4`, and the diagnostic string attribute `STEP07_B1_TEST_ATTRIBUTE = KNOWN_ANSWER_07C3`. This attribute is intentionally different from the Part/model material property `1.2738`.

After the 0.20.20 workstation quality gate passes:

1. Open disposable `KA-PART-1` as the active **Part**.
2. Run the setup helper with `--apply`; it must report entity `4` as `cmBody` and either `ATTACHED_AND_READ_BACK` or `ALREADY_PRESENT`.
3. The helper does **not** save the model. Confirm the message `MODEL MUTATED IN MEMORY - MANUAL SAVE REQUIRED`, then manually save `KA-PART-1`.
4. Reopen/reload `KA-ASM-1` so the later read-only 07C-3 baseline starts after the deliberate known-answer change.
5. Confirm the independent Part/model material known answer remains `1.2738` (or record the actual value if intentionally changed).
6. Run only the separate read-only 07C-3 verifier after setup is saved/reloaded. Creating the attribute does not itself verify U13.

Setup command:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.KnownAnswerModelSetup.exe" `
  --expect Part `
  --model-title KA-PART-1 `
  --entity-id 4 `
  --attribute-name STEP07_B1_TEST_ATTRIBUTE `
  --attribute-value KNOWN_ANSWER_07C3 `
  --apply
```

### 0.20.21 read-back diagnostic corrective

The first 0.20.20 controlled setup run reached `Attach()` but failed the exact read-back comparison. Because 0.20.20 emitted the observed read-back fields only after that comparison, the specific mismatch was not visible. 0.20.21 keeps the same API path and fail-closed rules but prints these observations **before** comparison:

```text
ReadBack.Name: <actual>
ReadBack.Type: <actual>
ReadBack.Value: <actual>
```

Before rerunning 0.20.21, close the failed-run `KA-PART-1` **without saving** and reopen the clean disposable Part. Do not save unless the helper later reports `ATTACHED_AND_READ_BACK` (or `ALREADY_PRESENT` on a known clean/saved state). A mismatch remains a stop condition; do not switch identifiers, attribute values, types or APIs.

| 07C-3 known-answer item | User-recorded value |
|---|---|
| B1 body entity id | `4` (carried from validated 07C-1 evidence; reconfirm verifier reports `cmBody`) |
| Body attribute name | `STEP07_B1_TEST_ATTRIBUTE` |
| Body attribute type | `cmAttString` |
| Body attribute value | `KNOWN_ANSWER_07C3` |
| Part/model material value | `1.2738` unless user records an intentional different value |
| KA-ASM-1 reopened after save | |

07C-3 does not interpret `cmNoFiltering` versus `cmVisibleOnly` membership differences. That comparison belongs to separately approved 07C-4.

### 0.20.22 returned-name observation corrective

The user-run 0.20.21 setup provided the missing observation:

```text
ReadBack.Name:
ReadBack.Type: cmAttString
ReadBack.Value: KNOWN_ANSWER_07C3
```

The helper had already performed exact `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` and passed the non-null guard, so this is evidence that the named lookup returned an attribute even though the returned `IAttribute.Name` property was blank. 0.20.22 therefore keeps the exact named lookup and continues to print `ReadBack.Name`, but success is based on non-null + exact `cmAttString` type + exact `KNOWN_ANSWER_07C3` value. No alternate API or fallback lookup is introduced.

Before the 0.20.22 setup rerun, use a clean reopened `KA-PART-1` with the failed-run in-memory mutation discarded. After a successful `ATTACHED_AND_READ_BACK` result, manually save `KA-PART-1`, then reopen/reload `KA-ASM-1`. The setup result alone does **not** verify U13; U13 remains pending the separate read-only 07C-3 verification run.


### 0.20.23 occurrence-resolution corrective

The 0.20.22 setup rerun succeeded with `Result: ATTACHED_AND_READ_BACK`, `EntityId: 4`, `EntityType: cmBody`, `ReadBack.Type: cmAttString`, and `ReadBack.Value: KNOWN_ANSWER_07C3`; the user then manually saved `KA-PART-1` and reopened `KA-ASM-1`. The first 07C-3 verifier run failed before attribute/BOM interpretation because the verifier used `instance.Model.GetEntityById(4, partModel)`.

A follow-up read-only assembly diagnostic proved body entity `4` is still present on all loaded `KA-PART-1` occurrences when reached through `IAssInstance.GetAllEntities()`; therefore the known-answer ID remains `4`. 0.20.23 uses that already-proven occurrence path, requires exact ID `4` + `cmBody`, and does not guess a replacement ID. The exact known attribute lookup remains `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` with type/value validation and returned `Name` treated as evidence only.


### 0.20.24 07C-3 final validation

The saved `KA-PART-1` known answer persisted and was read successfully from active `KA-ASM-1` in the final 0.20.23 governed run. Body entity `4` was found through the occurrence entity list as `cmBody`. Both the Part-model body and its assembly-context entity returned `STEP07_B1_TEST_ATTRIBUTE` through exact `GetAttribute(cmAttString, name)` with value `KNOWN_ANSWER_07C3`. The returned `IAttribute.Name` remained blank, matching the setup evidence.

The same run exported both governed BOM variants and found `KA-PART-1` with `Material=1.2738` in the `Material` column. No visibility/filter semantics were inferred from the differing row counts. File and folder no-mutation evidence were UNCHANGED. The known-answer setup prerequisite is therefore complete and 07C-3 is CLOSED / USER VALIDATED.
