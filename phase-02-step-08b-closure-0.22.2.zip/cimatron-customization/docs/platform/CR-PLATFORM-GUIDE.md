## 0.15.4 Step 05B2 lifecycle identity correction

The 0.15.3 source-close monitor proved the close completion path live, but managed COM-wrapper token comparison caused false `SOURCE_DOCUMENT_CLOSED` results on later normal Picks. Version 0.15.4 changes only the watchdog identity signal to the source Part model PID/document type already used elsewhere in the verified Pick boundary. Exactly-once completion, strong-reference cleanup, late callback suppression, the normal document-switch confirmation window, Application contracts, Plugin UI and deferred scope remain unchanged. User validation is pending.

# CR Platform Guide

## Purpose

This guide describes the implemented Phase 02 platform contract for adding future customer CR/SA features without moving business logic into the Cimatron Plugin boundary.

## Feature placement

- Pure rules, findings, measurements, units, tolerances and reusable business value types belong in `CimatronCustomization.Domain`.
- Feature orchestration and Cimatron-independent ports belong in `CimatronCustomization.Application`.
- Read-only customer validation feature classes belong in `CimatronCustomization.DesignChecks`.
- Modifying customer automation feature classes belong in `CimatronCustomization.Automations`.
- Cimatron COM/Interop adapters belong in `CimatronCustomization.CimatronIntegration`.
- Configuration/logging/file adapters belong in `CimatronCustomization.Infrastructure`.
- `CimatronCustomization.Plugin` is the thin host and explicit composition root only.

## Registration

Register features explicitly in `FeatureComposition`. Reflection discovery and a DI framework are not part of the approved platform.

Each feature publishes a `FeatureDefinition` containing:

- stable feature id;
- business name;
- Validation or Automation kind;
- one or more requirement ids;
- functional group;
- required document context;
- read-only declaration.

Validation features must declare read-only intent. Architectural enforcement is provided by read-only ports; runtime proof is performed in live Cimatron validation.

## Execution

Features implement `IApplicationFeature.Execute(FeatureExecutionContext)`.

The execution context carries the correlation id, current session snapshot, validated rule parameters, and optional run inputs. Rule-parameter population is introduced in Phase 02 Step 02; interactive inputs are expanded in later platform steps.

All normal outcomes use `ResultStatus`. Validation success is `Passed`. Successful modifying Automation execution is `Succeeded`. Runtime/API failures are `Error` and are never converted to `Failed`.

## Findings

A feature may return zero or more `Finding` instances. Findings carry requirement id, canonical status, message, optional measured value/limit with unit, optional current-session entity references, and optional 3D location.

Do not persist `ModelEntityReference` values across sessions and do not assume a Cimatron entity id is stable.

## Parameters

Step 02 implements schema-2 feature parameters. A feature declares `RuleParameterDefinition` metadata (name, type, unit, optional numeric range and required/optional status) on its `FeatureDefinition`. `ExecuteRegisteredFeature` resolves and validates the configured values through `IRuleParameterProvider` before the feature runs, then supplies a `RuleParameterSet` in `FeatureExecutionContext`.

Supported platform parameter types are String, Integer, Decimal, Boolean and ColorCode. Color codes use `#RRGGBB` text representation; mapping that representation to Cimatron display/color values is deferred until the relevant verified Cimatron color API work.

The shipped XML uses configuration schema 2. Schema-1 files are migrated in memory to schema 2 so existing logging settings continue to work. Missing or invalid required values produce a controlled `Error`; there are no invented runtime defaults. Step 02 is file-editable only. Parameter UI editing is intentionally deferred. Do not hard-code customer values into feature logic.

## Document applicability

The common execution pipeline checks `DocumentContextRequirement` before calling the feature. A wrong supported document context returns `NotApplicable`; unavailable application/document returns `Error`.

## Logging

Execute all registered features through `ExecuteRegisteredFeature`. It logs the correlation id, application/Cimatron versions, feature, requirement ids, operation, canonical status, duration, exception context when applicable, and finding count summary. Proprietary geometry is not logged.

## Tests and validation

- Keep pure rules covered in Domain tests.
- Keep orchestration/metadata/applicability in Application tests.
- Preserve architecture tests.
- Cimatron API behavior still requires real supported-Cimatron validation; mocks do not satisfy that gate.
- Read-only customer checks require a live proof that the document is not modified.

## Step 03 launcher/report contract

- Registered features are discovered only through the explicit `FeatureRegistry`; there is no reflection discovery.
- `ListAvailableFeatures` projects feature metadata and current document-context applicability for the Plugin UI.
- The launcher groups features by `FeatureKind` and `FunctionalGroup`. Unavailable features remain visible and cannot be selected for execution.
- `ExecuteFeatureChecklist` runs a selected set sequentially with one shared correlation ID.
- `FeatureFindingView` is the presentation-safe projection used by Plugin UI so Domain finding/value types do not become a new Plugin dependency.
- Result reporting is read-only. Highlight, zoom and pick behavior is intentionally deferred to Step 05.


## Step 04 read-only model access contract

Future validation features must read Cimatron model data through Application ports rather than Interop:

- `IAssemblyStructureReader` — current Assembly component hierarchy, model identity/context, instance state/color and verified placement data.
- `IEntityAttributeReader` — verified entity attributes. Instance/component attribute access remains explicitly unsupported until a documented API contract is established.
- `IEntityColorReader` — instance color and explicit entity `cmAttColor` values.
- `IBodyTopologyReader` — bodies/faces, surface type, area and verified normal-at-point access.

The concrete Cimatron adapter lives in `CimatronCustomization.CimatronIntegration`. Current-session `ModelEntityReference` values are opaque outside that adapter and must never be persisted.

Cimatron 2026 topology code prefers `IBody`/`IFace` where available. General bounding-box access remains `Unsupported` in Step 04 because no authoritative signature was established. See `docs/platform/CIMATRON-2026-MODEL-ACCESS-VERIFICATION.md`.

`FOUNDATION-MODEL-INSPECTION-PROBE` exists only to prove these platform ports and must not contain customer CR logic. It remains a development/foundation feature in this progressive implementation package; the separate D5 client-shipping choice is not silently converted into a client packaging decision here.

## Exception diagnostics

From version 0.14.10, structured JSONL error entries include `exceptionType`, `exceptionMessage`, `exceptionStackTrace`, and `exceptionDetail` (`Exception.ToString()`). This is diagnostic infrastructure only and does not alter feature execution semantics. It exists so live Cimatron interop failures can be resolved from exact stack evidence instead of inference.


## Step 05A viewport highlight contract

`IViewportEntityHighlighter` is the Application-owned boundary for Result Report highlighting. Plugin UI passes only opaque current-session entity-reference strings obtained from `FeatureFindingView`; Plugin does not resolve Cimatron entities and does not reference Domain.

`CimatronViewportEntityHighlighter` is the CimatronIntegration adapter. Version 0.15.0 uses only the verified active-model highlight path: resolve the reference against the active model/session, build a Cimatron entity list, and assign it to `ISelection.Selection`. Normal inability to highlight is returned as controlled `Unsupported`; unexpected Interop/runtime exceptions still propagate.

Step 05A deliberately does **not** implement zoom or interactive picking. The Result Report shows those actions disabled as Unsupported. Nested assembly-instance entity highlighting remains Unsupported in Step 05A. See `docs/platform/CIMATRON-2026-VIEWPORT-HIGHLIGHT-VERIFICATION.md`.

Step 05A is CLOSED / VERIFIED from user-supplied workstation evidence: local quality gate PASS; standalone Part Highlight visibly highlighted the corresponding geometry; nested assembly-instance Highlight returned the controlled Unsupported guard; Zoom and Pick remained disabled as designed.

## Step 05B1 diagnostic Pick boundary (0.15.1)

Interactive Pick remains a foundation diagnostic in `0.15.1`, not a customer-facing CR/SA capability. The spike is deliberately Part-only and uses `CimatronPartPickSpike` + `CimatronDiagnosticPickTool` in CimatronIntegration. The Feature Launcher is strongly retained and modeless for this spike. It hides while the asynchronous Cimatron tool is active and is restored after completion/cancellation. This lifecycle was chosen after live Cimatron evidence showed that hiding the previous modal `ShowDialog()` launcher ended the dialog lifetime and immediately cancelled the PickTool. No Application pick port or Result Report Pick action is promoted until live behavior is verified.

Only `CimatronDiagnosticPickTool` may opt into COM visibility; the integration assembly stays `ComVisible(false)`. No COM registration is assumed or installed. Picked entity IDs are current-session diagnostics only. See `CIMATRON-2026-PICK-TOOL-VERIFICATION.md` for the installed Interop signatures and live questions. Zoom and Assembly/NC Pick remain Unsupported in this increment.



### Step 05B1 closure

Step 05B1 is **CLOSED / VERIFIED** from user-supplied workstation and live Cimatron evidence. The validated lifecycle is: strongly retained modeless Feature Launcher -> asynchronous Part-only PickTool -> owned dedicated result dialog -> explicit foreground return to the Cimatron main window and Feature Launcher. Direct managed-object PickTool handoff does not require COM registration in the validated environment. Esc cancellation, active-document switching during Pick, external window toggling, and repeated foreground restoration were exercised without crash/freeze.

The 0.15.1 spike does not create a production Application Pick abstraction or enable Result Report Pick. Picked entity IDs are current-session only, temporary selection may clear when the tool ends, Assembly/NC Pick remain Unsupported, and Zoom remains Unsupported. Step 05B2 must build only on these verified facts and requires a new approved plan.


## Step 05B2 production Pick contract (0.15.2)

`IViewportEntityPicker` is now the Application-owned boundary for interactive Part picking. Plugin code may request a Pick and present the returned result, but it must not resolve Cimatron COM entities itself. `CimatronViewportEntityPicker` and `CimatronViewportPickTool` own all Cimatron COM/Interop work.

The contract is deliberately assembly-ready even though 0.15.2 runtime support is Part-only. `ViewportPickResult` contains a session-scoped source-document token, entity id, entity type, optional occurrence path, reason code/message and one of the exact outcomes `Picked`, `Cancelled`, `Unsupported`, `Failed`, `Busy`, `StaleResult`. Part occurrence paths are empty.

The source-document token is authoritative for reuse of a picked entity id. File path/title are descriptive only. Consumers must call the picker validation boundary before reusing a prior `Picked` result against live Cimatron geometry; a result whose source token is no longer current becomes `StaleResult` and must not reach a Cimatron entity lookup.

Pick is non-blocking and event-driven. Completion from live PickTool events occurs on the Cimatron STA/UI event thread. Do not block that thread and do not move live COM object access onto `Task.Run`/thread-pool continuations. Caller cancellation is request-scoped via `CancellationToken` and is marshalled back to the captured Cimatron UI synchronization context.

Only one Pick may be active. A second request returns `Busy` and does not cancel the first. The caller supplies allowed entity types; the Cimatron adapter applies them through the verified `cmFilterEntityType`/`FilterType.Add(...)` filter so disallowed types are normally not selectable. Post-pick type validation is a defensive guard only.

The 0.15.1 diagnostic `Pick Spike (Part)` implementation is removed from the Release production source tree. The closed 0.15.1 ZIP and `CIMATRON-2026-PICK-TOOL-VERIFICATION.md` preserve the evidence. The 0.15.2 launcher uses the production port and retains the already verified modeless-window, result-dialog, foreground and focus-return lifecycle.

No coverage exclusions are introduced for Step 05B2. CimatronIntegration pure state tests participate in coverage collection, and the package's measured rate is reported. Real PickTool COM event behavior still requires live Cimatron evidence; automated tests do not substitute for it.

CR-11 dependencies still deferred after 0.15.2 are Assembly/sub-assembly/component occurrence Pick, multi-select (FR-003/FR-004), and Zoom-to-result (FR-014). NC Pick also remains Unsupported.

### Step 05B2 current validation status

User-supplied local quality evidence for the warning-corrected package is clean: Release x64 and all local test/coverage/quality gates PASS with 0 warnings / 0 errors. Live normal Part Pick, Esc cancellation, repeat Pick after Esc, and active-document switching during Pick are PASS. The Busy path is not live-testable through the current launcher because the launcher hides during an active Pick; automated state tests remain the evidence for that contract.

Step 05B2 is **CLOSED / VERIFIED** at version 0.15.4. User-run Release x64 build/tests/coverage/local quality gate passed with 0 warnings / 0 errors. Live validation confirmed normal Pick, Esc/repeat Pick, live Busy protection, elimination of the 0.15.3 false source-close regression, and real source-document-close completion as `Cancelled / SOURCE_DOCUMENT_CLOSED` with safe launcher restoration and no crash. The previously verified document-switch path remains `Cancelled / CIMATRON_TOOL_POPPED`. Assembly/occurrence Pick, multi-select, NC Pick and Zoom remain deferred. The final 0.15.4 `ViewportPickCompleted` JSONL line was not separately supplied in chat and is not claimed as independent live evidence.
