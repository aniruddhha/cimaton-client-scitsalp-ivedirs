# Coverage and Quality Gates

## Purpose

This document defines the baseline quality infrastructure introduced in Phase 01 Step 04. The user executes all tools on the real development workstation and supplies evidence; the AI agent does not claim execution results.

## Local quality sequence

1. Restore pinned development tools with `tools/Restore-QualityTools.ps1`.
2. Close Cimatron so the in-process plugin DLL is not locked.
3. Run Release x64 rebuild with `tools/Invoke-ReleaseBuild.ps1`.
4. Run architecture enforcement with `tools/Invoke-ArchitectureTests.ps1`.
5. Collect coverage with `tools/Invoke-Coverage.ps1`.
6. Evaluate coverage with `tools/Test-CoverageGate.ps1`.
7. Run SonarQube separately with `tools/Invoke-SonarQube.ps1` when server URL, project key, and token are available.

`tools/Invoke-QualityGate.ps1` orchestrates the local steps. It does not silently claim the SonarQube gate.

## Coverage thresholds

The baseline follows AGENTS.md:

| Area | Minimum line coverage |
|---|---:|
| Domain | 90% |
| Application | 90% |
| Design-rule logic | 95% |
| Infrastructure | 80% |
| New/changed code | 90% |
| Critical calculations/safety logic | 95%+ |

At version 0.4.0 the Domain/Application/DesignChecks/Infrastructure projects contain no substantive production C# source beyond assembly metadata. Therefore the coverage gate may report `NOT APPLICABLE` for those governed packages during this foundation step. Once substantive governed source exists, absence from the coverage report becomes a failure.

Cimatron COM/Interop adapter coverage is risk-based and does not replace real Cimatron integration validation.

## Analyzer policy

- `Microsoft.CodeAnalysis.NetAnalyzers` is pinned centrally in `Directory.Build.props`.
- Analyzer and code-style behavior is controlled by the root `.editorconfig`.
- Analyzer execution is enabled during build and live analysis.
- Warnings are reviewed; this baseline does not globally convert every warning to an error because unrelated template/interop warnings must not trigger broad cleanup without approval.

## SonarQube

The repository pins `dotnet-sonarscanner` as a local .NET tool. The SonarQube script requires explicit server inputs and does not store secrets. Tokens must never be committed to the repository.

SonarQube submission does not equal a passing quality gate. The user must provide the actual SonarQube result for review.
