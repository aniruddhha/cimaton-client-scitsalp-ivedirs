# Quality Tooling Baseline

Phase 01 Step 04 establishes the following development-only tooling:

- Visual Studio / MSBuild Release x64 build.
- Roslyn/.NET analyzers plus `.editorconfig`.
- ArchitectureTests executable.
- Microsoft `dotnet-coverage` with Cobertura and XML outputs under `artifacts/coverage/`.
- SonarScanner for .NET for SonarQube Community Build.
- PowerShell orchestration scripts under `tools/`.

## Important operating rule

Cimatron loads the plugin DLL in-process and locks it. Close `CimatronE.exe` before rebuilds that write `CimatronCustomizationPlugin.dll` into the Cimatron Program directory.

## Development-only assets

Tool manifests, analyzer packages, coverage reports, Sonar tooling, tests, and these internal documents are development assets. They are not intended for the production client runtime package.
