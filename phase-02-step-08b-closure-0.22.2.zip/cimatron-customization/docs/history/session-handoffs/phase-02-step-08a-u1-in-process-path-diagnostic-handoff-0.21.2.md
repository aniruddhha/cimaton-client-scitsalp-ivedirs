# Phase 02 — Step 08A U1 In-Process Path Diagnostic Handoff — 0.21.2

## Status

**DIAGNOSTIC PREPARED / AWAITING USER QUALITY GATE + ONE LIVE DIAGNOSTIC RUN**

Step 08A remains open. U1 is Step-07 VERIFIED but is not yet IN-PROCESS VERIFIED.

## Evidence entering this increment

User workstation quality gate `artifacts/console-captures/quality-gate-20261001-015904.txt`:

- Release x64: PASS.
- 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration, Infrastructure tests: PASS.
- Coverage gate: PASS.
- Local quality gate: PASS.
- Exit code: 0.

First controlled Plugin run of `U1 In-Process Geometry Confirmation`:

- Volume: Failed.
- Center: Failed.
- Surface area: Failed.
- No-mutation evidence: Passed.

The screenshot is retained at `artifacts/diagnostics/step-08a-u1-live-validation-failed-20261001.png`.

## Approved diagnostic scope

The user approved a read-only investigation before any further identical live run.

0.21.2 intentionally keeps the current result path unchanged and adds side-by-side evidence:

1. active model/document/path and `GetEntityById` body ID/type/runtime/service-cast information;
2. raw Volume / Center / SurfaceArea from the current `GetEntityById`-derived single-body list;
3. the exact Step 07 entity-type enumeration path (`IEntityQuery` + `cmBody` filter + `Select()`), including all enumerated body IDs/types/service casts and raw U1 values for body ID 4.

The Step 07-equivalent path is evidence only. It is not promoted or substituted in this package.

## Result Report expectations

After running the U1 feature, the report should still contain the original four U1 findings plus three **Warning** evidence rows beginning with:

- `Step 08A diagnostic evidence — Context:`
- `Step 08A diagnostic evidence — CurrentPathRaw:`
- `Step 08A diagnostic evidence — Step07Equivalent:`

Return a screenshot showing all rows. If the third message is too long to read in one screenshot, widen the Message column/window or provide screenshots that expose its complete text.

## No-mutation boundary

The existing document modified-state + saved-file timestamp/length check remains in place and now encloses both diagnostic read paths. Any changed/unverifiable no-mutation evidence raises an error through the normal pipeline.

## Production / CR boundary

- No CR/SA business logic added.
- No model modification.
- No configuration or installer change.
- No other Step 07D-whitelisted capability promoted.
- Step 06 deferred findings remain carried forward unchanged.

## Required user sequence

1. Run the normal quality gate.
2. Only if it is clean, open saved `KA-PART-1` in Cimatron 2026.
3. In the Feature Launcher, check only `U1 In-Process Geometry Confirmation [U1]`.
4. Click `Run Selected`.
5. Return the Result Report screenshot(s), especially all three diagnostic Warning rows.

Do not repeat or change the model between the quality gate and diagnostic run except as required to open the known-answer Part.

## Agent execution boundary

The agent did not build, run tests, execute coverage, launch Cimatron, or claim validation PASS.
