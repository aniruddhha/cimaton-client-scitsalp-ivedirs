# Phase 02 Step 07C-1D — Geometry Verification Execution Handoff — 0.20.5

## Session status

**Context:** GREEN  
**Step:** 07C-1D — execute Geometry Services verification using only locked known-answer IDs.  
**State:** **AWAITING USER 0.20.5 QUALITY GATE + LIVE GEOMETRY EVIDENCE**.

## Validated evidence entering 0.20.5

User workstation 0.20.4 quality gate passed: Release x64 build PASS; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.

Known-answer mapping is now locked from user visual selection plus runtime ID inspection:

- B1 → body ID `4`.
- B2 → body ID `5`.
- B1↔B2 minimum distance → `25 mm`.
- test face → ID `90` (`cmFace`).
- convex edge → ID `89`, convexity `cmConvex` at `0.5`.
- concave edge → ID `95`, convexity `cmConcave` at `0.5`.
- `KA_UCS_90Z` → UCS ID `2` after explicit user activation.
- no-mutation evidence remained `UNCHANGED`.

## Execution order

1. Close Cimatron and run the standard captured quality gate for 0.20.5.
2. After PASS, open standalone `KA-PART-1.elt` directly as a Part document.
3. Explicitly activate `KA_UCS_90Z`.
4. Run:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-geometry --expect Part --ucs-id 2 --entity-a 4 --entity-b 5 --edge-id 89
```

5. Return the generated `api-capability-geometry-*.txt` evidence.
6. Then run the concave-edge check:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-geometry --expect Part --ucs-id 2 --edge-id 95
```

7. Return the second evidence file.

## Deliberately unresolved inputs

Do not guess the through-hole/ray or face-point inputs. Ray origin/direction, through-hole diameter, test-point coordinates, expected face↔point distance, and interpreted UCS bounding-box dimensions still require explicit known-answer evidence before those API calls are interpreted.

## Scope boundary

No production `src/**`, Plugin behavior, configuration, CR/SA logic, Geometry Services implementation logic, or 07C-2/3/4 work changed in 0.20.5. Only diagnostic version labels and mandatory governance/known-answer documentation were updated.
