# Phase 02 Step 05C2 Session Handoff

## Current checkpoint — 0.15.36 Step 05C2-B closed with documented exception

User validation is complete for the final hidden-state investigation path. The 0.15.35 full quality gate is clean: Release x64 build PASS with 0 warnings / 0 errors; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.

The approved final `--probe-occurrence-interfaces` diagnostic queried 528 unique installed-Interop COM IIDs once per known-answer occurrence and immediately released each successful interface pointer. Visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B` exposed identical interface sets. `IProvideClassInfo` was unsupported; `IDispatch.GetTypeInfo` identified `_IAssInstance` for all three. Before/after model evidence remained `UNCHANGED`.

Exactly one supported interface had been missed by the prior visibility-name search: `IEntityQuery` (IID `7AB728E2-2B06-11D4-B7FF-00105ACCAC8E`). Reflection-only members are `CreateFilter`, `GetFilter`, `Select`, and `SetFilter`. There is no hidden/visibility getter, and no newly discovered member was invoked.

**Approved stopping rule applied:** reflection-based hidden-state searching ends here. FR-021 is recorded as:

```text
suppressed: supported
hidden: BLOCKED — pending Cimatron guidance
```

Step 05C2-B is **CLOSED WITH DOCUMENTED EXCEPTION**. This technical closure does not silently change CR-11 product scope. Any decision to ship suppressed-only first requires explicit client/product approval. Hidden occurrence readback remains dependent on authoritative Cimatron guidance; vendor-outreach status is not asserted by this package.

0.15.36 also corrects the stale development-diagnostic version label/banner from 0.15.34 to 0.15.36 only. COM probing logic and production `src/` behavior are unchanged.

### Next action
Do not start another reflection/Interop hidden-state search. Continue to the next approved project step while tracking FR-021 hidden-state as an external/vendor dependency. Reopen this exception only if authoritative Cimatron guidance supplies a supported occurrence-level hidden-state read path, or if client/product scope is explicitly changed.


## Current checkpoint — 0.15.34 final occurrence COM-interface diagnostic

User validation through 0.15.33 is complete:
- 0.15.33 full quality gate PASS: Release x64 build 0 warnings / 0 errors; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.
- 0.15.33 `--reflect-visibility-api` SUCCESS. The five occurrence-context getter entries are not new hidden-state paths: they are `IgnoreInShowOperations` aliases already proven non-discriminating plus `_IAssInstance.get_Show_()`, which remains closed by 0.15.29 `E_NOINTERFACE`. The 14 `cmAttVisibility` / `cmAttBlankLevel` entries are duplicate enum metadata and do not prove occurrence semantics.

Approved 0.15.34 scope is **one final hidden-state diagnostic with a defined stopping rule**. New development-only `--probe-occurrence-interfaces` enumerates all installed Interop COM interface IIDs, deduplicates runtime checks by IID, and calls `Marshal.QueryInterface` once per IID for visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`, releasing every successful pointer immediately. It records `IProvideClassInfo` / `IDispatch.GetTypeInfo` class evidence where supported and emits an interface × object matrix. Supported interfaces missed by the previous name-based visibility search are reflected for getter/setter/method classification **only**; no newly discovered member is invoked.

Expectation: the three occurrence objects will probably expose identical interface sets. This is stated in advance.

**Stopping rule:** if this run yields no new supported interface/member path, stop reflection-based hidden-state discovery. Record FR-021 as `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance` and propose closing Step 05C2-B with that documented exception. Any decision to ship suppressed-only first is a client/product scope decision and must be explicit. Vendor-email status is currently not asserted in package evidence; confirm it if the stop rule triggers.

Immediate next step: run the 0.15.34 full quality gate. After PASS, with the approved known-answer copy active, run:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --probe-occurrence-interfaces
```

Return the console output and generated `occurrence-com-interface-matrix-*.txt`.

## Current checkpoint — 0.15.32 occurrence/component visibility reflection narrowing

User validation of 0.15.30 is complete:
- full quality gate PASS; Release x64 build 0 warnings / 0 errors; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0;
- live ToolVersion 0.15.30 known-answer diagnostic completed read-only with no mutation;
- visible `Block_A`, suppressed `Block_B`, and hidden-not-suppressed `Known_Pocket_Body` all reported `IgnoreInShowOperations=0`, with occurrence `cmAttVisibility` and `cmAttBlankLevel` absent; these compatible candidates do not discriminate hidden state;
- `_IAssInstance.get_Show_()` remains closed by the validated 0.15.29 `InvalidCastException / 0x80004002 (E_NOINTERFACE)` evidence.

Approved 0.15.32 scope is diagnostic-only. `InteropReflectionInventory` now narrows installed-Interop metadata to read-only visibility/display getters on occurrence/component-context interfaces. Newly discovered members are **not invoked**. Production `src/`, Assembly Pick, and production Zoom-to-result remain unchanged. CR-11 FR-021 remains OPEN.

Immediate next step: run the 0.15.32 full quality gate. After it passes, run `CimatronCustomization.ZoomCommandDiscovery.exe --reflect-visibility-api` and return the generated `visibility-api-interop-reflection-*.txt` evidence for analysis. Any runtime getter experiment requires separate approval.


## Current checkpoint — 0.15.30 compatible IAssInstance visibility-candidate comparison

- 0.15.29 user quality gate: PASS, Release x64 build 0 warnings / 0 errors, Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS, coverage/local quality gates PASS, exit code 0.
- 0.15.29 live `--assembly-entities` known-answer run: 9 occurrences, 18 entity inspections, no limits reached, and before/after no-mutation evidence `UNCHANGED`.
- Every tested runtime occurrence rejected `interop.CimMdlrAPI._IAssInstance` with `System.InvalidCastException`, HRESULT `0x80004002 (E_NOINTERFACE)`, including visible `Block_A`, suppressed `Block_B`, hidden-not-suppressed `Known_Pocket_Body`, and the root pseudo-instance. The metadata `Show_` route is closed for these runtime objects.
- 0.15.30 stays on the already-compatible `interop.CimMdlrAPI.IAssInstance` and records only read-only candidates: getter-only `IgnoreInShowOperations`, occurrence-level `GetAttribute(cmAttVisibility, string.Empty)`, and occurrence-level `GetAttribute(cmAttBlankLevel, string.Empty)`.
- Candidate outputs are raw evidence only (`PRESENT value=...`, `ABSENT`, or exact `READ_ERROR` exception/HRESULT). No hidden/visible meaning is assigned before known-answer workstation comparison.
- All setters, Show/Hide mutation, component open/load/activation, production `src/`, Assembly Pick, and production Zoom-to-result remain unchanged/prohibited.
- Next action: user runs the 0.15.30 full quality gate. After PASS, rerun `--assembly-entities` on the same known-answer copy and upload console output plus the generated evidence file for visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B` comparison.

## Current checkpoint — 0.15.28 getter-only occurrence visibility runtime probe

- 0.15.27 user quality gate: PASS, 0 warnings / 0 errors, all required test suites and coverage/local gates PASS.
- 0.15.27 `--reflect-visibility-api`: SUCCESS / exit 0. Exactly one installed `_IAssInstance` copy exists: `interop.CimMdlrAPI._IAssInstance`, GUID `4C8A5941-F526-11D5-B89D-006008719C4A`.
- Reflection proves `get_Show_()` is a property getter; `set_Show_()` is a mutating setter. The earlier C# `as` cast returned null and therefore gave no exception/HRESULT.
- 0.15.28 performs an explicit compatibility cast per occurrence. On failure it records exception type/HRESULT. On success it reads only `get_Show_()` and records the raw integer without assigning semantics.
- Known-answer runtime target: visible `Block_A`, hidden-but-not-suppressed `Known_Pocket_Body`, suppressed `Block_B`; verify before/after no-mutation evidence and exit code 0.
- `cmAttVisibility` / `cmAttBlankLevel` remain body/entity candidates only.
- Production `src/` remains byte-identical to 0.15.27.
- Next action: user runs the elevated quality gate; after PASS, run `--assembly-entities` from normal/non-elevated PowerShell with the known-answer model active and send console + generated evidence.

## 0.15.26 Current Session Update — Hidden Occurrence-State Reflection Discovery

### User-validated 0.15.25 closure evidence
- Full local quality gate PASS: Release x64 build, 0 warnings / 0 errors, all required test suites, coverage gate and local quality gate; exit code 0.
- Non-elevated known-answer `--assembly-entities` run PASS / exit code 0.
- `OccurrencesObserved=9`, `RevisitCount=0`, no depth/occurrence/entity-inspection limit reached, no-mutation `UNCHANGED`.
- Two `Block_A` root-child placements are both emitted with distinct authoritative occurrence paths and known transforms: instance 8 at `[-30,0,20]` and instance 5 at `[100,0,20]`; both have parent/root `-1`. This closes the repeated-occurrence identity defect and confirms `InstanceId` is evidence, not occurrence identity.
- `Block_B` remains `Suppressed=1`; real Mold Pocket body remains `MbPocket(cmAttInteger)=1`.
- Definition-cycle guard is not exercised against a real recursive self-assembly; evidence correctly states that limitation.

### Remaining Step 05C2-B dependency
CR-11 FR-021 requires a read-only way to distinguish a **hidden-but-not-suppressed assembly occurrence** from a visible occurrence. The approved copy model uses `Known_Pocket_Body` as the intended hidden component occurrence. Do not substitute body/entity visibility for occurrence visibility without proof.

### Approved 0.15.26 discovery scope
- Add reflection-only `--reflect-visibility-api`; no live Cimatron attach and no invocation of newly discovered members.
- Search terms: `Show`, `Visible`, `Visibility`, `Hidden`, `Hide`, `Blank`, `Display`, `State`.
- Inventory every installed `_IAssInstance` copy with assembly, namespace/full name, GUID metadata, base interfaces and member signatures.
- Current cast target is `interop.CimMdlrAPI._IAssInstance`; current code uses `instance as ...`. The user-validated result is null/unavailable. Because C# `as` does not throw on incompatibility, current evidence has **no exception type and no HRESULT**; record this explicitly rather than inventing `InvalidCastException`/`E_NOINTERFACE`.
- For every visibility-related member, classify property-get/property-set/get accessor/set accessor/ordinary method. A name such as Show/Hide does not authorize invocation.
- Reflect `cmAttVisibility` and `cmAttBlankLevel` as **body/entity-level candidates only** through the already-proven attribute concept; occurrence semantics remain unproven.
- User will ask Cimatron in parallel for the supported read-only occurrence-hidden API.
- Production `src/`, production Assembly Pick, and production Zoom-to-result remain byte-identical/unchanged.

### Exact next validation
1. User runs the full quality gate for 0.15.26 and provides the capture.
2. Only after a clean gate, run from normal/non-elevated PowerShell:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --reflect-visibility-api
$LASTEXITCODE
```

3. Upload the generated `visibility-api-interop-reflection-*.txt`.
4. Review findings without calling any candidate member. If a read-only occurrence getter is proven by installed Interop and/or Cimatron support, propose a separate runtime validation scope and obtain approval before implementation.

---

## 0.15.25 — Repeated-occurrence identity correction prepared

### User-validated 0.15.24 known-answer evidence
- `CR11_Smoke_Assembly_Prepared.elt` diagnostic completed successfully with `$LASTEXITCODE=0`; no-mutation evidence was `UNCHANGED`; occurrence/entity limits were not reached.
- Real Cimatron Mold Pocket workflow evidence: `PocketPart_CR11_Smoke_Assembly_Prepared`, body entity 10, returned `MbPocket(cmAttInteger)=PRESENT value=1`. This is genuine FR-010 runtime evidence, not a synthetic marker.
- `Block_B` was shown as suppressed in the Cimatron tree and emitted `Suppressed=1`.
- Nested Assembly/child evidence exposed different local vs root-relative transforms.
- The Cimatron tree showed `Block_A(2)`, but the 0.15.24 diagnostic emitted only one `Block_A` and reported `RevisitCount=1`. One emitted `Block_A` was a root child with `InstanceId=8`; the dropped sibling's actual runtime ID remains unknown until the corrected run emits it.
- `Known_Pocket_Body` is the known hidden-but-not-suppressed UI case, but runtime `Show_` remains unavailable because `_IAssInstance` cast fails. Hidden-state detection therefore remains **UNRESOLVED — CR-11 FR-021 dependency**.

### 0.15.25 approved correction
- Occurrence identity is the full traversal path with sibling ordinal; positive `InstanceId` is evidence only and is never a global deduplication key.
- Child path segment is `<positive-id-or-no-id>@ordinal-N`, guaranteeing distinct sibling paths even if IDs collide.
- Cycle protection is ancestry-only and keyed by referenced Assembly definition `IModel.PID`, already part of the approved read-only API surface. Repeated sibling placements of the same definition are allowed.
- If Assembly definition PID is unavailable, do not invent another identity key; depth 16 and occurrence limit 2000 remain the bounded fail-safe.
- Real recursive self-assembly cycle behavior is **not exercised at runtime**; do not claim otherwise.
- No new Cimatron API; no production `src/` changes.

### Required user validation for 0.15.25
1. Run the full quality gate and provide the capture; target is 0 warnings / 0 errors and all required gates PASS.
2. Open the same known-answer Assembly and rerun `--assembly-entities`; capture `$LASTEXITCODE`.
3. Confirm evidence shows both `Block_A` placements with distinct occurrence paths and their known transform offsets, `RevisitCount=0`, suppressed `Block_B`, real `MbPocket=1`, no limits reached, and no-mutation `UNCHANGED`.
4. Hidden-state API remains a separate follow-up investigation after this repeated-occurrence correction is validated.

## 0.15.23 Current Session Update — Step 05C2-B Root Parent Runtime Correction

## 0.15.24 — Separate occurrence/entity budgets; known-answer acceptance remains open

### User-validated 0.15.23 evidence
- Local quality gate: PASS, 0 warnings / 0 errors, required tests/coverage/local gate PASS.
- Real-mold read-only traversal: SUCCESS; 80 occurrences; 490 occurrence-reached body attribute checks; no-mutation evidence `UNCHANGED`.
- Nested recursion and suppressed occurrences were observed.
- `MbCooling(cmAttInteger)=1` was read on body 47 under occurrence `root:-1/8/137`: **MbCooling via occurrence is proven**.
- Shared guard reached `TotalItemsObserved=2000` / `ItemLimitReached=True`; therefore the stress run does **not** prove complete tree traversal.
- `_IAssInstance` cast was unavailable; hidden-state detection remains **UNRESOLVED — CR-11 FR-021 dependency**.
- No `MbPocket` marker was proven through occurrence; this remains open.

### 0.15.24 implementation boundary
- `MaximumOccurrences=2000` and `MaximumEntityInspections=2000` are independent. Entity-budget exhaustion cannot stop occurrence recursion.
- Per-occurrence `EntityInspectionStatus` distinguishes COMPLETE from `ENTITIES_NOT_INSPECTED_ENTITY_BUDGET_EXHAUSTED`, `PARTIAL_ENTITY_INSPECTION_BUDGET_EXHAUSTED`, and `DISABLED_OCCURRENCE_ONLY`. A skipped/partial status is never evidence of attribute absence.
- New optional read-only mode: `--assembly-entities --occurrence-only`; it does not call `GetAllEntities` or attribute APIs.
- Evidence includes total runtime plus both counters/limit flags.
- No new Cimatron API and no production `src/` changes.

### 05C2-B acceptance still required after 0.15.24 gate/runtime
Use a **small known-answer copy assembly** and compare evidence against the Cimatron tree. It must include: (1) one repeated component at a known offset with transform comparison; (2) one body known to carry `MbPocket`; (3) one hidden occurrence; (4) one suppressed occurrence. Hidden-state detection must not be declared solved until a verified read-only signal is found.


User-run 0.15.22 validation is now complete for the local gate: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage gate PASS, local quality gate PASS, exit code 0.

First controlled runtime evidence from `--assembly-entities`:
- attach and active-Assembly discovery succeeded;
- `IAssemblyModel.GetRootInstance()` succeeded;
- root `IAssInstance.ID` returned `-1`;
- `IAssInstance.get_AssParentInstance` on `root:-1` returned COM `E_FAIL` (`0x80004005`).

Approved 0.15.23 correction: do not call `get_AssParentInstance` for the root pseudo-instance. Record parent evidence as `ROOT/N/A`. Keep the parent getter for non-root occurrences. The existing cycle guard remains ID-based only for IDs > 0 and uses the full occurrence path otherwise, so root ID `-1` is never treated as a global stable identity. No other traversal/API/timeout/no-mutation behavior is changed. Production `src/`, Assembly Pick, Highlight and production Zoom-to-result remain unchanged.

Validation for 0.15.23 is awaiting the user's full quality gate; after a clean gate, rerun `--assembly-entities` on the copy of the known test Assembly and return both console output and generated evidence/trace.

## 0.15.22 Current Session Update — Step 05C2-B Checkpoint Guard Correction

User-run 0.15.21 quality gate evidence:
- Release x64 build: PASS.
- Build warnings: 2 x CA1834 in `AssemblyEntityInventory.cs` (`StringBuilder.Append(string)` with single-character constants).
- Architecture Tests: FAIL with `Step 05C2 Assembly entity inventory must retain immediate diagnostic checkpoints around the potentially blocking COM calls.`
- Quality-gate exit code: 1.
- Direct Architecture Tests run reproduced the same failure and exit code 1.

Root cause: the 0.15.21 runtime already checkpoints every approved API call through the common `RunApiCall` wrapper (`BEGIN API` immediately before `call()`, `END API` immediately after success), but the architecture guard still expected old exploratory `GetInstances` / `Select` / `GetFaces` checkpoint strings that were intentionally removed in 05C2-B.

0.15.22 corrects only that stale guard and the two CA1834 warnings. No Cimatron API, traversal semantics, timeout behavior, production `src/`, Assembly Pick, Highlight, or production Zoom-to-result behavior changes. Validation is awaiting the user's full quality-gate rerun. Do not run `--assembly-entities` until that gate passes cleanly.

# Phase 02 Step 05C2 — Session Handoff

## 0.15.21 Current Session Update — Step 05C2-B Prepared

User validation after the original 0.15.15 handoff progressed through 0.15.20. Key verified facts now supersede the older pending section below:

- 0.15.18 root cause for the earlier standalone attach hang was verified as an elevation mismatch: non-elevated Cimatron + non-elevated diagnostic attaches successfully; elevated diagnostic + non-elevated Cimatron fails fast with exit code 6.
- 0.15.20 local quality gate passed with 0 warnings / 0 errors and exit code 0.
- 0.15.20 `--reflect-assembly-api` succeeded and confirmed the installed Cimatron 2026 Assembly occurrence surface without making runtime calls.
- User approved Step 05C2-B implementation only, with production behavior unchanged.

0.15.21 replaces the old exploratory Assembly entity diagnostic path with the approved controlled allow-list:

- `IAssemblyModel.GetRootInstance()`;
- `IAssInstance.get_SubInstances(1, 0)`;
- parent/root/ID/suppression getters;
- controlled `_IAssInstance.get_Show_()`;
- `IAssInstance.get_Transformation(0/1)` plus matrix/vector getters;
- `IAssInstance.GetAllEntities()` plus entity-list count/item and entity type/ID getters;
- occurrence-reached body `IAttributeSink.GetAttribute(cmAttInteger, "MbPocket"/"MbCooling")`;
- `ICimDocument.IsModified()` and `GetPath()` for before/after no-mutation evidence.

Safety controls:

- 15-second timeout observer for every Cimatron API call; timeout exit code 7; watchdog does not call COM;
- maximum depth 16; maximum total observed items 2000;
- stable occurrence-ID cycle guard with full-path fallback;
- exception type + HRESULT + failing call recorded;
- before/after document modified state, path, timestamp, and file length recorded; mismatch exit code 8;
- no calls that open/load/activate/save/suppress/modify component documents; no attribute or transform mutation APIs.

Validation remains workstation-only and must use a **copy** of the known test Assembly. Required known-answer contents: nested sub-assembly, same component placed twice at simple known offsets, hidden occurrence, suppressed occurrence (if distinct), one pocket body, and one cooling body. Compare diagnostic output against the Cimatron Assembly tree.

Production `src/`, production Assembly Pick, and production Zoom-to-result remain unchanged.


## Project
Cimatron 2026 customization project — production plugin architecture with development-only diagnostics for validating Cimatron API behavior before production wiring.

## Phase
Phase 02 — CR Platform Extensions

## Step
Step 05C2 — Controlled Zoom Selection / Assembly occurrence diagnostic validation.

## Version
Handoff package: `0.15.15` (documentation-only handoff update).

Latest code/diagnostic implementation baseline: `0.15.14`.

## Context Status
AMBER — start a new ChatGPT session before further implementation. The technical state is reconstructable and documented, but the current conversation is long enough that continuing implementation here increases context risk.

## Latest Approved Package
`phase-02-step-05c2-session-handoff-0.15.15.zip`

This package is cumulative and extracts to exactly:

`cimatron-customization/`

## Requirement
Continue CR-11 / FR-014 Zoom-to-result prerequisite validation without changing production behavior until the Cimatron 2026 runtime behavior is proven.

The immediate technical objective is to determine a safe Assembly occurrence/entity addressing path for the already-discovered native command:

`&Display,Zoom Selection`

Production Zoom-to-result is **not implemented yet**.

## Approved Scope
The following development-only work has been approved through Step 05C2:

1. Inspect installed Cimatron 2026 interop assemblies for Zoom/Fit/View/Frame/Camera-related APIs.
2. Read the native Cimatron command inventory for active Part and Assembly documents.
3. Perform a controlled development-only `Zoom Selection` validation in a Part document.
4. Keep production Assembly Pick unsupported; do not broaden Step 05B2 production Pick behavior.
5. Add a read-only Assembly entity inventory diagnostic under `tools/CimatronCustomization.ZoomCommandDiscovery`.
6. Add immediate diagnostic checkpoints around the Assembly inventory COM calls to identify the exact blocking API call.
7. Add a developer-only console capture helper for quality-gate and Assembly diagnostic output.
8. Documentation/history/checksum maintenance required by `AGENTS.md`.

No approval exists to wire production Zoom-to-result, enable production Assembly Pick, modify geometry, or execute arbitrary Cimatron commands.

## Completed Work

### Step 05B2 — Production Pick Integration — CLOSED
Version `0.15.4` is the closed/verified Step 05B2 baseline.

User-validated behavior includes:

- normal Part Pick — PASS;
- second click while Pick active — `PICK_ALREADY_ACTIVE` PASS;
- Esc cancellation — `ESC` PASS;
- repeated Pick after Esc — PASS;
- normal entity selection — PASS;
- active-document switch handling — PASS;
- source document close during Pick — `Cancelled / SOURCE_DOCUMENT_CLOSED` PASS;
- no duplicate popup after the final correction.

Production Pick intentionally supports only an active Part document. Assembly and NC remain unsupported.

### Step 05C1 — Zoom command discovery
A dedicated x64 standalone diagnostic tool was added under:

`tools/CimatronCustomization.ZoomCommandDiscovery`

The tool uses the installed Cimatron 2026 interop and attaches through `AppAccess.GetApplication()`.

Reflection evidence from the user's workstation:

- 13 assemblies scanned;
- 251 matching members for Zoom/Fit/View/Frame/Camera terms;
- `IApplication.GetActiveViewOpenGlService` was present;
- `IOpenGLService` exposed `ConvertDrawablePointToViewPoint`, `RedrawFrame`, and `ViewParameters`;
- no direct proven `ZoomToEntity`, `FitEntity`, or equivalent entity-framing API was identified.

Command inventory evidence from both Part and Assembly:

- 1401 commands;
- 74 filtered candidates;
- exact native command present in both contexts: `&Display,Zoom Selection`.

No command was executed during command inventory.

### Step 05C2 — Controlled Part Zoom Selection
Version `0.15.9` added a development-only controlled validation mode.

The user selected Part entity ID `60` in `Z101 Heated Nozzle` and ran the diagnostic. The tool:

- resolved the explicit entity;
- temporarily placed it into the Cimatron selection;
- executed exactly `&Display,Zoom Selection` once;
- restored the prior selection.

Runtime result:

- command returned successfully;
- visible viewport framing/zoom occurred around the selected geometry;
- no model modification was observed.

Result: **Part controlled Zoom Selection validation PASS**.

### Assembly Pick boundary confirmed
When the user switched to Assembly `AMPL_123_top_assm_MD` and attempted the existing production Pick feature, Cimatron correctly returned:

`Part Pick — Unsupported`

Reason:

`DOCUMENT_TYPE_UNSUPPORTED`

This is expected and must remain unchanged unless a separate production Assembly-Pick scope is explicitly approved.

### Assembly entity discovery diagnostic
Version `0.15.10` added development-only `--assembly-entities`.

Its intended path is read-only:

- attach to running Cimatron;
- require active Assembly;
- obtain `IAssemblyModel`;
- recursively enumerate instances through `GetInstances()`;
- inspect Part-instance models;
- use the existing entity-query/filter path to enumerate Bodies and Faces;
- print candidate `InstancePath`, `InstanceId`, `ModelTitle`, `ModelPID`, `EntityType`, and `EntityId`.

It must not select/highlight an entity, execute a Cimatron command, modify a model, or modify viewport state.

### Console capture utility
Versions `0.15.11`–`0.15.13` introduced and corrected:

`tools/Invoke-And-Capture.ps1`

Final validated invocation:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

and:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task assembly-entities
```

The helper:

- displays child-process output live;
- captures stdout/stderr to `artifacts\console-captures\`;
- records timestamps and effective command;
- preserves the child exit code;
- prints the capture-file path.

The 0.15.13 quality-gate capture validated the helper itself.

### 0.15.13 user quality-gate evidence
User-supplied capture reported:

- Release x64 build — PASS;
- 0 warnings;
- 0 errors;
- Architecture tests — PASS;
- Domain tests — PASS;
- Application tests — PASS;
- CimatronIntegration tests — PASS;
- Infrastructure tests — PASS;
- Coverage gate — PASS;
- Local Quality Gate — PASS;
- helper ExitCode — 0.

Coverage reported:

- Domain: 100%;
- Application: 95.75%;
- DesignChecks: 100%;
- Infrastructure: 98.48%;
- CimatronIntegration: 4.57%, measured only, with no threshold introduced in Step 05B2.

### Assembly diagnostic hang
The first `assembly-entities` run under 0.15.13 produced only the console-capture wrapper header and the launched command. The Cimatron diagnostic itself emitted no result before the user manually stopped it with Ctrl+C.

Therefore the exact blocking API call is **not proven**.

### 0.15.14 diagnostic checkpoints
The user approved a diagnostic-only instrumentation update. Version `0.15.14` added timestamped, immediately flushed checkpoints before/after the Assembly inventory COM operations, including:

- `GetApplication()`;
- `GetActiveDoc()`;
- active document/model resolution;
- `GetInstances()`;
- per-instance model resolution;
- entity-query/filter creation;
- `SetFilter()`;
- `Select()`;
- body-list access;
- `GetFaces()`.

The purpose is only to identify the last completed API call before any hang.

No production `src/` behavior changed.

## Pending Work
1. User must run the quality gate for the 0.15.14/0.15.15 cumulative package.
2. If the quality gate passes, run the checkpointed `assembly-entities` diagnostic with an Assembly active.
3. Upload the resulting `assembly-entities-<timestamp>.txt` capture.
4. Identify the exact last successful checkpoint and therefore the blocking call.
5. Propose the smallest diagnostic correction based only on that evidence.
6. Obtain explicit approval before implementing that correction.
7. After safe Assembly entity/occurrence addressing is proven, separately design and approve an occurrence-aware controlled Zoom Selection experiment.
8. Only after successful controlled validation should production Zoom-to-result wiring be proposed.

## Files Added
Relevant additions during this workstream include:

- `tools/CimatronCustomization.ZoomCommandDiscovery/AssemblyEntityInventory.cs`
- `tools/Invoke-And-Capture.ps1`
- `docs/history/session-handoffs/phase-02-step-05c2-handoff.md` (this file)

Earlier Step 05C diagnostic files remain in the tool project.

## Files Modified
Step 05C work has modified only the approved diagnostic/tooling, architecture-guard, documentation, version/history, and checksum surfaces, including:

- `tools/CimatronCustomization.ZoomCommandDiscovery/Program.cs`
- `tools/CimatronCustomization.ZoomCommandDiscovery/ZoomSelectionValidation.cs`
- `tools/CimatronCustomization.ZoomCommandDiscovery/AssemblyEntityInventory.cs`
- `tools/CimatronCustomization.ZoomCommandDiscovery/CimatronCustomization.ZoomCommandDiscovery.csproj`
- `tools/CimatronCustomization.ZoomCommandDiscovery/Properties/AssemblyInfo.cs`
- `tools/Invoke-And-Capture.ps1`
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`
- `docs/platform/CIMATRON-2026-ZOOM-COMMAND-DISCOVERY.md`
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `CHECKSUMS.sha256`

No production `src/` behavior was changed by the Assembly entity discovery/checkpoint work.

## Approved Existing-File Changes
Approved changes are limited to:

- diagnostic tooling needed for Step 05C1/05C2;
- architecture tests that guard the diagnostic scope;
- console-capture tooling;
- platform documentation;
- version, changelog, implementation history, handoff, and checksum metadata.

Do not alter production Cimatron behavior without a new explicit approval.

## Tests Completed
Latest user-validated full gate is **0.15.13**, which passed as described above.

The AI did not execute tests/build/Cimatron runtime validation, in accordance with `AGENTS.md`.

## Quality-Gate Status
- `0.15.13`: **PASS** from user-supplied workstation output, 0 warnings / 0 errors.
- `0.15.14`: **NOT YET USER-VALIDATED** at handoff time.
- `0.15.15`: documentation-only handoff package derived from 0.15.14; **NOT YET USER-VALIDATED**.

## Known Errors
No current compile error is known in the latest package because 0.15.14 has not yet been built on the user's workstation.

Historical resolved issues:

- 0.15.7 diagnostic project compile failure `CS0656` due to missing `Microsoft.CSharp` reference — fixed in 0.15.8.
- standalone attach `0x80040154 Class not registered` — resolved on the workstation by registering `CimAppAccess.dll` with 64-bit `regsvr32` and running Cimatron/PowerShell at matching privilege.
- 0.15.11 helper could not conveniently pass its mandatory script-block through `powershell -File` — redesigned in 0.15.12.
- 0.15.12 `Tee-Object -LiteralPath ... -Append` parameter-set failure under Windows PowerShell 5.1 — fixed in 0.15.13.

## Known Limitations
1. Production Pick remains Part-only. Assembly and NC are unsupported by design in Step 05B2.
2. Production Result Report Zoom button is not wired.
3. The native `&Display,Zoom Selection` command is proven only in the controlled Part experiment.
4. Assembly occurrence-owned entity addressing is not yet proven.
5. The existing controlled validation resolves an entity from the active model by entity ID; a nested Part entity ID may not be resolvable from the root Assembly model.
6. Do not assume an occurrence-owned Part entity can be placed directly into root Assembly selection. That requires runtime evidence.
7. The exact `assembly-entities` blocking API call is still unknown until the 0.15.14 checkpointed run is captured.

## Important Decisions
- Do not broaden production Assembly Pick merely to support this diagnostic.
- Do not promote `&Display,Zoom Selection` to production until both safe entity addressing and runtime behavior are proven.
- Use installed Cimatron 2026 interop/runtime behavior as authoritative evidence.
- Keep the standalone diagnostic tool development-only and outside production project dependencies.
- Keep experiments read-only unless a separately approved controlled command execution is explicitly stated.
- Do not claim PASS without user workstation evidence.
- Keep chat responses concise; detailed engineering documentation belongs in the package.
- Every implementation change requires explicit user approval before modification.

## Cimatron API Findings
Verified/observed during this workstream:

- `AppAccess.GetApplication()` can attach from the standalone diagnostic when COM registration and privilege match are correct.
- `IApplication.GetActiveDoc()` is used for active-document context.
- active Part and Assembly command pools both expose `&Display,Zoom Selection`.
- the controlled Part experiment proves native Zoom Selection can visually frame a selected Part entity.
- reflection found `IApplication.GetActiveViewOpenGlService` and `IOpenGLService` members such as `RedrawFrame` and `ViewParameters`, but no direct proven entity-framing method.
- `IAssemblyModel.GetInstances()` and the model-inspection APIs already exist in production integration code; the new diagnostic intentionally reuses established API names rather than inventing new ones.
- runtime safety of the current Assembly inventory traversal is not yet proven because the 0.15.13 probe hung.

## Exact Next Step
**Do not implement anything first.**

From repository root, with Cimatron completely closed, the user should run:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

Upload the generated:

`artifacts\console-captures\quality-gate-<timestamp>.txt`

If and only if the quality gate passes, the next runtime step is:

1. launch Cimatron normally;
2. activate an Assembly document (the previously used `AMPL_123_top_assm_MD` is suitable);
3. in normal/non-elevated PowerShell matching Cimatron privilege, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task assembly-entities
```

4. if it hangs, wait only long enough to observe the last checkpoint, then stop with Ctrl+C;
5. upload `artifacts\console-captures\assembly-entities-<timestamp>.txt`.

The next agent must use the **last emitted checkpoint** as evidence for the blocking call and must not guess a fix.

## Files To Read First
The next ChatGPT session must read, in this order:

1. `AGENTS.md` — completely, before planning or changing anything.
2. `docs/history/session-handoffs/phase-02-step-05c2-handoff.md` — this handoff.
3. `VERSION.md`.
4. `IMPLEMENTATION-HISTORY.md` — especially 0.15.4 through 0.15.15 entries.
5. `CHANGELOG.md` — latest entries.
6. `docs/platform/CIMATRON-2026-ZOOM-COMMAND-DISCOVERY.md`.
7. `tools/CimatronCustomization.ZoomCommandDiscovery/AssemblyEntityInventory.cs`.
8. `tools/CimatronCustomization.ZoomCommandDiscovery/ZoomSelectionValidation.cs`.
9. `tools/CimatronCustomization.ZoomCommandDiscovery/Program.cs`.
10. `tools/Invoke-And-Capture.ps1`.
11. `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs` relevant diagnostic guards.

If the new session receives fresh workstation capture files, read those before proposing any code change.

## New-Session Starting Instruction
Use this exact prompt with the package attached:

> Continue the Cimatron 2026 customization project from the attached Phase 02 Step 05C2 handoff package. Read `AGENTS.md` completely first, then read `docs/history/session-handoffs/phase-02-step-05c2-handoff.md` and the listed files in its **Files To Read First** section. Do not implement anything until you reconstruct the approved scope and check the latest user validation. Step 05B2 is closed at 0.15.4. Current work is Step 05C2 Assembly occurrence/entity diagnostics for Zoom-to-result. Production Assembly Pick and production Zoom-to-result must remain unchanged unless separately approved. Follow AGENTS.md response-length and approval rules strictly.

## 0.15.27 compile-fix status
- User-run 0.15.26 quality gate failed before runtime discovery validation with `CS0136` at `InteropReflectionInventory.cs(362,37)`: local `value` conflicted with an enclosing lambda parameter under C# 7.3.
- The same run also had Program Files deployment `MSB3021` access-denied errors because the quality gate was not elevated.
- Approved 0.15.27 correction renames only the conflicting local to `guidValue`; discovery semantics and production `src/` remain unchanged.
- Next validation: run the full quality gate from elevated PowerShell. If clean, run `--reflect-visibility-api` and capture the resulting evidence.

## 0.15.31 — Session handoff checkpoint for new chat

### Current position
- Phase 02 — CR Platform Extensions.
- Step 05C2-B — Hidden occurrence-state validation remains in progress.
- Production `src/` remains unchanged by 0.15.26 through 0.15.31 diagnostic/documentation increments.
- Production Assembly Pick and production Zoom-to-result behavior must remain unchanged.
- Step 06 — Excel/tabular input reader remains after Step 05 closes.

### Last validated package / evidence
- 0.15.29 quality gate: user-run PASS. Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage/local quality gates PASS; exit code 0.
- 0.15.29 live known-answer traversal: clean read-only run, 9 occurrences, 18 entity inspections, no traversal/entity/depth limits, no mutation.
- `_IAssInstance` runtime compatibility experiment is closed: every tested occurrence rejected `interop.CimMdlrAPI._IAssInstance` with `System.InvalidCastException`, HRESULT `0x80004002 (E_NOINTERFACE)`. Therefore `get_Show_()` is not a usable occurrence visibility path for the runtime objects returned by the current traversal.
- Repeated-occurrence identity remains proven by full sibling-ordinal occurrence path; both `Block_A` placements are distinct and `RevisitCount=0`.
- `Block_B` suppression remains proven (`Suppressed=1`).
- Real Mold Pocket evidence remains proven (`MbPocket(cmAttInteger)=1`).
- `Known_Pocket_Body` is the intended hidden-but-not-suppressed known-answer occurrence for CR-11 FR-021 comparison.

### Current package awaiting workstation validation
- Version: 0.15.30.
- Package: `phase-02-step-05c2-compatible-iassinstance-visibility-candidate-comparison-0.15.30.zip`.
- Purpose: stop the incompatible `_IAssInstance.Show_` route and compare only read-only candidate signals available through the already-compatible `IAssInstance` runtime object.
- Candidate reads added:
  - getter-only `IAssInstance.IgnoreInShowOperations`;
  - occurrence-level `GetAttribute(cmAttVisibility, string.Empty)`;
  - occurrence-level `GetAttribute(cmAttBlankLevel, string.Empty)`.
- Raw values/errors are evidence only. Do not assign hidden/visible semantics in advance.
- No setter, Show/Hide mutation, component activation/opening, or production `src/` change is permitted.
- 0.15.30 quality gate has NOT yet been supplied by the user.
- The most recent uploaded diagnostic after 0.15.30 packaging was actually the older 0.15.28 evidence file (`ToolVersion: 0.15.28`), so it does not validate 0.15.30.

### Immediate next actions in the new session
1. Read `AGENTS.md` completely before planning or changing anything.
2. Treat this handoff plus `VERSION.md`, `CHANGELOG.md`, and `IMPLEMENTATION-HISTORY.md` as the current project state.
3. Ask the user to run the 0.15.30 full quality gate from Administrator PowerShell:
   `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate`
4. Analyze the supplied quality-gate capture. Do not claim PASS without user evidence.
5. Only after a clean gate, with the known-answer assembly open and matching Cimatron/PowerShell elevation, run:
   `& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ZoomCommandDiscovery.exe" --assembly-entities`
   followed by `$LASTEXITCODE`.
6. Inspect the new `assembly-occurrence-entity-diagnostic-*.txt` and compare `IgnoreInShowOperations`, `cmAttVisibility`, and `cmAttBlankLevel` for both visible `Block_A` occurrences, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`.
7. Preserve read-only/no-mutation evidence. Do not infer FR-021 semantics unless the known-answer values clearly and reproducibly discriminate the hidden occurrence.
8. If a new code/documentation correction is required, list exact files/reasons/risks/tests and obtain scope-specific user approval before editing.

### New-chat continuation prompt
```text
Continue the Cimatron 2026 customization project from the attached 0.15.31 session-handoff package. Read AGENTS.md completely first, then read docs/history/session-handoffs/phase-02-step-05c2-handoff.md, VERSION.md, CHANGELOG.md, and the relevant IMPLEMENTATION-HISTORY.md entries before planning anything. Follow AGENTS.md strictly and keep chat responses small/medium; detailed engineering documentation belongs inside the package.

We are in Phase 02 — CR Platform Extensions, Step 05C2-B — Hidden occurrence-state validation. Production src, Assembly Pick, and production Zoom-to-result must remain unchanged unless separately approved.

Important current state:
- 0.15.29 quality gate is user-validated PASS: Release x64 build 0 warnings/0 errors; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local gate PASS; exit code 0.
- The 0.15.29 known-answer live run proved `_IAssInstance` is not exposed by the runtime occurrence objects: explicit cast failed for every occurrence with InvalidCastException / HRESULT 0x80004002 (E_NOINTERFACE). Do not pursue `_IAssInstance.get_Show_()` further unless new authoritative Cimatron evidence justifies it.
- Repeated occurrence identity, Block_B suppression, transforms, and real MbPocket evidence are already proven.
- CR-11 FR-021 hidden occurrence detection remains open. `Known_Pocket_Body` is the intended hidden-but-not-suppressed known-answer occurrence.
- 0.15.30 is the current diagnostic package awaiting user validation. It reads only compatible IAssInstance candidates: getter-only IgnoreInShowOperations plus occurrence-level cmAttVisibility and cmAttBlankLevel. Raw values are evidence only; no semantics are assigned in advance.
- No 0.15.30 quality-gate evidence has been accepted yet. The last uploaded diagnostic was an older ToolVersion 0.15.28 file and must not be treated as 0.15.30 evidence.

Immediate next step: ask me to run the 0.15.30 full quality gate. After it passes, guide me through the live --assembly-entities run on the known-answer assembly and analyze the new candidate visibility values without changing production behavior.
```



## 0.15.33 validation checkpoint
- User-run 0.15.32 quality gate: Release x64 build PASS, 0 warnings / 0 errors; Architecture Tests FAIL; exit code 1.
- Failure is a static diagnostic architecture-contract mismatch, not a production/runtime failure.
- Required correction: restore the four legacy `_IAssInstance` cast-evidence marker strings in `InteropReflectionInventory.cs`: `CurrentCastTarget`, `CurrentCastMechanism`, `CurrentCastExceptionType`, `CurrentCastHRESULT`.
- `_IAssInstance.get_Show_()` remains closed by 0.15.29 `E_NOINTERFACE` evidence. 0.15.30 compatible candidates remain non-discriminating. FR-021 remains open.
- Production `src/`, Assembly Pick, and production Zoom-to-result remain unchanged.
- Immediate next step: run the full 0.15.33 quality gate. Only after PASS run `--reflect-visibility-api`.

## 0.15.35 — Warning-only correction checkpoint

- User-run 0.15.34 quality gate completed with all test/coverage/local gates PASS and exit code 0, but the Release build emitted three CA1859 warnings in the new development-only `OccurrenceComInterfaceInventory.cs`.
- 0.15.35 changes only the flagged property declarations: `Aliases` and `ReflectedMembers` use concrete `List<T>`; `Support` uses concrete `Dictionary<Guid,T>`.
- No diagnostic behavior or approved COM-interface probing method changes. No production `src/`, Assembly Pick, or production Zoom-to-result changes.
- Next step: rerun the full quality gate. Do not run `--probe-occurrence-interfaces` until the user supplies a clean 0-warning/0-error gate result.
- After the clean gate, run exactly one final hidden-state interface probe. If it finds no new supported interface/member path, stop reflection-based hidden-state searching and record FR-021 as `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance`; then propose Step 05C2-B closure with that documented exception.
