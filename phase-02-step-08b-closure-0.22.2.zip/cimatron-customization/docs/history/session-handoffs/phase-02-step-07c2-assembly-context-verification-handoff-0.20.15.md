# Session Handoff — Phase 02 / Step 07C-2 Assembly Context Verification

## Version
0.20.15

## Context Status
GREEN

## Approved Scope
User-approved 07C-2 plan:

- 07C-2A is user-recorded Cimatron UI/Measure known-answer evidence only; no API-under-test may establish its own expected transform/state/gap/bounding-box values.
- 07C-2B+C is one development-diagnostic corrective package followed by one governed quality gate and one live KA-ASM-1 run with visual highlight observation.
- unresolved behavior after the single live run is documented as limitation unless a separately approved corrective is required.

## Implemented in 0.20.15
- Guarded `IsSuppressed` and `Lock` occurrence reads.
- Local/root occurrence transformation matrix/vector evidence.
- `GetInstancesByModel` evidence retained.
- Per-matching-occurrence `GetAssemblyEntity`.
- Explicit `InstanceByAssemblyEnt` origin/reverse ID `MATCH` / `MISMATCH`.
- Optional `--ucs-id` support for `GetAssemblyBoundingBox`; active UCS fallback when omitted.
- `MinDistancePos` across every pair of matching occurrences; each record includes occurrence IDs, nesting depth, distance and both closest points.
- User-visible highlight pause for every matching assembly-context entity.
- Selection restoration covers both captured non-empty selection and originally-empty selection.
- Before/after no-mutation evidence retained.

## Production Impact
None. No production `src/**`, Plugin, CR/SA implementation, configuration, installer or Cimatron model data changed.

## Validation State
**AWAITING USER EXECUTION.** The AI agent did not run build/tests/Cimatron. U7-U12 remain unverified until user evidence is supplied.

## User Action — 07C-2A first
Before the live verifier run, record from Cimatron UI/Measure tools:

1. exact root assembly title;
2. nested sub-assembly title;
3. exact KA-PART-1 model title used by `--model-title`;
4. visible/repeated occurrences and UI placement transforms;
5. suppressed occurrence;
6. nested KA-PART-1 occurrence and UI placement transform;
7. locked occurrence and expected lock state;
8. intended cross-component body pair and UI Measure minimum distance;
9. expected assembly bounding box and which UCS is used.

Do not derive these expected values from the verifier APIs. Body/entity IDs may reuse evidence-backed API IDs where the UI does not expose them.

## Then Run
First run the governed quality gate:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

Only after it passes, run one assembly-context command using the exact known-answer values:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-assembly-context --expect Assembly --model-title "<EXACT_MODEL_TITLE>" --entity-id <BODY_ENTITY_ID> --ucs-id <ASSEMBLY_UCS_ID> --highlight
```

If the assembly UCS ID has not been independently mapped, omit `--ucs-id`, explicitly activate the intended UCS before execution, and report that active-UCS choice with the evidence.

During the run, visually inspect each highlighted match and press Enter only after observing it. The tool then restores the prior selection.

## Return Evidence
- the filled 07C-2A known-answer values;
- quality-gate capture;
- generated `api-capability-assembly-context-*.txt`;
- whether each temporary highlight corresponded to the expected occurrence, especially the nested occurrence;
- screenshot where practical.

## Expected Next Decision
Compare the live evidence against the independently recorded UI known answers and update U7-U12. Do not start another runtime experiment automatically.
