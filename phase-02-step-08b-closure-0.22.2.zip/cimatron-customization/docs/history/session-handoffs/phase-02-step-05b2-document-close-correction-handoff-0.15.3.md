# Phase 02 Step 05B2 — Document-Close Correction Handoff — 0.15.3

## Current state

- Phase 02 — CR Platform Extensions
- Step 05B2 — Production Pick Integration
- Version 0.15.3
- Status: correction implemented; **AWAITING USER EXECUTION**
- Previous user-validated baseline: warning-corrected 0.15.2 local quality gate PASS; live normal Pick/Esc/repeat/document-switch PASS; source-document close FAIL.

## Approved correction implemented

The source-document-close defect is addressed without changing the Application Pick contract or Plugin UI.

1. `CimatronViewportEntityPicker` starts a request-scoped 250 ms monitor after `PushPickTool` succeeds.
2. Every monitor observation is marshalled to the captured Cimatron STA/UI `SynchronizationContext`; live COM access is never moved to the timer worker thread.
3. The monitor uses the existing verified `IApplication.GetActiveDoc()` identity path. Four consecutive observations where the source token is no longer current are required before lifecycle completion.
4. The confirmation window gives the already live-verified active-document-switch `OnToolPoped` path time to complete normally first.
5. If the Pick is still active after the persistent source loss, the managed PickTool completes directly as `Cancelled` / `SOURCE_DOCUMENT_CLOSED`. It does not call `PopTool` against the disappeared source document.
6. `ViewportPickSessionState.TryComplete` is the ownership gate. Only the first completion releases the strong PickTool reference and clears lifecycle state. Any late duplicate COM callback is ignored at the adapter boundary.
7. Existing PickTool completion logging remains in use, so the expected close-document result includes one `ViewportPickCompleted` entry.

## Files changed

Production:
- `src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityPicker.cs`
- `src/CimatronCustomization.CimatronIntegration/ViewportPickSessionState.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronViewportPickTool.cs`
- production assembly version metadata under `src/*/Properties/AssemblyInfo.cs`

Tests:
- `tests/CimatronCustomization.CimatronIntegrationTests/ViewportPickStateTests.cs`

Traceability/bookkeeping:
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/platform/CIMATRON-2026-PICK-TOOL-VERIFICATION.md`
- `docs/platform/CR-PLATFORM-GUIDE.md`
- this handoff
- `CHECKSUMS.sha256`

## Automated regression intent

Pure CimatronIntegration state tests now verify:
- active tool is strongly retained;
- first completion releases it;
- duplicate/late completion is rejected;
- persistent source-document mismatch requires the configured confirmation count;
- a current-source observation resets mismatch accumulation.

These tests do not prove live Cimatron COM behavior.

## Required user execution

1. From repository root, run:
   `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-QualityGate.ps1`
2. Confirm Release x64 build and all test/coverage/local-quality gates.
3. Deploy the new Plugin DLL using the existing project procedure.
4. Live regression:
   - normal Part Pick;
   - Esc cancellation;
   - repeat Pick after Esc;
   - active-document switch during Pick;
   - close the source Part document while Pick is active.
5. For the close case expect exactly one result:
   - outcome `Cancelled`;
   - reason `SOURCE_DOCUMENT_CLOSED`;
   - launcher/result UI returns safely;
   - one new `ViewportPickCompleted` log entry;
   - a subsequent Pick can start normally.
6. Continue the remaining Step 05B2 live cases only after the correction above is green.

## Important limitations

- 0.15.3 is not claimed PASS until the user supplies workstation and live Cimatron evidence.
- Busy is still not live-testable through the current launcher.
- Assembly/occurrence Pick, NC Pick, multi-select and Zoom remain deferred.
- Cimatron exit during active Pick remains `NOT TESTED` unless deliberately and safely exercised.
