# Phase 02 Step 05B1 -> Step 05B2 Session Handoff

Version: `0.15.1`
Date: 2026-09-26
Context health: GREEN

## 1. Mandatory startup sequence for the next session

Before planning or changing code:

1. Read `AGENTS.md` completely.
2. Read this handoff completely.
3. Read `VERSION.md`, `CHANGELOG.md`, and `IMPLEMENTATION-HISTORY.md`.
4. Read `docs/platform/CIMATRON-2026-PICK-TOOL-VERIFICATION.md`.
5. Read `docs/platform/CIMATRON-2026-VIEWPORT-HIGHLIGHT-VERIFICATION.md`.
6. Read `docs/platform/CR-PLATFORM-GUIDE.md`.
7. Treat 0.15.1 as the closed verified baseline.
8. Prepare a Step 05B2 plan and obtain explicit user approval before implementation.

## 2. Closed baseline

Phase 02 Step 05B1 — Part-only Pick Spike is **CLOSED / VERIFIED**.

Final user-supplied quality evidence:

- Release x64 build: PASS.
- Warnings: 0.
- Errors: 0.
- Architecture tests: PASS.
- Domain tests: PASS.
- Application tests: PASS.
- Infrastructure tests: PASS.
- Coverage collection/gate: PASS.
- Local quality gate: PASS.
- Coverage: Domain 100%; Application 95.41%; DesignChecks 100%; Infrastructure 98.48%.

Final live Cimatron evidence:

- Direct managed-object `PushPickTool` handoff without COM registration: PASS.
- Part face pick completion: PASS.
- Current-session entity ID capture: PASS.
- Esc cancellation/tool cleanup: PASS.
- Dedicated result dialog remains reachable after external window toggles: PASS.
- Feature Launcher returns to front when Cimatron regains foreground: PASS.
- Closing result dialog returns focus to Cimatron/Feature Launcher: PASS.
- Active-document switching during Pick: PASS.
- No crash/freeze reported during the validated scenarios.

## 3. Verified installed Cimatron boundary

Installed assembly evidence used for 0.15.1:

- `interop.CimBaseAPI, Version=2026.201.2064.662`
- `interop.CimMdlrAPI, Version=2026.201.2064.662`
- `IToolContainer.PushPickTool(interop.CimBaseAPI.Tool, IEntityFilter, IEntityFilter, Int32)` is the verified push boundary.
- `interop.CimBaseAPI.Tool` is an interface inheriting `ITool`.
- The managed diagnostic tool implements the verified tool/event interfaces recorded in `CIMATRON-2026-PICK-TOOL-VERIFICATION.md`.
- Only the approved diagnostic PickTool class is COM-visible; the CimatronIntegration assembly remains `ComVisible(false)`.
- No COM registration/RegAsm/registry write is required for the validated direct managed-object handoff.

Do not invent or substitute an unverified Pick API.

## 4. Validated lifecycle that must not regress

The Feature Launcher is modeless and strongly retained. It hides while the asynchronous PickTool is active and restores when the tool completes/cancels. A dedicated owned result dialog is used for completion/cancellation. Foreground recovery is intentionally limited so the launcher is not permanently TopMost. After the result dialog closes, foreground returns to the captured Cimatron main window and then the launcher is restored/activated.

The architecture/source-contract tests protect these choices. Do not revert to a modal `ShowDialog()` launcher or broad permanent TopMost behavior without a new approved architecture change.

## 5. Session/reference rules

Picked Cimatron entity IDs are **current-session diagnostics only**. They are not stable persisted identifiers and must not be stored or reused across Cimatron sessions. Step 05B2 should use an Application-facing abstraction that preserves this session-scoped nature rather than exposing durable-ID semantics.

Temporary selection clearing when the PickTool ends is accepted 0.15.1 behavior. If Step 05B2 wants persistent post-pick visual feedback, it should explicitly reuse the already verified Step 05A Highlight capability after a successful Pick rather than assuming the PickTool selection will persist.

## 6. Step 05B2 objective

Step 05B2 should convert the verified Part-only diagnostic spike into a proper product architecture increment. Planning should consider:

- an Application-owned Pick port/result contract;
- controlled supported/unsupported/cancelled/error semantics;
- Plugin/Result Report integration without moving Cimatron COM concerns into Application/Domain;
- explicit session-scoped entity reference handling;
- optional explicit re-highlight after successful Pick using the verified Step 05A highlight port, if approved;
- lifecycle ownership/cancellation using the verified modeless launcher behavior;
- focused unit/architecture tests and live Cimatron validation.

This is a planning target, not implementation authorization.

## 7. Still Unsupported / out of scope unless separately verified and approved

- Assembly Pick.
- NC Pick.
- Zoom/display transformation.
- Durable persistence/reuse of picked entity IDs.
- Unverified nested assembly-instance Pick semantics.
- Any model mutation/write operation.
- Unrelated refactoring, dependency upgrades, warning cleanup, or architecture changes.

## 8. Step 05A state

Step 05A Viewport Highlight (`0.15.0`) remains CLOSED / VERIFIED and must not regress. Active Part highlighting through the verified `ISelection.Selection` boundary works. Nested assembly-instance highlighting remains controlled Unsupported. Zoom remains Unsupported.

## 9. Required Step 05B2 planning output

Before coding, the next session must provide the user with:

- exact Step 05B2 scope;
- proposed architecture and runtime flow;
- every new file;
- every existing file proposed for modification and why;
- Cimatron API facts being reused vs any facts still requiring verification;
- assumptions/risks;
- TDD/test plan;
- quality-gate plan;
- live Cimatron validation plan;
- explicit exclusions;
- proposed next version.

Then wait for explicit approval.

## 10. Closure statement

The 0.15.1 closure package changes documentation/handoff/checksums only. Production and test code from the user-validated warning-corrected 0.15.1 baseline is unchanged. Step 05B2 has not started.
