# Phase 02 Step 07C-3 — Known-Answer Attribute Name-Observation Corrective Handoff — 0.20.22

## Baseline

0.20.21 quality gate is user-validated PASS (`quality-gate-20260930-125811.txt`): Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gate PASS, exit code 0.

## Runtime evidence entering this corrective

User reran the controlled setup against active `KA-PART-1` and observed:

```text
ReadBack.Name:
ReadBack.Type: cmAttString
ReadBack.Value: KNOWN_ANSWER_07C3
KNOWN-ANSWER SETUP FAILED: System.InvalidOperationException: Exact attribute read-back did not match the requested name/type/value.
```

The helper had already executed exact `GetAttribute(cmAttString, args.AttributeName)` and passed the null guard. The returned type and value matched; only returned `IAttribute.Name` was blank.

## Approved corrective

0.20.22 changes only the post-lookup validation:

- exact named `GetAttribute(cmAttString, requestedName)` remains unchanged;
- non-null remains mandatory;
- returned type must still be `cmAttString`;
- returned value must still equal `KNOWN_ANSWER_07C3`;
- returned `IAttribute.Name` remains printed/recorded as evidence but is not an equality gate.

No alternate API, overwrite behavior, auto-save, model/entity/name/value change, production `src/**` change, or read-only 07C-3 verifier change is included.

## Validation status

**AWAITING USER WORKSTATION QUALITY GATE.** Agent did not build/test/run Cimatron and does not claim PASS for 0.20.22.

After the quality gate passes, reopen a clean `KA-PART-1` and rerun the same controlled setup command. Do not save unless the helper reports `ATTACHED_AND_READ_BACK`. After success, manually save the Part and reopen/reload `KA-ASM-1` before the separate read-only 07C-3 verification.
