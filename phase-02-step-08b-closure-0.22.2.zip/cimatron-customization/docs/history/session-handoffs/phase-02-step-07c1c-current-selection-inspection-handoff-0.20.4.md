# Phase 02 Step 07C-1C — Current Selection Inspection Handoff — 0.20.4

## Session status

**Context:** GREEN  
**Step:** 07C-1C — capture actual selected face/edge IDs without guessing.  
**State:** implementation prepared; **AWAITING USER QUALITY GATE + LIVE SELECTION EVIDENCE**.

## Evidence already established

User workstation 0.20.3 quality gate passed. Live `KA-PART-1` discovery established:

- Part context, unit mm;
- body IDs `4` and `5`;
- B1/B2 minimum distance `25 mm`;
- after explicit user activation of `KA_UCS_90Z`, active UCS entity ID `2`;
- no-mutation evidence `UNCHANGED`.

The user visually confirmed B1 as the large complex left body and B2 as the separate rectangular right body. The user also visually selected the intended test face, but its runtime ID is not yet known.

## Added command

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --inspect-current-selection --expect Part
```

The command reads only the selection that already exists. It records selected count plus each selected entity's actual ID/type. For a selected edge it also records `GetEdgeConvexity(..., 0.5)`. It never assigns `ISelection.Selection`.

## User execution order

1. Close Cimatron and run the standard captured quality gate.
2. After PASS, open the validated standalone `KA-PART-1.elt` directly as a Part document.
3. Select **only the intended test face**.
4. Run the command above.
5. Return the generated `api-capability-current-selection-*.txt` evidence.
6. After the test-face ID is recorded, repeat the same process for one intended convex edge and one intended concave edge.

Do not run `--verify-geometry` until required target IDs/known-answer values are complete. Do not start 07C-2.

## Scope boundary

No production source, Plugin behavior, configuration, CR/SA logic, or 07C-2/3/4 work is included.

## Validation rule

The agent did not execute build/tests/Cimatron. 0.20.4 remains unvalidated until user workstation evidence is supplied.
