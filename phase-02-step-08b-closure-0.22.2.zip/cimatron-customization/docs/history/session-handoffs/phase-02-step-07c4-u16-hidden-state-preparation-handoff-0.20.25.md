# Phase 02 Step 07C-4 — U16 Hidden-State Verification Preparation — 0.20.25

## Context Status
GREEN

## Current State
- Step 07C-3: CLOSED / USER VALIDATED.
- Step 07C-4: IMPLEMENTATION PREPARED / AWAITING USER WORKSTATION QUALITY GATE + SINGLE LIVE RUN.
- Production `src/**`: unchanged.
- Finalized known-answer copy: `KA-ASM-1-U16-HiddenBody-Control`.

## Approved Scope
Verify U16 / CR-11 FR-021 using one governed read-only run that separates:
1. normal visible occurrence + visible body;
2. hidden-not-suppressed occurrence + otherwise-visible body;
3. visible occurrence + hidden body;
4. suppressed occurrence.

Also classify `cmNoFiltering` versus `cmVisibleOnly` BOM membership as a separate candidate read-only route.

## Implementation Prepared
`HiddenStateCandidateVerification` now:
- records `IAssInstance.IsSuppressed` and occurrence title;
- enumerates occurrence-reached entities through `IAssInstance.GetAllEntities()`;
- maps body entities to assembly context and reads `ICimEntity.Show` getter only;
- records body counts and IDs so the two-body visible occurrence can be compared without assigning semantics in code;
- exports both BOM filters to the governed Step07 temp folder;
- records raw and comparable BOM rows, normalizing the leading ordinal field for comparison;
- records exact rows present only in `cmNoFiltering` or only in `cmVisibleOnly`;
- retains the single-run stopping rule and no-mutation evidence.

## API Basis
Retained 07A reflection evidence records `ICimEntity.Show` as `Int32 Show` getter/setter. This verifier calls only the getter. `IBOM.Export`, `cmNoFiltering`, and `cmVisibleOnly` were already runtime-verified in Step 07C-3.

## Classification Rule After Runtime Evidence
Report separately:
- whether `Show` distinguishes the hidden occurrence;
- whether `Show` distinguishes the hidden body inside a visible occurrence;
- whether it reflects both/neither;
- whether `cmVisibleOnly` BOM membership distinguishes the hidden occurrence.

Only an occurrence-hidden discriminator supports the per-occurrence FR-021 requirement. If neither `Show` nor BOM membership discriminates the known hidden occurrence, retain FR-021 hidden-state support as BLOCKED pending Cimatron guidance.

## User Run Order
1. Run the normal repository quality gate.
2. Only if the quality gate passes, open `KA-ASM-1-U16-HiddenBody-Control` in Cimatron and run exactly once:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" `
  --verify-hidden-state-candidates `
  --expect Assembly
```

3. Send the generated `api-capability-hidden-state-candidates-*.txt` evidence file.

## Validation State
No build/test/Cimatron execution was performed by the agent. 0.20.25 remains AWAITING USER EXECUTION.
