# Phase 02 Step 07C-1A — Geometry Known-Answer Discovery Handoff — 0.20.3

## Session status

**Context:** GREEN

**Step:** 07C-1A — establish actual `KA-PART-1` identifiers/values before 07C-1 Geometry Services verification.

**State:** implementation prepared; **AWAITING USER QUALITY GATE + LIVE DISCOVERY EVIDENCE**.

## Why this package exists

The validated 0.20.2 tool accepts geometry verification IDs but does not discover them. The Step 07 handoff prohibits guessed IDs. Version 0.20.3 therefore adds one narrow read-only developer-diagnostic mode and does not start 07C-2.

## Added mode

```text
--discover-geometry-targets --expect Part
```

It records:

- unit, model title and `ModelPID`;
- body IDs/types and body volume/centre/surface area;
- active-UCS per-body bounding boxes when available;
- exact two-body minimum distance and closest points when two bodies are present;
- face IDs/types;
- edge IDs/types and edge-convexity observations at parameter `0.5`;
- active UCS ID when exposed as an entity;
- UCS candidates using only runtime-discovered installed enum names containing `UCS`;
- before/after no-mutation evidence.

It does not infer B1/B2/test face/convex edge/concave edge/UCS roles from ID or enumeration order.

## User execution order

1. Extract the ZIP over a disposable project working directory.
2. Run the standard captured quality gate:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

3. Only after the quality gate passes, open validated `KA-PART-1` in Cimatron.
4. Activate `KA_UCS_90Z` if Cimatron permits it.
5. Run:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --discover-geometry-targets --expect Part
```

6. Return the console output and generated `api-capability-geometry-known-answer-discovery-*.txt` file.

## Required interpretation before 07C-1

From the evidence, record and confirm:

- B1 entity ID;
- B2 entity ID;
- one intended convex edge ID;
- one intended concave edge ID;
- intended test face ID;
- `KA_UCS_90Z` entity ID;
- body dimensions/volume/centre/bounding-box evidence and B1↔B2 minimum distance.

Ray origins/directions and the test point must still be model-confirmed before the corresponding 07C-1 calls. Missing values must not be invented.

## Scope boundary

No `src/**`, Plugin behavior, production configuration, CR/SA logic, or Step 05 diagnostic was changed. 07C-2/3/4 remain unexecuted.

## Validation rule

Agent did not execute build/tests/Cimatron. Do not mark 0.20.3 PASS until user workstation evidence is returned.
