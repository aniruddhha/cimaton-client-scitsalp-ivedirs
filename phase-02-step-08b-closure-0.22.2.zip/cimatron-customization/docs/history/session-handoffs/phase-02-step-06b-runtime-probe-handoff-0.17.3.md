# Phase 02 Step 06B — Cimatron Runtime Probe Handoff — 0.17.3

## Validated baseline entering this package
- 0.17.2 user-run full quality gate: PASS.
- Release x64 build and Architecture/Domain/Application/Cimatron Integration/Infrastructure tests: PASS.
- Coverage gate and local quality gate: PASS; exit code 0.
- Infrastructure coverage: 91.02% (minimum 80%).
- Filesystem preflight after build found `ExcelDataReader.dll` 3.9.0.0 and `System.ValueTuple.dll` in `C:\Program Files\Cimatron\Cimatron\2026.0\Program`.

## Why 0.17.3 exists
Filesystem presence does not prove in-process CLR binding and reader execution inside `CimatronE.exe`. Step 06B requires one controlled live read before closure.

## Changes
- Added Plugin `TabularReaderRuntimeProbe.cs`.
- Modified only the Plugin command entry point to check the opt-in probe variable before ordinary launcher behavior.
- Added `tools/Start-Step06BTabularProbe.ps1`.
- Bumped Plugin assembly version to 0.17.3 and updated release/history documentation.
- Production `ExcelTabularDataReader` is unchanged.

## Trigger and safety
The probe runs only when `CIMATRON_STEP06B_TABULAR_PROBE_FILE` is set in the Cimatron process environment. Normal launches without that variable continue the existing Feature Launcher path.

The probe:
- reads only the existing deterministic BIFF8 `LegacyInput.xls` fixture;
- expects worksheet `Input` and known-answer `Block_A / 1.2344 / 12.5`;
- records process name/PID, base directory, reader result, and loaded Plugin/Infrastructure/ExcelDataReader/System.ValueTuple versions and locations;
- performs no Cimatron model API read/write and no CR-04/CR-22 business behavior;
- writes a text evidence file and shows PASS/FAIL.

## Required validation
1. Close Cimatron.
2. Run the standard full quality gate for 0.17.3 and return the capture.
3. Only after the gate passes, from a normal/non-elevated PowerShell matching normal Cimatron execution, run:
   `powershell -ExecutionPolicy Bypass -File .\tools\Start-Step06BTabularProbe.ps1`
4. In the launched Cimatron instance, open a disposable supported Part/Assembly document if needed so the registered command is visible.
5. Click `Cimatron Customization` once.
6. Expect a Step 06B probe PASS/FAIL message. The ordinary Feature Launcher should not open in this explicitly triggered probe process.
7. Return the generated `artifacts\console-captures\step06b-tabular-probe-*.txt` evidence file.
8. Close the probe-launched Cimatron process before any further build.

## Closure rule
Do not close Step 06B unless the evidence proves:
- process is `CimatronE`;
- known-answer read succeeds and values match;
- `ExcelDataReader` is loaded from the expected Cimatron Program deployment path with version 3.9.0.0;
- there is no binding/load exception;
- no second/unintended Cimatron process behavior is observed by the operator.

`System.ValueTuple` may report `NOT_LOADED` if the executing .NET Framework path does not require loading that facade/assembly; this alone is not a failure. Any binding exception or unexpected loaded path/version blocks 06B closure.
