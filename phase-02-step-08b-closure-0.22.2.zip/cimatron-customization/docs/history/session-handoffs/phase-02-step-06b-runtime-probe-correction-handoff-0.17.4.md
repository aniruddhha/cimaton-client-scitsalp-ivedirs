# Phase 02 Step 06B — Runtime Probe Architecture Correction Handoff — 0.17.4

## Trigger
User-run 0.17.3 quality gate built successfully with zero warnings/errors but stopped at Architecture Tests. Running `CimatronCustomization.ArchitectureTests.exe` directly reported that the Plugin contained an unexpected top-level production source file.

## Root cause
`TabularReaderRuntimeProbe.cs` had been added at the Plugin project root. The established architecture test intentionally whitelists exactly five top-level Plugin sources so the Plugin remains a thin Cimatron entry point.

## Correction
- Moved the unchanged probe implementation to `src/CimatronCustomization.Plugin/Diagnostics/TabularReaderRuntimeProbe.cs`.
- Updated only the Plugin project compile include path.
- Did not relax or edit the architecture test.
- Did not change `ExcelTabularDataReader`, CR-04/CR-22 logic, Cimatron model access, or the opt-in trigger semantics.

## Validation required
1. Run the full local quality gate.
2. Only after PASS, run `tools/Start-Step06BTabularProbe.ps1`.
3. Return the probe evidence file for review.

## Status
Prepared; workstation validation pending.
