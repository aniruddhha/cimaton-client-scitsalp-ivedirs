# Phase 02 Step 05B2 — Session Handoff — 0.15.2

## Purpose

Continue Step 05B2 — Production Pick Integration from the latest warning-corrected `0.15.2` package. Read `AGENTS.md` completely before planning or changing code. This handoff records the exact approved contract, user-supplied quality-gate evidence, live Cimatron evidence, the current blocker, and the next approval boundary.

## Current status

- **Phase:** 02 — CR Platform Extensions
- **Step:** 05B2 — Production Pick Integration
- **Version:** `0.15.2`
- **Baseline:** Step 05B1 / `0.15.1` CLOSED / VERIFIED
- **Current state:** OPEN — LIVE VALIDATION IN PROGRESS / DOCUMENT-CLOSE DEFECT
- **Context:** AMBER
- **Production correction approval:** NOT YET GIVEN for the document-close lifecycle correction

## Mandatory working protocol

Follow `AGENTS.md` strictly.

- Keep chat responses concise / small-to-medium.
- Put detailed engineering notes in the development package.
- Do not modify production behavior without explicit user approval.
- The user runs builds, tests, quality gates, and live Cimatron validation.
- Never claim PASS without user-supplied workstation evidence.
- Maintain `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, verification docs, handoffs, and `CHECKSUMS.sha256`.
- Do not move to the next step until Step 05B2 is formally closed.

## Step 05B1 closed baseline

Step 05B1 proved the real Part-only PickTool boundary and is CLOSED / VERIFIED in `0.15.1`.

Verified facts carried forward:

- `IToolContainer.PushPickTool(...)` is the installed/live boundary.
- Managed PickTool works without COM registration.
- `Tool`, `IToolEvents`, `IPickToolEvents`, and `IFigureEvent` are the implemented interfaces.
- Esc cancellation works.
- Active-document switching can clean up the PickTool.
- The launcher is strongly retained and modeless while Pick is active.
- Dedicated result-dialog and launcher foreground/focus handling were live-verified.
- Picked IDs are current-session values only.
- Assembly Pick, NC Pick, multi-select, and Zoom were not enabled.

Reference package: `phase-02-step-05b1-part-pick-spike-0.15.1-closed.zip`.

## Approved Step 05B2 production contract

### Application boundary

Production port: `IViewportEntityPicker`.

Final outcome set:

- `Picked`
- `Cancelled`
- `Unsupported`
- `Failed`
- `Busy`
- `StaleResult`

The contract is non-blocking/event-driven.

### Assembly-ready result shape

Even though runtime support remains Part-only in `0.15.2`, the result shape includes:

- session-scoped source-document token;
- optional document title/path metadata;
- entity ID;
- entity type;
- optional occurrence/instance path;
- reason code/message;
- outcome.

Occurrence path remains empty for Part.

### Document identity / stale-result rule

A file path is not authoritative identity. Each observed Cimatron document receives a session-scoped token. Unsaved documents still receive a token. Closing/reopening the same file must produce a newly observed document/token. Entity IDs are valid only against the originating token/current session. Before reuse, consumers validate the source token. Invalid reuse returns `StaleResult`; stale IDs must not be passed deeper into Cimatron APIs.

### Threading

Pick completion is delivered from the Cimatron PickTool COM event path on the Cimatron STA/UI thread. Do not synchronously block that thread and do not access live COM objects from thread-pool continuations. Caller cancellation is request-scoped and marshalled to the captured UI synchronization context.

### Concurrency

Only one Pick may be active. A second request returns `Busy`, does not cancel the first request, and must not push another PickTool.

### Selection scope

`0.15.2` supports Part single-select. Caller-supplied Body/Face/Edge filtering is applied through the Cimatron PickTool filter where supported; post-pick validation is defensive only.

Deferred: Assembly/occurrence Pick, multi-select, NC Pick, Zoom.

### Caller cancellation

Caller-initiated cancellation is supported through a request-scoped `CancellationToken`, in addition to Esc.

### Diagnostic spike disposition

The `0.15.1` diagnostic Pick Spike is not retained as dead Release production UI/code. Its evidence is preserved by the closed package, implementation history, and Pick verification document. Production logic may reuse/refactor the proven behavior.

### Coverage rule

No coverage exclusion may be added silently. Any future exclusion requires exact file/member + reason + explicit user approval. CimatronIntegration remains measured even though no minimum threshold was introduced for this step.

## Current implementation packages

Initial implementation:

`phase-02-step-05b2-production-pick-integration-0.15.2.zip`

Latest implementation baseline used for validation:

`phase-02-step-05b2-production-pick-integration-warning-corrected-0.15.2.zip`

The warning-only correction fixed six `CA1806` warnings and one `CA1861` warning in Application test code only. No production Pick behavior changed.

## Latest user-supplied quality-gate evidence

The latest warning-corrected `0.15.2` package was run by the user and produced:

- Build succeeded
- **0 warnings / 0 errors**
- Release x64 build: PASS
- Architecture tests: PASS
- Domain tests: PASS
- Application tests: PASS
- CimatronIntegration tests: PASS
- Infrastructure tests: PASS
- Coverage collection: PASS
- Coverage gate: PASS
- Local quality gate: PASS

Measured coverage:

- Domain: **100%**
- Application: **95.75%**
- DesignChecks: **100%**
- Infrastructure: **98.48%**
- CimatronIntegration: **3.44% measured**; no threshold was introduced in Step 05B2

## Live Cimatron validation completed so far

### Normal Part Pick — PASS

User selected a Part face using `Pick Entity (Part)`.

Observed:

- outcome `Picked`;
- entity ID returned (example: `60`);
- entity type `Face`;
- source-document token present;
- document metadata present;
- reason `ENTITY_PICKED`;
- correlation ID present;
- result dialog foreground behavior correct;
- Cimatron remained responsive.

### Esc cancellation — PASS

Observed:

- outcome `Cancelled`;
- reason `ESC`;
- source-document identity retained;
- launcher/result UI restored;
- no crash/freeze.

### Repeat Pick after Esc — PASS

After an Esc cancellation and closing its result dialog, a new Pick could start immediately and complete normally. No stale active-Pick state was observed.

### Busy live case — NOT TESTED THROUGH CURRENT UI

The Feature Launcher intentionally hides while Pick is active and reappears only when that Pick ends. Therefore the user cannot issue a second Pick request through the current launcher while the first is active. Automated state tests cover `Busy`; do not claim a live PASS.

### Active-document switch during Pick — PASS

User started Pick and switched to another open Cimatron document.

Observed:

- outcome `Cancelled`;
- reason `CIMATRON_TOOL_POPPED`;
- source document identity retained;
- launcher returned;
- result dialog shown;
- no crash/freeze.

### Active source document closed during Pick — FAIL / CURRENT BLOCKER

User opened two documents, started Pick on one document, then closed that active source document before selecting an entity.

Observed:

- source document closed successfully;
- **no result/cancellation popup appeared**.

User then inspected the JSONL Pick logs. The recent `0.15.2` entries showed normal Pick completions, but **no new `ViewportPickCompleted` entry for the close-document test**. Therefore do not claim that `OnToolPoped` or any normal completion path fired for this case.

This is materially different from the active-document-switch path.

## Current defect and proposed correction

The production adapter currently cannot guarantee completion when the source document is closed during an active Pick. Live evidence shows that relying on the normal PickTool pop/event path is insufficient for this scenario.

The proposed narrow correction is:

1. Detect that the active Pick's **source document has disappeared/closed**.
2. Complete the pending request exactly once.
3. Return `Cancelled` with reason `SOURCE_DOCUMENT_CLOSED`.
4. Release the strong PickTool reference.
5. Clear the active-Pick state.
6. Restore the Feature Launcher/result UI safely.
7. Ignore/prevent any late COM callback from completing the same request a second time.
8. Add automated lifecycle/state tests for this transition.
9. Preserve all already validated behavior: normal Pick, Esc, repeat Pick, document switch, focus/z-order behavior, no COM registration, and Step 05A Highlight.

**Important:** Do not implement this correction until the user explicitly approves it in the new chat.

## Remaining live acceptance work after correction

Continue only after the document-close correction is approved, implemented, quality-gated, and deployed:

- close source document during active Pick -> safe controlled completion;
- no active document -> controlled `Unsupported` or defined `Failed`, no crash;
- stale-result rejection after source document is no longer current / reopen case;
- caller-initiated cancellation;
- disallowed entity type filtering;
- launcher/result focus regression check;
- no second/unintended Cimatron process;
- Cimatron exit during active Pick only if safe.

If the Cimatron-exit case is not exercised, record exactly `NOT TESTED — <reason>`; never infer PASS.

## CR-11 deferred dependencies

Explicitly keep deferred:

- Assembly/sub-assembly/component occurrence Pick;
- multi-select for FR-003 / FR-004;
- Zoom-to-result for FR-014;
- NC Pick.

## Next action

Start the new session by reading `AGENTS.md` and this handoff. Then obtain explicit user approval for the document-close lifecycle correction before changing production code.

────────────────────────────────────────  
PROJECT STATUS  
Phase        : Phase 02 — CR Platform Extensions  
Step         : Step 05B2 — Production Pick Integration  
Version      : 0.15.2  
Context      : AMBER  
Build        : PASS — 0 warnings / 0 errors  
Tests        : PASS  
Coverage     : PASS  
Normal Pick  : PASS  
Esc          : PASS  
Repeat Pick  : PASS  
Document Switch: PASS  
Busy Live    : NOT TESTED THROUGH CURRENT UI  
Document Close: FAIL / INCOMPLETE  
Next Action  : Obtain approval, then implement document-close lifecycle correction  
────────────────────────────────────────
