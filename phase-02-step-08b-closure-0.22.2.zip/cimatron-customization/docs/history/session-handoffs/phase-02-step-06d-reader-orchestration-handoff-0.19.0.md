# Phase 02 — Step 06D Reader Orchestration Handoff — 0.19.0

## State

- Phase: 02 — CR Platform Extensions.
- Step: 06D — Reader Orchestration / Architecture Integration.
- Version: 0.19.0.
- Context: GREEN at packaging time.
- Latest validated baseline entering 06D: 0.18.3 CSV-ledger closure package.
- 06D status: IMPLEMENTED / AWAITING USER QUALITY GATE AND LIVE CIMATRON PROBE.

## Approved scope

Three work items under one approval:

1. safe header discovery and source-consistency protection;
2. canonical Application orchestration using existing `ResultStatus`;
3. real Cimatron live probe through `ReadMappedTabularData`.

## Completed implementation

### 1. Safe discovery and two-pass consistency

- Added `TabularHeaderSourceDefinition`, `TabularHeaderDiscoveryResult`, and `ITabularHeaderReader` in Application.
- `ExcelTabularDataReader` implements `ITabularHeaderReader`.
- Discovery applies the same existence, extension, and maximum-file-size controls as row reading.
- Row reading has a consistency overload that receives the discovered ordered header snapshot.
- If the pass-two header row differs in length, order, spelling, case, or value from the discovery snapshot, the reader returns `TABULAR_HEADERS_CHANGED` before mapped rows are accepted.
- `TabularSourceDefinition` was not weakened or made partially configured.

### 2. Canonical orchestration

- Added `ReadMappedTabularData`.
- Flow: Discovery → Mapping → Read → Validation.
- Added `ReadMappedTabularDataResult` using Domain `ResultStatus` only.
- Success: `ResultStatus.Passed`, stage `Completed`.
- Controlled failure: `ResultStatus.Error` with stage `Discovery`, `Mapping`, `Read`, or `Validation`.
- No new free-text status or alternate success/failure enum exists.

### 3. Live probe

- Existing Plugin diagnostic `TabularReaderRuntimeProbe` now constructs the generic mapping and invokes `ReadMappedTabularData` using `ExcelTabularDataReader` for both header and row adapters.
- New `tools/Start-Step06DTabularProbe.ps1` writes a one-shot Step 06D request.
- The script does not start Cimatron; the user starts Cimatron normally and invokes the registered command once.
- Normal Plugin UI is unchanged when no valid probe request exists.

## Tests prepared

Application:
- canonical Passed result on success;
- discovered header snapshot forwarded to the reader;
- Discovery failure short-circuits;
- Mapping failure short-circuits;
- Read/header-consistency failure identifies Read stage;
- Validation failure identifies Validation stage.

Infrastructure:
- header discovery is subject to the same maximum-file-size guard;
- source changed between discovery and read returns `TABULAR_HEADERS_CHANGED` with no partial table.

Existing CSV/XLSX/XLS, worksheet, missing-column, conversion, row-limit, and oversize behavior remains covered by the existing Infrastructure test suite.

## Explicit exclusions

- CR-04 business logic.
- CR-22 business logic.
- Customer-specific DO/slider-table layouts.
- Plugin UI changes.
- Cimatron model modification.
- Dependency version changes.
- Unrelated refactoring/cleanup/warning work.

## Required user validation

### A. Quality gate

From repository root:

```powershell
Get-ChildItem -Path . -Recurse | Unblock-File
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

Send the resulting `quality-gate-*.txt`.

Expected before live probe:
- Release x64 build PASS;
- 0 warnings / 0 errors;
- Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS;
- coverage gate PASS;
- local quality gate PASS;
- exit code 0.

### B. Live Cimatron mapped-tabular probe

Only after the quality gate is GREEN:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Start-Step06DTabularProbe.ps1
```

Then:
1. Start Cimatron normally using the normal user workflow.
2. Open a disposable Part/Assembly document if needed so the registered customization command is visible.
3. Click the Cimatron Customization command once.
4. Send the generated `step06d-tabular-probe-*.txt` evidence.

Expected evidence includes:
- `OrchestrationResult: PASS`;
- `OrchestrationStage: Completed`;
- one known-answer row;
- expected Part/SteelGrade/Weight values;
- `ProbeResult: PASS`.

## Step 06 closure boundary

After 06D, no additional architecture expansion is planned. Step 06 can be closed when the user has supplied GREEN quality-gate and live-probe evidence and explicitly approves closure. WP8 closure must cover the generic reader, configuration-driven mapping, controlled failures, approved dependency, orchestration, and live probe.

## Files to read first in a new session

1. `AGENTS.md`
2. this handoff
3. `docs/platform/STEP-06-TABULAR-INPUT-CONTRACT.md`
4. `VERSION.md`
5. `IMPLEMENTATION-HISTORY.md`
6. `CHANGELOG.md`
7. `docs/time-tracking/PROJECT-TIMESHEET.csv`

## Continuation prompt

> Continue the Cimatron customization project from the attached Step 06D 0.19.0 package. Read `AGENTS.md` completely, then `docs/history/session-handoffs/phase-02-step-06d-reader-orchestration-handoff-0.19.0.md`. Step 06D implementation is prepared but not validated. First review the user-supplied 0.19.0 quality-gate capture. If it is fully GREEN, instruct the user to run the Step 06D live Cimatron mapped-tabular probe. Do not close Step 06 or begin CR-04/CR-22 until both evidence sets are reviewed and explicit Step 06 closure approval is received. Keep chat concise and maintain the authoritative CSV time ledger.
