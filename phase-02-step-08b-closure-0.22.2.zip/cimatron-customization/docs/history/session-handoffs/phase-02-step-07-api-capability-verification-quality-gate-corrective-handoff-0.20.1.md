# Phase 02 Step 07 — Quality-Gate Corrective Handoff — 0.20.1

## Status

0.20.0 user quality gate **FAILED** during Release x64 compilation: 0 warnings / 12 errors, exit code 1. 0.20.1 contains the narrow Step 07 diagnostic compile correction and is **AWAITING USER QUALITY GATE**.

## Evidence entering this corrective package

`quality-gate-20260929-141352.txt` reported compiler errors only in `tools/CimatronCustomization.ApiCapabilityVerification/`. No Architecture/Domain/Application/CimatronIntegration/Infrastructure test or coverage PASS is inferred because the build failed first.

## Corrective changes

- Add `Microsoft.CSharp` framework reference required by COM/dynamic interop conversion.
- Explicitly cast installed variant/object returns to `double[]` for `BodiesCenter`, `GetBoundingBoxByUCS`, `GetPiercingPoints`, and `GetAssemblyBoundingBox`.
- Use explicit object typing for `get_SubInstances(1, 0)` observation.
- Call `GetEntityPointDistance(ICimEntity, object, out IPointData)` and record distance plus returned point.
- Bump the development diagnostic/version records to 0.20.1.

## Unchanged boundary

No production `src/**`, `config/**`, existing `tools/CimatronCustomization.ZoomCommandDiscovery/**`, unrelated tests, `AGENTS.md`, CR/SA behavior, or Step 06 deferred finding is changed.

## Required user sequence

1. Extract/unblock 0.20.1.
2. Run the full captured quality gate from Administrator PowerShell.
3. Return the new `quality-gate-*.txt`.
4. Do **not** run 07A or any 07C runtime probe until the quality gate is clean with 0 warnings / 0 errors and exit code 0.
