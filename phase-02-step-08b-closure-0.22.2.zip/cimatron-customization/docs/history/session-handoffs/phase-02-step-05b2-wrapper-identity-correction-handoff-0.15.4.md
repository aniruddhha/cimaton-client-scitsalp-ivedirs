# Phase 02 Step 05B2 — Wrapper-Identity Regression Correction Handoff — 0.15.4

## Current state

- Phase 02 — CR Platform Extensions
- Step 05B2 — Production Pick Integration
- Version 0.15.4
- Context: GREEN
- Status: narrow live-regression correction implemented; **AWAITING USER EXECUTION**
- 0.15.3 user quality gate: PASS, 0 warnings / 0 errors; Architecture, Domain, Application, CimatronIntegration, Infrastructure, coverage collection/gate and local quality gate PASS.

## Live evidence leading to 0.15.4

1. Closing the source Part during active Pick produced the intended `Cancelled / SOURCE_DOCUMENT_CLOSED` result.
2. Closing the popup produced no duplicate popup.
3. Regression: later `Pick Entity (Part)` actions falsely produced the same source-closed result while the source Part was still open.

## Root cause

The 0.15.3 watchdog used `SessionDocumentIdentityRegistry` tokens to determine whether the source document remained current. The registry is intentionally keyed by the observed managed document object. A repeated `GetActiveDoc()` can provide a different managed COM wrapper for the same underlying live document, so wrapper-keyed token inequality cannot safely represent document closure.

## 0.15.4 correction

- The watchdog no longer uses session-document token equality for lifecycle detection.
- It reads the current Part model on the captured Cimatron STA/UI context and compares the current `IModel.PID` with the source model PID captured at Pick start.
- Matching source model PID + Part document type is treated as current even if the managed document wrapper instance differs.
- A different/no active Part model is a mismatch observation, not an immediate close result. Four consecutive 250 ms mismatches are still required.
- This preserves priority for the already live-verified normal document-switch `OnToolPoped` path.
- Exactly-once session completion, strong PickTool release, late duplicate suppression and direct `SOURCE_DOCUMENT_CLOSED` completion are unchanged.

## Production files changed

- `src/CimatronCustomization.CimatronIntegration/CimatronViewportEntityPicker.cs`
- production assembly version metadata under `src/*/Properties/AssemblyInfo.cs`

## Tests changed

- `tests/CimatronCustomization.CimatronIntegrationTests/ViewportPickStateTests.cs`

Regression intent:
- same source model PID stays current despite managed-wrapper identity changes;
- repeated same-source probes never accumulate source-loss state;
- a different Part model/no active model does not match source lifecycle identity.

## Traceability/bookkeeping

- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/platform/CIMATRON-2026-PICK-TOOL-VERIFICATION.md`
- `docs/platform/CR-PLATFORM-GUIDE.md`
- this handoff
- `CHECKSUMS.sha256`

## Required user execution

1. Run `powershell -ExecutionPolicy Bypass -File .\tools\Invoke-QualityGate.ps1`.
2. Deploy/reload the 0.15.4 Plugin DLL using the existing procedure.
3. Start `Pick Entity (Part)` several times with the same source Part still open. Expected: **no `SOURCE_DOCUMENT_CLOSED` popup**; normal Pick remains available and selected entities complete normally.
4. Re-test Esc and repeat Pick after Esc.
5. Re-test normal document switch during active Pick. Expected: existing controlled switch cancellation path, not source-close misclassification.
6. Re-test closing the source Part during active Pick. Expected exactly one `Cancelled / SOURCE_DOCUMENT_CLOSED` result and no duplicate popup.
7. Check the corresponding `ViewportPickCompleted` log entry for the close case.

## Limitations

- 0.15.4 is not PASS until the user provides workstation quality-gate and live Cimatron evidence.
- Busy remains not live-testable through the current hidden-launcher UI.
- Assembly/occurrence Pick, NC Pick, multi-select and Zoom remain deferred.
