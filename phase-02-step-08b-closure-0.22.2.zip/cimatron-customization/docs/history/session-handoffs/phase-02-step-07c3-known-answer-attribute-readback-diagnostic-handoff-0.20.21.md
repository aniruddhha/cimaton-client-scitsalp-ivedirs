# Phase 02 Step 07C-3 — Known-Answer Attribute Read-Back Diagnostic Corrective Handoff — 0.20.21

## Status

**PREPARED / AWAITING USER WORKSTATION QUALITY GATE + CONTROLLED SETUP RERUN.**

0.20.20 workstation quality gate is user-validated PASS. The first controlled setup run then reached `Attach()` and failed the exact read-back comparison. U13 remains NOT VERIFIED.

## Approved corrective

Only the development-only setup helper is corrected for observability. After exact `GetAttribute(cmAttString, name)` returns, it now prints actual:

- `ReadBack.Name`
- `ReadBack.Type`
- `ReadBack.Value`

before executing the existing equality comparison. A mismatch still throws and stops.

## Safety boundary

Unchanged from 0.20.20:

- active Part must be `KA-PART-1`;
- entity ID must be `4` and `cmBody`;
- type is `cmAttString`;
- name/value are exactly `STEP07_B1_TEST_ATTRIBUTE = KNOWN_ANSWER_07C3`;
- overwrite is prohibited;
- `--apply` is mandatory;
- no Save/SaveAs/Close;
- no alternate mutation/read-back API;
- read-only 07C-3 verifier unchanged;
- production `src/**` unchanged.

## Recovery before rerun

The failed 0.20.20 run may have mutated the active model in memory because failure occurred after `Attach()`. Close `KA-PART-1` **without saving**, reopen it, and only then perform the next setup attempt.

## User validation sequence

1. With Cimatron closed, run the standard repository quality gate for 0.20.21.
2. Return the full quality-gate capture.
3. Only after that gate is reviewed as PASS, reopen clean disposable `KA-PART-1` and rerun the same setup command.
4. Return the full console output showing the new `ReadBack.*` lines.
5. Do not save on a mismatch. Save manually only after `ATTACHED_AND_READ_BACK` is confirmed.

## Current capability status

- U13 — **NOT VERIFIED**.
- U14 — **NOT AVAILABLE**.
- U15 — **NOT VERIFIED**.
- U16 — reserved for 07C-4; untouched.
- U17 — **NOT AVAILABLE FROM RETAINED 07A EVIDENCE**.

No 0.20.21 PASS is claimed until user workstation evidence is returned.
