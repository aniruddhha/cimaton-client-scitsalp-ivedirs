# Phase 02 Step 07C-3 — Known-Answer Body Attribute Setup Helper Handoff — 0.20.20

## Status

**PREPARED / AWAITING USER WORKSTATION QUALITY GATE + CONTROLLED SETUP RUN.**

0.20.19 is workstation-validated by user evidence `quality-gate-20260930-120311.txt`: Release x64 build PASS, 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage/local gates PASS; exit code 0.

No 0.20.20 PASS is claimed. The AI agent did not build/tests/coverage or run Cimatron.

## Approved purpose

Prepare the disposable Step 07 known-answer B1 body with an unambiguous body-level attribute without adding mutation to the existing read-only `--verify-component-properties` path.

Diagnostic attribute:

- entity: `KA-PART-1` body ID `4`;
- type: `cmAttString`;
- name: `STEP07_B1_TEST_ATTRIBUTE`;
- value: `KNOWN_ANSWER_07C3`.

The existing Part/model material `1.2738` remains a separate known answer for BOM/material evidence and is not body-attribute proof.

## Verified API basis

Before implementation, the official Cimatron API documentation was rechecked for the mutation path used by this helper: `IApplication.GetAttributeFactory()`, `IAttributeFactory.Create(AttributeEnumType, string)`, `AttributeEnumType.cmAttString = 9`, `IAttribute.Value`, and `IAttributeSink.Attach/GetAttribute/GetAttributes`. The helper uses only that documented path; it does not introduce speculative APIs.

## Implementation boundary

New development-only project:

`tools/CimatronCustomization.KnownAnswerModelSetup/`

The helper:

- requires `--apply`;
- requires active Part context and exact model title `KA-PART-1`;
- requires entity ID `4` and verifies `cmBody`;
- requires the exact approved diagnostic name/value;
- inspects attributes before mutation;
- returns `ALREADY_PRESENT` with no mutation for an exact existing match;
- fails without overwrite when the name already exists with another type/value;
- creates `cmAttString`, sets the string value, attaches it, then reads back the exact type/name/value;
- never calls `Save`, `SaveAs` or `Close`;
- writes setup evidence under `artifacts/diagnostics` and reports manual save is required.

Production `src/**`, Plugin, CR/SA logic, configuration, installer and customer models are outside this change.

## User validation sequence

1. Keep Cimatron closed and run the repository quality gate for 0.20.20.
2. After PASS, open disposable `KA-PART-1` as an active Part.
3. Run:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.KnownAnswerModelSetup.exe" `
  --expect Part `
  --model-title KA-PART-1 `
  --entity-id 4 `
  --attribute-name STEP07_B1_TEST_ATTRIBUTE `
  --attribute-value KNOWN_ANSWER_07C3 `
  --apply
```

4. Return the console capture and `known-answer-body-attribute-setup-*.txt` evidence.
5. If the helper reports `ATTACHED_AND_READ_BACK`, manually save `KA-PART-1`.
6. Reopen/reload `KA-ASM-1` before the separate read-only 07C-3 verification.

## Capability status

- U13 — **NOT VERIFIED**; setup only.
- U14 — **NOT AVAILABLE**; unchanged.
- U15 — **NOT VERIFIED**; awaiting read-only 07C-3 run.
- U16 — reserved for 07C-4; untouched.
- U17 — **NOT AVAILABLE FROM RETAINED 07A EVIDENCE**; unchanged.

## Stopping rule

If quality gate fails, or setup reports a context/entity/attribute conflict or unexpected API/runtime error, stop. Do not retry with changed identifiers, names, values or alternate mutation APIs without explicit user approval.
