# Phase 02 Step 06A Validation Handoff — 0.16.0

## Scope

Step 06A defines the dependency-neutral Application contract for WP8 tabular input. It is required by future CR-04 and CR-22 work. No runtime Excel reader, third-party dependency, CR business logic, or Cimatron API behavior is included.

## Requirement boundary

- CR-04: future steel-grade comparison against the customer's DO Input Sheet.
- CR-22: future finger-pin diameter validation against the customer's slider weight/diameter table.
- Customer workbook layouts are still pending; worksheet/header/column mapping is therefore configuration-driven.
- Temporary files under `tests/TestData/Step06/` are requirement-derived fixtures only, not customer layout assumptions.

## User validation required

From an elevated or normal PowerShell session as already required by the existing project workflow, from repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

Return the generated quality-gate capture file or console output.

## Expected result

- Release x64 build: PASS, with no new warnings/errors.
- Architecture tests: PASS.
- Domain tests: PASS.
- Application tests: PASS, including `TabularInputContractTests`.
- Cimatron Integration tests: PASS.
- Infrastructure tests: PASS.
- Coverage/local quality gate: PASS.

No live Cimatron model action is required for 06A because this increment introduces no Cimatron API adapter and no runtime file reader.

## If validation fails

Do not proceed to 06B. Supply the complete failure output. Any corrective change will be separately scoped and documented before implementation.

## After validation

If the full quality gate passes and the user approves 06A closure, Step 06B begins with the separately approval-gated reader technology decision and Cimatron in-process dependency-risk check.
