# Cimatron Customization — Phase 02 Step 04 Session Handoff

**Date:** 2026-09-25  
**Current package:** `phase-02-step-04-cimatron-model-access-ports-0.14.10.zip`  
**Current version:** `0.14.10`  
**Phase:** Phase 02 — CR Platform Extensions  
**Step:** Step 04 — Cimatron Model Access Ports  
**Status:** **NOT CLOSED** — local quality gate is green, but one specific Part still returns `Error` in `Model Inspection Probe`.

---

## 1. Governing rules

Read `AGENTS.md` completely before making any plan or code change.

Key rules to continue enforcing:

- Keep chat responses small/medium.
- One meaningful step at a time.
- Do not claim PASS without user workstation evidence.
- User runs all builds/tests/quality gates/live Cimatron validation.
- Plugin remains a thin host.
- Domain/Application own business logic.
- CimatronIntegration contains Cimatron API/interop access.
- No customer CR/SA business logic is allowed in Step 04.
- Prefer verified Cimatron 2026 API behavior; do not guess unsupported signatures.
- Read-only model access only in Step 04.
- Zero-warning build expectation is now established.
- Full exception stack/detail logging must be preserved.

---

## 2. Completed prior steps

### Step 01 — Feature contract/composition
Closed at `0.11.3`.

### Step 02 — Rule parameter configuration
Closed at `0.12.0`.

### Step 03 — Feature launcher + result report
Closed at `0.13.2`.

Validated live:
- single feature execution;
- checklist execution;
- two selected features reported under one correlation ID.

---

## 3. Step 04 original scope

Target work package: WP5 + `ModelInspectionProbe`.

Application ports introduced:

- `IAssemblyStructureReader`
- `IEntityAttributeReader`
- `IEntityColorReader`
- `IBodyTopologyReader`

CimatronIntegration:

- read-only `CimatronModelInspectionAdapter`
- assembly structure traversal
- instance metadata
- entity attributes
- entity colors
- body/face topology
- face geometry/surface type/area

Foundation feature:

- `FOUNDATION-MODEL-INSPECTION-PROBE`

No write APIs and no customer CR logic.

---

## 4. Version history during Step 04

### `0.14.0`
Initial Step 04 implementation.

Local gate:
- build/tests passed;
- DesignChecks coverage only 73.15%, below 95%.

### `0.14.1`
Added focused ModelInspectionProbe coverage.

Result:
- DesignChecks coverage became 100%.
- Local quality gate PASS.
- 40 warnings remained.

### `0.14.2`
Attempted Step-04 warning cleanup.

Result:
- local gate PASS;
- warnings reduced to 36.

### `0.14.3`
User explicitly asked to fix **all warnings**.

Validated:
- `0 Warning(s)`
- `0 Error(s)`
- Release x64 PASS
- Architecture PASS
- Domain PASS
- Application PASS
- Infrastructure PASS
- Domain 100%
- Application 95.31%
- DesignChecks 100%
- Infrastructure 98.45%
- Coverage Gate PASS
- Local Quality Gate PASS

### `0.14.4`
Live assembly exposed:
`Cannot implicitly convert type 'object[]' ...`

A COM-array compatibility patch was attempted.

### `0.14.5`
Corrected assembly enumeration to the official pattern:
- strongly typed `IAssemblyModel.GetInstances()`
- consume as `object[]`
- cast each element to `IAssInstance`
- added topology stage diagnostics.

Local gate PASS, zero warnings.

### `0.14.6`
Added diagnostics around:
- `IModelContainer.Model`
- assembly instance `Model`
- assembly instance `ID`
- model `PID`
- body/face entity IDs
- entity-reference creation

Local gate PASS, zero warnings.

### `0.14.7`
Added diagnostics around:
- Cimatron application retrieval
- active document retrieval
- active document type

Local gate PASS, zero warnings.

### `0.14.8`
Added full exception diagnostics to JSONL:
- `exceptionType`
- `exceptionMessage`
- `exceptionStackTrace`
- `exceptionDetail = Exception.ToString()`

Initial package had a test-harness compile defect.

### `0.14.9`
Fixed the missing logger diagnostic test method only.

Validated:
- `0 Warning(s)`
- `0 Error(s)`
- Release x64 PASS
- Architecture PASS
- Domain PASS
- Application PASS
- Infrastructure PASS
- Domain 100%
- Application 95.31%
- DesignChecks 100%
- Infrastructure 98.48%
- Coverage Gate PASS
- Local Quality Gate PASS

### `0.14.10`
Live stack trace from the failing Part proved:

```text
System.ArgumentException: Value does not fall within the expected range.
   at interop.CimBaseAPI.IAttributeSink.GetAttributes()
   at CimatronCustomization.CimatronIntegration.CimatronModelInspectionAdapter.ReadAttributes(...)
```

Patch intent:
- only `ArgumentException` from `IAttributeSink.GetAttributes()` should become controlled `Unsupported`;
- unexpected exception types should still propagate;
- no write API;
- no CR/SA logic.

Local validation supplied by user:
- `0 Warning(s)`
- `0 Error(s)`
- Release x64 PASS
- Architecture PASS
- Domain PASS
- Application PASS
- Infrastructure PASS
- Domain 100%
- Application 95.31%
- DesignChecks 100%
- Infrastructure 98.48%
- Coverage Gate PASS
- Local Quality Gate PASS

**However:** user reports the problematic Part **still shows the same Error** after `0.14.10`.

Therefore Step 04 is **not closed**.

---

## 5. Live validation evidence

### Representative mold assembly — PASS

After `0.14.5`, representative mold assembly produced:

- Assembly structure: Passed
- 130 components in one run
- topology: Passed
- 843 bodies / 5464 faces in one run
- representative face surface type/area: Passed
- representative attributes: Passed
- representative Cimatron color: Passed
- bounding box: controlled `Unsupported`
- summary: `Total 7 | Passed 6 | Unsupported 1 | Error 0`

Another assembly/subassembly run produced:

- 83 components
- topology passed
- 582 bodies / 3652 faces
- attributes passed
- color passed
- bounding box Unsupported
- `Error 0`

So assembly model access is proven working.

### Another Part — PASS

A different Part produced:

- topology Passed
- representative face/surface Passed
- attributes Passed
- color Unsupported
- bounding box Unsupported
- no Error

This proves Part documents in general are supported.

### Specific problematic Part — FAILS

The problematic Part repeatedly returns:

```text
Model Inspection Probe — Error
Value does not fall within the expected range.
```

With `0.14.9`, correlation:

`ab83b88dbd8a447cb2d2976dd2dcf6c8`

The JSONL log showed the exact stack:

```text
System.ArgumentException: Value does not fall within the expected range.
   at interop.CimBaseAPI.IAttributeSink.GetAttributes()
   at CimatronCustomization.CimatronIntegration.CimatronModelInspectionAdapter.ReadAttributes(ModelEntityReference entityReference)
   at CimatronCustomization.DesignChecks.ModelInspectionProbeFeature.AddAttributeFinding(...)
   at CimatronCustomization.DesignChecks.ModelInspectionProbeFeature.Execute(...)
   at CimatronCustomization.Application.ExecuteRegisteredFeature.Execute(...)
```

That is the strongest confirmed runtime evidence.

After `0.14.10`, user reports the same failing Part still shows the same Error.

---

## 6. Critical next action for the new session

**Do not assume that 0.14.10 is actually handling the live exception correctly.**

First inspect the actual `0.14.10` source/package and verify the exact live execution path.

Specifically inspect:

1. `CimatronCustomization.CimatronIntegration/CimatronModelInspectionAdapter.cs`
   - `ReadAttributes(ModelEntityReference entityReference)`
   - confirm the `try/catch (ArgumentException)` actually surrounds the exact `attributeSink.GetAttributes()` call in production source;
   - confirm the built DLL/version metadata is `0.14.10`.

2. `CimatronCustomization.DesignChecks/ModelInspectionProbeFeature.cs`
   - `AddAttributeFinding(...)`
   - verify how `ModelReadResult.Unsupported` is translated into findings;
   - verify it does not throw or reinterpret Unsupported as Error.

3. Plugin deployment/output path
   - confirm the newly built `0.14.10` DLLs were actually copied to the Cimatron Program folder used by the running instance;
   - check whether Cimatron might still be loading an older DLL.
   - this is now a serious possibility because the code intent and live result disagree.

4. JSONL log for the failing run after `0.14.10`
   - retrieve the new correlation ID;
   - check `applicationVersion` in the log;
   - verify whether the stack still points to `GetAttributes()`;
   - if `applicationVersion` is not `0.14.10`, the wrong DLL is loaded.
   - if it is `0.14.10` and stack still escapes `ReadAttributes`, inspect source line mapping and actual compiled code path.

**Recommended first diagnostic in new chat:**
Ask the user for the correlation ID from the failing `0.14.10` run, then query the log and verify:

```powershell
Select-String `
    -Path "$env:LOCALAPPDATA\CimatronCustomization\Logs\*" `
    -Pattern "<CORRELATION-ID>" `
    -Context 0,60
```

The most important fields are:

- `applicationVersion`
- `exceptionType`
- `exceptionMessage`
- `exceptionStackTrace`
- `exceptionDetail`

Do **not** create `0.14.11` until this evidence is inspected.

---

## 7. Current package

Current package:

`phase-02-step-04-cimatron-model-access-ports-0.14.10.zip`

SHA-256:

`28dd5c6ee931364790b8453c5cfb715857ab5574630337ae891e56ac2f22f2d2`

Local quality gate for 0.14.10 is validated green by the user.

Step 04 remains open solely because the specific problematic Part still returns `Error` in live Cimatron.

---

## 8. Step 04 closure criteria still outstanding

Before Step 04 can close:

- representative assembly remains PASS;
- representative Part remains PASS;
- problematic Part must no longer crash/fail the whole probe for entity-specific unsupported attribute access;
- unsupported capability must be surfaced as controlled `Unsupported`;
- no model modification;
- no crash;
- no second Cimatron process;
- local quality gate must remain PASS;
- zero warnings / zero errors expected.

Only after that should Step 04 be formally closed and Step 05 planned.

---

## 9. Next planned step after Step 04 closes

**Step 05 — viewport-highlight-zoom-picks**  
Target from the approved platform spec: `0.15.0`

Do not start Step 05 until Step 04 is formally validated and closed.
