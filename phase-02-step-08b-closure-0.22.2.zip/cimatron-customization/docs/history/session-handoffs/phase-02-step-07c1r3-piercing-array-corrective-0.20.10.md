# Phase 02 Step 07C-1R3 — Piercing-array Corrective Handoff — 0.20.10

**Version:** 0.20.10  
**Context:** GREEN  
**07C-1:** OPEN  
**07C-2:** BLOCKED

## Approved scope

Correct only the development diagnostic result conversion exposed by the final 0.20.9 run: `GetPiercingPoints` returned `object[]`, while the tool directly cast it to `double[]`. Also correct the stale evidence ToolVersion label and maintain required governance/time records. No production behavior or model data may change.

## Evidence entering this package

- User workstation 0.20.9 quality gate passed earlier with 0 warnings / 0 errors, governed test suites and coverage/local gate PASS, exit code 0.
- Candidate UCS 251 produced the +30° Z bounding-box behavior; candidate 249 produced the 90° behavior.
- `GetEntityPointDistance` on face 90 returned `10 mm` for `(110,30,20)` and `14.142135623730951 mm` for `(110,70,20)`, with bounded-face closest points.
- All three approved piercing calls reached Cimatron but the diagnostic recorded runtime-binder errors because `object[]` could not be cast to `double[]`.
- No-mutation evidence remained `UNCHANGED`.
- Console banner was 0.20.9 while evidence still printed stale ToolVersion 0.20.7.

## 0.20.10 changes

- `GeometryServicesVerification.cs`: replace the direct piercing return cast with guarded one-dimensional numeric-array conversion.
- `Program.cs` + `VerificationRuntimeContext.cs`: use one shared ToolVersion source (`0.20.10`) for banner and evidence.
- Diagnostic `AssemblyInfo.cs`: align assembly/file version to 0.20.10.
- Required version/history/changelog/platform/time-ledger/checksum records updated.

## Validation state

Agent did not build, test, or launch Cimatron. Status is **AWAITING USER EXECUTION**.

## Exact next step

1. Close Cimatron completely and run the normal quality gate.
2. After PASS, copy/deploy the 0.20.10 diagnostic as already used for 0.20.9.
3. With `KA-PART-1` open, rerun the same approved final geometry command containing UCS 251/reference 2/face 90 and the three rays.
4. Return the generated `api-capability-geometry-*.txt` evidence.

Do not start 07C-2 until 07C-1 is explicitly closed.
