# Phase 02 Step 08A — U1 In-Process Confirmation Handoff — 0.21.0

## Context health

**GREEN** — Step 07D is closed / user validated. Step 08A is the only active implementation scope.

## Approved scope

Confirm the already Step-07-`VERIFIED` U1 body metrics inside the real registered Cimatron Plugin process before any CR production use:

- `IGeomServices.BodiesVolume`
- `IGeomServices.BodiesCenter`
- `IGeomServices.BodiesSurfArea`

No CR business rule, model modification, configuration change, installer change, or unrelated refactor is authorized.

## Implementation prepared

- Application: `IBodyGeometryMetricsReader`, `BodyGeometryMetricsSnapshot`.
- CimatronIntegration: `CimatronBodyGeometryMetricsReader`.
- DesignChecks: `U1InProcessGeometryConfirmationFeature`.
- Plugin: registered the new foundation feature in `FeatureComposition`.
- Tests: added fake-port coverage in `U1InProcessGeometryConfirmationTests` and test-runner registration.
- Version metadata: Application, CimatronIntegration, DesignChecks, and Plugin report `0.21.0.0` under separately approved metadata-only scope.

The adapter requires:

- active document type = Part;
- model title = `KA-PART-1`;
- entity ID `4` resolves to `cmBody`;
- saved model path is available for no-mutation evidence.

Locked Step 07 known answer:

| Value | Expected |
|---|---:|
| Body ID | `4` |
| Volume | `227576.685834808` |
| Center | `[50,30,20]` |
| Surface area | `26684.9371823929` |

The live confirmation also requires unchanged `IsModified()`, file path, last-write timestamp, and file length before/after the U1 read.

## Step 07D closure evidence carried forward

User supplied `artifacts/console-captures/quality-gate-20261001-013106.txt`:

- Release x64 build: PASS
- 0 warnings / 0 errors
- Architecture / Domain / Application / Cimatron Integration / Infrastructure tests: PASS
- Coverage gate: PASS
- Local quality gate: PASS
- Exit code: 0

User then explicitly approved the Step 07D promotion whitelist. U1/U3/U4/U5/U6/U7/U8/U9/U10/U12/U13/U15/U16 are eligible for Step 08; U2/U11/U14/U17 remain excluded.

## Required user validation for 0.21.0

1. Extract/copy the 0.21.0 package into the normal workstation repository location.
2. Run the standard quality gate:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

3. If and only if the quality gate passes, launch Cimatron 2026.0 SP2P1 and open the saved `KA-PART-1` known-answer Part used in Step 07.
4. Open the registered Plugin launcher and execute **U1 In-Process Geometry Confirmation**.
5. Return the finding/report output or screenshot. Expected result is four Passed findings: volume, center, surface area, and no-mutation evidence.
6. Confirm Cimatron shows no unexpected modified/unsaved state after execution.

Do not mark U1 `IN-PROCESS VERIFIED` until both workstation quality-gate and controlled live Plugin evidence are supplied.

## Carry-forward

- Step 08 whitelist remains unchanged except that U1 is now under confirmation; it is not yet promoted to production CR use.
- U2/U11 remain `PARTIALLY VERIFIED` and excluded.
- U14/U17 remain unavailable/not eligible.
- `ST06-DF-01` through `ST06-DF-06` remain `DEFERRED` unchanged.

## Agent execution boundary

The agent prepared source/tests/docs/checksums/package only. The agent did **not** build, run tests, execute SonarQube, launch Cimatron, or perform the live confirmation.
