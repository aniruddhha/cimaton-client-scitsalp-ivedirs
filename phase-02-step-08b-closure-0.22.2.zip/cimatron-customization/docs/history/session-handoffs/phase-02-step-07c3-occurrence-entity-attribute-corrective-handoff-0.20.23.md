# Phase 02 Step 07C-3 — Occurrence-Entity / Named-Attribute Corrective Handoff — 0.20.23

## Entering validated evidence

- 0.20.22 workstation quality gate `quality-gate-20260930-130837.txt`: Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gates PASS, exit code 0.
- Controlled 0.20.22 setup on active `KA-PART-1`: entity `4` = `cmBody`; `ReadBack.Type = cmAttString`; `ReadBack.Value = KNOWN_ANSWER_07C3`; result `ATTACHED_AND_READ_BACK`; mutation in memory only; user manually saved the Part and reopened `KA-ASM-1`.
- First governed 07C-3 run stopped before U13/BOM because `instance.Model.GetEntityById(4, partModel)` raised COM `0x80040207`.
- Read-only follow-up `assembly-occurrence-entity-diagnostic-20260930-131646.txt` proved `KA-PART-1` occurrences expose body entity `4` through `IAssInstance.GetAllEntities()` and recorded no-mutation `UNCHANGED`.

## Approved 0.20.23 corrective

Only the development-only `--verify-component-properties` path and its regression guard are changed:

1. Resolve the requested body from `IAssInstance.GetAllEntities()`.
2. Require exact entity ID and `cmBody`; fail on missing, wrong-type, or duplicate match.
3. Keep `GetAttributes()` as enumeration evidence.
4. Confirm the known attribute with exact `GetAttribute(cmAttString, requestedName)`.
5. Require non-null, exact `cmAttString`, and exact expected value. Returned `IAttribute.Name` is logged evidence only because the setup proof showed it blank after successful named lookup.
6. Preserve assembly-context conversion, BOM temp export/evidence, no-mutation guards, U14/U17 classifications, and 07C-4 exclusion.
7. Add architecture guard against regression to the failed model `GetEntityById` path or returned-name equality gate.

Production `src/**`, Plugin, setup helper, CR/SA logic, configuration, installer and model behavior are unchanged.

## Static pre-handoff checks performed by agent

- Verified the 07C-3 verifier source contains `IAssInstance.GetAllEntities()` body resolution and exact named `cmAttString` lookup.
- Verified the failed `partModel.GetEntityById(args.EntityId.Value, partModel)` token is absent from `ComponentPropertySourceVerification.cs`.
- Verified the old `string.Equals(attribute.Name, knownAttributeName, ...)` match gate is absent.
- Verified no `Save`, `SaveAs`, `Close`, `GetAttributeFactory`, or other mutation API was added to the read-only verifier.
- Verified production `src/**` is byte-identical to the 0.20.22 baseline before packaging.

## Validation status / next action

**AWAITING USER 0.20.23 WORKSTATION QUALITY GATE.** The agent did not build/test/run Cimatron and does not claim PASS.

After a clean quality-gate PASS, reopen `KA-ASM-1` and perform exactly one governed `--verify-component-properties` rerun with the existing known-answer arguments. Review U13/U15 and no-mutation evidence before any further change.
