# Phase 02 Step 07C-4 — BOM Read-Error Corrective — 0.20.26

## Context status
GREEN

## Current state
- Step 07C-4 remains open.
- 0.20.25 workstation quality gate: PASS.
- Corrected-model evidence verifies `ICimEntity.Show` as body/entity visibility, not occurrence-hidden visibility.
- Hidden occurrence `Known_Pocket_Body`: `Show.GET=1`.
- Hidden body in visible `Visible_Component_With_Hidden_Body`: one body `Show.GET=0` while sibling bodies returned `1`.
- `GetBomManager()` returned COM `E_FAIL`; corrected-model BOM route therefore remains unresolved.
- No-mutation evidence from the failed BOM-stage run: UNCHANGED.

## 0.20.26 corrective
Only the development-only hidden-state verifier and its architecture source guard are changed. `GetBomManager()` now uses `TryObserve`. A BOM read failure is recorded but no longer aborts the verifier; the run completes semantics-neutral and no-mutation evidence. Existing successful BOM export/membership behavior is unchanged when the manager is available.

## Production boundary
`src/**`, Plugin, configuration, installer, CR/SA behavior, and model behavior are unchanged.

## Validation required
1. Run the 0.20.26 governed workstation quality gate.
2. With the corrected U16 assembly open, run `--verify-hidden-state-candidates` once as the controlled retry.
3. Supply the generated evidence file for classification of the BOM route.

No 0.20.26 PASS is claimed before user workstation evidence.
