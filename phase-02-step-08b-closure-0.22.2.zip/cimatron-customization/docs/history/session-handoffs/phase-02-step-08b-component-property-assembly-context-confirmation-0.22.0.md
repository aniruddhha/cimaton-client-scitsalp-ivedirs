# Phase 02 — Step 08B Handoff — 0.22.0

## Project
Cimatron 2026 customization platform.

## Phase / Step
- Phase: 02 — CR Platform Extensions
- Step: 08B — U13/U15/U8/U7/U12 In-Process Confirmation
- Version: 0.22.0
- Context: GREEN
- Status: IMPLEMENTATION PREPARED / AWAITING USER QUALITY GATE AND SINGLE GOVERNED LIVE RUN

## Approved scope
Foundation diagnostic only. No CR-04 business logic.

- U8: `KA-ASM-1` -> `KA-PART-1` occurrence structure = 3 total, 2 top-level through `GetInstancesByModel`, 1 nested through recursive `SubInstances`; runtime instance IDs are evidence only.
- U13: on the nested occurrence, body ID 4 exactly once as `cmBody`; exact named `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` returns `KNOWN_ANSWER_07C3`; returned `IAttribute.Name` is evidence only.
- U7: map nested Part body to active Assembly context with `IAssemblyModel.GetAssemblyEntity`.
- U12: the feature returns the nested occurrence reference; user validates through the real Result Report Highlight path. No UI/pause inside feature execution.
- U15: `IBOM.Export(..., cmNoFiltering, ...)` to governed temp path; parse through existing `ITabularDataReader`; `Standard Number=KA-PART-1`, `Material=1.2738`.
- Programmatic no-mutation and model-folder guards.
- Single-run stopping rule.

## API decisions
- `IAssemblyModel.GetAssemblyEntity` and `IBOM.Export` are present in authoritative Cimatron documentation.
- `IAssInstance.GetAllEntities()` is present in installed Interop and prior governed runtime evidence but no authoritative SDK documentation-index entry was found. It is recorded accordingly and not represented as officially documented.
- `GetBomManager()` / BOM export COM failures are `READ_ERROR` evidence and do not count as U15 confirmation.

## Files added
- `src/CimatronCustomization.Application/IOccurrenceEntityAttributeReader.cs`
- `src/CimatronCustomization.Application/OccurrenceEntityAttributeResult.cs`
- `src/CimatronCustomization.Application/IAssemblyEntityMapper.cs`
- `src/CimatronCustomization.Application/AssemblyEntityMappingResult.cs`
- `src/CimatronCustomization.Application/IBomMaterialExporter.cs`
- `src/CimatronCustomization.Application/BomMaterialExportResult.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronOccurrenceEntityAttributeReader.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronAssemblyEntityMapper.cs`
- `src/CimatronCustomization.CimatronIntegration/CimatronBomMaterialExporter.cs`
- `src/CimatronCustomization.DesignChecks/Step08BInProcessConfirmationFeature.cs`
- `tests/CimatronCustomization.Application.Tests/Step08BInProcessConfirmationTests.cs`
- this handoff file.

## Approved existing-file modifications
- Application/CimatronIntegration/DesignChecks project files — compile includes for new files.
- `CimatronViewportEntityHighlighter.cs` — nested-reference production path for U12.
- `FeatureComposition.cs` — register Step 08B and compose validated tabular reader.
- four production `AssemblyInfo.cs` files — version metadata `0.22.0.0`.
- `CimatronCustomization.Application.Tests.csproj` — new test fixture include.
- `CimatronCustomization.Application.Tests/Program.cs` — explicit custom-runner invocation; separately approved after the scope boundary was discovered.
- `ArchitectureBoundaryTests.cs` — Step 08B regression/source-contract guards.
- `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, capability register, authoritative time CSV and checksum manifest.

## Safety / no-mutation
- Occurrence and mapping adapters snapshot `IsModified`, saved-file timestamp and length before/after reads.
- BOM adapter additionally snapshots the saved model-folder file listing.
- BOM output is restricted to `%TEMP%\CimatronCustomization\Step08B\<timestamp>\`.
- Cleanup is permitted only inside that generated Step08B run directory. Cleanup failure becomes Warning.
- No model save, geometry change, attribute write, placement change or customer-rule mutation is introduced.

## DF-05
The Step 08B diagnostic is developer-visible in the launcher and must be gated or removed before D5 client packaging.

## Agent execution boundary
The agent did not build, run tests/coverage, launch Cimatron, or claim PASS.

## Required user validation
1. Extract the cumulative ZIP so the repository root is `cimatron-customization/`.
2. Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

3. Stop and return the capture. Live Cimatron validation is blocked until the gate is clean: Release x64 PASS, 0 warnings / 0 errors, all governed tests PASS, coverage/local gate PASS.
4. After clean-gate review, open saved `KA-ASM-1`, run only `Step 08B Component Property / Assembly Context Confirmation`, then stop.
5. In the Result Report select the U12 nested-highlight finding and click `Highlight` once. Visually confirm the nested `KA-PART-1` body is correct and that selection/highlight restoration behaves correctly.
6. Return the Result Report evidence/screenshot and confirm no unexpected modified/unsaved state.

## Single-run stopping rule
Exactly one governed feature run and one U12 Highlight action after the clean gate. Any Failed/Error/READ_ERROR, wrong material/attribute, wrong occurrence count, wrong highlight, restoration problem, or no-mutation failure stops the step. No retry, alternate API, or corrective implementation without explicit new approval.

## Next action
User runs the quality gate and returns the capture.
