# Phase 02 Step 07 — Session Handoff — 0.20.2

## Session status

**Context:** GREEN

**Step:** 07 — Cimatron API Capability Verification

**Current state:** 07A complete and evidence-reviewed; 07B known-answer models user-prepared; 07C has not started.

## Validated evidence

### Quality gate

User supplied `quality-gate-20260929-143207.txt` for the 0.20.2 package. Result:

- Release x64 build PASS
- 0 warnings / 0 errors
- Architecture / Domain / Application / Cimatron Integration / Infrastructure tests PASS
- Coverage gate PASS
- Local quality gate PASS
- Exit code 0

This is the latest validated workstation quality-gate evidence for the Step 07 executable source.

### 07A reflection inventory

User executed:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --reflect-capability-api
```

Result: `STEP 07A REFLECTION INVENTORY: COMPLETE`.

Evidence: `api-capability-reflection-20260929-143432.txt`.

Evidence footer: `RuntimeCalls: NONE (reflection-only installed-Interop inventory)`.

Important installed-Interop facts established:

1. `IGeomServices` is available in `interop.CimMdlrAPI` with the required geometry-query members.
2. `GetEntityPointDistance` signature is `Double GetEntityPointDistance(ICimEntity, Object, out IPointData)`.
3. `IAssemblyModel.GetAssemblyEntity`, `GetInstancesByModel`, `GetRootInstance`, `GetGeomServicesObj`, `ActivateUcs` getter, and `InstanceByAssemblyEnt` getter are present.
4. `IAssInstance.Attribute` is SET-ONLY in the installed 2026 Interop reflection evidence.
5. `IAssInstance.Lock` getter exists.
6. `ICimEntity.Show` getter exists.
7. `IBOM.Export` is the installed seven-parameter signature.
8. `ComponentsFilterOption.cmVisibleOnly = 1`.

07A reflection/signature discovery is complete. These facts do not by themselves establish runtime correctness; 07C remains required.

## 07B known-answer model work completed in this session

### KA-PART-1

The user prepared a native Cimatron Part based on the Step 07 reference geometry. During this session the following were observed/confirmed:

- two separate bodies;
- through-hole visible in the larger body;
- `KA_UCS_90Z` created as a separate user UCS;
- Part Material/model property saved as `1.2738`.

Do not mislabel `1.2738` as a verified B1 body-level custom attribute. The visible Cimatron UI exposed it as a part/model property. This distinction must remain explicit when 07C-3 is analysed.

### KA-ASM-1

A preparation package was created from the validated `CR11_Smoke_Assembly_Prepared.elt` baseline. The user then continued native Cimatron assembly preparation and, at the end of the session, explicitly stated: **"Model is ready"**.

The next session must treat this as user confirmation that the known-answer assembly is ready, but must still capture/record the actual final runtime values before comparison:

- final nested KA-PART-1 occurrence/path and transform;
- top-level pair used for known cross-component distance;
- expected physical gap;
- locked occurrence and expected lock value;
- model title used with `--model-title`;
- target entity id used with `--entity-id`;
- any ids needed for KA-PART-1 07C-1 geometry probes.

Do not invent missing ids or transforms.

## Important baseline states to preserve

The validated CR11 assembly baseline previously contained:

- repeated visible `Block_A`;
- suppressed `Block_B`;
- hidden-not-suppressed `Known_Pocket_Body`;
- `Nested_SubAssembly` / nested child content.

The Step 07 KA-ASM-1 working copy is intended to preserve those known-answer conditions. Verify them from the final user model/evidence before interpreting 07C.

## Tool/package state

Current Step 07 executable source version remains **0.20.2**.

No tool/production code was changed for this session handoff. This handoff package changes documentation/time-ledger/status/checksums only.

Production `src/**`, `config/**`, existing `tools/CimatronCustomization.ZoomCommandDiscovery/**`, unrelated tests, and `AGENTS.md` remain unchanged.

## Exact next step in the new session

1. Read `AGENTS.md` completely.
2. Read this handoff and `docs/platform/STEP-07-KNOWN-ANSWER-MODELS.md`.
3. Confirm/record the final KA-PART-1 known-answer values and the entity/edge/UCS ids required by 07C-1. Do not guess ids.
4. With **KA-PART-1 active in Cimatron**, run **07C-1 geometry verification** using the actual ids/rays from the model.
5. Return the generated `api-capability-geometry-*.txt` and console capture.
6. Review no-mutation evidence before proceeding to 07C-2.

Do not jump directly to 07C-2/3/4.

## Pending Step 07 work

- 07C-1 geometry services: NOT STARTED
- 07C-2 assembly-context resolution / cross-component distance / highlight: NOT STARTED
- 07C-3 component-property/BOM sources: NOT STARTED
- 07C-4 hidden-state candidate single run: NOT STARTED
- 07D verification register finalization: PENDING 07C evidence
- Step 07 closure approval: PENDING

## Deferred items

Step 06 findings `ST06-DF-01` through `ST06-DF-06` remain `DEFERRED` and must continue to be carried forward.
