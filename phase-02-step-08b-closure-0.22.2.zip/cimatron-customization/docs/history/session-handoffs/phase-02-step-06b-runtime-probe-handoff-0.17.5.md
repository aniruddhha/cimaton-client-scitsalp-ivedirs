# Phase 02 Step 06B — Runtime Probe Handoff — 0.17.5

## Purpose
Validate the approved ExcelDataReader-based tabular reader inside the real Cimatron process without making Step 06B responsible for launching Cimatron.

## Entering evidence
- 0.17.4 user-run quality gate: PASS; Release x64 build clean; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.
- Direct `Start-Process` of `CimatronE.exe` on the user workstation exited with code 0 and no UI. Exact cause was not established.

## 0.17.5 correction
- `Start-Step06BTabularProbe.ps1` no longer launches Cimatron or uses environment variables.
- It writes one request file at `%TEMP%\CimatronCustomization\step06b-tabular-probe.request`.
- Request fields: `Version=0.17.5`, `RequestedUtc`, known-answer `InputFile`, `EvidenceFile`.
- Plugin consumes the request once on the next command click, validates version/freshness (30 minutes), deletes the consumed request, and runs the existing read-only probe.
- No request => normal Feature Launcher path unchanged.

## Scope unchanged
No CR-04/CR-22 business logic, no model mutation, no reader/dependency change, no architecture-rule weakening.

## Required user validation
1. Run full quality gate and return capture.
2. If PASS, run `powershell -ExecutionPolicy Bypass -File .\tools\Start-Step06BTabularProbe.ps1`.
3. Start Cimatron normally using the user's normal installation shortcut/start method.
4. Open a disposable Part/Assembly if required for command visibility.
5. Click `Cimatron Customization` exactly once.
6. Return the generated `artifacts\console-captures\step06b-tabular-probe-*.txt` and report whether any unintended additional Cimatron process appeared.

## Closure criteria
Do not close 06B until evidence proves the probe ran in `CimatronE`, the known-answer row read succeeded, ExcelDataReader loaded at the expected version/path, no binding/load exception occurred, and no unintended process behavior was observed.
