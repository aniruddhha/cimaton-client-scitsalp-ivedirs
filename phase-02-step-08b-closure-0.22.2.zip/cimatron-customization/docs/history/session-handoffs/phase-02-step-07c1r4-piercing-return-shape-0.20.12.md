# Phase 02 Step 07C-1R4 — Piercing Return-Shape Inspection Handoff — 0.20.12

**Version:** 0.20.12  
**Context:** GREEN  
**07C-1:** OPEN  
**07C-2:** BLOCKED

## Approved scope

Inspect only the development-diagnostic return shape from `IGeomServices.GetPiercingPoints`: keep the same Cimatron call, face 90 target, and three approved rays; do not convert the result to `double[]`; record the raw return type/value and every top-level array item type/value. Correct stale diagnostic version metadata and maintain required governance/time/checksum records. No production behavior or model data may change.

## Evidence entering this package

- `quality-gate-20260930-003832.txt`: 0.20.11 Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- `api-capability-geometry-20260930-004342.txt`: UCS 251/reference 2 evidence remained stable; `GetEntityPointDistance` remained `10` and `14.142135623730951`; no-mutation remained `UNCHANGED`.
- All three `GetPiercingPoints` calls reached Cimatron but the diagnostic reported a non-numeric item while converting the returned array. The exact return shape is therefore still unknown.
- The same evidence showed stale `ToolVersion: 0.20.10`; 0.20.12 aligns tool/assembly metadata.

## 0.20.12 change

- `GeometryServicesVerification.cs`: capture raw piercing return and record overall type/value.
- If it is an array, record array type/rank/length and each top-level item's runtime type/value.
- Nested array values are formatted recursively using the existing evidence formatter.
- Remove the numeric-array conversion from this inspection path.
- `Program.cs` and diagnostic `AssemblyInfo.cs`: align version metadata to `0.20.12`.
- Production `src/**` remains untouched.

## Validation state

Agent did not build, test, or launch Cimatron. Status is **AWAITING USER EXECUTION**.

## Exact next step

1. Close Cimatron completely.
2. Run the normal quality gate.
3. Send the new quality-gate capture.
4. Only after PASS, open `KA-PART-1` and rerun the same approved final geometry command.
5. Send the generated `api-capability-geometry-*.txt` file so the raw piercing return shape can be classified.

Do not start 07C-2 until 07C-1 is explicitly closed.
