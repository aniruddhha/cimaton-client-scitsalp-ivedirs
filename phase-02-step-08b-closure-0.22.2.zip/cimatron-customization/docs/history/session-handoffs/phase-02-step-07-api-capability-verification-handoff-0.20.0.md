# Phase 02 Step 07 API Capability Verification — Session Handoff — 0.20.0

## Status

Step 07 implementation package is prepared. **AWAITING USER EXECUTION.** No build/test/Cimatron PASS is claimed by the agent.

## Approved scope

- 07A installed-Interop reflection-only inventory.
- 07B user-prepared known-answer models and sheet.
- 07C-1 geometry services read-only probe.
- 07C-2 assembly-context resolution/read-only probe with optional temporary highlight and restoration.
- 07C-3 component-property sources plus BOM export only to a fresh Step 07 temp folder.
- 07C-4 hidden-state candidate single-run probe, separately approved with the Step 07 plan.
- 07D verification register, initially awaiting user evidence.

## Production boundary

All `src/**`, `config/**`, existing `tools/CimatronCustomization.ZoomCommandDiscovery/**`, unrelated tests, and `AGENTS.md` remain outside Step 07 technical scope. Step 07 adds a development-only executable; no production project may reference it.

## Required user sequence

1. Extract/unblock the package.
2. From Administrator PowerShell, run the normal captured quality gate. Do not proceed to Cimatron runtime probes unless it is clean with 0 warnings / 0 errors and exit code 0.
3. Close Cimatron and run 07A:
   `& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --reflect-capability-api`
4. Return the reflection evidence for review before interpreting live API results.
5. Prepare KA-PART-1 and KA-ASM-1 working copies and fill `docs/platform/STEP-07-KNOWN-ANSWER-MODELS.md`.
6. Run 07C modes from normal/non-elevated PowerShell against the matching active known-answer document using ids/values from the filled sheet.
7. Return captures, evidence files, filled sheet, and highlight screenshot/observation.

## Closure rule

The verification register changes from `NOT VERIFIED — AWAITING USER EXECUTION` only from user-supplied evidence. Every live item remains labelled out-of-process only. Step 07 closes only after clean quality-gate evidence, known-answer runtime evidence, register update, and explicit user approval.
