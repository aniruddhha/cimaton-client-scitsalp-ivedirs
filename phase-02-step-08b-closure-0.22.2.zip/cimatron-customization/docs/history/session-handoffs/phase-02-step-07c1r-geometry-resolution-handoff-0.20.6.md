# Phase 02 Step 07C-1R — Geometry Resolution Handoff — 0.20.6

## Session status

**Context:** GREEN  
**Step:** 07C-1R — resolve remaining Geometry Services evidence gaps only.  
**State:** **AWAITING USER 0.20.6 QUALITY GATE + KNOWN-ANSWER PREPARATION + LIVE 07C-1R EVIDENCE**.

## Evidence entering 0.20.6

User workstation 0.20.5 quality gate passed with exit code 0. Two live geometry runs confirmed:

- B1 body 4: volume `227576.685834808`, centre `[50,30,20]`, surface area `26684.9371823929`;
- B2 body 5: volume `64000`, centre `[145,30,20]`, surface area `9600`;
- B1↔B2 minimum distance `25 mm`, closest points `100,50,40` and `125,50,40`;
- edge 89 → `cmConvex`; edge 95 → `cmConcave`;
- body-list UCS bounding box observation `[1,1,1,0,0,0]`;
- B1-face-list UCS bounding box observation `[0,0,0,100,60,40]`;
- no-mutation evidence `UNCHANGED` in both runs.

## Review correction incorporated

`GetPiercingPoints` and `GetEntityPointDistance` were not tested by the 0.20.5 commands and must have explicit statuses before 07C-1 closure. The 0.20.6 mode records `NOT_TESTED` when their known-answer inputs are absent instead of omitting them.

The hypothesis that `[1,1,1,0,0,0]` is an empty-box sentinel is deliberately **not** accepted yet. It requires the controlled B1-face comparison first.

## 0.20.6 diagnostic delta

No new probe mode. Existing `--verify-geometry` gains:

- `--face-id N` — resolves and guards `cmFace`, records face area and face-only bounding boxes;
- `--reference-ucs-id N` — compares the same B1 faces/test face under a separately evidence-mapped reference/main UCS and the primary UCS supplied by `--ucs-id`;
- B1-face-list bounding boxes sourced from the body supplied by `--entity-a`;
- conditional `SurfacesArea` invocation only when the installed `IGeomServices` Interop contract contains that member; otherwise raw evidence says `BLOCKED`;
- explicit `NOT_TESTED` output for omitted `GetPiercingPoints` and `GetEntityPointDistance` inputs;
- unchanged no-mutation check.

## Required user preparation before final run

1. Run the standard 0.20.6 quality gate with Cimatron closed.
2. Reopen standalone `KA-PART-1.elt`.
3. Map the **main/reference UCS ID** using the existing discovery mode while the main UCS is active. Do not infer that the other previously enumerated UCS candidate is the main UCS.
4. Record the physical role and expected geometry of face ID 90 from the model/UI: expected area, plane/flat axis, and expected main-UCS box.
5. Record a test point at a known offset from face 90 plus the expected face↔point distance.
6. Record one known-answer through-hole ray and one known-answer through-solid ray if `GetPiercingPoints` is to be promoted beyond `NOT TESTED`.

Only after these values are evidence-backed should the final one-run 07C-1R command be issued with both UCS IDs, face ID 90, point, and ray arguments.

## Scope boundary

No production `src/**`, Plugin behavior, configuration, CR/SA logic, or 07C-2/3/4 work is changed or authorized. User approval is required before 07C-1 can be closed and before 07C-2 can start.
