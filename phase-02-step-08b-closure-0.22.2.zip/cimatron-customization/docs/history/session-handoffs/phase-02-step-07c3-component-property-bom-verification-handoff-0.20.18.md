# Session Handoff — Phase 02 / Step 07C-3 Component Property / BOM Verification

## Version
0.20.18

## Context Status
GREEN

## Approved Scope

- U13: verify one deliberate B1 body attribute on the Part-model body and assembly-context body.
- U14: retain `NOT AVAILABLE`; 07A shows `IAssInstance.Attribute` SET-ONLY.
- U15: verify `IBOM.Export` using `cmNoFiltering` and `cmVisibleOnly`, including known-answer KA-PART-1 material-column/value evidence.
- U17: existing-evidence-only search for a model/Part material-property getter. Retained 07A evidence does not establish one, so no new reflection or speculative getter call is permitted.
- Existing U16 remains reserved for separately approved 07C-4 hidden-state work.
- 07C-2 cross-occurrence `MinDistancePos` limitation remains documented and is not reprobed.

## Implemented in 0.20.18

- Hardened the existing development-only `--verify-component-properties` mode.
- Requires explicit known-answer inputs: body attribute name/value and Part/model material value.
- Confirms the target entity resolves as `cmBody` before attribute evidence is accepted.
- Reads `IAttributeSink.GetAttributes()` on both Part-model and assembly-context entities and records whether the known attribute name/value matches.
- Preserves U14 as no-call evidence: no instance-attribute getter is invoked.
- Exports both BOM filters only under `%TEMP%\CimatronCustomization\Step07\<timestamp>`.
- Records CSV filenames, headers, row counts, detected material-column candidates, and material values only for rows matching the known-answer model title.
- Explicitly does not interpret visibility-related differences between `cmNoFiltering` and `cmVisibleOnly`.
- Adds a model-folder filename/size/timestamp snapshot before/after in addition to the existing model-file `IsModified`, timestamp and size evidence.
- A `CHANGED_OR_UNVERIFIED` model-file or folder guard returns a non-zero verifier result and blocks capability interpretation.
- U17 is recorded as `NOT AVAILABLE FROM RETAINED 07A EVIDENCE`; no new reflection was added.

## Production Impact

None. Production `src/**`, Plugin behavior, CR/SA implementation, configuration, installer and customer models are unchanged.

## Required Known-Answer Setup — Do This Before Running the Verifier

1. Open disposable `KA-PART-1`.
2. Select B1 **body entity 4**, not a face.
3. In Cimatron UI, create one body-level custom manufacturing attribute.
4. Record its exact **name, type and value**.
5. Save `KA-PART-1`.
6. Reopen/reload `KA-ASM-1` so the no-mutation baseline begins after this deliberate setup change.
7. Confirm the Part/model material known answer (currently observed as `1.2738`, unless intentionally changed).

Do not treat the Part/model `1.2738` property as proof of U13. The body attribute is a separate known-answer input.

## Workstation Validation

First run the governed quality gate:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

Only after it passes, with `KA-ASM-1` active, run exactly one 07C-3 verification using the values you recorded:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --verify-component-properties --expect Assembly --model-title "KA-PART-1" --entity-id 4 --known-attribute-name "<EXACT_ATTRIBUTE_NAME>" --known-attribute-value "<EXACT_ATTRIBUTE_VALUE>" --known-material "1.2738"
```

If the material known answer is intentionally different, replace `1.2738` with the exact recorded value.

## Return Evidence

Return:

- exact body attribute name/type/value created in the Cimatron UI;
- confirmation that KA-PART-1 was saved and KA-ASM-1 reopened/reloaded before the run;
- quality-gate capture;
- generated `api-capability-component-properties-*.txt`;
- any unexpected file/folder change observed by the guard.

## Stopping Rule

One governed live run only. Do not automatically rerun or broaden the probe. Any unresolved U13/U15 behavior becomes a documented limitation unless a separate corrective scope is explicitly approved.

## Validation State

**AWAITING USER SETUP + WORKSTATION QUALITY GATE + ONE LIVE 07C-3 RUN.**

The AI agent did not build, run tests/coverage, launch Cimatron, or claim PASS for 0.20.18.
