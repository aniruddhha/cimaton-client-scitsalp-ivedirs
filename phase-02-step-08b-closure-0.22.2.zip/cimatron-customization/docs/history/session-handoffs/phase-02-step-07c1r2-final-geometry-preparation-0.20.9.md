# Phase 02 Step 07C-1R2 — Final Geometry Preparation — 0.20.9

**State:** IMPLEMENTED / AWAITING USER VALIDATION / 07C-1 OPEN / 07C-2 BLOCKED  
**Context health:** GREEN

## Approved scope

Prepare the existing geometry diagnostic for one final known-answer evidence cycle covering a 30° Z-rotated UCS, two face-90 entity-point distances, and three face-90 piercing rays. No production or 07C-2 work is authorized.

## What changed

- `--verify-geometry` accepts repeated `--point` arguments.
- It accepts repeated matched `--ray-origin` / `--ray-direction` pairs.
- With `--face-id`, piercing targets that guarded `cmFace`; the final known-answer target is face 90.
- Installed absence of `SurfacesArea` is recorded as `NOT_AVAILABLE`.
- Tool version advanced to 0.20.9.

## Workstation sequence

1. Run the standard 0.20.9 quality gate. Stop on any failure.
2. In the disposable `KA-PART-1`, create UCS `KA_UCS_30Z` at the same origin as UCS 2, rotated exactly +30° about Z, with no translation.
3. Save, reopen, and confirm the model is healthy.
4. Activate `KA_UCS_30Z` and run:

```powershell
& "C:\Program Files\Cimatron\Cimatron\2026.0\Program\CimatronCustomization.ApiCapabilityVerification.exe" --discover-geometry-targets --expect Part
```

5. Record the actual active-UCS entity ID. Do not guess it.
6. Run the final geometry command from `VERSION.md` / `STEP-07-KNOWN-ANSWER-MODELS.md`, replacing `<ROTATED_UCS_ID>` with the discovered ID.
7. Return the quality-gate capture, discovery capture/evidence, final geometry capture/evidence, and confirmation that the intended 30° UCS was active.

## Expected interpretation targets

- Distance case 1: face 90 to `(110,30,20)` should establish the basic 10 mm/frame behavior.
- Distance case 2: `(110,70,20)` distinguishes bounded-face distance from support-plane distance.
- Piercing cases 1–3 distinguish basic hit, face-boundary behavior, and ray-vs-infinite-line behavior.
- Rotated-UCS B1/face boxes settle whether `GetBoundingBoxByUCS` follows rotated axes.
- Final no-mutation evidence must remain `UNCHANGED`.

No result is pre-declared PASS. Raw workstation evidence controls classification.
