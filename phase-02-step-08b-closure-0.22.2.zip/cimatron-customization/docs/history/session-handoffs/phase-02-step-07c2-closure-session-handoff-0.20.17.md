# Session Handoff — Phase 02 / Step 07C-2 Closure

## Version
`0.20.17`

## Context status
**GREEN — 07C-2 CLOSED / USER VALIDATED.**

## Authoritative closure evidence
- `docs/history/evidence/step-07c2/quality-gate-20260930-033812.txt`
  - Release x64 build PASS; 0 warnings / 0 errors.
  - Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS.
  - Coverage/local quality gates PASS; exit code 0.
- `docs/history/evidence/step-07c2/api-capability-assembly-context-20260930-034145.txt`
  - `ToolVersion: 0.20.17`; active context Assembly.
  - one nested + two top-level `KA-PART-1` occurrences.
  - local/root transforms recorded.
  - `GetAssemblyEntity` resolved B1 body ID 4 for all three.
  - `InstanceByAssemblyEnt` matched 6→6, 12→12, 13→13.
  - `IAssInstance.Lock` getter readable.
  - active assembly UCS resolved; assembly bounding box returned.
  - three highlight pauses completed; selection restore completed.
  - model no-mutation evidence `UNCHANGED`.

## User confirmations
User confirmed all of the following **YES**:
- Match1 / nested instance 6 highlighted the correct body.
- Match2 / top-level instance 12 highlighted the correct body.
- Match3 / top-level instance 13 highlighted the correct body.
- final selection was empty.
- no unsaved-change indicator remained.

User then explicitly approved Step 07C-2 closure.

## Capability register state
- U7 `GetAssemblyEntity`: **VERIFIED**.
- U8 `GetInstancesByModel` / `SubInstances`: **VERIFIED** for the known-answer traversal; direct model lookup returned two top-level matches and nested traversal reached the third.
- U9 `InstanceByAssemblyEnt`: **VERIFIED**.
- U10 `IAssInstance.Lock` getter: **VERIFIED** as readable across the known-answer tree.
- U11 `GetAssemblyBoundingBox`: **PARTIALLY VERIFIED** — operational result obtained, but UI overall assembly extents were unavailable for independent absolute comparison.
- U12 temporary assembly-context highlight/restore: **VERIFIED**.

## Locked known answers retained
- exact model title: `KA-PART-1`.
- B1 body entity ID: `4`.
- independent top-level B1-to-B1 minimum distance: `25.000 mm`.
- measurement UCS: `UCS10_1`.
- UI assembly extents: not available.
- detailed tree/state and B1 corner measurements remain user-recorded evidence; do not invent missing numeric values.

## Documented limitation — do not re-probe in 07C-2
`MinDistancePos` returned distance `0` for pairs 1-2, 1-3 and 2-3 with identical reported closest points, even though the occurrences have different transformations and the independent top-level B1 gap is `25.000 mm`. Therefore direct `MinDistancePos` on these occurrence-derived assembly entities is **not validated for cross-component assembly placement**. Per the approved stopping rule this is a limitation, not a reason for another 07C-2 experiment.

## Superseded troubleshooting evidence
Earlier assembly-context files reporting `ToolVersion: 0.20.13` were produced from a stale workstation source tree. They are troubleshooting evidence only and must not override the 0.20.17 closing evidence.

## Governance boundary
- No production `src/**` behavior was changed by this closure handoff.
- All Step 07 runtime evidence is development/out-of-process only.
- Do not promote any Step 07 surface to production without the later in-process confirmation boundary.
- Step 07C-3 is **NOT STARTED** by this handoff. The next session must read `AGENTS.md` and this handoff before proposing or implementing further work.
