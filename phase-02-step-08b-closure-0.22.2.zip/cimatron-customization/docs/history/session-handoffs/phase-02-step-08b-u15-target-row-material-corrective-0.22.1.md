# Phase 02 — Step 08B U15 Target-Row Material Corrective — 0.22.1

## Project
Cimatron 2026 customization platform.

## Phase / Step
- Phase: 02 — CR Platform Extensions
- Step: 08B — U13/U15/U8/U7/U12 In-Process Confirmation
- Version: 0.22.1
- Context: GREEN
- Status: U15 CORRECTIVE PREPARED / AWAITING USER CLEAN QUALITY GATE

## User evidence that triggered the corrective
- `artifacts/console-captures/quality-gate-20261002-124744.txt` — user workstation clean gate: Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gate PASS, exit code 0.
- `artifacts/diagnostics/step-08b-live-validation-u15-read-error-0.22.0.png` — first governed Step 08B live Result Report.
- Live evidence: U8 PASS, U13 body/attribute PASS, U7 PASS, U12 nested production highlight reference prepared, U15 Error, no-mutation PASS, temp cleanup PASS.
- U12 Result Report Highlight action was not executed because the single-run stopping rule fired on U15.

## Root cause
`CimatronBomMaterialExporter` configured both `Standard Number` and `Material` as required for every parsed BOM row. The validated `ITabularDataReader` therefore stopped at an unrelated source row whose Material cell was blank, before the adapter could find `Standard Number=KA-PART-1`.

Observed error:

```text
READ_ERROR TABULAR_REQUIRED_VALUE_MISSING: Required value for logical column 'Material' is missing at source row 2.
```

This error is a readback-contract defect in the Step 08B adapter. It is not evidence that the known-answer `KA-PART-1` row lacks material `1.2738`.

## Approved corrective
- `Standard Number` remains required for every parsed row.
- `Material` becomes optional at table-read level so unrelated BOM rows may be blank.
- After locating rows where `Standard Number=KA-PART-1`, Material is mandatory for the target row itself.
- Missing/blank target Material returns explicit `READ_ERROR` and does not become a business-rule failure.
- Preserve `IBOM.Export(... cmNoFiltering ...)`, locked Step 07 header, `ITabularDataReader`, governed Step08B temp folder/cleanup, no-mutation guards, and U8/U13/U7/U12 behavior.
- No alternate API/filter/path and no CR-04 logic.

## Approved files changed
- `src/CimatronCustomization.CimatronIntegration/CimatronBomMaterialExporter.cs`
- `tests/CimatronCustomization.Application.Tests/Step08BInProcessConfirmationTests.cs`
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs`
- `VERSION.md`
- `CHANGELOG.md`
- `IMPLEMENTATION-HISTORY.md`
- `docs/platform/CIMATRON-2026-API-CAPABILITY-VERIFICATION.md`
- `docs/time-tracking/PROJECT-TIMESHEET.csv`
- `CHECKSUMS.sha256`
- this handoff and the supplied validation evidence files.

## Version-metadata boundary
Production `AssemblyInfo.cs` files are intentionally unchanged from 0.22.0 because they were not part of the explicitly approved 0.22.1 corrective file list. Package/product documentation advances to 0.22.1 without silently broadening the approved source scope.

## Validation boundary
The agent did not build, run tests/coverage, launch Cimatron, or claim PASS for 0.22.1.

User must next run:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

Required before any live rerun:
- Release x64 PASS
- 0 warnings / 0 errors
- Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS
- Coverage gate PASS
- Local quality gate PASS
- exit code 0

After the clean gate is reviewed, a new separately governed single live `KA-ASM-1` run may be authorized. If no stopping condition occurs, the user then performs exactly one Result Report Highlight action on the U12 finding.

## Stopping rule
Any Failed/Error/READ_ERROR, wrong known answer, unexpected highlight/restoration result, or no-mutation failure stops the separately governed rerun. No automatic retry, alternate API/filter/path, or further corrective code without explicit approval.

## Next action
User runs the 0.22.1 quality gate and returns the capture. Do not run Cimatron yet.
