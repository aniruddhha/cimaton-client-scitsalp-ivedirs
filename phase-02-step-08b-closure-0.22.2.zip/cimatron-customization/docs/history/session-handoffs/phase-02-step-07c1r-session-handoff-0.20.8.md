# Phase 02 Step 07C-1R — Session Handoff — 0.20.8

**Phase:** 02 — CR Platform Extensions  
**Step:** 07C-1R — Geometry Services remaining-evidence resolution  
**Version:** 0.20.8  
**State:** **07C-1 OPEN / FINAL EVIDENCE PENDING / 07C-2 BLOCKED**  
**Context health:** GREEN

## 1. Purpose of this handoff

Carry the validated 0.20.7 quality-gate/runtime evidence and the final 07C-1 interpretation corrections into the next session without changing production, diagnostic, test, configuration, or known-answer model behavior.

## 2. User-validated workstation evidence

### 0.20.7 quality gate

Evidence: `quality-gate-20260929-190027.txt`.

- Release x64 build: PASS.
- 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration, Infrastructure tests: PASS.
- Coverage collection/gate: PASS.
- Local quality gate: PASS.
- Exit code: 0.

### Discovery evidence

Evidence: `api-capability-geometry-known-answer-discovery-20260929-190407.txt`.

- Active context: Part; unit: `cmMillimeter`; model: `KA-PART-1`.
- B1 = body ID 4; B2 = body ID 5.
- B1: volume `227576.685834808`, centre `[50,30,20]`, surface area `26684.9371823929`.
- B2: volume `64000`, centre `[145,30,20]`, surface area `9600`.
- B1↔B2 min distance: `25 mm`, points `(100,50,40)` and `(125,50,40)`.
- face 90 remains `cmFace`.
- edge 89 remains `cmConvex`; edge 95 remains `cmConcave`.
- UCS candidates exposed: IDs 2 and 249.
- No mutation: UNCHANGED.

### Geometry resolution evidence

Evidence: `api-capability-geometry-20260929-191114.txt`.

- Primary UCS ID 2 resolves; second/reference candidate UCS ID 249 resolves.
- B1 face-list bounding box:
  - UCS 2: `[0,0,0,100,60,40]`
  - UCS 249: `[-50,-60,0,50,0,40]`
- body-list `GetBoundingBoxByUCS` returned `[1,1,1,0,0,0]` in both UCS frames; do not use this as geometry extents.
- face 90 resolves as `cmFace`.
- face 90 bounding box:
  - UCS 2: `[100,0,0,100,60,40]`
  - UCS 249: `[50,-60,0,50,0,40]`
- `SurfacesArea`: member absent from installed `IGeomServices`; classify **NOT AVAILABLE**, not BLOCKED.
- `GetPiercingPoints`: NOT TESTED because no ray was supplied in this run.
- `GetEntityPointDistance`: NOT TESTED because no point was supplied in this run.
- no mutation: UNCHANGED.

## 3. UCS interpretation — important correction

Do **not** call UCS 249 “Main UCS.” Current evidence only supports “second/reference UCS candidate.”

The B1 and face-90 boxes show UCS 249 has axes parallel to UCS 2 and is consistent with a `(50,60,0)` translation. This means the current comparison does **not** verify whether `GetBoundingBoxByUCS` truly orients the box to rotated UCS axes. It verifies only the axis-parallel case.

CR-01 and CR-25 require that orientation question to be settled before promotion. The current proposal is to add one known-answer UCS rotated `30°` about Z, then discover its real entity ID and compare B1/face-90 boxes in the same final 07C-1 run. This model change is **not implemented** in 0.20.8. Obtain explicit approval before changing the known-answer model or tool.

## 4. Final known-answer inputs for remaining APIs

All coordinates below are in UCS 2, where B1 spans `[0,0,0]..[100,60,40]` and face 90 is the bounded plane `x=100`, `y=0..60`, `z=0..40`.

### `GetEntityPointDistance`

| Point | Expected | Purpose |
|---|---|---|
| `(110,30,20)` | `10` | perpendicular distance + confirms input coordinate frame |
| `(110,70,20)` | `sqrt(200) ≈ 14.1421356237` if bounded-face distance; `10` if infinite-plane distance | determines whether face edges are respected |

If the first point does not return 10, preserve the raw result as a coordinate-frame/contract finding rather than forcing a PASS/FAIL interpretation.

### `GetPiercingPoints`

| Origin → direction | Expected | Purpose |
|---|---|---|
| `(150,30,20) → (-1,0,0)` | hit `(100,30,20)` | basic hit + raw returned-array layout |
| `(150,70,20) → (-1,0,0)` | no hit if bounded face edges are respected | bounded-face semantics |
| `(150,30,20) → (+1,0,0)` | empty = one-way ray; hit at x=100 = infinite-line behavior | relevant to CR-10 guiding length |

Raw returned arrays must be recorded.

## 5. Final run rules

- Existing `--verify-geometry` mode only; no speculative new mode.
- One controlled run after all known inputs and any rotated-UCS ID are established.
- No mutation check must run again and remain UNCHANGED.
- Each remaining item must finish with an explicit evidence-backed state.
- `SurfacesArea` remains **NOT AVAILABLE** for installed 2026 SP2P1.
- Do not silently reinterpret point/ray coordinate frames if observed values differ.
- Do not touch 07C-2.

## 6. Closure boundary

07C-1 is **not closed** in 0.20.8. Closure requires review of the final distance/piercing run and resolution of the rotated-UCS bounding-box orientation question (or an explicit user-approved carry-forward limitation). Only after user approval of 07C-1 closure may 07C-2 begin.

## 7. Change discipline for 0.20.8

Documentation/time-ledger/checksum/session-handoff only. No `src/**`, diagnostic source, tests, configuration, or model file is intentionally changed.
