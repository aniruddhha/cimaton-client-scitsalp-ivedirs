# Phase 02 Step 07C-1R — Quality-Gate Corrective Handoff — 0.20.7

**Phase:** 02 — CR Platform Extensions  
**Step:** 07C-1R — remaining Geometry Services evidence resolution  
**Version:** 0.20.7  
**State:** **AWAITING USER QUALITY GATE**

## Trigger evidence

User-supplied `quality-gate-20260929-185330.txt` for 0.20.6 failed during Release x64 compilation with CS1061 at `GeometryServicesVerification.cs(141,82)`: installed `interop.CimBaseAPI.IFace` does not expose `Area`. Release build exit code was `1`; no governed test/coverage PASS may be claimed from that run.

## Approved corrective delta

- Remove only the invalid compile-time `IFace.Area()` call.
- Keep face ID/type guarding unchanged.
- Keep the existing reflection-guarded `IGeomServices.SurfacesArea` observation as the only face-area API path in 07C-1R.
- If `SurfacesArea` is absent or invocation fails, preserve explicit blocked/raw error evidence; do not guess another API.
- Keep all other 0.20.6 07C-1R arguments, bounding-box comparisons, point/ray status handling, and no-mutation behavior unchanged.
- No production `src/**` changes. 07C-2 remains blocked.

## User action

Close Cimatron and rerun the full captured quality gate:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Invoke-And-Capture.ps1 -Task quality-gate
```

Return the capture before any live 07C-1R execution. The agent has not run build/tests/Cimatron and does not claim 0.20.7 PASS.
