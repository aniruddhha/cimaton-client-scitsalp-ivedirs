# Version

Product Version: `0.22.2`

Phase: 02 — CR Platform Extensions  
Step: 08B — U13/U15/U8/U7/U12 In-Process Confirmation

Status: **CLOSED / USER VALIDATED**.

## Step 08B closure result

User workstation evidence confirms the approved Assembly-context in-process foundation scope:

- **U8 — IN-PROCESS VERIFIED:** `KA-ASM-1` contained three `KA-PART-1` occurrences in the locked structure: two top-level occurrences through `GetInstancesByModel` and one nested occurrence reached through recursive `SubInstances`. Runtime instance IDs remain evidence only.
- **U13 — IN-PROCESS VERIFIED:** on the nested occurrence, body ID `4` resolved exactly once as `cmBody` through `IAssInstance.GetAllEntities()` and exact named lookup `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` returned `KNOWN_ANSWER_07C3`. Returned `IAttribute.Name` remains evidence-only. `GetAllEntities()` remains classified as installed-Interop + governed runtime evidence only because no authoritative SDK index entry was found.
- **U7 — IN-PROCESS VERIFIED:** the nested Part body mapped into active Assembly context through `IAssemblyModel.GetAssemblyEntity`.
- **U12 — IN-PROCESS VERIFIED:** the normal production Result Report `Highlight` action visibly highlighted the intended nested `KA-PART-1` body. After closing/clearing the report, the highlight restored and the user confirmed the Assembly remained unmodified.
- **U15 — IN-PROCESS VERIFIED for the approved `cmNoFiltering` material-read scope:** BOM export/readback completed through the existing `ITabularDataReader`; target `Standard Number=KA-PART-1` occurred exactly once and `Material=1.2738` matched the locked Step 07 known answer. This closure does not promote `cmVisibleOnly` visibility-filter semantics beyond their existing Step 07 evidence.
- **No-mutation:** programmatic document modified-state, model file timestamp/length, and model-folder listing guards passed.
- **Temp cleanup:** the governed `%TEMP%\CimatronCustomization\Step08B\<timestamp>\` run directory was removed after readback.
- **Quality gate:** `quality-gate-20261002-131500.txt` shows Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS, and exit code 0.

The earlier 0.22.0 U15 `READ_ERROR` is retained for traceability. The 0.22.1 target-row corrective was validated by the successful governed rerun.

## Production / CR boundary

- No CR-04 business logic is introduced by this closure.
- Capability-named ports/adapters from Step 08B are now in-process verified for the approved scope and may be considered by later CR-specific implementation only after normal CR planning/approval.
- DF-05 remains active: the developer-visible Step 08B diagnostic must be gated/removed before D5 client packaging.
- Production assembly/file metadata remains `0.22.0.0`; 0.22.2 is documentation/evidence closure only and does not silently broaden production-source scope.

## Next boundary

Step 08B is closed. No later Step 08 capability group or CR implementation is started by 0.22.2.
