# Development Dependencies

These dependencies are development/quality tooling only and are not part of the normal client runtime package.

| Dependency | Version | Purpose | Source | License | Approval |
|---|---:|---|---|---|---|
| Microsoft.CodeAnalysis.NetAnalyzers | 10.0.401 | Roslyn/.NET correctness, security, performance, maintainability and API-usage analyzers | NuGet.org / Microsoft | MIT | Approved in Phase 01 Step 04 |
| dotnet-coverage | 18.11.0 | Coverage collection and Cobertura/XML report generation | NuGet.org / Microsoft | Microsoft Software License Terms — Microsoft .NET Library | Approved in Phase 01 Step 04 |
| dotnet-sonarscanner | 11.3.0 | SonarScanner for .NET / SonarQube Community Build analysis | NuGet.org / SonarSource | GNU LGPL v3.0 | Approved in Phase 01 Step 04 |

## Controls

- Versions are pinned; no floating versions are permitted.
- Dependency upgrades require normal project approval.
- These tools remain on the development side and are not shipped to clients.
- `dotnet tool restore` restores the pinned local tools declared in `.config/dotnet-tools.json`.

# Approved Client Runtime Dependencies

| Dependency | Version | Purpose | Source | License | Approval |
|---|---:|---|---|---|---|
| ExcelDataReader | 3.9.0 | Read `.xlsx`, `.xls`, and `.csv` tabular master-data files for the WP8 platform adapter | NuGet.org / ExcelDataReader project | MIT | Approved by user for Phase 02 Step 06B on 2026-09-28; Cimatron in-process compatibility still requires live validation |
| System.ValueTuple | 4.5.0 | Pinned transitive runtime dependency required by ExcelDataReader 3.9.0 on its .NET Framework target | NuGet.org / Microsoft | MIT | Approved as part of the ExcelDataReader 3.9.0 dependency set; host compatibility still requires live validation |

## Step 06B runtime controls

- Runtime versions are pinned; no floating versions are permitted.
- Only the `ExcelDataReader` base package is used. `ExcelDataReader.DataSet` is intentionally not added.
- Microsoft Excel / Office COM automation is not required and is not used.
- Initial advertised formats are `.xlsx`, `.xls`, and `.csv` only.
- The Infrastructure adapter opens input files with `FileShare.ReadWrite` so normal Excel-open files can be read where Windows/filesystem permissions allow it.
- Initial safety limits are 25 MiB per input file and 100,000 non-empty mapped data rows.
- CSV is treated as a single table; the worksheet name in `TabularSourceDefinition` has no effect for CSV input.
- Decimal strings are parsed with invariant culture until a real customer workbook proves a locale-specific policy is required. Native numeric Excel cells are converted from their numeric CLR value.
- Customer cell contents are not logged by this adapter.
- Cimatron 2026 host-process binding compatibility is **NOT VERIFIED** by package preparation. The user must run the dependency preflight before build and later perform the approved in-process probe before Step 06B is closed.
- Client installer/package impact: the eventual production client package must include the approved runtime dependency assemblies resolved by the pinned NuGet graph beside the plugin, subject to successful host-process validation.
