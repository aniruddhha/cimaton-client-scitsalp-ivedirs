using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class RuleParameterTests
    {
        internal static void RunAll()
        {
            DefinitionStoresMetadata();
            InvalidDefinitionRangesAreRejected();
            SetIsCaseInsensitiveAndTyped();
            SetRejectsDuplicateValues();
            ContextCanBeEnrichedWithoutLosingRunIdentity();
            ProbeUsesValidatedParameter();
            ParameterizedFeatureLoadsThroughExecutionPipeline();
            MissingProviderBecomesControlledError();
            ProviderFailureBecomesControlledError();
        }

        private static void DefinitionStoresMetadata()
        {
            RuleParameterDefinition p = new RuleParameterDefinition("Ratio", RuleParameterType.Decimal, "ratio", 0m, 10m, true);
            AssertEqual("Ratio", p.Name, "Parameter name"); AssertEqual(RuleParameterType.Decimal, p.Type, "Parameter type"); AssertEqual("ratio", p.Unit, "Unit");
            AssertEqual(0m, p.Minimum.Value, "Minimum"); AssertEqual(10m, p.Maximum.Value, "Maximum"); AssertEqual(true, p.IsRequired, "Required");
        }

        private static void InvalidDefinitionRangesAreRejected()
        {
            Expect<ArgumentException>(() => new RuleParameterDefinition("X", RuleParameterType.Decimal, "mm", 2m, 1m, true));
            Expect<ArgumentException>(() => new RuleParameterDefinition("X", RuleParameterType.String, "", 0m, null, true));
        }

        private static void SetIsCaseInsensitiveAndTyped()
        {
            RuleParameterDefinition d = new RuleParameterDefinition("Count", RuleParameterType.Integer, "", 1m, 10m, true);
            RuleParameterSet set = new RuleParameterSet(new[] { new RuleParameterValue(d, "3", 3) });
            AssertEqual(1, set.Count, "Set count"); AssertEqual(3, set.GetRequired("count").AsInteger(), "Typed integer");
            RuleParameterValue ignored; AssertEqual(true, set.TryGet("COUNT", out ignored), "Case insensitive lookup");
            Expect<InvalidOperationException>(() => set.GetRequired("Missing"));
        }

        private static void SetRejectsDuplicateValues()
        {
            RuleParameterDefinition a = new RuleParameterDefinition("X", RuleParameterType.Integer, "", null, null, true);
            RuleParameterDefinition b = new RuleParameterDefinition("x", RuleParameterType.Integer, "", null, null, true);
            Expect<ArgumentException>(() => new RuleParameterSet(new[] { new RuleParameterValue(a, "1", 1), new RuleParameterValue(b, "2", 2) }));
        }

        private static void ContextCanBeEnrichedWithoutLosingRunIdentity()
        {
            FeatureExecutionContext original = new FeatureExecutionContext("corr", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part));
            RuleParameterDefinition d = new RuleParameterDefinition("Flag", RuleParameterType.Boolean, "", null, null, true);
            RuleParameterSet set = new RuleParameterSet(new[] { new RuleParameterValue(d, "true", true) });
            FeatureExecutionContext enriched = original.WithRuleParameters(set);
            AssertEqual("corr", enriched.CorrelationId, "Correlation preserved"); AssertEqual(true, enriched.RuleParameters.GetRequired("Flag").AsBoolean(), "Parameter available");
        }

        private static void ProbeUsesValidatedParameter()
        {
            RuleParameterDefinition d = new RuleParameterDefinition(RuleParameterProbeFeature.ProbeParameterName, RuleParameterType.Decimal, "mm", 0m, 1000m, true);
            RuleParameterSet set = new RuleParameterSet(new[] { new RuleParameterValue(d, "25.0", 25m) });
            FeatureExecutionOutcome result = new RuleParameterProbeFeature().Execute(new FeatureExecutionContext("corr", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part), set));
            AssertEqual(ResultStatus.Passed, result.Status, "Probe status"); AssertEqual(1, result.Findings.Count, "Probe finding");
        }

        private static void ParameterizedFeatureLoadsThroughExecutionPipeline()
        {
            RecordingLogger logger = new RecordingLogger(); RecordingProvider provider = new RecordingProvider(false);
            RuleParameterProbeFeature feature = new RuleParameterProbeFeature();
            ExecuteRegisteredFeature executor = new ExecuteRegisteredFeature(new FeatureRegistry(new IApplicationFeature[] { feature }), logger, "0.14.10", provider);
            FeatureExecutionReport report = executor.Execute(feature.Definition.Id, new FeatureExecutionContext("corr", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026");
            AssertEqual(ResultStatus.Passed, report.Status, "Parameterized report"); AssertEqual(true, provider.Called, "Provider called");
        }

        private static void MissingProviderBecomesControlledError()
        {
            RuleParameterProbeFeature feature = new RuleParameterProbeFeature(); RecordingLogger logger = new RecordingLogger();
            FeatureExecutionReport report = new ExecuteRegisteredFeature(new FeatureRegistry(new IApplicationFeature[] { feature }), logger, "0.14.10")
                .Execute(feature.Definition.Id, new FeatureExecutionContext("corr", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026");
            AssertEqual(ResultStatus.Error, report.Status, "Missing provider status");
        }

        private static void ProviderFailureBecomesControlledError()
        {
            RuleParameterProbeFeature feature = new RuleParameterProbeFeature(); RecordingLogger logger = new RecordingLogger();
            FeatureExecutionReport report = new ExecuteRegisteredFeature(new FeatureRegistry(new IApplicationFeature[] { feature }), logger, "0.14.10", new RecordingProvider(true))
                .Execute(feature.Definition.Id, new FeatureExecutionContext("corr", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026");
            AssertEqual(ResultStatus.Error, report.Status, "Provider error status"); AssertEqual(true, report.Message.Contains("ProbeLength"), "Error names parameter");
        }

        private sealed class RecordingProvider : IRuleParameterProvider
        {
            private readonly bool fail; public bool Called;
            internal RecordingProvider(bool fail) { this.fail = fail; }
            public RuleParameterSet LoadFor(FeatureDefinition definition)
            {
                Called = true; if (fail) throw new InvalidOperationException("Rule parameter 'ProbeLength' is invalid in configuration file 'test.xml'.");
                RuleParameterDefinition d = definition.RuleParameterDefinitions[0];
                return new RuleParameterSet(new[] { new RuleParameterValue(d, "25.0", 25m) });
            }
        }
        private sealed class RecordingLogger : IApplicationLogger { public void Log(ApplicationLogEntry entry) { } }
        private static void Expect<T>(Func<object> action) where T : Exception { try { GC.KeepAlive(action()); } catch (T) { return; } throw new InvalidOperationException("Expected " + typeof(T).Name); }
        private static void AssertEqual<T>(T e, T a, string n) { if (!EqualityComparer<T>.Default.Equals(e,a)) throw new InvalidOperationException(n + " expected '"+e+"' but got '"+a+"'."); }
    }
}
