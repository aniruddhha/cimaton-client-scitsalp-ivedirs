using System;

namespace CimatronCustomization.Application.Tests
{
    internal static class ReadCurrentCimatronSessionTests
    {
        internal static void RunAll()
        {
            ExecuteReturnsSnapshotFromSessionPort();
            ConstructorRejectsNullSessionPort();
        }

        private static void ExecuteReturnsSnapshotFromSessionPort()
        {
            CimatronSessionSnapshot expected =
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part);
            StubCimatronSession session = new StubCimatronSession(expected);
            ReadCurrentCimatronSession useCase = new ReadCurrentCimatronSession(session);

            CimatronSessionSnapshot actual = useCase.Execute();

            if (!ReferenceEquals(expected, actual))
            {
                throw new InvalidOperationException("ReadCurrentCimatronSession must return the snapshot supplied by ICimatronSession.");
            }

            if (session.CallCount != 1)
            {
                throw new InvalidOperationException("ReadCurrentCimatronSession must call ICimatronSession.GetCurrentSession exactly once.");
            }
        }

        private static void ConstructorRejectsNullSessionPort()
        {
            try
            {
                ReadCurrentCimatronSession useCase = new ReadCurrentCimatronSession(null);
                GC.KeepAlive(useCase);
            }
            catch (ArgumentNullException exception) when (exception.ParamName == "session")
            {
                return;
            }

            throw new InvalidOperationException("ReadCurrentCimatronSession must reject a null ICimatronSession dependency.");
        }

        private sealed class StubCimatronSession : ICimatronSession
        {
            private readonly CimatronSessionSnapshot snapshot;

            internal StubCimatronSession(CimatronSessionSnapshot snapshot)
            {
                this.snapshot = snapshot;
            }

            internal int CallCount { get; private set; }

            public CimatronSessionSnapshot GetCurrentSession()
            {
                CallCount++;
                return snapshot;
            }
        }
    }
}
