using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class ViewportPickContractTests
    {
        private static readonly string[] AssemblyOccurrencePath = { "ROOT", "SUB1", "INSTANCE2" };

        internal static void RunAll()
        {
            RequestRequiresExplicitAllowedTypes();
            RequestDeduplicatesAndChecksTypes();
            PickedResultRequiresDocumentEntityAndType();
            AssemblyReadyResultCarriesDocumentAndOccurrenceShape();
            NonPickedOutcomesUseSharedContract();
            OutcomeEnumMatchesApprovedContract();
        }

        private static void RequestRequiresExplicitAllowedTypes()
        {
            ExpectException<ArgumentNullException>(() => Consume(new ViewportPickRequest(null)));
            ExpectException<ArgumentException>(() => Consume(new ViewportPickRequest(Array.Empty<ViewportEntityType>())));
            ExpectException<ArgumentException>(() => Consume(new ViewportPickRequest(new[] { ViewportEntityType.Unknown })));
        }

        private static void RequestDeduplicatesAndChecksTypes()
        {
            ViewportPickRequest request = new ViewportPickRequest(new[]
            {
                ViewportEntityType.Face,
                ViewportEntityType.Body,
                ViewportEntityType.Face
            });

            AssertEqual(2, request.AllowedEntityTypes.Count, "Allowed entity type count");
            AssertEqual(true, request.Allows(ViewportEntityType.Face), "Face allowed");
            AssertEqual(true, request.Allows(ViewportEntityType.Body), "Body allowed");
            AssertEqual(false, request.Allows(ViewportEntityType.Edge), "Edge not allowed");
        }

        private static void PickedResultRequiresDocumentEntityAndType()
        {
            ViewportDocumentIdentity identity = Identity();
            ExpectException<ArgumentNullException>(() => Consume(new ViewportPickResult(
                "c", ViewportPickOutcome.Picked, null, 10, ViewportEntityType.Face, null, "ENTITY_PICKED", "Picked.")));
            ExpectException<ArgumentException>(() => Consume(new ViewportPickResult(
                "c", ViewportPickOutcome.Picked, identity, null, ViewportEntityType.Face, null, "ENTITY_PICKED", "Picked.")));
            ExpectException<ArgumentException>(() => Consume(new ViewportPickResult(
                "c", ViewportPickOutcome.Picked, identity, 10, ViewportEntityType.Unknown, null, "ENTITY_PICKED", "Picked.")));
        }

        private static void AssemblyReadyResultCarriesDocumentAndOccurrenceShape()
        {
            ViewportDocumentIdentity identity = Identity();
            ViewportPickResult result = new ViewportPickResult(
                "correlation",
                ViewportPickOutcome.Picked,
                identity,
                48,
                ViewportEntityType.Face,
                AssemblyOccurrencePath,
                "ENTITY_PICKED",
                "Picked.");

            AssertEqual("doc-token", result.SourceDocument.SessionDocumentToken, "Document token");
            AssertEqual("Part", result.SourceDocument.DocumentType, "Document type");
            AssertEqual(48, result.EntityId.Value, "Entity id");
            AssertEqual(ViewportEntityType.Face, result.EntityType, "Entity type");
            AssertEqual(3, result.OccurrencePath.Count, "Occurrence path count");
        }

        private static void NonPickedOutcomesUseSharedContract()
        {
            ViewportPickResult busy = ViewportPickResult.WithoutEntity(
                "busy", ViewportPickOutcome.Busy, null, "PICK_ALREADY_ACTIVE", "Busy.");
            AssertEqual(ViewportPickOutcome.Busy, busy.Outcome, "Busy outcome");
            AssertEqual(false, busy.EntityId.HasValue, "Busy entity id");

            ExpectException<ArgumentException>(() => ViewportPickResult.WithoutEntity(
                "bad", ViewportPickOutcome.Picked, Identity(), "ENTITY_PICKED", "Picked."));
        }

        private static void OutcomeEnumMatchesApprovedContract()
        {
            string[] names = Enum.GetNames(typeof(ViewportPickOutcome));
            string[] expected = { "Picked", "Cancelled", "Unsupported", "Failed", "Busy", "StaleResult" };
            AssertEqual(expected.Length, names.Length, "Outcome enum count");
            for (int index = 0; index < expected.Length; index++)
            {
                AssertEqual(expected[index], names[index], "Outcome enum item " + index);
            }
        }

        private static ViewportDocumentIdentity Identity()
        {
            return new ViewportDocumentIdentity("doc-token", "Part", "Part A", "C:\\Models\\PartA.elt");
        }

        private static void Consume(object value)
        {
            GC.KeepAlive(value);
        }

        private static void ExpectException<TException>(Action action) where TException : Exception
        {
            try { action(); }
            catch (TException) { return; }
            throw new InvalidOperationException("Expected " + typeof(TException).Name + ".");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
            {
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
            }
        }
    }
}
