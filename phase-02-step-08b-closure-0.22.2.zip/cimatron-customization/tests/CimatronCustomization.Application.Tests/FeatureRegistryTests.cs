using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class FeatureRegistryTests
    {
        private static readonly string[] SingleRequirement = { "REQ" };

        internal static void RunAll()
        {
            RegisteredFeatureCanBeDiscoveredAndExecuted();
            FeatureLookupIsCaseInsensitive();
            DefinitionsPreserveRegistrationOrder();
            DuplicateFeatureIdsAreRejected();
            InvalidDefinitionsAreRejected();
            ValidationMustDeclareReadOnlyIntent();
            ActivePartReadinessFeaturePublishesMetadataAndExecutes();
        }

        private static void RegisteredFeatureCanBeDiscoveredAndExecuted()
        {
            StubFeature feature = new StubFeature("TEST-VALIDATION", "Test Validation", FeatureKind.Validation, true);
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[] { feature });
            FeatureDefinition definition = registry.GetDefinition("TEST-VALIDATION");
            FeatureExecutionOutcome outcome = registry.Execute("TEST-VALIDATION", Context());
            AssertEqual("TEST-VALIDATION", definition.Id, "Registered feature id");
            AssertEqual(ResultStatus.Passed, outcome.Status, "Registered feature outcome");
        }

        private static void FeatureLookupIsCaseInsensitive()
        {
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[] { new StubFeature("CASE-SAFE-ID", "Case Safe", FeatureKind.Validation, true) });
            AssertEqual("CASE-SAFE-ID", registry.GetDefinition("case-safe-id").Id, "Case-insensitive lookup");
        }

        private static void DefinitionsPreserveRegistrationOrder()
        {
            FeatureRegistry registry = new FeatureRegistry(new IApplicationFeature[]
            {
                new StubFeature("FIRST", "First", FeatureKind.Validation, true),
                new StubFeature("SECOND", "Second", FeatureKind.Automation, false)
            });
            FeatureDefinition[] definitions = registry.GetDefinitions();
            AssertEqual("FIRST", definitions[0].Id, "First registration");
            AssertEqual("SECOND", definitions[1].Id, "Second registration");
        }

        private static void DuplicateFeatureIdsAreRejected()
        {
            ExpectException<InvalidOperationException>(() => new FeatureRegistry(new IApplicationFeature[]
            {
                new StubFeature("DUPLICATE", "One", FeatureKind.Validation, true),
                new StubFeature("duplicate", "Two", FeatureKind.Automation, false)
            }));
        }

        private static void InvalidDefinitionsAreRejected()
        {
            ExpectArgument(() => new FeatureDefinition(" ", "Name", FeatureKind.Validation, SingleRequirement, "Tests", DocumentContextRequirement.Part, true, TestTraceability()), "id");
            ExpectArgument(() => new FeatureDefinition("ID", " ", FeatureKind.Validation, SingleRequirement, "Tests", DocumentContextRequirement.Part, true, TestTraceability()), "name");
            ExpectArgument(() => new FeatureDefinition("ID", "Name", FeatureKind.Validation, Array.Empty<string>(), "Tests", DocumentContextRequirement.Part, true, TestTraceability()), "requirementIds");
            ExpectArgument(() => new FeatureExecutionOutcome(ResultStatus.Passed, " "), "message");
        }

        private static void ValidationMustDeclareReadOnlyIntent()
        {
            ExpectArgument(() => new FeatureDefinition("ID", "Name", FeatureKind.Validation, SingleRequirement, "Tests", DocumentContextRequirement.Part, false, TestTraceability()), "isReadOnly");
        }

        private static void ActivePartReadinessFeaturePublishesMetadataAndExecutes()
        {
            StubCimatronSession session = new StubCimatronSession(CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part));
            ActivePartReadinessFeature feature = new ActivePartReadinessFeature(new CheckActivePartReadiness(session));
            AssertEqual(FeatureKind.Validation, feature.Definition.Kind, "Foundation feature kind");
            AssertEqual(true, feature.Definition.IsReadOnly, "Foundation read-only intent");
            AssertEqual(DocumentContextRequirement.Part, feature.Definition.RequiredDocumentContext, "Foundation document context");
            FeatureExecutionOutcome outcome = feature.Execute(Context());
            AssertEqual(ResultStatus.Passed, outcome.Status, "Foundation feature outcome");
            AssertEqual(1, outcome.Findings.Count, "Foundation finding count");
        }

        private static FeatureExecutionContext Context()
        {
            return new FeatureExecutionContext("test-run", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part));
        }

        private static void ExpectArgument(Func<object> action, string parameterName)
        {
            try { GC.KeepAlive(action()); }
            catch (ArgumentException exception) when (exception.ParamName == parameterName) { return; }
            throw new InvalidOperationException("Expected ArgumentException for parameter '" + parameterName + "'.");
        }

        private static void ExpectException<TException>(Func<object> action) where TException : Exception
        {
            try { GC.KeepAlive(action()); }
            catch (TException) { return; }
            throw new InvalidOperationException("Expected " + typeof(TException).Name + ".");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }

        private static FeatureTraceability TestTraceability()
        {
            return new FeatureTraceability("Test description.", "Test acceptance.", "Test inputs.", "Test outputs.", "Test dependencies.", "None.", "None.", "Test failures.", "Test coverage.", "0.14.10", "Test-only metadata.");
        }

        private sealed class StubFeature : IApplicationFeature
        {
            internal StubFeature(string id, string name, FeatureKind kind, bool isReadOnly)
            {
                Definition = new FeatureDefinition(id, name, kind, new[] { "REQ-" + id }, "Tests", DocumentContextRequirement.Part, isReadOnly, TestTraceability());
            }
            public FeatureDefinition Definition { get; }
            public FeatureExecutionOutcome Execute(FeatureExecutionContext context) => new FeatureExecutionOutcome(ResultStatus.Passed, "Executed.");
        }

        private sealed class StubCimatronSession : ICimatronSession
        {
            private readonly CimatronSessionSnapshot snapshot;
            internal StubCimatronSession(CimatronSessionSnapshot snapshot) { this.snapshot = snapshot; }
            public CimatronSessionSnapshot GetCurrentSession() => snapshot;
        }
    }
}
