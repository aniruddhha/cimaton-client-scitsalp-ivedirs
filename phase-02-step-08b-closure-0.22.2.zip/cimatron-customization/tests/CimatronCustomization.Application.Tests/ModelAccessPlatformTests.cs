using System;
using System.Collections.Generic;
using CimatronCustomization.DesignChecks;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class ModelAccessPlatformTests
    {
        internal static void RunAll()
        {
            ModelReadResultContracts();
            SnapshotContracts();
            AssemblyProbeAggregatesReadOnlyModelFindings();
            PartProbeSkipsAssemblyTraversal();
            UnsupportedTopologyIsReportedWithoutGuessing();
            ProbeConstructorGuardsRejectNullDependencies();
            ProbeRejectsNullExecutionContext();
            UnavailableAssemblyIsReportedAndTopologyContinues();
            EmptyAssemblyAndBodyOnlyTopologyAreHandled();
            EmptyTopologyIsNotApplicableAndSupportedBoundingBoxesDoNotAddUnsupported();
            UnavailableAttributesAreReported();
        }

        private static void ModelReadResultContracts()
        {
            ModelReadResult<string> passed = ModelReadResult<string>.Passed("value", "Read succeeded.");
            AssertEqual(ResultStatus.Passed, passed.Status, "Passed model-read status");
            AssertEqual("Read succeeded.", passed.Message, "Passed model-read message");
            AssertEqual("value", passed.Value, "Passed model-read value");
            AssertTrue(passed.IsAvailable, "Passed model-read availability");

            ModelReadResult<string> unsupported = ModelReadResult<string>.Unsupported("Not verified.");
            AssertEqual(ResultStatus.Unsupported, unsupported.Status, "Unsupported model-read status");
            AssertEqual("Not verified.", unsupported.Message, "Unsupported model-read message");
            AssertEqual(null, unsupported.Value, "Unsupported model-read value");
            AssertFalse(unsupported.IsAvailable, "Unsupported model-read availability");

            ExpectException<ArgumentNullException>(
                CreateNullPassedResult,
                "Null passed value");
        }

        private static void SnapshotContracts()
        {
            ModelEntityReference componentReference = new ModelEntityReference("instance|7");
            double[] matrix = { 1d, 0d, 0d, 0d, 0d, 1d, 0d, 0d, 0d, 0d, 1d, 0d };
            AssemblyComponentSnapshot component = new AssemblyComponentSnapshot(
                componentReference,
                7,
                3,
                "Insert",
                @"C:\Models\Insert.elt",
                CimatronDocumentContext.Part,
                12,
                false,
                matrix);

            AssertEqual(7, component.InstanceId, "Component instance id");
            AssertEqual(3, component.ParentInstanceId.Value, "Component parent instance id");
            AssertEqual("Insert", component.ModelTitle, "Component title");
            AssertEqual(CimatronDocumentContext.Part, component.ModelContext, "Component context");
            AssertEqual(12, component.Color, "Component color");
            AssertFalse(component.IsSuppressed, "Component suppressed flag");
            AssertTrue(component.HasPlacementMatrix, "Component placement");
            AssertEqual(12, component.PlacementMatrix.Count, "Component placement size");

            AssemblyStructureSnapshot assembly = new AssemblyStructureSnapshot("Mold", new List<AssemblyComponentSnapshot> { component });
            AssertEqual("Mold", assembly.AssemblyTitle, "Assembly title");
            AssertEqual(1, assembly.Components.Count, "Assembly component count");

            EntityAttributeValue attribute = new EntityAttributeValue("SteelGrade", "cmAttString", "P20");
            EntityAttributeSnapshot attributes = new EntityAttributeSnapshot(componentReference, new List<EntityAttributeValue> { attribute });
            AssertEqual(1, attributes.Attributes.Count, "Attribute count");
            AssertEqual("P20", attributes.Attributes[0].Value, "Attribute value");

            EntityColorSnapshot color = new EntityColorSnapshot(componentReference, 21);
            AssertEqual(21, color.Color, "Color value");

            ModelEntityReference faceReference = new ModelEntityReference("entity|7|pid|19");
            FaceTopologySnapshot face = new FaceTopologySnapshot(faceReference, "cmPlan", 250d);
            BodyTopologySnapshot topology = new BodyTopologySnapshot(
                new List<ModelEntityReference> { new ModelEntityReference("entity|7|pid|18") },
                new List<FaceTopologySnapshot> { face },
                false);

            AssertEqual(1, topology.Bodies.Count, "Body count");
            AssertEqual(1, topology.Faces.Count, "Face count");
            AssertEqual("cmPlan", topology.Faces[0].GeometryType, "Face geometry type");
            AssertEqual(250d, topology.Faces[0].Area, "Face area");
            AssertFalse(topology.BoundingBoxesSupported, "Bounding box support");

            AssemblyComponentSnapshot noPlacement = new AssemblyComponentSnapshot(
                new ModelEntityReference("instance|8"),
                8,
                null,
                "Plate",
                null,
                CimatronDocumentContext.Part,
                0,
                true);
            AssertFalse(noPlacement.HasPlacementMatrix, "Missing placement");
            AssertEqual(string.Empty, noPlacement.ModelPath, "Null model path");

            EntityAttributeValue normalizedAttribute = new EntityAttributeValue(null, null, null);
            AssertEqual(string.Empty, normalizedAttribute.Name, "Normalized attribute name");
            AssertEqual("Unknown", normalizedAttribute.Type, "Normalized attribute type");
            AssertEqual(string.Empty, normalizedAttribute.Value, "Normalized attribute value");

            FaceTopologySnapshot normalizedFace = new FaceTopologySnapshot(faceReference, null, 0d);
            AssertEqual("Unknown", normalizedFace.GeometryType, "Normalized face type");

            ExpectException<ArgumentException>(
                () => CreateInvalidComponentTitle(componentReference),
                "Blank component title");
            ExpectException<ArgumentNullException>(
                CreateInvalidAssemblyComponents,
                "Null assembly components");
            ExpectException<ArgumentNullException>(
                CreateInvalidAttributeSnapshot,
                "Null attribute collection");
            ExpectException<ArgumentNullException>(
                CreateInvalidTopologyFaces,
                "Null topology faces");
        }

        private static void AssemblyProbeAggregatesReadOnlyModelFindings()
        {
            ModelEntityReference componentReference = new ModelEntityReference("instance|42");
            ModelEntityReference bodyReference = new ModelEntityReference("entity|42|pid|100");
            ModelEntityReference faceReference = new ModelEntityReference("entity|42|pid|101");

            FakeAssemblyReader assembly = new FakeAssemblyReader(
                ModelReadResult<AssemblyStructureSnapshot>.Passed(
                    new AssemblyStructureSnapshot(
                        "Customer Mold",
                        new List<AssemblyComponentSnapshot>
                        {
                            new AssemblyComponentSnapshot(
                                componentReference,
                                42,
                                null,
                                "Core",
                                @"C:\Mold\Core.elt",
                                CimatronDocumentContext.Part,
                                7,
                                false,
                                new List<double> { 1d, 0d, 0d, 0d })
                        }),
                    "Assembly read."));

            FakeTopologyReader topology = new FakeTopologyReader(
                ModelReadResult<BodyTopologySnapshot>.Passed(
                    new BodyTopologySnapshot(
                        new List<ModelEntityReference> { bodyReference },
                        new List<FaceTopologySnapshot> { new FaceTopologySnapshot(faceReference, "cmPlan", 125d) },
                        false),
                    "Topology read."));

            FakeAttributeReader attributes = new FakeAttributeReader(
                ModelReadResult<EntityAttributeSnapshot>.Passed(
                    new EntityAttributeSnapshot(
                        faceReference,
                        new List<EntityAttributeValue> { new EntityAttributeValue("SteelGrade", "cmAttString", "P20") }),
                    "Attributes read."));

            FakeColorReader colors = new FakeColorReader(
                ModelReadResult<EntityColorSnapshot>.Passed(
                    new EntityColorSnapshot(componentReference, 7),
                    "Color read."));

            ModelInspectionProbeFeature feature = new ModelInspectionProbeFeature(assembly, attributes, colors, topology);
            FeatureExecutionOutcome outcome = feature.Execute(
                new FeatureExecutionContext(
                    "step04-assembly",
                    CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly)));

            AssertEqual(ResultStatus.Unsupported, outcome.Status, "Probe overall status");
            AssertTrue(outcome.Findings.Count >= 5, "Probe finding count");
            AssertEqual(1, assembly.CallCount, "Assembly reader call count");
            AssertEqual(1, topology.CallCount, "Topology reader call count");
            AssertTrue(colors.CallCount >= 2, "Color reader call count");
            AssertEqual(1, attributes.CallCount, "Attribute reader call count");
            AssertTrue(ContainsMessage(outcome.Findings, "component instance"), "Assembly finding");
            AssertTrue(ContainsMessage(outcome.Findings, "body reference"), "Topology finding");
            AssertTrue(ContainsMessage(outcome.Findings, "surface type"), "Representative face finding");
            AssertTrue(ContainsMessage(outcome.Findings, "bounding-box"), "Unsupported bounding-box finding");
        }

        private static void PartProbeSkipsAssemblyTraversal()
        {
            ThrowingAssemblyReader assembly = new ThrowingAssemblyReader();
            ModelEntityReference faceReference = new ModelEntityReference("entity|0|pid|2");

            FakeTopologyReader topology = new FakeTopologyReader(
                ModelReadResult<BodyTopologySnapshot>.Passed(
                    new BodyTopologySnapshot(
                        Array.Empty<ModelEntityReference>(),
                        new List<FaceTopologySnapshot> { new FaceTopologySnapshot(faceReference, "cmCylinder", 50d) },
                        false),
                    "Topology read."));

            FakeAttributeReader attributes = new FakeAttributeReader(
                ModelReadResult<EntityAttributeSnapshot>.Passed(
                    new EntityAttributeSnapshot(faceReference, Array.Empty<EntityAttributeValue>()),
                    "Attributes read."));
            FakeColorReader colors = new FakeColorReader(
                ModelReadResult<EntityColorSnapshot>.Unsupported("No explicit color."));

            ModelInspectionProbeFeature feature = new ModelInspectionProbeFeature(assembly, attributes, colors, topology);
            FeatureExecutionOutcome outcome = feature.Execute(
                new FeatureExecutionContext(
                    "step04-part",
                    CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)));

            AssertEqual(ResultStatus.Unsupported, outcome.Status, "Part probe status");
            AssertEqual(1, topology.CallCount, "Part topology calls");
            AssertEqual(1, attributes.CallCount, "Part attribute calls");
            AssertEqual(1, colors.CallCount, "Part color calls");
        }

        private static void UnsupportedTopologyIsReportedWithoutGuessing()
        {
            ModelInspectionProbeFeature feature = new ModelInspectionProbeFeature(
                new ThrowingAssemblyReader(),
                new FakeAttributeReader(ModelReadResult<EntityAttributeSnapshot>.Unsupported("Unavailable.")),
                new FakeColorReader(ModelReadResult<EntityColorSnapshot>.Unsupported("Unavailable.")),
                new FakeTopologyReader(ModelReadResult<BodyTopologySnapshot>.Unsupported("Topology is unsupported.")));

            FeatureExecutionOutcome outcome = feature.Execute(
                new FeatureExecutionContext(
                    "step04-unsupported",
                    CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)));

            AssertEqual(ResultStatus.Unsupported, outcome.Status, "Unsupported topology status");
            AssertEqual(1, outcome.Findings.Count, "Unsupported topology finding count");
            AssertEqual("Topology is unsupported.", outcome.Findings[0].Message, "Unsupported topology message");
        }

        private static void ProbeConstructorGuardsRejectNullDependencies()
        {
            ThrowingAssemblyReader assembly = new ThrowingAssemblyReader();
            FakeAttributeReader attributes = new FakeAttributeReader(ModelReadResult<EntityAttributeSnapshot>.Unsupported("Unavailable."));
            FakeColorReader colors = new FakeColorReader(ModelReadResult<EntityColorSnapshot>.Unsupported("Unavailable."));
            FakeTopologyReader topology = new FakeTopologyReader(ModelReadResult<BodyTopologySnapshot>.Unsupported("Unavailable."));

            ExpectException<ArgumentNullException>(() => CreateProbe(null, attributes, colors, topology), "Null assembly reader");
            ExpectException<ArgumentNullException>(() => CreateProbe(assembly, null, colors, topology), "Null attribute reader");
            ExpectException<ArgumentNullException>(() => CreateProbe(assembly, attributes, null, topology), "Null color reader");
            ExpectException<ArgumentNullException>(() => CreateProbe(assembly, attributes, colors, null), "Null topology reader");
        }

        private static void ProbeRejectsNullExecutionContext()
        {
            ModelInspectionProbeFeature feature = CreateMinimalProbe();
            ExpectException<ArgumentNullException>(() => ExecuteProbe(feature, null), "Null execution context");
            AssertEqual(ModelInspectionProbeFeature.FeatureId, feature.Definition.Id, "Probe definition id");
        }

        private static void UnavailableAssemblyIsReportedAndTopologyContinues()
        {
            FakeAssemblyReader assembly = new FakeAssemblyReader(
                ModelReadResult<AssemblyStructureSnapshot>.Unsupported("Assembly read is unavailable."));
            FakeTopologyReader topology = new FakeTopologyReader(
                ModelReadResult<BodyTopologySnapshot>.Passed(
                    new BodyTopologySnapshot(Array.Empty<ModelEntityReference>(), Array.Empty<FaceTopologySnapshot>(), true),
                    "Topology read."));

            ModelInspectionProbeFeature feature = new ModelInspectionProbeFeature(
                assembly,
                new FakeAttributeReader(ModelReadResult<EntityAttributeSnapshot>.Unsupported("Attributes unavailable.")),
                new FakeColorReader(ModelReadResult<EntityColorSnapshot>.Unsupported("Color unavailable.")),
                topology);

            FeatureExecutionOutcome outcome = feature.Execute(
                new FeatureExecutionContext("step04-assembly-unavailable", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly)));

            AssertEqual(ResultStatus.Unsupported, outcome.Status, "Unavailable assembly overall status");
            AssertEqual(1, assembly.CallCount, "Unavailable assembly call count");
            AssertEqual(1, topology.CallCount, "Topology continues after unavailable assembly");
            AssertTrue(ContainsMessage(outcome.Findings, "Assembly read is unavailable"), "Unavailable assembly finding");
            AssertTrue(ContainsMessage(outcome.Findings, "No body or face entity"), "Empty topology representative finding");
            AssertFalse(ContainsMessage(outcome.Findings, "bounding-box"), "Supported bounding box has no unsupported finding");
        }

        private static void EmptyAssemblyAndBodyOnlyTopologyAreHandled()
        {
            ModelEntityReference bodyReference = new ModelEntityReference("entity|0|pid|body-only");
            FakeAssemblyReader assembly = new FakeAssemblyReader(
                ModelReadResult<AssemblyStructureSnapshot>.Passed(
                    new AssemblyStructureSnapshot("Empty Mold", Array.Empty<AssemblyComponentSnapshot>()),
                    "Assembly read."));
            FakeAttributeReader attributes = new FakeAttributeReader(
                ModelReadResult<EntityAttributeSnapshot>.Passed(
                    new EntityAttributeSnapshot(bodyReference, Array.Empty<EntityAttributeValue>()),
                    "Attributes read."));
            FakeColorReader colors = new FakeColorReader(
                ModelReadResult<EntityColorSnapshot>.Passed(new EntityColorSnapshot(bodyReference, 3), "Color read."));
            FakeTopologyReader topology = new FakeTopologyReader(
                ModelReadResult<BodyTopologySnapshot>.Passed(
                    new BodyTopologySnapshot(new List<ModelEntityReference> { bodyReference }, Array.Empty<FaceTopologySnapshot>(), true),
                    "Topology read."));

            ModelInspectionProbeFeature feature = new ModelInspectionProbeFeature(assembly, attributes, colors, topology);
            FeatureExecutionOutcome outcome = feature.Execute(
                new FeatureExecutionContext("step04-body-only", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly)));

            AssertEqual(ResultStatus.Passed, outcome.Status, "Body-only topology status");
            AssertEqual(1, attributes.CallCount, "Body-only attribute call count");
            AssertEqual(1, colors.CallCount, "Body-only color call count");
            AssertTrue(ContainsMessage(outcome.Findings, "0 component instance"), "Empty assembly finding");
            AssertTrue(ContainsMessage(outcome.Findings, "0 face reference"), "Body-only topology finding");
            AssertFalse(ContainsMessage(outcome.Findings, "surface type"), "No face-detail finding for body-only topology");
            AssertFalse(ContainsMessage(outcome.Findings, "bounding-box"), "Supported bounding boxes do not add unsupported finding");
        }

        private static void EmptyTopologyIsNotApplicableAndSupportedBoundingBoxesDoNotAddUnsupported()
        {
            ModelInspectionProbeFeature feature = new ModelInspectionProbeFeature(
                new ThrowingAssemblyReader(),
                new FakeAttributeReader(ModelReadResult<EntityAttributeSnapshot>.Unsupported("Must not be called.")),
                new FakeColorReader(ModelReadResult<EntityColorSnapshot>.Unsupported("Must not be called.")),
                new FakeTopologyReader(ModelReadResult<BodyTopologySnapshot>.Passed(
                    new BodyTopologySnapshot(Array.Empty<ModelEntityReference>(), Array.Empty<FaceTopologySnapshot>(), true),
                    "Topology read.")));

            FeatureExecutionOutcome outcome = feature.Execute(
                new FeatureExecutionContext("step04-empty", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)));

            AssertEqual(ResultStatus.NotApplicable, outcome.Status, "Empty topology status");
            AssertTrue(ContainsMessage(outcome.Findings, "No body or face entity"), "Empty topology message");
            AssertFalse(ContainsMessage(outcome.Findings, "bounding-box"), "Bounding boxes supported branch");
        }

        private static void UnavailableAttributesAreReported()
        {
            ModelEntityReference faceReference = new ModelEntityReference("entity|0|pid|attr-unavailable");
            FakeAttributeReader attributes = new FakeAttributeReader(
                ModelReadResult<EntityAttributeSnapshot>.Unsupported("Representative attributes unavailable."));
            FakeColorReader colors = new FakeColorReader(
                ModelReadResult<EntityColorSnapshot>.Passed(new EntityColorSnapshot(faceReference, 4), "Color read."));
            FakeTopologyReader topology = new FakeTopologyReader(
                ModelReadResult<BodyTopologySnapshot>.Passed(
                    new BodyTopologySnapshot(
                        Array.Empty<ModelEntityReference>(),
                        new List<FaceTopologySnapshot> { new FaceTopologySnapshot(faceReference, "cmPlan", 1d) },
                        true),
                    "Topology read."));

            ModelInspectionProbeFeature feature = new ModelInspectionProbeFeature(new ThrowingAssemblyReader(), attributes, colors, topology);
            FeatureExecutionOutcome outcome = feature.Execute(
                new FeatureExecutionContext("step04-attributes-unavailable", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)));

            AssertEqual(ResultStatus.Unsupported, outcome.Status, "Unavailable attribute status");
            AssertEqual(1, attributes.CallCount, "Unavailable attribute call count");
            AssertEqual(1, colors.CallCount, "Supported color call count");
            AssertTrue(ContainsMessage(outcome.Findings, "Representative attributes unavailable"), "Unavailable attribute finding");
            AssertTrue(ContainsMessage(outcome.Findings, "color value = 4"), "Supported color finding");
        }

        private static ModelInspectionProbeFeature CreateMinimalProbe()
        {
            return new ModelInspectionProbeFeature(
                new ThrowingAssemblyReader(),
                new FakeAttributeReader(ModelReadResult<EntityAttributeSnapshot>.Unsupported("Unavailable.")),
                new FakeColorReader(ModelReadResult<EntityColorSnapshot>.Unsupported("Unavailable.")),
                new FakeTopologyReader(ModelReadResult<BodyTopologySnapshot>.Unsupported("Unavailable.")));
        }

        private static void CreateProbe(
            IAssemblyStructureReader assembly,
            IEntityAttributeReader attributes,
            IEntityColorReader colors,
            IBodyTopologyReader topology)
        {
            ModelInspectionProbeFeature ignored = new ModelInspectionProbeFeature(assembly, attributes, colors, topology);
            GC.KeepAlive(ignored);
        }

        private static void ExecuteProbe(ModelInspectionProbeFeature feature, FeatureExecutionContext context)
        {
            FeatureExecutionOutcome ignored = feature.Execute(context);
            GC.KeepAlive(ignored);
        }

        private static void CreateNullPassedResult()
        {
            ModelReadResult<string> ignored = ModelReadResult<string>.Passed(null, "Invalid.");
            GC.KeepAlive(ignored);
        }

        private static void CreateInvalidComponentTitle(ModelEntityReference reference)
        {
            AssemblyComponentSnapshot ignored = new AssemblyComponentSnapshot(reference, 1, null, " ", string.Empty, CimatronDocumentContext.Part, 0, false);
            GC.KeepAlive(ignored);
        }

        private static void CreateInvalidAssemblyComponents()
        {
            AssemblyStructureSnapshot ignored = new AssemblyStructureSnapshot("Mold", null);
            GC.KeepAlive(ignored);
        }

        private static void CreateInvalidAttributeSnapshot()
        {
            EntityAttributeSnapshot ignored = new EntityAttributeSnapshot(new ModelEntityReference("entity|0|x|1"), null);
            GC.KeepAlive(ignored);
        }

        private static void CreateInvalidTopologyFaces()
        {
            BodyTopologySnapshot ignored = new BodyTopologySnapshot(Array.Empty<ModelEntityReference>(), null, false);
            GC.KeepAlive(ignored);
        }

        private static bool ContainsMessage(IReadOnlyList<Finding> findings, string fragment)
        {
            foreach (Finding finding in findings)
            {
                if (finding.Message.IndexOf(fragment, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private sealed class FakeAssemblyReader : IAssemblyStructureReader
        {
            private readonly ModelReadResult<AssemblyStructureSnapshot> result;

            internal FakeAssemblyReader(ModelReadResult<AssemblyStructureSnapshot> result)
            {
                this.result = result;
            }

            internal int CallCount { get; private set; }

            public ModelReadResult<AssemblyStructureSnapshot> ReadCurrentAssembly()
            {
                CallCount++;
                return result;
            }
        }

        private sealed class ThrowingAssemblyReader : IAssemblyStructureReader
        {
            public ModelReadResult<AssemblyStructureSnapshot> ReadCurrentAssembly()
            {
                throw new InvalidOperationException("Assembly reader must not be called for a Part probe.");
            }
        }

        private sealed class FakeAttributeReader : IEntityAttributeReader
        {
            private readonly ModelReadResult<EntityAttributeSnapshot> result;

            internal FakeAttributeReader(ModelReadResult<EntityAttributeSnapshot> result)
            {
                this.result = result;
            }

            internal int CallCount { get; private set; }

            public ModelReadResult<EntityAttributeSnapshot> ReadAttributes(ModelEntityReference entityReference)
            {
                CallCount++;
                return result;
            }
        }

        private sealed class FakeColorReader : IEntityColorReader
        {
            private readonly ModelReadResult<EntityColorSnapshot> result;

            internal FakeColorReader(ModelReadResult<EntityColorSnapshot> result)
            {
                this.result = result;
            }

            internal int CallCount { get; private set; }

            public ModelReadResult<EntityColorSnapshot> ReadColor(ModelEntityReference entityReference)
            {
                CallCount++;
                return result;
            }
        }

        private sealed class FakeTopologyReader : IBodyTopologyReader
        {
            private readonly ModelReadResult<BodyTopologySnapshot> result;

            internal FakeTopologyReader(ModelReadResult<BodyTopologySnapshot> result)
            {
                this.result = result;
            }

            internal int CallCount { get; private set; }

            public ModelReadResult<BodyTopologySnapshot> ReadCurrentTopology()
            {
                CallCount++;
                return result;
            }

            public ModelReadResult<Direction3> ReadFaceNormal(ModelEntityReference faceReference, Point3 point)
            {
                return ModelReadResult<Direction3>.Unsupported("Normal-at-point requires a live Cimatron face/point pair.");
            }
        }

        private static void ExpectException<TException>(Action action, string name)
            where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException)
            {
                return;
            }

            throw new InvalidOperationException(name + " did not throw " + typeof(TException).Name + ".");
        }

        private static void AssertTrue(bool value, string name)
        {
            if (!value) throw new InvalidOperationException(name + " expected true.");
        }

        private static void AssertFalse(bool value, string name)
        {
            if (value) throw new InvalidOperationException(name + " expected false.");
        }

        private static void AssertEqual<T>(T expected, T actual, string name)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
            {
                throw new InvalidOperationException(
                    name + " expected <" + expected + "> but was <" + actual + ">.");
            }
        }
    }
}
