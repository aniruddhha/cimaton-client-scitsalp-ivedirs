using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class TabularInputContractTests
    {
        internal static void RunAll()
        {
            SourceDefinitionRequiresRuntimeFileAndConfiguredMapping();
            SourceDefinitionRejectsInvalidHeaderRowAndDuplicateMappings();
            ColumnDefinitionSupportsOnlyApprovedStep06ATypes();
            RowCarriesTypedValuesByLogicalColumnName();
            TableRequiresConsistentRows();
            ReadResultIsAllOrNothing();
            ErrorResultRequiresActionableCodeAndMessage();
        }

        private static void SourceDefinitionRequiresRuntimeFileAndConfiguredMapping()
        {
            TabularSourceDefinition source = Source();

            AssertEqual("C:\\Customer\\DO-1001.xlsx", source.FilePath, "Runtime file path");
            AssertEqual("ConfiguredSheet", source.WorksheetName, "Worksheet name");
            AssertEqual(3, source.HeaderRowNumber, "Header row");
            AssertEqual(2, source.Columns.Count, "Mapped column count");

            ExpectException<ArgumentException>(() => Consume(new TabularSourceDefinition(
                " ", "ConfiguredSheet", 3, Columns())));
            ExpectException<ArgumentException>(() => Consume(new TabularSourceDefinition(
                "C:\\Customer\\DO-1001.xlsx", " ", 3, Columns())));
            ExpectException<ArgumentNullException>(() => Consume(new TabularSourceDefinition(
                "C:\\Customer\\DO-1001.xlsx", "ConfiguredSheet", 3, null)));
            ExpectException<ArgumentException>(() => Consume(new TabularSourceDefinition(
                "C:\\Customer\\DO-1001.xlsx", "ConfiguredSheet", 3, Array.Empty<TabularColumnDefinition>())));
        }

        private static void SourceDefinitionRejectsInvalidHeaderRowAndDuplicateMappings()
        {
            ExpectException<ArgumentOutOfRangeException>(() => Consume(new TabularSourceDefinition(
                "C:\\Customer\\DO-1001.xlsx", "ConfiguredSheet", 0, Columns())));

            ExpectException<ArgumentException>(() => Consume(new TabularSourceDefinition(
                "C:\\Customer\\DO-1001.xlsx",
                "ConfiguredSheet",
                3,
                new[]
                {
                    new TabularColumnDefinition("SteelGrade", "Steel", TabularValueType.Text, true),
                    new TabularColumnDefinition("SteelGrade", "OtherSteel", TabularValueType.Text, true)
                })));

            ExpectException<ArgumentException>(() => Consume(new TabularSourceDefinition(
                "C:\\Customer\\DO-1001.xlsx",
                "ConfiguredSheet",
                3,
                new[]
                {
                    new TabularColumnDefinition("SteelGrade", "Steel", TabularValueType.Text, true),
                    new TabularColumnDefinition("PartName", "Steel", TabularValueType.Text, true)
                })));
        }

        private static void ColumnDefinitionSupportsOnlyApprovedStep06ATypes()
        {
            string[] names = Enum.GetNames(typeof(TabularValueType));
            string[] expected = { "Text", "Decimal" };
            AssertEqual(expected.Length, names.Length, "Tabular value type count");
            for (int index = 0; index < expected.Length; index++)
            {
                AssertEqual(expected[index], names[index], "Tabular value type item " + index);
            }

            TabularColumnDefinition text = new TabularColumnDefinition("SteelGrade", "Steel", TabularValueType.Text, true);
            AssertEqual(true, text.IsRequired, "Required text mapping");
            ExpectException<ArgumentException>(() => Consume(new TabularColumnDefinition(" ", "Steel", TabularValueType.Text, true)));
            ExpectException<ArgumentException>(() => Consume(new TabularColumnDefinition("SteelGrade", " ", TabularValueType.Text, true)));
        }

        private static void RowCarriesTypedValuesByLogicalColumnName()
        {
            TabularRow row = new TabularRow(
                4,
                new Dictionary<string, TabularValue>(StringComparer.OrdinalIgnoreCase)
                {
                    { "SteelGrade", TabularValue.FromText("1.2311") },
                    { "SliderWeightKg", TabularValue.FromDecimal(12.5m) }
                });

            AssertEqual(4, row.SourceRowNumber, "Source row number");
            AssertEqual("1.2311", row.GetRequired("SteelGrade").TextValue, "Text value");
            AssertEqual(12.5m, row.GetRequired("SliderWeightKg").DecimalValue.Value, "Decimal value");
            AssertEqual(false, row.TryGetValue("Unknown", out TabularValue ignored), "Unknown logical column");
            ExpectException<ArgumentOutOfRangeException>(() => Consume(new TabularRow(0, new Dictionary<string, TabularValue>())));
            ExpectException<ArgumentException>(() => row.GetRequired("Unknown"));
        }

        private static void TableRequiresConsistentRows()
        {
            TabularSourceDefinition source = Source();
            TabularRow row = new TabularRow(
                4,
                new Dictionary<string, TabularValue>(StringComparer.OrdinalIgnoreCase)
                {
                    { "SteelGrade", TabularValue.FromText("1.2311") },
                    { "SliderWeightKg", TabularValue.FromDecimal(12.5m) }
                });

            TabularTable table = new TabularTable(source, new[] { row });
            AssertEqual(1, table.Rows.Count, "Row count");
            AssertEqual(source, table.Source, "Source definition");

            TabularRow missingRequired = new TabularRow(
                5,
                new Dictionary<string, TabularValue>(StringComparer.OrdinalIgnoreCase)
                {
                    { "SliderWeightKg", TabularValue.FromDecimal(9m) }
                });
            ExpectException<ArgumentException>(() => Consume(new TabularTable(source, new[] { missingRequired })));
        }

        private static void ReadResultIsAllOrNothing()
        {
            TabularTable table = new TabularTable(Source(), Array.Empty<TabularRow>());
            TabularReadResult success = TabularReadResult.Succeeded(table);
            AssertEqual(true, success.IsSuccess, "Success flag");
            AssertEqual(table, success.Table, "Success table");
            AssertEqual(string.Empty, success.ErrorCode, "Success error code");

            TabularReadResult error = TabularReadResult.Error("TABULAR_FILE_NOT_FOUND", "The configured input file was not found.");
            AssertEqual(false, error.IsSuccess, "Error flag");
            AssertEqual(null, error.Table, "Error table must be absent");
        }

        private static void ErrorResultRequiresActionableCodeAndMessage()
        {
            ExpectException<ArgumentException>(() => TabularReadResult.Error(" ", "The file was not found."));
            ExpectException<ArgumentException>(() => TabularReadResult.Error("TABULAR_FILE_NOT_FOUND", " "));
            ExpectException<ArgumentNullException>(() => TabularReadResult.Succeeded(null));
        }

        private static TabularSourceDefinition Source()
        {
            return new TabularSourceDefinition(
                "C:\\Customer\\DO-1001.xlsx",
                "ConfiguredSheet",
                3,
                Columns());
        }

        private static TabularColumnDefinition[] Columns()
        {
            return new[]
            {
                new TabularColumnDefinition("SteelGrade", "Steel", TabularValueType.Text, true),
                new TabularColumnDefinition("SliderWeightKg", "Weight", TabularValueType.Decimal, true)
            };
        }

        private static void Consume(object value)
        {
            GC.KeepAlive(value);
        }

        private static void ExpectException<TException>(Action action) where TException : Exception
        {
            try { action(); }
            catch (TException) { return; }
            throw new InvalidOperationException("Expected " + typeof(TException).Name + ".");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
            {
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
            }
        }
    }
}
