using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.Application.Tests")]
[assembly: AssemblyDescription("Focused application-layer tests for the Cimatron session boundary")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: ComVisible(false)]
[assembly: Guid("0bb533f8-1bf6-4ab1-870e-e0079cf53a2f")]
[assembly: AssemblyVersion("0.14.10.0")]
[assembly: AssemblyFileVersion("0.14.10.0")]
