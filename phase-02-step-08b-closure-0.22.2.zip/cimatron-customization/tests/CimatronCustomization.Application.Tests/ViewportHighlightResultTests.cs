using System;

namespace CimatronCustomization.Application.Tests
{
    internal static class ViewportHighlightResultTests
    {
        internal static void RunAll()
        {
            CreatesHighlightedResult();
            CreatesUnsupportedResult();
            RejectsMissingMessages();
        }

        private static void CreatesHighlightedResult()
        {
            ViewportHighlightResult result = ViewportHighlightResult.Highlighted("Highlighted one entity.");
            AssertEqual(true, result.IsHighlighted, "Highlighted status");
            AssertEqual("Highlighted one entity.", result.Message, "Highlighted message");
        }

        private static void CreatesUnsupportedResult()
        {
            ViewportHighlightResult result = ViewportHighlightResult.Unsupported("Not supported.");
            AssertEqual(false, result.IsHighlighted, "Unsupported status");
            AssertEqual("Not supported.", result.Message, "Unsupported message");
        }

        private static void RejectsMissingMessages()
        {
            ExpectException<ArgumentException>(() => ViewportHighlightResult.Highlighted(" "));
            ExpectException<ArgumentException>(() => ViewportHighlightResult.Unsupported(null));
        }

        private static void ExpectException<TException>(Action action) where TException : Exception
        {
            try { action(); }
            catch (TException) { return; }
            throw new InvalidOperationException("Expected " + typeof(TException).Name + ".");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!object.Equals(expected, actual))
            {
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
            }
        }
    }
}
