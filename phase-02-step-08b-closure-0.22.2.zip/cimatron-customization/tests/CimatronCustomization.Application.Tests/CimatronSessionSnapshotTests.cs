using System;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class CimatronSessionSnapshotTests
    {
        internal static void RunAll()
        {
            ApplicationUnavailableHasNoDocument();
            AvailableSessionCanHaveNoActiveDocument();
            PartContextIsSupported();
            AssemblyContextIsSupported();
            NcContextIsSupported();
            UnsupportedContextIsReportedWithoutBeingTreatedAsSupported();
            ActiveDocumentRejectsNoneContext();
        }

        private static void ApplicationUnavailableHasNoDocument()
        {
            CimatronSessionSnapshot snapshot = CimatronSessionSnapshot.ApplicationUnavailable();
            AssertFalse(snapshot.IsApplicationAvailable, nameof(snapshot.IsApplicationAvailable));
            AssertFalse(snapshot.HasActiveDocument, nameof(snapshot.HasActiveDocument));
            AssertEqual(CimatronDocumentContext.None, snapshot.ActiveDocumentContext, nameof(snapshot.ActiveDocumentContext));
            AssertFalse(snapshot.HasSupportedDocumentContext, nameof(snapshot.HasSupportedDocumentContext));
        }

        private static void AvailableSessionCanHaveNoActiveDocument()
        {
            CimatronSessionSnapshot snapshot = CimatronSessionSnapshot.NoActiveDocument();
            AssertTrue(snapshot.IsApplicationAvailable, nameof(snapshot.IsApplicationAvailable));
            AssertFalse(snapshot.HasActiveDocument, nameof(snapshot.HasActiveDocument));
            AssertEqual(CimatronDocumentContext.None, snapshot.ActiveDocumentContext, nameof(snapshot.ActiveDocumentContext));
        }

        private static void PartContextIsSupported()
        {
            AssertSupported(CimatronDocumentContext.Part);
        }

        private static void AssemblyContextIsSupported()
        {
            AssertSupported(CimatronDocumentContext.Assembly);
        }

        private static void NcContextIsSupported()
        {
            AssertSupported(CimatronDocumentContext.Nc);
        }

        private static void UnsupportedContextIsReportedWithoutBeingTreatedAsSupported()
        {
            CimatronSessionSnapshot snapshot = CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Unsupported);
            AssertTrue(snapshot.IsApplicationAvailable, nameof(snapshot.IsApplicationAvailable));
            AssertTrue(snapshot.HasActiveDocument, nameof(snapshot.HasActiveDocument));
            AssertFalse(snapshot.HasSupportedDocumentContext, nameof(snapshot.HasSupportedDocumentContext));
        }

        private static void ActiveDocumentRejectsNoneContext()
        {
            try
            {
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.None);
                throw new InvalidOperationException("Expected ArgumentException was not thrown.");
            }
            catch (ArgumentException)
            {
                // Expected.
            }
        }

        private static void AssertSupported(CimatronDocumentContext context)
        {
            CimatronSessionSnapshot snapshot = CimatronSessionSnapshot.ActiveDocument(context);
            AssertTrue(snapshot.IsApplicationAvailable, nameof(snapshot.IsApplicationAvailable));
            AssertTrue(snapshot.HasActiveDocument, nameof(snapshot.HasActiveDocument));
            AssertEqual(context, snapshot.ActiveDocumentContext, nameof(snapshot.ActiveDocumentContext));
            AssertTrue(snapshot.HasSupportedDocumentContext, nameof(snapshot.HasSupportedDocumentContext));
        }

        private static void AssertTrue(bool value, string name)
        {
            if (!value)
            {
                throw new InvalidOperationException(name + " was expected to be true.");
            }
        }

        private static void AssertFalse(bool value, string name)
        {
            if (value)
            {
                throw new InvalidOperationException(name + " was expected to be false.");
            }
        }

        private static void AssertEqual(CimatronDocumentContext expected, CimatronDocumentContext actual, string name)
        {
            if (expected != actual)
            {
                throw new InvalidOperationException(name + " expected " + expected + " but was " + actual + ".");
            }
        }
    }
}
