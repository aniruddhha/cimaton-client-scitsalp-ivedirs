using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class CheckActivePartReadinessTests
    {
        internal static void RunAll()
        {
            AssertOutcome(CimatronSessionSnapshot.ApplicationUnavailable(), ResultStatus.Error, "Application unavailable");
            AssertOutcome(CimatronSessionSnapshot.NoActiveDocument(), ResultStatus.NotApplicable, "No active document");
            AssertOutcome(CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly), ResultStatus.Unsupported, "Assembly active document");
            AssertOutcome(CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part), ResultStatus.Passed, "Active Part");
            OutcomeRejectsBlankMessage();
            ConstructorRejectsNullSessionPort();
        }

        private static void OutcomeRejectsBlankMessage()
        {
            try { GC.KeepAlive(new ActivePartReadinessOutcome(ResultStatus.Passed, " ")); }
            catch (ArgumentException exception) when (exception.ParamName == "message") { return; }
            throw new InvalidOperationException("ActivePartReadinessOutcome must reject a blank message.");
        }

        private static void ConstructorRejectsNullSessionPort()
        {
            try { GC.KeepAlive(new CheckActivePartReadiness(null)); }
            catch (ArgumentNullException exception) when (exception.ParamName == "session") { return; }
            throw new InvalidOperationException("CheckActivePartReadiness must reject a null ICimatronSession dependency.");
        }

        private static void AssertOutcome(CimatronSessionSnapshot snapshot, ResultStatus expectedStatus, string scenario)
        {
            StubCimatronSession session = new StubCimatronSession(snapshot);
            ActivePartReadinessOutcome outcome = new CheckActivePartReadiness(session).Execute();
            if (expectedStatus != outcome.Status) throw new InvalidOperationException(scenario + " expected status " + expectedStatus + " but received " + outcome.Status + ".");
            if (string.IsNullOrWhiteSpace(outcome.Message)) throw new InvalidOperationException(scenario + " must return a non-empty outcome message.");
            if (session.CallCount != 1) throw new InvalidOperationException(scenario + " must read the Cimatron session exactly once.");
        }

        private sealed class StubCimatronSession : ICimatronSession
        {
            private readonly CimatronSessionSnapshot snapshot;
            internal StubCimatronSession(CimatronSessionSnapshot snapshot) { this.snapshot = snapshot; }
            internal int CallCount { get; private set; }
            public CimatronSessionSnapshot GetCurrentSession() { CallCount++; return snapshot; }
        }
    }
}
