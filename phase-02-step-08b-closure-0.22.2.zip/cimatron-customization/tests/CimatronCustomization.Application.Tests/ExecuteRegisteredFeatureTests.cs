using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class ExecuteRegisteredFeatureTests
    {
        internal static void RunAll()
        {
            SuccessfulValidationIsReportedAndLogged();
            FailedOutcomeIsPreserved();
            WarningOutcomeIsPreserved();
            ErrorOutcomeIsPreserved();
            UnknownFeatureBecomesErrorReport();
            FeatureExceptionBecomesErrorReport();
            AutomationSucceededIsPreserved();
            ValidationSucceededBecomesError();
            WrongDocumentContextIsNotApplicable();
            MissingDocumentIsError();
        }

        private static void SuccessfulValidationIsReportedAndLogged()
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = CreateExecutor(
                new StubFeature("VALIDATION-1", "Validation One", FeatureKind.Validation, ResultStatus.Passed, "All checks passed.", DocumentContextRequirement.Part),
                logger);

            FeatureExecutionReport report = executor.Execute("VALIDATION-1", Context("run-1", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");

            AssertEqual("VALIDATION-1", report.FeatureId, "Feature id");
            AssertEqual(FeatureKind.Validation, report.Kind.Value, "Feature kind");
            AssertEqual(ResultStatus.Passed, report.Status, "Success status");
            AssertEqual("Passed", report.StatusText, "Success status text");
            AssertEqual("run-1", logger.Last.CorrelationId, "Correlation id");
            AssertEqual("REQ-VALIDATION-1", logger.Last.RequirementId, "Requirement id");
            Assert(logger.Last.Message.StartsWith("Findings=0; ", StringComparison.Ordinal), "Log must summarize finding count.");
        }

        private static void FailedOutcomeIsPreserved()
        {
            FeatureExecutionReport report = ExecuteOutcome(ResultStatus.Failed, "Rule did not pass.");
            AssertEqual(ResultStatus.Failed, report.Status, "Failed status");
            Assert(report.Exception == null, "A normal Failed outcome must not be converted to an exception.");
        }

        private static void WarningOutcomeIsPreserved()
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = CreateExecutor(
                new StubFeature("WARNING", "Warning Feature", FeatureKind.Validation, ResultStatus.Warning, "Review required.", DocumentContextRequirement.Part), logger);
            FeatureExecutionReport report = executor.Execute("WARNING", Context("run-warning", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");
            AssertEqual(ResultStatus.Warning, report.Status, "Warning status");
            AssertEqual("Warning", logger.Last.Level, "Warning log level");
        }

        private static void ErrorOutcomeIsPreserved()
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = CreateExecutor(
                new StubFeature("ERROR", "Error Feature", FeatureKind.Validation, ResultStatus.Error, "Feature reported an error.", DocumentContextRequirement.Part), logger);
            FeatureExecutionReport report = executor.Execute("ERROR", Context("run-error", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");
            AssertEqual(ResultStatus.Error, report.Status, "Error status");
            Assert(report.Exception == null, "A reported Error outcome is not itself an execution exception.");
        }

        private static void UnknownFeatureBecomesErrorReport()
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = new ExecuteRegisteredFeature(new FeatureRegistry(Array.Empty<IApplicationFeature>()), logger, "0.14.10");
            FeatureExecutionReport report = executor.Execute("UNKNOWN", Context("run-unknown", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");
            AssertEqual(ResultStatus.Error, report.Status, "Unknown feature status");
            Assert(report.Exception != null, "Unknown feature error must retain exception context.");
        }

        private static void FeatureExceptionBecomesErrorReport()
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = CreateExecutor(new ThrowingFeature(), logger);
            FeatureExecutionReport report = executor.Execute("THROWS", Context("run-throws", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");
            AssertEqual(ResultStatus.Error, report.Status, "Thrown exception status");
            Assert(report.Exception is InvalidOperationException, "Execution exception must be retained.");
        }

        private static void AutomationSucceededIsPreserved()
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = CreateExecutor(
                new StubFeature("AUTO-1", "Automation One", FeatureKind.Automation, ResultStatus.Succeeded, "Automation completed.", DocumentContextRequirement.Part, false), logger);
            FeatureExecutionReport report = executor.Execute("AUTO-1", Context("run-auto", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");
            AssertEqual(ResultStatus.Succeeded, report.Status, "Automation success status");
        }

        private static void ValidationSucceededBecomesError()
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = CreateExecutor(
                new StubFeature("BAD-VALIDATION", "Bad Validation", FeatureKind.Validation, ResultStatus.Succeeded, "Invalid success state.", DocumentContextRequirement.Part), logger);
            FeatureExecutionReport report = executor.Execute("BAD-VALIDATION", Context("run-bad", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");
            AssertEqual(ResultStatus.Error, report.Status, "Validation Succeeded must be rejected");
        }

        private static void WrongDocumentContextIsNotApplicable()
        {
            RecordingLogger logger = new RecordingLogger();
            StubFeature feature = new StubFeature("PART-ONLY", "Part Only", FeatureKind.Validation, ResultStatus.Passed, "Executed.", DocumentContextRequirement.Part);
            ExecuteRegisteredFeature executor = CreateExecutor(feature, logger);
            FeatureExecutionReport report = executor.Execute("PART-ONLY", Context("run-assembly", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly)), "2026.0");
            AssertEqual(ResultStatus.NotApplicable, report.Status, "Wrong context");
            AssertEqual(0, feature.ExecutionCount, "Feature must not execute in wrong context");
        }

        private static void MissingDocumentIsError()
        {
            RecordingLogger logger = new RecordingLogger();
            StubFeature feature = new StubFeature("PART-ONLY", "Part Only", FeatureKind.Validation, ResultStatus.Passed, "Executed.", DocumentContextRequirement.Part);
            ExecuteRegisteredFeature executor = CreateExecutor(feature, logger);
            FeatureExecutionReport report = executor.Execute("PART-ONLY", Context("run-none", CimatronSessionSnapshot.NoActiveDocument()), "2026.0");
            AssertEqual(ResultStatus.Error, report.Status, "Missing document");
            AssertEqual(0, feature.ExecutionCount, "Feature must not execute without a document");
        }

        private static FeatureExecutionReport ExecuteOutcome(ResultStatus status, string message)
        {
            RecordingLogger logger = new RecordingLogger();
            ExecuteRegisteredFeature executor = CreateExecutor(new StubFeature("OUTCOME", "Outcome Feature", FeatureKind.Validation, status, message, DocumentContextRequirement.Part), logger);
            return executor.Execute("OUTCOME", Context("run-outcome", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)), "2026.0");
        }

        private static ExecuteRegisteredFeature CreateExecutor(IApplicationFeature feature, RecordingLogger logger)
        {
            return new ExecuteRegisteredFeature(new FeatureRegistry(new[] { feature }), logger, "0.14.10");
        }

        private static FeatureExecutionContext Context(string correlationId, CimatronSessionSnapshot session)
        {
            return new FeatureExecutionContext(correlationId, session);
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!Equals(expected, actual)) throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }

        private static FeatureTraceability TestTraceability()
        {
            return new FeatureTraceability("Test description.", "Test acceptance.", "Test inputs.", "Test outputs.", "Test dependencies.", "None.", "None.", "Test failures.", "Test coverage.", "0.14.10", "Test-only metadata.");
        }

        private sealed class RecordingLogger : IApplicationLogger
        {
            internal ApplicationLogEntry Last { get; private set; }
            public void Log(ApplicationLogEntry entry) { Last = entry; }
        }

        private sealed class StubFeature : IApplicationFeature
        {
            private readonly ResultStatus status;
            private readonly string message;

            internal StubFeature(string id, string name, FeatureKind kind, ResultStatus status, string message, DocumentContextRequirement context, bool isReadOnly = true)
            {
                Definition = new FeatureDefinition(id, name, kind, new[] { "REQ-" + id }, "Tests", context, isReadOnly, TestTraceability());
                this.status = status;
                this.message = message;
            }

            public FeatureDefinition Definition { get; }
            internal int ExecutionCount { get; private set; }

            public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
            {
                ExecutionCount++;
                return new FeatureExecutionOutcome(status, message);
            }
        }

        private sealed class ThrowingFeature : IApplicationFeature
        {
            public FeatureDefinition Definition { get; } = new FeatureDefinition(
                "THROWS", "Throwing Feature", FeatureKind.Automation, new[] { "REQ-THROWS" }, "Tests", DocumentContextRequirement.Part, false, TestTraceability());

            public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
            {
                throw new InvalidOperationException("execution failed");
            }
        }
    }
}
