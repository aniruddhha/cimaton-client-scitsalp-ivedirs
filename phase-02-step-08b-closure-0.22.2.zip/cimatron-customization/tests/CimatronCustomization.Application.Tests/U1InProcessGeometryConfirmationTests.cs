using System;
using CimatronCustomization.DesignChecks;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class U1InProcessGeometryConfirmationTests
    {
        private static readonly string[] SampleDiagnosticEvidence =
        {
            "Context: sample",
            "Step07Equivalent: sample"
        };

        internal static void RunAll()
        {
            MatchingKnownAnswerPasses();
            NumericMismatchFails();
            UnavailableReaderIsReported();
            NoMutationFailureFails();
            DiagnosticEvidenceIsSurfacedAsWarning();
            ConstructorAndContextGuards();
        }

        private static void MatchingKnownAnswerPasses()
        {
            U1InProcessGeometryConfirmationFeature feature = new U1InProcessGeometryConfirmationFeature(
                new FakeReader(ModelReadResult<BodyGeometryMetricsSnapshot>.Passed(
                    new BodyGeometryMetricsSnapshot(
                        U1InProcessGeometryConfirmationFeature.KnownAnswerModelTitle,
                        U1InProcessGeometryConfirmationFeature.KnownAnswerBodyId,
                        227576.685834808d,
                        new Point3(50d, 30d, 20d),
                        26684.9371823929d,
                        true),
                    "Read.")));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Passed, outcome.Status, "Known-answer status");
            AssertEqual(4, outcome.Findings.Count, "Known-answer finding count");
            AssertEqual(DocumentContextRequirement.Part, feature.Definition.RequiredDocumentContext, "Required context");
            AssertTrue(feature.Definition.IsReadOnly, "Read-only declaration");
        }

        private static void NumericMismatchFails()
        {
            U1InProcessGeometryConfirmationFeature feature = new U1InProcessGeometryConfirmationFeature(
                new FakeReader(ModelReadResult<BodyGeometryMetricsSnapshot>.Passed(
                    new BodyGeometryMetricsSnapshot("KA-PART-1", 4, 227500d, new Point3(51d, 30d, 20d), 26600d, true),
                    "Read.")));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Failed, outcome.Status, "Mismatch status");
        }

        private static void UnavailableReaderIsReported()
        {
            U1InProcessGeometryConfirmationFeature feature = new U1InProcessGeometryConfirmationFeature(
                new FakeReader(ModelReadResult<BodyGeometryMetricsSnapshot>.Unsupported("Wrong known-answer model.")));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Unsupported, outcome.Status, "Unavailable status");
            AssertEqual(1, outcome.Findings.Count, "Unavailable finding count");
        }

        private static void NoMutationFailureFails()
        {
            U1InProcessGeometryConfirmationFeature feature = new U1InProcessGeometryConfirmationFeature(
                new FakeReader(ModelReadResult<BodyGeometryMetricsSnapshot>.Passed(
                    new BodyGeometryMetricsSnapshot("KA-PART-1", 4, 227576.685834808d, new Point3(50d, 30d, 20d), 26684.9371823929d, false),
                    "Read.")));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Failed, outcome.Status, "No-mutation failure status");
        }

        private static void DiagnosticEvidenceIsSurfacedAsWarning()
        {
            U1InProcessGeometryConfirmationFeature feature = new U1InProcessGeometryConfirmationFeature(
                new FakeReader(ModelReadResult<BodyGeometryMetricsSnapshot>.Passed(
                    new BodyGeometryMetricsSnapshot(
                        "KA-PART-1",
                        4,
                        227576.685834808d,
                        new Point3(50d, 30d, 20d),
                        26684.9371823929d,
                        true,
                        SampleDiagnosticEvidence),
                    "Read.")));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Warning, outcome.Status, "Diagnostic aggregate status");
            AssertEqual(6, outcome.Findings.Count, "Diagnostic finding count");
            AssertEqual(ResultStatus.Warning, outcome.Findings[4].Status, "First diagnostic status");
            AssertEqual(ResultStatus.Warning, outcome.Findings[5].Status, "Second diagnostic status");
        }

        private static void ConstructorAndContextGuards()
        {
            ExpectException<ArgumentNullException>(() =>
            {
                U1InProcessGeometryConfirmationFeature unexpected = new U1InProcessGeometryConfirmationFeature(null);
                GC.KeepAlive(unexpected);
            }, "Null reader");
            U1InProcessGeometryConfirmationFeature feature = new U1InProcessGeometryConfirmationFeature(
                new FakeReader(ModelReadResult<BodyGeometryMetricsSnapshot>.Unsupported("Not used.")));
            ExpectException<ArgumentNullException>(() => feature.Execute(null), "Null execution context");
        }

        private static FeatureExecutionContext CreateContext()
        {
            return new FeatureExecutionContext(
                "step08a-u1",
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part));
        }

        private static void AssertEqual<T>(T expected, T actual, string name)
        {
            if (!Equals(expected, actual))
            {
                throw new InvalidOperationException(name + ": expected=" + expected + "; actual=" + actual + ".");
            }
        }

        private static void AssertTrue(bool value, string name)
        {
            if (!value) throw new InvalidOperationException(name + ": expected true.");
        }

        private static void ExpectException<TException>(Action action, string name) where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException)
            {
                return;
            }

            throw new InvalidOperationException(name + ": expected " + typeof(TException).Name + ".");
        }

        private sealed class FakeReader : IBodyGeometryMetricsReader
        {
            private readonly ModelReadResult<BodyGeometryMetricsSnapshot> result;

            internal FakeReader(ModelReadResult<BodyGeometryMetricsSnapshot> result)
            {
                this.result = result;
            }

            public ModelReadResult<BodyGeometryMetricsSnapshot> ReadBodyMetrics(string expectedModelTitle, int bodyId)
            {
                AssertEqual(U1InProcessGeometryConfirmationFeature.KnownAnswerModelTitle, expectedModelTitle, "Reader model title");
                AssertEqual(U1InProcessGeometryConfirmationFeature.KnownAnswerBodyId, bodyId, "Reader body ID");
                return result;
            }
        }
    }
}
