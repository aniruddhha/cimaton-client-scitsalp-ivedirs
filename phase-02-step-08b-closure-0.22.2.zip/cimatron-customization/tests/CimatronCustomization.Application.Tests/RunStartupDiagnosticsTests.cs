using System;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class RunStartupDiagnosticsTests
    {
        public static void RunAll()
        {
            ExecutesAndLogsSuccess();
            LogsAndRethrowsRuntimeErrors();
        }
        private static void ExecutesAndLogsSuccess()
        {
            RecordingLogger logger = new RecordingLogger();
            RunStartupDiagnostics useCase = new RunStartupDiagnostics(new Config(), new Runtime(), logger, "0.9.0");
            StartupDiagnosticsReport report = useCase.Execute("run-1");
            Assert(report.ConfigurationSchemaVersion == 1, "Schema version should be reported.");
            Assert(report.Runtime.Version == "2026.0", "Cimatron version should be reported.");
            Assert(logger.Last != null && logger.Last.Status == "Succeeded", "Success must be logged.");
        }
        private static void LogsAndRethrowsRuntimeErrors()
        {
            RecordingLogger logger = new RecordingLogger(); bool threw = false;
            try { new RunStartupDiagnostics(new Config(), new ThrowingRuntime(), logger, "0.9.0").Execute("run-2"); }
            catch (InvalidOperationException) { threw = true; }
            Assert(threw, "Runtime errors must propagate.");
            Assert(logger.Last != null && logger.Last.Status == "Error", "Runtime errors must be logged as Error.");
        }
        private sealed class Config : IStartupConfigurationProvider { public StartupConfigurationSnapshot Load() => new StartupConfigurationSnapshot(1, "logs", 1000, 2); }
        private sealed class Runtime : ICimatronRuntimeInfo { public CimatronRuntimeSnapshot GetCurrentRuntime() => new CimatronRuntimeSnapshot("Cimatron", "2026.0", CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)); }
        private sealed class ThrowingRuntime : ICimatronRuntimeInfo { public CimatronRuntimeSnapshot GetCurrentRuntime() { throw new InvalidOperationException("runtime"); } }
        private sealed class RecordingLogger : IApplicationLogger { public ApplicationLogEntry Last; public void Log(ApplicationLogEntry entry) { Last = entry; } }
        private static void Assert(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    }
}
