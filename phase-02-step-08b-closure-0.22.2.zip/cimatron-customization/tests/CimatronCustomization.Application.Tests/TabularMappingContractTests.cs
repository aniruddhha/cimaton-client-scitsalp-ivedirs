using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class TabularMappingContractTests
    {
        private static readonly string[] SteelGradeAliases = { "Steel Grade", "Material Grade", "Grade" };
        private static readonly string[] SingleSteelHeader = { "Steel" };
        private static readonly string[] BlankSteelAlias = { "Steel", " " };
        private static readonly string[] DuplicateSteelAlias = { "Steel", "steel" };
        private static readonly string[] OtherSteelHeader = { "Other Steel" };
        private static readonly string[] SteelAndGradeHeaders = { "Steel", "Grade" };
        private static readonly string[] PartAndGradeHeaders = { "Part", "grade" };
        private static readonly string[] SteelGradeFieldHeaders = { "Steel Grade", "Grade" };
        private static readonly string[] WeightFieldHeaders = { "Weight", "Slider Weight" };

        internal static void RunAll()
        {
            FieldMappingSupportsConfiguredHeaderAliases();
            FieldMappingRejectsInvalidHeaderCandidates();
            MappingRequiresUniqueLogicalFieldsAndHeaderCandidates();
            MappingPreservesRequiredAndTypeMetadata();
        }

        private static void FieldMappingSupportsConfiguredHeaderAliases()
        {
            TabularFieldMappingDefinition field = new TabularFieldMappingDefinition(
                "SteelGrade",
                SteelGradeAliases,
                TabularValueType.Text,
                true);

            AssertEqual("SteelGrade", field.LogicalName, "Logical field name");
            AssertEqual(3, field.SourceHeaders.Count, "Header candidate count");
            AssertEqual("Steel Grade", field.SourceHeaders[0], "Primary configured header");
            AssertEqual("Grade", field.SourceHeaders[2], "Configured alias");
        }

        private static void FieldMappingRejectsInvalidHeaderCandidates()
        {
            ExpectException<ArgumentException>(() => Consume(new TabularFieldMappingDefinition(" ", SingleSteelHeader, TabularValueType.Text, true)));
            ExpectException<ArgumentNullException>(() => Consume(new TabularFieldMappingDefinition("SteelGrade", null, TabularValueType.Text, true)));
            ExpectException<ArgumentException>(() => Consume(new TabularFieldMappingDefinition("SteelGrade", Array.Empty<string>(), TabularValueType.Text, true)));
            ExpectException<ArgumentException>(() => Consume(new TabularFieldMappingDefinition("SteelGrade", BlankSteelAlias, TabularValueType.Text, true)));
            ExpectException<ArgumentException>(() => Consume(new TabularFieldMappingDefinition("SteelGrade", DuplicateSteelAlias, TabularValueType.Text, true)));
        }

        private static void MappingRequiresUniqueLogicalFieldsAndHeaderCandidates()
        {
            ExpectException<ArgumentException>(() => Consume(new TabularMappingDefinition(" ", Fields())));
            ExpectException<ArgumentNullException>(() => Consume(new TabularMappingDefinition("CustomerInput", null)));
            ExpectException<ArgumentException>(() => Consume(new TabularMappingDefinition("CustomerInput", Array.Empty<TabularFieldMappingDefinition>())));

            ExpectException<ArgumentException>(() => Consume(new TabularMappingDefinition(
                "DuplicateLogical",
                new[]
                {
                    new TabularFieldMappingDefinition("SteelGrade", SingleSteelHeader, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("steelgrade", OtherSteelHeader, TabularValueType.Text, true)
                })));

            ExpectException<ArgumentException>(() => Consume(new TabularMappingDefinition(
                "AmbiguousHeader",
                new[]
                {
                    new TabularFieldMappingDefinition("SteelGrade", SteelAndGradeHeaders, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("PartName", PartAndGradeHeaders, TabularValueType.Text, true)
                })));
        }

        private static void MappingPreservesRequiredAndTypeMetadata()
        {
            TabularMappingDefinition mapping = new TabularMappingDefinition("CustomerInput", Fields());

            AssertEqual("CustomerInput", mapping.Name, "Mapping name");
            AssertEqual(2, mapping.Fields.Count, "Field count");
            AssertEqual(TabularValueType.Text, mapping.Fields[0].ValueType, "Text metadata");
            AssertEqual(true, mapping.Fields[0].IsRequired, "Required metadata");
            AssertEqual(TabularValueType.Decimal, mapping.Fields[1].ValueType, "Decimal metadata");
            AssertEqual(false, mapping.Fields[1].IsRequired, "Optional metadata");
        }

        private static TabularFieldMappingDefinition[] Fields()
        {
            return new[]
            {
                new TabularFieldMappingDefinition("SteelGrade", SteelGradeFieldHeaders, TabularValueType.Text, true),
                new TabularFieldMappingDefinition("WeightKg", WeightFieldHeaders, TabularValueType.Decimal, false)
            };
        }

        private static void Consume(object value) { GC.KeepAlive(value); }

        private static void ExpectException<TException>(Action action) where TException : Exception
        {
            try { action(); }
            catch (TException) { return; }
            throw new InvalidOperationException("Expected " + typeof(TException).Name + ".");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }
    }
}
