using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class TabularMappingIntegrationTests
    {
        private static readonly string[] PartHeaderCandidates = { "Part", "Part Name" };
        private static readonly string[] SteelGradeHeaderCandidates = { "Steel Grade", "Material Grade", "Grade" };
        private static readonly string[] WeightHeaderCandidates = { "Weight", "Slider Weight" };
        private static readonly string[] CompleteAliasHeaders = { "Part Name", "material grade", "Slider Weight" };
        private static readonly string[] RequiredHeadersOnly = { "Part", "Steel Grade" };
        private static readonly string[] AmbiguousHeaders = { "Part", "Steel Grade", "Material Grade" };

        internal static void RunAll()
        {
            ResolvedColumnsComposeWithExistingReaderSourceContract();
            OptionalMappingRemainsCompatibleWithValidatedRows();
            AmbiguousSchemaFailsBeforeReaderSourceConstruction();
            InvalidMappedRowsRemainFailClosedAndDoNotLeakValues();
        }

        private static void ResolvedColumnsComposeWithExistingReaderSourceContract()
        {
            TabularMappingDefinition mapping = Mapping();
            TabularMappingEngine engine = new TabularMappingEngine();
            TabularMappingResolution resolution = engine.ResolveHeaders(mapping, CompleteAliasHeaders);

            AssertEqual(true, resolution.IsSuccess, "Integration header resolution");

            TabularSourceDefinition source = new TabularSourceDefinition(
                "fixture.xlsx",
                "Sheet1",
                3,
                resolution.Columns);

            TabularRow row = new TabularRow(4, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("Block_A"),
                ["SteelGrade"] = TabularValue.FromText("1.2344"),
                ["WeightKg"] = TabularValue.FromDecimal(12.5m)
            });
            TabularTable table = new TabularTable(source, new[] { row });
            TabularRowValidationResult validation = engine.ValidateRows(mapping, table.Rows);

            AssertEqual(true, validation.IsSuccess, "Integration row validation");
            AssertEqual(3, source.Columns.Count, "Resolved reader column count");
            AssertEqual("Material Grade", source.Columns[1].SourceHeader, "Resolved alias propagated to source contract");
            AssertEqual(4, validation.Rows[0].SourceRowNumber, "Source row identity preserved");
            AssertEqual("1.2344", validation.Rows[0].GetRequired("SteelGrade").TextValue, "Consumer-neutral logical value preserved");
        }

        private static void OptionalMappingRemainsCompatibleWithValidatedRows()
        {
            TabularMappingDefinition mapping = Mapping();
            TabularMappingEngine engine = new TabularMappingEngine();
            TabularMappingResolution resolution = engine.ResolveHeaders(mapping, RequiredHeadersOnly);

            AssertEqual(true, resolution.IsSuccess, "Optional integration header resolution");
            AssertEqual(2, resolution.Columns.Count, "Optional column omitted from source contract");

            TabularSourceDefinition source = new TabularSourceDefinition("fixture.xlsx", "Sheet1", 1, resolution.Columns);
            TabularRow row = new TabularRow(2, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("Block_B"),
                ["SteelGrade"] = TabularValue.FromText("H13")
            });
            TabularTable table = new TabularTable(source, new[] { row });
            TabularRowValidationResult validation = engine.ValidateRows(mapping, table.Rows);

            AssertEqual(true, validation.IsSuccess, "Optional row validation");
            AssertEqual(false, validation.Rows[0].TryGetValue("WeightKg", out _), "Optional logical value remains absent");
        }

        private static void AmbiguousSchemaFailsBeforeReaderSourceConstruction()
        {
            TabularMappingResolution resolution = new TabularMappingEngine().ResolveHeaders(Mapping(), AmbiguousHeaders);

            AssertEqual(false, resolution.IsSuccess, "Ambiguous schema failure");
            AssertEqual(0, resolution.Columns.Count, "Failed resolution exposes no reader columns");
            AssertEqual("TABULAR_MAPPING_HEADER_AMBIGUOUS", resolution.Errors[0].Code, "Ambiguous schema error code");
            AssertEqual("SteelGrade", resolution.Errors[0].LogicalName, "Ambiguous schema logical field");
        }

        private static void InvalidMappedRowsRemainFailClosedAndDoNotLeakValues()
        {
            TabularRow row = new TabularRow(9, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("SensitivePart"),
                ["SteelGrade"] = TabularValue.FromDecimal(1.2344m)
            });

            TabularRowValidationResult validation = new TabularMappingEngine().ValidateRows(Mapping(), new[] { row });

            AssertEqual(false, validation.IsSuccess, "Invalid row failure");
            AssertEqual(0, validation.Rows.Count, "Failed validation exposes no consumer rows");
            AssertEqual("TABULAR_MAPPING_VALUE_TYPE_MISMATCH", validation.Errors[0].Code, "Invalid row error code");
            AssertEqual(9, validation.Errors[0].SourceRowNumber.Value, "Invalid row source identity");
            AssertEqual(false, validation.Errors[0].Message.Contains("SensitivePart"), "Part value not disclosed");
            AssertEqual(false, validation.Errors[0].Message.Contains("1.2344"), "Grade value not disclosed");
        }

        private static TabularMappingDefinition Mapping()
        {
            return new TabularMappingDefinition(
                "CustomerInput",
                new[]
                {
                    new TabularFieldMappingDefinition("Part", PartHeaderCandidates, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("SteelGrade", SteelGradeHeaderCandidates, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("WeightKg", WeightHeaderCandidates, TabularValueType.Decimal, false)
                });
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }
    }
}
