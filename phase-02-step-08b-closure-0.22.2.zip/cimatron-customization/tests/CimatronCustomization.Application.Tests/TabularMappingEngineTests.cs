using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomization.Application.Tests
{
    internal static class TabularMappingEngineTests
    {
        private static readonly string[] PrimaryAliasHeaders = { "Part Name", "material grade", "Slider Weight" };
        private static readonly string[] RequiredHeadersOnly = { "Part", "Steel Grade" };
        private static readonly string[] MissingSteelGradeHeaders = { "Part", "Weight" };
        private static readonly string[] MultipleSteelGradeAliases = { "Part", "Steel Grade", "Material Grade" };
        private static readonly string[] DuplicateSteelGradeHeaders = { "Part", "Steel Grade", "steel grade" };
        private static readonly string[] PartHeaderCandidates = { "Part", "Part Name" };
        private static readonly string[] SteelGradeHeaderCandidates = { "Steel Grade", "Material Grade", "Grade" };
        private static readonly string[] WeightHeaderCandidates = { "Weight", "Slider Weight" };

        internal static void RunAll()
        {
            ResolvesPrimaryHeadersAndAliasesCaseInsensitively();
            OptionalMissingHeaderIsAllowed();
            MissingRequiredHeaderFailsWithoutCustomerValues();
            MultipleAliasesPresentAreRejectedAsAmbiguous();
            DuplicatePhysicalHeaderIsRejectedAsAmbiguous();
            ValidatesRequiredMappedValuesAndTypes();
            ValidRowsArePreservedForConsumers();
        }

        private static void ResolvesPrimaryHeadersAndAliasesCaseInsensitively()
        {
            TabularMappingResolution result = Engine().ResolveHeaders(
                Mapping(),
                PrimaryAliasHeaders);

            AssertEqual(true, result.IsSuccess, "Header resolution success");
            AssertEqual(3, result.Columns.Count, "Resolved column count");
            AssertEqual("Part", result.Columns[0].LogicalName, "Part logical name");
            AssertEqual("Part Name", result.Columns[0].SourceHeader, "Primary header selection");
            AssertEqual("SteelGrade", result.Columns[1].LogicalName, "Steel logical name");
            AssertEqual("Material Grade", result.Columns[1].SourceHeader, "Alias selection");
        }

        private static void OptionalMissingHeaderIsAllowed()
        {
            TabularMappingResolution result = Engine().ResolveHeaders(
                Mapping(),
                RequiredHeadersOnly);

            AssertEqual(true, result.IsSuccess, "Optional missing header success");
            AssertEqual(2, result.Columns.Count, "Only present columns resolved");
        }

        private static void MissingRequiredHeaderFailsWithoutCustomerValues()
        {
            TabularMappingResolution result = Engine().ResolveHeaders(
                Mapping(),
                MissingSteelGradeHeaders);

            AssertEqual(false, result.IsSuccess, "Missing required header failure");
            AssertEqual(1, result.Errors.Count, "Missing header error count");
            AssertEqual("TABULAR_MAPPING_REQUIRED_HEADER_MISSING", result.Errors[0].Code, "Missing header code");
            AssertEqual("SteelGrade", result.Errors[0].LogicalName, "Missing logical field");
            AssertEqual(false, result.Errors[0].Message.Contains("1.2344"), "No customer value leakage");
        }

        private static void MultipleAliasesPresentAreRejectedAsAmbiguous()
        {
            TabularMappingResolution result = Engine().ResolveHeaders(
                Mapping(),
                MultipleSteelGradeAliases);

            AssertEqual(false, result.IsSuccess, "Multiple aliases ambiguous");
            AssertEqual("TABULAR_MAPPING_HEADER_AMBIGUOUS", result.Errors[0].Code, "Ambiguous alias code");
            AssertEqual("SteelGrade", result.Errors[0].LogicalName, "Ambiguous logical field");
        }

        private static void DuplicatePhysicalHeaderIsRejectedAsAmbiguous()
        {
            TabularMappingResolution result = Engine().ResolveHeaders(
                Mapping(),
                DuplicateSteelGradeHeaders);

            AssertEqual(false, result.IsSuccess, "Duplicate physical header ambiguous");
            AssertEqual("TABULAR_MAPPING_HEADER_AMBIGUOUS", result.Errors[0].Code, "Duplicate physical header code");
        }

        private static void ValidatesRequiredMappedValuesAndTypes()
        {
            TabularRow missing = new TabularRow(7, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("Block_A")
            });
            TabularRow wrongType = new TabularRow(8, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("Block_B"),
                ["SteelGrade"] = TabularValue.FromDecimal(1.2344m)
            });

            TabularRowValidationResult result = Engine().ValidateRows(Mapping(), new[] { missing, wrongType });

            AssertEqual(false, result.IsSuccess, "Row validation failure");
            AssertEqual(2, result.Errors.Count, "Row error count");
            AssertEqual("TABULAR_MAPPING_REQUIRED_VALUE_MISSING", result.Errors[0].Code, "Required value code");
            AssertEqual(7, result.Errors[0].SourceRowNumber.Value, "Required value row");
            AssertEqual("TABULAR_MAPPING_VALUE_TYPE_MISMATCH", result.Errors[1].Code, "Type mismatch code");
            AssertEqual(8, result.Errors[1].SourceRowNumber.Value, "Type mismatch row");
            AssertEqual(false, result.Errors[1].Message.Contains("1.2344"), "No value in type error");
        }

        private static void ValidRowsArePreservedForConsumers()
        {
            TabularRow row = new TabularRow(5, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("Block_A"),
                ["SteelGrade"] = TabularValue.FromText("1.2344"),
                ["WeightKg"] = TabularValue.FromDecimal(12.5m)
            });

            TabularRowValidationResult result = Engine().ValidateRows(Mapping(), new[] { row });

            AssertEqual(true, result.IsSuccess, "Valid row success");
            AssertEqual(1, result.Rows.Count, "Valid row count");
            AssertEqual(5, result.Rows[0].SourceRowNumber, "Source row preserved");
            AssertEqual("1.2344", result.Rows[0].GetRequired("SteelGrade").TextValue, "Logical value preserved");
        }

        private static TabularMappingEngine Engine()
        {
            return new TabularMappingEngine();
        }

        private static TabularMappingDefinition Mapping()
        {
            return new TabularMappingDefinition(
                "CustomerInput",
                new[]
                {
                    new TabularFieldMappingDefinition("Part", PartHeaderCandidates, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("SteelGrade", SteelGradeHeaderCandidates, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("WeightKg", WeightHeaderCandidates, TabularValueType.Decimal, false)
                });
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }
    }
}
