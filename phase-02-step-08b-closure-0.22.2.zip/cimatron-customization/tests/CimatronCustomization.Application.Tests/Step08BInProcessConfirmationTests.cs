using System;
using CimatronCustomization.DesignChecks;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class Step08BInProcessConfirmationTests
    {
        internal static void RunAll()
        {
            LockedKnownAnswerPassesAndCarriesNestedHighlightReference();
            StructureOrAttributeMismatchFails();
            BomReadErrorRemainsError();
            TargetRowMissingMaterialRemainsReadError();
            CleanupFailureIsWarning();
            ConstructorAndContextGuards();
        }

        private static void LockedKnownAnswerPassesAndCarriesNestedHighlightReference()
        {
            ModelEntityReference nestedReference = new ModelEntityReference("entity|6|cGlk|4");
            Step08BInProcessConfirmationFeature feature = CreateFeature(
                CreateOccurrence(nestedReference, 3, 2, 1, "KNOWN_ANSWER_07C3", true),
                ModelReadResult<AssemblyEntityMappingResult>.Passed(
                    new AssemblyEntityMappingResult(6, 4, 4, "cmBody", nestedReference, true),
                    "Mapped."),
                CreateBom(ResultStatus.Passed, "1.2738", true, true, true));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Passed, outcome.Status, "Known-answer status");
            AssertEqual(9, outcome.Findings.Count, "Known-answer finding count");
            AssertEqual(DocumentContextRequirement.Assembly, feature.Definition.RequiredDocumentContext, "Required context");
            AssertTrue(feature.Definition.IsReadOnly, "Read-only declaration");
            AssertEqual(1, outcome.Findings[4].EntityReferences.Count, "U12 nested highlight reference count");
            AssertEqual(nestedReference.Value, outcome.Findings[4].EntityReferences[0].Value, "U12 nested highlight reference");
        }

        private static void StructureOrAttributeMismatchFails()
        {
            ModelEntityReference nestedReference = new ModelEntityReference("entity|6|cGlk|4");
            Step08BInProcessConfirmationFeature feature = CreateFeature(
                CreateOccurrence(nestedReference, 2, 2, 0, "WRONG", true),
                ModelReadResult<AssemblyEntityMappingResult>.Passed(
                    new AssemblyEntityMappingResult(6, 4, 4, "cmBody", nestedReference, true),
                    "Mapped."),
                CreateBom(ResultStatus.Passed, "1.2738", true, true, true));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Failed, outcome.Status, "Mismatch status");
        }

        private static void BomReadErrorRemainsError()
        {
            ModelEntityReference nestedReference = new ModelEntityReference("entity|6|cGlk|4");
            Step08BInProcessConfirmationFeature feature = CreateFeature(
                CreateOccurrence(nestedReference, 3, 2, 1, "KNOWN_ANSWER_07C3", true),
                ModelReadResult<AssemblyEntityMappingResult>.Passed(
                    new AssemblyEntityMappingResult(6, 4, 4, "cmBody", nestedReference, true),
                    "Mapped."),
                new BomMaterialExportResult(
                    ResultStatus.Error,
                    "READ_ERROR GetBomManager failed with HRESULT=0x80004005.",
                    false,
                    0,
                    string.Empty,
                    true,
                    true,
                    true,
                    "%TEMP%\\CimatronCustomization\\Step08B\\sample",
                    string.Empty));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Error, outcome.Status, "BOM read-error aggregate status");
            AssertEqual(ResultStatus.Error, outcome.Findings[5].Status, "BOM read-error finding status");
            AssertEqual(ResultStatus.Skipped, outcome.Findings[6].Status, "Material comparison skipped after read error");
        }

        private static void TargetRowMissingMaterialRemainsReadError()
        {
            ModelEntityReference nestedReference = new ModelEntityReference("entity|6|cGlk|4");
            Step08BInProcessConfirmationFeature feature = CreateFeature(
                CreateOccurrence(nestedReference, 3, 2, 1, "KNOWN_ANSWER_07C3", true),
                ModelReadResult<AssemblyEntityMappingResult>.Passed(
                    new AssemblyEntityMappingResult(6, 4, 4, "cmBody", nestedReference, true),
                    "Mapped."),
                new BomMaterialExportResult(
                    ResultStatus.Error,
                    "READ_ERROR Required Material value is missing for target model 'KA-PART-1' at source row 5.",
                    true,
                    1,
                    string.Empty,
                    true,
                    true,
                    true,
                    "%TEMP%\\CimatronCustomization\\Step08B\\sample",
                    "bom-material.csv"));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Error, outcome.Status, "Target-row missing material aggregate status");
            AssertEqual(ResultStatus.Error, outcome.Findings[5].Status, "Target-row missing material read status");
            AssertEqual(ResultStatus.Skipped, outcome.Findings[6].Status, "Target-row material comparison skipped after read error");
        }

        private static void CleanupFailureIsWarning()
        {
            ModelEntityReference nestedReference = new ModelEntityReference("entity|6|cGlk|4");
            Step08BInProcessConfirmationFeature feature = CreateFeature(
                CreateOccurrence(nestedReference, 3, 2, 1, "KNOWN_ANSWER_07C3", true),
                ModelReadResult<AssemblyEntityMappingResult>.Passed(
                    new AssemblyEntityMappingResult(6, 4, 4, "cmBody", nestedReference, true),
                    "Mapped."),
                CreateBom(ResultStatus.Passed, "1.2738", true, true, false));

            FeatureExecutionOutcome outcome = feature.Execute(CreateContext());
            AssertEqual(ResultStatus.Warning, outcome.Status, "Cleanup warning aggregate status");
            AssertEqual(ResultStatus.Warning, outcome.Findings[8].Status, "Cleanup warning finding status");
        }

        private static void ConstructorAndContextGuards()
        {
            ExpectException<ArgumentNullException>(() =>
            {
                Step08BInProcessConfirmationFeature unexpected = new Step08BInProcessConfirmationFeature(null, new FakeMapper(null), new FakeBom(null));
                GC.KeepAlive(unexpected);
            }, "Null occurrence reader");

            ExpectException<ArgumentNullException>(() =>
            {
                Step08BInProcessConfirmationFeature unexpected = new Step08BInProcessConfirmationFeature(new FakeOccurrenceReader(null), null, new FakeBom(null));
                GC.KeepAlive(unexpected);
            }, "Null mapper");

            ExpectException<ArgumentNullException>(() =>
            {
                Step08BInProcessConfirmationFeature unexpected = new Step08BInProcessConfirmationFeature(new FakeOccurrenceReader(null), new FakeMapper(null), null);
                GC.KeepAlive(unexpected);
            }, "Null BOM exporter");

            Step08BInProcessConfirmationFeature feature = new Step08BInProcessConfirmationFeature(
                new FakeOccurrenceReader(ModelReadResult<OccurrenceEntityAttributeResult>.Unsupported("Not used.")),
                new FakeMapper(null),
                new FakeBom(null));
            ExpectException<ArgumentNullException>(() => feature.Execute(null), "Null context");
        }

        private static Step08BInProcessConfirmationFeature CreateFeature(
            OccurrenceEntityAttributeResult occurrence,
            ModelReadResult<AssemblyEntityMappingResult> mapping,
            BomMaterialExportResult bom)
        {
            return new Step08BInProcessConfirmationFeature(
                new FakeOccurrenceReader(ModelReadResult<OccurrenceEntityAttributeResult>.Passed(occurrence, "Read.")),
                new FakeMapper(mapping),
                new FakeBom(bom));
        }

        private static OccurrenceEntityAttributeResult CreateOccurrence(
            ModelEntityReference nestedReference,
            int total,
            int topLevel,
            int nested,
            string attributeValue,
            bool noMutation)
        {
            return new OccurrenceEntityAttributeResult(
                "KA-ASM-1",
                "KA-PART-1",
                total,
                topLevel,
                nested,
                6,
                4,
                1,
                "cmBody",
                true,
                "cmAttString",
                attributeValue,
                "ObservedReturnedName",
                nestedReference,
                noMutation);
        }

        private static BomMaterialExportResult CreateBom(
            ResultStatus status,
            string material,
            bool noMutation,
            bool folderUnchanged,
            bool cleanup)
        {
            return new BomMaterialExportResult(
                status,
                "BOM material evidence captured.",
                true,
                1,
                material,
                noMutation,
                folderUnchanged,
                cleanup,
                "%TEMP%\\CimatronCustomization\\Step08B\\sample",
                "bom-material.csv");
        }

        private static FeatureExecutionContext CreateContext()
        {
            return new FeatureExecutionContext(
                "step08b",
                CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Assembly));
        }

        private static void AssertEqual<T>(T expected, T actual, string name)
        {
            if (!Equals(expected, actual))
                throw new InvalidOperationException(name + ": expected=" + expected + "; actual=" + actual + ".");
        }

        private static void AssertTrue(bool value, string name)
        {
            if (!value) throw new InvalidOperationException(name + ": expected true.");
        }

        private static void ExpectException<TException>(Action action, string name) where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException)
            {
                return;
            }

            throw new InvalidOperationException(name + ": expected " + typeof(TException).Name + ".");
        }

        private sealed class FakeOccurrenceReader : IOccurrenceEntityAttributeReader
        {
            private readonly ModelReadResult<OccurrenceEntityAttributeResult> result;
            internal FakeOccurrenceReader(ModelReadResult<OccurrenceEntityAttributeResult> result) { this.result = result; }

            public ModelReadResult<OccurrenceEntityAttributeResult> ReadNestedOccurrenceAttribute(
                string expectedAssemblyTitle,
                string targetModelTitle,
                int bodyId,
                string attributeName)
            {
                AssertEqual("KA-ASM-1", expectedAssemblyTitle, "Occurrence assembly title");
                AssertEqual("KA-PART-1", targetModelTitle, "Occurrence model title");
                AssertEqual(4, bodyId, "Occurrence body ID");
                AssertEqual("STEP07_B1_TEST_ATTRIBUTE", attributeName, "Occurrence attribute name");
                return result;
            }
        }

        private sealed class FakeMapper : IAssemblyEntityMapper
        {
            private readonly ModelReadResult<AssemblyEntityMappingResult> result;
            internal FakeMapper(ModelReadResult<AssemblyEntityMappingResult> result) { this.result = result; }
            public ModelReadResult<AssemblyEntityMappingResult> MapToActiveAssembly(ModelEntityReference occurrenceEntityReference)
            {
                if (occurrenceEntityReference == null) throw new InvalidOperationException("Expected a nested reference.");
                return result;
            }
        }

        private sealed class FakeBom : IBomMaterialExporter
        {
            private readonly BomMaterialExportResult result;
            internal FakeBom(BomMaterialExportResult result) { this.result = result; }
            public BomMaterialExportResult ExportAndReadMaterial(string expectedAssemblyTitle, string targetModelTitle)
            {
                AssertEqual("KA-ASM-1", expectedAssemblyTitle, "BOM assembly title");
                AssertEqual("KA-PART-1", targetModelTitle, "BOM model title");
                return result;
            }
        }
    }
}
