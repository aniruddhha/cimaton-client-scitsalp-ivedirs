using System;
using System.Collections.Generic;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application.Tests
{
    internal static class ReadMappedTabularDataTests
    {
        private static readonly string[] Headers = { "Part", "Steel Grade", "Weight" };
        private static readonly string[] PartHeaders = { "Part" };
        private static readonly string[] SteelGradeHeaders = { "Steel Grade" };
        private static readonly string[] WeightHeaders = { "Weight" };
        private static readonly string[] PartOnlyHeaders = { "Part" };

        internal static void RunAll()
        {
            SuccessfulFlowUsesCanonicalPassedStatusAndHeaderSnapshot();
            DiscoveryFailureStopsBeforeMappingAndRead();
            MappingFailureStopsBeforeRead();
            ReadFailureIdentifiesReadStage();
            ValidationFailureIdentifiesValidationStage();
        }

        private static void SuccessfulFlowUsesCanonicalPassedStatusAndHeaderSnapshot()
        {
            FakeReader reader = new FakeReader(
                TabularHeaderDiscoveryResult.Succeeded(Headers),
                SuccessfulReadResult());

            ReadMappedTabularDataResult result = CreateUseCase(reader).Execute(Source(), Mapping());

            AssertEqual(ResultStatus.Passed, result.Status, "Canonical success status");
            AssertEqual(TabularProcessingStage.Completed, result.Stage, "Completed stage");
            AssertEqual(true, result.IsSuccess, "Success flag");
            AssertEqual(1, result.Table.Rows.Count, "Validated row count");
            AssertEqual(1, reader.ReadCount, "Reader invocation count");
            AssertEqual(Headers.Length, reader.ExpectedHeaders.Count, "Expected header snapshot count");
            AssertEqual("Steel Grade", reader.ExpectedHeaders[1], "Expected header snapshot value");
        }

        private static void DiscoveryFailureStopsBeforeMappingAndRead()
        {
            FakeReader reader = new FakeReader(
                TabularHeaderDiscoveryResult.Error("TABULAR_FILE_TOO_LARGE", "Input exceeds the configured maximum."),
                SuccessfulReadResult());

            ReadMappedTabularDataResult result = CreateUseCase(reader).Execute(Source(), Mapping());

            AssertEqual(ResultStatus.Error, result.Status, "Discovery canonical error status");
            AssertEqual(TabularProcessingStage.Discovery, result.Stage, "Discovery failure stage");
            AssertEqual("TABULAR_FILE_TOO_LARGE", result.ErrorCode, "Discovery error code");
            AssertEqual(0, reader.ReadCount, "Read not invoked after discovery failure");
            AssertEqual(null, result.Table, "Discovery failure table");
        }

        private static void MappingFailureStopsBeforeRead()
        {
            FakeReader reader = new FakeReader(
                TabularHeaderDiscoveryResult.Succeeded(PartOnlyHeaders),
                SuccessfulReadResult());

            ReadMappedTabularDataResult result = CreateUseCase(reader).Execute(Source(), Mapping());

            AssertEqual(ResultStatus.Error, result.Status, "Mapping canonical error status");
            AssertEqual(TabularProcessingStage.Mapping, result.Stage, "Mapping failure stage");
            AssertEqual("TABULAR_MAPPING_REQUIRED_HEADER_MISSING", result.ErrorCode, "Mapping error code");
            AssertEqual(0, reader.ReadCount, "Read not invoked after mapping failure");
        }

        private static void ReadFailureIdentifiesReadStage()
        {
            FakeReader reader = new FakeReader(
                TabularHeaderDiscoveryResult.Succeeded(Headers),
                TabularReadResult.Error("TABULAR_HEADERS_CHANGED", "Headers changed between discovery and read."));

            ReadMappedTabularDataResult result = CreateUseCase(reader).Execute(Source(), Mapping());

            AssertEqual(ResultStatus.Error, result.Status, "Read canonical error status");
            AssertEqual(TabularProcessingStage.Read, result.Stage, "Read failure stage");
            AssertEqual("TABULAR_HEADERS_CHANGED", result.ErrorCode, "Read consistency error code");
            AssertEqual(null, result.Table, "Read failure table");
        }

        private static void ValidationFailureIdentifiesValidationStage()
        {
            TabularSourceDefinition source = new TabularSourceDefinition(
                "fixture.xlsx",
                "Input",
                1,
                new[]
                {
                    new TabularColumnDefinition("Part", "Part", TabularValueType.Text, true),
                    new TabularColumnDefinition("SteelGrade", "Steel Grade", TabularValueType.Text, true),
                    new TabularColumnDefinition("Weight", "Weight", TabularValueType.Text, true)
                });
            TabularRow invalidRow = new TabularRow(2, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("Block_A"),
                ["SteelGrade"] = TabularValue.FromText("1.2344"),
                ["Weight"] = TabularValue.FromText("wrong-type")
            });
            FakeReader reader = new FakeReader(
                TabularHeaderDiscoveryResult.Succeeded(Headers),
                TabularReadResult.Succeeded(new TabularTable(source, new[] { invalidRow })));

            ReadMappedTabularDataResult result = CreateUseCase(reader).Execute(Source(), Mapping());

            AssertEqual(ResultStatus.Error, result.Status, "Validation canonical error status");
            AssertEqual(TabularProcessingStage.Validation, result.Stage, "Validation failure stage");
            AssertEqual("TABULAR_MAPPING_VALUE_TYPE_MISMATCH", result.ErrorCode, "Validation error code");
            AssertEqual(null, result.Table, "Validation failure table");
        }

        private static ReadMappedTabularData CreateUseCase(FakeReader reader)
        {
            return new ReadMappedTabularData(reader, reader, new TabularMappingEngine());
        }

        private static TabularHeaderSourceDefinition Source()
        {
            return new TabularHeaderSourceDefinition("fixture.xlsx", "Input", 1);
        }

        private static TabularMappingDefinition Mapping()
        {
            return new TabularMappingDefinition(
                "ProbeInput",
                new[]
                {
                    new TabularFieldMappingDefinition("Part", PartHeaders, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("SteelGrade", SteelGradeHeaders, TabularValueType.Text, true),
                    new TabularFieldMappingDefinition("Weight", WeightHeaders, TabularValueType.Decimal, true)
                });
        }

        private static TabularReadResult SuccessfulReadResult()
        {
            TabularSourceDefinition source = new TabularSourceDefinition(
                "fixture.xlsx",
                "Input",
                1,
                new[]
                {
                    new TabularColumnDefinition("Part", "Part", TabularValueType.Text, true),
                    new TabularColumnDefinition("SteelGrade", "Steel Grade", TabularValueType.Text, true),
                    new TabularColumnDefinition("Weight", "Weight", TabularValueType.Decimal, true)
                });
            TabularRow row = new TabularRow(2, new Dictionary<string, TabularValue>
            {
                ["Part"] = TabularValue.FromText("Block_A"),
                ["SteelGrade"] = TabularValue.FromText("1.2344"),
                ["Weight"] = TabularValue.FromDecimal(12.5m)
            });
            return TabularReadResult.Succeeded(new TabularTable(source, new[] { row }));
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
        }

        private sealed class FakeReader : ITabularHeaderReader, ITabularDataReader
        {
            private readonly TabularHeaderDiscoveryResult discoveryResult;
            private readonly TabularReadResult readResult;

            internal FakeReader(TabularHeaderDiscoveryResult discoveryResult, TabularReadResult readResult)
            {
                this.discoveryResult = discoveryResult;
                this.readResult = readResult;
                ExpectedHeaders = Array.Empty<string>();
            }

            internal int ReadCount { get; private set; }
            internal IReadOnlyList<string> ExpectedHeaders { get; private set; }

            public TabularHeaderDiscoveryResult DiscoverHeaders(TabularHeaderSourceDefinition source)
            {
                return discoveryResult;
            }

            public TabularReadResult Read(TabularSourceDefinition source)
            {
                ReadCount++;
                return readResult;
            }

            public TabularReadResult Read(TabularSourceDefinition source, IReadOnlyList<string> expectedHeaders)
            {
                ReadCount++;
                ExpectedHeaders = expectedHeaders;
                return readResult;
            }
        }
    }
}
