using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace CimatronCustomization.ArchitectureTests
{
    internal static class ArchitectureBoundaryTests
    {
        private static readonly XNamespace MsBuildNamespace = "http://schemas.microsoft.com/developer/msbuild/2003";

        internal static void RunAll()
        {
            string repositoryRoot = FindRepositoryRoot();

            ProjectReferencesMustPointInward(repositoryRoot);
            DomainMustNotReferenceCimatron(repositoryRoot);
            DesignChecksMustRemainReadOnlyAtTheProjectBoundary(repositoryRoot);
            CimatronDependenciesMustRemainAtApprovedOuterBoundaries(repositoryRoot);
            PluginMustRemainAThinCimatronEntryPoint(repositoryRoot);
            AttributeReaderMustHandleEntitySpecificArgumentException(repositoryRoot);
            ViewportHighlightMustRemainWithinVerifiedSelectionApi(repositoryRoot);
            Step08BProductionBoundariesMustRemainGuarded(repositoryRoot);
            ProductionPickMustRemainWithinVerifiedComBoundary(repositoryRoot);
            ZoomDiscoveryToolMustRemainReadOnlyAndDevelopmentOnly(repositoryRoot);
            ZoomSelectionValidationMustRemainControlledAndDevelopmentOnly(repositoryRoot);
            ApiCapabilityVerificationMustRemainReadOnlyAndDevelopmentOnly(repositoryRoot);
        }

        private static void ProjectReferencesMustPointInward(string repositoryRoot)
        {
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Domain", Array.Empty<string>());
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.CimatronIntegration", "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.DesignChecks", "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Automations", "CimatronCustomization.Application", "CimatronCustomization.Domain");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Infrastructure", "CimatronCustomization.Application");
            AssertProjectReferences(repositoryRoot, "CimatronCustomization.Plugin",
                "CimatronCustomization.Application",
                "CimatronCustomization.Automations",
                "CimatronCustomization.CimatronIntegration",
                "CimatronCustomization.DesignChecks",
                "CimatronCustomization.Infrastructure");
        }

        private static void DomainMustNotReferenceCimatron(string repositoryRoot)
        {
            string domainProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Domain");
            AssertNoAssemblyReferencesContaining(domainProject, "Cim", "interop.");
            AssertNoProjectReference(domainProject, "CimatronCustomization.CimatronIntegration");
        }

        private static void DesignChecksMustRemainReadOnlyAtTheProjectBoundary(string repositoryRoot)
        {
            string designChecksProject = GetProjectPath(repositoryRoot, "CimatronCustomization.DesignChecks");
            AssertNoProjectReference(designChecksProject, "CimatronCustomization.Automations");
            AssertNoProjectReference(designChecksProject, "CimatronCustomization.CimatronIntegration");
            AssertNoAssemblyReferencesContaining(designChecksProject, "Cim", "interop.");

            string automationsProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Automations");
            AssertNoProjectReference(automationsProject, "CimatronCustomization.DesignChecks");
            AssertNoProjectReference(automationsProject, "CimatronCustomization.CimatronIntegration");
            AssertNoAssemblyReferencesContaining(automationsProject, "Cim", "interop.");
        }

        private static void CimatronDependenciesMustRemainAtApprovedOuterBoundaries(string repositoryRoot)
        {
            string[] projectsWithoutDirectCimatronDependencies =
            {
                "CimatronCustomization.Domain",
                "CimatronCustomization.Application",
                "CimatronCustomization.DesignChecks",
                "CimatronCustomization.Automations",
                "CimatronCustomization.Infrastructure"
            };

            foreach (string projectName in projectsWithoutDirectCimatronDependencies)
            {
                AssertNoAssemblyReferencesContaining(GetProjectPath(repositoryRoot, projectName), "Cim", "interop.");
            }
        }

        private static void PluginMustRemainAThinCimatronEntryPoint(string repositoryRoot)
        {
            string pluginProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Plugin");
            AssertNoProjectReference(pluginProject, "CimatronCustomization.Domain");

            string pluginDirectory = Path.GetDirectoryName(pluginProject);
            string[] productionSources = Directory.GetFiles(pluginDirectory, "*.cs", SearchOption.TopDirectoryOnly)
                .Select(Path.GetFileName)
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            string[] expectedSources =
            {
                "CimatronCommandExecution.cs",
                "CimatronPluginCommand.cs",
                "FeatureComposition.cs",
                "FeatureLauncherWindow.cs",
                "FindingReportWindow.cs"
            };

            if (!productionSources.SequenceEqual(expectedSources, StringComparer.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "Plugin boundary violation: unexpected top-level production source files were found. " +
                    "The Plugin project must remain a thin Cimatron entry point until an explicit architecture change is approved.");
            }
        }


        private static void AttributeReaderMustHandleEntitySpecificArgumentException(string repositoryRoot)
        {
            string sourcePath = Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.CimatronIntegration",
                "CimatronModelInspectionAdapter.cs");

            string source = File.ReadAllText(sourcePath);
            const string getAttributesCall = ".GetAttributes()";
            int getAttributesCount = 0;
            int searchIndex = 0;
            while ((searchIndex = source.IndexOf(getAttributesCall, searchIndex, StringComparison.Ordinal)) >= 0)
            {
                getAttributesCount++;
                searchIndex += getAttributesCall.Length;
            }

            if (getAttributesCount != 1)
            {
                throw new InvalidOperationException(
                    "Cimatron model inspection adapter must contain exactly one GetAttributes() call. Every GetAttributes() call must go through the guarded TryGetRawAttributes helper.");
            }

            int helperStart = source.IndexOf("private static bool TryGetRawAttributes(", StringComparison.Ordinal);
            if (helperStart < 0)
            {
                throw new InvalidOperationException(
                    "Cimatron model inspection adapter must define TryGetRawAttributes so every GetAttributes() call goes through the guarded helper.");
            }

            int nextMethod = source.IndexOf("        public ModelReadResult<BodyTopologySnapshot> ReadCurrentTopology()", helperStart, StringComparison.Ordinal);
            if (nextMethod < 0)
            {
                throw new InvalidOperationException(
                    "Cimatron model inspection adapter source contract could not determine the end of TryGetRawAttributes.");
            }

            string helperSource = source.Substring(helperStart, nextMethod - helperStart);
            if (helperSource.IndexOf(getAttributesCall, StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "The single GetAttributes() call must be located inside the guarded TryGetRawAttributes helper.");
            }

            if (helperSource.IndexOf("catch (ArgumentException exception)", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "TryGetRawAttributes must convert live entity-specific GetAttributes ArgumentException failures into a controlled Unsupported result.");
            }

            if (source.IndexOf("GetAttributes() is not supported for this entity", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Cimatron model attribute reader must provide an explicit Unsupported message for entity-specific GetAttributes rejection.");
            }

            if (helperSource.IndexOf("catch (Exception", StringComparison.Ordinal) >= 0 ||
                helperSource.IndexOf("catch (COMException", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "TryGetRawAttributes must catch only ArgumentException; unexpected GetAttributes exceptions must still propagate.");
            }
        }

        private static void ViewportHighlightMustRemainWithinVerifiedSelectionApi(string repositoryRoot)
        {
            string sourcePath = Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.CimatronIntegration",
                "CimatronViewportEntityHighlighter.cs");

            if (!File.Exists(sourcePath))
            {
                throw new InvalidOperationException("Step 05A requires the Cimatron viewport highlight adapter.");
            }

            string source = File.ReadAllText(sourcePath);
            if (source.IndexOf("ISelection", StringComparison.Ordinal) < 0 ||
                source.IndexOf("selection.Selection = entityList", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Viewport highlighting must use the verified Cimatron ISelection.Selection boundary.");
            }

            if (source.IndexOf("IPickTool", StringComparison.Ordinal) >= 0 ||
                source.IndexOf("IDisplayUtils", StringComparison.Ordinal) >= 0 ||
                source.IndexOf("PushPickTool", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05A must not implement unapproved PickTool or zoom/display-transformation behavior.");
            }

            string pluginProject = GetProjectPath(repositoryRoot, "CimatronCustomization.Plugin");
            AssertNoProjectReference(pluginProject, "CimatronCustomization.Domain");
        }

        private static void Step08BProductionBoundariesMustRemainGuarded(string repositoryRoot)
        {
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string occurrenceSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronOccurrenceEntityAttributeReader.cs"));
            if (occurrenceSource.IndexOf("nestedInstance.GetAllEntities()", StringComparison.Ordinal) < 0 ||
                occurrenceSource.IndexOf("GetAttribute(", StringComparison.Ordinal) < 0 ||
                occurrenceSource.IndexOf("AttributeEnumType.cmAttString", StringComparison.Ordinal) < 0 ||
                occurrenceSource.IndexOf("GetEntityById(", StringComparison.Ordinal) >= 0 ||
                occurrenceSource.IndexOf("string.Equals(attribute.Name", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U13 adapter must use occurrence-reached GetAllEntities plus exact named cmAttString lookup and must not regress to GetEntityById or returned IAttribute.Name equality.");
            }

            string mapperSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronAssemblyEntityMapper.cs"));
            if (mapperSource.IndexOf("assembly.GetAssemblyEntity(", StringComparison.Ordinal) < 0 ||
                mapperSource.IndexOf("FindOccurrenceEntity", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U7 adapter must map the occurrence-owned entity through IAssemblyModel.GetAssemblyEntity.");
            }

            string bomSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronBomMaterialExporter.cs"));
            if (bomSource.IndexOf("ComponentsFilterOption.cmNoFiltering", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("ITabularDataReader", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("new TabularColumnDefinition(\"Model\", \"Standard Number\", TabularValueType.Text, true)", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("new TabularColumnDefinition(\"Material\", \"Material\", TabularValueType.Text, false)", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("row.TryGetValue(\"Material\"", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("Required Material value is missing for target model", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("Path.GetTempPath()", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("\"CimatronCustomization\", \"Step08B\"", StringComparison.Ordinal) < 0 ||
                bomSource.IndexOf("Directory.Delete(runDirectory, true)", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U15 adapter must retain cmNoFiltering export, validated tabular readback, required Standard Number, optional non-target Material values, target-row Material enforcement, and governed Step08B temporary cleanup.");
            }

            string highlighterSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronViewportEntityHighlighter.cs"));
            if (highlighterSource.IndexOf("Nested Cimatron entity references require an active Assembly document.", StringComparison.Ordinal) < 0 ||
                highlighterSource.IndexOf("assembly.GetAssemblyEntity(occurrenceEntity", StringComparison.Ordinal) < 0 ||
                highlighterSource.IndexOf("selection.Selection = entityList", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 08B U12 production highlight path must resolve the nested occurrence, map it into Assembly context, and use the verified ISelection.Selection boundary.");
            }
        }

        private static void ProductionPickMustRemainWithinVerifiedComBoundary(string repositoryRoot)
        {
            string integrationDirectory = Path.Combine(repositoryRoot, "src", "CimatronCustomization.CimatronIntegration");
            string assemblyInfo = File.ReadAllText(Path.Combine(integrationDirectory, "Properties", "AssemblyInfo.cs"));
            if (assemblyInfo.IndexOf("[assembly: ComVisible(false)]", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "CimatronIntegration must remain ComVisible(false) at assembly level; only the approved production PickTool class may opt in.");
            }

            string[] comVisibleSources = Directory.GetFiles(integrationDirectory, "*.cs", SearchOption.TopDirectoryOnly)
                .Where(path => File.ReadAllText(path).IndexOf("[ComVisible(true)]", StringComparison.Ordinal) >= 0)
                .Select(Path.GetFileName)
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            string[] expectedComVisibleSources = { "CimatronViewportPickTool.cs" };
            if (!comVisibleSources.SequenceEqual(expectedComVisibleSources, StringComparer.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "Step 05B2 allows exactly one COM-visible CimatronIntegration class: CimatronViewportPickTool.");
            }

            string pickToolSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronViewportPickTool.cs"));
            if (pickToolSource.IndexOf("[Guid(\"8C05B1D6-7440-4EF7-A369-9A86B54AE151\")]", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.Tool", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.IToolEvents", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.IPickToolEvents", StringComparison.Ordinal) < 0 ||
                pickToolSource.IndexOf("interop.CimBaseAPI.IFigureEvent", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Production PickTool must retain the verified fixed GUID and installed Cimatron Tool/event interfaces from Step 05B1.");
            }

            string pickerSource = File.ReadAllText(Path.Combine(integrationDirectory, "CimatronViewportEntityPicker.cs"));
            if (pickerSource.IndexOf("IToolContainer", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("PushPickTool", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmPart", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("ViewportPickOutcome.Busy", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("SynchronizationContext.Current", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("CancellationToken", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmBody", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmFace", StringComparison.Ordinal) < 0 ||
                pickerSource.IndexOf("cmEdge", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 production Pick must remain Part-only, non-blocking/cancellable, use IToolContainer.PushPickTool, expose Busy/StaleResult, and enforce the approved Cimatron entity-type filter.");
            }

            string resultValidatorSource = File.ReadAllText(Path.Combine(integrationDirectory, "ViewportPickResultValidator.cs"));
            if (resultValidatorSource.IndexOf("ViewportPickOutcome.StaleResult", StringComparison.Ordinal) < 0 ||
                resultValidatorSource.IndexOf("SOURCE_DOCUMENT_STALE", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 must fail closed with the approved StaleResult outcome before a source-document-scoped entity ID can be reused.");
            }

            if (pickerSource.IndexOf("RegAsm", StringComparison.OrdinalIgnoreCase) >= 0 ||
                pickToolSource.IndexOf("RegAsm", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 must retain direct managed-object handoff and must not introduce COM registration behavior.");
            }

            string[] removedSpikeFiles =
            {
                "CimatronPartPickSpike.cs",
                "CimatronDiagnosticPickTool.cs",
                "PartPickSpikeOutcome.cs",
                "PartPickSpikeStartResult.cs"
            };
            if (removedSpikeFiles.Any(name => File.Exists(Path.Combine(integrationDirectory, name))))
            {
                throw new InvalidOperationException(
                    "The Step 05B1 diagnostic spike must not remain in the 0.15.2 Release production source tree.");
            }

            string commandSource = File.ReadAllText(Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.Plugin",
                "CimatronCommandExecution.cs"));
            if (commandSource.IndexOf("launcher.ShowDialog()", StringComparison.Ordinal) >= 0 ||
                commandSource.IndexOf("launcher.ShowOwnedByCimatron();", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("activeLauncher.RestoreToFront();", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("Process.GetCurrentProcess().MainWindowHandle", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("private static FeatureLauncherWindow activeLauncher", StringComparison.Ordinal) < 0 ||
                commandSource.IndexOf("IViewportEntityPicker viewportEntityPicker", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 requires the modeless/strongly-retained launcher lifecycle and Application-owned production Pick port.");
            }

            string launcherSource = File.ReadAllText(Path.Combine(
                repositoryRoot,
                "src",
                "CimatronCustomization.Plugin",
                "FeatureLauncherWindow.cs"));
            if (launcherSource.IndexOf("Pick Spike (Part)", StringComparison.Ordinal) >= 0 ||
                launcherSource.IndexOf("CimatronPartPickSpike", StringComparison.Ordinal) >= 0 ||
                launcherSource.IndexOf("IViewportEntityPicker", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("new CancellationTokenSource()", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("viewportEntityPicker.BeginPick", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("viewportEntityPicker.ValidateForCurrentDocument", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("BringToFront();", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("Show(new WindowHandleOwner(cimatronWindowHandle));", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("foregroundMonitor.Tick += ForegroundMonitorTick;", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("GetForegroundWindow()", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("SetForegroundWindow(cimatronWindowHandle);", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("uint foregroundThreadId = GetWindowThreadProcessId", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("if (foregroundThreadId == 0)", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("currentProcessForeground && !cimatronWasForeground", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("Visible && Enabled && !viewportEntityPicker.IsActive", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("private sealed class PickResultDialog : Form", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("PickResultDialog.ShowResult(", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("RestoreCimatronAndLauncherFocus();", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("TopMost = true;", StringComparison.Ordinal) < 0 ||
                launcherSource.IndexOf("dialog.ShowDialog(owner);", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05B2 UI must remove the diagnostic spike path while preserving the verified launcher/result focus lifecycle and using the Application production Pick contract.");
            }
        }


        private static void ZoomDiscoveryToolMustRemainReadOnlyAndDevelopmentOnly(string repositoryRoot)
        {
            string toolDirectory = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.ZoomCommandDiscovery");
            string toolProject = Path.Combine(toolDirectory, "CimatronCustomization.ZoomCommandDiscovery.csproj");
            string programSource = File.ReadAllText(Path.Combine(toolDirectory, "Program.cs"));
            string commandSource = File.ReadAllText(Path.Combine(toolDirectory, "CommandPoolInventory.cs"));
            string reflectionSource = File.ReadAllText(Path.Combine(toolDirectory, "InteropReflectionInventory.cs"));
            string assemblyEntitySource = File.ReadAllText(Path.Combine(toolDirectory, "AssemblyEntityInventory.cs"));
            string occurrenceInterfaceSource = File.ReadAllText(Path.Combine(toolDirectory, "OccurrenceComInterfaceInventory.cs"));
            string traceWriterPath = Path.Combine(toolDirectory, "DiagnosticTraceWriter.cs");
            if (!File.Exists(traceWriterPath))
            {
                throw new InvalidOperationException("Step 05C2 durable diagnostic trace writer is missing.");
            }

            string traceWriterSource = File.ReadAllText(traceWriterPath);
            string projectSource = File.ReadAllText(toolProject);
            string captureSource = File.ReadAllText(Path.Combine(repositoryRoot, "tools", "Invoke-And-Capture.ps1"));

            if (projectSource.IndexOf("C:\\Program Files\\Cimatron\\Cimatron\\2026.0\\Program", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<ApplicationManifest>app.manifest</ApplicationManifest>", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<PlatformTarget>x64</PlatformTarget>", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C1 standalone discovery tool must remain x64, use the embedded Cimatron side-by-side manifest, and build into the Cimatron 2026 Program folder.");
            }

            string combinedSource = programSource + commandSource + reflectionSource + assemblyEntitySource + occurrenceInterfaceSource;

            string[] assemblyReflectionRequiredTokens =
            {
                "--reflect-assembly-api",
                "RunAssemblyApi()",
                "AssemblyApiTerms",
                "ReflectionOnlyLoadFrom",
                "GetInterfaces()",
                "RuntimeCalls: NONE (reflection-only installed-Interop inventory)"
            };
            if (assemblyReflectionRequiredTokens.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                reflectionSource.IndexOf("new AppAccess", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetActiveDoc()", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-A Assembly API surface inventory must remain reflection-only, base-interface-aware, and free of live Cimatron runtime calls.");
            }

            string[] visibilityReflectionRequiredTokens =
            {
                "--reflect-visibility-api",
                "RunVisibilityApi()",
                "VisibilityTerms",
                "Show",
                "Visible",
                "Visibility",
                "Hidden",
                "Hide",
                "Blank",
                "Display",
                "State",
                "_IASSINSTANCE COPIES",
                "CurrentCastTarget: interop.CimMdlrAPI._IAssInstance",
                "CurrentCastMechanism: C# 'as' cast",
                "CurrentCastExceptionType: NONE",
                "CurrentCastHRESULT: N/A",
                "PROPERTY_GET",
                "PROPERTY_SET",
                "AMBIGUOUS_METHOD_NOT_INVOKED",
                "cmAttVisibility",
                "cmAttBlankLevel",
                "BODY/ENTITY-LEVEL CANDIDATES ONLY",
                "NewlyDiscoveredMemberInvocation: PROHIBITED / NOT CALLED",
                "FR-021 remains OPEN"
            };
            if (visibilityReflectionRequiredTokens.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                reflectionSource.IndexOf("interop.CimAppAccess", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetApplication()", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetActiveDoc()", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B hidden-state discovery must remain reflection-only, classify visibility members by access kind, inventory _IAssInstance copies and visibility attributes, and invoke no newly discovered Cimatron member.");
            }
            string[] occurrenceInterfaceRequiredTokens =
            {
                "--probe-occurrence-interfaces",
                "Marshal.QueryInterface",
                "Marshal.Release(supportedPointer)",
                "Marshal.Release(unknown)",
                "IProvideClassInfo",
                "GetClassInfo",
                "IDispatch.GetTypeInfo",
                "INTERFACE x OBJECT SUPPORT MATRIX",
                "VISIBLE_Block_A",
                "HIDDEN_NOT_SUPPRESSED_Known_Pocket_Body",
                "SUPPRESSED_Block_B",
                "NewlyDiscoveredMemberInvocation: PROHIBITED / NOT CALLED",
                "EXPECTED: visible/hidden/suppressed occurrences likely expose identical COM interface sets",
                "STOP reflection search",
                "suppressed: supported; hidden: BLOCKED — pending Cimatron guidance"
            };
            string[] occurrenceInterfaceForbiddenTokens =
            {
                ".Execute(",
                "PushPickTool",
                "PopTool",
                "Selection(",
                "Highlight(",
                "CreateProcedure(",
                "RemoveAttribute(",
                "SuppressComponents(",
                "Save()",
                "SaveAs("
            };
            if (occurrenceInterfaceRequiredTokens.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                occurrenceInterfaceForbiddenTokens.Any(value => occurrenceInterfaceSource.IndexOf(value, StringComparison.Ordinal) >= 0) ||
                projectSource.IndexOf("<Compile Include=\"OccurrenceComInterfaceInventory.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B final occurrence COM-interface diagnostic must query each IID read-only, release COM pointers immediately, classify newly found interfaces by reflection only, and retain the approved stopping rule.");
            }

            string[] forbiddenMutationCalls =
            {
                ".Execute(",
                "ExecutePluginCommand",
                "PushPickTool",
                "PopTool",
                "Selection(",
                "Highlight("
            };
            if (forbiddenMutationCalls.Any(value => combinedSource.IndexOf(value, StringComparison.Ordinal) >= 0))
            {
                throw new InvalidOperationException(
                    "Step 05C1 discovery tool is evidence-only and must not execute Cimatron commands or mutate selection/view/model state.");
            }

            string[] allowedApiTokens =
            {
                "GetApplication()",
                "GetActiveDoc()",
                "GetPoolCommands()",
                "GetCommandsNames()",
                "application.ProductName",
                "application.Version",
                "activeDocument.Type"
            };
            if (allowedApiTokens.Any(value => commandSource.IndexOf(value, StringComparison.Ordinal) < 0))
            {
                throw new InvalidOperationException(
                    "Step 05C1 live inventory must retain only the approved read-only application/document/command-pool calls and metadata reads.");
            }

            string[] assemblyInventoryRequiredTokens =
            {
                "GetApplication()",
                "GetActiveDoc()",
                "GetRootInstance()",
                "SubInstances[1, 0]",
                "AssParentInstance",
                "AssRootInstance",
                "IsSuppressed",
                "IgnoreInShowOperations",
                "IAssInstance.get_IgnoreInShowOperations GETTER_ONLY",
                "GetAttribute(attributeType, string.Empty)",
                "cmAttVisibility",
                "cmAttBlankLevel",
                "LegacyShowProbe: CLOSED BY USER-VALIDATED 0.15.29 RUN",
                "OccurrenceVisibilityMutation: PROHIBITED / NOT CALLED",
                "OccurrenceVisibilitySemantics: raw candidate values are evidence only",
                "Transformation[rootParent]",
                ".Matrix",
                ".Vector",
                "GetAllEntities()",
                "entities.Count",
                "entities[index]",
                "GetAttribute(interop.CimBaseAPI.AttributeEnumType.cmAttInteger, attributeName)",
                "IsModified()",
                "GetPath()",
                "ApiCallTimeoutMilliseconds = 15000",
                "ApiCallTimeoutExitCode = 7",
                "MaximumDepth = 16",
                "MaximumOccurrences = 2000",
                "MaximumEntityInspections = 2000",
                "Environment.Exit(ApiCallTimeoutExitCode)",
                "OccurrenceIdentity: full traversal path with sibling ordinal",
                "CycleGuard: ancestor assembly definition ModelPID only",
                "@ordinal-",
                "ancestorAssemblyDefinitions.Contains(modelPid)",
                "SKIPPED_DEFINITION_CYCLE_GUARD"
            };
            string[] assemblyInventoryForbiddenTokens =
            {
                "GetInstances()",
                "CreateFilter(",
                "SetFilter(",
                "Select()",
                "GetFaces()",
                "OpenDocument(",
                "OpenDocumentAsync(",
                "SetActiveDocument(",
                "Save()",
                "SaveAs(",
                "SuppressComponents(",
                "CreateProcedure(",
                "RemoveAttribute(",
                ".Attach(",
                ".Detach(",
                ".Move(",
                ".Rotate(",
                ".ScaleFactor(",
                ".Inverse(",
                "VisitedIdentity",
                "(interop.CimMdlrAPI._IAssInstance)instance",
                "extended.Show_",
                "set_",
                ".Show_ =",
                "Show_="
            };
            if (assemblyInventoryRequiredTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                assemblyInventoryForbiddenTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) >= 0) ||
                assemblyEntitySource.IndexOf(".Execute(", StringComparison.Ordinal) >= 0 ||
                assemblyEntitySource.IndexOf("selection.Selection", StringComparison.Ordinal) >= 0 ||
                assemblyEntitySource.IndexOf("PushPickTool", StringComparison.Ordinal) >= 0 ||
                assemblyEntitySource.IndexOf("PopTool", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B Assembly diagnostic must remain inside the approved read-only installed-Interop allow-list with timeout, traversal limits, cycle guard, attribute reads, and no-mutation evidence.");
            }

            if (projectSource.IndexOf("<Compile Include=\"AssemblyEntityInventory.cs\" />", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<Compile Include=\"DiagnosticTraceWriter.cs\" />", StringComparison.Ordinal) < 0 ||
                programSource.IndexOf("--assembly-entities", StringComparison.Ordinal) < 0 ||
                programSource.IndexOf("--occurrence-only", StringComparison.Ordinal) < 0 ||
                programSource.IndexOf("--trace-selftest", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 Assembly entity inventory/trace diagnostic source and entry points must remain present.");
            }

            string[] durableTraceRequiredTokens =
            {
                "Environment.SpecialFolder.LocalApplicationData",
                "CimatronCustomization",
                "diagnostics",
                "FileOptions.WriteThrough",
                "stream.Flush(true)",
                "Environment.CommandLine",
                "IsElevated()",
                "GetApartmentState()",
                "HEARTBEAT alive; lastCheckpoint="
            };
            if (durableTraceRequiredTokens.Any(value => traceWriterSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                traceWriterSource.IndexOf("interop.", StringComparison.OrdinalIgnoreCase) >= 0 ||
                traceWriterSource.IndexOf("CimAppAccess", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 durable trace must remain user-writable, write-through, environment-aware, heartbeat-enabled, and independent of Cimatron APIs.");
            }

            string[] selfTestRequiredTokens =
            {
                "Dispatch: trace-selftest",
                "TRACE SELFTEST checkpoint 1",
                "TRACE SELFTEST checkpoint 2",
                "TRACE SELFTEST completed"
            };
            if (selfTestRequiredTokens.Any(value => programSource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                captureSource.IndexOf("'trace-selftest'", StringComparison.Ordinal) < 0 ||
                captureSource.IndexOf("@('--trace-selftest')", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 trace self-test must retain its Cimatron-independent checkpoints and named capture task.");
            }

            string[] attachDiagnosticRequiredTokens =
            {
                "--attach-only",
                "--apartment=STA",
                "--apartment=MTA",
                "worker.SetApartmentState(requestedApartment)",
                "AttachTimeoutMilliseconds = 30000",
                "ATTACH CHECKPOINT A2",
                "ATTACH CHECKPOINT A3",
                "ATTACH TIMEOUT",
                "return 5;",
                "GetApplication reflection signature",
                "GetInterfaces()",
                "Process.GetProcessesByName(\"CimatronE\")",
                "CimatronProcessCount:",
                "SessionId=",
                "Elevated=",
                "ATTACH PRECONDITION FAILED: confirmed elevation mismatch",
                "AttachElevationMismatchExitCode = 6",
                "OPERATOR_CONFIRMATION_REQUIRED"
            };
            if (attachDiagnosticRequiredTokens.Any(value => programSource.IndexOf(value, StringComparison.Ordinal) < 0))
            {
                throw new InvalidOperationException(
                    "Step 05C2 attach-only diagnostic must retain switchable STA/MTA execution, bounded observation, inherited-interface signature evidence, exact CimatronE process/elevation evidence, and mismatch fail-fast behavior.");
            }

            string[] assemblyBudgetEvidenceRequiredTokens =
            {
                "TryConsumeOccurrence",
                "TryConsumeEntityInspection",
                "OccurrenceLimitReached",
                "EntityInspectionLimitReached",
                "ENTITIES_NOT_INSPECTED_ENTITY_BUDGET_EXHAUSTED",
                "PARTIAL_ENTITY_INSPECTION_BUDGET_EXHAUSTED",
                "DISABLED_OCCURRENCE_ONLY",
                "EntityInspectionStatus",
                "TotalRunTime:",
                "MbCoolingViaOccurrence: PROVEN BY USER-VALIDATED 0.15.23 RUN",
                "MbPocketViaOccurrence: PROVEN BY USER-VALIDATED 0.15.24 KNOWN-ANSWER RUN",
                "OccurrenceIdentityFinding: InstanceId is not authoritative placed-occurrence identity",
                "CycleGuardRuntimeStatus: recursive self-assembly cycle not exercised in live Cimatron validation",
                "HiddenStateDetection: RUNTIME CANDIDATE COMPARISON PENDING",
                "FalseNegativeRule:"
            };
            if (assemblyBudgetEvidenceRequiredTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) < 0) ||
                programSource.IndexOf("AssemblyEntityInventory.Run(!occurrenceOnly)", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2-B must keep occurrence traversal and entity-inspection budgets independent, explicitly mark skipped/partial entity inspection, record runtime/open findings, and expose read-only occurrence-only mode.");
            }

            string[] assemblyInventoryCheckpointTokens =
            {
                "CHECKPOINT ",
                "Console.Out.Flush()",
                "WriteCheckpoint(ref checkpointNumber, \"BEGIN API \" + label)",
                "T value = call();",
                "WriteCheckpoint(ref checkpointNumber, \"END API \" + label)",
                "AppAccess.GetApplication",
                "IApplication.GetActiveDoc",
                "IAssemblyModel.GetRootInstance",
                "string parentId = \"ROOT/N/A\";",
                "if (!isRoot)",
                "IAssInstance.get_AssParentInstance",
                "IAssInstance.get_SubInstances",
                "IAssInstance.GetAllEntities",
                "IAttributeSink.GetAttribute(cmAttInteger, ",
                "IAssInstance.get_Transformation(",
                "IModelTransformation.get_Matrix",
                "IModelTransformation.get_Vector",
                "ICimDocument.IsModified"
            };
            if (assemblyInventoryCheckpointTokens.Any(value => assemblyEntitySource.IndexOf(value, StringComparison.Ordinal) < 0))
            {
                throw new InvalidOperationException(
                    "Step 05C2 Assembly entity inventory must retain immediate diagnostic checkpoints around the approved potentially blocking COM calls.");
            }

            int rootParentGuard = assemblyEntitySource.IndexOf("if (!isRoot)", StringComparison.Ordinal);
            int parentCall = assemblyEntitySource.IndexOf("IAssInstance.get_AssParentInstance", StringComparison.Ordinal);
            if (rootParentGuard < 0 || parentCall <= rootParentGuard)
            {
                throw new InvalidOperationException(
                    "Step 05C2 root pseudo-instance must skip the parent-instance COM call and record parent as not applicable.");
            }

            int beginApiCheckpoint = assemblyEntitySource.IndexOf(
                "WriteCheckpoint(ref checkpointNumber, \"BEGIN API \" + label)",
                StringComparison.Ordinal);
            int wrappedApiCall = assemblyEntitySource.IndexOf("T value = call();", StringComparison.Ordinal);
            int endApiCheckpoint = assemblyEntitySource.IndexOf(
                "WriteCheckpoint(ref checkpointNumber, \"END API \" + label)",
                StringComparison.Ordinal);
            if (beginApiCheckpoint < 0 || wrappedApiCall <= beginApiCheckpoint || endApiCheckpoint <= wrappedApiCall)
            {
                throw new InvalidOperationException(
                    "Step 05C2 Assembly API wrapper must checkpoint immediately before and after the wrapped COM call.");
            }

            string srcDirectory = Path.Combine(repositoryRoot, "src");
            foreach (string productionProject in Directory.GetFiles(srcDirectory, "*.csproj", SearchOption.AllDirectories))
            {
                string text = File.ReadAllText(productionProject);
                if (text.IndexOf("CimatronCustomization.ZoomCommandDiscovery", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    throw new InvalidOperationException(
                        "Production projects must not reference the Step 05C1 diagnostic tool: " + productionProject);
                }
            }

            string integrationTestProject = Path.Combine(
                repositoryRoot,
                "tests",
                "CimatronCustomization.CimatronIntegrationTests",
                "CimatronCustomization.CimatronIntegrationTests.csproj");
            string integrationTestProgram = Path.Combine(
                repositoryRoot,
                "tests",
                "CimatronCustomization.CimatronIntegrationTests",
                "Program.cs");
            if (File.ReadAllText(integrationTestProject).IndexOf("ZoomCommandDiscovery", StringComparison.OrdinalIgnoreCase) >= 0 ||
                File.ReadAllText(integrationTestProgram).IndexOf("discover-zoom-commands", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                throw new InvalidOperationException(
                    "The obsolete 0.15.6 test-executable zoom discovery hook must remain removed.");
            }
        }

        private static void AssertProjectReferences(string repositoryRoot, string projectName, params string[] expectedProjectNames)
        {
            string projectPath = GetProjectPath(repositoryRoot, projectName);
            XDocument document = XDocument.Load(projectPath);

            string[] actualProjectNames = document
                .Descendants(MsBuildNamespace + "ProjectReference")
                .Select(reference => reference.Element(MsBuildNamespace + "Name"))
                .Where(name => name != null)
                .Select(name => name.Value)
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            string[] expected = expectedProjectNames
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (!actualProjectNames.SequenceEqual(expected, StringComparer.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    projectName + " project references are invalid. Expected: [" + string.Join(", ", expected) +
                    "]; Actual: [" + string.Join(", ", actualProjectNames) + "].");
            }
        }

        private static void AssertNoProjectReference(string projectPath, string forbiddenProjectName)
        {
            XDocument document = XDocument.Load(projectPath);
            bool found = document
                .Descendants(MsBuildNamespace + "ProjectReference")
                .Select(reference => reference.Element(MsBuildNamespace + "Name"))
                .Where(name => name != null)
                .Any(name => string.Equals(name.Value, forbiddenProjectName, StringComparison.OrdinalIgnoreCase));

            if (found)
            {
                throw new InvalidOperationException(
                    Path.GetFileNameWithoutExtension(projectPath) + " must not reference " + forbiddenProjectName + ".");
            }
        }

        private static void AssertNoAssemblyReferencesContaining(string projectPath, params string[] forbiddenFragments)
        {
            XDocument document = XDocument.Load(projectPath);
            IEnumerable<string> references = document
                .Descendants(MsBuildNamespace + "Reference")
                .Select(reference => (string)reference.Attribute("Include"))
                .Where(include => !string.IsNullOrWhiteSpace(include));

            foreach (string reference in references)
            {
                foreach (string forbiddenFragment in forbiddenFragments)
                {
                    if (reference.IndexOf(forbiddenFragment, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        throw new InvalidOperationException(
                            Path.GetFileNameWithoutExtension(projectPath) +
                            " contains forbidden direct Cimatron dependency: " + reference + ".");
                    }
                }
            }
        }

        private static void ZoomSelectionValidationMustRemainControlledAndDevelopmentOnly(string repositoryRoot)
        {
            string toolDirectory = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.ZoomCommandDiscovery");
            string validationSourcePath = Path.Combine(toolDirectory, "ZoomSelectionValidation.cs");
            string projectPath = Path.Combine(toolDirectory, "CimatronCustomization.ZoomCommandDiscovery.csproj");
            string programPath = Path.Combine(toolDirectory, "Program.cs");

            if (!File.Exists(validationSourcePath))
            {
                throw new InvalidOperationException("Step 05C2 requires the controlled Zoom Selection validation diagnostic.");
            }

            string validationSource = File.ReadAllText(validationSourcePath);
            string projectSource = File.ReadAllText(projectPath);
            string programSource = File.ReadAllText(programPath);

            if (validationSource.IndexOf("private const string ZoomCategoryName = \"&Display\";", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("private const string ZoomCommandName = \"Zoom Selection\";", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("GetCommand(ZoomCategoryName, ZoomCommandName)", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("zoomSelectionCommand.Execute();", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 may execute only the explicitly discovered &Display / Zoom Selection native command.");
            }

            if (CountOccurrences(validationSource, ".Execute();") != 1)
            {
                throw new InvalidOperationException(
                    "Step 05C2 diagnostic must contain exactly one native command execution call.");
            }

            if (validationSource.IndexOf("selection.Selection = validationSelection;", StringComparison.Ordinal) < 0 ||
                validationSource.IndexOf("RestorePreviousSelection", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 must use the verified ISelection.Selection boundary and restore the prior selection after validation.");
            }

            string[] forbiddenCalls =
            {
                "ExecutePluginCommand",
                "PushPickTool",
                "PopTool",
                "SetActiveDocument",
                "UpdateSelection("
            };
            if (forbiddenCalls.Any(value => validationSource.IndexOf(value, StringComparison.Ordinal) >= 0))
            {
                throw new InvalidOperationException(
                    "Step 05C2 controlled validation must not broaden into other Cimatron command, PickTool, document, or selection mutation APIs.");
            }

            if (projectSource.IndexOf("interop.CimMdlrAPI.dll", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<Compile Include=\"ZoomSelectionValidation.cs\" />", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 diagnostic project must compile only the approved Cimatron selection validation source with the installed Cimatron modeler interop.");
            }

            if (programSource.IndexOf("--validate-zoom-selection", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException(
                    "Step 05C2 diagnostic entry point is missing the approved controlled validation mode.");
            }

            string srcDirectory = Path.Combine(repositoryRoot, "src");
            foreach (string productionProject in Directory.GetFiles(srcDirectory, "*.csproj", SearchOption.AllDirectories))
            {
                string text = File.ReadAllText(productionProject);
                if (text.IndexOf("CimatronCustomization.ZoomCommandDiscovery", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    throw new InvalidOperationException(
                        "Production projects must not reference the Step 05C2 diagnostic tool: " + productionProject);
                }
            }
        }


        private static void ApiCapabilityVerificationMustRemainReadOnlyAndDevelopmentOnly(string repositoryRoot)
        {
            string toolDirectory = Path.Combine(repositoryRoot, "tools", "CimatronCustomization.ApiCapabilityVerification");
            string projectPath = Path.Combine(toolDirectory, "CimatronCustomization.ApiCapabilityVerification.csproj");
            string reflectionPath = Path.Combine(toolDirectory, "CapabilityApiReflectionInventory.cs");
            if (!File.Exists(projectPath) || !File.Exists(reflectionPath))
            {
                throw new InvalidOperationException("Step 07 API capability verification tool is missing.");
            }

            string projectSource = File.ReadAllText(projectPath);
            if (projectSource.IndexOf("C:\\Program Files\\Cimatron\\Cimatron\\2026.0\\Program", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<ApplicationManifest>app.manifest</ApplicationManifest>", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("<PlatformTarget>x64</PlatformTarget>", StringComparison.Ordinal) < 0 ||
                projectSource.IndexOf("interop.CimServicesAPI.dll", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07 verification tool must remain x64, Program-folder output, embedded-manifest, and explicitly reference installed CimServicesAPI.");
            }

            string reflectionSource = File.ReadAllText(reflectionPath);
            if (reflectionSource.IndexOf("ReflectionOnlyLoadFrom", StringComparison.Ordinal) < 0 ||
                reflectionSource.IndexOf("RuntimeCalls: NONE (reflection-only installed-Interop inventory)", StringComparison.Ordinal) < 0 ||
                reflectionSource.IndexOf("AppAccess", StringComparison.Ordinal) >= 0 ||
                reflectionSource.IndexOf("GetActiveDoc()", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("Step 07 07A path must remain installed-Interop reflection-only with no Cimatron runtime attach.");
            }

            string[] sourceFiles = Directory.GetFiles(toolDirectory, "*.cs", SearchOption.AllDirectories);
            string combined = string.Join("\n", sourceFiles.Where(path => !string.Equals(path, reflectionPath, StringComparison.OrdinalIgnoreCase)).Select(File.ReadAllText));
            string[] forbiddenTokens =
            {
                "Show =", ".Color =", ".Lock =", ".Attribute =", "IgnoreInShowOperations =", "ActiveInstance =", "ActivateUcs =",
                "SuppressComponents", "SetDimensionByName", "RenameComponent", "CreateProcedure", "DeleteProcedure", "DeleteProcedureById",
                ".Execute()", "Save()", "SaveAs(", "Close()", "SetActiveDocument", "PushPickTool", "PopTool", "ExecutePluginCommand", "GetCommand",
                "GetAttributeFactory", "AddProcedure"
            };
            if (forbiddenTokens.Any(token => combined.IndexOf(token, StringComparison.Ordinal) >= 0))
            {
                throw new InvalidOperationException("Step 07 verification source contains a prohibited modifying Cimatron API token.");
            }

            string assemblySource = File.ReadAllText(Path.Combine(toolDirectory, "AssemblyContextVerification.cs"));
            if (assemblySource.IndexOf("previousSelection = selection.Selection", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("selection.Selection = highlightList", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("RestoreSelection(context, previousSelection)", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("restore = (interop.CimMdlrAPI.ICimEntityList)new interop.CimBaseAPI.CimEntityList()", StringComparison.Ordinal) < 0 ||
                assemblySource.IndexOf("selection.Selection = restore", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07 optional highlight must snapshot selection, restore through the guarded helper, and restore an empty list when the original selection was empty.");
            }

            string componentSource = File.ReadAllText(Path.Combine(toolDirectory, "ComponentPropertySourceVerification.cs"));
            if (componentSource.IndexOf("Path.GetTempPath()", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("\"CimatronCustomization\", \"Step07\"", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("bom.Export(stem", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07 BOM export must remain constrained to a new %TEMP%/CimatronCustomization/Step07 folder.");
            }

            if (componentSource.IndexOf("instance.GetAllEntities()", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("FindBodyEntityOnOccurrence", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("sink.GetAttribute(", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("AttributeEnumType.cmAttString", StringComparison.Ordinal) < 0 ||
                componentSource.IndexOf("partModel.GetEntityById(args.EntityId.Value, partModel)", StringComparison.Ordinal) >= 0 ||
                componentSource.IndexOf("string.Equals(attribute.Name, knownAttributeName", StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException("Step 07C-3 known-body verification must use occurrence-reached entity enumeration plus exact named string-attribute lookup, without the failed model GetEntityById path or returned IAttribute.Name equality gate.");
            }

            string hiddenStateSource = File.ReadAllText(Path.Combine(toolDirectory, "HiddenStateCandidateVerification.cs"));
            if (hiddenStateSource.IndexOf("instance.GetAllEntities()", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("visibleEntity.Show", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("context.TryObserve(\"GetBomManager\"", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("BOM.Stage: SKIPPED_AFTER_READ_ERROR", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("BOMMembership.Difference.OnlyInNoFiltering", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("BOMMembership.SemanticsAssignedInCode=FALSE", StringComparison.Ordinal) < 0 ||
                hiddenStateSource.IndexOf("StoppingRule: SINGLE RUN", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Step 07C-4 hidden-state verification must remain getter-only, occurrence/body discriminating, BOM-membership explicit, semantics-neutral, and single-run governed.");
            }

            if (combined.IndexOf("No-mutation evidence: ", StringComparison.Ordinal) < 0 ||
                combined.IndexOf("CHANGED_OR_UNVERIFIED", StringComparison.Ordinal) < 0)
            {
                throw new InvalidOperationException("Every Step 07 live verification mode must retain no-mutation evidence and fail-closed wording.");
            }

            string srcDirectory = Path.Combine(repositoryRoot, "src");
            foreach (string productionProject in Directory.GetFiles(srcDirectory, "*.csproj", SearchOption.AllDirectories))
            {
                if (File.ReadAllText(productionProject).IndexOf("CimatronCustomization.ApiCapabilityVerification", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    throw new InvalidOperationException("Production projects must not reference the Step 07 development-only verification tool: " + productionProject);
                }
            }
        }

        private static int CountOccurrences(string source, string value)
        {
            int count = 0;
            int index = 0;
            while ((index = source.IndexOf(value, index, StringComparison.Ordinal)) >= 0)
            {
                count++;
                index += value.Length;
            }

            return count;
        }

        private static string GetProjectPath(string repositoryRoot, string projectName)
        {
            return Path.Combine(repositoryRoot, "src", projectName, projectName + ".csproj");
        }

        private static string FindRepositoryRoot()
        {
            DirectoryInfo current = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);

            while (current != null)
            {
                if (File.Exists(Path.Combine(current.FullName, "CimatronCustomization.sln")) &&
                    File.Exists(Path.Combine(current.FullName, "AGENTS.md")))
                {
                    return current.FullName;
                }

                current = current.Parent;
            }

            throw new InvalidOperationException("Unable to locate the cimatron-customization repository root.");
        }
    }
}
