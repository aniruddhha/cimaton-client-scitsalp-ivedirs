using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.ArchitectureTests")]
[assembly: AssemblyDescription("Executable architecture boundary tests for CimatronCustomization")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("64f8d52e-ffea-43f0-b94e-c749490f6161")]
[assembly: AssemblyVersion("0.14.10.0")]
[assembly: AssemblyFileVersion("0.14.10.0")]
