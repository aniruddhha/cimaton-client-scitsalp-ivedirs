using System;

namespace CimatronCustomization.ArchitectureTests
{
    internal static class Program
    {
        private static int Main()
        {
            try
            {
                ArchitectureBoundaryTests.RunAll();
                Console.WriteLine("ARCHITECTURE TESTS: PASS");
                return 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("ARCHITECTURE TESTS: FAIL");
                Console.Error.WriteLine(exception.Message);
                return 1;
            }
        }
    }
}
