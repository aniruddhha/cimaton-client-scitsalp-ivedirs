using System;
using System.Collections.Generic;
using CimatronCustomization.CimatronIntegration;

namespace CimatronCustomization.CimatronIntegrationTests
{
    internal static class ViewportPickStateTests
    {
        internal static void RunAll()
        {
            SingleActivePickIsEnforced();
            CompletionReleasesStrongReference();
            CompletionIsAcceptedExactlyOnce();
            SourceDocumentLossRequiresPersistentMismatch();
            CurrentSourceDocumentResetsLossDetection();
            SameSourceModelPidSurvivesManagedWrapperIdentityChanges();
            SameSourceModelPidDoesNotAccumulateLifecycleLoss();
            DifferentActivePartModelDoesNotMatchSourceLifecycleIdentity();
            DocumentTokensAreStablePerObservedDocumentAndDifferentAcrossDocuments();
            StaleResultRejectsEntityIdForDifferentDocumentToken();
        }

        private static void SingleActivePickIsEnforced()
        {
            ViewportPickSessionState state = new ViewportPickSessionState();
            object first = new object();
            object second = new object();

            AssertEqual(true, state.TryBegin(first), "First Pick start");
            AssertEqual(true, state.IsActive, "Pick active");
            AssertEqual(false, state.TryBegin(second), "Second Pick rejected");
            AssertEqual(first, state.GetActiveTool<object>(), "First Pick retained");
        }

        private static void CompletionReleasesStrongReference()
        {
            ViewportPickSessionState state = new ViewportPickSessionState();
            object tool = new object();
            state.TryBegin(tool);
            AssertEqual(true, state.TryComplete(tool), "Pick completion accepted");

            AssertEqual(false, state.IsActive, "Pick inactive after completion");
            AssertEqual(null, state.GetActiveTool<object>(), "Strong tool reference released");
        }

        private static void CompletionIsAcceptedExactlyOnce()
        {
            ViewportPickSessionState state = new ViewportPickSessionState();
            object tool = new object();
            state.TryBegin(tool);

            AssertEqual(true, state.TryComplete(tool), "First completion accepted");
            AssertEqual(false, state.TryComplete(tool), "Late duplicate completion ignored");
            AssertEqual(false, state.IsActive, "Pick remains inactive after duplicate completion");
        }

        private static void SourceDocumentLossRequiresPersistentMismatch()
        {
            ViewportPickSessionState state = new ViewportPickSessionState();
            state.TryBegin(new object());

            AssertEqual(false, state.ShouldCompleteForSourceDocumentLoss(false, 4), "First mismatch");
            AssertEqual(false, state.ShouldCompleteForSourceDocumentLoss(false, 4), "Second mismatch");
            AssertEqual(false, state.ShouldCompleteForSourceDocumentLoss(false, 4), "Third mismatch");
            AssertEqual(true, state.ShouldCompleteForSourceDocumentLoss(false, 4), "Persistent mismatch");
        }

        private static void CurrentSourceDocumentResetsLossDetection()
        {
            ViewportPickSessionState state = new ViewportPickSessionState();
            state.TryBegin(new object());

            state.ShouldCompleteForSourceDocumentLoss(false, 3);
            state.ShouldCompleteForSourceDocumentLoss(false, 3);
            AssertEqual(false, state.ShouldCompleteForSourceDocumentLoss(true, 3), "Current source resets mismatch count");
            AssertEqual(false, state.ShouldCompleteForSourceDocumentLoss(false, 3), "Mismatch count restarted after reset");
            AssertEqual(false, state.ShouldCompleteForSourceDocumentLoss(false, 3), "Second mismatch after reset");
            AssertEqual(true, state.ShouldCompleteForSourceDocumentLoss(false, 3), "Third mismatch after reset");
        }


        private static void SameSourceModelPidSurvivesManagedWrapperIdentityChanges()
        {
            const string sourceModelPid = "stable-part-model-pid";

            AssertEqual(
                true,
                CimatronViewportEntityPicker.SourceDocumentLifecycleMatches(sourceModelPid, "cmPart", "stable-part-model-pid"),
                "Same source model remains current even when GetActiveDoc returns a different managed wrapper");
        }

        private static void SameSourceModelPidDoesNotAccumulateLifecycleLoss()
        {
            ViewportPickSessionState state = new ViewportPickSessionState();
            state.TryBegin(new object());

            for (int i = 0; i < 8; i++)
            {
                bool sameSource = CimatronViewportEntityPicker.SourceDocumentLifecycleMatches(
                    "stable-part-model-pid",
                    "cmPart",
                    "stable-part-model-pid");
                AssertEqual(false, state.ShouldCompleteForSourceDocumentLoss(sameSource, 4), "Stable source probe " + i);
            }
        }

        private static void DifferentActivePartModelDoesNotMatchSourceLifecycleIdentity()
        {
            AssertEqual(
                false,
                CimatronViewportEntityPicker.SourceDocumentLifecycleMatches("source-model-pid", "cmPart", "other-model-pid"),
                "Different active Part model is not the source model");
            AssertEqual(
                false,
                CimatronViewportEntityPicker.SourceDocumentLifecycleMatches("source-model-pid", null, null),
                "No active Part model is not the source model");
        }

        private static void DocumentTokensAreStablePerObservedDocumentAndDifferentAcrossDocuments()
        {
            SessionDocumentIdentityRegistry registry = new SessionDocumentIdentityRegistry();
            object firstDocument = new object();
            object reopenedDocument = new object();

            string firstToken = registry.GetOrCreate(firstDocument);
            string repeatedToken = registry.GetOrCreate(firstDocument);
            string reopenedToken = registry.GetOrCreate(reopenedDocument);

            AssertEqual(firstToken, repeatedToken, "Same observed document token");
            if (string.Equals(firstToken, reopenedToken, StringComparison.Ordinal))
            {
                throw new InvalidOperationException("A newly observed document must receive a new session-scoped token.");
            }
        }


        private static void StaleResultRejectsEntityIdForDifferentDocumentToken()
        {
            CimatronCustomization.Application.ViewportDocumentIdentity source =
                new CimatronCustomization.Application.ViewportDocumentIdentity("source-token", "cmPart", "Part", "");
            CimatronCustomization.Application.ViewportPickResult picked =
                new CimatronCustomization.Application.ViewportPickResult(
                    "correlation",
                    CimatronCustomization.Application.ViewportPickOutcome.Picked,
                    source,
                    48,
                    CimatronCustomization.Application.ViewportEntityType.Face,
                    Array.Empty<string>(),
                    "ENTITY_PICKED",
                    "Picked.");

            CimatronCustomization.Application.ViewportPickResult current =
                ViewportPickResultValidator.ValidateForDocumentToken(picked, "source-token");
            AssertEqual(CimatronCustomization.Application.ViewportPickOutcome.Picked, current.Outcome, "Current result outcome");
            AssertEqual(48, current.EntityId.Value, "Current result entity id");

            CimatronCustomization.Application.ViewportPickResult stale =
                ViewportPickResultValidator.ValidateForDocumentToken(picked, "different-token");
            AssertEqual(CimatronCustomization.Application.ViewportPickOutcome.StaleResult, stale.Outcome, "Stale result outcome");
            AssertEqual(false, stale.EntityId.HasValue, "Stale result entity id removed");
            AssertEqual("SOURCE_DOCUMENT_STALE", stale.ReasonCode, "Stale result reason");
        }

        private static void AssertEqual<T>(T expected, T actual, string scenario)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
            {
                throw new InvalidOperationException(scenario + " expected '" + expected + "' but received '" + actual + "'.");
            }
        }
    }
}
