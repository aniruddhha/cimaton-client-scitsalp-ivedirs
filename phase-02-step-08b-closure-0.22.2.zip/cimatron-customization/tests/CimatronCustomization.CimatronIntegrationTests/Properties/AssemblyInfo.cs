using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.CimatronIntegrationTests")]
[assembly: AssemblyDescription("User-run live Cimatron session boundary diagnostic")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: ComVisible(false)]
[assembly: Guid("ad395a0c-a1cc-42cf-ac64-f910f1d0dc17")]
[assembly: AssemblyVersion("0.14.10.0")]
[assembly: AssemblyFileVersion("0.14.10.0")]
