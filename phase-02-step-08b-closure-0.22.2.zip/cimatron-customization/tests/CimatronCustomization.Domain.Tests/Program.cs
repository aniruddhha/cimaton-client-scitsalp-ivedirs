using System;

namespace CimatronCustomization.Domain.Tests
{
    internal static class Program
    {
        private static int Main()
        {
            try
            {
                ActivePartReadinessValidationTests.RunAll();
                PlatformResultModelTests.RunAll();
                Console.WriteLine("DOMAIN TESTS: PASS");
                return 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("DOMAIN TESTS: FAIL");
                Console.Error.WriteLine(exception);
                return 1;
            }
        }
    }
}
