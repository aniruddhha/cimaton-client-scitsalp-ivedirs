using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.Domain.Tests")]
[assembly: AssemblyDescription("Domain tests for Cimatron Customization")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("f3f33771-deba-4669-a521-6ab6d88203b6")]
[assembly: AssemblyVersion("0.14.10.0")]
[assembly: AssemblyFileVersion("0.14.10.0")]
