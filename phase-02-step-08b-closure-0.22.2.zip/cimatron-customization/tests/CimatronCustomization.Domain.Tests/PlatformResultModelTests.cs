using System;
using System.Collections;
using System.Collections.Generic;

namespace CimatronCustomization.Domain.Tests
{
    internal static class PlatformResultModelTests
    {
        internal static void RunAll()
        {
            ResultStatusIncludesSucceeded();
            GeometryToleranceUsesAbsoluteTolerance();
            GeometryToleranceRejectsInvalidValues();
            DirectionIsNormalized();
            DirectionRejectsInvalidVectors();
            PointStoresCoordinates();
            MeasurementStoresValueAndUnit();
            MeasurementRejectsMissingUnit();
            ModelEntityReferenceStoresValue();
            ModelEntityReferenceRejectsMissingValue();
            FindingStoresAllValues();
            FindingRejectsMissingRequirementId();
            FindingRejectsMissingMessage();
            FindingRejectsUnitMismatch();
            FindingAllowsMatchingUnitsIgnoringCase();
            FindingCollectionExposesItemsAndEnumerators();
            FindingCollectionRejectsNullSource();
            FindingCollectionRejectsNullEntry();
            AggregationReturnsEmptyStatusForEmptyCollection();
            AggregationRejectsNullCollection();
            AggregationRejectsNullEntry();
            AggregationKeepsRuntimeErrorDistinctFromFailed();
            AggregationUsesCanonicalSeverityOrder();
            PassedAndSucceededShareSuccessSeverity();
        }

        private static void ResultStatusIncludesSucceeded()
        {
            if (!Enum.IsDefined(typeof(ResultStatus), ResultStatus.Succeeded))
            {
                throw new InvalidOperationException("Succeeded must be part of the canonical result states.");
            }
        }

        private static void GeometryToleranceUsesAbsoluteTolerance()
        {
            GeometryTolerance tolerance = new GeometryTolerance(0.1d);
            AssertEqual(0.1d, tolerance.Absolute, "Absolute tolerance");
            AssertTrue(tolerance.AreEqual(20.0d, 20.09d), "Inside tolerance");
            AssertFalse(tolerance.AreEqual(20.0d, 20.11d), "Outside tolerance");

            GeometryTolerance zero = new GeometryTolerance(0d);
            AssertTrue(zero.AreEqual(5d, 5d), "Zero tolerance exact equality");
        }

        private static void GeometryToleranceRejectsInvalidValues()
        {
            ExpectException<ArgumentOutOfRangeException>(() => new GeometryTolerance(-0.1d), "Negative tolerance");
            ExpectException<ArgumentOutOfRangeException>(() => new GeometryTolerance(double.NaN), "NaN tolerance");
            ExpectException<ArgumentOutOfRangeException>(() => new GeometryTolerance(double.PositiveInfinity), "Infinite tolerance");
        }

        private static void DirectionIsNormalized()
        {
            Direction3 direction = new Direction3(0d, 3d, 4d);
            double magnitude = Math.Sqrt((direction.X * direction.X) + (direction.Y * direction.Y) + (direction.Z * direction.Z));
            AssertTrue(Math.Abs(magnitude - 1d) <= 0.0000001d, "Direction magnitude");
            AssertEqual(0d, direction.X, "Direction X");
            AssertEqual(0.6d, direction.Y, "Direction Y");
            AssertEqual(0.8d, direction.Z, "Direction Z");
        }

        private static void DirectionRejectsInvalidVectors()
        {
            ExpectException<ArgumentException>(() => new Direction3(0d, 0d, 0d), "Zero direction");
            ExpectException<ArgumentException>(() => new Direction3(double.NaN, 0d, 0d), "NaN direction");
            ExpectException<ArgumentException>(() => new Direction3(double.PositiveInfinity, 0d, 0d), "Infinite direction");
        }

        private static void PointStoresCoordinates()
        {
            Point3 point = new Point3(1d, 2d, 3d);
            AssertEqual(1d, point.X, "Point X");
            AssertEqual(2d, point.Y, "Point Y");
            AssertEqual(3d, point.Z, "Point Z");
        }

        private static void MeasurementStoresValueAndUnit()
        {
            Measurement measurement = new Measurement(12.5d, "mm");
            AssertEqual(12.5d, measurement.Value, "Measurement value");
            AssertEqual("mm", measurement.Unit, "Measurement unit");
        }

        private static void MeasurementRejectsMissingUnit()
        {
            ExpectException<ArgumentException>(() => new Measurement(1d, null), "Null unit");
            ExpectException<ArgumentException>(() => new Measurement(1d, " "), "Blank unit");
        }

        private static void ModelEntityReferenceStoresValue()
        {
            ModelEntityReference reference = new ModelEntityReference("face:42");
            AssertEqual("face:42", reference.Value, "Entity reference");
        }

        private static void ModelEntityReferenceRejectsMissingValue()
        {
            ExpectException<ArgumentException>(() => new ModelEntityReference(null), "Null entity reference");
            ExpectException<ArgumentException>(() => new ModelEntityReference(" "), "Blank entity reference");
        }

        private static void FindingStoresAllValues()
        {
            Measurement measured = new Measurement(10d, "mm");
            Measurement limit = new Measurement(12d, "mm");
            ModelEntityReference entity = new ModelEntityReference("face:1");
            Point3 location = new Point3(1d, 2d, 3d);

            Finding finding = new Finding(
                "CR-TEST",
                ResultStatus.Warning,
                "Check this.",
                measured,
                limit,
                new[] { entity },
                location);

            AssertEqual("CR-TEST", finding.RequirementId, "Finding requirement");
            AssertEqual(ResultStatus.Warning, finding.Status, "Finding status");
            AssertEqual("Check this.", finding.Message, "Finding message");
            AssertSame(measured, finding.MeasuredValue, "Finding measured value");
            AssertSame(limit, finding.Limit, "Finding limit");
            AssertEqual(1, finding.EntityReferences.Count, "Finding entity count");
            AssertSame(entity, finding.EntityReferences[0], "Finding entity");
            AssertTrue(finding.Location.HasValue, "Finding location");
            AssertEqual(2d, finding.Location.Value.Y, "Finding location Y");

            Finding minimal = new Finding("FOUNDATION-X", ResultStatus.Passed, "OK");
            AssertEqual(0, minimal.EntityReferences.Count, "Minimal finding entity count");
            AssertFalse(minimal.Location.HasValue, "Minimal finding location");
            AssertSame(null, minimal.MeasuredValue, "Minimal measured value");
            AssertSame(null, minimal.Limit, "Minimal limit");
        }

        private static void FindingRejectsMissingRequirementId()
        {
            ExpectException<ArgumentException>(() => new Finding(null, ResultStatus.Error, "Message"), "Null requirement id");
            ExpectException<ArgumentException>(() => new Finding(" ", ResultStatus.Error, "Message"), "Blank requirement id");
        }

        private static void FindingRejectsMissingMessage()
        {
            ExpectException<ArgumentException>(() => new Finding("CR-X", ResultStatus.Error, null), "Null finding message");
            ExpectException<ArgumentException>(() => new Finding("CR-X", ResultStatus.Error, " "), "Blank finding message");
        }

        private static void FindingRejectsUnitMismatch()
        {
            ExpectException<ArgumentException>(
                () => new Finding("CR-X", ResultStatus.Failed, "Mismatch", new Measurement(10d, "mm"), new Measurement(1d, "deg")),
                "Finding unit mismatch");
        }

        private static void FindingAllowsMatchingUnitsIgnoringCase()
        {
            Finding finding = new Finding(
                "CR-X",
                ResultStatus.Passed,
                "Units match.",
                new Measurement(10d, "mm"),
                new Measurement(10d, "MM"));

            AssertEqual(ResultStatus.Passed, finding.Status, "Case-insensitive unit match");
        }

        private static void FindingCollectionExposesItemsAndEnumerators()
        {
            Finding first = new Finding("CR-1", ResultStatus.Passed, "First");
            Finding second = new Finding("CR-2", ResultStatus.Warning, "Second");
            FindingCollection collection = new FindingCollection(new[] { first, second });

            AssertEqual(2, collection.Count, "Collection count");
            AssertSame(second, collection[1], "Collection indexer");

            int genericCount = 0;
            foreach (Finding finding in collection)
            {
                AssertTrue(finding != null, "Generic enumerator item");
                genericCount++;
            }
            AssertEqual(2, genericCount, "Generic enumerator count");

            int nongenericCount = 0;
            IEnumerable nongeneric = collection;
            foreach (object finding in nongeneric)
            {
                AssertTrue(finding != null, "Non-generic enumerator item");
                nongenericCount++;
            }
            AssertEqual(2, nongenericCount, "Non-generic enumerator count");
        }

        private static void FindingCollectionRejectsNullSource()
        {
            ExpectException<ArgumentNullException>(() => new FindingCollection(null), "Null finding source");
        }

        private static void FindingCollectionRejectsNullEntry()
        {
            ExpectException<ArgumentException>(
                () => new FindingCollection(new Finding[] { new Finding("CR-1", ResultStatus.Passed, "OK"), null }),
                "Null finding entry");
        }

        private static void AggregationReturnsEmptyStatusForEmptyCollection()
        {
            ResultStatus status = FindingAggregation.Aggregate(Array.Empty<Finding>(), ResultStatus.NotApplicable);
            AssertEqual(ResultStatus.NotApplicable, status, "Empty aggregation status");
        }

        private static void AggregationRejectsNullCollection()
        {
            ExpectException<ArgumentNullException>(
                () => FindingAggregation.Aggregate(null, ResultStatus.Passed),
                "Null aggregation source");
        }

        private static void AggregationRejectsNullEntry()
        {
            ExpectException<ArgumentException>(
                () => FindingAggregation.Aggregate(new Finding[] { null }, ResultStatus.Passed),
                "Null aggregation entry");
        }

        private static void AggregationKeepsRuntimeErrorDistinctFromFailed()
        {
            ResultStatus status = FindingAggregation.Aggregate(new[]
            {
                new Finding("CR-1", ResultStatus.Failed, "Rule failed."),
                new Finding("CR-2", ResultStatus.Error, "Runtime failed.")
            }, ResultStatus.Passed);

            AssertEqual(ResultStatus.Error, status, "Error dominates Failed");
        }

        private static void AggregationUsesCanonicalSeverityOrder()
        {
            AssertAggregate(ResultStatus.Error, ResultStatus.Failed, ResultStatus.Error);
            AssertAggregate(ResultStatus.Failed, ResultStatus.Warning, ResultStatus.Failed);
            AssertAggregate(ResultStatus.Warning, ResultStatus.Unsupported, ResultStatus.Warning);
            AssertAggregate(ResultStatus.Unsupported, ResultStatus.NotApplicable, ResultStatus.Unsupported);
            AssertAggregate(ResultStatus.NotApplicable, ResultStatus.Skipped, ResultStatus.NotApplicable);
            AssertAggregate(ResultStatus.Skipped, ResultStatus.Passed, ResultStatus.Skipped);
        }

        private static void PassedAndSucceededShareSuccessSeverity()
        {
            ResultStatus passed = FindingAggregation.Aggregate(
                new[] { new Finding("CR-1", ResultStatus.Passed, "Passed") },
                ResultStatus.Succeeded);
            AssertEqual(ResultStatus.Succeeded, passed, "Passed does not override Succeeded at equal severity");

            ResultStatus succeeded = FindingAggregation.Aggregate(
                new[] { new Finding("SA-1", ResultStatus.Succeeded, "Succeeded") },
                ResultStatus.Passed);
            AssertEqual(ResultStatus.Passed, succeeded, "Succeeded does not override Passed at equal severity");
        }

        private static void AssertAggregate(ResultStatus lower, ResultStatus higher, ResultStatus expected)
        {
            ResultStatus result = FindingAggregation.Aggregate(new[]
            {
                new Finding("R-1", lower, "Lower"),
                new Finding("R-2", higher, "Higher")
            }, ResultStatus.Passed);

            AssertEqual(expected, result, "Aggregation severity");
        }

        private static void ExpectException<TException>(Func<object> action, string name) where TException : Exception
        {
            try
            {
                GC.KeepAlive(action());
            }
            catch (TException)
            {
                return;
            }

            throw new InvalidOperationException(name + " did not throw " + typeof(TException).Name + ".");
        }

        private static void AssertTrue(bool value, string name)
        {
            if (!value)
            {
                throw new InvalidOperationException(name + " expected true.");
            }
        }

        private static void AssertFalse(bool value, string name)
        {
            if (value)
            {
                throw new InvalidOperationException(name + " expected false.");
            }
        }

        private static void AssertSame(object expected, object actual, string name)
        {
            if (!ReferenceEquals(expected, actual))
            {
                throw new InvalidOperationException(name + " expected the same reference.");
            }
        }

        private static void AssertEqual<T>(T expected, T actual, string name)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
            {
                throw new InvalidOperationException(
                    name + " expected <" + expected + "> but was <" + actual + ">.");
            }
        }
    }
}
