using System;

namespace CimatronCustomization.Domain.Tests
{
    internal static class ActivePartReadinessValidationTests
    {
        internal static void RunAll()
        {
            ApplicationUnavailableReturnsError();
            NoActiveDocumentReturnsNotApplicable();
            NonPartDocumentReturnsUnsupported();
            ActivePartReturnsPassed();
            ResultRejectsBlankMessage();
        }

        private static void ApplicationUnavailableReturnsError()
        {
            ActivePartReadinessResult result = ActivePartReadinessValidation.Evaluate(false, false, false);
            AssertStatus(ResultStatus.Error, result.Status, "Application unavailable");
        }

        private static void NoActiveDocumentReturnsNotApplicable()
        {
            ActivePartReadinessResult result = ActivePartReadinessValidation.Evaluate(true, false, false);
            AssertStatus(ResultStatus.NotApplicable, result.Status, "No active document");
        }

        private static void NonPartDocumentReturnsUnsupported()
        {
            ActivePartReadinessResult result = ActivePartReadinessValidation.Evaluate(true, true, false);
            AssertStatus(ResultStatus.Unsupported, result.Status, "Non-Part active document");
        }

        private static void ActivePartReturnsPassed()
        {
            ActivePartReadinessResult result = ActivePartReadinessValidation.Evaluate(true, true, true);
            AssertStatus(ResultStatus.Passed, result.Status, "Active Part");
        }

        private static void ResultRejectsBlankMessage()
        {
            try
            {
                ActivePartReadinessResult result = new ActivePartReadinessResult(ResultStatus.Passed, " ");
                GC.KeepAlive(result);
            }
            catch (ArgumentException exception) when (exception.ParamName == "message")
            {
                return;
            }

            throw new InvalidOperationException("ActivePartReadinessResult must reject a blank message.");
        }

        private static void AssertStatus(ResultStatus expected, ResultStatus actual, string scenario)
        {
            if (actual != expected)
            {
                throw new InvalidOperationException(
                    scenario + " expected status " + expected + " but received " + actual + ".");
            }
        }
    }
}
