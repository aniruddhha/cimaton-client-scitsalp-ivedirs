# Step 06A requirement-derived fixtures

These files are **temporary known-answer fixtures**, not customer layouts.

The real customer DO Input Sheet and slider-weight/finger-pin table have not been supplied. Their worksheet names, header row positions, and source column headers therefore remain configuration-driven and must not be hard-coded from these fixtures.

- `placeholder-do-input.csv` represents the minimum data shape needed to exercise the future CR-04 steel-grade lookup path.
- `placeholder-finger-pin-weight-table.csv` represents the minimum data shape needed to exercise the future CR-22 weight/diameter lookup path.

CSV is used here only as a human-readable contract fixture. Step 06A does not select or implement a runtime file-reader dependency. The Step 06B dependency decision remains separately approval-gated.
