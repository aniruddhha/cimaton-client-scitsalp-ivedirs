using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("CimatronCustomization.Infrastructure.Tests")]
[assembly: AssemblyProduct("CimatronCustomization.Infrastructure.Tests")]
[assembly: ComVisible(false)]
[assembly: Guid("A7E25C89-4A30-4C38-8CB6-6E8F4E5D1C0C")]
[assembly: AssemblyVersion("0.17.2.0")]
[assembly: AssemblyFileVersion("0.17.2.0")]
