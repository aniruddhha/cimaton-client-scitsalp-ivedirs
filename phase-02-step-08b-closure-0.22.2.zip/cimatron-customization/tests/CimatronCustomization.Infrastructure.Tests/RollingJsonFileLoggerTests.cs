using System;
using System.IO;
using CimatronCustomization.Application;
using CimatronCustomization.Infrastructure;
namespace CimatronCustomization.Infrastructure.Tests
{
    internal static class RollingJsonFileLoggerTests
    {
        public static void RunAll(){WritesStructuredLine();EscapesJsonStringValues();WritesExceptionStackTraceAndDetail();RollsAndRetainsBoundedFiles();}
        private static void WritesStructuredLine(){string d=TempDir();try{var l=new RollingJsonFileLogger(d,10000,3);l.Log(Entry("hello"));string text=File.ReadAllText(Path.Combine(d,"cimatron-customization.log.jsonl"));Assert(text.Contains("\"correlationId\":\"run-1\"")&&text.Contains("\"status\":\"Succeeded\""),"Required structured fields must be written.");}finally{Directory.Delete(d,true);}}

        private static void EscapesJsonStringValues(){string d=TempDir();try{var l=new RollingJsonFileLogger(d,10000,3);l.Log(Entry("quote \" slash \\ newline\n"));string text=File.ReadAllText(Path.Combine(d,"cimatron-customization.log.jsonl"));Assert(text.Contains("quote \\\" slash \\\\ newline\\n"),"JSON string values must be escaped.");}finally{Directory.Delete(d,true);}}
        private static void WritesExceptionStackTraceAndDetail()
        {
            string d=TempDir();
            try
            {
                var l=new RollingJsonFileLogger(d,10000,3);
                Exception captured=null;
                try { ThrowLoggerTestException(); }
                catch(InvalidOperationException ex) { captured=ex; }

                l.Log(new ApplicationLogEntry(
                    DateTimeOffset.UtcNow,"Error","run-ex","0.14.10","2026.0",
                    "Model Inspection Probe","FOUNDATION-MODEL-INSPECTION-PROBE",
                    "ExecuteRegisteredFeature","Error",1,"logger-test",captured));

                string text=File.ReadAllText(Path.Combine(d,"cimatron-customization.log.jsonl"));
                Assert(text.Contains("\"exceptionType\":\"System.InvalidOperationException\""),"Exception type must be written.");
                Assert(text.Contains("\"exceptionMessage\":\"logger-test\""),"Exception message must be written.");
                Assert(text.Contains("\"exceptionStackTrace\":"),"Exception stack trace field must be written.");
                Assert(text.Contains("ThrowLoggerTestException"),"Stack trace must contain the throwing method.");
                Assert(text.Contains("\"exceptionDetail\":"),"Exception detail field must be written.");
                Assert(text.Contains("System.InvalidOperationException: logger-test"),"Exception.ToString detail must be written.");
            }
            finally { Directory.Delete(d,true); }
        }

        private static void ThrowLoggerTestException(){throw new InvalidOperationException("logger-test");}

        private static void RollsAndRetainsBoundedFiles(){string d=TempDir();try{var l=new RollingJsonFileLogger(d,250,20);for(int i=0;i<40;i++)l.Log(Entry(new string('x',120)));string[] files=Directory.GetFiles(d,"cimatron-customization*.log.jsonl");Assert(files.Length>2,"Rapid writes must create multiple rolled files without collisions.");var bounded=new RollingJsonFileLogger(d,250,2);for(int i=0;i<8;i++)bounded.Log(Entry(new string('x',120)));Assert(Directory.GetFiles(d,"cimatron-customization*.log.jsonl").Length<=2,"Retention must be bounded.");}finally{Directory.Delete(d,true);}}
        private static ApplicationLogEntry Entry(string m)=>new ApplicationLogEntry(DateTimeOffset.UtcNow,"Information","run-1","0.9.1","2026.0","StartupDiagnostics","","Test","Succeeded",1,m);
        private static string TempDir(){string p=Path.Combine(Path.GetTempPath(),"CimatronCustomizationTests",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(p);return p;}
        private static void Assert(bool c,string m){if(!c)throw new InvalidOperationException(m);}
    }
}
