using System;
using System.IO;
using CimatronCustomization.Infrastructure;
namespace CimatronCustomization.Infrastructure.Tests
{
    internal static class StartupConfigurationTests
    {
        public static void RunAll() { LoadsAndMigratesSchema1Configuration(); RejectsUnsupportedSchema(); RejectsMissingFile(); }
        private static void LoadsAndMigratesSchema1Configuration()
        {
            string p=Temp("<cimatronCustomization schemaVersion=\"1\"><logging directory=\"logs\" maximumFileBytes=\"1000\" retainedFileCount=\"3\" /></cimatronCustomization>");
            try { var c=new XmlStartupConfigurationProvider(p).Load(); Assert(c.SchemaVersion==2 && c.MaximumLogFileBytes==1000 && c.RetainedLogFileCount==3,"Schema 1 config should migrate in memory to schema 2 and preserve logging."); } finally { File.Delete(p); }
        }
        private static void RejectsUnsupportedSchema()
        {
            string p=Temp("<cimatronCustomization schemaVersion=\"3\"><logging directory=\"logs\" maximumFileBytes=\"1000\" retainedFileCount=\"3\" /></cimatronCustomization>"); bool threw=false;
            try { new XmlStartupConfigurationProvider(p).Load(); } catch(InvalidDataException){threw=true;} finally{File.Delete(p);} Assert(threw,"Unsupported schema must fail.");
        }
        private static void RejectsMissingFile(){ bool threw=false; try{new XmlStartupConfigurationProvider(Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xml")).Load();}catch(FileNotFoundException){threw=true;} Assert(threw,"Missing config must fail."); }
        private static string Temp(string c){string p=Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xml");File.WriteAllText(p,c);return p;}
        private static void Assert(bool c,string m){if(!c)throw new InvalidOperationException(m);}
    }
}
