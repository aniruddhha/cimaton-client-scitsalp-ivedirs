using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomization.Infrastructure.Tests
{
    internal static class ExcelTabularDataReaderTests
    {
        public static void RunAll()
        {
            ReadsCsvWithConfiguredHeadersAndTypedValues();
            ReadsOpenXmlWorkbookFromConfiguredWorksheet();
            ReadsLegacyBiff8Workbook();
            ReturnsActionableErrorForMissingWorksheet();
            ReturnsActionableErrorForMissingColumn();
            ReturnsActionableErrorForInvalidDecimal();
            ReturnsActionableErrorForRowLimit();
            ReturnsActionableErrorForOversizeFile();
            DiscoversHeadersWithSameSizeLimit();
            RejectsChangedHeadersBetweenDiscoveryAndRead();
        }

        private static void ReadsCsvWithConfiguredHeadersAndTypedValues()
        {
            string path = CreateTemporaryFile(".csv", "Part,Steel Grade,Weight\r\nBlock_A,1.2344,12.5\r\n");
            try
            {
                TabularReadResult result = new ExcelTabularDataReader().Read(CreateSource(path, "IgnoredForCsv", 1));
                Assert(result.IsSuccess, "CSV read should succeed.");
                Assert(result.Table.Rows.Count == 1, "CSV should contain one logical row.");
                Assert(result.Table.Rows[0].GetRequired("SteelGrade").TextValue == "1.2344", "Text value mismatch.");
                Assert(result.Table.Rows[0].GetRequired("Weight").DecimalValue == 12.5m, "Decimal value mismatch.");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void ReadsOpenXmlWorkbookFromConfiguredWorksheet()
        {
            string path = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + ".xlsx");
            CreateMinimalXlsx(path);
            try
            {
                TabularReadResult result = new ExcelTabularDataReader().Read(CreateSource(path, "Input", 1));
                Assert(result.IsSuccess, "XLSX read should succeed.");
                Assert(result.Table.Rows.Count == 1, "XLSX should contain one logical row.");
                Assert(result.Table.Rows[0].GetRequired("Weight").DecimalValue == 12.5m, "XLSX decimal mismatch.");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void ReadsLegacyBiff8Workbook()
        {
            string fixturePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TestData", "Step06", "LegacyInput.xls");
            Assert(File.Exists(fixturePath), "Legacy XLS/BIFF8 fixture should be copied to the test output directory.");

            TabularReadResult result = new ExcelTabularDataReader().Read(CreateSource(fixturePath, "Input", 1));
            Assert(result.IsSuccess, "Legacy XLS/BIFF8 read should succeed.");
            Assert(result.Table.Rows.Count == 1, "Legacy XLS should contain one logical row.");
            Assert(result.Table.Rows[0].GetRequired("SteelGrade").TextValue == "1.2344", "Legacy XLS text mismatch.");
            Assert(result.Table.Rows[0].GetRequired("Weight").DecimalValue == 12.5m, "Legacy XLS decimal mismatch.");
        }

        private static void ReturnsActionableErrorForMissingWorksheet()
        {
            string path = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + ".xlsx");
            CreateMinimalXlsx(path);
            try
            {
                TabularReadResult result = new ExcelTabularDataReader().Read(CreateSource(path, "Missing", 1));
                AssertError(result, "TABULAR_WORKSHEET_NOT_FOUND");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void ReturnsActionableErrorForMissingColumn()
        {
            string path = CreateTemporaryFile(".csv", "Part,Steel Grade\r\nBlock_A,1.2344\r\n");
            try
            {
                TabularReadResult result = new ExcelTabularDataReader().Read(CreateSource(path, "IgnoredForCsv", 1));
                AssertError(result, "TABULAR_COLUMN_NOT_FOUND");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void ReturnsActionableErrorForInvalidDecimal()
        {
            string path = CreateTemporaryFile(".csv", "Part,Steel Grade,Weight\r\nBlock_A,1.2344,not-a-number\r\n");
            try
            {
                TabularReadResult result = new ExcelTabularDataReader().Read(CreateSource(path, "IgnoredForCsv", 1));
                AssertError(result, "TABULAR_VALUE_INVALID");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void ReturnsActionableErrorForRowLimit()
        {
            string path = CreateTemporaryFile(".csv", "Part,Steel Grade,Weight\r\nA,S1,1\r\nB,S2,2\r\n");
            try
            {
                TabularReadResult result = new ExcelTabularDataReader(1024 * 1024, 1).Read(CreateSource(path, "IgnoredForCsv", 1));
                AssertError(result, "TABULAR_ROW_LIMIT_EXCEEDED");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void ReturnsActionableErrorForOversizeFile()
        {
            string path = CreateTemporaryFile(".csv", "Part,Steel Grade,Weight\r\nA,S1,1\r\n");
            try
            {
                TabularReadResult result = new ExcelTabularDataReader(1, 100).Read(CreateSource(path, "IgnoredForCsv", 1));
                AssertError(result, "TABULAR_FILE_TOO_LARGE");
            }
            finally
            {
                File.Delete(path);
            }
        }


        private static void DiscoversHeadersWithSameSizeLimit()
        {
            string path = CreateTemporaryFile(".csv", "Part,Steel Grade,Weight\r\nA,S1,1\r\n");
            try
            {
                ExcelTabularDataReader reader = new ExcelTabularDataReader(1, 100);
                TabularHeaderDiscoveryResult result = reader.DiscoverHeaders(new TabularHeaderSourceDefinition(path, "IgnoredForCsv", 1));
                Assert(!result.IsSuccess, "Oversize discovery should fail.");
                Assert(result.ErrorCode == "TABULAR_FILE_TOO_LARGE", "Discovery should use the same file-size limit as row reading.");
                Assert(result.Headers.Count == 0, "Failed discovery must not expose a partial header snapshot.");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static void RejectsChangedHeadersBetweenDiscoveryAndRead()
        {
            string path = CreateTemporaryFile(".csv", "Part,Steel Grade,Weight\r\nA,S1,1\r\n");
            try
            {
                ExcelTabularDataReader reader = new ExcelTabularDataReader();
                TabularHeaderDiscoveryResult discovery = reader.DiscoverHeaders(new TabularHeaderSourceDefinition(path, "IgnoredForCsv", 1));
                Assert(discovery.IsSuccess, "Initial header discovery should succeed.");

                File.WriteAllText(path, "Part,Material Grade,Weight\r\nA,S1,1\r\n", new UTF8Encoding(false));
                TabularReadResult read = reader.Read(CreateSource(path, "IgnoredForCsv", 1), discovery.Headers);

                AssertError(read, "TABULAR_HEADERS_CHANGED");
            }
            finally
            {
                File.Delete(path);
            }
        }

        private static TabularSourceDefinition CreateSource(string path, string worksheetName, int headerRowNumber)
        {
            return new TabularSourceDefinition(
                path,
                worksheetName,
                headerRowNumber,
                new[]
                {
                    new TabularColumnDefinition("Part", "Part", TabularValueType.Text, true),
                    new TabularColumnDefinition("SteelGrade", "Steel Grade", TabularValueType.Text, true),
                    new TabularColumnDefinition("Weight", "Weight", TabularValueType.Decimal, true)
                });
        }

        private static string CreateTemporaryFile(string extension, string content)
        {
            string path = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + extension);
            File.WriteAllText(path, content, new UTF8Encoding(false));
            return path;
        }

        private static void CreateMinimalXlsx(string path)
        {
            using (FileStream stream = File.Create(path))
            using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Create))
            {
                WriteEntry(archive, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
                WriteEntry(archive, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
                WriteEntry(archive, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Input\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
                WriteEntry(archive, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
                WriteEntry(archive, "xl/worksheets/sheet1.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData><row r=\"1\"><c r=\"A1\" t=\"inlineStr\"><is><t>Part</t></is></c><c r=\"B1\" t=\"inlineStr\"><is><t>Steel Grade</t></is></c><c r=\"C1\" t=\"inlineStr\"><is><t>Weight</t></is></c></row><row r=\"2\"><c r=\"A2\" t=\"inlineStr\"><is><t>Block_A</t></is></c><c r=\"B2\" t=\"inlineStr\"><is><t>1.2344</t></is></c><c r=\"C2\"><v>12.5</v></c></row></sheetData></worksheet>");
            }
        }

        private static void WriteEntry(ZipArchive archive, string name, string content)
        {
            ZipArchiveEntry entry = archive.CreateEntry(name);
            using (StreamWriter writer = new StreamWriter(entry.Open(), new UTF8Encoding(false)))
                writer.Write(content);
        }

        private static void AssertError(TabularReadResult result, string expectedCode)
        {
            Assert(!result.IsSuccess, "Expected tabular read error.");
            Assert(result.Table == null, "Error result must not contain a partial table.");
            Assert(result.ErrorCode == expectedCode, "Expected error code " + expectedCode + " but received " + result.ErrorCode + ".");
            Assert(!string.IsNullOrWhiteSpace(result.ErrorMessage), "Error message must be actionable.");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
