using System;
using System.IO;
using CimatronCustomization.Application;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomization.Infrastructure.Tests
{
    internal static class RuleParameterConfigurationTests
    {
        private static readonly string[] FoundationRequirements = { "FOUNDATION-TEST" };

        internal static void RunAll()
        {
            Schema1MigratesInMemoryToSchema2();
            Schema2LoadsLoggingSettings();
            LoadsAllSupportedParameterTypes();
            MissingRequiredParameterNamesParameterAndFile();
            InvalidNumberNamesParameterAndFile();
            OutOfRangeValueIsRejected();
            InvalidColorCodeIsRejected();
            DuplicateParameterIsRejected();
            OptionalMissingParameterIsAllowed();
            MissingFeatureFailsWhenRequiredParameterExists();
        }

        private static void Schema1MigratesInMemoryToSchema2()
        {
            string path = Temp("<cimatronCustomization schemaVersion=\"1\"><logging directory=\"logs\" maximumFileBytes=\"1000\" retainedFileCount=\"3\" /></cimatronCustomization>");
            try { StartupConfigurationSnapshot c = new XmlStartupConfigurationProvider(path).Load(); AssertEqual(2, c.SchemaVersion, "Migrated schema"); } finally { File.Delete(path); }
        }

        private static void Schema2LoadsLoggingSettings()
        {
            string path = Temp("<cimatronCustomization schemaVersion=\"2\"><logging directory=\"logs\" maximumFileBytes=\"1000\" retainedFileCount=\"3\" /><features /></cimatronCustomization>");
            try { StartupConfigurationSnapshot c = new XmlStartupConfigurationProvider(path).Load(); AssertEqual(2, c.SchemaVersion, "Schema2"); AssertEqual(1000L, c.MaximumLogFileBytes, "Logging preserved"); } finally { File.Delete(path); }
        }

        private static void LoadsAllSupportedParameterTypes()
        {
            FeatureDefinition f = Feature(new[] {
                new RuleParameterDefinition("S", RuleParameterType.String, "", null, null, true),
                new RuleParameterDefinition("I", RuleParameterType.Integer, "count", 1m, 10m, true),
                new RuleParameterDefinition("D", RuleParameterType.Decimal, "mm", 0m, 10m, true),
                new RuleParameterDefinition("B", RuleParameterType.Boolean, "", null, null, true),
                new RuleParameterDefinition("C", RuleParameterType.ColorCode, "", null, null, true)});
            string path = Temp(Config("<parameter name=\"S\" value=\"abc\"/><parameter name=\"I\" value=\"3\"/><parameter name=\"D\" value=\"2.5\"/><parameter name=\"B\" value=\"true\"/><parameter name=\"C\" value=\"#A1B2C3\"/>"));
            try { RuleParameterSet set = new XmlRuleParameterProvider(path).LoadFor(f); AssertEqual("abc", set.GetRequired("S").AsString(), "String"); AssertEqual(3, set.GetRequired("I").AsInteger(), "Integer"); AssertEqual(2.5m, set.GetRequired("D").AsDecimal(), "Decimal"); AssertEqual(true, set.GetRequired("B").AsBoolean(), "Boolean"); AssertEqual("#A1B2C3", set.GetRequired("C").AsString(), "Color"); } finally { File.Delete(path); }
        }

        private static void MissingRequiredParameterNamesParameterAndFile()
        {
            FeatureDefinition f = Feature(new[] { new RuleParameterDefinition("RequiredX", RuleParameterType.Decimal, "mm", null, null, true) }); string path = Temp(Config(""));
            try { ExpectInvalidData(path, () => new XmlRuleParameterProvider(path).LoadFor(f), "RequiredX"); } finally { File.Delete(path); }
        }
        private static void InvalidNumberNamesParameterAndFile()
        {
            FeatureDefinition f = Feature(new[] { new RuleParameterDefinition("Number", RuleParameterType.Decimal, "mm", null, null, true) }); string path = Temp(Config("<parameter name=\"Number\" value=\"abc\"/>"));
            try { ExpectInvalidData(path, () => new XmlRuleParameterProvider(path).LoadFor(f), "Number"); } finally { File.Delete(path); }
        }
        private static void OutOfRangeValueIsRejected()
        {
            FeatureDefinition f = Feature(new[] { new RuleParameterDefinition("Number", RuleParameterType.Integer, "", 1m, 5m, true) }); string path = Temp(Config("<parameter name=\"Number\" value=\"6\"/>"));
            try { ExpectInvalidData(path, () => new XmlRuleParameterProvider(path).LoadFor(f), "Number"); } finally { File.Delete(path); }
        }
        private static void InvalidColorCodeIsRejected()
        {
            FeatureDefinition f = Feature(new[] { new RuleParameterDefinition("Color", RuleParameterType.ColorCode, "", null, null, true) }); string path = Temp(Config("<parameter name=\"Color\" value=\"red\"/>"));
            try { ExpectInvalidData(path, () => new XmlRuleParameterProvider(path).LoadFor(f), "Color"); } finally { File.Delete(path); }
        }
        private static void DuplicateParameterIsRejected()
        {
            FeatureDefinition f = Feature(new[] { new RuleParameterDefinition("Number", RuleParameterType.Integer, "", null, null, true) }); string path = Temp(Config("<parameter name=\"Number\" value=\"1\"/><parameter name=\"number\" value=\"2\"/>"));
            try { ExpectInvalidData(path, () => new XmlRuleParameterProvider(path).LoadFor(f), "Number"); } finally { File.Delete(path); }
        }
        private static void OptionalMissingParameterIsAllowed()
        {
            FeatureDefinition f = Feature(new[] { new RuleParameterDefinition("Optional", RuleParameterType.String, "", null, null, false) }); string path = Temp(Config(""));
            try { AssertEqual(0, new XmlRuleParameterProvider(path).LoadFor(f).Count, "Optional missing"); } finally { File.Delete(path); }
        }
        private static void MissingFeatureFailsWhenRequiredParameterExists()
        {
            FeatureDefinition f = Feature(new[] { new RuleParameterDefinition("X", RuleParameterType.String, "", null, null, true) }); string path = Temp("<cimatronCustomization schemaVersion=\"2\"><logging directory=\"logs\" maximumFileBytes=\"1000\" retainedFileCount=\"3\"/><features/></cimatronCustomization>");
            try { ExpectInvalidData(path, () => new XmlRuleParameterProvider(path).LoadFor(f), "X"); } finally { File.Delete(path); }
        }

        private static FeatureDefinition Feature(RuleParameterDefinition[] parameters) { return new FeatureDefinition("FOUNDATION-TEST", "Test", FeatureKind.Validation, FoundationRequirements, "Foundation", DocumentContextRequirement.Either, true, new FeatureTraceability("d","a","i","o","dep","None","config","fail","tests","0.13.0","none"), parameters); }
        private static string Config(string parameters) { return "<cimatronCustomization schemaVersion=\"2\"><logging directory=\"logs\" maximumFileBytes=\"1000\" retainedFileCount=\"3\"/><features><feature id=\"FOUNDATION-TEST\"><parameters>" + parameters + "</parameters></feature></features></cimatronCustomization>"; }
        private static string Temp(string content) { string p = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N") + ".xml"); File.WriteAllText(p, content); return p; }
        private static void ExpectInvalidData(string path, Action action, string parameter) { try { action(); } catch (InvalidDataException e) { Assert(e.Message.Contains(parameter), "Error names parameter"); Assert(e.Message.Contains(path), "Error names config file"); return; } throw new InvalidOperationException("Expected InvalidDataException"); }
        private static void Assert(bool c, string m) { if (!c) throw new InvalidOperationException(m); }
        private static void AssertEqual<T>(T e, T a, string n) { if (!object.Equals(e,a)) throw new InvalidOperationException(n + " expected '" + e + "' but got '" + a + "'."); }
    }
}
