using System;
namespace CimatronCustomization.Infrastructure.Tests
{
    internal static class Program
    {
        private static int Main()
        {
            try { StartupConfigurationTests.RunAll(); RuleParameterConfigurationTests.RunAll(); RollingJsonFileLoggerTests.RunAll(); ExcelTabularDataReaderTests.RunAll(); Console.WriteLine("INFRASTRUCTURE TESTS: PASS"); return 0; }
            catch (Exception exception) { Console.Error.WriteLine("INFRASTRUCTURE TESTS: FAIL"); Console.Error.WriteLine(exception); return 1; }
        }
    }
}
