## 0.22.2 — 2026-10-02 — Step 08B Closure / User Validation

- Records clean user workstation quality gate `quality-gate-20261002-131500.txt`: Release x64 PASS, 0 warnings / 0 errors, Architecture/Domain/Application/CimatronIntegration/Infrastructure tests PASS, coverage/local gates PASS, exit code 0.
- Records the successful governed 0.22.1 live `KA-ASM-1` rerun: U8 occurrence structure PASS; U13 nested body resolution and exact named attribute PASS; U7 `GetAssemblyEntity` mapping PASS; U15 `cmNoFiltering` BOM export/readback PASS with exactly one target `Standard Number=KA-PART-1` row and `Material=1.2738`; programmatic no-mutation PASS; Step08B temp cleanup PASS.
- Records production Result Report Highlight validation for U12: user clicked `Highlight` on the nested-reference finding, visually confirmed the intended nested `KA-PART-1` body highlighted, then confirmed highlight restoration after closing and that `KA-ASM-1` remained unmodified.
- Promotes U7, U8, U12 and U13 to **IN-PROCESS VERIFIED** for the approved Assembly-context scope.
- Promotes U15 to **IN-PROCESS VERIFIED for the approved `cmNoFiltering` material-read scope only**. `cmVisibleOnly` visibility-filter semantics are not newly promoted by this step and remain governed by their existing Step 07 evidence / later Step 08 needs.
- Retains `IAssInstance.GetAllEntities()` classification as installed-Interop + governed runtime evidence only because no authoritative SDK documentation-index entry was found.
- Retains the earlier 0.22.0 U15 `READ_ERROR` and the 0.22.1 target-row corrective for audit traceability.
- Documentation/evidence closure only: no production `src/**`, Plugin behavior, configuration, installer, model, CR-04 logic, or production assembly metadata changed from 0.22.1.
- DF-05 remains active: the developer-visible Step 08B diagnostic must be gated/removed before D5 client packaging.
- Status: **STEP 08B CLOSED / USER VALIDATED**.

## 0.22.1 — 2026-10-02 — Step 08B U15 Target-Row Material Corrective

- User workstation `quality-gate-20261002-124744.txt` is retained as clean 0.22.0 evidence: Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gate PASS, exit code 0.
- First governed 0.22.0 live Step 08B run stopped on U15 as required: U8/U13/U7 PASS; U12 nested highlight reference was prepared but no Highlight action was executed; U15 returned `READ_ERROR TABULAR_REQUIRED_VALUE_MISSING` at a non-target BOM row; no-mutation and temporary-run-directory cleanup PASS.
- Root cause is in `CimatronBomMaterialExporter`: the existing validated `ITabularDataReader` was configured with `Material` required for every BOM row, so an unrelated row with blank Material blocked lookup of `Standard Number=KA-PART-1`.
- Corrected only U15 readback semantics: `Standard Number` remains required; `Material` is optional while parsing unrelated rows; after locating a target `KA-PART-1` row, Material is mandatory for that target row and missing/blank target Material becomes explicit `READ_ERROR`.
- Preserved `IBOM.Export(... cmNoFiltering ...)`, locked Step 07 BOM header, existing `ITabularDataReader`, governed `%TEMP%\CimatronCustomization\Step08B\<timestamp>\` cleanup, programmatic no-mutation guards, and all U8/U13/U7/U12 logic.
- Added focused Application-result coverage for the target-row missing-material error path and strengthened architecture guards so the adapter cannot regress to globally-required Material semantics.
- Added the supplied clean quality-gate capture and first-run live Result Report screenshot to cumulative evidence.
- No CR-04 business logic, alternate API/filter/path, unrelated refactor, or new Cimatron behavior was introduced. Production `AssemblyInfo.cs` metadata remains `0.22.0.0` because it was outside the specifically approved 0.22.1 corrective file list.
- Agent did not build/test/run Cimatron. Validation: **AWAITING USER CLEAN QUALITY GATE, THEN SEPARATELY GOVERNED LIVE RERUN**.

## 0.22.0 — 2026-10-02 — Step 08B Component Property / Assembly Context In-Process Confirmation

- Adds capability-named Application ports/results for nested occurrence attribute read, assembly-entity mapping, and governed BOM material export/readback.
- Adds CimatronIntegration adapters for U8/U13, U7, and U15 using the approved known-answer routes. `IAssInstance.GetAllEntities()` is explicitly treated as installed-Interop/runtime-evidence only; no official SDK index entry was found.
- Extends the production viewport highlighter so a nested occurrence reference can be resolved, mapped with `IAssemblyModel.GetAssemblyEntity`, and highlighted through the existing verified `ISelection.Selection` path.
- Adds the Assembly-only `Step 08B Component Property / Assembly Context Confirmation` foundation feature. The feature carries the nested U12 reference to the normal Result Report; it shows no UI and performs no pause itself.
- Locks U8 known answers to 3 total `KA-PART-1` occurrences, 2 top-level via model lookup, and 1 nested via recursive `SubInstances`; IDs remain runtime evidence only.
- Locks U13 to nested body ID 4 / `cmBody` and exact named `cmAttString` value `KNOWN_ANSWER_07C3`; returned `IAttribute.Name` is not a match condition.
- Locks U15 to `cmNoFiltering`, the Step 07 CSV header contract (`Standard Number` + `Material` included), and `KA-PART-1` material `1.2738`, parsed through the existing `ITabularDataReader`.
- BOM export is constrained to `%TEMP%\CimatronCustomization\Step08B\<timestamp>\`; cleanup failure is Warning, and `GetBomManager`/export COM failures become `READ_ERROR` feature evidence rather than crashes.
- Adds programmatic no-mutation evidence (document modified-state + model file timestamp/length + model-folder listing around BOM export).
- Adds Application fake-port tests, custom test-runner registration, and architecture guards preventing regression to the failed U13 `GetEntityById` route / returned-name equality gate and guarding the nested production highlight/BOM boundaries.
- Registers the diagnostic in the existing Plugin composition root using the validated `ExcelTabularDataReader`.
- Aligns Application, CimatronIntegration, DesignChecks and Plugin assembly/file metadata to `0.22.0.0`.
- DF-05 remains explicit: this developer-visible foundation diagnostic must be gated/removed before D5 client packaging.
- No CR-04 business logic, customer configuration, installer change, or model-writing behavior is introduced.
- Agent did not build/test/run Cimatron; validation is awaiting the user workstation quality gate and the single governed live run.

## 0.21.4 — 2026-10-01 — Step 08A U1 In-Process Confirmation Closure

- Records clean user workstation quality gate `quality-gate-20261001-023742.txt`: Release x64 PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records final controlled live Plugin validation against `KA-PART-1`: Volume, Center, Surface Area and no-mutation all PASS against the locked Step 07 known answer.
- Promotes U1 from Step-07-only VERIFIED / Step-08A open to **IN-PROCESS VERIFIED** for the approved Part-context scope.
- Retains both the earlier zero-value diagnostic observation and the later successful governed rerun; no unsupported explanation is invented and no runtime correction is introduced in this closure package.
- Updates capability register, implementation history, session handoff, time ledger, retained evidence, version and checksums only.
- Step 08A is **CLOSED / USER VALIDATED**. Step 08B is not started.
- No production source, Plugin runtime behavior, configuration, installer, CR/SA behavior, or model data changed in 0.21.4.

# Changelog

## 0.21.3 — Phase 02 Step 08A Quality-Gate CA1861 Corrective

- Records user workstation quality gate `quality-gate-20261001-023056.txt`: Release x64 build PASS, governed tests PASS, coverage gate PASS, local quality gate PASS and exit code 0, but **1 warning / 0 errors**.
- The warning is Roslyn analyzer `CA1861` in `U1InProcessGeometryConfirmationTests.DiagnosticEvidenceIsSurfacedAsWarning`, caused by an inline constant string-array argument.
- Corrects only that test fixture by moving the sample diagnostic evidence to a reusable `static readonly string[]`.
- Does not change `CimatronBodyGeometryMetricsReader`, U1 validation logic, Plugin behavior, known-answer values, CR/SA logic, configuration, installer or model state.
- Production assembly/file versions remain `0.21.2.0`; this corrective does not touch production assembly metadata.
- Live Cimatron diagnostic execution remains blocked until the user supplies a clean 0-warning quality gate.
- Agent did not execute build/tests/Cimatron.


## 0.21.2 — Phase 02 Step 08A U1 In-Process Path Diagnostic

- Records clean user workstation quality gate `quality-gate-20261001-015904.txt`: Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gates PASS, exit code 0.
- Records the first controlled live Plugin result: U1 volume, center, and surface-area comparisons failed; no-mutation evidence passed. Step 08A remains open and U1 is not IN-PROCESS VERIFIED.
- Adds read-only side-by-side diagnostic evidence in `CimatronBodyGeometryMetricsReader`: current `GetEntityById` path versus the exact Step 07 entity-type enumeration/list-construction path.
- Surfaces three diagnostic Warning rows in the existing Result Report: context/entity resolution, current-path raw values, and Step-07-equivalent enumeration/raw values.
- Does **not** switch production behavior to the alternate path and does not change the locked U1 known-answer values.
- Adds a focused Application test proving diagnostic evidence is surfaced without being mistaken for a pass.
- Aligns the four Step 08A production assembly metadata files to `0.21.2.0`; metadata only.
- Carries the clean quality-gate capture and live-failure screenshot as package evidence.
- No CR/SA implementation, configuration, installer, or model mutation. Agent did not execute build/tests/Cimatron.

## 0.21.1 — Phase 02 Step 08A Quality-Gate Warning Corrective

- Records user workstation quality gate `quality-gate-20261001-015133.txt`: Release x64 build PASS, governed tests PASS, coverage gate PASS, local quality gate PASS, exit code 0, but **1 warning / 0 errors**.
- The single warning is Roslyn analyzer `CA1806` in `U1InProcessGeometryConfirmationTests.ConstructorAndContextGuards`, caused by intentionally constructing the feature only to assert the null-reader guard.
- Corrects only that test expression by retaining the constructed value with `GC.KeepAlive`; no Application, CimatronIntegration, DesignChecks, Plugin, CR/SA, configuration, installer, or Cimatron runtime behavior changes.
- Carries the supplied quality-gate capture into `artifacts/console-captures/` and updates Step 08A history/handoff/time records.
- U1 remains **NOT IN-PROCESS VERIFIED** until the user supplies a clean 0-warning quality gate and controlled live Plugin evidence.
- Agent did not execute build/tests/Cimatron.

## 0.21.0 — Phase 02 Step 08A U1 In-Process Confirmation Foundation

- Closed the approved Step 07D register gate using user-supplied workstation quality-gate evidence (`quality-gate-20261001-013106.txt`) and explicit whitelist approval.
- Added `IBodyGeometryMetricsReader` and `BodyGeometryMetricsSnapshot` to the Application boundary.
- Added read-only `CimatronBodyGeometryMetricsReader` using the already Step-07-verified Cimatron 2026 U1 path: `IMdlrModel.GetGeomServicesObj` plus `IGeomServices.BodiesVolume`, `BodiesCenter`, and `BodiesSurfArea`.
- Added `U1InProcessGeometryConfirmationFeature`, restricted to saved `KA-PART-1` body ID `4` and the locked Step 07 B1 known-answer values.
- Added explicit no-mutation verification using document modified-state plus saved-file timestamp/length before and after the U1 read.
- Registered the foundation diagnostic in the existing Plugin composition root.
- Added fake-port Application tests for matching values, mismatch behavior, unsupported input, no-mutation failure, and guard clauses.
- Under separately approved metadata-only scope, aligned Application, CimatronIntegration, DesignChecks, and Plugin AssemblyVersion/AssemblyFileVersion to `0.21.0.0`.
- No CR/SA business rule was implemented. No other Step 08 capability was promoted.
- Agent did not execute build/tests/Cimatron; status remains awaiting user quality gate and live in-process validation.

## 0.20.26 — 2026-09-30 — Step 07C-4 BOM Read-Error Corrective

- Records user workstation 0.20.25 quality-gate PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records the corrected-model live evidence proving `ICimEntity.Show` is a body/entity visibility signal: the hidden body returned `Show.GET=0`, while visible bodies and hidden occurrence `Known_Pocket_Body` returned `Show.GET=1`.
- Records `GetBomManager()` COM `E_FAIL` on the corrected model, which prevented re-confirming the `cmVisibleOnly` occurrence route.
- Changes only the development verifier so `GetBomManager()` is observed with `TryObserve`; a read error is recorded and the run continues to semantics-neutral status plus no-mutation evidence instead of aborting.
- Adds an architecture source-contract guard for the non-fatal BOM-read path.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer, or model behavior changed.
- Validation: **AWAITING USER 0.20.26 QUALITY GATE + CONTROLLED LIVE RETRY**. No 0.20.26 PASS claimed.

## 0.20.25 — 2026-09-30 — Step 07C-4 U16 Hidden-State Verification Preparation

- Starts the explicitly approved Step 07C-4 U16 verification using the finalized copy model `KA-ASM-1-U16-HiddenBody-Control`.
- Keeps `ICimEntity.Show` getter-only and records retained 07A getter evidence in the live diagnostic output.
- Changes the development-only hidden-state verifier to enumerate occurrence-reached bodies through `IAssInstance.GetAllEntities()`, record occurrence title/suppression/body IDs, and read assembly-context `Show.GET` without assigning semantics.
- Adds explicit BOM membership evidence for `cmNoFiltering` and `cmVisibleOnly`, including complete data rows and exact row-set differences so the hidden-occurrence candidate can be classified from one run.
- Retains the single-run stopping rule and no-mutation evidence.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer, or model behavior changed.
- Validation: **AWAITING USER 0.20.25 QUALITY GATE + ONE GOVERNED 07C-4 LIVE RUN**. No PASS claimed.

## 0.20.24 — 2026-09-30 — Step 07C-3 Closure / User Validation

- Records user workstation 0.20.23 quality-gate PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records final governed live evidence `api-capability-component-properties-20260930-133403.txt`.
- Promotes U13 body/entity attribute read path to VERIFIED on both Part-model and assembly-context entities.
- Promotes U15 BOM export/material evidence to VERIFIED for both `cmNoFiltering` and `cmVisibleOnly`; visibility-row differences remain uninterpreted and reserved for 07C-4.
- Retains U14 as NOT AVAILABLE and U17 as NOT AVAILABLE FROM RETAINED 07A EVIDENCE; U16 remains reserved for 07C-4.
- Records model file and model-folder no-mutation evidence as UNCHANGED.
- Documentation/evidence/session-handoff only; no production, verifier runtime, test, configuration, setup-helper, or model behavior changed.
- Step 07C-3 status: **CLOSED / USER VALIDATED**.

## 0.20.23 — 2026-09-30 — Step 07C-3 Occurrence-Entity / Named-Attribute Corrective

- Records user-validated 0.20.22 quality gate PASS (`quality-gate-20260930-130837.txt`): Release x64 PASS, 0 warnings / 0 errors, governed tests PASS, coverage/local gates PASS, exit code 0.
- Records successful controlled setup: `KA-PART-1` body entity `4` = `cmBody`; `STEP07_B1_TEST_ATTRIBUTE` read back as `cmAttString` / `KNOWN_ANSWER_07C3`; result `ATTACHED_AND_READ_BACK`; manual save required.
- Records the first governed 07C-3 verifier stop: `instance.Model.GetEntityById(4, partModel)` raised COM `0x80040207` before U13/BOM evidence.
- Records follow-up read-only assembly evidence proving all loaded `KA-PART-1` occurrences expose body entity `4` through `IAssInstance.GetAllEntities()`.
- Corrects the development-only verifier to resolve exact body ID/type through `IAssInstance.GetAllEntities()` and removes the failed model `GetEntityById` route from this path.
- Keeps `GetAttributes()` enumeration for evidence, then performs exact `GetAttribute(cmAttString, requestedName)` confirmation; matching requires non-null, exact type and exact value, while returned `IAttribute.Name` is evidence only.
- Adds architecture source guards against regression to the failed entity route or returned-name equality gate.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer, setup-helper, or customer-model behavior changed.
- Validation: **AWAITING USER 0.20.23 QUALITY GATE + ONE GOVERNED LIVE RERUN**. No PASS claimed for 0.20.23.

## 0.20.22 — 2026-09-30 — Step 07C-3 Known-Answer Attribute Name-Observation Corrective

- Records the completed 0.20.21 workstation quality gate as PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the controlled 0.20.21 setup evidence: exact named `GetAttribute(cmAttString, STEP07_B1_TEST_ATTRIBUTE)` returned non-null; `ReadBack.Type = cmAttString`; `ReadBack.Value = KNOWN_ANSWER_07C3`; returned `ReadBack.Name` was blank.
- Corrects only the post-lookup validation rule: returned `IAttribute.Name` remains logged but is no longer required to equal the requested lookup name.
- Non-null/type/value checks remain fail-closed. Exact model/entity/name/value restrictions, no-overwrite behavior, `Attach()`, exact named lookup, and no Save/SaveAs/Close remain unchanged.
- Existing read-only `CimatronCustomization.ApiCapabilityVerification` remains unchanged; U13 remains NOT VERIFIED until the saved attribute is later read by the governed 07C-3 verifier.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer or customer model behavior changed.
- Validation: **AWAITING USER 0.20.22 QUALITY GATE + CONTROLLED SETUP RERUN**. No PASS claimed for 0.20.22.

## 0.20.21 — 2026-09-30 — Step 07C-3 Known-Answer Attribute Read-Back Diagnostic Corrective

- Records the completed 0.20.20 workstation quality gate as PASS: Release x64 build PASS, 0 warnings / 0 errors, governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the first controlled 0.20.20 setup run failure after `Attach()`: exact `GetAttribute(cmAttString, name)` returned an attribute object, but the subsequent name/type/value comparison failed.
- Corrects diagnostic observability only: actual `ReadBack.Name`, `ReadBack.Type`, and `ReadBack.Value` are now printed to the console before the fail-closed comparison.
- The helper still fails on mismatch, does not overwrite, does not auto-save, and does not try alternate mutation/read-back APIs.
- Existing read-only `CimatronCustomization.ApiCapabilityVerification` remains unchanged; U13 remains NOT VERIFIED.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer or customer model behavior changed.
- Validation: **AWAITING USER 0.20.21 QUALITY GATE + CONTROLLED SETUP RERUN**. No PASS claimed for 0.20.21.

## 0.20.20 — 2026-09-30 — Step 07C-3 Known-Answer Body Attribute Setup Helper

- Records the user-returned 0.20.19 workstation quality gate `quality-gate-20260930-120311.txt` as PASS: Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Adds separate developer-only `CimatronCustomization.KnownAnswerModelSetup`; the existing `CimatronCustomization.ApiCapabilityVerification` remains read-only and unchanged.
- Setup helper is fail-closed to active Part `KA-PART-1`, B1 body entity ID `4`, and `cmAttString` diagnostic attribute `STEP07_B1_TEST_ATTRIBUTE = KNOWN_ANSWER_07C3`.
- Existing same name/type/value returns `ALREADY_PRESENT`; same name with another type/value fails without overwrite.
- New attribute creation uses `IApplication.GetAttributeFactory()`, `IAttributeFactory.Create(cmAttString, name)`, `IAttribute.Value`, `IAttributeSink.Attach()`, then exact `GetAttribute(cmAttString, name)` read-back.
- Helper never calls `Save`, `SaveAs` or `Close`; it reports `MODEL MUTATED IN MEMORY - MANUAL SAVE REQUIRED`.
- U13 remains NOT VERIFIED until the later governed read-only 07C-3 verification reads the saved body attribute. U16/07C-4 remains out of scope.
- No production `src/**`, Plugin, CR/SA logic, configuration, installer or customer model behavior changed.
- Validation: **AWAITING USER 0.20.20 QUALITY GATE + CONTROLLED SETUP RUN**. No PASS claimed for 0.20.20.

## 0.20.19 — 2026-09-30 — Step 07C-3 Verifier Compile Corrective

- Records failed workstation quality gates `quality-gate-20260930-115502.txt` and `quality-gate-20260930-115729.txt`; no PASS is claimed.
- The second capture identifies two `CS1061` errors in `ComponentPropertySourceVerification.cs` because `AttributeObservation` is an enum and the evidence lines referenced a nonexistent `.Status` member.
- Corrected only those two evidence expressions to render the enum value directly. No U13/U15 logic, Cimatron API call, filter, model input, BOM handling, or no-mutation behavior changed.
- Aligns development-verifier ToolVersion and assembly/file version to `0.20.19`.
- The same workstation capture also reports access-denied deployment/copy errors under the Cimatron `Program` folder. This corrective does not change deployment permissions or production code.
- No production `src/**`, Plugin behavior, CR/SA behavior, configuration, installer or model data changed.
- Validation: **AWAITING USER 0.20.19 QUALITY GATE**. Only after PASS may the already-approved single 07C-3 live run proceed.

## 0.20.17 — 2026-09-30

## 0.20.18 — 2026-09-30 — Step 07C-3 Component Property / BOM Verification Preparation

- Hardened the existing development-only `--verify-component-properties` mode under the user-approved 07C-3 scope.
- Requires explicit `--known-attribute-name`, `--known-attribute-value`, and `--known-material`; no customer naming/value assumptions are hard-coded.
- Guards the target entity as `cmBody`, records known body-attribute matching on both Part and assembly-context entities, and keeps U14 getter invocation prohibited.
- BOM evidence now records known-answer model rows, material-column candidates, and known material values while keeping 07C-4 visibility interpretation explicitly out of scope.
- Added model-folder before/after listing evidence in addition to existing model file `IsModified`/timestamp/size evidence.
- Added U17 as the model/Part material-getter evidence item; classified `NOT AVAILABLE FROM RETAINED 07A EVIDENCE` with no new reflection run. Existing U16 remains unchanged for 07C-4.
- No production `src/**`, Plugin, configuration, CR/SA behavior or customer model change.
- Validation: **AWAITING USER QUALITY GATE + ONE LIVE 07C-3 RUN**. No PASS is claimed.

### Step 07C-2 — Architecture-guard alignment corrective
- Records workstation quality gate `quality-gate-20260930-033343.txt`: Release x64 build PASS with 0 warnings / 0 errors, then architecture tests FAIL, overall exit code 1.
- Aligns the Step 07 architecture source guard with the approved empty-selection-safe restore implementation.
- Guard now requires prior-selection capture, temporary highlight assignment, `RestoreSelection(context, previousSelection)`, explicit empty-list fallback, and final restore assignment.
- No verifier runtime behavior, production `src/**`, Plugin, CR/SA, configuration or model-data change.
- U7-U12 remain NOT VERIFIED pending a clean 0.20.17 quality gate and the single approved live run.

## 0.20.16 — 2026-09-30

### Step 07C-2 — Assembly Context verifier compile corrective
- Records failed workstation quality gate `quality-gate-20260930-032936.txt`: verifier compilation failed with CS0411 at `AssemblyContextVerification.cs(214,21)` and `(218,21)`; overall gate exit code 1.
- Fixes only those two development-diagnostic observations by specifying `TryObserve<object>` for transformation matrix/vector reads.
- Aligns verifier ToolVersion and assembly/file version to `0.20.16`.
- Carries forward completed 07C-2A manual known answers: `KA-PART-1`, body ID `4`, top-level B1 gap `25.000 mm`, UCS `UCS10_1`, UI assembly extents unavailable.
- Earlier 0.20.13 live evidence is troubleshooting-only and does not promote U7-U12.
- No production `src/**`, Plugin, CR/SA, configuration or model-data change.
- Validation: awaiting user 0.20.16 quality gate; only after PASS, one governed live assembly-context run.

## 0.20.15 — 2026-09-30

### Step 07C-2 — Assembly Context verification preparation
- Redefines 07C-2A as user-recorded, Cimatron UI/Measure sourced known answers; expected transforms/states/gap/bounding-box values are not derived from the APIs under test.
- Corrects the development-only `--verify-assembly-context` mode so suppressed/lock reads are guarded, matching occurrence transformations are recorded, reverse lookup is explicitly compared, and `--ucs-id` can drive `GetAssemblyBoundingBox`.
- Cross-component `MinDistancePos` now evaluates every matching occurrence pair and records occurrence IDs/depths plus both closest points instead of silently choosing the first two matches.
- Temporary highlight now pauses for user observation and restores the prior selection even when it was originally empty.
- Retains read-only/no-mutation evidence and leaves U7-U12 unpromoted pending user quality-gate + one live KA-ASM-1 run.
- No production `src/**`, Plugin, CR/SA, configuration or model-data change.

## 0.20.14 — 2026-09-30

### Step 07C-1 — Geometry Services closure
- Records user workstation 0.20.13 quality-gate PASS: Release x64 build PASS, 0 errors, all governed test suites PASS, coverage/local quality gates PASS, exit code 0.
- Records the final live evidence `api-capability-geometry-20260930-010854.txt` and closes 07C-1 per the user-approved stop rule.
- `GetPiercingPoints` is VERIFIED for the known-answer face-90 semantics: corrected direction/base-position order, bounded-face miss returns `null`, pointing-away ray returns `null`, and direction `(-2,0,0)` returns the same intersection as `(-1,0,0)`.
- Reconfirms `GetEntityPointDistance`, rotated-UCS face-list `GetBoundingBoxByUCS`, and no-mutation `UNCHANGED`.
- Records remaining limitations: `SurfacesArea` is NOT AVAILABLE; body-list `GetBoundingBoxByUCS` remains unresolved/unsupported for consumer use and U2 remains PARTIALLY VERIFIED.
- Documentation/governance only; no production `src/**`, Plugin, CR/SA logic, configuration, model data, tests, or diagnostic runtime behavior changed.
- 07C-1 is CLOSED. 07C-2 is unblocked by closure but NOT STARTED and requires separate explicit approval.

## 0.20.13 — 2026-09-30

### Step 07C-1R5 — Final geometry semantics run preparation
- Corrected development-diagnostic `GetPiercingPoints` argument mapping to the installed signature `iDirection, iBasePositin, iEntList`.
- Added exact input evidence and the fourth `(-2,0,0)` direction-length case to the single final 07C-1 batch.
- User workstation quality gate subsequently passed and the final live geometry run was completed in 0.20.13.
- No production `src/**`, Plugin, CR/SA logic, configuration, or model-data change.

## 0.20.12 — 2026-09-30

### Step 07C-1R4 — Piercing return-shape inspection
- Records user-supplied 0.20.11 quality-gate PASS: Release x64 build PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- Records live evidence `api-capability-geometry-20260930-004342.txt`: all three face-90 `GetPiercingPoints` calls reached Cimatron but post-call numeric conversion failed because the returned array contains at least one non-numeric top-level item.
- Replaces that conversion only in the development diagnostic with raw return-shape evidence: overall runtime type/value, array type/rank/length, and each top-level item type/value.
- Aligns diagnostic ToolVersion and assembly/file metadata to `0.20.12`.
- Does not change the Cimatron call, face target, approved rays, production `src/**`, Plugin behavior, CR/SA logic, model data, or 07C-2.
- Validation: **AWAITING USER 0.20.12 QUALITY GATE + SAME THREE-RAY PIERCING RERUN**. Agent did not build/test/run Cimatron.

## 0.20.11 — 2026-09-30

### Step 07C-1R3 — Piercing-array compile corrective
- Records user-supplied 0.20.10 quality-gate failure: CS0411 at `GeometryServicesVerification.cs(131,25)` because the compiler could not infer `T` for `VerificationRuntimeContext.TryObserve<T>`.
- Adds only the explicit generic type `double[]` to that existing diagnostic observation call.
- Does not change the COM-array conversion logic, Cimatron call, face/ray inputs, production `src/**`, Plugin behavior, CR/SA logic, model data, or 07C-2.
- Validation: **AWAITING USER 0.20.11 PACKAGE QUALITY GATE + THREE-RAY PIERCING RERUN**. Agent did not build/test/run Cimatron.

## 0.20.10 — 2026-09-30

### Step 07C-1R3 — Piercing-array conversion corrective
- Implements only the user-approved 07C-1R3 diagnostic corrective after the final 0.20.9 live run returned `object[]` from `GetPiercingPoints` and the diagnostic attempted a direct `double[]` cast.
- Converts the returned one-dimensional numeric COM array safely to `double[]` before evidence formatting; no Cimatron geometry call, target, ray, or model behavior is changed.
- Removes the stale evidence-version literal by sourcing live evidence `ToolVersion` from the diagnostic's single `Program.ToolVersion` constant. Assembly/file version is aligned to `0.20.10`.
- Carries forward user evidence: UCS `251` behaves as the +30° Z UCS, UCS `249` as the 90° UCS candidate; `GetEntityPointDistance` returned `10` and `14.142135623730951` mm with bounded-face closest points; no-mutation evidence remained `UNCHANGED`.
- Production `src/**`, Plugin behavior, CR/SA logic, known-answer model data, and 07C-2 remain unchanged.
- Validation: **AWAITING USER 0.20.10 QUALITY GATE + THREE-RAY PIERCING RERUN**. Agent did not build/test/run Cimatron.

## 0.20.9 — 2026-09-29

### Step 07C-1R2 — Final Geometry Services resolution preparation
- Implements only the user-approved 07C-1R2 diagnostic preparation; production `src/**`, Plugin behavior, CR/SA logic, and 07C-2 remain unchanged.
- Extends the existing `--verify-geometry` mode to accept repeated ray pairs and repeated point inputs, allowing all three approved piercing cases and both approved entity-point-distance cases in one controlled invocation.
- When `--face-id` is supplied, `GetPiercingPoints` now targets the guarded face list (face 90 in the known-answer run) rather than the body list, which is necessary to test bounded-face and ray-vs-line semantics.
- Aligns absent `IGeomServices.SurfacesArea` runtime evidence with the established `NOT_AVAILABLE` classification.
- Records the workstation-only requirement to create `KA_UCS_30Z` at the same origin as UCS 2, rotated +30° about Z, and discover its actual entity ID before the final run.
- Validation: **AWAITING USER 0.20.9 QUALITY GATE + ROTATED-UCS DISCOVERY + FINAL LIVE GEOMETRY EVIDENCE**. Agent did not build/test/run Cimatron.

## 0.20.7 — 2026-09-29

### Step 07C-1R — Quality-gate build corrective
- Records user-supplied 0.20.6 quality-gate failure: CS1061 at `GeometryServicesVerification.cs(141,82)` because installed `CimBaseAPI.IFace` has no `Area` member; Release x64 build exited `1`.
- Removes only the invalid compile-time `IFace.Area()` call.
- Retains the existing conditional/reflected `IGeomServices.SurfacesArea` path for face-area evidence; absent/failing installed API is recorded as blocked/raw evidence rather than guessed.
- No production `src/**`, Plugin behavior, CR/SA logic, or 07C-2/3/4 work changed.
- Validation: **AWAITING USER 0.20.7 QUALITY GATE**. Agent did not build/test/run Cimatron.

## 0.20.6 — 2026-09-29

### Step 07C-1R — Remaining Geometry Services evidence resolution
- Carries forward user workstation 0.20.5 quality-gate PASS and live geometry evidence: body metrics, 25 mm minimum distance, convex edge 89, concave edge 95, and unchanged no-mutation evidence.
- Extends the existing `--verify-geometry` mode only; no new probe mode is added.
- Adds `--face-id` with a `cmFace` guard, face area evidence, face-only bounding boxes, and B1-face-list bounding boxes.
- Adds `--reference-ucs-id` so one geometry run can compare the same face/B1 faces under the rotated user UCS and a separately evidence-mapped main/reference UCS.
- `SurfacesArea` is invoked only if the installed `IGeomServices` Interop contract actually exposes that member; otherwise evidence records `BLOCKED` and records the installed-contract outcome explicitly.
- Adds explicit `NOT_TESTED` evidence for `GetPiercingPoints` and `GetEntityPointDistance` when their known-answer input arguments are absent.
- Preserves no-mutation evidence. The `[1,1,1,0,0,0]` body bounding-box observation remains unclassified pending face-list comparison.
- No production `src/**`, Plugin behavior, CR/SA logic, or 07C-2/3/4 work changed.
- Validation: **AWAITING USER 0.20.6 QUALITY GATE + LIVE 07C-1R EVIDENCE**.

## 0.20.5 — 2026-09-29

### Step 07C-1D — Geometry verification execution checkpoint
- Records user-run 0.20.4 quality gate PASS and the completed evidence-backed KA-PART-1 mapping: B1=4, B2=5, test face=90, convex edge=89, concave edge=95, KA_UCS_90Z=2, and 25 mm body-pair minimum distance.
- Adds the exact first `--verify-geometry` commands using only evidence-backed IDs.
- Leaves ray/through-hole/test-point values unresolved rather than guessing.
- Aligns development diagnostic version labels to 0.20.5; Geometry Services logic and production `src/**` are unchanged.
- 07C-2/3/4 remain blocked.
- Validation: **AWAITING USER 0.20.5 QUALITY GATE + LIVE GEOMETRY EVIDENCE**.

## 0.20.3 — 2026-09-29

### Step 07C-1A — Geometry known-answer target discovery
- Adds development-only `--discover-geometry-targets --expect Part` to establish actual KA-PART-1 body/face/edge/UCS identifiers before 07C-1 verification.
- Records per-body volume/centre/surface area, active-UCS bounding boxes, exact two-body minimum distance, face IDs, edge IDs/convexity, active/runtime-discoverable UCS candidates, and no-mutation evidence.
- Does not infer B1/B2/test-face/edge/UCS roles and does not hard-code or guess IDs.
- No production `src/**`, Plugin behavior, configuration or CR/SA logic changed. 07C-2/3/4 remain unexecuted.
- Validation: **AWAITING USER QUALITY GATE AND LIVE DISCOVERY EXECUTION**.

## 0.18.0 — 2026-09-28

### Step 06C1 — Mapping Contracts & Configuration
- Records Step 06B closure from user-supplied quality-gate and in-process Cimatron probe evidence.
- Adds `TabularFieldMappingDefinition` for logical field name, one-or-more configured source header candidates/aliases, approved `Text`/`Decimal` type, and required/optional metadata.
- Adds `TabularMappingDefinition` as a named, consumer-neutral mapping profile.
- Rejects blank/duplicate logical fields and ambiguous header candidates case-insensitively at configuration construction time.
- Adds focused Application contract tests for aliases, uniqueness and metadata preservation.
- No workbook-header matching engine, row-validation engine, CR-04/CR-22 business logic, Infrastructure reader behavior, dependency version, or Cimatron model/plugin behavior changed.
- Validation status: **AWAITING USER QUALITY GATE**.

## 0.17.5 — 2026-09-28

- Records user-run 0.17.4 full quality gate PASS: Release x64 build, all required test suites, coverage gate/local quality gate, exit code 0.
- Replaces the environment-variable child-process trigger with a one-shot `%TEMP%\CimatronCustomization\step06b-tabular-probe.request` file.
- `Start-Step06BTabularProbe.ps1` now prepares the request and evidence path only; it no longer launches `CimatronE.exe`.
- The operator starts Cimatron normally, and the Plugin consumes the fresh 0.17.5 request on the first command click. Normal Feature Launcher behavior is unchanged when no request exists.
- No architecture-rule, production-reader, dependency-version, CR-04/CR-22, or model-behavior change.
- Cimatron in-process compatibility remains NOT VERIFIED pending user-run 0.17.5 live evidence.

## 0.17.4 — 2026-09-28

- Corrected the Step 06B diagnostic probe packaging after the user-run 0.17.3 quality gate exposed the existing Plugin thin-boundary architecture rule.
- Moved `TabularReaderRuntimeProbe.cs` from the Plugin project top level to `Plugin/Diagnostics/`; no probe logic or production reader logic changed.
- Preserved the five approved top-level Plugin production source files exactly as required by `ArchitectureBoundaryTests`.
- Cimatron in-process compatibility remains NOT VERIFIED until the 0.17.4 quality gate passes and the opt-in live probe is executed.

## 0.17.3 — 2026-09-28

### Added
- Opt-in `TabularReaderRuntimeProbe` inside the existing Cimatron plugin process.
- `tools/Start-Step06BTabularProbe.ps1` for controlled launch with the known-answer BIFF8 fixture and evidence path.

### Evidence / scope
- User-run 0.17.2 quality gate: PASS, including all required suites, coverage gate, local quality gate, exit code 0.
- User-run filesystem preflight found `ExcelDataReader.dll` 3.9.0.0 and `System.ValueTuple.dll` in the Cimatron Program directory.
- Runtime compatibility remains NOT VERIFIED until the live in-process probe passes.
- Production reader logic, dependency versions, CR business logic, and normal plugin behavior are unchanged.

## 0.17.2 — 2026-09-28

### Fixed
- Replaced the synthetic BIFF2 legacy-XLS test generator with a deterministic static BIFF8/CDF `.xls` fixture containing named worksheet `Input`.
- The fixture preserves the same known-answer headers/data used by the `.xlsx` and CSV tests and is copied to the Infrastructure test output directory.
- Production `ExcelTabularDataReader` behavior is unchanged.

### Validation evidence
- User-run 0.17.1 Release x64 build succeeded; Infrastructure test executable then failed only at `ReadsLegacyBiff2Workbook` because the BIFF2 fixture could not satisfy named-sheet selection.
- 0.17.2 validation: **AWAITING USER EXECUTION**.

### Scope control
- No runtime dependency, production reader, supported-format, mapping, safety-limit, Cimatron API, or CR business-rule change.

## 0.17.1 — 2026-09-28

### Fixed
- Added the missing .NET Framework `System.Data` reference required by ExcelDataReader's `IDataReader` / `IDataRecord` API surface.
- Changed the private `ResolveColumns` header parameter to the concrete `string[]` produced by `ReadHeaders`, resolving the reported CA1859 warning without suppression.

### Validation evidence
- User-supplied 0.17.0 quality-gate capture: restore PASS; Release x64 build FAIL with 25 cascading Infrastructure compiler errors rooted in missing `System.Data`, plus one CA1859 warning.
- 0.17.1 validation: AWAITING USER EXECUTION.

### Scope control
- No change to ExcelDataReader 3.9.0 / System.ValueTuple 4.5.0 selection, tabular contracts, supported formats, row/file limits, Cimatron APIs, or business rules.

# Changelog

## 0.17.0 — 2026-09-28

### Step 06B — Tabular reader Infrastructure
- Records user-approved closure of 06A after a clean workstation quality gate.
- Adds approved pinned runtime dependencies ExcelDataReader 3.9.0 and System.ValueTuple 4.5.0; no Excel COM automation and no DataSet extension package.
- Adds `ExcelTabularDataReader` for `.xlsx`, `.xls`, and `.csv`, preserving configuration-driven worksheet/header/column mapping.
- Adds shared-read access, 25 MiB / 100,000-row safety limits, stable actionable errors and all-or-nothing results.
- Adds Infrastructure reader tests including generated XLSX and legacy BIFF2 XLS fixtures plus CSV and negative cases.
- Adds `Test-TabularDependencyPreflight.ps1` and documents client-package/runtime binding impact.
- Cimatron in-process compatibility is NOT VERIFIED and must not be treated as PASS until user-supplied live evidence exists.
- Validation: **AWAITING USER EXECUTION**.

## 0.16.0 — 2026-09-28

### Step 06A — Tabular input requirement and Application contract
- Establishes WP8 consumers as CR-04 (steel grade vs DO Input Sheet) and CR-22 (finger-pin diameter vs slider-weight table).
- Adds `ITabularDataReader` and dependency-neutral Application models for configuration-driven worksheet/header/column mapping and typed tabular rows.
- Adds all-or-nothing `TabularReadResult`; errors require an actionable code and message and never contain a partial table.
- Limits 06A value types to `Text` and `Decimal`; workbook-specific behavior remains intentionally undecided until Step 06B/customer evidence.
- Adds requirement-derived temporary CSV fixtures under `tests/TestData/Step06/`; these are not customer layouts.
- Adds Application contract tests and registers them in the existing test harness.
- No Excel/NuGet dependency, Infrastructure reader, CR-04/CR-22 rule logic, or Cimatron runtime behavior is added.
- Validation: **AWAITING USER EXECUTION**. The AI agent did not run build/tests/coverage/Cimatron.

## 0.15.36 — 2026-09-27

### Step 05C2-B closure with documented hidden-state exception
- Records user validation of 0.15.35: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.
- Records the approved final `--probe-occurrence-interfaces` runtime evidence: 528 unique Interop COM IIDs queried once per known-answer occurrence with immediate pointer release; visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B` exposed identical interface sets; no-mutation evidence remained `UNCHANGED`.
- Records the single supported interface missed by the prior visibility-name search as `IEntityQuery`. Its reflection-only members are `CreateFilter`, `GetFilter`, `Select`, and `SetFilter`; no hidden/visibility getter exists and no newly discovered member was invoked.
- Applies the pre-approved stopping rule: end reflection-based hidden-state discovery. FR-021 is recorded as `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance`.
- Closes Step 05C2-B with the documented FR-021 hidden-state exception. Any suppressed-only initial shipping decision remains an explicit client/product scope decision.
- Corrects only the development-diagnostic version label/banner from stale 0.15.34 to 0.15.36; no COM probing logic, production `src/`, Assembly Pick, or production Zoom-to-result behavior changes.


### 0.15.35 Step 05C2-B — Diagnostic CA1859 warning-only correction
- Records user-run 0.15.34 quality-gate result: Release x64 build PASS; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0; three CA1859 analyzer warnings in `OccurrenceComInterfaceInventory.cs`.
- Changes only the flagged diagnostic collection property declarations: `Aliases` and `ReflectedMembers` from `IList<T>` to `List<T>`, and `Support` from `IDictionary<Guid,T>` to `Dictionary<Guid,T>`.
- No runtime logic, COM probing semantics, member invocation, stop rule, production `src/`, Assembly Pick, or production Zoom-to-result change.
- Validation status: **AWAITING USER EXECUTION**.

## 0.15.34 — 2026-09-27

### Step 05C2-B final occurrence COM-interface diagnostic
- Records user validation of 0.15.33: full quality gate PASS with Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage/local quality gate PASS; exit code 0.
- Records the 0.15.33 reflection-only result: no genuinely new occurrence-level visibility getter was found. The five occurrence-context getter entries reduce to `IgnoreInShowOperations` aliases already shown non-discriminating plus the closed `_IAssInstance.get_Show_()` route; visibility attributes remain metadata only.
- Adds development-only `--probe-occurrence-interfaces`. It enumerates COM interface IIDs from installed `interop.Cim*.dll` files, deduplicates runtime probes by IID, queries each IID once per known-answer occurrence with `Marshal.QueryInterface`, and immediately releases every successful interface pointer.
- Targets exactly visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`; captures `IProvideClassInfo` / `IDispatch.GetTypeInfo` class evidence where supported; emits an interface × object matrix.
- Any supported interface missed by the previous visibility-name search is reflected for member access classification only. No newly discovered member is invoked.
- Expected outcome is explicitly identical interface sets. Stop rule is explicit: if no new supported interface/member path results, end reflection-based hidden-state discovery, record FR-021 as `suppressed: supported; hidden: BLOCKED — pending Cimatron guidance`, and propose closing 05C2-B with that documented exception.
- Suppressed-only initial shipping, if necessary, is explicitly a client/product scope decision and is not decided by the diagnostic.
- Production `src/`, Assembly Pick, production Zoom-to-result, and model/view/selection mutation behavior remain unchanged.
- Validation: awaiting user-run full quality gate; after PASS run `--probe-occurrence-interfaces` on the approved known-answer copy.

## 0.15.33 — 2026-09-27

### Step 05C2-B architecture guard evidence-marker correction
- Recorded the user-run 0.15.32 quality-gate result: Release x64 build PASS with 0 warnings / 0 errors, followed by Architecture Tests FAIL and overall exit code 1.
- Root cause is a static architecture contract mismatch: `InteropReflectionInventory.cs` omitted four explicit legacy `_IAssInstance` cast-evidence marker strings required by `ZoomDiscoveryToolMustRemainReadOnlyAndDevelopmentOnly`.
- Restored only `CurrentCastTarget`, `CurrentCastMechanism`, `CurrentCastExceptionType`, and `CurrentCastHRESULT` output markers. These document the already-closed historical cast route and do not reopen or invoke `_IAssInstance.get_Show_()`.
- No production `src/`, Assembly Pick, production Zoom-to-result, or live diagnostic semantics changed.
- Validation: awaiting user-run full quality gate.



## 0.15.32 — 2026-09-27

### Step 05C2-B diagnostic-only visibility reflection narrowing
- Recorded user validation of the 0.15.30 full quality gate: Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration, and Infrastructure tests PASS; coverage/local quality gates PASS; exit code 0.
- Recorded the 0.15.30 live known-answer result: visible `Block_A`, suppressed `Block_B`, and hidden-not-suppressed `Known_Pocket_Body` all returned `IgnoreInShowOperations=0` with occurrence `cmAttVisibility` and `cmAttBlankLevel` absent, so those candidates are non-discriminating for FR-021.
- Kept `_IAssInstance.get_Show_()` closed based on the user-validated 0.15.29 `InvalidCastException / 0x80004002 (E_NOINTERFACE)` evidence.
- Extended only `InteropReflectionInventory` to identify read-only visibility/display getter metadata on occurrence/component-context interfaces. No newly discovered member is invoked.
- Production `src/`, Assembly Pick, production Zoom-to-result, tests, and mutating Cimatron behavior remain unchanged.
- Validation: awaiting user-run full quality gate, then `--reflect-visibility-api`.


## 0.15.31 — 2026-09-27

### Documentation / handoff
- Added a current Step 05C2-B new-session checkpoint and continuation prompt to `docs/history/session-handoffs/phase-02-step-05c2-handoff.md`.
- Captures that 0.15.29 is quality-gate validated, `_IAssInstance` / `Show_` is closed by live `E_NOINTERFACE` evidence, and 0.15.30 compatible-`IAssInstance` candidate comparison is still awaiting workstation validation.
- No source, tests, runtime behavior, Cimatron API behavior, or production behavior changed.

## 0.15.30 — Step 05C2-B compatible IAssInstance visibility-candidate comparison

- Records user validation of 0.15.29: full quality gate PASS with Release x64 build 0 warnings / 0 errors, all required test suites PASS, coverage/local quality gates PASS, and exit code 0.
- Records the live 0.15.29 known-answer diagnostic: 9 occurrences / 18 entity inspections / no limits / no mutation; explicit `_IAssInstance` compatibility failed for every occurrence with `InvalidCastException` / `0x80004002 (E_NOINTERFACE)`, closing the `Show_` route for the runtime objects supplied by Cimatron.
- Replaces the failed `_IAssInstance.get_Show_()` experiment with read-only signals available on the already-compatible `IAssInstance`: getter-only `IgnoreInShowOperations` plus occurrence-level `GetAttribute(cmAttVisibility, string.Empty)` and `GetAttribute(cmAttBlankLevel, string.Empty)`.
- Candidate reads record raw present/absent/value/error evidence independently for each occurrence; no visibility semantics are assigned in advance and per-candidate read failures do not abort the remaining comparison.
- No setter, Show/Hide mutation, component open/load/activation, production `src/`, Assembly Pick, or production Zoom-to-result change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.29 — Step 05C2-B architecture assertion correction

- Records user-run 0.15.28 quality-gate evidence: Release x64 build PASS with 0 warnings / 0 errors; Architecture Tests FAIL; overall exit code 1.
- Direct ArchitectureTests execution identified the stale guard literal `HiddenStateDetection: UNRESOLVED`.
- Updates only that guard to require the approved runtime-probe state `HiddenStateDetection: RUNTIME PROBE PENDING`.
- No diagnostic runtime behavior, Cimatron API usage, production `src/`, Assembly Pick, or production Zoom-to-result change.

## 0.15.28 — Step 05C2-B getter-only occurrence visibility runtime probe

- Records user validation of 0.15.27: Release x64 build PASS with 0 warnings / 0 errors; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage/local quality gates PASS; reflection diagnostic exit code 0.
- Reflection evidence proves exactly one installed `interop.CimMdlrAPI._IAssInstance` copy (GUID `4C8A5941-F526-11D5-B89D-006008719C4A`) and classifies `get_Show_()` as a read-only getter candidate while `set_Show_()` is mutating.
- Replaces the prior silent `as` cast with an explicit `_IAssInstance` compatibility cast that records exact exception type and HRESULT on failure.
- Calls only the getter when compatibility succeeds; the setter remains prohibited/not called. Returned values are evidence only until compared against known visible `Block_A`, hidden-not-suppressed `Known_Pocket_Body`, and suppressed `Block_B`.
- Keeps `cmAttVisibility` / `cmAttBlankLevel` as body/entity candidates only; no occurrence semantics are claimed.
- Production `src/`, Assembly Pick and production Zoom-to-result remain unchanged.

## 0.15.27
- Corrects the 0.15.26 development-only visibility reflection diagnostic compile failure (`CS0136`) by renaming the conflicting local variable to `guidValue`.
- No reflection behavior, Cimatron API usage, or production `src/` changes.
- User must rerun the quality gate elevated because the prior non-elevated run also hit Program Files deployment access-denied errors.

## 0.15.26 — 2026-09-27

### Step 05C2-B — Hidden occurrence-state reflection discovery
- Records successful user validation of 0.15.25: clean local quality gate, diagnostic exit code 0, 9 occurrences, 0 revisits, both `Block_A` placements at distinct occurrence paths/known offsets, suppressed `Block_B`, real `MbPocket=1`, and no mutation.
- Adds reflection-only `--reflect-visibility-api` for the remaining CR-11 FR-021 hidden-but-not-suppressed occurrence dependency.
- Searches `Show`, `Visible`, `Visibility`, `Hidden`, `Hide`, `Blank`, `Display`, and `State`; inventories every installed `_IAssInstance` copy and classifies matching members as getter/setter/accessor/method without invoking them.
- Records current cast target `interop.CimMdlrAPI._IAssInstance` and the exact observed failure semantics: the C# `as` cast returned null, so no exception/HRESULT exists in current evidence.
- Inventories `cmAttVisibility` / `cmAttBlankLevel` as body/entity visibility candidates only; occurrence semantics remain unproven.
- Discovery only: no newly discovered member invocation, no new live Cimatron API call, and no production `src/` change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.25 — 2026-09-27

### Step 05C2-B — Repeated-occurrence identity / definition-cycle correction
- Records the user-validated known-answer Assembly: real Mold Pocket `MbPocket(cmAttInteger)=1`, suppressed `Block_B`, nested transforms, no-mutation evidence `UNCHANGED`, and diagnostic exit code 0.
- Fixes the known-answer defect where Cimatron showed `Block_A(2)` but the diagnostic emitted only one placement and counted one revisit because positive `InstanceId` was treated as globally unique.
- Makes the full occurrence path, including sibling ordinal, the diagnostic occurrence identity; `InstanceId` is evidence only.
- Replaces global ID deduplication with ancestry-only Assembly definition cycle protection keyed by already-approved `IModel.PID`; missing PID relies on the existing depth/occurrence limits and is recorded as a limitation.
- Records that recursive self-assembly cycle protection is not exercised by live Cimatron validation.
- Keeps hidden-state detection unresolved and separate. No new Cimatron API and no production `src/` change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.24 — 2026-09-27

### Step 05C2-B — Separate occurrence/entity budgets and evidence completeness
- Records user validation of 0.15.23: clean quality gate and successful real-mold read-only traversal with 80 occurrences, 490 body checks, nested recursion, suppression detection, unchanged file evidence, and `MbCooling=1` through occurrence `root:-1/8/137`.
- Replaces the shared 2000-item guard with independent 2000-occurrence and 2000-entity-inspection budgets. Entity-budget exhaustion no longer terminates occurrence recursion.
- Adds explicit per-occurrence entity-inspection status so skipped/partial inspection cannot be misread as absence of `MbPocket`/`MbCooling`.
- Adds read-only `--assembly-entities --occurrence-only` and total-runtime evidence.
- Records open acceptance items: `MbPocket` via occurrence unproven; hidden-state detection unresolved (CR-11 FR-021); known-answer small-assembly validation still required.
- No new Cimatron API and no production `src/` change.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.23 — 2026-09-26

### Step 05C2-B — Root parent runtime correction
- Records the user-run 0.15.22 quality gate as clean: Release x64 PASS, 0 warnings / 0 errors, required tests PASS, coverage/local quality gates PASS, exit code 0.
- Records the first 0.15.22 controlled Assembly runtime: attach, active Assembly resolution, model/root acquisition and root ID read succeeded; root ID was `-1`; `IAssInstance.get_AssParentInstance` on that root returned COM `E_FAIL` (`0x80004005`).
- Root pseudo-instance traversal now skips `get_AssParentInstance` and records `ParentId` as `ROOT/N/A`; non-root parent traversal remains unchanged.
- Full occurrence path remains the cycle/revisit fallback whenever an occurrence ID is non-positive.
- Architecture guard now protects the root-parent special case. No new Cimatron API, production `src/`, traversal limits, watchdog, or no-mutation behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.22 — 2026-09-26

### Step 05C2-B — Checkpoint guard correction and analyzer cleanup
- Corrected the Step 05C2 architecture guard so it validates the approved 0.15.21 controlled traversal calls and the common `RunApiCall` BEGIN/call/END checkpoint ordering instead of requiring removed exploratory `GetInstances` / `Select` / `GetFaces` checkpoint text.
- Retained the existing runtime `RunApiCall` checkpoint behavior; no Cimatron API or traversal semantics were added or changed.
- Corrected two CA1834 analyzer warnings in `AssemblyEntityInventory.FormatObject` by using `StringBuilder.Append(char)` for comma and closing-bracket characters.
- Production `src/` remains unchanged.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.21 — 2026-09-26

- Implements Step 05C2-B controlled read-only Assembly occurrence/entity diagnostics from the user-approved installed-Interop allow-list.
- Removes the diagnostic's older exploratory `GetInstances/CreateFilter/SetFilter/Select/GetFaces` traversal path.
- Adds per-Cimatron-call 15-second watchdog/exit code 7, depth/item/revisit guards, exception type + HRESULT evidence, occurrence parent/root/suppression/show/transform evidence, occurrence-reached body enumeration, and `MbPocket` / `MbCooling` read-only `cmAttInteger` checks.
- Adds before/after active-document modified-state and file timestamp/length evidence; changed/unverifiable no-mutation evidence returns exit code 8.
- Architecture tests enforce the approved allow-list and prohibit component open/load/activation, save/suppress/set/attribute mutation and transformation mutation calls in the diagnostic.
- No production `src/`, Assembly Pick, Highlight, or production Zoom-to-result behavior changes.
- Validation status: **AWAITING USER EXECUTION**.

## 0.15.20 — 2026-09-26

- Corrects the single CA1859 warning reported by the user-run 0.15.19 quality gate in the development-only Assembly API reflection inventory.
- Changes `EnumerateDeclaredMembers(Type)` from `IEnumerable<MemberInfo>` to `MemberInfo[]`, matching `Type.GetMembers(...)`; no reflection logic or runtime Cimatron behavior changes.
- Advances diagnostic/version stamps to 0.15.20.
- No production `src/`, Assembly Pick, Assembly traversal, Highlight, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**; require 0 warnings / 0 errors before the reflection inventory run.

## 0.15.19 — 2026-09-26

- Adds Step 05C2-A development-only `--reflect-assembly-api` to inventory the installed Cimatron 2026 Interop assembly surface before any new Assembly traversal call is approved.
- Uses `Assembly.ReflectionOnlyLoadFrom` only; no Cimatron process attach, document access, traversal, selection, command execution, load/activate/save, or model mutation is performed by this mode.
- Scans inherited/base COM interfaces with `GetInterfaces()` and records exact method/property/member signatures and declaring interfaces for Assembly/instance/occurrence/component/model/body/face/entity/transform/attribute/visibility/suppression/document/modified-state candidates.
- Adds architecture protection requiring the new inventory to remain reflection-only and base-interface-aware.
- Records user validation of 0.15.18: quality gate PASS with 0 warnings / 0 errors; non-admin MTA attach PASS / exit 0; deliberate elevation mismatch failed fast with exit 6.
- No production `src/`, Assembly Pick, Assembly traversal, Highlight, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.18 — 2026-09-26

- Hardens the Step 05C2 development-only attach diagnostic after workstation evidence isolated the `GetApplication()` timeout to a privilege mismatch: CimatronE was non-elevated while the failing discovery runs were launched from Administrator PowerShell.
- Records user validation: 0.15.17 quality gate PASS, corrected `trace-selftest` task PASS, elevated STA/MTA attach-only runs TIMEOUT/5, non-elevated `Cr11RuntimeProbe` PASS on active `cmAssembly`, and non-elevated Discovery MTA attach-only PASS/0.
- Replaces broad process-name matching with exact `CimatronE.exe` inventory and records PID, Windows Session ID and elevation. A confirmed Cimatron/tool elevation mismatch now fails fast before `GetApplication()` with exit code `6`.
- Corrects COM reflection evidence by scanning inherited interfaces (`GetInterfaces()`) for the parameterless `GetApplication()` method.
- No production `src/`, Assembly Pick, Highlight, Assembly traversal, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.17 — 2026-09-26

- Adds development-only `--attach-only --apartment=STA|MTA` to isolate the confirmed `AppAccess.GetApplication()` hang without entering Assembly traversal.
- Runs the attach on a background worker explicitly configured to STA or MTA; the controller records a 30-second timeout and returns exit code `5` without force-aborting the COM call.
- Records the parameterless `GetApplication()` reflection signature, Cimatron process count/PID/Windows Session ID, and run-precondition evidence/reminders.
- Records user validation of 0.15.16: full local quality gate PASS, trace self-test PASS, and `assembly-entities` heartbeat proving the process stayed alive while blocked after `AppAccess` creation and before `GetApplication()` returned.
- Corrects the missed 0.15.16 condition by adding `trace-selftest` to `Invoke-And-Capture.ps1`; architecture coverage now guards the named task and attach-only diagnostic boundary.
- No production `src/`, Assembly Pick, Highlight, Assembly traversal, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.16 — 2026-09-26

- Adds development-only durable startup/dispatch tracing for Step 05C2 under `%LOCALAPPDATA%\CimatronCustomization\diagnostics\`, using timestamp+PID filenames and write-through/flush/close for every record.
- Adds `--trace-selftest` with no Cimatron API calls, startup environment evidence (PID, command line, elevation, apartment state), and a background heartbeat recording the last persisted checkpoint.
- Mirrors existing `assembly-entities` checkpoints to the durable file before console output.
- Preserves the existing `[STAThread]` configuration; no apartment-state behavior is changed.
- Adds architecture enforcement for diagnostic isolation and durable-trace requirements.
- No new Cimatron API calls; no production `src/`, Assembly Pick, Highlight, or production Zoom-to-result behavior changes.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.15 — 2026-09-26

### Step 05C2 — Session handoff package
- Adds the canonical Step 05C2 session handoff under `docs/history/session-handoffs/phase-02-step-05c2-handoff.md`.
- Captures approved scope, completed work, current validation evidence, unresolved Assembly diagnostic hang, 0.15.14 checkpoint plan, exact next steps, and required read order for a new session.
- No production source, diagnostic runtime behavior, or Cimatron behavior changed.
- Validation: **DOCUMENTATION-ONLY / AWAITING USER EXECUTION**.

## 0.15.14 — 2026-09-26

### Step 05C2 — Assembly entity diagnostic checkpoints
- Records user-supplied 0.15.13 local quality-gate PASS with 0 warnings / 0 errors and successful console-capture output.
- Records that the first `assembly-entities` runtime probe produced no diagnostic output and had to be stopped manually; the exact blocking API call is therefore not yet identified.
- Adds timestamped, immediately flushed checkpoints before/after the read-only Assembly inventory COM calls so the next capture identifies the last completed call.
- Adds an architecture guard for the checkpoint instrumentation.
- No production source or Cimatron production behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.13 — 2026-09-26

### Step 05C2 — PowerShell 5.1 console capture compatibility fix
- User-run 0.15.12 helper failed with `Parameter set cannot be resolved using the specified named parameters` before the child task executed.
- Replaced `Tee-Object -LiteralPath ... -Append` with explicit per-line console output plus `Add-Content`, compatible with Windows PowerShell 5.1.
- Preserves named tasks, stdout/stderr capture, live console display, timestamped files and child exit-code propagation.
- No production code or Cimatron runtime behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.12 — 2026-09-26

### Step 05C2 — Named-task console capture fix
- Replaces the 0.15.11 `-Name` + mandatory `-Command` script-block interface with a `-Task` interface compatible with `powershell -ExecutionPolicy Bypass -File`.
- Adds fixed tasks `quality-gate` and `assembly-entities`, while preserving live console display, timestamped text capture, stderr/stdout capture and exit-code propagation.
- No production code or Cimatron runtime behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.11 — 2026-09-26

### Step 05C2 — Console capture helper
- Adds developer-only `tools/Invoke-And-Capture.ps1` to tee long console output into timestamped text files under `artifacts/console-captures/` while still displaying it in PowerShell.
- Captures stdout/error streams, records the supplied command and execution context, preserves the command exit code, and prints the final capture path for easy upload to the agent.
- No production code, Cimatron runtime behavior, Zoom diagnostic behavior, Pick, Highlight, or model/view logic changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.10 — 2026-09-26

### Step 05C2 — Read-only Assembly entity discovery
- Records user-supplied 0.15.9 quality-gate PASS with 0 warnings / 0 errors and the live Part `&Display,Zoom Selection` visual PASS.
- Adds development-only `--assembly-entities` to enumerate candidate Body/Face entity IDs from Part instances in the active Assembly, together with instance path/ID and model PID/title.
- Uses only the already-established read-only assembly/model inspection path (`GetInstances`, entity query/filter/select, `IBody.GetFaces`).
- Executes no native Cimatron command and does not alter selection, Pick, model geometry, or viewport state.
- Production Assembly Pick remains unsupported and unchanged.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.8 — 2026-09-26

## 0.15.9 — 2026-09-26

### Step 05C2 — Controlled native Zoom Selection validation
- Records user-supplied 0.15.8 quality-gate PASS with 0 warnings / 0 errors and successful Part/Assembly command inventory evidence.
- Adds a development-only validation mode that temporarily selects one explicit active-model entity and executes only the discovered `&Display,Zoom Selection` command.
- Restores the prior selection after the command returns and writes a diagnostic evidence file.
- Adds architecture guards limiting the diagnostic to the exact approved command and keeping the tool outside production dependencies.
- No production Zoom-to-result behavior is implemented.
- Validation: **AWAITING USER EXECUTION**.


### Step 05C1 — Microsoft.CSharp binder dependency correction
- User-run 0.15.7 Release x64 build failed with `CS0656` because the standalone ZoomCommandDiscovery project did not reference `Microsoft.CSharp`.
- Added `<Reference Include="Microsoft.CSharp" />` to `CimatronCustomization.ZoomCommandDiscovery.csproj`.
- No production code or diagnostic behavior changed; the tool remains read-only and development-only.
- Validation: **PASS** from user-supplied 0.15.8 local quality-gate output (0 warnings / 0 errors; all reported tests/coverage gates PASS).

## 0.15.7 — 2026-09-26

### Step 05C1 — Dedicated read-only Zoom/View discovery tool
- Replaced the 0.15.6 test-executable discovery hook with a dedicated x64 tool under `tools/CimatronCustomization.ZoomCommandDiscovery`.
- Embedded the official-style Cimatron side-by-side manifest and configured Release/Debug x64 output to the Cimatron 2026 Program folder for standalone dependency resolution.
- Added reflection-only installed-Interop inventory for `Zoom`, `Fit`, `View`, `Frame`, and `Camera` interface members.
- Added full read-only `GetCommandsNames()` dumps with Part/Assembly context headers and filtered console candidates.
- Defined exit codes 0/1/2/3/4 and evidence output under `artifacts/diagnostics`.
- Added architecture guards proving no production project references the tool and preventing command execution or selection/view/model mutation in the diagnostic.
- Removed obsolete zoom-discovery/filter sources from the CimatronIntegration test project.
- Repository review does not support the suggested `Microsoft.NET.Test.Sdk` generated-entry-point root cause for 0.15.6; exact silent-invocation mechanism remains unproven without workstation `obj/` artifacts.
- No production Plugin/Application/CimatronIntegration/Domain/DesignChecks behavior changed.
- Validation: **AWAITING USER EXECUTION**.

## 0.15.6 — 2026-09-26

### Step 05C1 — Analyzer warning cleanup
- User-run 0.15.5 Release build/tests/coverage/local quality gate passed, but the build emitted two `CA1861` warnings in `ZoomCommandCandidateFilterTests.cs`.
- Replaced the two inline constant command arrays with `static readonly` test fixtures.
- No production code or native command-discovery behavior changed.
- Workstation validation for 0.15.6 remains **AWAITING USER EXECUTION**.

## 0.15.5 — 2026-09-26

### Step 05C1 — Native Zoom Command Discovery
- Added a development-only `--discover-zoom-commands` mode to the CimatronIntegration test executable.
- Discovery uses documented PoolCommands inventory APIs and does not execute candidate commands.
- Added candidate-filter regression tests and Step 05C1 API-discovery documentation.
- No production runtime behavior changed.
- Workstation build/test/runtime evidence remains **AWAITING USER EXECUTION**.

# Changelog

## 0.15.4 — CLOSED / VERIFIED — 2026-09-26

### Step 05B2 closure
- User-run Release x64 build: **PASS**, **0 warnings / 0 errors**.
- Architecture, Domain, Application, CimatronIntegration and Infrastructure tests: **PASS**.
- Coverage collection/gate and local quality gate: **PASS**.
- Coverage: Domain **100%**; Application **95.75%**; DesignChecks **100%**; Infrastructure **98.48%**; CimatronIntegration **4.57% measured** (no Step 05B2 threshold).
- Live same-document idle Pick: **PASS**; no false `SOURCE_DOCUMENT_CLOSED`.
- Live second request while Pick active: **PASS** with `Busy / PICK_ALREADY_ACTIVE`.
- Live Esc cancellation after Busy: **PASS** with `Cancelled / ESC`.
- Repeat Pick after Esc and normal entity selection: **PASS**.
- Live real source-document close: **PASS** with `Cancelled / SOURCE_DOCUMENT_CLOSED`; launcher restored safely and no crash observed.
- Normal document-switch cancellation remains previously live-verified and its path was preserved by 0.15.4.
- Exactly-once/no-duplicate behavior was explicitly live-verified in 0.15.3 and unchanged in 0.15.4; the final 0.15.4 close-dialog dismissal was not separately reported.
- A 0.15.4 `ViewportPickCompleted` log line was not separately supplied in chat and is recorded as an evidence limitation rather than inferred.
- Step 05B2 — Production Pick Integration is formally **CLOSED / VERIFIED** by user approval.
- Added closure/new-session handoff `docs/history/session-handoffs/phase-02-step-05b2-to-step-05c-session-handoff-0.15.4.md`.

## 0.15.4 — 2026-09-26

### Fixed
- Replaced the 0.15.3 source-document watchdog's managed COM-wrapper token comparison with stable source Part model-PID/document-type comparison on the captured Cimatron STA/UI context.
- Prevents false `SOURCE_DOCUMENT_CLOSED` cancellation when repeated `GetActiveDoc()` calls represent the same still-open Part through a different managed COM wrapper.
- Preserves the four-probe confirmation window so a normal active-document switch can complete first through the already verified `OnToolPoped` path; exactly-once completion and late-callback suppression are unchanged.

### Tests
- Added regression coverage showing the same source model PID remains current across wrapper-identity changes and does not accumulate source-loss observations.
- Added negative lifecycle-identity coverage for a different active Part model and no active model.

### Validation
- User-run 0.15.3 local quality gate: PASS with 0 warnings / 0 errors; all listed test projects, coverage collection/gate, and local quality gate PASS.
- 0.15.3 live close-document result: intended `Cancelled / SOURCE_DOCUMENT_CLOSED` appeared once and no duplicate popup followed, but subsequent Pick starts exposed the false-cancellation regression fixed here.
- This implementation was subsequently user-validated and Step 05B2 closure is recorded in the closure section above.

## 0.15.3 — 2026-09-26

### Fixed
- Added source-document lifecycle monitoring for an active production Part Pick. If the source token remains non-current for four consecutive 250 ms UI-thread probes and the normal Cimatron tool-pop path has not already completed the request, the Pick completes as `Cancelled` with reason `SOURCE_DOCUMENT_CLOSED`.
- Added an exactly-once `TryComplete` session gate so lifecycle completion releases the strong PickTool reference and any late COM completion is ignored instead of reaching the caller twice.
- Source-document-close completion does not call `PopTool` against a document that has already disappeared; it completes the managed PickTool directly and preserves the existing result/log callback path.

### Tests
- Added pure lifecycle-state regression coverage for first/duplicate completion, persistent source-document mismatch confirmation, and reset when the source becomes current again.

### Scope / validation
- No Application contract/outcome change. No Plugin UI change. No Step 05A Highlight change. Assembly/occurrence Pick, NC Pick, multi-select and Zoom remain deferred.
- Previous 0.15.2 user evidence remains historical only. Version 0.15.3 is **AWAITING USER EXECUTION** for Release x64 build, all tests, coverage/local quality gate, and live Cimatron validation.

## 0.15.2 — 2026-09-26

### Added
- Application-owned production Pick contract: `IViewportEntityPicker`, `ViewportPickRequest`, `ViewportPickResult`, `ViewportPickOutcome`, `ViewportEntityType`, and `ViewportDocumentIdentity`.
- Exact Pick outcomes: `Picked`, `Cancelled`, `Unsupported`, `Failed`, `Busy`, `StaleResult`.
- Assembly-ready result shape with source-document token, entity type and optional occurrence path while 0.15.2 runtime support remains Part-only.
- Session document identity registry and current-document stale-result validation.
- Caller-initiated cancellation through `CancellationToken`, marshalled to the captured Cimatron UI synchronization context.
- Cimatron entity-type filter mapping for Body, Face and Edge using the verified `cmFilterEntityType` / `FilterType.Add(...)` boundary.
- Pure CimatronIntegration lifecycle/token tests and Application contract tests.
- CimatronIntegration coverage collection/reporting with no silent production-member exclusions.

### Changed
- Replaced the diagnostic `CimatronPartPickSpike` / `CimatronDiagnosticPickTool` Release path with `CimatronViewportEntityPicker` / `CimatronViewportPickTool`.
- Feature Launcher action is now `Pick Entity (Part)` and consumes only the Application Pick port.
- Preserved the verified modeless launcher, owned TopMost result dialog, foreground recovery and explicit focus-return behavior from 0.15.1.
- A second Pick request returns `Busy` without cancelling the first.
- Entity IDs are explicitly scoped to the source document token and current Cimatron session; stale results are rejected before reuse.

### Scope / deferred
- Part single-select only in 0.15.2. Assembly/sub-assembly/component occurrence Pick, NC Pick and multi-select remain deferred.
- Occurrence path is intentionally empty for Part results.
- Zoom remains Unsupported and is tracked for CR-11 FR-014. Multi-select remains deferred for CR-11 FR-003/FR-004.
- Step 05A Highlight behavior is unchanged.
- Cimatron exit during an active Pick is a live case only if safe; if not exercised it must be recorded as `NOT TESTED`, never PASS.

### Coverage policy
- No coverage exclusions were added.
- `CimatronCustomization.CimatronIntegration` is now included in coverage collection and printed as a measured informational package. No new percentage threshold was approved for the API adapter in this increment.

### Validation
- First user-run local quality gate: Release x64 build **PASS**; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests **PASS**; coverage collection/gate and local quality gate **PASS**; **0 errors / 7 warnings**.
- The seven warnings were confined to `ViewportPickContractTests.cs`: six `CA1806` warnings from intentionally constructed exception-test objects and one `CA1861` warning from a constant occurrence-path array argument.
- Warning-only correction consumes the constructed instances through the test helper and reuses a `static readonly` occurrence-path fixture. No production behavior changed.
- Warning-corrected package user re-execution: Release x64 **PASS**, **0 warnings / 0 errors**; Architecture, Domain, Application, CimatronIntegration and Infrastructure tests **PASS**; coverage collection/gate and local quality gate **PASS**.
- Measured coverage: Domain **100%**; Application **95.75%**; DesignChecks **100%**; Infrastructure **98.48%**; CimatronIntegration **3.44% measured** (no threshold introduced in Step 05B2).

### Live validation in progress
- Normal Part Pick: **PASS**; production result returned entity ID, entity type, source-document token/metadata, reason code and correlation id.
- Esc cancellation: **PASS**.
- Repeat Pick immediately after Esc: **PASS**.
- Active-document switch during Pick: **PASS** with controlled `Cancelled` / `CIMATRON_TOOL_POPPED`.
- `Busy` live case: **NOT TESTED THROUGH CURRENT UI** because the launcher is intentionally hidden while Pick is active; automated state coverage remains the evidence for this path.
- Active source-document close during Pick: **FAIL / INCOMPLETE**. The document closes but no result dialog is produced and no corresponding `ViewportPickCompleted` log entry was observed.
- Step 05B2 remains OPEN. A document-close lifecycle correction is proposed but requires explicit approval before production code changes.
- Added session handoff `docs/history/session-handoffs/phase-02-step-05b2-document-close-defect-session-handoff-0.15.2.md`.


## 0.15.1 — CLOSED / VERIFIED — 2026-09-26

### Closure
- Step 05B1 — Part-only Pick Spike is formally **CLOSED / VERIFIED** from user-supplied workstation and live Cimatron evidence.
- Final user-run Release x64 build: **PASS**, **0 warnings / 0 errors**.
- Architecture, Domain, Application and Infrastructure tests: **PASS**.
- Coverage collection, coverage gate and local quality gate: **PASS**.
- Coverage: Domain **100%**; Application **95.41%**; DesignChecks **100%**; Infrastructure **98.48%**.
- Live Part pick success: **PASS**.
- Live Esc cancellation and tool cleanup: **PASS**.
- Dedicated Pick result-dialog reachability across window toggles: **PASS**.
- Feature Launcher foreground restoration after returning to Cimatron: **PASS**.
- Post-result focus return to Cimatron/Feature Launcher: **PASS**.
- Active-document switching during Pick: **PASS**.
- Direct managed-object PickTool activation without COM registration: **PASS**.

### Deferred / next increment
- 0.15.1 remains a diagnostic/foundation Part-only spike; it does not promote Pick into the production Result Report flow.
- Persistent post-pick highlight is deferred.
- Assembly/NC Pick remain Unsupported.
- Zoom remains Unsupported.
- Step 05B2 will plan the proper Application-owned Pick contract/result model and UI integration using only the live-verified 0.15.1 behavior. Implementation requires separate explicit approval.


## 0.15.1

### Added
- Part-only diagnostic PickTool spike using the installed Cimatron 2026 `IToolContainer.PushPickTool` contract.
- `CIMATRON-2026-PICK-TOOL-VERIFICATION.md` recording the exact installed Interop signatures supplied from the workstation before implementation.
- `Pick Spike (Part)` launcher action with a **strongly retained modeless Feature Launcher**. The launcher can hide during the asynchronous Cimatron pick without terminating its window lifetime and is restored on completion/cancellation.
- Bounded event tracing and current-session picked entity-ID diagnostics.
- Architecture guard allowing exactly one `[ComVisible(true)]` class in CimatronIntegration with a fixed GUID while the assembly remains `ComVisible(false)`.

### Scope / limitations
- No COM registration, RegAsm, registry change, installer change, or CLSID activation is introduced; live validation must prove whether direct managed-object handoff is accepted by Cimatron.
- Pick is intentionally limited to active Part documents and a face filter. Assembly/NC Pick remain Unsupported.
- Result Report Pick integration is deferred to 0.15.2 after the spike establishes real runtime behavior.
- Zoom remains Unsupported. Step 05A Highlight code is unchanged.
- Entity IDs are session-only diagnostics and are not persisted.

### Validation
- User-supplied local quality gate before the lifecycle correction: **PASS** — Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS.
- First live Pick spike proved direct managed-object handoff works **without COM registration**: `OnToolPushed`, `PickToolHelperAvailable`, and `OnToolPoped` were observed.
- Live defect found: hiding the modal `ShowDialog()` launcher ended the dialog lifetime and triggered owner-shutdown cancellation before entity/keyboard callbacks could complete.
- Corrected 0.15.1 uses a strongly retained modeless launcher and architecture protection against returning to `launcher.ShowDialog()`.
- User re-validation after that lifecycle correction: local quality gate **PASS** with 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate PASS. Live Part pick **PASS** — completion popup reported current-session entity ID 48 and restored the launcher.
- Live Esc cancellation path PASS after the first popup correction, but a second window-toggle test showed the standard MessageBox can still become unreachable behind another window.
- Replaced the Step 05B1 completion/cancellation MessageBox with a dedicated owned nested `PickSpikeResultDialog` inside `FeatureLauncherWindow.cs` that remains TopMost while open and has its own OK action; no new top-level Plugin source file is introduced.
- Picked selection clearing when the diagnostic tool ends remains expected spike behavior; persistent highlight is deferred to 0.15.2 integration.
- User re-validation of the architecture-compliant dedicated result-dialog package: **PASS** — Release x64 build 0 warnings / 0 errors; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate and local quality gate PASS. Live Esc cancellation dialog remained reachable and behaved correctly.
- Follow-up live observation isolated a separate modeless-launcher z-order issue: after switching away from Cimatron and back, the Feature Launcher itself could stay behind. Pressing Esc without first starting Pick produced no Pick result, ruling out Esc-alone duplicate Pick activation.
- Corrected launcher foreground lifecycle: show the modeless launcher owned by the Cimatron main window and monitor only transitions where the Cimatron process regains foreground; restore/activate the launcher once on that transition only when it is visible, enabled, and no Pick is active. The launcher is not permanently TopMost.
- User live validation confirmed the launcher-foreground correction works when switching away from Cimatron and back, and active-document switching during Pick behaved as expected. A package-specific local quality-gate transcript was not supplied for that correction.
- Follow-up live defect: after cancelling Pick with Esc and closing the dedicated result dialog, Cimatron could fall behind another application.
- Corrected focus return after the Pick result dialog closes: explicitly foreground the captured Cimatron main window, then restore/activate the owned Feature Launcher. Existing PickTool/Interop behavior, the dedicated result dialog, and the external-window foreground monitor are unchanged.
- User live re-validation confirmed the focus-return behavior works: after `Pick Spike (Part)` -> Esc -> closing the result dialog, Cimatron remains foreground and the Feature Launcher is restored.
- User reran the full local quality gate for the focus-return package: Release x64 build PASS; Architecture, Domain, Application and Infrastructure tests PASS; coverage gate/local quality gate PASS. The build reported one analyzer warning, `CA1806`, because `GetWindowThreadProcessId`'s return value was ignored.
- Warning-only correction: `IsCurrentProcessForeground()` now checks the `GetWindowThreadProcessId` return value and fails closed when it returns 0. Runtime foreground behavior is otherwise unchanged. Architecture source-contract coverage protects the checked-return-value pattern.
- **WARNING-ONLY CORRECTION NOT VERIFIED / AWAITING USER RE-EXECUTION.**


## 0.15.0 — 2026-09-25

### Added
- Step 05A viewport highlight Application port/result model.
- CimatronIntegration highlight adapter using verified `ISelection.Selection` behavior.
- Result Report **Highlight** action for findings carrying current-session entity references.
- Disabled **Zoom — Unsupported** and **Pick — Unsupported** actions to make the current boundary explicit.
- Focused Application and Architecture tests plus Cimatron API verification documentation.

### Scope / limitations
- Active-model entity highlighting only. Nested assembly-instance highlighting is not yet verified and returns controlled Unsupported.
- Zoom/display transformation and interactive PickTool integration are not implemented in 0.15.0.
- No model mutation/write API and no customer CR/SA business logic.

### Validation
- User-supplied local quality gate: **PASS**.
- Release x64 build: **PASS** with **0 warnings / 0 errors**.
- Architecture, Domain, Application and Infrastructure tests: **PASS**.
- Coverage gate: **PASS** — Domain 100%, Application 95.41%, DesignChecks 100%, Infrastructure 98.48%.
- Live standalone Part Highlight: **PASS** — the corresponding finding geometry was visibly highlighted in orange in the Cimatron viewport with no error.
- Live mold assembly nested-instance Highlight: controlled **Unsupported** as designed; no unverified nested-instance selection was attempted.
- **Zoom — Unsupported** and **Pick — Unsupported** remained disabled as designed.
- Step 05A — Viewport Highlight: **CLOSED / VERIFIED** from user-supplied workstation and live Cimatron evidence.
- Next increment: Step 05B planning for the remaining viewport interaction scope; implementation requires explicit approval.


## 0.14.11 — 2026-09-25

### Fixed
- Confirmed live correlation `bc56bfd20991494288ea499ee9d9ccd1` loaded application version 0.14.10 and failed in `CimatronModelInspectionAdapter.ReadColor()` at the second `IAttributeSink.GetAttributes()` call.
- Centralized every `GetAttributes()` call in `CimatronModelInspectionAdapter` through `TryGetRawAttributes()`.
- `ReadColor()` now converts the same entity-specific `ArgumentException` into controlled `Unsupported` with a `Color inspection:` prefix, while unexpected exception types continue to propagate.
- Strengthened the architecture/source-contract test so exactly one `GetAttributes()` call is allowed and it must be inside the guarded helper; the helper is also protected against broad `Exception`/`COMException` catches.

### Validation
- User-supplied validation completed for 0.14.11.
- Release x64 build: PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Coverage gate: PASS — Domain 100%, Application 95.31%, DesignChecks 100%, Infrastructure 98.48%.
- Problematic Part live probe: Total 5 / Passed 2 / Unsupported 3 / Error 0.
- Representative mold assembly live probe: Total 7 / Passed 6 / Unsupported 1 / Error 0; 130 components.
- Representative Part regression: Total 5 / Passed 2 / Unsupported 3 / Error 0.
- Runtime log correlation `bfd082fc3d04457bbdd7de9f67c0380c` confirmed `applicationVersion` 0.14.11 with empty exception type/message.
- Step 04 — Cimatron Model Access Ports: CLOSED.
- Next planned step: Step 05 — `viewport-highlight-zoom-picks` (`0.15.0`).

## 0.14.10 — 2026-09-25

### Fixed
- Live stack trace proved that a specific Part/entity fails at `IAttributeSink.GetAttributes()` with `System.ArgumentException`.
- `ReadAttributes()` now reports that entity-specific runtime rejection as controlled `Unsupported` instead of failing the entire Model Inspection Probe.
- Unexpected exception types remain errors and continue through full stack/detail logging.
- Added focused source-contract coverage for this compatibility branch.

### Validation
- Version 0.14.10 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun the previously failing Part and confirm topology/surface findings remain available while attributes become `Unsupported` instead of overall `Error`.

## 0.14.9 — 2026-09-25

### Fixed
- Corrected the 0.14.8 Infrastructure test-harness compile failure.
- Added the missing `WritesExceptionStackTraceAndDetail()` test method and its throw helper.
- Production logging behavior is unchanged from 0.14.8.

### Validation
- Version 0.14.9 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.14.8 — 2026-09-25

### Changed
- Extended JSONL error logging with full exception stack trace and `Exception.ToString()` detail.
- Added focused Infrastructure coverage for persisted exception diagnostics.
- Logging-only diagnostic patch; no Cimatron API or feature execution behavior changed.

### Validation
- Version 0.14.8 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun the failing single-Part Model Inspection Probe once and query the new correlation ID in the JSONL log.

## 0.14.7 — 2026-09-25

### Changed
- Added precise stage diagnostics around `GetApplication()`, `GetActiveDoc()`, and active-document type access in the topology reader.
- No runtime compatibility behavior is guessed in this patch; it only identifies the remaining pre-topology failure boundary.
- No write APIs or customer CR/SA logic changes.

### Validation
- Version 0.14.7 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun only the failing single-Part Model Inspection Probe and capture the complete stage-labelled message.

## 0.14.6 — 2026-09-25

### Changed
- Added exact diagnostic labels around the Part-entry/model/reference operations that remained outside 0.14.5 topology instrumentation.
- Instrumented model-container access, model retrieval, assembly-instance model/ID reads, model PID, body/face entity IDs, and entity-reference creation.
- No behavior fix is guessed in this version; the purpose is to identify the exact live COM operation that raises the range exception.

### Validation
- Version 0.14.6 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, rerun the failing single-Part Model Inspection Probe and report the full stage-labelled message.

## 0.14.5 — 2026-09-25

### Fixed
- Removed dynamic dispatch from assembly enumeration and now call `IAssemblyModel.GetInstances()` through the typed interop interface.
- Consume the returned instance array as `object[]` and cast each element defensively to `IAssInstance`.
- Added precise topology-stage exception context so live COM failures identify the failing read operation instead of only returning a generic range/interop message.

### Live evidence addressed
- 0.14.4 representative assembly run: `System.__ComObject` did not expose `GetInstances` through dynamic dispatch.
- Separate smaller/single-assembly topology run: `Value does not fall within the expected range.`

### Validation
- Version 0.14.5 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- If green, repeat both live Model Inspection Probe scenarios.

## 0.14.4 — 2026-09-25

### Fixed
- Corrected live Cimatron COM-array marshaling for `IAssemblyModel.GetInstances()`.
- Replaced the three direct `IAssInstance[]` assumptions with one defensive runtime-normalization path that accepts the actual COM `object[]`/`Array` representation and casts entries individually to `IAssInstance`.
- Applies consistently to assembly structure traversal, topology part-instance collection and instance lookup.
- No analyzer suppression, model mutation, Cimatron write API or customer business logic was introduced.

### User-supplied validation from 0.14.3
- Build: PASS with 0 warnings and 0 errors.
- Release x64, Architecture, Domain, Application and Infrastructure tests: PASS.
- Coverage: Domain 100%, Application 95.31%, DesignChecks 100%, Infrastructure 98.45%.
- Coverage gate and local quality gate: PASS.
- Live Model Inspection Probe: runtime Error due to `object[]` -> `IAssInstance[]` conversion; this package addresses that observed defect.

### Validation
- Version 0.14.4 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`, then repeat the Model Inspection Probe on the same Assembly.

## 0.14.3 — 2026-09-25

### Fixed
- Removed the complete 36-warning analyzer baseline reported by the 0.14.2 workstation build.
- Fixed `CA1806`, `CA1822`, `CA1825`, `CA1852`, `CA1859`, and `CA1861` at source; no analyzer suppression was added.
- Production edits are mechanical/behavior-preserving and do not alter Cimatron API calls or customer feature logic.
- Test edits preserve existing assertions and coverage intent.

### User-supplied validation from 0.14.2
- Release x64 build: PASS.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Domain coverage: 100%.
- Application coverage: 95.31%.
- DesignChecks coverage: 100%.
- Infrastructure coverage: 98.45%.
- Coverage gate and local quality gate: PASS.
- Build warnings: 36 total; user requested that all be fixed.

### Validation
- Version 0.14.3 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- Target warning count: 0.

## 0.14.2 — 2026-09-25

### Fixed
- Removed the five analyzer warnings introduced by Step 04 without changing runtime behavior:
  - one `CA1826` in `ModelInspectionProbeFeature`;
  - two `CA1859` warnings in `ModelInspectionProbeFeature`;
  - two `CA1859` warnings in `CimatronModelInspectionAdapter`.

### User-supplied validation from 0.14.1
- Release x64 build: PASS.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Domain coverage: 100%.
- Application coverage: 95.31%.
- DesignChecks coverage: 100%.
- Infrastructure coverage: 98.45%.
- Coverage gate and local quality gate: PASS.
- Build warnings: 40 total; five were newly introduced by Step 04 and are the sole target of this patch.

### Validation
- Version 0.14.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- Expected warning count: return to the established 35-warning baseline if no environment-dependent analyzer difference appears.

## 0.14.1 — 2026-09-25

### Fixed
- Added focused coverage tests for `ModelInspectionProbeFeature` after the 0.14.0 workstation gate reported DesignChecks at 73.15% against the required 95%.
- Covered the untested probe guards and supported/unsupported read-result branches without changing production behavior.
- Avoided new analyzer-warning patterns in the corrective test additions where practical.

### User-supplied validation from 0.14.0
- Release x64 build: PASS.
- Architecture tests: PASS.
- Domain tests: PASS.
- Application tests: PASS.
- Infrastructure tests: PASS.
- Domain coverage: 100%.
- Application coverage: 95.31%.
- DesignChecks coverage: 73.15% (minimum 95%) — FAIL.
- Infrastructure coverage: 98.45%.
- Build warnings: 40 versus the prior 35-warning baseline.

### Validation
- Version 0.14.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`; the rerun is authoritative for both DesignChecks coverage and warning count.

## 0.14.0 — 2026-09-25

### Added
- Phase 02 Step 04 — read-only Cimatron model-access ports (WP5).
- `IAssemblyStructureReader`, `IEntityAttributeReader`, `IEntityColorReader`, and `IBodyTopologyReader` Application boundaries.
- Presentation-neutral snapshots for assembly components, attributes, colors, bodies and faces.
- `CimatronModelInspectionAdapter` using verified Cimatron 2026 read/query APIs.
- `FOUNDATION-MODEL-INSPECTION-PROBE` in DesignChecks.
- `docs/platform/CIMATRON-2026-MODEL-ACCESS-VERIFICATION.md`.
- Focused Application/fake-port tests for the new contracts and probe orchestration.

### Changed
- CimatronIntegration adds verified `interop.CimBaseAPI` and `interop.CimMdlrAPI` references.
- CimatronIntegration explicitly references Domain because the Application read-port contracts use Domain-owned `ModelEntityReference`, `Point3`, and `Direction3`; architecture tests encode this approved inward dependency.
- Feature composition registers the model-inspection foundation probe.

### API verification
- U1: verified for recursive `IAssemblyModel.GetInstances()`, instance model/id/color/suppression, `get_Transformation(1)` and transformation matrix.
- U2: entity attributes verified through `IAttributeSink.GetAttributes()`; instance/component attributes remain `Unsupported`.
- U3: assembly instance color and explicit entity `cmAttColor` verified.
- U4: body filtering + 2026 `IBody.GetFaces()`/`IFace`, `IGeom3DSurface.SurfType`, `Area()` and `NormalFromPoint()` verified. General bounding box remains `Unsupported`.
- No unverified API signature is guessed.

### Previous-step user validation
- Step 03 / 0.13.2: Release x64 and all local test suites PASS.
- Coverage: Domain 100%, Application 94.76%, Infrastructure 98.45%; coverage/local quality gate PASS.
- Live launcher, single-feature result report and two-feature `Run Selected` checklist PASS.

### Scope controls
- Read-only only; no save/move/recolor/attribute-write/procedure creation API.
- No customer CR/SA business rules or specialized analyzers.
- D5 client-shipping policy for foundation probes remains separate from this progressive development package.

### Validation
- Version 0.14.0 agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1`, then run Model Inspection Probe on a representative Part/Assembly in Cimatron 2026.0 SP2P1.

## 0.13.2 — 2026-09-25

### Fixed
- Fixed the Step 03 launcher checked-vs-selected UX mismatch found during live Cimatron validation.
- Checking or unchecking an actual feature node now also selects that node, so `Run Feature` can operate on the feature the user just interacted with.
- `Run Selected` remains based on checked applicable features; checklist behavior is unchanged.

### User-supplied validation from 0.13.1
- Release x64 build: PASS.
- Architecture, Domain, Application and Infrastructure tests: PASS.
- Domain coverage: 100%; Application coverage: 94.76%; Infrastructure coverage: 98.45%.
- Coverage gate and local quality gate: PASS.
- Build warnings: 35, matching the established warning baseline.
- Live Cimatron launcher: opens and groups features correctly; Assembly applicability correctly disables Active Part Readiness.
- Live UX defect: checking `Rule Parameter Probe` did not set `TreeView.SelectedNode`, so `Run Feature` displayed `Select a feature first.`

### Validation
- Version 0.13.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1` and then continue Step 03 live launcher/report validation.

## 0.13.1 — 2026-09-25

### Fixed
- Updated the architecture test's explicit Plugin top-level source allow-list for the two Step 03 UI files already approved by the Step 03 architecture plan: `FeatureLauncherWindow.cs` and `FindingReportWindow.cs`.
- Cleaned only Step-03-introduced analyzer warnings in `FeatureLauncherApplicationTests.cs` without changing production behavior.

### User-supplied validation from 0.13.0
- Release x64 build: PASS; 0 errors.
- Architecture tests: FAIL because the pre-Step-03 source allow-list did not include the newly approved launcher/report UI files.
- Build emitted 51 analyzer warnings; legacy warnings remain out of scope, while Step-03-introduced warnings in the new launcher Application test file are corrected here.

### Validation
- Version 0.13.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.13.0 — 2026-09-25

### Previous-step validation closeout
- Step 02 / 0.12.0 user validation: Release x64, Architecture/Domain/Application/Infrastructure tests, coverage gate and local quality gate PASS.
- Coverage: Domain 100%, Application 93.71%, Infrastructure 98.45%.
- Live Cimatron: schema 2 and `ProbeLength = 25 mm` probe PASS in Assembly context.

### Added
- Feature Launcher window grouped by feature kind and functional group.
- Current-context feature availability with disabled/unavailable features and reasons.
- Single-feature execution and sequential selected-feature checklist execution under one correlation ID.
- Result Report window with sortable finding columns, status filter and summary counts.
- Application use cases/projections: `ListAvailableFeatures`, `FeatureAvailability`, `ExecuteFeatureChecklist`, `FeatureChecklistReport`, and `FeatureFindingView`.
- Startup diagnostics access from the launcher.

### Boundaries
- No viewport highlighting, zoom, picks, model-reading ports, or customer CR/SA logic.
- No background-thread Cimatron COM access; all Step 03 execution stays on the command/UI thread. U10 remains explicitly UNVERIFIED beyond that conservative rule.

### Validation
- Agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1` and the Step 03 live Cimatron checklist.

## 0.12.0 — 2026-09-25

### Added
- Phase 02 Step 02 — versioned rule-parameter configuration (WP4).
- Schema-2 per-feature parameter configuration and in-memory schema-1 migration.
- `RuleParameterDefinition`, typed values/set, `IRuleParameterProvider`, XML provider, and foundation `RuleParameterProbeFeature`.
- Validation for required parameters, supported types, numeric ranges and `#RRGGBB` color-code representation.
- Focused Application and Infrastructure tests for the new parameter pipeline.

### Changed
- Common execution pipeline now resolves validated rule parameters before parameterized features run.
- Shipped config is schema 2 while retaining existing logging settings.
- Plugin registers/runs the internal parameter probe under the same correlation id as the readiness validation until the launcher arrives in Step 03.

### Scope controls
- No customer CR/SA business rule or customer parameter value added.
- No new Cimatron API/Interop usage.
- Parameter editing is file-only; UI editing remains deferred.

### Validation
- Agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1` and live Cimatron validation.

## 0.11.3 — 2026-09-25

### Fixed
- Fixed the Step 01 coverage pipeline so Domain tests contribute to Domain coverage.
- `Invoke-Coverage.ps1` now collects:
  - `domain.coverage.xml` from `CimatronCustomization.Domain.Tests.exe`;
  - `application.coverage.xml` from `CimatronCustomization.Application.Tests.exe`;
  - `infrastructure.coverage.xml` from `CimatronCustomization.Infrastructure.Tests.exe`;
  and merges all three into `coverage.cobertura.xml`.
- No production behavior changed.

### Root cause confirmed from 0.11.2
- Domain tests were included in the Domain test project and invoked by its `Program.Main`.
- The quality gate separately reported `DOMAIN TESTS: PASS`.
- The coverage script collected only Application and Infrastructure test executables, so the newly added Domain tests were never instrumented.
- This explains why Domain coverage remained exactly 55.56% after 0.11.2.

### Validation
- Version 0.11.3 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.
- Expected coverage output now includes a `domain.coverage.xml` collection before the merge.

## 0.11.2 — 2026-09-25

### Fixed
- Added focused Domain coverage tests for the Step 01 result model introduced in 0.11.0.
- Covered constructor guards, value accessors, collection enumeration, empty/null aggregation paths, and every canonical result-severity branch.
- No production behavior or Cimatron API usage changed.

### User-supplied validation from 0.11.1
- Release x64 build: PASS.
- Architecture tests: PASS.
- Domain tests: PASS.
- Application tests: PASS.
- Infrastructure tests: PASS.
- Coverage collection: PASS.
- Application coverage: 92.65% (minimum 90%).
- Infrastructure coverage: 100% (minimum 80%).
- Domain coverage: 55.56% (minimum 90%) — quality gate FAIL.

### Validation
- Version 0.11.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.11.1 — 2026-09-25

### Fixed
- Corrected the user-reported Step 01 Release x64 build failure `CS0012` in `CimatronCommandExecution`.
- Kept the approved architecture boundary intact: Plugin still has no direct reference to `CimatronCustomization.Domain`.
- Added `FeatureExecutionReport.StatusText` as an Application-owned presentation value; Plugin now displays that instead of directly consuming the Domain-owned `ResultStatus`.
- Added a focused Application regression assertion for the status-text boundary.

### User-supplied validation from 0.11.0
- Release x64 build: FAIL with 1 error (`CS0012`) because Plugin accessed `FeatureExecutionReport.Status`, whose type is defined in Domain.
- Existing analyzer warnings, including the known Plugin `CA1852` warning, remain outside this corrective patch.

### Validation
- Version 0.11.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.11.0 — 2026-09-25

### Added
- Canonical enum-based feature execution status, including approved Automation-only `Succeeded`.
- Feature execution context/run inputs, enriched feature metadata, findings/value types, document-context applicability, and platform guide.
- Dedicated Plugin `FeatureComposition` for explicit registry composition.

### Changed
- Feature outcomes/reports no longer use free-text status strings.
- Validation wrong-document context is stopped by the common pipeline as `NotApplicable`; missing application/document is `Error`.
- Execution logs now carry feature requirement ids and finding-count summaries.
- Plugin architecture now permits composition-only references to DesignChecks and Automations while preserving their isolation from CimatronIntegration/Interop and from each other.

### Previous-step validation closeout
- Version 0.10.0 user evidence: Release x64 build PASS; Architecture, Domain, Application and Infrastructure tests PASS; Domain 95.24%, Application 96.23%, Infrastructure 100%; coverage gate PASS; local quality gate PASS.
- Live Cimatron 2026.0 SP2P1 Step 10 execution PASS with active Part, startup diagnostics, registry-backed Active Part Readiness `Passed`, and no visible runtime regression.

### Validation
- Version 0.11.0 agent execution status: NOT VERIFIED. User must run the local quality gate and live Cimatron regression.

## 0.10.0 — 2026-09-17

### Added
- Common Application execution pipeline for registry-backed Validation and Automation features.
- Standardized `FeatureExecutionReport` with feature metadata, status/message, duration, and retained exception context for execution errors.
- Focused Application regression coverage for success, Failed, Warning, Error, unknown feature, exception-to-Error behavior, timing/report metadata, logging/correlation metadata, and both feature categories.

### Changed
- Plugin now delegates registry-backed feature execution and operational logging to Application instead of executing/logging the readiness feature directly.
- `FeatureRegistry` exposes registered-feature resolution for the executor while retaining existing discovery/execution behavior.

### Previous-step validation
- Version 0.9.4 user evidence: Release x64 build PASS; Architecture, Domain, Application, and Infrastructure tests PASS; Domain 95.24%, Application 100%, Infrastructure 100%; coverage gate PASS; local quality gate PASS.
- Live Cimatron startup diagnostics PASS and structured JSON-lines runtime logging PASS.

### Validation
- Version 0.10.0 agent execution status: NOT VERIFIED. User must run the local quality gate and live Cimatron regression.

## 0.9.4 — 2026-09-17

### Fixed
- Prevented rolled-log filename collisions when multiple log rolls occur within the same millisecond.
- Added a rapid-roll regression check while retaining the bounded-file retention assertion.

### Validation
- 0.9.3 user evidence: Release x64 build PASS; Architecture PASS; Domain PASS; Application PASS; Infrastructure FAIL on duplicate rolled filename.
- 0.9.4 requires user quality-gate execution.

## 0.9.3 — 2026-09-17

### Fixed
- Corrected malformed XML C# string literals in `StartupConfigurationTests.cs` that caused the 0.9.2 Infrastructure test project to fail compilation.
- Reviewed the Step 09 source/test files for the same string-literal/escaping defect class; no additional malformed literals were found in the inspected Step 09 files.

### Validation
- Version 0.9.2 user validation: FAIL with 16 compile errors in `StartupConfigurationTests.cs`.
- Version 0.9.3 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.9.2 — 2026-09-17

### Fixed
- Added the missing .NET Framework `System.Xml` assembly reference to `CimatronCustomization.Infrastructure`, required by `XmlStartupConfigurationProvider` / `System.Xml.Linq`.

### Validation
- Version 0.9.1 user validation: FAIL with `CS0012` because `XmlReader` could not be resolved.
- Version 0.9.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.

## 0.9.1 — 2026-09-17

### Fixed
- Corrected malformed C# string literals in `RollingJsonFileLogger` JSON serialization/escaping code that caused the 0.9.0 Release x64 build to fail.
- Corrected the focused Infrastructure logger test string literals and added a regression assertion for escaped quote, backslash, and newline content.

### User-supplied validation from 0.9.0
- Release x64 build: FAIL with 22 compile errors in `RollingJsonFileLogger.cs`; known CA1822/CA1825 warnings were unrelated.

### Validation
- Version 0.9.1 agent execution status: NOT VERIFIED. User must rerun the local quality gate, then live Cimatron validation.

## 0.9.0 — 2026-09-17

### Added
- Versioned XML startup configuration, bounded rolling structured logging, Application startup diagnostics, and Cimatron runtime-version/context diagnostics.
- Infrastructure test harness and governed Infrastructure coverage.

### Changed
- Plugin composition root now references Infrastructure only to compose approved logging/configuration adapters.
- Existing registry-backed Active Part readiness execution remains the representative feature after startup diagnostics.

### Validation
- Agent execution status: NOT VERIFIED. User must run the local quality gate and live Cimatron validation.

## 0.8.0 — 2026-09-17

### Added
- Explicit Application-layer `FeatureRegistry` using composition-root registration; no reflection or assembly scanning.
- `IApplicationFeature`, `FeatureDefinition`, `FeatureKind`, and `FeatureExecutionOutcome` application contracts for scalable Validation/Automation registration.
- `ActivePartReadinessFeature` as the first registry-backed internal foundation feature.
- Focused Application registry tests covering registration, discovery, duplicate ids, invalid registrations, metadata, lookup, and execution.

### Changed
- Plugin composition root now registers and executes the existing Active Part readiness feature through `FeatureRegistry` rather than invoking the use case directly.
- Product and assembly version metadata advanced to 0.8.0.

### Previous-step validation
- Version 0.7.0 Release x64 build, Architecture tests, Domain tests, Application tests, coverage gate, and local quality gate: PASS based on user-supplied evidence.
- Domain coverage: 95.24%; Application coverage: 100%.
- In-process Cimatron Active Part readiness runtime: PASS with status `Passed`.

### Validation
- Version 0.8.0 agent execution status: NOT VERIFIED.
- User must rerun the Release x64 local quality gate and then validate the registry-backed command in real Cimatron with an active Part.

## 0.7.0 — 2026-09-17

### Added
- Internal foundation `ActivePartReadinessValidation` vertical slice in Domain; this is not a customer CR/SA feature.
- Standard Domain `ResultStatus` states and structured Active Part readiness result.
- Application `CheckActivePartReadiness` orchestration and Plugin-safe outcome DTO.
- Dedicated Domain test executable and local quality-gate execution.
- Application tests covering Error, NotApplicable, Unsupported, and Passed readiness paths.

### Changed
- Plugin command now exercises the first complete read-only vertical slice instead of displaying the raw session diagnostic.
- Product and assembly version metadata advanced to 0.7.0.

### Validation
- Agent execution status: NOT VERIFIED.
- User must run the Release x64 local quality gate and then validate the command in real Cimatron with an active Part.

## 0.6.1 — 2026-09-17

### Fixed
- Corrected `ReadCurrentCimatronSessionTests` to use `CimatronSessionSnapshot.ActiveDocument(CimatronDocumentContext.Part)` instead of an unavailable four-argument constructor.
- Assigned the constructor-under-test to a local variable in the null-dependency test to remove the test-only `CA1806` analyzer warning.

### User-supplied validation from 0.6.0
- Release x64 build reached Application.Tests and failed with `CS1729` because the test attempted to call a non-existent four-argument `CimatronSessionSnapshot` constructor.
- `CA1806` was also reported in the null-dependency test.

### Validation
- Version 0.6.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`, then execute the registered command inside Cimatron with an active Part.


## 0.6.0 — 2026-09-17

### Added
- Added `ReadCurrentCimatronSession` as the Application-layer use case for current-session orchestration.
- Added focused Application tests proving the use case delegates exactly once to `ICimatronSession` and rejects a null dependency.

### Changed
- `CimatronCommandExecution` now composes `CimatronSessionAdapter` with the Application use case instead of directly invoking the session port.
- Product/test assembly version metadata advanced to 0.6.0.0.

### Previous-step validation
- Version 0.5.5 local quality gate: PASS.
- Version 0.5.5 in-process Cimatron session diagnostic: PASS with an active Part.

### Validation
- Version 0.6.0 agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1` and then execute the registered command inside Cimatron.
## 0.5.5 — 2026-09-17

### Changed
- Wired the validated Cimatron Plugin command to the production `CimatronSessionAdapter` for in-process session validation.
- Plugin now acts as the composition root and references both Application and CimatronIntegration.
- Updated ArchitectureTests to permit the approved Plugin → CimatronIntegration composition-root dependency while retaining other Plugin boundary guards.

### User-supplied validation from 0.5.4
- Release x64 build: PASS.
- Architecture tests: PASS.
- Application tests: PASS.
- Application coverage: 100%.
- Coverage gate and local quality gate: PASS.
- Optional standalone diagnostic EXE: FAIL at runtime with `REGDB_E_CLASSNOTREG`; it is no longer the mandatory Step 05 production-path validation.

### Validation
- Version 0.5.5 agent execution status: NOT VERIFIED.
- User must run `tools\Invoke-QualityGate.ps1`, then execute the registered Plugin command inside Cimatron with an active Part.

## 0.5.4 — 2026-09-17

### Fixed
- Added the missing .NET Framework `Microsoft.CSharp` assembly reference to `CimatronCustomization.CimatronIntegrationTests` so the approved dynamic COM/Interop conversion in the optional diagnostic EXE can compile.
- No production `CimatronSessionAdapter` logic or Plugin behavior changed.

### User-supplied validation from 0.5.3
- Release x64 build reached the diagnostic project and failed with `CS0656: Missing compiler required member Microsoft.CSharp.RuntimeBinder.Binder.Convert`.

### Validation
- Version 0.5.4 agent execution status: NOT VERIFIED.
- User must rerun the local quality gate, then run the external diagnostic with Cimatron open and an active Part.

## 0.5.3 — 2026-09-17

### Fixed
- Corrected the optional external Cimatron session diagnostic to use the official EXE-project access path: `interop.CimAppAccess.AppAccess.GetApplication()`.
- Added explicit diagnostic-project references to `interop.CimAppAccess.dll` and `interop.CimatronE.dll` through the configurable `CimatronProgramDir` property.
- Removed the diagnostic EXE dependency on the production `CimatronCustomization.CimatronIntegration` project.
- Production `CimatronSessionAdapter` remains unchanged on the official Class-project `CimApplicationProvider.GetApplication()` path.

### User-supplied validation from 0.5.2
- Local quality gate: PASS.
- External diagnostic failed with `REGDB_E_CLASSNOTREG` when the Class-project provider path was invoked from the EXE process.

### Validation
- Version 0.5.3 agent execution status: NOT VERIFIED.
- User must rerun the local quality gate, then run the external diagnostic with Cimatron open and an active Part.

## 0.5.2 — 2026-09-17

### Fixed
- Added the missing .NET Framework `Microsoft.CSharp` assembly reference to `CimatronCustomization.CimatronIntegration` so the approved `dynamic` Interop conversion can compile.
- No session-adapter logic or Plugin behavior changed.

### User-supplied validation from 0.5.1
- Interop reference-path correction progressed the Release x64 build past unresolved Cimatron assemblies.
- Build then failed with `CS0656: Missing compiler required member Microsoft.CSharp.RuntimeBinder.Binder.Convert`.

### Validation
- Version 0.5.2 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1`.


## 0.5.1 — 2026-09-17

### Fixed
- Corrected `CimatronCustomization.CimatronIntegration` Interop reference resolution by defining a configurable `CimatronProgramDir` defaulting to the verified Cimatron 2026 Program directory.
- Updated `interop.CimatronE.dll` and `interop.CimServicesAPI.dll` HintPaths to resolve through `$(CimatronProgramDir)`.

### User-supplied validation from 0.5.0
- Release x64 build reached CimatronIntegration and failed because both Interop assemblies could not be resolved from project-relative HintPaths.
- The resulting `interop` namespace compiler errors were downstream of the unresolved references.

### Validation
- Version 0.5.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1` and then run the live Cimatron session diagnostic.

## 0.5.0 — 2026-09-17

- Added the Application-layer `ICimatronSession` port and immutable `CimatronSessionSnapshot`.
- Added `CimatronSessionAdapter` in CimatronIntegration using the official `CimApplicationProvider.GetApplication()` and `IApplication.GetActiveDoc()` plugin/class-project access path.
- Added focused Application tests and a user-run live Cimatron session diagnostic executable.
- Extended the local quality gate to execute Application tests and collect governed Application coverage.
- No CR/SA business logic added; validated Plugin command source remains unchanged.

## 0.4.1 — 2026-09-17

### Fixed
- Corrected `Test-CoverageGate.ps1` so generated C# files under `bin/` and `obj/` are excluded when deciding whether a governed project contains substantive production source.
- Preserved exclusion of `Properties/AssemblyInfo.cs`.

### User-supplied validation from 0.4.0
- Release x64 build: PASS with 0 errors and one non-blocking `CA1852` warning in the existing plugin execution class.
- ArchitectureTests: PASS.
- `dotnet-coverage` and `dotnet-sonarscanner` restore: PASS.
- Coverage collection/report generation: PASS.
- Coverage gate: FAIL because generated Domain files were incorrectly classified as substantive source; this patch addresses that root cause only.

### Validation
- Version 0.4.1 agent execution status: NOT VERIFIED.
- User must rerun `tools\Invoke-QualityGate.ps1` and provide the resulting output.

## 0.4.0 — 2026-09-17

### Added
- Root `.editorconfig` and centrally enabled Roslyn/.NET analyzer configuration.
- Pinned `Microsoft.CodeAnalysis.NetAnalyzers` 10.0.401 development dependency.
- Local tool manifest pinning `dotnet-coverage` 18.11.0 and `dotnet-sonarscanner` 11.3.0.
- Release-build, architecture-test, coverage, coverage-gate, SonarQube and local quality-gate PowerShell scripts.
- Coverage settings and baseline quality-tooling documentation.
- Development dependency/license inventory.

### Previous-step validation
- Version 0.3.1 Release x64 ArchitectureTests: PASS based on user-supplied output `ARCHITECTURE TESTS: PASS`.

### Validation
- Version 0.4.0 agent execution status: NOT VERIFIED.
- User must execute the quality tooling on the real workstation and provide results.
- SonarQube remains AWAITING USER EXECUTION until an approved server/project/token are available.

## 0.3.1 — 2026-09-17

### Fixed
- Added the missing .NET Framework `System.Xml` assembly reference required by the ArchitectureTests project when using `System.Xml.Linq`.

### Validation
- Root cause identified from user-supplied build output: `XmlReader` could not be resolved because `System.Xml` was not referenced.
- Version 0.3.1 Release x64 ArchitectureTests: PASS based on user-supplied output `ARCHITECTURE TESTS: PASS`.

## 0.3.0 — 2026-09-17

### Added
- Executable `CimatronCustomization.ArchitectureTests` project under `tests/`.
- Automated checks for approved project-reference direction and Hexagonal boundaries.
- Guards preventing direct Cimatron dependencies in Domain, Application, DesignChecks, Automations, and Infrastructure.
- Guards preserving DesignChecks/Automations separation and the thin Plugin boundary.

### Changed
- Solution includes the ArchitectureTests project.
- Product assembly version metadata advanced to 0.3.0.0; production behavior is otherwise unchanged.

### Previous-step validation
- Version 0.2.0 Release x64 solution rebuild: PASS based on user-supplied evidence (7 succeeded, 0 failed, 0 skipped).
- Version 0.2.0 Cimatron command regression: PASS based on user-supplied runtime feedback.

### Validation
- Version 0.3.0 agent execution status: NOT VERIFIED.
- User must run Release x64 rebuild and execute the ArchitectureTests harness.

## 0.18.1 — 2026-09-28

### Added
- Consumer-neutral `TabularMappingEngine` in Application.
- Deterministic header-resolution result/error contracts.
- Deterministic mapped-row validation result/error contracts.
- Header resolution across configured primary/alias names, case-insensitively.
- Fail-closed validation for missing required headers, ambiguous alias matches, duplicate physical headers, missing required logical values, and logical value-type mismatches.
- Focused Application tests for header resolution and mapped-row validation.

### Security / privacy
- Mapping errors identify logical fields and source row numbers where needed, but do not echo customer cell values.

### Previous-step validation
- User-supplied 0.18.0 quality gate: Release x64 PASS; Architecture/Domain/Application/Cimatron Integration/Infrastructure tests PASS; Application coverage 95.89%; Infrastructure coverage 91.02%; coverage/local quality gates PASS; exit code 0.

### Scope control
- No ExcelDataReader/Infrastructure reader behavior change.
- No Plugin/Cimatron behavior change.
- No CR-04 steel-grade comparison or CR-22 finger-pin lookup/business rules.
- Reader orchestration/integration is deferred to Step 06D.

### Validation
- 0.18.1 agent execution status: NOT VERIFIED.
- User must run the standard captured quality gate and provide the resulting evidence.

## 0.18.1 — 2026-09-28 — Session Handoff Documentation Refresh

### Session handoff/documentation checkpoint
- Expanded the 0.18.1 Step 06C2 handoff to the full `AGENTS.md` handoff schema: approved checkpoint, scope, completed/pending work, files added/modified, approved existing-file changes, tests/gate status, known issues/limitations, decisions, API findings, exact next action, read-first list, and continuation prompt.
- No production behavior or 06C2 implementation logic changed by this documentation checkpoint.
- 0.18.1 remains AWAITING USER QUALITY GATE; the handoff does not convert the candidate to an approved checkpoint.

## 0.18.2 — 2026-09-28 — Pre-06C3 Analyzer Warning Cleanup

### User-supplied evidence entering change
- 0.18.1 captured quality gate: Release x64 build PASS; Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS; coverage gate PASS; local quality gate PASS; exit code 0.
- Build completed with 20 analyzer warnings: 2 `CA1822` findings in `TabularMappingEngine` and 18 `CA1861` findings in `TabularMappingEngineTests` / `TabularMappingContractTests`.
- Step 06C2 was explicitly approved/closed by the user after review of that evidence.

### Changed
- Preserved the intentional instance-service API of `TabularMappingEngine` and added narrow, documented `CA1822` suppressions to `ResolveHeaders` and `ValidateRows`; no method behavior changed.
- Replaced repeated constant string-array arguments in the focused Application mapping tests with named `static readonly` fixtures, addressing the 18 `CA1861` findings without disabling the analyzer rule globally.
- Advanced the Application assembly/product checkpoint to `0.18.2` and added a dedicated warning-cleanup session handoff.

### Scope control
- No mapping semantics, result/error codes, customer-value disclosure policy, Infrastructure reader behavior, Plugin/Cimatron behavior, CR-04/CR-22 business logic, dependency version, or architecture rule changed.
- This is not Step 06C3 implementation.

### Validation
- AI agent did not build, run tests, or execute Cimatron, per `AGENTS.md`.
- 0.18.2 is **AWAITING USER QUALITY GATE**. Expected acceptance condition: the standard captured gate passes and the prior 20 analyzer warnings are absent.

## 0.18.3 — 2026-09-28 — Step 06C3 Integration Verification

### Previous checkpoint validation
- User-supplied 0.18.2 captured quality gate: Release x64 build PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration and Infrastructure tests: PASS.
- Coverage gate: PASS.
- Local quality gate: PASS.
- Exit code: 0.
- The user explicitly approved proceeding to Step 06C3 after review of this evidence.

### Added
- `TabularMappingIntegrationTests` in the Application test project.
- Integration-style verification that resolved 06C1/06C2 mapping columns can populate the existing `TabularSourceDefinition` contract and that resulting `TabularTable` rows validate through `TabularMappingEngine`.
- Verification that optional mappings remain omitted without invalidating consumer-neutral rows.
- Verification that ambiguous header resolution fails before a downstream reader source can be constructed.
- Verification that invalid mapped rows fail closed, preserve source-row error context, expose no consumer rows, and do not leak customer values in error messages.

### Scope control
- No production source behavior changed.
- No `ExcelTabularDataReader` orchestration added; that remains Step 06D.
- No CR-04 / CR-22 business logic added.
- No Plugin/Cimatron behavior changed.
- No dependency or architecture-boundary change.

### Validation
- AI agent did not build, run tests, or execute Cimatron, per `AGENTS.md`.
- 0.18.3 is AWAITING USER QUALITY GATE.

## 0.18.3 — 2026-09-28 — Step 06C Validation Closure / Documentation Refresh

### Validation / approval
- User-supplied `quality-gate-20260928-151541.txt` confirmed Release x64 build PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS.
- Application coverage 96.35%, DesignChecks 100%, Infrastructure 91.84%; CimatronIntegration 4.57% measured with no Step 05B2 threshold.
- Coverage gate PASS; local quality gate PASS; exit code 0.
- User explicitly approved Step 06C closure after review of the evidence.

### Documentation closure
- Step 06C3 is now VALIDATED / APPROVED.
- Step 06C overall is now CLOSED / APPROVED.
- Added `docs/history/session-handoffs/phase-02-step-06c-to-step-06d-session-handoff-0.18.3.md`.
- Updated `VERSION.md` and appended the authoritative post-validation closure record to the 06C3 handoff.
- No production source, test behavior, project registration, dependency, or Cimatron behavior changed in this documentation-only refresh.
- Step 06D is the next eligible step but remains NOT STARTED pending plan/scope approval under `AGENTS.md`.


## 0.18.3 — 2026-09-28 — AGENTS CSV Time-Ledger Policy Migration

### Documentation / governance
- Replaced `AGENTS.md` with the user-supplied revision that makes `docs/time-tracking/PROJECT-TIMESHEET.csv` the single authoritative engineering-time ledger.
- Migrated the measured `TT-BOOTSTRAP-001` record from the previous Markdown timesheets into the CSV ledger without inventing unavailable timestamps.
- Removed `docs/time-tracking/PROJECT-TIMESHEET.md` and `docs/time-tracking/phase-02-timesheet.md` because the new policy explicitly forbids duplicate phase-wise Markdown timesheets.
- Added the current AGENTS/CSV migration submission cycle to the CSV with user-feedback/closure fields left empty until actual feedback is received.
- No production source, tests, project files, dependency versions, or Cimatron behavior changed.

## 0.18.3 — 2026-09-28 — CSV Time-Ledger Migration Validation Closure

### Validation
- User-supplied `quality-gate-20260928-154231.txt` confirmed Release x64 build PASS with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration and Infrastructure tests PASS.
- Coverage gate PASS; local quality gate PASS; exit code 0.
- Closed `TT-CSV-MIGRATION-001` in `docs/time-tracking/PROJECT-TIMESHEET.csv` with the observed feedback timestamp, feedback-wait duration and closure timing.
- No production source, tests, project files, dependency versions, or Cimatron behavior changed.

## 0.19.0 — 2026-09-28 — Step 06D Reader Orchestration

- Added Application header-discovery contracts while preserving `TabularSourceDefinition` mapping invariants.
- Added two-pass source consistency protection: the row-reading pass rejects a header row that differs from the snapshot used for mapping with `TABULAR_HEADERS_CHANGED`.
- Applied existing reader file-format and maximum-file-size controls to header discovery.
- Added consumer-neutral `ReadMappedTabularData` orchestration for discovery → mapping → read → validation.
- Combined orchestration result uses the canonical Step 01 `ResultStatus` enum; no new success/failure status model is introduced.
- Added focused Application orchestration tests and Infrastructure discovery/header-change tests.
- Updated the real Cimatron in-process tabular probe to call `ReadMappedTabularData` and added `Start-Step06DTabularProbe.ps1`.
- Updated Step 06 platform documentation and session handoff; updated the authoritative CSV time ledger.
- No CR-04/CR-22 logic, customer layout assumptions, Plugin UI change, Cimatron model modification, or dependency upgrade.
- Status: AWAITING USER QUALITY GATE AND LIVE CIMATRON PROBE.


## 0.19.1 — 2026-09-28 — Step 06D Quality-Gate Corrective Patch

- User quality-gate evidence for 0.19.0 reported 4 analyzer warnings and `APPLICATION TESTS: FAIL` / exit code 1.
- Corrected `ReadMappedTabularData` analyzer findings (`CA1826`) without behavior change.
- Corrected new Application test analyzer findings (`CA1861`, `CA1825`).
- Fixed the validation-stage test fixture so it no longer violates `TabularTable` construction invariants before orchestration validation executes.
- No reader/orchestration/probe architecture change and no CR/customer-specific behavior added.
- Status: AWAITING USER QUALITY GATE.

- **0.19.1 validation update:** User workstation quality gate confirmed the Step 06D corrective patch with 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, and exit code 0. Live Step 06D Cimatron probe remains pending.


### 0.19.1 — Step 06D live validation closure

- User live Cimatron probe executed inside `CimatronE` and returned `ProbeResult: PASS`.
- `ReadMappedTabularData` completed with stage `Completed`, one row, and expected known-answer values from `LegacyInput.xls`.
- Runtime evidence confirms `ExcelDataReader` 3.9.0.0 loaded from the Cimatron Program directory.
- Step 06D is validated. No production/source/test behavior changed by this closure update.
- Step 06 now has all planned WP8 implementation evidence; only explicit Step 06 closure approval remains.

## 0.19.1 — 2026-09-28 — Step 06 Overall Closure

- User explicitly approved Step 06 overall closure after the 0.19.1 clean quality gate and successful live in-process Cimatron mapped-tabular probe.
- Step 06 is now **CLOSED / APPROVED** against the WP8 definition of done: reader, configuration mapping, controlled failure modes, dependency/runtime approval, orchestration, and live probe evidence are complete.
- Added the Step 06 closure session handoff.
- No production/source/test behavior changed by this closure documentation update.
- The next implementation step must be identified from the governing Phase 02 roadmap/requirements and separately planned/approved; Step 06 must not grow another architecture sub-step.


### 0.19.1 — Step 06 final closure validation

- User workstation closure-package quality gate passed with 0 warnings / 0 errors, all governed test suites PASS, coverage gate PASS, local quality gate PASS, and exit code 0.
- Step 06 overall is now VALIDATED / CLOSED.
- Documentation/time-ledger/checksum update only; no production/source/test behavior change.


## 0.19.1 — 2026-09-28 — Step 06E Documentation Alignment / Deferred-Findings Register

- Corrected traceability so the already-completed real-workstation sample-file validation and formal closure are explicitly classified as **06E — Live Validation & Closure**.
- Added `docs/platform/STEP-06-DEFERRED-FINDINGS.md` with six non-blocking findings and mandatory carry-forward ownership to CR-04, CR-22, D5/client packaging, or generic release hardening.
- Preserved historical evidence filenames (including the `step06d-...` probe) without rewriting evidence.
- No source, test, project, dependency, or runtime behavior changed.


### 0.19.1 — Step 06E documentation-alignment validation

- User workstation quality gate `quality-gate-20260928-164128.txt` passed with 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration, and Infrastructure test suites PASS.
- Coverage gate and local quality gate PASS; exit code 0.
- 06E documentation alignment is VALIDATED / CLOSED.
- Deferred findings remain open carry-forward obligations; no source/test/runtime behavior changed.


## 0.20.0 — Phase 02 Step 07 — Cimatron API Capability Verification

- Added development-only `CimatronCustomization.ApiCapabilityVerification` x64/.NET Framework 4.8 diagnostic project.
- Added 07A installed-Interop reflection-only inventory for the Step 07 target interfaces/enums; this path performs no Cimatron runtime attach.
- Added 07C-1 geometry, 07C-2 assembly-context, 07C-3 component-property/BOM, and approved 07C-4 hidden-state candidate probes.
- Added before/after model-file and `IsModified` no-mutation evidence to every live mode; any `CHANGED_OR_UNVERIFIED` result is a failed run.
- BOM export is restricted to a newly created `%TEMP%\CimatronCustomization\Step07\<timestamp>\` folder.
- Added architecture guards enforcing the development-only boundary, reflection-only 07A path, prohibited mutation tokens, temporary selection restoration, and temp-only BOM output.
- Added `STEP-07-KNOWN-ANSWER-MODELS.md`, the initial API capability verification register, Step 07 handoff, PowerShell capture helper, time-ledger entry, and regenerated checksums.
- Production `src/**`, `config/**`, existing ZoomCommandDiscovery sources, and unrelated tests are intentionally unchanged.
- Validation: **AWAITING USER EXECUTION**. No build/test/Cimatron PASS is claimed by the agent.


## 0.20.1 — 2026-09-29 — Step 07 Quality-Gate Corrective Patch

- User workstation quality gate `quality-gate-20260929-141352.txt` failed during the Release x64 build with 0 warnings / 12 errors, all in the new Step 07 development-only verification project.
- Added the missing `Microsoft.CSharp` framework reference required by installed COM interop conversions.
- Corrected installed-Interop variant/object return handling for geometry array results and assembly bounding-box results.
- Corrected `get_SubInstances(1, 0)` observation typing.
- Corrected `GetEntityPointDistance` to the installed signature with `out IPointData`.
- No production source/configuration/Plugin behavior, existing ZoomCommandDiscovery source, CR/SA behavior, or Step 06 deferred finding changed.
- Validation: **AWAITING USER QUALITY GATE**. No PASS is claimed.


## 0.20.1 — 2026-09-29 — Step 07 Quality-Gate Validation

- User workstation quality gate `quality-gate-20260929-142529.txt` passed with Release x64 build PASS, 0 warnings / 0 errors.
- Architecture, Domain, Application, Cimatron Integration, and Infrastructure test suites PASS.
- Coverage gate and local quality gate PASS; exit code 0.
- This validates the 0.20.1 compile corrective only; Step 07 capability evidence still required 07A/07C execution.

## 0.20.2 — 2026-09-29 — Step 07 Reflection-Only Enum Corrective

- First user-run 07A on 0.20.1 failed with `InvalidOperationException: Code execution is prohibited in an assembly loaded as ReflectionOnly.`
- Root cause: enum inventory called `Enum.GetNames` / `Enum.Parse` on enum `Type` objects loaded by `ReflectionOnlyLoadFrom`.
- Replaced enum parsing/execution with metadata-only public static field enumeration and `FieldInfo.GetRawConstantValue()`.
- No Cimatron runtime attach, production source/configuration/Plugin behavior, existing ZoomCommandDiscovery source, CR/SA behavior, or Step 06 deferred finding changed.
- Validation: **AWAITING USER QUALITY GATE**. No PASS is claimed for 0.20.2.


## 2026-09-29 — Step 07 Session Handoff — 0.20.2

- User workstation quality gate `quality-gate-20260929-143207.txt`: PASS, 0 warnings / 0 errors, all governed test suites PASS, coverage/local gates PASS, exit code 0.
- User-run 07A reflection inventory `api-capability-reflection-20260929-143432.txt`: COMPLETE; footer confirms `RuntimeCalls: NONE`.
- Verification register updated with evidence-backed installed signatures. Runtime capability statuses remain pending 07C, except the instance-attribute getter is recorded `NOT AVAILABLE` because 07A shows `IAssInstance.Attribute` is SET-ONLY.
- KA-PART-1 preparation observed with two bodies, through-hole, `KA_UCS_90Z`, and part/model material `1.2738`; body-level custom attribute is not claimed.
- User explicitly stated that KA-ASM-1 is ready for continuation. Final ids/transforms/lock/gap values remain to be recorded before runtime comparison.
- No production or Step 07 tool code change. Documentation/time-ledger/handoff/checksum update only.
- Next session starts with 07C-1 preparation/execution against KA-PART-1; do not jump to 07C-2/3/4.

## 0.20.4 — 2026-09-29 — Step 07C-1C Current Selection ID Inspection

- Added development-only `--inspect-current-selection --expect Part` to read the user's existing Cimatron selection without changing it.
- Records selected entity count, actual entity IDs/types, and read-only edge convexity at parameter `0.5` for selected edges.
- Preserves Step 07 before/after no-mutation evidence; the new mode contains no selection assignment.
- Carried forward user workstation 0.20.3 evidence: clean quality gate, successful geometry target discovery, `KA_UCS_90Z` mapped to active UCS entity ID 2 after explicit activation, B1/B2 visual mapping, and 25 mm body-pair distance.
- The visually chosen test face still has no recorded entity ID; 0.20.4 exists to capture it without guessing. Convex/concave target edge IDs remain pending.
- No production `src/**`, Plugin/configuration, CR/SA behavior, or 07C-2/3/4 change.
- Validation: **AWAITING USER QUALITY GATE + LIVE SELECTION INSPECTION**. Agent did not run build/tests/Cimatron.


## 0.20.8 — 2026-09-29 — Step 07C-1R Session Handoff / Evidence Alignment

- Documentation-only handoff; no production, diagnostic, test, config, or model behavior changed.
- Records user workstation 0.20.7 quality-gate PASS (`quality-gate-20260929-190027.txt`).
- Records live discovery `api-capability-geometry-known-answer-discovery-20260929-190407.txt` and live geometry evidence `api-capability-geometry-20260929-191114.txt`.
- Reclassifies `IGeomServices.SurfacesArea` as **NOT AVAILABLE** in installed Cimatron 2026 SP2P1 Interop; it is not BLOCKED because the member is absent.
- Records UCS 249 only as a second/reference UCS candidate. UCS 2 and 249 have parallel axes in the observed evidence, so rotated-axis `GetBoundingBoxByUCS` semantics remain unverified.
- Records final known-answer inputs proposed for `GetEntityPointDistance` and `GetPiercingPoints`; those APIs remain NOT TESTED until the controlled final 07C-1 run.
- Carries forward a proposed 30° Z-rotated UCS check for 07C-1R2; no such model/tool change is implemented in this handoff.
- 07C-1 remains OPEN; 07C-2 remains BLOCKED pending explicit user closure approval.


## 0.20.13 — 2026-09-30 — Step 07C-1R5 Final Geometry Semantics Run Preparation

- Re-analysed existing 07A reflection evidence before requesting any additional live run. Installed signature is `GetPiercingPoints(iDirection, iBasePositin, iEntList)`.
- Identified the diagnostic argument-order defect: 0.20.12 passed `(origin, direction, targets)` instead of `(direction, basePosition, targets)`.
- Confirmed the 0.20.12 returned points lie exactly on the lines implied by the swapped calls; the intended “miss” and “pointing away” cases therefore cannot answer ray-vs-infinite-line semantics.
- Corrected only the development diagnostic mapping and added explicit evidence of direction/base-position inputs.
- Final live batch is fixed at four piercing cases, two entity-point-distance cases, the UCS 251/reference 2 rotated-UCS check, and no-mutation evidence.
- Per user instruction, that next live geometry run is the final 07C-1 runtime experiment. Any remaining uncertainty is to be documented as a limitation and 07C-1 then closes.
- No production `src/**`, Plugin, CR/SA behavior, configuration, or model data changed.
- Validation: **AWAITING USER QUALITY GATE + FINAL LIVE RUN**. Agent did not build/test/run Cimatron.

## 0.20.14 — 2026-09-30 — 07C-1 Closure Session Handoff

- Added a new-session handoff recording the approved 07C-1 closure and final evidence state.
- Recorded that 07C-2 is unblocked but not started and still requires explicit scope approval.
- Updated the authoritative project time ledger and checksum manifest.
- No production/runtime/test/model behavior change.


## 0.20.17 — 2026-09-30 — 07C-2 Closure / Session Handoff

- Recorded workstation quality-gate PASS for 0.20.17 and the single approved live assembly-context run.
- Promoted U7/U8/U9/U10/U12 from pending to evidence-backed VERIFIED; U11 to PARTIALLY VERIFIED because UI assembly extents were unavailable for independent numeric comparison.
- Recorded user confirmation that all three highlighted bodies were correct, final selection was empty, no unsaved-change indicator remained, and 07C-2 closure was approved.
- Recorded direct cross-occurrence `MinDistancePos` as an assembly-placement limitation: all three pairs returned 0 despite distinct occurrence transforms and the independent 25.000 mm top-level B1 gap.
- Added final 07C-2 evidence files and a new-session closure handoff.
- Documentation/evidence only; no production, verifier runtime, test, configuration or model behavior changed.


## 0.20.27 — Phase 02 / Step 07C-4 Closure

- Closed Step 07C-4 after user workstation validation of the corrected U16 known-answer model.
- Archived final 0.20.26 quality evidence and controlled live evidence, plus the earlier governed blocked/diagnostic attempts needed for traceability.
- Promoted U16 to VERIFIED for the approved scope: `ICimEntity.Show` is body/entity visibility only; `cmVisibleOnly` BOM membership distinguishes the known hidden assembly occurrence.
- CR-11 FR-021 hidden-component detection is therefore supported by the read-only BOM filter route, subject to Step 08 in-process confirmation before production use.
- Final model no-mutation evidence: UNCHANGED.
- Documentation, capability register, history, session handoff, time ledger, evidence retention, version, and checksums only.
- No production `src/**`, Plugin, configuration, installer, CR/SA behavior, diagnostic runtime code, or model behavior changes.

## 0.20.28 — 2026-10-01 — Step 07D Verification Register and Promotion Recommendations

- Finalizes the Step 07 evidence register as the formal Step 08 eligibility gate.
- Defines the rule that only final-status `VERIFIED` capabilities may enter Step 08 in-process confirmation or later production-port / first-CR-slice consideration.
- Whitelists U1, U3, U4, U5, U6, U7, U8, U9, U10, U12, U13, U15 and U16 for Step 08 in-process confirmation.
- Excludes U2 and U11 because they remain `PARTIALLY VERIFIED` and excludes U14/U17 because no evidence-backed readable API is available for the required use.
- Retains the exact U16 semantic split: `ICimEntity.Show` for body/entity visibility; `cmVisibleOnly` BOM membership for hidden occurrence detection.
- Carries `ST06-DF-01` through `ST06-DF-06` forward unchanged as `DEFERRED`.
- Documentation/governance only; no production source, Plugin, configuration, installer, diagnostic runtime, test, CR/SA, or model behavior changed.
- Status: **IMPLEMENTATION PREPARED / AWAITING USER REVIEW**. Step 08 is not started.
