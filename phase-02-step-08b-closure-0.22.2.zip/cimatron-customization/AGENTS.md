# AGENTS.md

# MUST READ / MUST FOLLOW — BEFORE ANY WORK

Every AI agent, developer, reviewer, coding assistant, or automation assistant working on this repository **must read this entire file before planning, editing, generating, testing, packaging, or recommending implementation changes**.

Reading only selected sections is not sufficient.

Before implementation, the agent must:

1. Read this full `AGENTS.md`.
2. Read the relevant requirement/specification.
3. Read the relevant `IMPLEMENTATION-HISTORY.md`, `CHANGELOG.md`, and `VERSION.md`.
4. Understand the current architecture and latest approved package/version.
5. Verify any uncertain Cimatron API behavior.
6. Prepare a clear execution plan.
7. Break work into meaningful necessary steps.
8. List new files to be created.
9. List every existing file proposed for modification.
10. Explain why each existing-file modification is necessary.
11. Identify assumptions, risks, tests, quality gates, and Cimatron validation required.
12. Present the plan to the user.
13. **Wait for explicit user approval before implementation.**

If scope changes, a blocker appears, or an extra change becomes necessary, stop and obtain approval again.

---

# NON-NEGOTIABLES

1. **Production-grade only.** This system is for real Cimatron client deployments.
2. **Read this entire file before acting.**
3. **Approval is mandatory before implementation.**
4. **Approval is scope-specific.** One approved step does not authorize unrelated work.
5. **Existing files are protected by default.**
6. **Prefer new files for new capability when technically reasonable.**
7. **Anything outside the approved scope must remain byte-for-byte identical.**
8. **No unnecessary changes.** No unrelated refactoring, formatting, renaming, dependency upgrades, cleanup, restructuring, or warning fixes.
9. **No silent fixes.** Report unrelated defects and request approval before fixing them.
10. **TDD is the default development mode.**
11. **Cimatron API facts must be verified. Never invent API names, signatures, enums, procedures, or behavior.**
12. **Official Cimatron SDK + installed target-version Interop + verified runtime behavior are authoritative.**
13. **Business class names must be self-explanatory. CR/SA IDs are traceability metadata, not primary class names.**
14. **Read-only checks must remain read-only.**
15. **API/runtime errors must never be reported as business-rule failures.**
16. **No swallowed exceptions.**
17. **No undocumented hard-coded customer assumptions.**
18. **Quality gates are mandatory.**
19. **Every change is traceable.**
20. **Every progressive ZIP is cumulative and self-contained.**
21. **Every progressive ZIP must follow the required naming convention.**
22. **Every ZIP must extract to exactly `cimatron-customization/`.**
23. **SHA-256 file checksums and package checksum are mandatory.**
24. **Unexpected checksum changes block delivery.**
25. **Development assets remain private and are not shipped to clients.**
26. **Do not claim production readiness unless all applicable gates pass.**
27. **Session context health is mandatory: GREEN / AMBER / RED.**
28. **When uncertain, stop and ask. Do not guess or silently broaden scope.**
29. **AI agent does not execute build/tests/Cimatron validation.** The user runs them and supplies feedback; the agent only prepares implementation, checksums, packaging, instructions, and analysis of supplied results.
30. **Mandatory C#/.NET quality stack:** Visual Studio 2026 + Roslyn/.NET analyzers + `.editorconfig` + unit/architecture tests + SonarQube Community Build.
31. **Engineering time and delivery tracking is mandatory.** Every approved implementation phase/step/task must be recorded in the authoritative CSV time ledger, including agent work timing, ZIP/output submission timestamp, user feedback timestamp, feedback-wait duration, rework time, and calendar elapsed time. Waiting for user execution/feedback must never be counted as agent active development time.

These rules override convenience, speed, cleanup preference, or agent preference.

---

## 1. Purpose

This file governs the Cimatron customization platform.

The current CR/SA items are examples only. The architecture must support many future customization requests without becoming a collection of unrelated scripts.

---

## 2. Technology Baseline

Unless explicitly changed by approved architecture decision:

- Language: C#
- IDE: Visual Studio 2022
- Runtime: .NET Framework 4.8
- Platform: x64
- Production delivery: Cimatron Plugin DLL
- Integration: Cimatron COM/Interop SDK
- Developer diagnostics: optional external EXE
- Initial supported Cimatron version: 2026.x
- Client deployment: installer-based

Client machines do not receive source code, `.sln`, development project files, `AGENTS.md`, internal architecture, implementation history, test source, or API research.

---

## 3. Source of Truth

Use this priority:

1. Official live Cimatron SDK documentation.
2. Installed target-version Interop assemblies/type information.
3. Verified behavior in the real supported Cimatron environment.
4. Cimatron Journaling output.
5. Official Cimatron examples.
6. Approved project architecture and requirements.
7. General engineering knowledge.

`agent-notes` are optional developer reference material only. They are not required and never override authoritative sources.

If an API detail is uncertain, verify it. Do not guess.

---

## 4. Architecture

Use pragmatic Clean/Hexagonal architecture.

```text
Cimatron / COM / UI / Filesystem / External Systems
                     |
                  Adapters
                     |
               Application
                     |
                  Domain
```

Dependencies point inward.

Domain/business logic must not directly depend on Cimatron COM, UI, filesystem paths, installer logic, or logging framework details.

Avoid unnecessary microservices, event sourcing, full CQRS, mediator chains, or framework-heavy abstractions unless a real requirement justifies them.

Recommended structure:

```text
cimatron-customization/
|
|-- CimatronCustomization.sln
|-- src/
|   |-- CimatronCustomization.Domain/
|   |-- CimatronCustomization.Application/
|   |-- CimatronCustomization.CimatronIntegration/
|   |-- CimatronCustomization.DesignChecks/
|   |-- CimatronCustomization.Automations/
|   |-- CimatronCustomization.Infrastructure/
|   |-- CimatronCustomization.Plugin/
|   `-- CimatronCustomization.DeveloperDiagnostics/
|
|-- tests/
|-- docs/
|-- installer/
|-- tools/
|-- AGENTS.md
|-- README.md
|-- BUILD.md
|-- RUN.md
|-- DEPLOYMENT.md
|-- CHANGELOG.md
|-- IMPLEMENTATION-HISTORY.md
|-- VERSION.md
`-- CHECKSUMS.sha256
```

### Layer responsibilities

**Domain**
- pure business models;
- calculations;
- rule results;
- statuses;
- tolerances;
- domain exceptions;
- no Cimatron references.

**Application**
- use cases;
- orchestration;
- validation/automation runners;
- result aggregation;
- dependency abstractions.

**Cimatron Integration**
- COM/Interop adapters;
- document access;
- selection;
- geometry;
- topology;
- assembly;
- measurement;
- procedures;
- interference;
- entity resolution.

**Design Checks**
- read-only validation rules.

**Automations**
- operations that modify, create, export, engrave, route, move, or generate Cimatron content.

**Infrastructure**
- logging;
- configuration;
- reports;
- filesystem;
- serialization;
- diagnostics;
- versioning.

**Plugin**
- production Cimatron entry point;
- command/UI shell;
- top-level exception boundary;
- no substantial business logic.

**Developer Diagnostics**
- developer-only API experiments and diagnostics;
- not part of normal client product.

---

## 5. Design Patterns

Use only when they solve a real problem:

- **Adapter** — isolate Cimatron COM/Interop.
- **Strategy** — independent design validations.
- **Command** — modifying automations/user actions.
- **Registry** — register validations/automations without large switches.
- **Result** — structured outcomes instead of exceptions for normal rule results.
- **Policy/Configuration** — client-specific standards/tolerances.
- **Facade** — simplify complex Cimatron geometry/topology workflows.
- **Factory** — selectively for controlled Cimatron object/procedure creation.

Do not use patterns mechanically.

---

## 6. Naming Rules

Use business-descriptive names.

Good:

```csharp
// CR-24: Verify wedge angle equals finger angle plus configured offset.
public sealed class WedgeFingerAngleValidation
{
}
```

Avoid:

```csharp
public sealed class CR24Check
{
}
```

Prefer names such as:

- `WedgeFingerAngleValidation`
- `BearingSurfaceDraftValidation`
- `SlenderSteelDetection`
- `CoolingLoopContinuityValidation`
- `FullAssemblyInterferenceValidation`

Avoid vague names such as:

- `Check1`
- `Helper`
- `Common`
- `Utils`
- vague `Manager`
- vague `Processor`

Methods must describe behavior:

```csharp
CalculateDraftAngle(...)
IdentifyBearingSurfaces(...)
MeasureGuidingLength(...)
ResolveActivePart(...)
```

CR/SA identifiers remain in comments, metadata, reports, tests, requirement files, configuration where useful, and history.

---

## 7. Coding Rules

Mandatory:

- isolate business logic from COM;
- prefer immutable models;
- prefer pure functions for calculations;
- keep methods cohesive;
- avoid global mutable state;
- avoid service locators;
- validate COM casts;
- validate active document and document type;
- validate geometry type before type-specific operations;
- avoid long-lived raw COM object references unless verified safe;
- avoid undocumented reflection/dynamic API access;
- avoid developer-specific absolute paths;
- avoid hard-coded client values where configuration is appropriate;
- no debug message boxes in production logic;
- no temporary/experimental code in production modules;
- meaningful compiler warnings are defects.

---

## 8. Cimatron API Rules

Before execution verify:

- Cimatron application is available;
- active document exists;
- document type is supported;
- required part/assembly context exists;
- required selections exist.

Before geometry operations:

- determine entity type;
- determine surface/curve type;
- reject unsupported geometry safely;
- record unsupported cases.

For Cimatron 2026+, prefer documented topology interfaces such as:

- `IBody`
- `IFace`
- `IEdge`
- `IVertex`

Do not assume observed entity IDs are persistent.

Use Journaling for discovery/verification, not as production-ready code.

Use documented procedure interfaces and validate inputs/outputs.

Do not call Cimatron COM APIs from arbitrary background threads unless officially supported.

Document version-specific behavior.

---

## 9. TDD and Testing

Default workflow:

```text
Requirement
  -> Acceptance Criteria
  -> Failing Test
  -> Minimum Implementation
  -> Passing Test
  -> Refactor
  -> Cimatron Integration Validation
  -> Regression Validation
  -> Documentation
```

### Unit tests
Use for logic that does not require Cimatron:

- angle calculations;
- tolerances;
- ratios;
- thresholds;
- configuration validation;
- result mapping.

### Integration tests
Use real supported Cimatron for:

- connection;
- active document access;
- selection;
- topology;
- geometry;
- procedures;
- assembly traversal;
- interference;
- export.

### Real Cimatron Validation Cannot Be Replaced by Mocks

Mocks, fakes, and test doubles are useful for validating our own business logic and application orchestration.

They do **not** prove compatibility with Cimatron.

A mocked Cimatron interface cannot satisfy the Cimatron Integration Quality Gate.

Any feature that depends on Cimatron COM/Interop behavior must be validated against the actual supported Cimatron environment before the integration gate can pass.

### Regression tests
Every defect fix should add a regression test whenever technically feasible.

### Client acceptance tests
Use approved real or representative CAD samples and record expected vs actual results.

---

## 10. Standard Result States

Use:

- `Passed`
- `Failed`
- `Warning`
- `Error`
- `NotApplicable`
- `Skipped`
- `Unsupported`

`Failed` means the business rule was evaluated successfully and violated.

`Error` means the software/API could not evaluate reliably.

Never convert an API/runtime exception into `Failed`.

---

## 11. Error Handling

No empty catch blocks.

Use clear exception categories when useful, for example:

- `CimatronConnectionException`
- `NoActiveDocumentException`
- `UnsupportedDocumentException`
- `EntityResolutionException`
- `UnsupportedGeometryException`
- `GeometryEvaluationException`
- `ConfigurationException`
- `RuleExecutionException`

User-facing errors must be actionable.

Technical diagnostics belong in logs.

---

## 12. Logging

Use structured logging.

Capture at least:

- timestamp;
- level;
- correlation/run ID;
- application version;
- Cimatron version;
- feature;
- requirement ID;
- operation;
- status;
- duration;
- exception context.

Use bounded rolling logs.

Do not log unnecessary proprietary geometry or sensitive client data.

---

## 13. Configuration

Customer-specific values belong in configuration/policies where appropriate.

Examples:

- tolerances;
- angle offsets;
- ratios;
- minimum distances;
- naming rules;
- colors;
- material tables;
- folders;
- catalogs;
- mappings.

Configuration must be versioned, validated, documented, and safely migrated.

Never silently fall back to unsafe defaults.

---

## 14. Requirement Traceability

Each customization must record at least:

```text
Requirement ID
Business Name
Description
Acceptance Criteria
Inputs
Outputs
Dependencies
Cimatron APIs
Configuration
Failure Modes
Tests
Implementation Version
Known Limitations
```

---

## 15. Coverage Gates

Coverage is a quality gate.

Minimum targets unless explicitly approved otherwise:

| Area | Minimum Line Coverage | Branch Expectation |
|---|---:|---:|
| Domain | 90% | 85%+ |
| Application | 90% | 85%+ |
| Design-rule logic | 95% | 90%+ |
| Infrastructure | 80% | Risk-based |
| New/changed code | 90% | 85%+ |
| Critical calculations/safety logic | 95%+ | 100% where practical |

Cimatron COM/Interop adapters may have lower unit-test coverage when mocks provide little value, but critical paths require real integration testing.

Coverage must not be inflated with trivial tests.

Release fails when required coverage is below threshold or critical changed logic is untested.

---

## 16. Static Analysis and Code Quality

At minimum:

- no build errors;
- no new critical/high-severity static-analysis findings;
- no unresolved compiler warnings of concern;
- no known blocking security findings;
- no swallowed exceptions;
- no obvious dead code;
- no duplicated critical business logic;
- no forbidden debug/test code in production packages;
- no known uncontrolled resource leaks.

If an approved SonarQube/SonarCloud or equivalent gate is introduced, it becomes part of release qualification.

---

## 16A. Mandatory C#/.NET Quality Tooling Stack

The following quality stack is mandatory for this project unless the user explicitly approves a replacement:

```text
Visual Studio 2026
+ Roslyn/.NET analyzers
+ .editorconfig
+ Unit tests
+ Architecture tests
+ SonarQube Community Build
```

These tools have different responsibilities and must be treated as complementary, not interchangeable.

### Visual Studio 2026

Used by the user for:

- Release builds;
- compiler diagnostics;
- test execution;
- debugging;
- integration with the configured analyzers.

The agent prepares the solution/configuration and run instructions. The user executes them on the real development workstation.

### Roslyn / .NET Analyzers

Used for:

- C# correctness;
- maintainability;
- API usage;
- performance-related diagnostics;
- security-related diagnostics;
- compiler-integrated code-quality rules.

Analyzer severities must be configured deliberately. Critical project rules must not depend only on IDE suggestions.

### `.editorconfig`

The repository must use `.editorconfig` to keep code-style and analyzer behavior consistent across AI-generated code, Visual Studio, and occasional minimal human corrective edits.

It must not be used as justification for broad automatic reformatting of unrelated files.

Files outside the approved scope must remain byte-identical.

### Unit Tests

Unit tests validate:

- domain calculations;
- tolerances;
- business decisions;
- configuration behavior;
- result mapping;
- pure application logic.

Mocks/fakes may be used for our own logic, but they do not prove Cimatron compatibility.

### Architecture Tests

Architecture tests must enforce project-specific dependency and boundary rules that generic analyzers cannot reliably understand.

At minimum, architecture tests should protect rules such as:

```text
Domain MUST NOT reference Cimatron Interop.

Domain MUST NOT reference CimatronIntegration.

DesignChecks MUST NOT directly modify Cimatron CAD data.

Plugin MUST NOT contain business-rule logic.

CimatronIntegration is the primary layer allowed to know Cimatron COM/Interop details.

Read-only validation code MUST remain separated from modifying automation code.
```

Additional architecture rules may be added as the solution evolves.

### SonarQube Community Build

SonarQube Community Build is the project's server-side/static-analysis quality dashboard and quality-gate layer.

It should be used for:

- code smells;
- complexity;
- duplication;
- maintainability;
- security findings;
- technical debt;
- quality trends;
- approved quality-gate thresholds.

SonarQube complements Roslyn, `.editorconfig`, and tests. It does not replace them.

### Execution Responsibility

The AI agent must not claim that any of these tools passed unless the user has supplied actual execution results.

The workflow is:

```text
Agent prepares configuration/code/tests/instructions
        ↓
User runs Visual Studio / tests / analyzers / SonarQube
        ↓
User sends actual output/results
        ↓
Agent analyzes and records the feedback
```

Until user-supplied evidence is received, the status remains:

```text
AWAITING USER EXECUTION
```

or:

```text
NOT VERIFIED
```

## 17. Mandatory Quality Gates

A delivery/release candidate is acceptable only if all applicable gates pass.

### Gate 1 — Requirement
- requirement clear;
- acceptance criteria defined;
- assumptions documented;
- required client inputs available.

### Gate 2 — Architecture
- correct layer selected;
- no unnecessary coupling;
- Cimatron impact reviewed;
- read-only vs modifying behavior confirmed.

### Gate 3 — Build
- Release build succeeds;
- correct x64/.NET target;
- no blocking warnings;
- version stamped.

### Gate 4 — Unit Tests
- required tests pass;
- no critical tests skipped.

### Gate 5 — Coverage
- thresholds pass;
- changed-code coverage passes;
- critical calculations covered.

### Gate 6 — C#/.NET Maintainability and Static Analysis
- Visual Studio Release build feedback received from the user;
- Roslyn/.NET analyzer results reviewed;
- `.editorconfig` rules applied consistently;
- required unit tests executed by the user;
- required architecture tests executed by the user;
- SonarQube Community Build results reviewed;
- no unapproved high/critical findings;
- no unapproved architecture violations;
- applicable maintainability/quality thresholds pass;
- gate remains `AWAITING USER EXECUTION` until the user supplies actual results.

### Gate 7 — Cimatron Integration
- target-version validation completed;
- document-state handling verified;
- API/geometry failure paths tested;
- unsupported cases controlled.

### Gate 8 — Regression
- regression suite passes;
- defect fixes have regression protection where feasible.

### Gate 9 — Performance
When relevant:
- agreed model sizes tested;
- execution time acceptable;
- no major UI freeze/resource leak.

### Gate 10 — Security / Client Data
- no secrets in source/config;
- no unauthorized data export;
- logs reviewed for sensitive content.

### Gate 11 — Documentation / Traceability
- implementation history updated;
- changelog updated;
- requirement/test docs updated;
- limitations documented.

### Gate 12 — Packaging
- runtime-only client package;
- no source/internal docs shipped;
- installer/upgrade/uninstall path validated when applicable.

### Gate 13 — Client Acceptance
When required:
- representative/client samples pass;
- UAT evidence captured;
- release approved.

Failure of a mandatory gate blocks release.

---

## 17A. Execution Responsibility Model

This ChatGPT/AI agent is an **implementation-preparation and packaging agent**, not the execution environment.

The agent may:

- study requirements and existing code;
- propose implementation plans;
- create approved new files;
- modify explicitly approved existing files;
- prepare source code, tests, configuration, documentation, and scripts;
- analyze user-supplied build/test/runtime feedback;
- update approved history/changelog/version artifacts;
- generate `CHECKSUMS.sha256`;
- create the cumulative progressive ZIP;
- calculate and report the ZIP SHA-256.

The agent must **not claim to execute or validate** any of the following unless the user explicitly changes this operating model:

- Visual Studio build;
- compilation;
- unit tests;
- integration tests;
- regression tests;
- code coverage;
- static analysis;
- Sonar or equivalent quality tools;
- Cimatron runtime execution;
- Cimatron COM/Interop behavior;
- plugin loading;
- installer execution;
- client-environment validation;
- performance testing;
- user acceptance testing.

These activities are executed by the **user on the real development/Cimatron workstation**.

The agent may prepare commands, scripts, expected results, and test instructions for the user to run.

### Evidence Rule

The agent must never report a test, build, quality gate, or Cimatron validation as `PASS` unless the user has supplied the actual result/evidence from the workstation.

Acceptable evidence may include:

- copied console output;
- build logs;
- test-result output;
- coverage reports;
- static-analysis output;
- Cimatron runtime output;
- screenshots;
- error messages;
- user-confirmed observed behavior.

The agent may analyze that evidence and record the result, but must not invent or infer a successful execution.

If execution feedback has not yet been supplied, the applicable status must remain:

```text
AWAITING USER EXECUTION
```

or:

```text
NOT VERIFIED
```

### Mandatory Feedback Loop

Before beginning or proposing the next implementation step, the agent must ask:

```text
What is the feedback/result of the last step?
```

The agent must review the user's feedback before continuing.

If the previous step produced errors, failed tests, unexpected Cimatron behavior, or unresolved observations, the agent must address those findings first unless the user explicitly instructs otherwise.

The agent must not assume silence means success.

### User Executes, Agent Interprets

Standard cycle:

```text
1. Agent studies requirement.
2. Agent proposes step and file impact.
3. User approves.
4. Agent prepares the approved implementation.
5. Agent generates checksums and cumulative ZIP.
6. Agent gives exact user-run instructions.
7. User builds/tests/runs in the real environment.
8. User sends results/feedback.
9. Agent analyzes the feedback.
10. Only then is the step considered verified or ready for the next step.
```

A delivered ZIP means:

```text
IMPLEMENTATION PREPARED
```

It does **not** automatically mean:

```text
BUILD PASSED
TESTS PASSED
CIMATRON VERIFIED
PRODUCTION READY
```

## 18. Approval and Change Control

### Before every implementation step

The agent must:

1. study the requirement;
2. identify exact scope;
3. identify dependencies/risks;
4. prepare execution plan;
5. propose meaningful necessary steps;
6. list new files;
7. list existing files that would change;
8. explain why each existing-file change is required;
9. identify API assumptions to verify;
10. present tests/quality gates;
11. wait for explicit approval.

If new work becomes necessary after approval, stop and request approval for the revised scope.

### Existing-file protection

Default preference:

```text
Create new capability in a new file
before
modifying an existing file
```

If an existing file must change, the agent must first state:

- exact file;
- why a new file alone is insufficient;
- exact intended modification;
- expected impact;
- regression risk;
- tests protecting the change.

Then wait for approval.

### No unnecessary changes

Forbidden without separate approval:

- unrelated refactoring;
- formatting unrelated files;
- unrelated renames;
- dependency upgrades unrelated to the task;
- project restructuring;
- unrelated warning cleanup;
- unrelated configuration changes;
- unrelated documentation edits.

### Byte-identical preservation

All files outside the explicitly approved change set must remain **byte-for-byte identical** to the previous approved version.

This includes:

- source;
- tests;
- project files;
- solution files;
- config;
- docs;
- scripts;
- line endings;
- encoding;
- whitespace.

If SHA-256 changes, the file is changed.

Unexpected changes outside approved scope must be reverted unless the user separately approves them.

### Discovered defects

An unrelated defect does not authorize a fix.

Report it. Explain impact. Ask whether to address it.

---

## 18A. Release Integrity and Environment Controls

These controls apply to progressive development packages and production releases.

### Git / Baseline Control

Each approved progressive version should correspond to a reproducible source-control baseline.

Where Git is used, record:

- commit ID;
- branch;
- release tag when applicable;
- associated product version;
- associated progressive ZIP name.

Recommended tag format:

```text
v<major>.<minor>.<patch>
```

A release package must not be built from an unidentified or ambiguous source state.

### Dependency and License Control

Every NuGet or third-party dependency must have its:

- exact version;
- purpose;
- source;
- license;
- approval status

recorded where appropriate.

Rules:

- no silent dependency upgrades;
- no floating versions for production;
- no unnecessary dependency additions;
- no dependency with unacceptable or unclear licensing;
- dependency changes require approval under the normal change-control rules.

### Reproducible Build / Build Provenance

For each progressive release or production release, record enough information to reproduce the build.

At minimum:

```text
Product Version
Git Commit / Source Baseline
Cimatron Version
Windows Version
.NET Framework Version
Build Configuration
Platform Target
Compiler / Visual Studio Version
Dependency Versions
Configuration Schema Version
Build Date
Package Name
Package SHA-256
```

A release must not depend on undocumented developer-machine state.

### Code Signing

Production client releases should support Authenticode/code signing for:

- installer packages;
- production plugin DLLs where appropriate;
- other executable runtime artifacts where appropriate.

Development ZIPs do not require code signing unless explicitly requested.

Signing certificates, private keys, passwords, and secrets must never be stored in source control or ordinary repository configuration.

### Supported Environment Matrix

Maintain an explicit compatibility matrix for released versions.

Example:

```text
Product Version | Cimatron Version | Windows | .NET | Status
1.0.0           | 2026.x           | Win 11  | 4.8  | Supported
```

Rules:

- never assume a new Cimatron version or patch is compatible;
- validate compatibility before marking it supported;
- record unsupported/untested combinations honestly;
- version-specific API behavior must be documented.

### Modification Transaction and Recovery

Any automation that modifies Cimatron data must define safe failure behavior before production approval.

Where supported, prefer documented Cimatron transaction/undo mechanisms.

A modifying automation must define:

- preconditions;
- operation boundary;
- failure detection;
- rollback/undo behavior;
- partial-change detection;
- recovery instructions;
- save behavior.

The system must never silently leave a client model in a partially modified state.

If reliable rollback is not technically available, the limitation must be explicit and the workflow must reduce risk through controlled copies, staged operations, or another approved recovery approach.

## 19. Progressive ZIP Standard

Every development ZIP must be cumulative and self-contained.

### ZIP naming

Exact format:

```text
phase-<phase>-step-<step>-<step-name>-<major>.<minor>.<patch>.zip
```

Rules:

- `<phase>` = phase number, normally two digits.
- `<step>` = step number, normally two digits.
- `<step-name>` = meaningful kebab-case name generated by the implementing agent.
- version = Semantic Versioning.

Examples:

```text
phase-01-step-01-engineering-foundation-0.1.0.zip
phase-01-step-02-cimatron-connection-0.2.0.zip
phase-01-step-03-plugin-shell-0.3.0.zip
phase-02-step-01-wedge-finger-angle-validation-0.5.0.zip
phase-02-step-02-wedge-angle-error-fix-0.5.1.zip
```

Avoid generic step names such as `update`, `changes`, `fixes`, or `new-code`.

### Extracted root folder

Every ZIP must extract to exactly:

```text
cimatron-customization/
```

Do not include phase/version in the root directory name.

### Cumulative delivery

Every ZIP contains the complete working solution up to that step.

Do not require earlier ZIPs to reconstruct the current solution.

### Version rules

Use:

```text
MAJOR.MINOR.PATCH
```

- PATCH = compatible bug/corrective fix.
- MINOR = new backward-compatible capability.
- MAJOR = intentional incompatible product/architecture/config/runtime change.

The ZIP version, application version, `VERSION.md`, changelog, and implementation history must remain consistent.

---

## 20. Required Development Package Contents

As applicable:

```text
cimatron-customization/
  CimatronCustomization.sln
  src/
  tests/
  docs/
  installer/
  tools/
  AGENTS.md
  README.md
  BUILD.md
  RUN.md
  DEPLOYMENT.md
  CHANGELOG.md
  IMPLEMENTATION-HISTORY.md
  VERSION.md
  CHECKSUMS.sha256
```

Development ZIPs are internal engineering artifacts, not client packages.

---

## 21. SHA-256 Integrity

Every progressive ZIP must contain:

```text
CHECKSUMS.sha256
```

It must contain SHA-256 for every packaged repository file except the checksum manifest itself and intentionally excluded generated/temp outputs.

Format:

```text
<sha256>  relative/path/to/file
```

Paths are relative to `cimatron-customization/`.

Use `/` as canonical path separator in the manifest.

Before delivery, compare the current manifest with the previous approved package when available.

Classify files as:

```text
ADDED
MODIFIED
UNCHANGED
DELETED
```

Unexpected checksum changes block delivery.

For files outside approved scope, changed checksums require restoration to the exact previous bytes unless separately approved.

Also calculate and record SHA-256 for the ZIP itself.

Production client installers/packages must also have release-recorded SHA-256.

---

## 22. Implementation History

Every implementation, bug fix, refactor, error removal, API discovery, configuration change, test change, deployment change, or small correction must be recorded.

Minimum fields:

```text
Date
Version
Phase
Step
Step Name
Change ID
Change Type
Requirement / Feature
Reason
Files Changed
Previous Behavior
New Behavior
Problem / Root Cause
Fix
Tests Added/Changed
Validation
Cimatron Version
Build Result
Runtime Result
Known Limitations
Next Action
```

Change types include:

- IMPLEMENTATION
- BUGFIX
- HOTFIX
- REFACTOR
- API-DISCOVERY
- CONFIGURATION
- TEST
- DEPLOYMENT
- DOCUMENTATION
- PERFORMANCE
- SECURITY
- COMPATIBILITY
- BUILD
- INSTALLER

Do not rewrite history to hide unsuccessful attempts.

---

## 23. Development vs Client Package

### Development side keeps

- source;
- solution/project files;
- `AGENTS.md`;
- architecture docs;
- implementation history;
- internal test plans;
- test source;
- API research;
- developer diagnostics;
- internal build/deployment notes.

### Client receives only

- compiled runtime DLLs;
- approved supporting runtime dependencies;
- production configuration;
- installer/uninstaller;
- version information;
- required user-facing operating/support documentation;
- runtime log/report locations.

Do not ship source or internal engineering material.

Avoid `.pdb` in normal production packages unless explicitly required for controlled support.

---

## 24. Installer / Upgrade Policy

Production deployment must be installer-based.

Installer should eventually support:

- prerequisite checks;
- supported Cimatron detection;
- plugin installation;
- supported registration/configuration;
- config migration;
- upgrade;
- repair;
- rollback where practical;
- uninstall;
- installed-version tracking.

Do not depend on undocumented Cimatron internals.

---

## 25. Geometry and Numerical Rules

Every geometry rule must define:

- units;
- tolerance;
- precision;
- comparison method;
- coordinate system;
- direction convention;
- rounding policy;
- degenerate-geometry behavior.

Never compare geometric floating-point values using exact equality.

Do not assume global X/Y/Z equals tooling direction.

Do not assume component orientation is canonical.

Do not assume face-normal sign already represents the required business direction.

If required direction cannot be resolved reliably, return a controlled result.

---

## 26. Entity Recognition

Semantic recognition must be documented.

Possible evidence:

- feature/procedure metadata;
- assembly structure;
- names;
- attributes;
- colors;
- geometry;
- catalogs;
- approved customer conventions.

Avoid fragile name-only recognition unless guaranteed.

Prefer multiple evidence signals when practical.

---

## 27. Read-Only / Modification Safety

Read-only checks may:

- read;
- measure;
- classify;
- highlight;
- report.

Read-only checks must not:

- move;
- delete;
- modify;
- save;
- alter procedures.

Modifying automations must:

- validate preconditions;
- avoid partial states;
- define undo/rollback behavior;
- avoid auto-save unless required;
- be tested on copies before production.

---

## 28. Performance / Security

Avoid:

- unnecessary repeated full-model scans;
- excessive COM round-trips;
- unbounded UI-blocking loops.

Performance-sensitive features require measurable acceptance criteria.

Do not:

- upload client CAD externally without explicit authorization;
- embed secrets in source;
- store credentials in plaintext;
- log unnecessary proprietary content;
- send telemetry externally without approval.

---

## 29. Definition of Done

A feature is Done only when:

- requirement is clear;
- acceptance criteria exist;
- architecture/naming rules are followed;
- TDD followed where feasible;
- required tests pass;
- coverage gate passes;
- static-analysis gate passes;
- Cimatron integration verified;
- regression passes;
- error handling/logging adequate;
- configuration documented;
- implementation history updated;
- changelog updated;
- deployment impact known;
- limitations documented;
- all applicable gates pass.

"Compiles" is not Done.

"Works once" is not Done.

---

## 30. Bug / Fix Workflow

For every defect:

1. record symptom;
2. record environment;
3. reproduce;
4. identify root cause;
5. add regression test where feasible;
6. apply smallest correct fix;
7. run focused tests;
8. run regression;
9. validate in Cimatron when API-related;
10. update history;
11. re-run coverage/static-analysis gates;
12. increment version appropriately;
13. generate cumulative ZIP.

---

## 31. API Investigation Workflow

When Cimatron API behavior is uncertain:

1. define exact technical question;
2. check official SDK docs;
3. inspect installed Interop if needed;
4. use Journaling when applicable;
5. create minimal diagnostic experiment;
6. run on controlled model;
7. record findings;
8. add integration tests where useful;
9. promote only proven behavior into production.

Do not invent API names, enums, signatures, procedures, or behavior.

---

## 32. Initial Progressive Foundation

Before production CR/SA implementations:

### Phase 01 — Engineering Foundation

**Step 01**
- solution skeleton;
- versioning;
- test projects;
- implementation history;
- coverage/quality infrastructure.

**Step 02**
- Cimatron session/connection abstraction;
- diagnostic connection test;
- integration harness.

**Step 03**
- production plugin shell;
- command registration/load;
- top-level exception boundary.

**Step 04**
- structured logging;
- configuration;
- startup diagnostics.

**Step 05**
- generic validation/automation execution framework;
- result model;
- registry;
- baseline reporting.

Only after the foundation is verified should production checks/automations be added.

---

## 33. Mandatory Agent Working Sequence

For implementation work:

```text
1. STUDY
2. UNDERSTAND
3. IDENTIFY SCOPE
4. VERIFY REQUIRED CIMATRON API INFORMATION
5. PLAN
6. PROPOSE NECESSARY STEPS
7. IDENTIFY NEW FILES
8. IDENTIFY EXISTING FILES THAT WOULD CHANGE
9. PRESENT RISKS / ASSUMPTIONS / TESTS / GATES
10. WAIT FOR USER APPROVAL
11. IMPLEMENT ONLY THE APPROVED STEP
12. PREPARE USER-RUN BUILD / TEST / COVERAGE / VALIDATION INSTRUCTIONS
13. UPDATE APPROVED HISTORY / CHANGELOG / VERSION FILES
14. GENERATE SHA-256 MANIFEST
15. VERIFY ALL UNAPPROVED FILES ARE BYTE-IDENTICAL
16. PACKAGE THE CUMULATIVE ZIP
17. CALCULATE ZIP SHA-256
18. PRESENT THE PACKAGE AND EXACT USER-RUN INSTRUCTIONS
19. WAIT FOR USER BUILD / TEST / CIMATRON FEEDBACK
20. ANALYZE THE USER'S FEEDBACK BEFORE PROPOSING THE NEXT STEP
```

Never skip the approval boundary between steps 10 and 11.

If the approved plan becomes invalid, stop and request approval for a revised plan.

---

## 34. Approval Interpretation

These count as approval only for the stated scope:

- "Approved"
- "Proceed with Step 2"
- "Implement these listed steps"
- "Modify AGENTS.md with these changes"
- equivalent explicit instructions

These do not automatically authorize implementation:

- "What do you recommend?"
- "How should we do this?"
- "Study this"
- "Review this"
- "Check this"
- "What is wrong?"
- "Give me the architecture"
- "Can this be done?"

When uncertain, do not modify code.

---

## 35. Multi-Session Context Management

This project will span multiple ChatGPT sessions.

The agent must continuously assess whether the current session still contains enough reliable context for safe work.

### GREEN — Continue

Use when:

- requirement is clear;
- approved step is clear;
- relevant decisions are available;
- affected files/scope are known;
- no critical instruction is being reconstructed from uncertain memory.

Action:

```text
Continue in current session.
```

### AMBER — Start New ChatGPT Session

Use when:

- chat is becoming bloated;
- old branches/decisions make scope harder to distinguish;
- risk of overlooking earlier constraints is increasing;
- state can still be summarized reliably, but continuing increases implementation risk.

Action:

```text
START NEW CHATGPT SESSION — context is becoming unclear.
```

Do not begin a new implementation step in an AMBER session.

Prepare a handoff containing:

- current phase;
- current step;
- current version;
- latest approved ZIP/package;
- approved scope;
- completed work;
- pending work;
- approved existing-file modifications;
- known issues;
- key decisions;
- exact next step;
- files the new session must read first.

### RED — Do Not Work in This Session

Use when:

- important context is missing/contradictory;
- approved scope cannot be determined confidently;
- authoritative package/version is unclear;
- approval boundaries cannot be reconstructed;
- necessary files/history are unavailable;
- risk of changing wrong code is material.

Action:

```text
DO NOT IMPLEMENT IN THIS SESSION.
START A NEW CHATGPT SESSION.
```

In RED, no repository modification is allowed.

Only safe handoff/recovery guidance may be provided.

---

## 36. New Session Handoff

When moving to a new session during active development, propose a handoff file such as:

```text
docs/history/session-handoffs/
  phase-<phase>-step-<step>-handoff.md
```

Creating/modifying this file still follows approval rules.

Recommended contents:

```text
Project
Phase
Step
Version
Context Status
Latest Approved Package
Requirement
Approved Scope
Completed Work
Pending Work
Files Added
Files Modified
Approved Existing-File Changes
Tests Completed
Quality-Gate Status
Known Errors
Known Limitations
Important Decisions
Cimatron API Findings
Exact Next Step
Files To Read First
```

The handoff does not replace implementation history.

---

## 37. Mandatory Response Footer

Every implementation-related response must end with:

```text
────────────────────────────────────────
PROJECT STATUS
Phase        : <phase number/name>
Step         : <step number/name>
Version      : <major.minor.patch or N/A>
Context      : GREEN | AMBER | RED
Scope        : <short approved/current scope>
Approval     : REQUIRED | APPROVED | NOT APPLICABLE
Changes      : NONE | PLANNED | IN PROGRESS | COMPLETED
User Validation: AWAITING USER EXECUTION | FEEDBACK RECEIVED | PASS | FAIL | N/A
Last Feedback: <user feedback received | NOT YET RECEIVED | N/A>
Next Action  : <single clear next action>
────────────────────────────────────────
```

Rules:

- `Context` must be honest.
- `Approval` must reflect actual approval.
- `User Validation` cannot be `PASS` unless the user supplied actual execution evidence from the workstation.
- `Next Action` must be one concrete action.
- If AMBER, next action should normally be a new ChatGPT session.
- If RED, no implementation may continue.

Context status is based on implementation safety, not token count alone.

---

## 38. Mandatory Repository Files

Before production release:

```text
AGENTS.md
README.md
CHANGELOG.md
IMPLEMENTATION-HISTORY.md
VERSION.md
BUILD.md
RUN.md
DEPLOYMENT.md
CHECKSUMS.sha256
```

Recommended testing docs:

```text
docs/testing/TEST-STRATEGY.md
docs/testing/COVERAGE-QUALITY-GATES.md
docs/testing/INTEGRATION-TEST-PLAN.md
docs/testing/REGRESSION-TEST-PLAN.md
```

Recommended architecture docs:

```text
docs/architecture/SOLUTION-ARCHITECTURE.md
docs/architecture/CIMATRON-INTEGRATION.md
docs/architecture/ERROR-HANDLING.md
docs/architecture/CONFIGURATION.md
```

---

## 39. Mandatory Agent Behavior

Every agent must:

1. read this entire file;
2. read relevant requirement/history/version context;
3. verify uncertain Cimatron API behavior;
4. plan before implementation;
5. obtain approval;
6. use self-explanatory names;
7. work test-first;
8. update tests;
9. maintain coverage;
10. preserve requirement traceability;
11. update approved history/changelog/version files;
12. preserve byte-identical files outside approved scope;
13. keep progressive ZIPs cumulative;
14. follow ZIP naming/root-folder rules;
15. maintain SHA-256 manifests and package hashes;
16. never report API errors as rule failures;
17. never modify geometry for a read-only check;
18. never ship development source/internal docs to clients;
19. assess session context health;
20. include the mandatory PROJECT STATUS footer;
21. never claim production readiness unless all applicable gates pass;
22. never claim build/test/coverage/Cimatron execution unless the user supplied evidence;
23. ask for the feedback/result of the last step before proceeding to the next implementation step;
24. record limitations honestly.

---

## 40. Communication Standard

Chat responses should normally remain small to medium.

Generated engineering files should be detailed and self-contained.

For each progressive ZIP, chat should summarize only:

- ZIP filename;
- version;
- what changed;
- immediate run steps;
- expected result;
- required user action.

Detailed engineering documentation belongs inside the development package.

---

## 40A. Mandatory Engineering Time and Delivery Tracking

Engineering time tracking is a **NON-NEGOTIABLE project-control requirement**.

The purpose is to distinguish actual AI-agent engineering effort from user validation time, feedback delay, rework, and total calendar duration so that phase-level productivity and future project estimates can be based on recorded evidence.

The authoritative detailed time ledger is:

```text
docs/time-tracking/PROJECT-TIMESHEET.csv
```

Do not maintain duplicate phase-wise Markdown timesheets. Phase and project summaries must be derived from the CSV ledger when needed.

For every approved implementation phase, step, or meaningful task/submission cycle, append or update the applicable CSV row. At minimum the CSV must contain these columns:

```text
Phase
Step
TaskOrChangeId
TaskName
Version
ApprovalTimestamp
AgentWorkStartTimestamp
AgentSubmissionTimestamp
SubmittedZipOrOutput
UserFeedbackReceivedTimestamp
TaskClosureTimestamp
AgentActiveMinutes
UserFeedbackWaitMinutes
ReworkMinutes
CalendarElapsedMinutes
Status
Notes
```

CSV and timestamp rules:

- use UTF-8 CSV with a single header row;
- use ISO-8601 timestamps with timezone;
- use one row per meaningful implementation/submission cycle, not per tiny agent action;
- record the agent submission timestamp when the ZIP/output is delivered to the user;
- if user feedback has not yet arrived, leave `UserFeedbackReceivedTimestamp` empty and keep `Status` as `AWAITING USER VALIDATION`;
- when feedback arrives, record its actual received timestamp and calculate the feedback-wait duration;
- waiting for user build/test/Cimatron execution or feedback must **never** be counted as agent active development time;
- rework after user feedback must be recorded separately from the original agent active time;
- calendar elapsed time must remain separate from agent active time;
- do not invent or backfill precise timestamps that were not actually observed; leave unavailable historical timestamp/duration fields empty and explain the gap in `Notes` where useful;
- updates to the CSV ledger are mandatory project documentation and must be carried forward in every cumulative progressive ZIP.

Phase and project reporting should be calculated from `PROJECT-TIMESHEET.csv`, including where data exists:

```text
Tasks / Steps Completed
Total Agent Active Time
Total Rework Time
Total User Feedback Wait Time
Total Calendar Elapsed Time
Average Agent Active Time per Completed Step
Average User Feedback Wait Time
```

AI-agent time and estimated human-development time are different metrics. If a human-equivalent estimate is later recorded, it must be explicitly identified as an estimate and must never be presented as measured actual human effort. Until an approved estimation method exists, human-equivalent time is `NOT ESTIMATED`.

The CSV ledger is engineering evidence and the source of truth for time-based productivity analysis and future project-duration forecasting.

---

## 41. Final Engineering Principle

The objective is not merely to automate Cimatron.

The objective is to build a maintainable, testable, auditable, deployable, upgradeable Cimatron customization platform that can safely support many real-client requirements over time.

Every technical decision must be judged against that objective.
