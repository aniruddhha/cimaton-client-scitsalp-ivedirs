using System;
using System.Collections.Generic;

namespace CimatronCustomization.Domain
{
    public static class FindingAggregation
    {
        public static ResultStatus Aggregate(IEnumerable<Finding> findings, ResultStatus emptyStatus)
        {
            if (findings == null)
            {
                throw new ArgumentNullException(nameof(findings));
            }

            bool any = false;
            ResultStatus aggregate = emptyStatus;
            int aggregateSeverity = Severity(emptyStatus);

            foreach (Finding finding in findings)
            {
                if (finding == null)
                {
                    throw new ArgumentException("A finding collection cannot contain null entries.", nameof(findings));
                }

                any = true;
                int severity = Severity(finding.Status);
                if (severity > aggregateSeverity)
                {
                    aggregate = finding.Status;
                    aggregateSeverity = severity;
                }
            }

            return any ? aggregate : emptyStatus;
        }

        private static int Severity(ResultStatus status)
        {
            switch (status)
            {
                case ResultStatus.Error: return 70;
                case ResultStatus.Failed: return 60;
                case ResultStatus.Warning: return 50;
                case ResultStatus.Unsupported: return 40;
                case ResultStatus.NotApplicable: return 30;
                case ResultStatus.Skipped: return 20;
                case ResultStatus.Passed:
                case ResultStatus.Succeeded:
                default: return 10;
            }
        }
    }
}
