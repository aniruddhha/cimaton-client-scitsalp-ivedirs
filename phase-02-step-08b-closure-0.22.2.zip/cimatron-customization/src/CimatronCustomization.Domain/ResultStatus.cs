namespace CimatronCustomization.Domain
{
    public enum ResultStatus
    {
        Passed,
        Succeeded,
        Failed,
        Warning,
        Error,
        NotApplicable,
        Skipped,
        Unsupported
    }
}
