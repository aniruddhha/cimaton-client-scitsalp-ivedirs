using System;

namespace CimatronCustomization.Domain
{
    /// <summary>
    /// Opaque current-session reference. It must never be treated as a persistent Cimatron entity id.
    /// </summary>
    public sealed class ModelEntityReference
    {
        public ModelEntityReference(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("An entity reference value is required.", nameof(value));
            }

            Value = value;
        }

        public string Value { get; }
    }
}
