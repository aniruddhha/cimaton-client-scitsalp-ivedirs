using System;
using System.Collections;
using System.Collections.Generic;

namespace CimatronCustomization.Domain
{
    public sealed class FindingCollection : IReadOnlyList<Finding>
    {
        private readonly Finding[] findings;

        public FindingCollection(IEnumerable<Finding> findings)
        {
            if (findings == null)
            {
                throw new ArgumentNullException(nameof(findings));
            }

            this.findings = new List<Finding>(findings).ToArray();
            for (int index = 0; index < this.findings.Length; index++)
            {
                if (this.findings[index] == null)
                {
                    throw new ArgumentException("A finding collection cannot contain null entries.", nameof(findings));
                }
            }
        }

        public int Count => findings.Length;
        public Finding this[int index] => findings[index];
        public IEnumerator<Finding> GetEnumerator() => ((IEnumerable<Finding>)findings).GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => findings.GetEnumerator();
    }
}
