using System;

namespace CimatronCustomization.Domain
{
    public sealed class ActivePartReadinessResult
    {
        public ActivePartReadinessResult(ResultStatus status, string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("A readiness result message is required.", nameof(message));
            }

            Status = status;
            Message = message;
        }

        public ResultStatus Status { get; }

        public string Message { get; }
    }
}
