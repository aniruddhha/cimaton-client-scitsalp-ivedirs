using System;

namespace CimatronCustomization.Domain
{
    public sealed class Measurement
    {
        public Measurement(double value, string unit)
        {
            if (string.IsNullOrWhiteSpace(unit))
            {
                throw new ArgumentException("A measurement unit is required.", nameof(unit));
            }

            Value = value;
            Unit = unit;
        }

        public double Value { get; }
        public string Unit { get; }
    }
}
