using System;

namespace CimatronCustomization.Domain
{
    public struct Direction3
    {
        public Direction3(double x, double y, double z)
        {
            double magnitude = Math.Sqrt((x * x) + (y * y) + (z * z));
            if (magnitude <= 0d || double.IsNaN(magnitude) || double.IsInfinity(magnitude))
            {
                throw new ArgumentException("A direction must have a finite non-zero magnitude.");
            }

            X = x / magnitude;
            Y = y / magnitude;
            Z = z / magnitude;
        }

        public double X { get; }
        public double Y { get; }
        public double Z { get; }
    }
}
