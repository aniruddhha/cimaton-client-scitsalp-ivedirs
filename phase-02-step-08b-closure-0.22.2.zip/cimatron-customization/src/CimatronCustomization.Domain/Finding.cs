using System;
using System.Collections.Generic;

namespace CimatronCustomization.Domain
{
    public sealed class Finding
    {
        private readonly ModelEntityReference[] entityReferences;

        public Finding(
            string requirementId,
            ResultStatus status,
            string message,
            Measurement measuredValue = null,
            Measurement limit = null,
            IEnumerable<ModelEntityReference> entityReferences = null,
            Point3? location = null)
        {
            if (string.IsNullOrWhiteSpace(requirementId))
            {
                throw new ArgumentException("A finding requirement id is required.", nameof(requirementId));
            }

            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("A finding message is required.", nameof(message));
            }

            if (measuredValue != null && limit != null &&
                !string.Equals(measuredValue.Unit, limit.Unit, StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Measured value and limit must use the same unit.");
            }

            RequirementId = requirementId;
            Status = status;
            Message = message;
            MeasuredValue = measuredValue;
            Limit = limit;
            this.entityReferences = entityReferences == null
                ? Array.Empty<ModelEntityReference>()
                : new List<ModelEntityReference>(entityReferences).ToArray();
            Location = location;
        }

        public string RequirementId { get; }
        public ResultStatus Status { get; }
        public string Message { get; }
        public Measurement MeasuredValue { get; }
        public Measurement Limit { get; }
        public IReadOnlyList<ModelEntityReference> EntityReferences => entityReferences;
        public Point3? Location { get; }
    }
}
