namespace CimatronCustomization.Domain
{
    /// <summary>
    /// Internal foundation validation used to prove the first end-to-end vertical slice.
    /// It is not a customer CR/SA requirement.
    /// </summary>
    public static class ActivePartReadinessValidation
    {
        public static ActivePartReadinessResult Evaluate(
            bool isApplicationAvailable,
            bool hasActiveDocument,
            bool isActiveDocumentPart)
        {
            if (!isApplicationAvailable)
            {
                return new ActivePartReadinessResult(
                    ResultStatus.Error,
                    "Cimatron is not available, so Part readiness cannot be evaluated reliably.");
            }

            if (!hasActiveDocument)
            {
                return new ActivePartReadinessResult(
                    ResultStatus.NotApplicable,
                    "No active Cimatron document is available for a Part readiness check.");
            }

            if (!isActiveDocumentPart)
            {
                return new ActivePartReadinessResult(
                    ResultStatus.Unsupported,
                    "The active Cimatron document is not a Part.");
            }

            return new ActivePartReadinessResult(
                ResultStatus.Passed,
                "The active Cimatron Part is ready for Part-based operations.");
        }
    }
}
