using System;

namespace CimatronCustomization.Domain
{
    public sealed class GeometryTolerance
    {
        public GeometryTolerance(double absolute)
        {
            if (double.IsNaN(absolute) || double.IsInfinity(absolute) || absolute < 0d)
            {
                throw new ArgumentOutOfRangeException(nameof(absolute));
            }

            Absolute = absolute;
        }

        public double Absolute { get; }

        public bool AreEqual(double left, double right)
        {
            return Math.Abs(left - right) <= Absolute;
        }
    }
}
