using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.DesignChecks
{
    /// <summary>
    /// Internal foundation probe that proves the read-only Cimatron model-access ports.
    /// It contains no customer CR/SA recognition or threshold logic.
    /// </summary>
    public sealed class ModelInspectionProbeFeature : IApplicationFeature
    {
        public const string FeatureId = "FOUNDATION-MODEL-INSPECTION-PROBE";

        private static readonly FeatureDefinition definition = new FeatureDefinition(
            FeatureId,
            "Model Inspection Probe",
            FeatureKind.Validation,
            new[] { FeatureId },
            "Foundation",
            DocumentContextRequirement.Either,
            true,
            new FeatureTraceability(
                "Internal foundation validation that proves read-only assembly, attribute, color and topology access through Application ports.",
                "For a supported Part or Assembly, verified read capabilities produce informational Passed findings; unverified sub-capabilities produce explicit Unsupported findings instead of guessed data.",
                "Current active Cimatron model through read-only Application ports.",
                "Foundation findings summarizing assembly components, topology, representative attributes/colors, and unsupported topology sub-capabilities.",
                "IAssemblyStructureReader, IEntityAttributeReader, IEntityColorReader and IBodyTopologyReader.",
                "Cimatron 2026 official SDK: IAssemblyModel.GetInstances, IAssInstance properties, IEntityQuery filters/select, IAttributeSink.GetAttributes, cmAttColor, IGeom3DSurface.SurfType/Area/NormalFromPoint. Bounding-box access remains UNVERIFIED in this step.",
                "No customer configuration values.",
                "No model modifications; API/runtime exceptions become Error in the common execution pipeline; unsupported API sub-capabilities remain Unsupported.",
                "Application fake-port tests plus user-run live Cimatron validation on a representative mold assembly.",
                "0.14.10",
                "Foundation-only probe. It must not be interpreted as a customer design check."));

        private readonly IAssemblyStructureReader assemblyReader;
        private readonly IEntityAttributeReader attributeReader;
        private readonly IEntityColorReader colorReader;
        private readonly IBodyTopologyReader topologyReader;

        public ModelInspectionProbeFeature(
            IAssemblyStructureReader assemblyReader,
            IEntityAttributeReader attributeReader,
            IEntityColorReader colorReader,
            IBodyTopologyReader topologyReader)
        {
            this.assemblyReader = assemblyReader ?? throw new ArgumentNullException(nameof(assemblyReader));
            this.attributeReader = attributeReader ?? throw new ArgumentNullException(nameof(attributeReader));
            this.colorReader = colorReader ?? throw new ArgumentNullException(nameof(colorReader));
            this.topologyReader = topologyReader ?? throw new ArgumentNullException(nameof(topologyReader));
        }

        public FeatureDefinition Definition => definition;

        public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            List<Finding> findings = new List<Finding>();

            if (context.Session.ActiveDocumentContext == CimatronDocumentContext.Assembly)
            {
                AddAssemblyFindings(findings);
            }

            ModelReadResult<BodyTopologySnapshot> topology = topologyReader.ReadCurrentTopology();
            if (!topology.IsAvailable)
            {
                findings.Add(new Finding(FeatureId, topology.Status, topology.Message));
            }
            else
            {
                BodyTopologySnapshot snapshot = topology.Value;
                findings.Add(new Finding(
                    FeatureId,
                    ResultStatus.Passed,
                    "Read-only topology inspection found " + snapshot.Bodies.Count.ToString(CultureInfo.InvariantCulture) +
                    " body reference(s) and " + snapshot.Faces.Count.ToString(CultureInfo.InvariantCulture) + " face reference(s).",
                    new Measurement(snapshot.Faces.Count, "count")));

                ModelEntityReference representative = snapshot.Faces.Count > 0
                    ? snapshot.Faces[0].Reference
                    : snapshot.Bodies.Count > 0 ? snapshot.Bodies[0] : null;

                if (snapshot.Faces.Count > 0)
                {
                    FaceTopologySnapshot representativeFace = snapshot.Faces[0];
                    findings.Add(new Finding(
                        FeatureId,
                        ResultStatus.Passed,
                        "Representative face surface type = " + representativeFace.GeometryType +
                        "; area = " + representativeFace.Area.ToString("G17", CultureInfo.InvariantCulture) + " model-unit^2.",
                        new Measurement(representativeFace.Area, "model-unit^2"),
                        entityReferences: new[] { representativeFace.Reference }));
                }

                if (representative != null)
                {
                    AddAttributeFinding(findings, representative);
                    AddColorFinding(findings, representative);
                }
                else
                {
                    findings.Add(new Finding(
                        FeatureId,
                        ResultStatus.NotApplicable,
                        "No body or face entity was available for representative attribute/color inspection."));
                }

                if (!snapshot.BoundingBoxesSupported)
                {
                    findings.Add(new Finding(
                        FeatureId,
                        ResultStatus.Unsupported,
                        "Entity/face bounding-box access remains UNVERIFIED for Step 04; no API signature was guessed."));
                }
            }

            ResultStatus status = FindingAggregation.Aggregate(findings, ResultStatus.Passed);
            string message = "Model inspection completed with " + findings.Count.ToString(CultureInfo.InvariantCulture) + " foundation finding(s).";
            return new FeatureExecutionOutcome(status, message, findings);
        }

        private void AddAssemblyFindings(List<Finding> findings)
        {
            ModelReadResult<AssemblyStructureSnapshot> assembly = assemblyReader.ReadCurrentAssembly();
            if (!assembly.IsAvailable)
            {
                findings.Add(new Finding(FeatureId, assembly.Status, assembly.Message));
                return;
            }

            int placementCount = assembly.Value.Components.Count(component => component.HasPlacementMatrix);
            findings.Add(new Finding(
                FeatureId,
                ResultStatus.Passed,
                "Assembly structure reader found " + assembly.Value.Components.Count.ToString(CultureInfo.InvariantCulture) +
                " component instance(s); placement matrix available for " + placementCount.ToString(CultureInfo.InvariantCulture) + ".",
                new Measurement(assembly.Value.Components.Count, "count")));

            if (assembly.Value.Components.Count > 0)
            {
                AddColorFinding(findings, assembly.Value.Components[0].Reference);
            }
        }

        private void AddAttributeFinding(List<Finding> findings, ModelEntityReference reference)
        {
            ModelReadResult<EntityAttributeSnapshot> attributes = attributeReader.ReadAttributes(reference);
            if (!attributes.IsAvailable)
            {
                findings.Add(new Finding(FeatureId, attributes.Status, attributes.Message, entityReferences: new[] { reference }));
                return;
            }

            findings.Add(new Finding(
                FeatureId,
                ResultStatus.Passed,
                "Representative entity exposes " + attributes.Value.Attributes.Count.ToString(CultureInfo.InvariantCulture) + " attribute(s).",
                new Measurement(attributes.Value.Attributes.Count, "count"),
                entityReferences: new[] { reference }));
        }

        private void AddColorFinding(List<Finding> findings, ModelEntityReference reference)
        {
            ModelReadResult<EntityColorSnapshot> color = colorReader.ReadColor(reference);
            if (!color.IsAvailable)
            {
                findings.Add(new Finding(FeatureId, color.Status, color.Message, entityReferences: new[] { reference }));
                return;
            }

            findings.Add(new Finding(
                FeatureId,
                ResultStatus.Passed,
                "Representative Cimatron color value = " + color.Value.Color.ToString(CultureInfo.InvariantCulture) + ".",
                entityReferences: new[] { reference }));
        }
    }
}
