using System;
using System.Collections.Generic;
using System.Globalization;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.DesignChecks
{
    /// <summary>
    /// Step 08B foundation diagnostic for U8/U13/U7/U12/U15 in the registered Cimatron Plugin process.
    /// This is not CR-04 business logic.
    /// </summary>
    public sealed class Step08BInProcessConfirmationFeature : IApplicationFeature
    {
        public const string FeatureId = "FOUNDATION-U13-U15-ASSEMBLY-IN-PROCESS-CONFIRMATION";
        public const string KnownAssemblyTitle = "KA-ASM-1";
        public const string KnownPartTitle = "KA-PART-1";
        public const int KnownBodyId = 4;
        public const string KnownAttributeName = "STEP07_B1_TEST_ATTRIBUTE";
        public const string KnownAttributeValue = "KNOWN_ANSWER_07C3";
        public const string KnownMaterial = "1.2738";

        private static readonly FeatureDefinition definition = new FeatureDefinition(
            FeatureId,
            "Step 08B Component Property / Assembly Context Confirmation",
            FeatureKind.Validation,
            new[] { "U8", "U13", "U7", "U12", "U15" },
            "Foundation",
            DocumentContextRequirement.Assembly,
            true,
            new FeatureTraceability(
                "Step 08B in-process confirmation of Step 07 VERIFIED assembly/property capabilities.",
                "With KA-ASM-1 active, confirm the locked U8/U13/U7/U12/U15 known answers through capability-named production boundaries without CR-04 logic.",
                "Active saved KA-ASM-1; KA-PART-1 occurrences; body ID 4; locked named attribute and BOM material known answers.",
                "Separate foundation findings for occurrence traversal, exact named attribute, assembly mapping, production nested highlight reference, BOM material, cleanup and no-mutation evidence.",
                "IOccurrenceEntityAttributeReader, IAssemblyEntityMapper, IBomMaterialExporter.",
                "Cimatron 2026 IAssemblyModel/IAssInstance/IAttributeSink/IBOM and production ISelection highlight path. GetAllEntities is installed-Interop plus runtime evidence only and is not in the official SDK index.",
                "No customer configuration. Locked Step 07 known-answer values only.",
                "Wrong model/context is Unsupported; known-answer mismatch is Failed; BOM COM read failure is Error/READ_ERROR; unexpected runtime exceptions remain Error in the common pipeline.",
                "Application fake-port tests, architecture source guards, user-run quality gate and one governed live Assembly run plus Result Report Highlight action.",
                "0.22.0",
                "Developer-visible foundation diagnostic. DF-05: gate/remove from the launcher before D5 client packaging."));

        private readonly IOccurrenceEntityAttributeReader occurrenceReader;
        private readonly IAssemblyEntityMapper assemblyEntityMapper;
        private readonly IBomMaterialExporter bomMaterialExporter;

        public Step08BInProcessConfirmationFeature(
            IOccurrenceEntityAttributeReader occurrenceReader,
            IAssemblyEntityMapper assemblyEntityMapper,
            IBomMaterialExporter bomMaterialExporter)
        {
            this.occurrenceReader = occurrenceReader ?? throw new ArgumentNullException(nameof(occurrenceReader));
            this.assemblyEntityMapper = assemblyEntityMapper ?? throw new ArgumentNullException(nameof(assemblyEntityMapper));
            this.bomMaterialExporter = bomMaterialExporter ?? throw new ArgumentNullException(nameof(bomMaterialExporter));
        }

        public FeatureDefinition Definition => definition;

        public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            List<Finding> findings = new List<Finding>();
            ModelReadResult<OccurrenceEntityAttributeResult> occurrenceRead = occurrenceReader.ReadNestedOccurrenceAttribute(
                KnownAssemblyTitle,
                KnownPartTitle,
                KnownBodyId,
                KnownAttributeName);

            if (!occurrenceRead.IsAvailable)
            {
                findings.Add(new Finding(FeatureId, occurrenceRead.Status, occurrenceRead.Message));
                return BuildOutcome(findings, occurrenceRead.Status, occurrenceRead.Message);
            }

            OccurrenceEntityAttributeResult occurrence = occurrenceRead.Value;
            bool u8Matched = occurrence.TotalOccurrenceCount == 3 &&
                occurrence.TopLevelOccurrenceCount == 2 &&
                occurrence.NestedOccurrenceCount == 1;
            findings.Add(new Finding(
                FeatureId,
                u8Matched ? ResultStatus.Passed : ResultStatus.Failed,
                "U8 occurrence structure " + (u8Matched ? "matched" : "did not match") +
                " the locked Step 07 known answer. Total=" + occurrence.TotalOccurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; GetInstancesByModelTopLevel=" + occurrence.TopLevelOccurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; NestedViaSubInstances=" + occurrence.NestedOccurrenceCount.ToString(CultureInfo.InvariantCulture) +
                "; NestedInstanceIdObserved=" + occurrence.NestedInstanceId.ToString(CultureInfo.InvariantCulture) +
                " (instance ID is current-session evidence only)."));

            bool bodyMatched = occurrence.BodyMatchCount == 1 && string.Equals(occurrence.BodyType, "cmBody", StringComparison.Ordinal);
            findings.Add(new Finding(
                FeatureId,
                bodyMatched ? ResultStatus.Passed : ResultStatus.Failed,
                "U13 nested body resolution " + (bodyMatched ? "matched" : "did not match") +
                ". RequestedBodyId=" + KnownBodyId.ToString(CultureInfo.InvariantCulture) +
                "; MatchCount=" + occurrence.BodyMatchCount.ToString(CultureInfo.InvariantCulture) +
                "; Type=" + occurrence.BodyType +
                ". Resolution uses IAssInstance.GetAllEntities(); this method is installed-Interop/live-evidence only, not documented in the official SDK index."));

            bool attributeMatched = occurrence.AttributeFound &&
                string.Equals(occurrence.AttributeType, "cmAttString", StringComparison.Ordinal) &&
                string.Equals(occurrence.AttributeValue, KnownAttributeValue, StringComparison.Ordinal);
            findings.Add(new Finding(
                FeatureId,
                attributeMatched ? ResultStatus.Passed : ResultStatus.Failed,
                "U13 exact named attribute " + (attributeMatched ? "matched" : "did not match") +
                ". RequestedName=" + KnownAttributeName +
                "; Found=" + occurrence.AttributeFound +
                "; Type=" + occurrence.AttributeType +
                "; Value=" + occurrence.AttributeValue +
                "; ReturnedNameEvidence=" + occurrence.ReturnedAttributeName +
                ". Returned IAttribute.Name is evidence only and is never used as the match gate."));

            ModelReadResult<AssemblyEntityMappingResult> mappingRead = null;
            if (occurrence.NestedBodyReference == null)
            {
                findings.Add(new Finding(FeatureId, ResultStatus.Skipped, "U7 assembly mapping skipped because a unique nested body reference was not available."));
                findings.Add(new Finding(FeatureId, ResultStatus.Skipped, "U12 production nested highlight reference was not produced because U7 mapping could not be attempted."));
            }
            else
            {
                mappingRead = assemblyEntityMapper.MapToActiveAssembly(occurrence.NestedBodyReference);
                if (!mappingRead.IsAvailable)
                {
                    findings.Add(new Finding(FeatureId, mappingRead.Status, "U7 assembly mapping: " + mappingRead.Message));
                    findings.Add(new Finding(FeatureId, ResultStatus.Skipped, "U12 production nested highlight reference was not promoted because U7 mapping did not succeed."));
                }
                else
                {
                    AssemblyEntityMappingResult mapping = mappingRead.Value;
                    bool mappingMatched = string.Equals(mapping.AssemblyEntityType, "cmBody", StringComparison.Ordinal);
                    findings.Add(new Finding(
                        FeatureId,
                        mappingMatched ? ResultStatus.Passed : ResultStatus.Failed,
                        "U7 GetAssemblyEntity " + (mappingMatched ? "mapped" : "returned an unexpected entity type") +
                        ". SourceInstanceId=" + mapping.SourceInstanceId.ToString(CultureInfo.InvariantCulture) +
                        "; SourceBodyId=" + mapping.SourceEntityId.ToString(CultureInfo.InvariantCulture) +
                        "; AssemblyEntityId=" + mapping.AssemblyEntityId.ToString(CultureInfo.InvariantCulture) +
                        "; AssemblyEntityType=" + mapping.AssemblyEntityType + "."));

                    findings.Add(new Finding(
                        FeatureId,
                        mappingMatched ? ResultStatus.Passed : ResultStatus.Skipped,
                        mappingMatched
                            ? "U12 production nested highlight reference is ready. In the Result Report, select this row and click Highlight; visually confirm the nested KA-PART-1 body is highlighted."
                            : "U12 production nested highlight reference was not promoted because the mapped assembly entity type did not match cmBody.",
                        entityReferences: mappingMatched ? new List<ModelEntityReference> { occurrence.NestedBodyReference } : null));
                }
            }

            BomMaterialExportResult bom = bomMaterialExporter.ExportAndReadMaterial(KnownAssemblyTitle, KnownPartTitle);
            findings.Add(new Finding(
                FeatureId,
                bom.Status,
                "U15 cmNoFiltering BOM export/readback: " + bom.Message +
                (string.IsNullOrWhiteSpace(bom.CsvFileName) ? string.Empty : " CSV=" + bom.CsvFileName + ".")));

            if (bom.Status == ResultStatus.Passed)
            {
                bool materialMatched = bom.MaterialColumnPresent &&
                    bom.KnownAnswerRowCount == 1 &&
                    string.Equals(bom.MaterialValue, KnownMaterial, StringComparison.OrdinalIgnoreCase);
                findings.Add(new Finding(
                    FeatureId,
                    materialMatched ? ResultStatus.Passed : ResultStatus.Failed,
                    "U15 locked BOM material " + (materialMatched ? "matched" : "did not match") +
                    ". RowHeader=Standard Number; Target=" + KnownPartTitle +
                    "; MatchingRows=" + bom.KnownAnswerRowCount.ToString(CultureInfo.InvariantCulture) +
                    "; MaterialColumnPresent=" + bom.MaterialColumnPresent +
                    "; Material=" + bom.MaterialValue +
                    "; ExpectedMaterial=" + KnownMaterial +
                    ". Visibility/row-set interpretation is out of scope."));
            }
            else
            {
                findings.Add(new Finding(FeatureId, ResultStatus.Skipped, "U15 material comparison skipped because BOM export/readback did not complete reliably."));
            }

            bool mappingNoMutation = mappingRead == null || !mappingRead.IsAvailable || mappingRead.Value.NoMutationConfirmed;
            bool noMutation = occurrence.NoMutationConfirmed && mappingNoMutation && bom.NoMutationConfirmed && bom.ModelFolderUnchanged;
            findings.Add(new Finding(
                FeatureId,
                noMutation ? ResultStatus.Passed : ResultStatus.Failed,
                noMutation
                    ? "Programmatic no-mutation evidence remained unchanged: document modified-state, model file timestamp/length and model-folder listing guards passed."
                    : "Programmatic no-mutation evidence changed or could not be confirmed. Stop and review before any rerun."));

            findings.Add(new Finding(
                FeatureId,
                bom.TempCleanupSucceeded ? ResultStatus.Passed : ResultStatus.Warning,
                bom.TempCleanupSucceeded
                    ? "Step 08B temporary BOM run directory was removed after readback."
                    : "Step 08B temporary BOM cleanup failed. Only the governed Step08B run directory may be removed manually; model evidence is unaffected by this Warning."));

            ResultStatus aggregate = FindingAggregation.Aggregate(findings, ResultStatus.Passed);
            return BuildOutcome(findings, aggregate, "Step 08B in-process foundation confirmation completed with status " + aggregate + ".");
        }

        private static FeatureExecutionOutcome BuildOutcome(IReadOnlyList<Finding> findings, ResultStatus status, string message)
        {
            return new FeatureExecutionOutcome(status, message, findings);
        }
    }
}
