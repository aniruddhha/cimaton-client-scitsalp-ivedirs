using System;
using System.Collections.Generic;
using System.Globalization;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.DesignChecks
{
    /// <summary>
    /// Step 08A foundation diagnostic. Confirms the Step 07 U1 known answer inside the registered Plugin process.
    /// This is not a customer CR design rule.
    /// </summary>
    public sealed class U1InProcessGeometryConfirmationFeature : IApplicationFeature
    {
        public const string FeatureId = "FOUNDATION-U1-IN-PROCESS-CONFIRMATION";
        public const string KnownAnswerModelTitle = "KA-PART-1";
        public const int KnownAnswerBodyId = 4;

        private const double ExpectedVolume = 227576.685834808d;
        private const double ExpectedCenterX = 50d;
        private const double ExpectedCenterY = 30d;
        private const double ExpectedCenterZ = 20d;
        private const double ExpectedSurfaceArea = 26684.9371823929d;
        private const double ScalarTolerance = 0.000001d;
        private const double CenterTolerance = 0.000000001d;

        private static readonly FeatureDefinition definition = new FeatureDefinition(
            FeatureId,
            "U1 In-Process Geometry Confirmation",
            FeatureKind.Validation,
            new[] { "U1" },
            "Foundation",
            DocumentContextRequirement.Part,
            true,
            new FeatureTraceability(
                "Step 08A in-process confirmation of Step 07 VERIFIED U1 body geometry metrics.",
                "With KA-PART-1 active, body ID 4 must reproduce the locked Step 07 B1 volume, center and surface-area values and preserve no-mutation evidence.",
                "Active saved KA-PART-1 model, body ID 4.",
                "Passed/Failed foundation findings for volume, center, surface area and no-mutation evidence.",
                "IBodyGeometryMetricsReader.",
                "Cimatron 2026 IGeomServices.BodiesVolume, BodiesCenter and BodiesSurfArea through IMdlrModel.GetGeomServicesObj.",
                "No customer configuration. Locked Step 07 KA-PART-1 values only.",
                "Wrong model/body is Unsupported; API/runtime exceptions become Error in the common execution pipeline; numeric mismatch becomes Failed.",
                "Application fake-port tests plus user-run in-process validation in the registered Cimatron Plugin.",
                "0.21.2",
                "Foundation diagnostic only. Passing Step 08A confirms U1 in-process behavior; it does not implement CR-22."));

        private readonly IBodyGeometryMetricsReader reader;

        public U1InProcessGeometryConfirmationFeature(IBodyGeometryMetricsReader reader)
        {
            this.reader = reader ?? throw new ArgumentNullException(nameof(reader));
        }

        public FeatureDefinition Definition => definition;

        public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            ModelReadResult<BodyGeometryMetricsSnapshot> result = reader.ReadBodyMetrics(KnownAnswerModelTitle, KnownAnswerBodyId);
            if (!result.IsAvailable)
            {
                Finding unavailable = new Finding(FeatureId, result.Status, result.Message);
                return new FeatureExecutionOutcome(result.Status, result.Message, new[] { unavailable });
            }

            BodyGeometryMetricsSnapshot snapshot = result.Value;
            List<Finding> findings = new List<Finding>
            {
                CompareScalar("Volume", snapshot.Volume, ExpectedVolume, ScalarTolerance, "model-unit^3"),
                CompareCenter(snapshot.Center),
                CompareScalar("Surface area", snapshot.SurfaceArea, ExpectedSurfaceArea, ScalarTolerance, "model-unit^2"),
                new Finding(
                    FeatureId,
                    snapshot.NoMutationConfirmed ? ResultStatus.Passed : ResultStatus.Failed,
                    snapshot.NoMutationConfirmed
                        ? "No-mutation evidence remained unchanged during the U1 read."
                        : "No-mutation evidence changed or could not be confirmed during the U1 read.")
            };

            foreach (string evidence in snapshot.DiagnosticEvidence)
            {
                findings.Add(new Finding(
                    FeatureId,
                    ResultStatus.Warning,
                    "Step 08A diagnostic evidence — " + evidence));
            }

            ResultStatus status = FindingAggregation.Aggregate(findings, ResultStatus.Passed);
            string message = "U1 in-process confirmation for " + snapshot.ModelTitle + " body " +
                snapshot.BodyId.ToString(CultureInfo.InvariantCulture) + " completed with status " + status + ".";
            return new FeatureExecutionOutcome(status, message, findings);
        }

        private static Finding CompareScalar(string label, double actual, double expected, double tolerance, string unit)
        {
            bool matched = Math.Abs(actual - expected) <= tolerance;
            string message = label + (matched ? " matched" : " did not match") +
                " the locked Step 07 known answer. Actual=" + actual.ToString("R", CultureInfo.InvariantCulture) +
                "; Expected=" + expected.ToString("R", CultureInfo.InvariantCulture) +
                "; Tolerance=" + tolerance.ToString("R", CultureInfo.InvariantCulture) + ".";
            return new Finding(
                FeatureId,
                matched ? ResultStatus.Passed : ResultStatus.Failed,
                message,
                new Measurement(actual, unit),
                new Measurement(expected, unit));
        }

        private static Finding CompareCenter(Point3 actual)
        {
            bool matched =
                Math.Abs(actual.X - ExpectedCenterX) <= CenterTolerance &&
                Math.Abs(actual.Y - ExpectedCenterY) <= CenterTolerance &&
                Math.Abs(actual.Z - ExpectedCenterZ) <= CenterTolerance;

            string message = "Center " + (matched ? "matched" : "did not match") +
                " the locked Step 07 known answer. Actual=[" +
                actual.X.ToString("R", CultureInfo.InvariantCulture) + "," +
                actual.Y.ToString("R", CultureInfo.InvariantCulture) + "," +
                actual.Z.ToString("R", CultureInfo.InvariantCulture) +
                "]; Expected=[50,30,20]; Tolerance=" + CenterTolerance.ToString("R", CultureInfo.InvariantCulture) + ".";

            return new Finding(FeatureId, matched ? ResultStatus.Passed : ResultStatus.Failed, message, location: actual);
        }
    }
}
