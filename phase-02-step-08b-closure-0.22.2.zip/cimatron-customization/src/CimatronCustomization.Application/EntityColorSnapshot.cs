using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class EntityColorSnapshot
    {
        public EntityColorSnapshot(ModelEntityReference reference, int color)
        {
            Reference = reference ?? throw new ArgumentNullException(nameof(reference));
            Color = color;
        }

        public ModelEntityReference Reference { get; }
        public int Color { get; }
    }
}
