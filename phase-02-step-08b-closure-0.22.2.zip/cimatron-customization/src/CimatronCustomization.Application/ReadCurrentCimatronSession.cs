using System;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Application use case for reading the current Cimatron session state.
    /// </summary>
    public sealed class ReadCurrentCimatronSession
    {
        private readonly ICimatronSession session;

        public ReadCurrentCimatronSession(ICimatronSession session)
        {
            this.session = session ?? throw new ArgumentNullException(nameof(session));
        }

        public CimatronSessionSnapshot Execute()
        {
            return session.GetCurrentSession();
        }
    }
}
