using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularTable
    {
        private readonly TabularRow[] rows;

        public TabularTable(TabularSourceDefinition source, IEnumerable<TabularRow> rows)
        {
            Source = source ?? throw new ArgumentNullException(nameof(source));
            if (rows == null) throw new ArgumentNullException(nameof(rows));

            this.rows = rows.ToArray();
            if (this.rows.Any(row => row == null)) throw new ArgumentException("Rows cannot contain null entries.", nameof(rows));

            foreach (TabularRow row in this.rows)
            {
                foreach (TabularColumnDefinition column in Source.Columns.Where(column => column.IsRequired))
                {
                    if (!row.TryGetValue(column.LogicalName, out TabularValue value))
                        throw new ArgumentException("A row is missing required logical column '" + column.LogicalName + "'.", nameof(rows));
                    if (value.ValueType != column.ValueType)
                        throw new ArgumentException("A row has the wrong value type for logical column '" + column.LogicalName + "'.", nameof(rows));
                }
            }
        }

        public TabularSourceDefinition Source { get; }
        public IReadOnlyList<TabularRow> Rows => rows;
    }
}
