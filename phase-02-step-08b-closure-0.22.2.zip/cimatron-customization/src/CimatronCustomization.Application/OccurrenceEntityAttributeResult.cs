using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class OccurrenceEntityAttributeResult
    {
        public OccurrenceEntityAttributeResult(
            string assemblyTitle,
            string targetModelTitle,
            int totalOccurrenceCount,
            int topLevelOccurrenceCount,
            int nestedOccurrenceCount,
            int nestedInstanceId,
            int bodyId,
            int bodyMatchCount,
            string bodyType,
            bool attributeFound,
            string attributeType,
            string attributeValue,
            string returnedAttributeName,
            ModelEntityReference nestedBodyReference,
            bool noMutationConfirmed)
        {
            AssemblyTitle = assemblyTitle ?? string.Empty;
            TargetModelTitle = targetModelTitle ?? string.Empty;
            TotalOccurrenceCount = totalOccurrenceCount;
            TopLevelOccurrenceCount = topLevelOccurrenceCount;
            NestedOccurrenceCount = nestedOccurrenceCount;
            NestedInstanceId = nestedInstanceId;
            BodyId = bodyId;
            BodyMatchCount = bodyMatchCount;
            BodyType = bodyType ?? string.Empty;
            AttributeFound = attributeFound;
            AttributeType = attributeType ?? string.Empty;
            AttributeValue = attributeValue ?? string.Empty;
            ReturnedAttributeName = returnedAttributeName ?? string.Empty;
            NestedBodyReference = nestedBodyReference;
            NoMutationConfirmed = noMutationConfirmed;
        }

        public string AssemblyTitle { get; }
        public string TargetModelTitle { get; }
        public int TotalOccurrenceCount { get; }
        public int TopLevelOccurrenceCount { get; }
        public int NestedOccurrenceCount { get; }
        public int NestedInstanceId { get; }
        public int BodyId { get; }
        public int BodyMatchCount { get; }
        public string BodyType { get; }
        public bool AttributeFound { get; }
        public string AttributeType { get; }
        public string AttributeValue { get; }
        public string ReturnedAttributeName { get; }
        public ModelEntityReference NestedBodyReference { get; }
        public bool NoMutationConfirmed { get; }
    }
}
