namespace CimatronCustomization.Application
{
    public interface IApplicationLogger
    {
        void Log(ApplicationLogEntry entry);
    }
}
