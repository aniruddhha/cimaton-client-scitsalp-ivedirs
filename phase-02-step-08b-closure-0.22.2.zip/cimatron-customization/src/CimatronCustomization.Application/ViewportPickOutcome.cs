namespace CimatronCustomization.Application
{
    public enum ViewportPickOutcome
    {
        Picked,
        Cancelled,
        Unsupported,
        Failed,
        Busy,
        StaleResult
    }
}
