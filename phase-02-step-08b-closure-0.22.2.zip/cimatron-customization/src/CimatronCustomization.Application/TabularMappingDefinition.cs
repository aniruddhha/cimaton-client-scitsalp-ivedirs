using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularMappingDefinition
    {
        private readonly TabularFieldMappingDefinition[] fields;

        public TabularMappingDefinition(string name, IEnumerable<TabularFieldMappingDefinition> fields)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("A mapping name is required.", nameof(name));
            if (fields == null) throw new ArgumentNullException(nameof(fields));

            this.fields = fields.ToArray();
            if (this.fields.Length == 0) throw new ArgumentException("At least one field mapping is required.", nameof(fields));
            if (this.fields.Any(field => field == null)) throw new ArgumentException("Field mappings cannot contain null entries.", nameof(fields));
            if (this.fields.GroupBy(field => field.LogicalName, StringComparer.OrdinalIgnoreCase).Any(group => group.Count() > 1))
                throw new ArgumentException("Logical field names must be unique within a mapping.", nameof(fields));

            string[] allHeaders = this.fields.SelectMany(field => field.SourceHeaders).ToArray();
            if (allHeaders.GroupBy(value => value, StringComparer.OrdinalIgnoreCase).Any(group => group.Count() > 1))
                throw new ArgumentException("A source header candidate cannot be assigned to more than one logical field.", nameof(fields));

            Name = name;
        }

        public string Name { get; }
        public IReadOnlyList<TabularFieldMappingDefinition> Fields => fields;
    }
}
