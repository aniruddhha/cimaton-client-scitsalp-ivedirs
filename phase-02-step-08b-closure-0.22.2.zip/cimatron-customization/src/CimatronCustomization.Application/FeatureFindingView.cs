using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>Presentation-safe projection of a Domain finding for Plugin/UI consumers.</summary>
    public sealed class FeatureFindingView
    {
        private readonly string[] entityReferenceValues;

        internal FeatureFindingView(Finding finding)
        {
            if (finding == null) throw new ArgumentNullException(nameof(finding));

            RequirementId = finding.RequirementId;
            StatusText = finding.Status.ToString();
            Message = finding.Message;
            MeasuredValueText = FormatMeasurement(finding.MeasuredValue);
            LimitText = FormatMeasurement(finding.Limit);

            List<string> referenceValues = new List<string>();
            foreach (ModelEntityReference reference in finding.EntityReferences)
            {
                if (reference != null)
                {
                    referenceValues.Add(reference.Value);
                }
            }
            entityReferenceValues = referenceValues.ToArray();
        }

        public string RequirementId { get; }
        public string StatusText { get; }
        public string Message { get; }
        public string MeasuredValueText { get; }
        public string LimitText { get; }
        public string[] EntityReferenceValues => (string[])entityReferenceValues.Clone();

        private static string FormatMeasurement(Measurement measurement)
        {
            return measurement == null
                ? string.Empty
                : measurement.Value.ToString(System.Globalization.CultureInfo.InvariantCulture) + " " + measurement.Unit;
        }
    }
}
