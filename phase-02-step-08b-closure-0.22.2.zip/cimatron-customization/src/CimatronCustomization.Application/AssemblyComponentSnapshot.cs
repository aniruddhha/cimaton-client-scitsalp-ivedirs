using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class AssemblyComponentSnapshot
    {
        private readonly double[] placementMatrix;

        public AssemblyComponentSnapshot(
            ModelEntityReference reference,
            int instanceId,
            int? parentInstanceId,
            string modelTitle,
            string modelPath,
            CimatronDocumentContext modelContext,
            int color,
            bool isSuppressed,
            IEnumerable<double> placementMatrix = null)
        {
            Reference = reference ?? throw new ArgumentNullException(nameof(reference));
            if (string.IsNullOrWhiteSpace(modelTitle)) throw new ArgumentException("A model title is required.", nameof(modelTitle));
            ModelTitle = modelTitle;
            ModelPath = modelPath ?? string.Empty;
            ModelContext = modelContext;
            InstanceId = instanceId;
            ParentInstanceId = parentInstanceId;
            Color = color;
            IsSuppressed = isSuppressed;
            this.placementMatrix = placementMatrix == null ? Array.Empty<double>() : new List<double>(placementMatrix).ToArray();
        }

        public ModelEntityReference Reference { get; }
        public int InstanceId { get; }
        public int? ParentInstanceId { get; }
        public string ModelTitle { get; }
        public string ModelPath { get; }
        public CimatronDocumentContext ModelContext { get; }
        public int Color { get; }
        public bool IsSuppressed { get; }
        public IReadOnlyList<double> PlacementMatrix => placementMatrix;
        public bool HasPlacementMatrix => placementMatrix.Length > 0;
    }
}
