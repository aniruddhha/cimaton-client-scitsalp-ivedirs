using System;
using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    /// <summary>Lists registered features with applicability for the current document context.</summary>
    public sealed class ListAvailableFeatures
    {
        private readonly FeatureRegistry registry;

        public ListAvailableFeatures(FeatureRegistry registry)
        {
            this.registry = registry ?? throw new ArgumentNullException(nameof(registry));
        }

        public FeatureAvailability[] Execute(CimatronSessionSnapshot session)
        {
            if (session == null) throw new ArgumentNullException(nameof(session));

            List<FeatureAvailability> result = new List<FeatureAvailability>();
            foreach (FeatureDefinition definition in registry.GetDefinitions())
            {
                bool applicable;
                string reason;
                Evaluate(definition, session, out applicable, out reason);
                result.Add(new FeatureAvailability(
                    definition.Id,
                    definition.Name,
                    definition.Kind,
                    definition.FunctionalGroup,
                    string.Join(", ", definition.RequirementIds),
                    definition.RequiredDocumentContext.ToString(),
                    applicable,
                    reason));
            }

            return result.ToArray();
        }

        private static void Evaluate(FeatureDefinition definition, CimatronSessionSnapshot session, out bool applicable, out string reason)
        {
            if (!session.IsApplicationAvailable)
            {
                applicable = false;
                reason = "Cimatron application is unavailable.";
                return;
            }

            if (!session.HasActiveDocument)
            {
                applicable = false;
                reason = "No active Cimatron document is available.";
                return;
            }

            applicable = IsContextApplicable(definition.RequiredDocumentContext, session.ActiveDocumentContext);
            reason = applicable
                ? "Applicable to the current " + session.ActiveDocumentContext + " document."
                : "Requires " + definition.RequiredDocumentContext + "; current context is " + session.ActiveDocumentContext + ".";
        }

        internal static bool IsContextApplicable(DocumentContextRequirement required, CimatronDocumentContext actual)
        {
            if (required == DocumentContextRequirement.Either)
            {
                return actual == CimatronDocumentContext.Part || actual == CimatronDocumentContext.Assembly;
            }

            if (required == DocumentContextRequirement.Part)
            {
                return actual == CimatronDocumentContext.Part;
            }

            return actual == CimatronDocumentContext.Assembly;
        }
    }
}
