using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class RuleParameterSet
    {
        private static readonly RuleParameterSet empty = new RuleParameterSet(Array.Empty<RuleParameterValue>());
        private readonly IReadOnlyDictionary<string, RuleParameterValue> values;

        public RuleParameterSet(IEnumerable<RuleParameterValue> values)
        {
            if (values == null) throw new ArgumentNullException(nameof(values));
            Dictionary<string, RuleParameterValue> map = new Dictionary<string, RuleParameterValue>(StringComparer.OrdinalIgnoreCase);
            foreach (RuleParameterValue value in values)
            {
                if (value == null) throw new ArgumentException("Parameter values cannot contain null entries.", nameof(values));
                if (map.ContainsKey(value.Definition.Name)) throw new ArgumentException("Duplicate parameter value: " + value.Definition.Name + ".", nameof(values));
                map.Add(value.Definition.Name, value);
            }
            this.values = new ReadOnlyDictionary<string, RuleParameterValue>(map);
        }

        public static RuleParameterSet Empty => empty;
        public int Count => values.Count;
        public IReadOnlyCollection<RuleParameterValue> Values => values.Values.ToArray();

        public bool TryGet(string name, out RuleParameterValue value)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("A parameter name is required.", nameof(name));
            return values.TryGetValue(name, out value);
        }

        public RuleParameterValue GetRequired(string name)
        {
            RuleParameterValue value;
            if (!TryGet(name, out value)) throw new InvalidOperationException("Validated rule parameter '" + name + "' is not available in the execution context.");
            return value;
        }
    }
}
