using System;

namespace CimatronCustomization.Application
{
    public sealed class CimatronRuntimeSnapshot
    {
        public CimatronRuntimeSnapshot(string productName, string version, CimatronSessionSnapshot session)
        {
            ProductName = productName ?? string.Empty;
            Version = version ?? string.Empty;
            Session = session ?? throw new ArgumentNullException(nameof(session));
        }
        public string ProductName { get; }
        public string Version { get; }
        public CimatronSessionSnapshot Session { get; }
    }
}
