namespace CimatronCustomization.Application
{
    public enum TabularProcessingStage
    {
        Discovery,
        Mapping,
        Read,
        Validation,
        Completed
    }
}
