using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class FaceTopologySnapshot
    {
        public FaceTopologySnapshot(ModelEntityReference reference, string geometryType, double area)
        {
            Reference = reference ?? throw new ArgumentNullException(nameof(reference));
            GeometryType = string.IsNullOrWhiteSpace(geometryType) ? "Unknown" : geometryType;
            Area = area;
        }

        public ModelEntityReference Reference { get; }
        public string GeometryType { get; }
        public double Area { get; }
    }
}
