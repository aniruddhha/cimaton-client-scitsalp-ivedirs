using System;
using System.Diagnostics;
using System.Linq;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Common execution pipeline for registry-backed validations and automations.
    /// Normal feature outcomes remain outcomes; unexpected execution exceptions become Error reports.
    /// </summary>
    public sealed class ExecuteRegisteredFeature
    {
        private const string OperationName = "ExecuteRegisteredFeature";
        private readonly FeatureRegistry registry;
        private readonly IApplicationLogger logger;
        private readonly string applicationVersion;
        private readonly IRuleParameterProvider ruleParameterProvider;

        public ExecuteRegisteredFeature(FeatureRegistry registry, IApplicationLogger logger, string applicationVersion)
            : this(registry, logger, applicationVersion, new MissingRuleParameterProvider())
        {
        }

        public ExecuteRegisteredFeature(FeatureRegistry registry, IApplicationLogger logger, string applicationVersion, IRuleParameterProvider ruleParameterProvider)
        {
            this.registry = registry ?? throw new ArgumentNullException(nameof(registry));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            if (string.IsNullOrWhiteSpace(applicationVersion))
            {
                throw new ArgumentException("An application version is required.", nameof(applicationVersion));
            }
            this.ruleParameterProvider = ruleParameterProvider ?? throw new ArgumentNullException(nameof(ruleParameterProvider));
            this.applicationVersion = applicationVersion;
        }

        public FeatureExecutionReport Execute(string featureId, FeatureExecutionContext context, string cimatronVersion)
        {
            if (string.IsNullOrWhiteSpace(featureId))
            {
                throw new ArgumentException("A feature id is required.", nameof(featureId));
            }

            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            Stopwatch stopwatch = Stopwatch.StartNew();
            IApplicationFeature feature = null;
            FeatureExecutionReport report;

            try
            {
                feature = registry.GetFeature(featureId);
                FeatureDefinition definition = feature.Definition;

                FeatureExecutionReport applicabilityReport = EvaluateApplicability(definition, context.Session, stopwatch);
                if (applicabilityReport != null)
                {
                    report = applicabilityReport;
                }
                else
                {
                    RuleParameterSet ruleParameters = definition.RuleParameterDefinitions.Count == 0
                        ? RuleParameterSet.Empty
                        : ruleParameterProvider.LoadFor(definition);
                    FeatureExecutionContext featureContext = context.WithRuleParameters(ruleParameters);
                    FeatureExecutionOutcome outcome = feature.Execute(featureContext);
                    if (outcome == null)
                    {
                        throw new InvalidOperationException("The registered feature returned no execution outcome.");
                    }

                    ValidateOutcomeForFeature(definition, outcome);
                    ResultStatus effectiveStatus = FindingAggregation.Aggregate(outcome.Findings, outcome.Status);
                    stopwatch.Stop();
                    report = new FeatureExecutionReport(
                        definition.Id,
                        definition.Name,
                        definition.Kind,
                        effectiveStatus,
                        outcome.Message,
                        stopwatch.ElapsedMilliseconds,
                        outcome.Findings);
                }
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                FeatureDefinition definition = feature?.Definition;
                string errorMessage = string.IsNullOrWhiteSpace(exception.Message)
                    ? "Registered feature execution failed."
                    : exception.Message;
                report = new FeatureExecutionReport(
                    definition?.Id ?? featureId,
                    definition?.Name ?? "Unregistered Feature",
                    definition?.Kind,
                    ResultStatus.Error,
                    errorMessage,
                    stopwatch.ElapsedMilliseconds,
                    exception: exception);
            }

            FeatureDefinition loggedDefinition = feature?.Definition;
            string requirementIds = loggedDefinition == null
                ? string.Empty
                : string.Join(",", loggedDefinition.RequirementIds);
            string logMessage = "Findings=" + report.Findings.Count + "; " + report.Message;

            logger.Log(new ApplicationLogEntry(
                DateTimeOffset.UtcNow,
                GetLogLevel(report.Status),
                context.CorrelationId,
                applicationVersion,
                cimatronVersion ?? string.Empty,
                report.FeatureName,
                requirementIds,
                OperationName,
                report.Status.ToString(),
                report.DurationMilliseconds,
                logMessage,
                report.Exception));

            return report;
        }

        private static FeatureExecutionReport EvaluateApplicability(
            FeatureDefinition definition,
            CimatronSessionSnapshot session,
            Stopwatch stopwatch)
        {
            if (!session.IsApplicationAvailable)
            {
                stopwatch.Stop();
                return new FeatureExecutionReport(
                    definition.Id, definition.Name, definition.Kind, ResultStatus.Error,
                    "Cimatron is not available, so the feature cannot be evaluated reliably.",
                    stopwatch.ElapsedMilliseconds);
            }

            if (!session.HasActiveDocument)
            {
                stopwatch.Stop();
                return new FeatureExecutionReport(
                    definition.Id, definition.Name, definition.Kind, ResultStatus.Error,
                    "No active Cimatron document is available for this feature.",
                    stopwatch.ElapsedMilliseconds);
            }

            bool applicable = ListAvailableFeatures.IsContextApplicable(
                definition.RequiredDocumentContext,
                session.ActiveDocumentContext);

            if (!applicable)
            {
                stopwatch.Stop();
                return new FeatureExecutionReport(
                    definition.Id, definition.Name, definition.Kind, ResultStatus.NotApplicable,
                    "The feature is not applicable to the active document context: " + session.ActiveDocumentContext + ".",
                    stopwatch.ElapsedMilliseconds);
            }

            return null;
        }

        private static void ValidateOutcomeForFeature(FeatureDefinition definition, FeatureExecutionOutcome outcome)
        {
            if (definition.Kind == FeatureKind.Validation)
            {
                if (outcome.Status == ResultStatus.Succeeded)
                {
                    throw new InvalidOperationException("Succeeded is reserved for successful Automation outcomes; Validation features must use Passed.");
                }

                foreach (Finding finding in outcome.Findings)
                {
                    if (finding.Status == ResultStatus.Succeeded)
                    {
                        throw new InvalidOperationException("Validation findings cannot use Succeeded; use Passed for successful validation findings.");
                    }
                }
            }
        }

        private sealed class MissingRuleParameterProvider : IRuleParameterProvider
        {
            public RuleParameterSet LoadFor(FeatureDefinition definition)
            {
                throw new InvalidOperationException("A rule parameter provider is required for feature '" + definition.Id + "'.");
            }
        }

        private static string GetLogLevel(ResultStatus status)
        {
            if (status == ResultStatus.Error)
            {
                return "Error";
            }

            if (status == ResultStatus.Warning)
            {
                return "Warning";
            }

            return "Information";
        }
    }
}
