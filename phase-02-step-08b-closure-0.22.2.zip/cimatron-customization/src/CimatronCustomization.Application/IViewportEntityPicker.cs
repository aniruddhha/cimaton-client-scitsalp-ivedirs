using System;
using System.Threading;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Starts one non-blocking viewport pick request from the Cimatron STA/UI thread. Active PickTool
    /// completion is raised on that same COM event thread. Consumers must not move live COM access to
    /// a thread-pool continuation. Returned entity ids are valid only for SourceDocument in this session.
    /// </summary>
    public interface IViewportEntityPicker
    {
        bool IsActive { get; }

        void BeginPick(
            ViewportPickRequest request,
            CancellationToken cancellationToken,
            Action<ViewportPickResult> completion);

        ViewportPickResult ValidateForCurrentDocument(ViewportPickResult result);
    }
}
