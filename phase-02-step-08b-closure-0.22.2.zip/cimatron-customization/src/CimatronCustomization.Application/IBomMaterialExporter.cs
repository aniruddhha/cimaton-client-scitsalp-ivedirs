namespace CimatronCustomization.Application
{
    /// <summary>Application boundary for a governed BOM export and material readback.</summary>
    public interface IBomMaterialExporter
    {
        BomMaterialExportResult ExportAndReadMaterial(string expectedAssemblyTitle, string targetModelTitle);
    }
}
