using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularHeaderDiscoveryResult
    {
        private readonly string[] headers;

        private TabularHeaderDiscoveryResult(bool isSuccess, IEnumerable<string> headers, string errorCode, string errorMessage)
        {
            IsSuccess = isSuccess;
            this.headers = (headers ?? Enumerable.Empty<string>()).Select(value => value ?? string.Empty).ToArray();
            ErrorCode = errorCode ?? string.Empty;
            ErrorMessage = errorMessage ?? string.Empty;
        }

        public bool IsSuccess { get; }
        public IReadOnlyList<string> Headers => headers;
        public string ErrorCode { get; }
        public string ErrorMessage { get; }

        public static TabularHeaderDiscoveryResult Succeeded(IEnumerable<string> headers)
        {
            if (headers == null) throw new ArgumentNullException(nameof(headers));
            return new TabularHeaderDiscoveryResult(true, headers, null, null);
        }

        public static TabularHeaderDiscoveryResult Error(string errorCode, string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(errorCode)) throw new ArgumentException("An actionable header-discovery error code is required.", nameof(errorCode));
            if (string.IsNullOrWhiteSpace(errorMessage)) throw new ArgumentException("An actionable header-discovery error message is required.", nameof(errorMessage));
            return new TabularHeaderDiscoveryResult(false, null, errorCode, errorMessage);
        }
    }
}
