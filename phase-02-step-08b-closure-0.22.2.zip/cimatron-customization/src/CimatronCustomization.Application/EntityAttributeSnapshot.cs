using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class EntityAttributeSnapshot
    {
        private readonly EntityAttributeValue[] attributes;

        public EntityAttributeSnapshot(ModelEntityReference reference, IEnumerable<EntityAttributeValue> attributes)
        {
            Reference = reference ?? throw new ArgumentNullException(nameof(reference));
            if (attributes == null) throw new ArgumentNullException(nameof(attributes));
            this.attributes = new List<EntityAttributeValue>(attributes).ToArray();
        }

        public ModelEntityReference Reference { get; }
        public IReadOnlyList<EntityAttributeValue> Attributes => attributes;
    }
}
