namespace CimatronCustomization.Application
{
    public interface ICimatronRuntimeInfo
    {
        CimatronRuntimeSnapshot GetCurrentRuntime();
    }
}
