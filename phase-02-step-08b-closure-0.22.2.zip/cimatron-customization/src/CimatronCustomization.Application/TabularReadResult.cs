using System;

namespace CimatronCustomization.Application
{
    public sealed class TabularReadResult
    {
        private TabularReadResult(bool isSuccess, TabularTable table, string errorCode, string errorMessage)
        {
            IsSuccess = isSuccess;
            Table = table;
            ErrorCode = errorCode;
            ErrorMessage = errorMessage;
        }

        public bool IsSuccess { get; }
        public TabularTable Table { get; }
        public string ErrorCode { get; }
        public string ErrorMessage { get; }

        public static TabularReadResult Succeeded(TabularTable table)
        {
            if (table == null) throw new ArgumentNullException(nameof(table));
            return new TabularReadResult(true, table, string.Empty, string.Empty);
        }

        public static TabularReadResult Error(string errorCode, string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(errorCode)) throw new ArgumentException("An actionable tabular-read error code is required.", nameof(errorCode));
            if (string.IsNullOrWhiteSpace(errorMessage)) throw new ArgumentException("An actionable tabular-read error message is required.", nameof(errorMessage));
            return new TabularReadResult(false, null, errorCode, errorMessage);
        }
    }
}
