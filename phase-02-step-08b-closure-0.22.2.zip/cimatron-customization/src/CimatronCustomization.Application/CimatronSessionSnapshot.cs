using System;

namespace CimatronCustomization.Application
{
    public sealed class CimatronSessionSnapshot
    {
        private CimatronSessionSnapshot(
            bool isApplicationAvailable,
            bool hasActiveDocument,
            CimatronDocumentContext activeDocumentContext)
        {
            IsApplicationAvailable = isApplicationAvailable;
            HasActiveDocument = hasActiveDocument;
            ActiveDocumentContext = activeDocumentContext;
        }

        public bool IsApplicationAvailable { get; }

        public bool HasActiveDocument { get; }

        public CimatronDocumentContext ActiveDocumentContext { get; }

        public bool HasSupportedDocumentContext =>
            ActiveDocumentContext == CimatronDocumentContext.Part ||
            ActiveDocumentContext == CimatronDocumentContext.Assembly ||
            ActiveDocumentContext == CimatronDocumentContext.Nc;

        public static CimatronSessionSnapshot ApplicationUnavailable()
        {
            return new CimatronSessionSnapshot(false, false, CimatronDocumentContext.None);
        }

        public static CimatronSessionSnapshot NoActiveDocument()
        {
            return new CimatronSessionSnapshot(true, false, CimatronDocumentContext.None);
        }

        public static CimatronSessionSnapshot ActiveDocument(CimatronDocumentContext documentContext)
        {
            if (documentContext == CimatronDocumentContext.None)
            {
                throw new ArgumentException("An active document cannot use the None context.", nameof(documentContext));
            }

            return new CimatronSessionSnapshot(true, true, documentContext);
        }
    }
}
