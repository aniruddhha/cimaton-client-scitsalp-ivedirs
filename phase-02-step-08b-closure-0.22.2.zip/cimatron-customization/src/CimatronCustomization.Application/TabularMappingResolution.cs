using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularMappingResolution
    {
        private readonly TabularColumnDefinition[] columns;
        private readonly TabularMappingValidationError[] errors;

        private TabularMappingResolution(
            IEnumerable<TabularColumnDefinition> columns,
            IEnumerable<TabularMappingValidationError> errors)
        {
            this.columns = (columns ?? Enumerable.Empty<TabularColumnDefinition>()).ToArray();
            this.errors = (errors ?? Enumerable.Empty<TabularMappingValidationError>()).ToArray();
        }

        public bool IsSuccess => errors.Length == 0;
        public IReadOnlyList<TabularColumnDefinition> Columns => columns;
        public IReadOnlyList<TabularMappingValidationError> Errors => errors;

        public static TabularMappingResolution Succeeded(IEnumerable<TabularColumnDefinition> columns)
        {
            if (columns == null) throw new ArgumentNullException(nameof(columns));
            return new TabularMappingResolution(columns, null);
        }

        public static TabularMappingResolution Failed(IEnumerable<TabularMappingValidationError> errors)
        {
            if (errors == null) throw new ArgumentNullException(nameof(errors));
            TabularMappingValidationError[] materialized = errors.ToArray();
            if (materialized.Length == 0) throw new ArgumentException("At least one mapping validation error is required.", nameof(errors));
            if (materialized.Any(error => error == null)) throw new ArgumentException("Mapping validation errors cannot contain null entries.", nameof(errors));
            return new TabularMappingResolution(null, materialized);
        }
    }
}
