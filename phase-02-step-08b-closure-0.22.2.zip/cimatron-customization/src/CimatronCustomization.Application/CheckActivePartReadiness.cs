using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Application use case for the internal foundation Active Part readiness vertical slice.
    /// </summary>
    public sealed class CheckActivePartReadiness
    {
        private readonly ICimatronSession session;

        public CheckActivePartReadiness(ICimatronSession session)
        {
            this.session = session ?? throw new ArgumentNullException(nameof(session));
        }

        public ActivePartReadinessOutcome Execute()
        {
            CimatronSessionSnapshot snapshot = session.GetCurrentSession();
            ActivePartReadinessResult result = ActivePartReadinessValidation.Evaluate(
                snapshot.IsApplicationAvailable,
                snapshot.HasActiveDocument,
                snapshot.ActiveDocumentContext == CimatronDocumentContext.Part);

            return new ActivePartReadinessOutcome(result.Status, result.Message);
        }
    }
}
