using System;

namespace CimatronCustomization.Application
{
    public sealed class ReadMappedTabularData
    {
        private readonly ITabularHeaderReader headerReader;
        private readonly ITabularDataReader dataReader;
        private readonly TabularMappingEngine mappingEngine;

        public ReadMappedTabularData(
            ITabularHeaderReader headerReader,
            ITabularDataReader dataReader,
            TabularMappingEngine mappingEngine)
        {
            this.headerReader = headerReader ?? throw new ArgumentNullException(nameof(headerReader));
            this.dataReader = dataReader ?? throw new ArgumentNullException(nameof(dataReader));
            this.mappingEngine = mappingEngine ?? throw new ArgumentNullException(nameof(mappingEngine));
        }

        public ReadMappedTabularDataResult Execute(
            TabularHeaderSourceDefinition source,
            TabularMappingDefinition mapping)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (mapping == null) throw new ArgumentNullException(nameof(mapping));

            TabularHeaderDiscoveryResult discovery = headerReader.DiscoverHeaders(source);
            if (!discovery.IsSuccess)
                return ReadMappedTabularDataResult.Error(TabularProcessingStage.Discovery, discovery.ErrorCode, discovery.ErrorMessage);

            TabularMappingResolution resolution = mappingEngine.ResolveHeaders(mapping, discovery.Headers);
            if (!resolution.IsSuccess)
            {
                TabularMappingValidationError firstError = resolution.Errors[0];
                return ReadMappedTabularDataResult.Error(TabularProcessingStage.Mapping, firstError.Code, firstError.Message);
            }

            TabularSourceDefinition mappedSource = new TabularSourceDefinition(
                source.FilePath,
                source.WorksheetName,
                source.HeaderRowNumber,
                resolution.Columns);

            TabularReadResult read = dataReader.Read(mappedSource, discovery.Headers);
            if (!read.IsSuccess)
                return ReadMappedTabularDataResult.Error(TabularProcessingStage.Read, read.ErrorCode, read.ErrorMessage);

            TabularRowValidationResult validation = mappingEngine.ValidateRows(mapping, read.Table.Rows);
            if (!validation.IsSuccess)
            {
                TabularMappingValidationError firstError = validation.Errors[0];
                return ReadMappedTabularDataResult.Error(TabularProcessingStage.Validation, firstError.Code, firstError.Message);
            }

            return ReadMappedTabularDataResult.Passed(new TabularTable(mappedSource, validation.Rows));
        }
    }
}
