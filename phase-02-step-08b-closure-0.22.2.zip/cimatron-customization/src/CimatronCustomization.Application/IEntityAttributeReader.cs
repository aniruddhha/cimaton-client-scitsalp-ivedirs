using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public interface IEntityAttributeReader
    {
        ModelReadResult<EntityAttributeSnapshot> ReadAttributes(ModelEntityReference entityReference);
    }
}
