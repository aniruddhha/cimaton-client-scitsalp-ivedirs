namespace CimatronCustomization.Application
{
    /// <summary>
    /// Executable feature contract used by the application registry.
    /// Concrete validations and automations may implement this contract without the registry knowing their type.
    /// </summary>
    public interface IApplicationFeature
    {
        FeatureDefinition Definition { get; }

        FeatureExecutionOutcome Execute(FeatureExecutionContext context);
    }
}
