using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class ModelReadResult<T>
    {
        private ModelReadResult(ResultStatus status, string message, T value)
        {
            Status = status;
            Message = string.IsNullOrWhiteSpace(message) ? status.ToString() : message;
            Value = value;
        }

        public ResultStatus Status { get; }
        public string Message { get; }
        public T Value { get; }
        public bool IsAvailable => Status == ResultStatus.Passed;

        public static ModelReadResult<T> Passed(T value, string message)
        {
            if (value == null) throw new ArgumentNullException(nameof(value));
            return new ModelReadResult<T>(ResultStatus.Passed, message, value);
        }

        public static ModelReadResult<T> Unsupported(string message)
        {
            return new ModelReadResult<T>(ResultStatus.Unsupported, message, default(T));
        }
    }
}
