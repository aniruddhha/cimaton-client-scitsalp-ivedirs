using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Read-only geometry values returned for one body in the active Cimatron Part.
    /// </summary>
    public sealed class BodyGeometryMetricsSnapshot
    {
        private readonly string[] diagnosticEvidence;
        public BodyGeometryMetricsSnapshot(
            string modelTitle,
            int bodyId,
            double volume,
            Point3 center,
            double surfaceArea,
            bool noMutationConfirmed,
            string[] diagnosticEvidence = null)
        {
            if (string.IsNullOrWhiteSpace(modelTitle))
            {
                throw new ArgumentException("A model title is required.", nameof(modelTitle));
            }

            ModelTitle = modelTitle;
            BodyId = bodyId;
            Volume = volume;
            Center = center;
            SurfaceArea = surfaceArea;
            NoMutationConfirmed = noMutationConfirmed;
            this.diagnosticEvidence = diagnosticEvidence == null ? Array.Empty<string>() : (string[])diagnosticEvidence.Clone();
        }

        public string ModelTitle { get; }
        public int BodyId { get; }
        public double Volume { get; }
        public Point3 Center { get; }
        public double SurfaceArea { get; }
        public bool NoMutationConfirmed { get; }
        public string[] DiagnosticEvidence => (string[])diagnosticEvidence.Clone();
    }
}
