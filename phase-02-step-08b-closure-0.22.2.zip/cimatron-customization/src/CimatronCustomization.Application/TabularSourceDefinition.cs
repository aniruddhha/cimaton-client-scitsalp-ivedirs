using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularSourceDefinition
    {
        private readonly TabularColumnDefinition[] columns;

        public TabularSourceDefinition(
            string filePath,
            string worksheetName,
            int headerRowNumber,
            IEnumerable<TabularColumnDefinition> columns)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentException("A tabular input file path is required.", nameof(filePath));
            if (string.IsNullOrWhiteSpace(worksheetName)) throw new ArgumentException("A worksheet name is required.", nameof(worksheetName));
            if (headerRowNumber < 1) throw new ArgumentOutOfRangeException(nameof(headerRowNumber), "The header row number must be at least 1.");
            if (columns == null) throw new ArgumentNullException(nameof(columns));

            this.columns = columns.ToArray();
            if (this.columns.Length == 0) throw new ArgumentException("At least one column mapping is required.", nameof(columns));
            if (this.columns.Any(column => column == null)) throw new ArgumentException("Column mappings cannot contain null entries.", nameof(columns));
            if (HasDuplicates(this.columns.Select(column => column.LogicalName)))
                throw new ArgumentException("Logical column names must be unique.", nameof(columns));
            if (HasDuplicates(this.columns.Select(column => column.SourceHeader)))
                throw new ArgumentException("Source headers must be unique.", nameof(columns));

            FilePath = filePath;
            WorksheetName = worksheetName;
            HeaderRowNumber = headerRowNumber;
        }

        public string FilePath { get; }
        public string WorksheetName { get; }
        public int HeaderRowNumber { get; }
        public IReadOnlyList<TabularColumnDefinition> Columns => columns;

        private static bool HasDuplicates(IEnumerable<string> values)
        {
            return values.GroupBy(value => value, StringComparer.OrdinalIgnoreCase).Any(group => group.Count() > 1);
        }
    }
}
