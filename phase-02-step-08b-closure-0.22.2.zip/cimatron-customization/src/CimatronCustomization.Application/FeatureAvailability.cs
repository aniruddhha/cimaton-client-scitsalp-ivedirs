using System;

namespace CimatronCustomization.Application
{
    /// <summary>Presentation-safe availability metadata for one registered feature.</summary>
    public sealed class FeatureAvailability
    {
        public FeatureAvailability(
            string featureId,
            string name,
            FeatureKind kind,
            string functionalGroup,
            string requirementIdsText,
            string requiredDocumentContextText,
            bool isApplicable,
            string reason)
        {
            if (string.IsNullOrWhiteSpace(featureId)) throw new ArgumentException("A feature id is required.", nameof(featureId));
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("A feature name is required.", nameof(name));
            if (string.IsNullOrWhiteSpace(functionalGroup)) throw new ArgumentException("A functional group is required.", nameof(functionalGroup));
            if (string.IsNullOrWhiteSpace(requirementIdsText)) throw new ArgumentException("Requirement ids are required.", nameof(requirementIdsText));
            if (string.IsNullOrWhiteSpace(requiredDocumentContextText)) throw new ArgumentException("A document context is required.", nameof(requiredDocumentContextText));
            if (string.IsNullOrWhiteSpace(reason)) throw new ArgumentException("An availability reason is required.", nameof(reason));

            FeatureId = featureId;
            Name = name;
            Kind = kind;
            FunctionalGroup = functionalGroup;
            RequirementIdsText = requirementIdsText;
            RequiredDocumentContextText = requiredDocumentContextText;
            IsApplicable = isApplicable;
            Reason = reason;
        }

        public string FeatureId { get; }
        public string Name { get; }
        public FeatureKind Kind { get; }
        public string FunctionalGroup { get; }
        public string RequirementIdsText { get; }
        public string RequiredDocumentContextText { get; }
        public bool IsApplicable { get; }
        public string Reason { get; }
    }
}
