using System;

namespace CimatronCustomization.Application
{
    public sealed class TabularMappingValidationError
    {
        public TabularMappingValidationError(string code, string message, string logicalName, int? sourceRowNumber)
        {
            if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("A mapping validation error code is required.", nameof(code));
            if (string.IsNullOrWhiteSpace(message)) throw new ArgumentException("A mapping validation error message is required.", nameof(message));

            Code = code;
            Message = message;
            LogicalName = logicalName ?? string.Empty;
            SourceRowNumber = sourceRowNumber;
        }

        public string Code { get; }
        public string Message { get; }
        public string LogicalName { get; }
        public int? SourceRowNumber { get; }
    }
}
