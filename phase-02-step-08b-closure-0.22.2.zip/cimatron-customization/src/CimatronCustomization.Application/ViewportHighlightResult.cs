using System;

namespace CimatronCustomization.Application
{
    /// <summary>Controlled outcome for a viewport highlight request. Unexpected runtime exceptions are not converted here.</summary>
    public sealed class ViewportHighlightResult
    {
        private ViewportHighlightResult(bool isHighlighted, string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("A viewport highlight result message is required.", nameof(message));
            }

            IsHighlighted = isHighlighted;
            Message = message;
        }

        public bool IsHighlighted { get; }
        public string Message { get; }

        public static ViewportHighlightResult Highlighted(string message)
        {
            return new ViewportHighlightResult(true, message);
        }

        public static ViewportHighlightResult Unsupported(string message)
        {
            return new ViewportHighlightResult(false, message);
        }
    }
}
