using System;

namespace CimatronCustomization.Application
{
    public sealed class ApplicationLogEntry
    {
        public ApplicationLogEntry(DateTimeOffset timestampUtc, string level, string correlationId, string applicationVersion,
            string cimatronVersion, string feature, string requirementId, string operation, string status,
            long durationMilliseconds, string message, Exception exception = null)
        {
            TimestampUtc = timestampUtc;
            Level = Require(level, nameof(level));
            CorrelationId = Require(correlationId, nameof(correlationId));
            ApplicationVersion = Require(applicationVersion, nameof(applicationVersion));
            CimatronVersion = cimatronVersion ?? string.Empty;
            Feature = Require(feature, nameof(feature));
            RequirementId = requirementId ?? string.Empty;
            Operation = Require(operation, nameof(operation));
            Status = Require(status, nameof(status));
            if (durationMilliseconds < 0) throw new ArgumentOutOfRangeException(nameof(durationMilliseconds));
            DurationMilliseconds = durationMilliseconds;
            Message = message ?? string.Empty;
            Exception = exception;
        }

        public DateTimeOffset TimestampUtc { get; }
        public string Level { get; }
        public string CorrelationId { get; }
        public string ApplicationVersion { get; }
        public string CimatronVersion { get; }
        public string Feature { get; }
        public string RequirementId { get; }
        public string Operation { get; }
        public string Status { get; }
        public long DurationMilliseconds { get; }
        public string Message { get; }
        public Exception Exception { get; }

        private static string Require(string value, string name)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException(name + " is required.", name);
            return value;
        }
    }
}
