using System;

namespace CimatronCustomization.Application
{
    public sealed class TabularHeaderSourceDefinition
    {
        public TabularHeaderSourceDefinition(string filePath, string worksheetName, int headerRowNumber)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentException("A tabular input file path is required.", nameof(filePath));
            if (string.IsNullOrWhiteSpace(worksheetName)) throw new ArgumentException("A worksheet name is required.", nameof(worksheetName));
            if (headerRowNumber < 1) throw new ArgumentOutOfRangeException(nameof(headerRowNumber));

            FilePath = filePath;
            WorksheetName = worksheetName;
            HeaderRowNumber = headerRowNumber;
        }

        public string FilePath { get; }
        public string WorksheetName { get; }
        public int HeaderRowNumber { get; }
    }
}
