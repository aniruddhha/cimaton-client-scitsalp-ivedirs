using System;

namespace CimatronCustomization.Application
{
    public sealed class EntityAttributeValue
    {
        public EntityAttributeValue(string name, string type, string value)
        {
            Name = name ?? string.Empty;
            Type = string.IsNullOrWhiteSpace(type) ? "Unknown" : type;
            Value = value ?? string.Empty;
        }

        public string Name { get; }
        public string Type { get; }
        public string Value { get; }
    }
}
