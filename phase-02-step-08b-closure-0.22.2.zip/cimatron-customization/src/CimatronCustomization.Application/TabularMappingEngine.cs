using System;
using System.Collections.Generic;
using System.Globalization;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularMappingEngine
    {
        [SuppressMessage("Performance", "CA1822:Mark members as static", Justification = "The mapping engine intentionally exposes an instance service API for application orchestration; making this member static would change that API shape without changing behavior.")]
        public TabularMappingResolution ResolveHeaders(
            TabularMappingDefinition mapping,
            IEnumerable<string> availableHeaders)
        {
            if (mapping == null) throw new ArgumentNullException(nameof(mapping));
            if (availableHeaders == null) throw new ArgumentNullException(nameof(availableHeaders));

            string[] headers = availableHeaders.Select(value => value ?? string.Empty).ToArray();
            List<TabularColumnDefinition> columns = new List<TabularColumnDefinition>();
            List<TabularMappingValidationError> errors = new List<TabularMappingValidationError>();

            foreach (TabularFieldMappingDefinition field in mapping.Fields)
            {
                List<string> matches = ResolveMatches(field, headers);
                if (matches.Count == 0)
                {
                    if (field.IsRequired)
                    {
                        errors.Add(new TabularMappingValidationError(
                            "TABULAR_MAPPING_REQUIRED_HEADER_MISSING",
                            "No configured source header was found for required logical field '" + field.LogicalName + "'.",
                            field.LogicalName,
                            null));
                    }
                    continue;
                }

                if (matches.Count > 1)
                {
                    errors.Add(new TabularMappingValidationError(
                        "TABULAR_MAPPING_HEADER_AMBIGUOUS",
                        "More than one configured source header matched logical field '" + field.LogicalName + "'.",
                        field.LogicalName,
                        null));
                    continue;
                }

                columns.Add(new TabularColumnDefinition(
                    field.LogicalName,
                    matches[0],
                    field.ValueType,
                    field.IsRequired));
            }

            return errors.Count == 0
                ? TabularMappingResolution.Succeeded(columns)
                : TabularMappingResolution.Failed(errors);
        }

        [SuppressMessage("Performance", "CA1822:Mark members as static", Justification = "The mapping engine intentionally exposes an instance service API for application orchestration; making this member static would change that API shape without changing behavior.")]
        public TabularRowValidationResult ValidateRows(
            TabularMappingDefinition mapping,
            IEnumerable<TabularRow> rows)
        {
            if (mapping == null) throw new ArgumentNullException(nameof(mapping));
            if (rows == null) throw new ArgumentNullException(nameof(rows));

            TabularRow[] materializedRows = rows.ToArray();
            if (materializedRows.Any(row => row == null)) throw new ArgumentException("Rows cannot contain null entries.", nameof(rows));

            List<TabularMappingValidationError> errors = new List<TabularMappingValidationError>();
            foreach (TabularRow row in materializedRows)
            {
                foreach (TabularFieldMappingDefinition field in mapping.Fields)
                {
                    if (!row.TryGetValue(field.LogicalName, out TabularValue value))
                    {
                        if (field.IsRequired)
                        {
                            errors.Add(new TabularMappingValidationError(
                                "TABULAR_MAPPING_REQUIRED_VALUE_MISSING",
                                "Required logical field '" + field.LogicalName + "' is missing at source row " + row.SourceRowNumber.ToString(CultureInfo.InvariantCulture) + ".",
                                field.LogicalName,
                                row.SourceRowNumber));
                        }
                        continue;
                    }

                    if (value.ValueType != field.ValueType)
                    {
                        errors.Add(new TabularMappingValidationError(
                            "TABULAR_MAPPING_VALUE_TYPE_MISMATCH",
                            "Logical field '" + field.LogicalName + "' has the wrong value type at source row " + row.SourceRowNumber.ToString(CultureInfo.InvariantCulture) + ".",
                            field.LogicalName,
                            row.SourceRowNumber));
                    }
                }
            }

            return errors.Count == 0
                ? TabularRowValidationResult.Succeeded(materializedRows)
                : TabularRowValidationResult.Failed(errors);
        }

        private static List<string> ResolveMatches(TabularFieldMappingDefinition field, string[] headers)
        {
            List<string> matches = new List<string>();
            foreach (string candidate in field.SourceHeaders)
            {
                int occurrences = headers.Count(header => string.Equals(header, candidate, StringComparison.OrdinalIgnoreCase));
                for (int index = 0; index < occurrences; index++)
                    matches.Add(candidate);
            }
            return matches;
        }
    }
}
