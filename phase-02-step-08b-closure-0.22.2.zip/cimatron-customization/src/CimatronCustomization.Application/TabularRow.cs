using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularRow
    {
        private readonly Dictionary<string, TabularValue> values;

        public TabularRow(int sourceRowNumber, IDictionary<string, TabularValue> values)
        {
            if (sourceRowNumber < 1) throw new ArgumentOutOfRangeException(nameof(sourceRowNumber), "The source row number must be at least 1.");
            if (values == null) throw new ArgumentNullException(nameof(values));
            if (values.Any(pair => string.IsNullOrWhiteSpace(pair.Key))) throw new ArgumentException("Logical column names cannot be empty.", nameof(values));
            if (values.Any(pair => pair.Value == null)) throw new ArgumentException("Tabular values cannot be null.", nameof(values));

            SourceRowNumber = sourceRowNumber;
            this.values = new Dictionary<string, TabularValue>(values, StringComparer.OrdinalIgnoreCase);
        }

        public int SourceRowNumber { get; }
        public IReadOnlyDictionary<string, TabularValue> Values => values;

        public bool TryGetValue(string logicalName, out TabularValue value)
        {
            if (string.IsNullOrWhiteSpace(logicalName))
            {
                value = null;
                return false;
            }

            return values.TryGetValue(logicalName, out value);
        }

        public TabularValue GetRequired(string logicalName)
        {
            if (!TryGetValue(logicalName, out TabularValue value))
                throw new ArgumentException("The requested logical column is not present in this row.", nameof(logicalName));
            return value;
        }
    }
}
