namespace CimatronCustomization.Application
{
    public enum CimatronDocumentContext
    {
        None = 0,
        Part = 1,
        Assembly = 2,
        Nc = 3,
        Unsupported = 4
    }
}
