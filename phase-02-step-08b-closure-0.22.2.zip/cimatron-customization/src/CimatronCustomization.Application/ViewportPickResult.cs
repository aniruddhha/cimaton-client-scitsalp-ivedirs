using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class ViewportPickResult
    {
        private readonly string[] occurrencePath;

        public ViewportPickResult(
            string correlationId,
            ViewportPickOutcome outcome,
            ViewportDocumentIdentity sourceDocument,
            int? entityId,
            ViewportEntityType entityType,
            IEnumerable<string> occurrencePath,
            string reasonCode,
            string message)
        {
            if (string.IsNullOrWhiteSpace(correlationId)) throw new ArgumentException("A correlation id is required.", nameof(correlationId));
            if (string.IsNullOrWhiteSpace(reasonCode)) throw new ArgumentException("A reason code is required.", nameof(reasonCode));
            if (string.IsNullOrWhiteSpace(message)) throw new ArgumentException("A result message is required.", nameof(message));
            if (outcome == ViewportPickOutcome.Picked && sourceDocument == null) throw new ArgumentNullException(nameof(sourceDocument));
            if (outcome == ViewportPickOutcome.Picked && !entityId.HasValue) throw new ArgumentException("A picked result requires an entity id.", nameof(entityId));
            if (outcome == ViewportPickOutcome.Picked && entityType == ViewportEntityType.Unknown) throw new ArgumentException("A picked result requires a known entity type.", nameof(entityType));

            CorrelationId = correlationId;
            Outcome = outcome;
            SourceDocument = sourceDocument;
            EntityId = entityId;
            EntityType = entityType;
            this.occurrencePath = occurrencePath == null ? Array.Empty<string>() : occurrencePath.Where(value => !string.IsNullOrWhiteSpace(value)).ToArray();
            ReasonCode = reasonCode;
            Message = message;
        }

        public string CorrelationId { get; }
        public ViewportPickOutcome Outcome { get; }
        public ViewportDocumentIdentity SourceDocument { get; }
        public int? EntityId { get; }
        public ViewportEntityType EntityType { get; }
        public IReadOnlyList<string> OccurrencePath => occurrencePath;
        public string ReasonCode { get; }
        public string Message { get; }

        public static ViewportPickResult WithoutEntity(
            string correlationId,
            ViewportPickOutcome outcome,
            ViewportDocumentIdentity sourceDocument,
            string reasonCode,
            string message)
        {
            if (outcome == ViewportPickOutcome.Picked)
            {
                throw new ArgumentException("Use the picked-result constructor for a Picked outcome.", nameof(outcome));
            }

            return new ViewportPickResult(
                correlationId,
                outcome,
                sourceDocument,
                null,
                ViewportEntityType.Unknown,
                Array.Empty<string>(),
                reasonCode,
                message);
        }
    }
}
