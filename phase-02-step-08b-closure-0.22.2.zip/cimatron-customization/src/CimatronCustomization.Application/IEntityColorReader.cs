using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public interface IEntityColorReader
    {
        ModelReadResult<EntityColorSnapshot> ReadColor(ModelEntityReference entityReference);
    }
}
