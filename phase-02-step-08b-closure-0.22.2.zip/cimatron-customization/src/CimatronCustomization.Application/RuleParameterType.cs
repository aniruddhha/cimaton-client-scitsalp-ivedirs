namespace CimatronCustomization.Application
{
    public enum RuleParameterType
    {
        String = 0,
        Integer = 1,
        Decimal = 2,
        Boolean = 3,
        ColorCode = 4
    }
}
