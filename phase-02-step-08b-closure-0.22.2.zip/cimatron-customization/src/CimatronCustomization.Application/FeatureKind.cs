namespace CimatronCustomization.Application
{
    /// <summary>
    /// High-level feature category used by the application registry.
    /// </summary>
    public enum FeatureKind
    {
        Validation = 0,
        Automation = 1
    }
}
