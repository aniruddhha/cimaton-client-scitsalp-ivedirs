namespace CimatronCustomization.Application
{
    public interface IStartupConfigurationProvider
    {
        StartupConfigurationSnapshot Load();
    }
}
