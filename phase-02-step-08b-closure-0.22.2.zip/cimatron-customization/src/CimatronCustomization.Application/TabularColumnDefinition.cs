using System;

namespace CimatronCustomization.Application
{
    public sealed class TabularColumnDefinition
    {
        public TabularColumnDefinition(string logicalName, string sourceHeader, TabularValueType valueType, bool isRequired)
        {
            if (string.IsNullOrWhiteSpace(logicalName)) throw new ArgumentException("A logical column name is required.", nameof(logicalName));
            if (string.IsNullOrWhiteSpace(sourceHeader)) throw new ArgumentException("A source header is required.", nameof(sourceHeader));

            LogicalName = logicalName;
            SourceHeader = sourceHeader;
            ValueType = valueType;
            IsRequired = isRequired;
        }

        public string LogicalName { get; }
        public string SourceHeader { get; }
        public TabularValueType ValueType { get; }
        public bool IsRequired { get; }
    }
}
