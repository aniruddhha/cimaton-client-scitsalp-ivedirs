using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace CimatronCustomization.Application
{
    public sealed class FeatureRunInputs
    {
        private readonly IReadOnlyDictionary<string, object> values;

        public FeatureRunInputs(IDictionary<string, object> values = null)
        {
            this.values = new ReadOnlyDictionary<string, object>(
                values == null
                    ? new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase)
                    : new Dictionary<string, object>(values, StringComparer.OrdinalIgnoreCase));
        }

        public IReadOnlyDictionary<string, object> Values => values;
    }
}
