using System;
using System.Diagnostics;

namespace CimatronCustomization.Application
{
    public sealed class RunStartupDiagnostics
    {
        private readonly IStartupConfigurationProvider configurationProvider;
        private readonly ICimatronRuntimeInfo runtimeInfo;
        private readonly IApplicationLogger logger;
        private readonly string applicationVersion;

        public RunStartupDiagnostics(IStartupConfigurationProvider configurationProvider, ICimatronRuntimeInfo runtimeInfo,
            IApplicationLogger logger, string applicationVersion)
        {
            this.configurationProvider = configurationProvider ?? throw new ArgumentNullException(nameof(configurationProvider));
            this.runtimeInfo = runtimeInfo ?? throw new ArgumentNullException(nameof(runtimeInfo));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.applicationVersion = string.IsNullOrWhiteSpace(applicationVersion) ? throw new ArgumentException("Application version is required.", nameof(applicationVersion)) : applicationVersion;
        }

        public StartupDiagnosticsReport Execute(string correlationId)
        {
            if (string.IsNullOrWhiteSpace(correlationId)) throw new ArgumentException("Correlation id is required.", nameof(correlationId));
            Stopwatch stopwatch = Stopwatch.StartNew();
            try
            {
                StartupConfigurationSnapshot configuration = configurationProvider.Load();
                CimatronRuntimeSnapshot runtime = runtimeInfo.GetCurrentRuntime();
                stopwatch.Stop();
                logger.Log(new ApplicationLogEntry(DateTimeOffset.UtcNow, "Information", correlationId, applicationVersion,
                    runtime.Version, "StartupDiagnostics", string.Empty, "RunStartupDiagnostics", "Succeeded",
                    stopwatch.ElapsedMilliseconds, "Startup diagnostics completed successfully."));
                return new StartupDiagnosticsReport(applicationVersion, configuration.SchemaVersion, runtime);
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                logger.Log(new ApplicationLogEntry(DateTimeOffset.UtcNow, "Error", correlationId, applicationVersion,
                    string.Empty, "StartupDiagnostics", string.Empty, "RunStartupDiagnostics", "Error",
                    stopwatch.ElapsedMilliseconds, "Startup diagnostics failed.", exception));
                throw;
            }
        }
    }
}
