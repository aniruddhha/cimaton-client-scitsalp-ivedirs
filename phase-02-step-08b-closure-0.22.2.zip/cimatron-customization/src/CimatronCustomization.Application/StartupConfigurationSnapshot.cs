using System;

namespace CimatronCustomization.Application
{
    public sealed class StartupConfigurationSnapshot
    {
        public StartupConfigurationSnapshot(int schemaVersion, string logDirectory, long maximumLogFileBytes, int retainedLogFileCount)
        {
            if (schemaVersion <= 0) throw new ArgumentOutOfRangeException(nameof(schemaVersion));
            if (string.IsNullOrWhiteSpace(logDirectory)) throw new ArgumentException("Log directory is required.", nameof(logDirectory));
            if (maximumLogFileBytes <= 0) throw new ArgumentOutOfRangeException(nameof(maximumLogFileBytes));
            if (retainedLogFileCount <= 0) throw new ArgumentOutOfRangeException(nameof(retainedLogFileCount));
            SchemaVersion = schemaVersion;
            LogDirectory = logDirectory;
            MaximumLogFileBytes = maximumLogFileBytes;
            RetainedLogFileCount = retainedLogFileCount;
        }

        public int SchemaVersion { get; }
        public string LogDirectory { get; }
        public long MaximumLogFileBytes { get; }
        public int RetainedLogFileCount { get; }
    }
}
