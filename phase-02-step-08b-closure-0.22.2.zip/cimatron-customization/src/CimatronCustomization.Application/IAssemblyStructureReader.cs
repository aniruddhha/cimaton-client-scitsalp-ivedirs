namespace CimatronCustomization.Application
{
    public interface IAssemblyStructureReader
    {
        ModelReadResult<AssemblyStructureSnapshot> ReadCurrentAssembly();
    }
}
