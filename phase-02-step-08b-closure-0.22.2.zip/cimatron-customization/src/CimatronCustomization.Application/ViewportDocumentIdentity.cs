using System;

namespace CimatronCustomization.Application
{
    public sealed class ViewportDocumentIdentity
    {
        public ViewportDocumentIdentity(string sessionDocumentToken, string documentType, string title, string path)
        {
            if (string.IsNullOrWhiteSpace(sessionDocumentToken)) throw new ArgumentException("A session document token is required.", nameof(sessionDocumentToken));
            SessionDocumentToken = sessionDocumentToken;
            DocumentType = documentType ?? string.Empty;
            Title = title ?? string.Empty;
            Path = path ?? string.Empty;
        }

        public string SessionDocumentToken { get; }
        public string DocumentType { get; }
        public string Title { get; }
        public string Path { get; }
    }
}
