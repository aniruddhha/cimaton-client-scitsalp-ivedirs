using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Application-boundary result returned by a registered feature.
    /// </summary>
    public sealed class FeatureExecutionOutcome
    {
        public FeatureExecutionOutcome(
            ResultStatus status,
            string message,
            IEnumerable<Finding> findings = null)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("A feature outcome message is required.", nameof(message));
            }

            Status = status;
            Message = message;
            Findings = new FindingCollection(findings ?? Array.Empty<Finding>());
        }

        public ResultStatus Status { get; }
        public string Message { get; }
        public FindingCollection Findings { get; }
    }
}
