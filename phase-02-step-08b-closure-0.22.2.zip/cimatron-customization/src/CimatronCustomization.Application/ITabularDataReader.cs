using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    public interface ITabularDataReader
    {
        TabularReadResult Read(TabularSourceDefinition source);
        TabularReadResult Read(TabularSourceDefinition source, IReadOnlyList<string> expectedHeaders);
    }
}
