namespace CimatronCustomization.Application
{
    public enum ViewportEntityType
    {
        Unknown,
        Body,
        Face,
        Edge,
        Vertex
    }
}
