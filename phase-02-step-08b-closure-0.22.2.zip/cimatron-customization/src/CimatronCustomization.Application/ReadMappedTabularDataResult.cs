using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class ReadMappedTabularDataResult
    {
        private ReadMappedTabularDataResult(
            ResultStatus status,
            TabularProcessingStage stage,
            TabularTable table,
            string errorCode,
            string errorMessage)
        {
            Status = status;
            Stage = stage;
            Table = table;
            ErrorCode = errorCode ?? string.Empty;
            ErrorMessage = errorMessage ?? string.Empty;
        }

        public ResultStatus Status { get; }
        public TabularProcessingStage Stage { get; }
        public TabularTable Table { get; }
        public string ErrorCode { get; }
        public string ErrorMessage { get; }
        public bool IsSuccess => Status == ResultStatus.Passed;

        public static ReadMappedTabularDataResult Passed(TabularTable table)
        {
            if (table == null) throw new ArgumentNullException(nameof(table));
            return new ReadMappedTabularDataResult(ResultStatus.Passed, TabularProcessingStage.Completed, table, null, null);
        }

        public static ReadMappedTabularDataResult Error(TabularProcessingStage stage, string errorCode, string errorMessage)
        {
            if (stage == TabularProcessingStage.Completed) throw new ArgumentException("Completed cannot be used as a failure stage.", nameof(stage));
            if (string.IsNullOrWhiteSpace(errorCode)) throw new ArgumentException("An actionable orchestration error code is required.", nameof(errorCode));
            if (string.IsNullOrWhiteSpace(errorMessage)) throw new ArgumentException("An actionable orchestration error message is required.", nameof(errorMessage));
            return new ReadMappedTabularDataResult(ResultStatus.Error, stage, null, errorCode, errorMessage);
        }
    }
}
