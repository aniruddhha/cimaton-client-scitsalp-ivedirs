using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Outer-boundary representation of the Domain readiness result.
    /// </summary>
    public sealed class ActivePartReadinessOutcome
    {
        public ActivePartReadinessOutcome(ResultStatus status, string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("A readiness outcome message is required.", nameof(message));
            }

            Status = status;
            Message = message;
        }

        public ResultStatus Status { get; }
        public string Message { get; }
    }
}
