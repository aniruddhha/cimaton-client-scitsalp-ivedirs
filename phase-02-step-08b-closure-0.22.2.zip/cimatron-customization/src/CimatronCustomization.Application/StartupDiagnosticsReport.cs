using System;

namespace CimatronCustomization.Application
{
    public sealed class StartupDiagnosticsReport
    {
        public StartupDiagnosticsReport(string applicationVersion, int configurationSchemaVersion, CimatronRuntimeSnapshot runtime)
        {
            ApplicationVersion = applicationVersion ?? throw new ArgumentNullException(nameof(applicationVersion));
            ConfigurationSchemaVersion = configurationSchemaVersion;
            Runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        }
        public string ApplicationVersion { get; }
        public int ConfigurationSchemaVersion { get; }
        public CimatronRuntimeSnapshot Runtime { get; }
    }
}
