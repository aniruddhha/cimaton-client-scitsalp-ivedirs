using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public interface IBodyTopologyReader
    {
        ModelReadResult<BodyTopologySnapshot> ReadCurrentTopology();
        ModelReadResult<Direction3> ReadFaceNormal(ModelEntityReference faceReference, Point3 point);
    }
}
