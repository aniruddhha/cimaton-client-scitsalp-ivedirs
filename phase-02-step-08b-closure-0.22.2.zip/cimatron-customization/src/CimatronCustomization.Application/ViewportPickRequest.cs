using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class ViewportPickRequest
    {
        private readonly ViewportEntityType[] allowedEntityTypes;

        public ViewportPickRequest(IEnumerable<ViewportEntityType> allowedEntityTypes)
        {
            if (allowedEntityTypes == null) throw new ArgumentNullException(nameof(allowedEntityTypes));
            this.allowedEntityTypes = allowedEntityTypes.Distinct().ToArray();
            if (this.allowedEntityTypes.Length == 0) throw new ArgumentException("At least one allowed entity type is required.", nameof(allowedEntityTypes));
            if (this.allowedEntityTypes.Contains(ViewportEntityType.Unknown))
            {
                throw new ArgumentException("Unknown cannot be used as an allowed pick entity type.", nameof(allowedEntityTypes));
            }
        }

        public IReadOnlyList<ViewportEntityType> AllowedEntityTypes => allowedEntityTypes;

        public bool Allows(ViewportEntityType entityType)
        {
            return allowedEntityTypes.Contains(entityType);
        }
    }
}
