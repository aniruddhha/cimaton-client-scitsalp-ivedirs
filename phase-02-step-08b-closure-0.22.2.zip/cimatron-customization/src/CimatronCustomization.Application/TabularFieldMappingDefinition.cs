using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularFieldMappingDefinition
    {
        private readonly string[] sourceHeaders;

        public TabularFieldMappingDefinition(
            string logicalName,
            IEnumerable<string> sourceHeaders,
            TabularValueType valueType,
            bool isRequired)
        {
            if (string.IsNullOrWhiteSpace(logicalName)) throw new ArgumentException("A logical field name is required.", nameof(logicalName));
            if (sourceHeaders == null) throw new ArgumentNullException(nameof(sourceHeaders));

            this.sourceHeaders = sourceHeaders.ToArray();
            if (this.sourceHeaders.Length == 0) throw new ArgumentException("At least one source header candidate is required.", nameof(sourceHeaders));
            if (this.sourceHeaders.Any(string.IsNullOrWhiteSpace)) throw new ArgumentException("Source header candidates cannot be blank.", nameof(sourceHeaders));
            if (this.sourceHeaders.GroupBy(value => value, StringComparer.OrdinalIgnoreCase).Any(group => group.Count() > 1))
                throw new ArgumentException("Source header candidates must be unique within a field mapping.", nameof(sourceHeaders));

            LogicalName = logicalName;
            ValueType = valueType;
            IsRequired = isRequired;
        }

        public string LogicalName { get; }
        public IReadOnlyList<string> SourceHeaders => sourceHeaders;
        public TabularValueType ValueType { get; }
        public bool IsRequired { get; }
    }
}
