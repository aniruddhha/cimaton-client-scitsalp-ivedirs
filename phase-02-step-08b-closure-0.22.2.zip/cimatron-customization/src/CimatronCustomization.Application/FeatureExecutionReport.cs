using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Standardized application-boundary report for one registered feature execution.
    /// </summary>
    public sealed class FeatureExecutionReport
    {
        public FeatureExecutionReport(
            string featureId,
            string featureName,
            FeatureKind? kind,
            ResultStatus status,
            string message,
            long durationMilliseconds,
            IEnumerable<Finding> findings = null,
            Exception exception = null)
        {
            if (string.IsNullOrWhiteSpace(featureId))
            {
                throw new ArgumentException("A feature id is required.", nameof(featureId));
            }

            if (string.IsNullOrWhiteSpace(featureName))
            {
                throw new ArgumentException("A feature name is required.", nameof(featureName));
            }

            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("A feature execution message is required.", nameof(message));
            }

            if (durationMilliseconds < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(durationMilliseconds));
            }

            FeatureId = featureId;
            FeatureName = featureName;
            Kind = kind;
            Status = status;
            Message = message;
            DurationMilliseconds = durationMilliseconds;
            Findings = new FindingCollection(findings ?? Array.Empty<Finding>());
            Exception = exception;
        }

        public string FeatureId { get; }
        public string FeatureName { get; }
        public FeatureKind? Kind { get; }
        public ResultStatus Status { get; }
        public string StatusText => Status.ToString();
        public string Message { get; }
        public long DurationMilliseconds { get; }
        public FindingCollection Findings { get; }
        public FeatureFindingView[] FindingViews
        {
            get
            {
                FeatureFindingView[] result = new FeatureFindingView[Findings.Count];
                for (int index = 0; index < Findings.Count; index++)
                {
                    result[index] = new FeatureFindingView(Findings[index]);
                }
                return result;
            }
        }
        public Exception Exception { get; }
    }
}
