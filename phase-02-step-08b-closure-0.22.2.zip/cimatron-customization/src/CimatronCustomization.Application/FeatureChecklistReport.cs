using System;
using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    /// <summary>Reports one sequential checklist run under a shared correlation id.</summary>
    public sealed class FeatureChecklistReport
    {
        private readonly FeatureExecutionReport[] reports;

        public FeatureChecklistReport(string correlationId, IEnumerable<FeatureExecutionReport> reports)
        {
            if (string.IsNullOrWhiteSpace(correlationId)) throw new ArgumentException("A correlation id is required.", nameof(correlationId));
            if (reports == null) throw new ArgumentNullException(nameof(reports));

            this.reports = new List<FeatureExecutionReport>(reports).ToArray();
            CorrelationId = correlationId;
        }

        public string CorrelationId { get; }
        public IReadOnlyList<FeatureExecutionReport> Reports => reports;
    }
}
