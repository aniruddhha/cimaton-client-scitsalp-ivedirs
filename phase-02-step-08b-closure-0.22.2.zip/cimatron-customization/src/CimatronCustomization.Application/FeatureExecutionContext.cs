using System;

namespace CimatronCustomization.Application
{
    public sealed class FeatureExecutionContext
    {
        public FeatureExecutionContext(
            string correlationId,
            CimatronSessionSnapshot session,
            RuleParameterSet ruleParameters = null,
            FeatureRunInputs runInputs = null)
        {
            if (string.IsNullOrWhiteSpace(correlationId)) throw new ArgumentException("A correlation id is required.", nameof(correlationId));
            CorrelationId = correlationId;
            Session = session ?? throw new ArgumentNullException(nameof(session));
            RuleParameters = ruleParameters ?? RuleParameterSet.Empty;
            RunInputs = runInputs ?? new FeatureRunInputs();
        }

        public string CorrelationId { get; }
        public CimatronSessionSnapshot Session { get; }
        public RuleParameterSet RuleParameters { get; }
        public FeatureRunInputs RunInputs { get; }

        public FeatureExecutionContext WithRuleParameters(RuleParameterSet ruleParameters)
        {
            return new FeatureExecutionContext(CorrelationId, Session, ruleParameters ?? throw new ArgumentNullException(nameof(ruleParameters)), RunInputs);
        }
    }
}
