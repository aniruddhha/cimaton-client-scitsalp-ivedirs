using System;
using System.Collections.Generic;
using System.Linq;

namespace CimatronCustomization.Application
{
    public sealed class TabularRowValidationResult
    {
        private readonly TabularRow[] rows;
        private readonly TabularMappingValidationError[] errors;

        private TabularRowValidationResult(
            IEnumerable<TabularRow> rows,
            IEnumerable<TabularMappingValidationError> errors)
        {
            this.rows = (rows ?? Enumerable.Empty<TabularRow>()).ToArray();
            this.errors = (errors ?? Enumerable.Empty<TabularMappingValidationError>()).ToArray();
        }

        public bool IsSuccess => errors.Length == 0;
        public IReadOnlyList<TabularRow> Rows => rows;
        public IReadOnlyList<TabularMappingValidationError> Errors => errors;

        public static TabularRowValidationResult Succeeded(IEnumerable<TabularRow> rows)
        {
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            return new TabularRowValidationResult(rows, null);
        }

        public static TabularRowValidationResult Failed(IEnumerable<TabularMappingValidationError> errors)
        {
            if (errors == null) throw new ArgumentNullException(nameof(errors));
            TabularMappingValidationError[] materialized = errors.ToArray();
            if (materialized.Length == 0) throw new ArgumentException("At least one row validation error is required.", nameof(errors));
            if (materialized.Any(error => error == null)) throw new ArgumentException("Row validation errors cannot contain null entries.", nameof(errors));
            return new TabularRowValidationResult(null, materialized);
        }
    }
}
