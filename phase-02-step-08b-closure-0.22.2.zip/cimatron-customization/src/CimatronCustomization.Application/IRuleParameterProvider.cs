namespace CimatronCustomization.Application
{
    public interface IRuleParameterProvider
    {
        RuleParameterSet LoadFor(FeatureDefinition definition);
    }
}
