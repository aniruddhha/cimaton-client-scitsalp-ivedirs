using System;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Requirement traceability metadata required by AGENTS.md §14.
    /// </summary>
    public sealed class FeatureTraceability
    {
        public FeatureTraceability(
            string description,
            string acceptanceCriteria,
            string inputs,
            string outputs,
            string dependencies,
            string cimatronApis,
            string configuration,
            string failureModes,
            string tests,
            string implementationVersion,
            string knownLimitations)
        {
            Description = Require(description, nameof(description));
            AcceptanceCriteria = Require(acceptanceCriteria, nameof(acceptanceCriteria));
            Inputs = Require(inputs, nameof(inputs));
            Outputs = Require(outputs, nameof(outputs));
            Dependencies = Require(dependencies, nameof(dependencies));
            CimatronApis = Require(cimatronApis, nameof(cimatronApis));
            Configuration = Require(configuration, nameof(configuration));
            FailureModes = Require(failureModes, nameof(failureModes));
            Tests = Require(tests, nameof(tests));
            ImplementationVersion = Require(implementationVersion, nameof(implementationVersion));
            KnownLimitations = Require(knownLimitations, nameof(knownLimitations));
        }

        public string Description { get; }
        public string AcceptanceCriteria { get; }
        public string Inputs { get; }
        public string Outputs { get; }
        public string Dependencies { get; }
        public string CimatronApis { get; }
        public string Configuration { get; }
        public string FailureModes { get; }
        public string Tests { get; }
        public string ImplementationVersion { get; }
        public string KnownLimitations { get; }

        private static string Require(string value, string parameterName)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("Traceability metadata is required.", parameterName);
            }

            return value;
        }
    }
}
