using System;

namespace CimatronCustomization.Application
{
    public sealed class RuleParameterDefinition
    {
        public RuleParameterDefinition(
            string name,
            RuleParameterType type,
            string unit,
            decimal? minimum,
            decimal? maximum,
            bool isRequired)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("A parameter name is required.", nameof(name));
            if (minimum.HasValue && maximum.HasValue && minimum.Value > maximum.Value)
                throw new ArgumentException("The minimum parameter value cannot exceed the maximum parameter value.", nameof(minimum));
            if ((minimum.HasValue || maximum.HasValue) && type != RuleParameterType.Integer && type != RuleParameterType.Decimal)
                throw new ArgumentException("Allowed ranges are supported only for Integer and Decimal parameters.", nameof(type));

            Name = name;
            Type = type;
            Unit = unit ?? string.Empty;
            Minimum = minimum;
            Maximum = maximum;
            IsRequired = isRequired;
        }

        public string Name { get; }
        public RuleParameterType Type { get; }
        public string Unit { get; }
        public decimal? Minimum { get; }
        public decimal? Maximum { get; }
        public bool IsRequired { get; }
    }
}
