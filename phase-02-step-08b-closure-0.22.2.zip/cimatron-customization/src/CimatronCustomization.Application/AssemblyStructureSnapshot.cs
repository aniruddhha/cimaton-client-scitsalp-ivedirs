using System;
using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    public sealed class AssemblyStructureSnapshot
    {
        private readonly AssemblyComponentSnapshot[] components;

        public AssemblyStructureSnapshot(string assemblyTitle, IEnumerable<AssemblyComponentSnapshot> components)
        {
            if (string.IsNullOrWhiteSpace(assemblyTitle)) throw new ArgumentException("An assembly title is required.", nameof(assemblyTitle));
            if (components == null) throw new ArgumentNullException(nameof(components));
            AssemblyTitle = assemblyTitle;
            this.components = new List<AssemblyComponentSnapshot>(components).ToArray();
        }

        public string AssemblyTitle { get; }
        public IReadOnlyList<AssemblyComponentSnapshot> Components => components;
    }
}
