using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class AssemblyEntityMappingResult
    {
        public AssemblyEntityMappingResult(
            int sourceInstanceId,
            int sourceEntityId,
            int assemblyEntityId,
            string assemblyEntityType,
            ModelEntityReference occurrenceEntityReference,
            bool noMutationConfirmed)
        {
            SourceInstanceId = sourceInstanceId;
            SourceEntityId = sourceEntityId;
            AssemblyEntityId = assemblyEntityId;
            AssemblyEntityType = assemblyEntityType ?? string.Empty;
            OccurrenceEntityReference = occurrenceEntityReference;
            NoMutationConfirmed = noMutationConfirmed;
        }

        public int SourceInstanceId { get; }
        public int SourceEntityId { get; }
        public int AssemblyEntityId { get; }
        public string AssemblyEntityType { get; }
        public ModelEntityReference OccurrenceEntityReference { get; }
        public bool NoMutationConfirmed { get; }
    }
}
