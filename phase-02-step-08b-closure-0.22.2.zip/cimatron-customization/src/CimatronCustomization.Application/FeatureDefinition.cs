using System;
using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Stable metadata for a feature registered with the application layer.
    /// Requirement identifiers belong here as metadata rather than in class names.
    /// </summary>
    public sealed class FeatureDefinition
    {
        private readonly string[] requirementIds;
        private readonly RuleParameterDefinition[] ruleParameterDefinitions;

        public FeatureDefinition(
            string id,
            string name,
            FeatureKind kind,
            IEnumerable<string> requirementIds,
            string functionalGroup,
            DocumentContextRequirement requiredDocumentContext,
            bool isReadOnly,
            FeatureTraceability traceability,
            IEnumerable<RuleParameterDefinition> ruleParameterDefinitions = null)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                throw new ArgumentException("A feature id is required.", nameof(id));
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("A feature name is required.", nameof(name));
            }

            if (requirementIds == null)
            {
                throw new ArgumentNullException(nameof(requirementIds));
            }

            List<string> ids = new List<string>();
            foreach (string requirementId in requirementIds)
            {
                if (string.IsNullOrWhiteSpace(requirementId))
                {
                    throw new ArgumentException("Requirement ids cannot contain blank values.", nameof(requirementIds));
                }

                ids.Add(requirementId);
            }

            if (ids.Count == 0)
            {
                throw new ArgumentException("At least one requirement id is required.", nameof(requirementIds));
            }

            if (string.IsNullOrWhiteSpace(functionalGroup))
            {
                throw new ArgumentException("A functional group is required.", nameof(functionalGroup));
            }

            if (kind == FeatureKind.Validation && !isReadOnly)
            {
                throw new ArgumentException("Validation features must declare read-only intent.", nameof(isReadOnly));
            }

            Traceability = traceability ?? throw new ArgumentNullException(nameof(traceability));

            Id = id;
            Name = name;
            Kind = kind;
            this.requirementIds = ids.ToArray();
            FunctionalGroup = functionalGroup;
            RequiredDocumentContext = requiredDocumentContext;
            IsReadOnly = isReadOnly;

            List<RuleParameterDefinition> parameters = new List<RuleParameterDefinition>();
            if (ruleParameterDefinitions != null)
            {
                HashSet<string> parameterNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (RuleParameterDefinition parameter in ruleParameterDefinitions)
                {
                    if (parameter == null) throw new ArgumentException("Rule parameter definitions cannot contain null values.", nameof(ruleParameterDefinitions));
                    if (!parameterNames.Add(parameter.Name)) throw new ArgumentException("Duplicate rule parameter definition: " + parameter.Name + ".", nameof(ruleParameterDefinitions));
                    parameters.Add(parameter);
                }
            }
            this.ruleParameterDefinitions = parameters.ToArray();
        }

        public string Id { get; }
        public string Name { get; }
        public FeatureKind Kind { get; }
        public IReadOnlyList<string> RequirementIds => requirementIds;
        public string FunctionalGroup { get; }
        public DocumentContextRequirement RequiredDocumentContext { get; }
        public bool IsReadOnly { get; }
        public FeatureTraceability Traceability { get; }
        public IReadOnlyList<RuleParameterDefinition> RuleParameterDefinitions => ruleParameterDefinitions;
    }
}
