using System;

namespace CimatronCustomization.Application
{
    public sealed class TabularValue
    {
        private TabularValue(TabularValueType valueType, string textValue, decimal? decimalValue)
        {
            ValueType = valueType;
            TextValue = textValue;
            DecimalValue = decimalValue;
        }

        public TabularValueType ValueType { get; }
        public string TextValue { get; }
        public decimal? DecimalValue { get; }

        public static TabularValue FromText(string value)
        {
            return new TabularValue(TabularValueType.Text, value ?? string.Empty, null);
        }

        public static TabularValue FromDecimal(decimal value)
        {
            return new TabularValue(TabularValueType.Decimal, string.Empty, value);
        }
    }
}
