using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Registry-facing wrapper for the internal foundation Active Part readiness slice.
    /// </summary>
    public sealed class ActivePartReadinessFeature : IApplicationFeature
    {
        public const string FeatureId = "FOUNDATION-ACTIVE-PART-READINESS";

        private static readonly FeatureDefinition featureDefinition = new FeatureDefinition(
            FeatureId,
            "Active Part Readiness Check",
            FeatureKind.Validation,
            new[] { FeatureId },
            "Foundation",
            DocumentContextRequirement.Part,
            true,
            new FeatureTraceability(
                "Internal foundation validation that proves the active Cimatron Part is available for Part-based operations.",
                "With Cimatron available and an active Part, the feature returns Passed through the common execution pipeline.",
                "Current Cimatron session/document context.",
                "One foundation readiness finding and execution report.",
                "ICimatronSession through CheckActivePartReadiness.",
                "No new Step 01 API; uses the already validated session adapter boundary.",
                "No feature-specific configuration.",
                "Unavailable application/document or unsupported/wrong document context.",
                "Domain and Application readiness/execution regression tests plus live Cimatron validation.",
                "0.14.10",
                "Foundation-only feature; not a customer CR/SA rule."));

        private readonly CheckActivePartReadiness readinessCheck;

        public ActivePartReadinessFeature(CheckActivePartReadiness readinessCheck)
        {
            this.readinessCheck = readinessCheck ?? throw new ArgumentNullException(nameof(readinessCheck));
        }

        public FeatureDefinition Definition => featureDefinition;

        public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            ActivePartReadinessOutcome outcome = readinessCheck.Execute();
            Finding finding = new Finding(FeatureId, outcome.Status, outcome.Message);
            return new FeatureExecutionOutcome(outcome.Status, outcome.Message, new[] { finding });
        }
    }
}
