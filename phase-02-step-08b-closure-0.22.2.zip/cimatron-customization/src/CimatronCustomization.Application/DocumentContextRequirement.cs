namespace CimatronCustomization.Application
{
    public enum DocumentContextRequirement
    {
        Either = 0,
        Part = 1,
        Assembly = 2
    }
}
