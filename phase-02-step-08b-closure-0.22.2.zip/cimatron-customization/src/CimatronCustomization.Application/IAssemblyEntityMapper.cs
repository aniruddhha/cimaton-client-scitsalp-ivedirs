using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>Application boundary for mapping an occurrence-owned Part entity into the active Assembly context.</summary>
    public interface IAssemblyEntityMapper
    {
        ModelReadResult<AssemblyEntityMappingResult> MapToActiveAssembly(ModelEntityReference occurrenceEntityReference);
    }
}
