namespace CimatronCustomization.Application
{
    /// <summary>
    /// Read-only port for verified U1 body geometry metrics.
    /// </summary>
    public interface IBodyGeometryMetricsReader
    {
        ModelReadResult<BodyGeometryMetricsSnapshot> ReadBodyMetrics(string expectedModelTitle, int bodyId);
    }
}
