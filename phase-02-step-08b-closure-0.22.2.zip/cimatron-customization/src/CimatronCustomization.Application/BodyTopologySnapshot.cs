using System;
using System.Collections.Generic;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class BodyTopologySnapshot
    {
        private readonly ModelEntityReference[] bodies;
        private readonly FaceTopologySnapshot[] faces;

        public BodyTopologySnapshot(IEnumerable<ModelEntityReference> bodies, IEnumerable<FaceTopologySnapshot> faces, bool boundingBoxesSupported)
        {
            if (bodies == null) throw new ArgumentNullException(nameof(bodies));
            if (faces == null) throw new ArgumentNullException(nameof(faces));
            this.bodies = new List<ModelEntityReference>(bodies).ToArray();
            this.faces = new List<FaceTopologySnapshot>(faces).ToArray();
            BoundingBoxesSupported = boundingBoxesSupported;
        }

        public IReadOnlyList<ModelEntityReference> Bodies => bodies;
        public IReadOnlyList<FaceTopologySnapshot> Faces => faces;
        public bool BoundingBoxesSupported { get; }
    }
}
