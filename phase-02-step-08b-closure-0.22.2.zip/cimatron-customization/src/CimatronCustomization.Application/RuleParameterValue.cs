using System;

namespace CimatronCustomization.Application
{
    public sealed class RuleParameterValue
    {
        public RuleParameterValue(RuleParameterDefinition definition, string rawValue, object value)
        {
            Definition = definition ?? throw new ArgumentNullException(nameof(definition));
            if (rawValue == null) throw new ArgumentNullException(nameof(rawValue));
            Value = value ?? throw new ArgumentNullException(nameof(value));
            RawValue = rawValue;
        }

        public RuleParameterDefinition Definition { get; }
        public string RawValue { get; }
        public object Value { get; }

        public string AsString()
        {
            if (Definition.Type != RuleParameterType.String && Definition.Type != RuleParameterType.ColorCode)
                throw new InvalidOperationException("Parameter '" + Definition.Name + "' is not a string parameter.");
            return (string)Value;
        }

        public int AsInteger()
        {
            if (Definition.Type != RuleParameterType.Integer)
                throw new InvalidOperationException("Parameter '" + Definition.Name + "' is not an integer parameter.");
            return (int)Value;
        }

        public decimal AsDecimal()
        {
            if (Definition.Type != RuleParameterType.Decimal)
                throw new InvalidOperationException("Parameter '" + Definition.Name + "' is not a decimal parameter.");
            return (decimal)Value;
        }

        public bool AsBoolean()
        {
            if (Definition.Type != RuleParameterType.Boolean)
                throw new InvalidOperationException("Parameter '" + Definition.Name + "' is not a Boolean parameter.");
            return (bool)Value;
        }
    }
}
