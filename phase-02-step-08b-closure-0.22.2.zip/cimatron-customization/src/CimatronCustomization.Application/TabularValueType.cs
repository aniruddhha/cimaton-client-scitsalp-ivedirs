namespace CimatronCustomization.Application
{
    public enum TabularValueType
    {
        Text = 0,
        Decimal = 1
    }
}
