using System;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    public sealed class BomMaterialExportResult
    {
        public BomMaterialExportResult(
            ResultStatus status,
            string message,
            bool materialColumnPresent,
            int knownAnswerRowCount,
            string materialValue,
            bool noMutationConfirmed,
            bool modelFolderUnchanged,
            bool tempCleanupSucceeded,
            string tempDirectory,
            string csvFileName)
        {
            if (string.IsNullOrWhiteSpace(message)) throw new ArgumentException("A BOM material result message is required.", nameof(message));
            Status = status;
            Message = message;
            MaterialColumnPresent = materialColumnPresent;
            KnownAnswerRowCount = knownAnswerRowCount;
            MaterialValue = materialValue ?? string.Empty;
            NoMutationConfirmed = noMutationConfirmed;
            ModelFolderUnchanged = modelFolderUnchanged;
            TempCleanupSucceeded = tempCleanupSucceeded;
            TempDirectory = tempDirectory ?? string.Empty;
            CsvFileName = csvFileName ?? string.Empty;
        }

        public ResultStatus Status { get; }
        public string Message { get; }
        public bool MaterialColumnPresent { get; }
        public int KnownAnswerRowCount { get; }
        public string MaterialValue { get; }
        public bool NoMutationConfirmed { get; }
        public bool ModelFolderUnchanged { get; }
        public bool TempCleanupSucceeded { get; }
        public string TempDirectory { get; }
        public string CsvFileName { get; }
        public bool IsAvailable => Status == ResultStatus.Passed;
    }
}
