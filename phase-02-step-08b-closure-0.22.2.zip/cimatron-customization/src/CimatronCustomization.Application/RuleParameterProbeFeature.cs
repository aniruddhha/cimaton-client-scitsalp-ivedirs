using System;
using System.Globalization;
using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>Internal foundation probe for schema-2 rule-parameter loading and validation.</summary>
    public sealed class RuleParameterProbeFeature : IApplicationFeature
    {
        public const string FeatureId = "FOUNDATION-RULE-PARAMETER-PROBE";
        public const string ProbeParameterName = "ProbeLength";

        private static readonly FeatureDefinition definition = new FeatureDefinition(
            FeatureId,
            "Rule Parameter Probe",
            FeatureKind.Validation,
            new[] { FeatureId },
            "Foundation",
            DocumentContextRequirement.Either,
            true,
            new FeatureTraceability(
                "Internal foundation validation that proves schema-2 feature parameters are loaded and validated before feature execution.",
                "With a valid required ProbeLength parameter, the feature returns Passed and reports the validated value.",
                "Validated rule parameter ProbeLength from the configured feature parameter set.",
                "One foundation finding describing the validated parameter value.",
                "IRuleParameterProvider through the common execution pipeline.",
                "No Cimatron API usage.",
                "Schema 2 feature parameter FOUNDATION-RULE-PARAMETER-PROBE/ProbeLength.",
                "Missing, malformed or out-of-range required parameter returns Error before feature execution.",
                "Application and Infrastructure parameter/configuration tests plus live Cimatron probe validation.",
                "0.14.10",
                "Foundation-only feature; not a customer CR/SA rule."),
            new[] { new RuleParameterDefinition(ProbeParameterName, RuleParameterType.Decimal, "mm", 0m, 1000m, true) });

        public FeatureDefinition Definition => definition;

        public FeatureExecutionOutcome Execute(FeatureExecutionContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));
            decimal value = context.RuleParameters.GetRequired(ProbeParameterName).AsDecimal();
            string formatted = value.ToString("0.###", CultureInfo.InvariantCulture);
            string message = "Validated rule parameter " + ProbeParameterName + " = " + formatted + " mm.";
            Finding finding = new Finding(FeatureId, ResultStatus.Passed, message, new Measurement((double)value, "mm"));
            return new FeatureExecutionOutcome(ResultStatus.Passed, message, new[] { finding });
        }
    }
}
