namespace CimatronCustomization.Application
{
    public interface ITabularHeaderReader
    {
        TabularHeaderDiscoveryResult DiscoverHeaders(TabularHeaderSourceDefinition source);
    }
}
