using System;
using System.Collections.Generic;

namespace CimatronCustomization.Application
{
    /// <summary>
    /// Explicit registry for application features. Registration is composition-root driven;
    /// no reflection or runtime assembly scanning is used.
    /// </summary>
    public sealed class FeatureRegistry
    {
        private readonly Dictionary<string, IApplicationFeature> featuresById;
        private readonly List<FeatureDefinition> definitions;

        public FeatureRegistry(IEnumerable<IApplicationFeature> features)
        {
            if (features == null)
            {
                throw new ArgumentNullException(nameof(features));
            }

            featuresById = new Dictionary<string, IApplicationFeature>(StringComparer.OrdinalIgnoreCase);
            definitions = new List<FeatureDefinition>();

            foreach (IApplicationFeature feature in features)
            {
                if (feature == null)
                {
                    throw new ArgumentException("A feature registry cannot contain a null feature.", nameof(features));
                }

                FeatureDefinition definition = feature.Definition;
                if (definition == null)
                {
                    throw new ArgumentException("Every registered feature must provide a definition.", nameof(features));
                }

                if (featuresById.ContainsKey(definition.Id))
                {
                    throw new InvalidOperationException(
                        "Duplicate feature id registration is not allowed: " + definition.Id + ".");
                }

                featuresById.Add(definition.Id, feature);
                definitions.Add(definition);
            }
        }

        public FeatureDefinition[] GetDefinitions() => definitions.ToArray();
        public FeatureDefinition GetDefinition(string featureId) => GetRequiredFeature(featureId).Definition;
        public IApplicationFeature GetFeature(string featureId) => GetRequiredFeature(featureId);

        public FeatureExecutionOutcome Execute(string featureId, FeatureExecutionContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            return GetRequiredFeature(featureId).Execute(context);
        }

        private IApplicationFeature GetRequiredFeature(string featureId)
        {
            if (string.IsNullOrWhiteSpace(featureId))
            {
                throw new ArgumentException("A feature id is required.", nameof(featureId));
            }

            IApplicationFeature feature;
            if (!featuresById.TryGetValue(featureId, out feature))
            {
                throw new KeyNotFoundException("No application feature is registered with id '" + featureId + "'.");
            }

            return feature;
        }
    }
}
