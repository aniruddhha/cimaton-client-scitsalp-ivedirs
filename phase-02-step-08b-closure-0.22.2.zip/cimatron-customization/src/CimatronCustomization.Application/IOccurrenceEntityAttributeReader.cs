using CimatronCustomization.Domain;

namespace CimatronCustomization.Application
{
    /// <summary>Application boundary for read-only assembly occurrence traversal and exact named entity-attribute reads.</summary>
    public interface IOccurrenceEntityAttributeReader
    {
        ModelReadResult<OccurrenceEntityAttributeResult> ReadNestedOccurrenceAttribute(
            string expectedAssemblyTitle,
            string targetModelTitle,
            int bodyId,
            string attributeName);
    }
}
