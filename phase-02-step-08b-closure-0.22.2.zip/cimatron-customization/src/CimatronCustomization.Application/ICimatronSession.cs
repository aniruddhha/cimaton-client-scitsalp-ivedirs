namespace CimatronCustomization.Application
{
    public interface ICimatronSession
    {
        CimatronSessionSnapshot GetCurrentSession();
    }
}
