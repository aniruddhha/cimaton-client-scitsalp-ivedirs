using System;
using System.Threading;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    public sealed class CimatronViewportEntityPicker : IViewportEntityPicker
    {
        private const int SourceDocumentProbeIntervalMilliseconds = 250;
        private const int SourceDocumentLossConfirmationCount = 4;
        private readonly IApplicationLogger logger;
        private readonly string applicationVersion;
        private readonly string cimatronVersion;
        private readonly SessionDocumentIdentityRegistry identityRegistry = new SessionDocumentIdentityRegistry();
        private readonly ViewportPickSessionState session = new ViewportPickSessionState();
        private CancellationTokenRegistration cancellationRegistration;
        private bool hasCancellationRegistration;
        private Timer sourceDocumentMonitor;

        public CimatronViewportEntityPicker(IApplicationLogger logger, string applicationVersion, string cimatronVersion)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.applicationVersion = applicationVersion ?? string.Empty;
            this.cimatronVersion = cimatronVersion ?? string.Empty;
        }

        public bool IsActive => session.IsActive;

        public void BeginPick(ViewportPickRequest request, CancellationToken cancellationToken, Action<ViewportPickResult> completion)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (completion == null) throw new ArgumentNullException(nameof(completion));

            string correlationId = Guid.NewGuid().ToString("N");
            SynchronizationContext completionContext = SynchronizationContext.Current;
            if (completionContext == null || Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
            {
                completion(ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Failed,
                    null,
                    "PICK_UI_THREAD_REQUIRED",
                    "Viewport Pick must be started from the Cimatron STA/UI thread."));
                return;
            }

            if (session.IsActive)
            {
                completion(ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Busy,
                    null,
                    "PICK_ALREADY_ACTIVE",
                    "A viewport Pick request is already active."));
                return;
            }

            if (cancellationToken.IsCancellationRequested)
            {
                completion(ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Cancelled,
                    null,
                    "CALLER_CANCELLED_BEFORE_START",
                    "Pick was cancelled before it started."));
                return;
            }

            try
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application == null)
                {
                    completion(ViewportPickResult.WithoutEntity(
                        correlationId,
                        ViewportPickOutcome.Unsupported,
                        null,
                        "CIMATRON_APPLICATION_UNAVAILABLE",
                        "Cimatron application is not available."));
                    return;
                }

                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                if (document == null)
                {
                    completion(ViewportPickResult.WithoutEntity(
                        correlationId,
                        ViewportPickOutcome.Unsupported,
                        null,
                        "NO_ACTIVE_DOCUMENT",
                        "No active Cimatron document is available."));
                    return;
                }

                CimatronDocumentIdentityProvider identityProvider = new CimatronDocumentIdentityProvider(application, identityRegistry);
                ViewportDocumentIdentity sourceDocument = identityProvider.GetIdentity(document);
                if (!string.Equals(document.Type.ToString(), "cmPart", StringComparison.Ordinal))
                {
                    completion(ViewportPickResult.WithoutEntity(
                        correlationId,
                        ViewportPickOutcome.Unsupported,
                        sourceDocument,
                        "DOCUMENT_TYPE_UNSUPPORTED",
                        "Step 05B2 production Pick supports only an active Part document. Assembly and NC Pick remain Unsupported."));
                    return;
                }

                interop.CimMdlrAPI.IModelContainer modelContainer = document as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IModel model = modelContainer == null ? null : modelContainer.Model as interop.CimMdlrAPI.IModel;
                interop.CimMdlrAPI.IEntityQuery query = model as interop.CimMdlrAPI.IEntityQuery;
                interop.CimBaseAPI.IToolContainer toolContainer = document as interop.CimBaseAPI.IToolContainer;
                if (model == null || query == null || toolContainer == null)
                {
                    completion(ViewportPickResult.WithoutEntity(
                        correlationId,
                        ViewportPickOutcome.Unsupported,
                        sourceDocument,
                        "PICK_BOUNDARY_UNAVAILABLE",
                        "The active Part does not expose the verified model/query/tool-container interfaces required for production Pick."));
                    return;
                }

                interop.CimBaseAPI.IEntityFilter entityFilter = CreateEntityTypeFilter(query, request);
                CimatronViewportPickTool tool = null;
                tool = new CimatronViewportPickTool(
                    application,
                    toolContainer,
                    model.PID,
                    sourceDocument,
                    identityProvider,
                    request,
                    correlationId,
                    applicationVersion,
                    cimatronVersion,
                    logger,
                    result => Finish(tool, result, completion));

                // The session owns the strong reference before Cimatron receives the managed CCW.
                if (!session.TryBegin(tool))
                {
                    completion(ViewportPickResult.WithoutEntity(
                        correlationId,
                        ViewportPickOutcome.Busy,
                        sourceDocument,
                        "PICK_ALREADY_ACTIVE",
                        "A viewport Pick request is already active."));
                    return;
                }

                try
                {
                    toolContainer.PushPickTool((interop.CimBaseAPI.Tool)tool, entityFilter, entityFilter, 0);
                    StartSourceDocumentMonitor(
                        tool,
                        application,
                        model.PID,
                        completionContext);
                    if (session.IsActive && cancellationToken.CanBeCanceled)
                    {
                        cancellationRegistration = cancellationToken.Register(() =>
                            completionContext.Post(_ => CancelActiveFromCaller(), null));
                        hasCancellationRegistration = true;
                    }
                }
                catch (Exception exception)
                {
                    session.TryComplete(tool);
                    DisposeRequestRegistrations();
                    ViewportPickResult failed = ViewportPickResult.WithoutEntity(
                        correlationId,
                        ViewportPickOutcome.Failed,
                        sourceDocument,
                        "PICK_TOOL_START_FAILED",
                        "Cimatron rejected or failed to start the production PickTool: " + exception.Message);
                    LogFailure(correlationId, "ViewportPickStart", failed, exception);
                    completion(failed);
                }
            }
            catch (Exception exception)
            {
                ViewportPickResult failed = ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Failed,
                    null,
                    "PICK_SETUP_FAILED",
                    "Production Pick setup failed before Cimatron could start the PickTool: " + exception.Message);
                LogFailure(correlationId, "ViewportPickSetup", failed, exception);
                completion(failed);
            }
        }

        public ViewportPickResult ValidateForCurrentDocument(ViewportPickResult result)
        {
            if (result == null) throw new ArgumentNullException(nameof(result));
            if (result.Outcome != ViewportPickOutcome.Picked)
            {
                return result;
            }

            try
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application == null)
                {
                    return ViewportPickResultValidator.ValidateForDocumentToken(result, null);
                }

                CimatronDocumentIdentityProvider identityProvider = new CimatronDocumentIdentityProvider(application, identityRegistry);
                return ViewportPickResultValidator.ValidateForDocumentToken(result, identityProvider.GetCurrentDocumentToken());
            }
            catch (Exception)
            {
                // Fail closed: if current-document identity cannot be established, never reuse a session/document-scoped entity ID.
                return ViewportPickResultValidator.ValidateForDocumentToken(result, null);
            }
        }

        private static interop.CimBaseAPI.IEntityFilter CreateEntityTypeFilter(
            interop.CimMdlrAPI.IEntityQuery query,
            ViewportPickRequest request)
        {
            interop.CimMdlrAPI.IEntityFilter rawFilter = query.CreateFilter(interop.CimMdlrAPI.EFilterEnumType.cmFilterEntityType);
            interop.CimBaseAPI.FilterType typeFilter = (interop.CimBaseAPI.FilterType)rawFilter;
            foreach (ViewportEntityType entityType in request.AllowedEntityTypes)
            {
                switch (entityType)
                {
                    case ViewportEntityType.Body:
                        typeFilter.Add(interop.CimBaseAPI.EntityEnumType.cmBody);
                        break;
                    case ViewportEntityType.Face:
                        typeFilter.Add(interop.CimBaseAPI.EntityEnumType.cmFace);
                        break;
                    case ViewportEntityType.Edge:
                        typeFilter.Add(interop.CimBaseAPI.EntityEnumType.cmEdge);
                        break;
                    case ViewportEntityType.Vertex:
                        typeFilter.Add(interop.CimBaseAPI.EntityEnumType.cmVertex);
                        break;
                    default:
                        throw new InvalidOperationException("Unsupported application entity type: " + entityType + ".");
                }
            }

            return (interop.CimBaseAPI.IEntityFilter)rawFilter;
        }

        private void CancelActiveFromCaller()
        {
            CimatronViewportPickTool tool = session.GetActiveTool<CimatronViewportPickTool>();
            if (tool != null)
            {
                tool.CancelFromCaller();
            }
        }

        private void Finish(CimatronViewportPickTool tool, ViewportPickResult result, Action<ViewportPickResult> completion)
        {
            if (!session.TryComplete(tool))
            {
                return;
            }

            DisposeRequestRegistrations();
            completion(result);
        }

        private void StartSourceDocumentMonitor(
            CimatronViewportPickTool tool,
            interop.CimatronE.IApplication application,
            string sourceModelPid,
            SynchronizationContext completionContext)
        {
            DisposeSourceDocumentMonitor();
            sourceDocumentMonitor = new Timer(
                _ =>
                {
                    try
                    {
                        completionContext.Post(
                            __ => CheckSourceDocumentLifecycle(tool, application, sourceModelPid),
                            null);
                    }
                    catch (Exception)
                    {
                        // Cimatron/UI shutdown can invalidate the captured context. Do not complete from a worker thread.
                    }
                },
                null,
                SourceDocumentProbeIntervalMilliseconds,
                SourceDocumentProbeIntervalMilliseconds);
        }

        private void CheckSourceDocumentLifecycle(
            CimatronViewportPickTool tool,
            interop.CimatronE.IApplication application,
            string sourceModelPid)
        {
            if (!ReferenceEquals(session.GetActiveTool<CimatronViewportPickTool>(), tool))
            {
                return;
            }

            bool sourceDocumentIsCurrent;
            try
            {
                interop.CimatronE.ICimDocument currentDocument = application.GetActiveDoc();
                interop.CimMdlrAPI.IModelContainer currentContainer = currentDocument as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IModel currentModel = currentContainer == null ? null : currentContainer.Model as interop.CimMdlrAPI.IModel;
                sourceDocumentIsCurrent = SourceDocumentLifecycleMatches(
                    sourceModelPid,
                    currentDocument == null ? null : currentDocument.Type.ToString(),
                    currentModel == null ? null : currentModel.PID);
            }
            catch (Exception)
            {
                // Current model identity could not be established safely. Keep the active request intact rather than guessing from a COM failure.
                return;
            }

            if (session.ShouldCompleteForSourceDocumentLoss(sourceDocumentIsCurrent, SourceDocumentLossConfirmationCount))
            {
                tool.CompleteBecauseSourceDocumentClosed();
            }
        }

        internal static bool SourceDocumentLifecycleMatches(string sourceModelPid, string currentDocumentType, string currentModelPid)
        {
            return !string.IsNullOrEmpty(sourceModelPid) &&
                string.Equals(currentDocumentType, "cmPart", StringComparison.Ordinal) &&
                string.Equals(currentModelPid ?? string.Empty, sourceModelPid, StringComparison.Ordinal);
        }

        private void LogFailure(string correlationId, string operation, ViewportPickResult failed, Exception exception)
        {
            try
            {
                logger.Log(new ApplicationLogEntry(
                    DateTimeOffset.UtcNow,
                    "Error",
                    correlationId,
                    applicationVersion,
                    cimatronVersion,
                    "Viewport Entity Pick",
                    "PLATFORM-STEP-05B2",
                    operation,
                    ViewportPickOutcome.Failed.ToString(),
                    0,
                    failed.Message,
                    exception));
            }
            catch (Exception)
            {
                // Logging must never prevent the structured Pick result from reaching the caller.
            }
        }

        private void DisposeRequestRegistrations()
        {
            DisposeCancellationRegistration();
            DisposeSourceDocumentMonitor();
        }

        private void DisposeCancellationRegistration()
        {
            if (hasCancellationRegistration)
            {
                cancellationRegistration.Dispose();
                hasCancellationRegistration = false;
            }
        }

        private void DisposeSourceDocumentMonitor()
        {
            Timer monitor = sourceDocumentMonitor;
            sourceDocumentMonitor = null;
            if (monitor != null)
            {
                monitor.Dispose();
            }
        }

    }
}
