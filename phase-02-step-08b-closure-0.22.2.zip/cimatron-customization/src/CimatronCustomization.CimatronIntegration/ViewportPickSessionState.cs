using System;

namespace CimatronCustomization.CimatronIntegration
{
    internal sealed class ViewportPickSessionState
    {
        private object activeTool;
        private int consecutiveSourceDocumentMismatchCount;

        internal bool IsActive => activeTool != null;

        internal bool TryBegin(object tool)
        {
            if (tool == null) throw new ArgumentNullException(nameof(tool));
            if (activeTool != null)
            {
                return false;
            }

            activeTool = tool;
            consecutiveSourceDocumentMismatchCount = 0;
            return true;
        }

        internal T GetActiveTool<T>() where T : class
        {
            return activeTool as T;
        }

        internal bool TryComplete(object tool)
        {
            if (tool == null || !ReferenceEquals(activeTool, tool))
            {
                return false;
            }

            activeTool = null;
            consecutiveSourceDocumentMismatchCount = 0;
            return true;
        }

        internal bool ShouldCompleteForSourceDocumentLoss(bool sourceDocumentIsCurrent, int requiredConsecutiveMismatches)
        {
            if (requiredConsecutiveMismatches < 1) throw new ArgumentOutOfRangeException(nameof(requiredConsecutiveMismatches));
            if (!IsActive)
            {
                return false;
            }

            if (sourceDocumentIsCurrent)
            {
                consecutiveSourceDocumentMismatchCount = 0;
                return false;
            }

            consecutiveSourceDocumentMismatchCount++;
            return consecutiveSourceDocumentMismatchCount >= requiredConsecutiveMismatches;
        }
    }
}
