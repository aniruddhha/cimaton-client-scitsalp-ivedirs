using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    public sealed class CimatronRuntimeInfoAdapter : ICimatronRuntimeInfo
    {
        public CimatronRuntimeSnapshot GetCurrentRuntime()
        {
            interop.CimServicesAPI.CimApplicationProvider applicationProvider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)applicationProvider.GetApplication();
            if (application == null)
            {
                return new CimatronRuntimeSnapshot(string.Empty, string.Empty, CimatronSessionSnapshot.ApplicationUnavailable());
            }

            interop.CimatronE.ICimDocument activeDocument = application.GetActiveDoc();
            CimatronSessionSnapshot session = activeDocument == null
                ? CimatronSessionSnapshot.NoActiveDocument()
                : CimatronSessionSnapshot.ActiveDocument(MapDocumentContext(activeDocument.Type.ToString()));

            return new CimatronRuntimeSnapshot(application.ProductName, application.Version, session);
        }

        private static CimatronDocumentContext MapDocumentContext(string name)
        {
            switch (name)
            {
                case "cmPart": return CimatronDocumentContext.Part;
                case "cmAssembly": return CimatronDocumentContext.Assembly;
                case "cmNc": return CimatronDocumentContext.Nc;
                default: return CimatronDocumentContext.Unsupported;
            }
        }
    }
}
