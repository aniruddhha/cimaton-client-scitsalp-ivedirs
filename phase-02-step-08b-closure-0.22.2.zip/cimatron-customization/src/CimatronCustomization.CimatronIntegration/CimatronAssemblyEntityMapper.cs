using System;
using System.Globalization;
using System.IO;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>Read-only Cimatron 2026 mapper from an occurrence-owned Part entity to active Assembly context.</summary>
    public sealed class CimatronAssemblyEntityMapper : IAssemblyEntityMapper
    {
        private const string EntityReferencePrefix = "entity";

        public ModelReadResult<AssemblyEntityMappingResult> MapToActiveAssembly(ModelEntityReference occurrenceEntityReference)
        {
            if (occurrenceEntityReference == null) throw new ArgumentNullException(nameof(occurrenceEntityReference));

            ParsedReference parsed;
            if (!TryParse(occurrenceEntityReference.Value, out parsed) || parsed.InstanceId == 0)
                return ModelReadResult<AssemblyEntityMappingResult>.Unsupported("U7 mapping requires a valid nested occurrence entity reference.");

            interop.CimatronE.IApplication application = GetApplication();
            interop.CimatronE.ICimDocument document = application.GetActiveDoc();
            if (document == null)
                return ModelReadResult<AssemblyEntityMappingResult>.Unsupported("No active Cimatron document is available.");
            if (!string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                return ModelReadResult<AssemblyEntityMappingResult>.Unsupported("U7 mapping requires an active Assembly document.");

            interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
            interop.CimMdlrAPI.IAssemblyModel assembly = container == null ? null : container.Model as interop.CimMdlrAPI.IAssemblyModel;
            if (assembly == null)
                throw new InvalidOperationException("Active Assembly does not expose IAssemblyModel through IModelContainer.");

            MutationSnapshot before = MutationSnapshot.Capture(document);
            interop.CimMdlrAPI.IAssInstance owner = FindInstance(assembly, parsed.InstanceId, 0);
            if (owner == null || owner.Model == null)
                return ModelReadResult<AssemblyEntityMappingResult>.Unsupported("The nested occurrence reference is no longer available in the active Assembly.");
            if (!string.Equals(owner.Model.PID ?? string.Empty, parsed.ModelPid ?? string.Empty, StringComparison.Ordinal))
                return ModelReadResult<AssemblyEntityMappingResult>.Unsupported("The nested occurrence reference belongs to a different Cimatron model/session.");

            interop.CimMdlrAPI.ICimEntity sourceEntity = FindOccurrenceEntity(owner, parsed.EntityId);
            if (sourceEntity == null)
                return ModelReadResult<AssemblyEntityMappingResult>.Unsupported("The referenced occurrence entity is no longer available.");

            interop.CimMdlrAPI.ICimEntity assemblyEntity = assembly.GetAssemblyEntity(
                sourceEntity,
                (interop.CimMdlrAPI.AssInstance)owner);
            if (assemblyEntity == null)
                return ModelReadResult<AssemblyEntityMappingResult>.Unsupported("IAssemblyModel.GetAssemblyEntity returned no assembly-context entity.");

            MutationSnapshot after = MutationSnapshot.Capture(document);
            AssemblyEntityMappingResult result = new AssemblyEntityMappingResult(
                parsed.InstanceId,
                parsed.EntityId,
                assemblyEntity.ID,
                assemblyEntity.Type.ToString(),
                occurrenceEntityReference,
                before.IsEquivalentTo(after));
            return ModelReadResult<AssemblyEntityMappingResult>.Passed(result, "Assembly-context entity mapping captured.");
        }

        private static interop.CimMdlrAPI.ICimEntity FindOccurrenceEntity(interop.CimMdlrAPI.IAssInstance instance, int entityId)
        {
            interop.CimMdlrAPI.ICimEntityList entities = instance.GetAllEntities();
            if (entities == null)
                throw new InvalidOperationException("IAssInstance.GetAllEntities() returned null while resolving the occurrence entity.");

            interop.CimMdlrAPI.ICimEntity match = null;
            int count = 0;
            for (int index = 1; index <= entities.Count; index++)
            {
                interop.CimMdlrAPI.ICimEntity entity = entities[index] as interop.CimMdlrAPI.ICimEntity;
                if (entity == null || entity.ID != entityId)
                    continue;
                count++;
                match = entity;
            }

            if (count > 1)
                throw new InvalidOperationException("Occurrence entity resolution returned more than one entity with the requested ID.");
            return match;
        }

        private static interop.CimMdlrAPI.IAssInstance FindInstance(interop.CimMdlrAPI.IAssemblyModel assembly, int instanceId, int depth)
        {
            if (depth > 16) throw new InvalidOperationException("Assembly traversal depth exceeded 16.");
            object[] rawInstances = assembly.GetInstances();
            if (rawInstances == null)
                return null;

            foreach (object raw in rawInstances)
            {
                interop.CimMdlrAPI.IAssInstance instance = raw as interop.CimMdlrAPI.IAssInstance;
                if (instance == null)
                    continue;
                if (instance.ID == instanceId)
                    return instance;

                object rawSubInstances = instance.get_SubInstances(1, 0);
                object[] subInstances = rawSubInstances as object[];
                if (subInstances != null && subInstances.Length > 0 && instance.Model != null &&
                    string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    interop.CimMdlrAPI.IAssInstance nested = FindInstance((interop.CimMdlrAPI.IAssemblyModel)instance.Model, instanceId, depth + 1);
                    if (nested != null)
                        return nested;
                }
            }
            return null;
        }

        private static bool TryParse(string value, out ParsedReference parsed)
        {
            parsed = null;
            if (string.IsNullOrWhiteSpace(value))
                return false;
            string[] parts = value.Split('|');
            if (parts.Length != 4 || !string.Equals(parts[0], EntityReferencePrefix, StringComparison.Ordinal))
                return false;

            int instanceId;
            int entityId;
            if (!int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out instanceId) ||
                !int.TryParse(parts[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out entityId))
                return false;

            string modelPid;
            try
            {
                modelPid = Encoding.UTF8.GetString(Convert.FromBase64String(parts[2]));
            }
            catch (FormatException)
            {
                return false;
            }

            parsed = new ParsedReference(instanceId, modelPid, entityId);
            return true;
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
                throw new InvalidOperationException("Cimatron application is not available.");
            return application;
        }

        private sealed class ParsedReference
        {
            internal ParsedReference(int instanceId, string modelPid, int entityId)
            {
                InstanceId = instanceId;
                ModelPid = modelPid;
                EntityId = entityId;
            }

            internal int InstanceId { get; }
            internal string ModelPid { get; }
            internal int EntityId { get; }
        }

        private sealed class MutationSnapshot
        {
            private MutationSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            private string Path { get; }
            private bool Modified { get; }
            private DateTime? LastWriteUtc { get; }
            private long? Length { get; }

            internal static MutationSnapshot Capture(interop.CimatronE.ICimDocument document)
            {
                bool modified = document.IsModified();
                string path = document.GetPath() ?? string.Empty;
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo info = new FileInfo(path);
                    lastWriteUtc = info.LastWriteTimeUtc;
                    length = info.Length;
                }
                return new MutationSnapshot(path, modified, lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(MutationSnapshot other)
            {
                return other != null &&
                    !string.IsNullOrWhiteSpace(Path) &&
                    LastWriteUtc.HasValue && Length.HasValue &&
                    other.LastWriteUtc.HasValue && other.Length.HasValue &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }
    }
}
