using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Read-only Cimatron 2026 adapter for occurrence traversal and exact named body-attribute lookup.
    /// IAssInstance.GetAllEntities() is available in the installed Interop and Step 07 runtime evidence,
    /// but is not present in the authoritative SDK documentation index used by this project.
    /// </summary>
    public sealed class CimatronOccurrenceEntityAttributeReader : IOccurrenceEntityAttributeReader
    {
        private const string EntityReferencePrefix = "entity";

        public ModelReadResult<OccurrenceEntityAttributeResult> ReadNestedOccurrenceAttribute(
            string expectedAssemblyTitle,
            string targetModelTitle,
            int bodyId,
            string attributeName)
        {
            if (string.IsNullOrWhiteSpace(expectedAssemblyTitle)) throw new ArgumentException("An expected assembly title is required.", nameof(expectedAssemblyTitle));
            if (string.IsNullOrWhiteSpace(targetModelTitle)) throw new ArgumentException("A target model title is required.", nameof(targetModelTitle));
            if (bodyId <= 0) throw new ArgumentOutOfRangeException(nameof(bodyId));
            if (string.IsNullOrWhiteSpace(attributeName)) throw new ArgumentException("An attribute name is required.", nameof(attributeName));

            interop.CimatronE.IApplication application = GetApplication();
            interop.CimatronE.ICimDocument document = application.GetActiveDoc();
            if (document == null)
                return ModelReadResult<OccurrenceEntityAttributeResult>.Unsupported("No active Cimatron document is available.");
            if (!string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                return ModelReadResult<OccurrenceEntityAttributeResult>.Unsupported("Step 08B confirmation requires an active Assembly document.");

            interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
            interop.CimMdlrAPI.IAssemblyModel assembly = container == null ? null : container.Model as interop.CimMdlrAPI.IAssemblyModel;
            interop.CimMdlrAPI.IModel assemblyModel = assembly as interop.CimMdlrAPI.IModel;
            if (assembly == null || assemblyModel == null)
                throw new InvalidOperationException("Active Assembly does not expose IAssemblyModel/IModel through IModelContainer.");
            if (!string.Equals(assemblyModel.Title, expectedAssemblyTitle, StringComparison.OrdinalIgnoreCase))
            {
                return ModelReadResult<OccurrenceEntityAttributeResult>.Unsupported(
                    "Active assembly title is '" + (assemblyModel.Title ?? string.Empty) + "'; expected '" + expectedAssemblyTitle + "'.");
            }

            MutationSnapshot before = MutationSnapshot.Capture(document);
            List<OccurrenceObservation> all = new List<OccurrenceObservation>();
            Traverse(assembly, all, 0);

            List<OccurrenceObservation> matching = all
                .Where(item => item.Instance.Model != null && string.Equals(item.Instance.Model.Title, targetModelTitle, StringComparison.OrdinalIgnoreCase))
                .ToList();
            List<OccurrenceObservation> nested = matching.Where(item => item.Depth > 0).ToList();

            int topLevelByModelCount = 0;
            interop.CimMdlrAPI.IModel targetPartModel = matching.Count > 0 ? matching[0].Instance.Model as interop.CimMdlrAPI.IModel : null;
            if (targetPartModel != null)
            {
                object rawByModel = assembly.GetInstancesByModel(targetPartModel);
                Array byModel = rawByModel as Array;
                topLevelByModelCount = byModel == null ? 0 : byModel.Length;
            }

            int nestedInstanceId = 0;
            int bodyMatchCount = 0;
            string bodyType = string.Empty;
            bool attributeFound = false;
            string attributeType = string.Empty;
            string attributeValue = string.Empty;
            string returnedAttributeName = string.Empty;
            ModelEntityReference nestedBodyReference = null;

            if (nested.Count == 1)
            {
                interop.CimMdlrAPI.IAssInstance nestedInstance = nested[0].Instance;
                nestedInstanceId = nestedInstance.ID;
                interop.CimMdlrAPI.ICimEntityList entities = nestedInstance.GetAllEntities();
                if (entities == null)
                    throw new InvalidOperationException("IAssInstance.GetAllEntities() returned null for " + targetModelTitle + ".");

                interop.CimMdlrAPI.ICimEntity matchedBody = null;
                for (int index = 1; index <= entities.Count; index++)
                {
                    interop.CimMdlrAPI.ICimEntity entity = entities[index] as interop.CimMdlrAPI.ICimEntity;
                    if (entity == null || entity.ID != bodyId)
                        continue;

                    bodyMatchCount++;
                    bodyType = entity.Type.ToString();
                    if (string.Equals(bodyType, "cmBody", StringComparison.Ordinal))
                        matchedBody = entity;
                }

                if (bodyMatchCount == 1 && matchedBody != null)
                {
                    interop.CimBaseAPI.IAttributeSink sink = matchedBody as interop.CimBaseAPI.IAttributeSink;
                    if (sink != null)
                    {
                        interop.CimBaseAPI.IAttribute attribute = sink.GetAttribute(
                            interop.CimBaseAPI.AttributeEnumType.cmAttString,
                            attributeName);
                        if (attribute != null)
                        {
                            attributeFound = true;
                            attributeType = attribute.Type.ToString();
                            attributeValue = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                            returnedAttributeName = attribute.Name ?? string.Empty;
                        }
                    }

                    interop.CimMdlrAPI.IModel nestedModel = nestedInstance.Model as interop.CimMdlrAPI.IModel;
                    string modelPid = nestedModel == null ? string.Empty : nestedModel.PID ?? string.Empty;
                    nestedBodyReference = CreateEntityReference(nestedInstance.ID, modelPid, bodyId);
                }
            }

            MutationSnapshot after = MutationSnapshot.Capture(document);
            OccurrenceEntityAttributeResult result = new OccurrenceEntityAttributeResult(
                assemblyModel.Title,
                targetModelTitle,
                matching.Count,
                topLevelByModelCount,
                nested.Count,
                nestedInstanceId,
                bodyId,
                bodyMatchCount,
                bodyType,
                attributeFound,
                attributeType,
                attributeValue,
                returnedAttributeName,
                nestedBodyReference,
                before.IsEquivalentTo(after));

            return ModelReadResult<OccurrenceEntityAttributeResult>.Passed(result, "Occurrence/attribute evidence captured.");
        }

        private static void Traverse(interop.CimMdlrAPI.IAssemblyModel assembly, ICollection<OccurrenceObservation> output, int depth)
        {
            if (assembly == null) throw new ArgumentNullException(nameof(assembly));
            if (depth > 16) throw new InvalidOperationException("Assembly traversal depth exceeded 16.");

            object[] rawInstances = assembly.GetInstances();
            if (rawInstances == null)
                return;

            foreach (object raw in rawInstances)
            {
                interop.CimMdlrAPI.IAssInstance instance = raw as interop.CimMdlrAPI.IAssInstance;
                if (instance == null)
                    continue;

                output.Add(new OccurrenceObservation(instance, depth));
                object rawSubInstances = instance.get_SubInstances(1, 0);
                object[] subInstances = rawSubInstances as object[];
                if (subInstances != null && subInstances.Length > 0 && instance.Model != null &&
                    string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    Traverse((interop.CimMdlrAPI.IAssemblyModel)instance.Model, output, depth + 1);
                }
            }
        }

        private static ModelEntityReference CreateEntityReference(int instanceId, string modelPid, int entityId)
        {
            string encodedPid = Convert.ToBase64String(Encoding.UTF8.GetBytes(modelPid ?? string.Empty));
            return new ModelEntityReference(
                EntityReferencePrefix + "|" +
                instanceId.ToString(CultureInfo.InvariantCulture) + "|" +
                encodedPid + "|" +
                entityId.ToString(CultureInfo.InvariantCulture));
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
                throw new InvalidOperationException("Cimatron application is not available.");
            return application;
        }

        private sealed class OccurrenceObservation
        {
            internal OccurrenceObservation(interop.CimMdlrAPI.IAssInstance instance, int depth)
            {
                Instance = instance;
                Depth = depth;
            }

            internal interop.CimMdlrAPI.IAssInstance Instance { get; }
            internal int Depth { get; }
        }

        private sealed class MutationSnapshot
        {
            private MutationSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            private string Path { get; }
            private bool Modified { get; }
            private DateTime? LastWriteUtc { get; }
            private long? Length { get; }

            internal static MutationSnapshot Capture(interop.CimatronE.ICimDocument document)
            {
                bool modified = document.IsModified();
                string path = document.GetPath() ?? string.Empty;
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo info = new FileInfo(path);
                    lastWriteUtc = info.LastWriteTimeUtc;
                    length = info.Length;
                }
                return new MutationSnapshot(path, modified, lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(MutationSnapshot other)
            {
                return other != null &&
                    !string.IsNullOrWhiteSpace(Path) &&
                    LastWriteUtc.HasValue && Length.HasValue &&
                    other.LastWriteUtc.HasValue && other.Length.HasValue &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }
    }
}
