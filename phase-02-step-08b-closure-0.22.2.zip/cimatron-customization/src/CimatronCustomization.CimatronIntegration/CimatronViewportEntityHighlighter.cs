using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Cimatron 2026 adapter for read-only viewport highlighting through ISelection.Selection.
    /// Step 05A intentionally does not implement zoom or interactive picking.
    /// </summary>
    public sealed class CimatronViewportEntityHighlighter : IViewportEntityHighlighter
    {
        private const string EntityReferencePrefix = "entity";

        public ViewportHighlightResult Highlight(IReadOnlyList<string> entityReferenceValues)
        {
            if (entityReferenceValues == null) throw new ArgumentNullException(nameof(entityReferenceValues));
            if (entityReferenceValues.Count == 0)
            {
                return ViewportHighlightResult.Unsupported("This finding has no Cimatron entity reference to highlight.");
            }

            interop.CimatronE.IApplication application = GetApplication();
            interop.CimatronE.ICimDocument document = application.GetActiveDoc();
            if (document == null)
            {
                return ViewportHighlightResult.Unsupported("No active Cimatron document is available for highlighting.");
            }

            interop.CimMdlrAPI.ISelection selection = document as interop.CimMdlrAPI.ISelection;
            if (selection == null)
            {
                return ViewportHighlightResult.Unsupported("The active Cimatron document does not expose ISelection.");
            }

            interop.CimMdlrAPI.ICimEntityList entityList =
                (interop.CimMdlrAPI.ICimEntityList)new interop.CimBaseAPI.CimEntityList();

            foreach (string referenceValue in entityReferenceValues)
            {
                interop.CimMdlrAPI.ICimEntity entity;
                string unsupportedReason;
                if (!TryResolveCurrentDocumentEntity(document, referenceValue, out entity, out unsupportedReason))
                {
                    return ViewportHighlightResult.Unsupported(unsupportedReason);
                }

                entityList.Add(entity);
            }

            selection.Selection = entityList;
            return ViewportHighlightResult.Highlighted(
                "Highlighted " + entityList.Count.ToString(CultureInfo.InvariantCulture) + " Cimatron entity reference(s).");
        }

        private static bool TryResolveCurrentDocumentEntity(
            interop.CimatronE.ICimDocument document,
            string referenceValue,
            out interop.CimMdlrAPI.ICimEntity entity,
            out string unsupportedReason)
        {
            entity = null;
            unsupportedReason = string.Empty;

            if (string.IsNullOrWhiteSpace(referenceValue))
            {
                unsupportedReason = "The finding contains an empty Cimatron entity reference.";
                return false;
            }

            string[] parts = referenceValue.Split('|');
            if (parts.Length != 4 || !string.Equals(parts[0], EntityReferencePrefix, StringComparison.Ordinal))
            {
                unsupportedReason = "This finding reference type is not supported by Step 05A viewport highlighting.";
                return false;
            }

            int instanceId;
            int entityId;
            if (!int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out instanceId) ||
                !int.TryParse(parts[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out entityId))
            {
                unsupportedReason = "The finding contains an invalid current-session Cimatron entity reference.";
                return false;
            }

            string expectedPid;
            try
            {
                expectedPid = Encoding.UTF8.GetString(Convert.FromBase64String(parts[2]));
            }
            catch (FormatException)
            {
                unsupportedReason = "The finding contains an invalid current-session Cimatron model reference.";
                return false;
            }

            interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
            if (container == null)
            {
                unsupportedReason = "The active Cimatron document does not expose a model container.";
                return false;
            }

            interop.CimMdlrAPI.IModel model = container.Model as interop.CimMdlrAPI.IModel;
            if (model == null)
            {
                unsupportedReason = "The active Cimatron document does not expose a model for entity highlighting.";
                return false;
            }

            if (instanceId == 0)
            {
                if (!string.Equals(model.PID ?? string.Empty, expectedPid ?? string.Empty, StringComparison.Ordinal))
                {
                    unsupportedReason = "The finding reference belongs to a different Cimatron model/session and cannot be highlighted safely.";
                    return false;
                }

                entity = model.GetEntityById(entityId, model);
                if (entity == null)
                {
                    unsupportedReason = "The referenced Cimatron entity is no longer available in the active model.";
                    return false;
                }

                return true;
            }

            if (!string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
            {
                unsupportedReason = "Nested Cimatron entity references require an active Assembly document.";
                return false;
            }

            interop.CimMdlrAPI.IAssemblyModel assembly = model as interop.CimMdlrAPI.IAssemblyModel;
            if (assembly == null)
            {
                unsupportedReason = "The active Cimatron model does not expose IAssemblyModel for nested highlighting.";
                return false;
            }

            interop.CimMdlrAPI.IAssInstance ownerInstance = FindInstance(assembly, instanceId, 0);
            if (ownerInstance == null || ownerInstance.Model == null)
            {
                unsupportedReason = "The referenced nested assembly occurrence is no longer available.";
                return false;
            }

            if (!string.Equals(ownerInstance.Model.PID ?? string.Empty, expectedPid ?? string.Empty, StringComparison.Ordinal))
            {
                unsupportedReason = "The nested finding reference belongs to a different Cimatron model/session and cannot be highlighted safely.";
                return false;
            }

            interop.CimMdlrAPI.ICimEntity occurrenceEntity = FindOccurrenceEntity(ownerInstance, entityId);
            if (occurrenceEntity == null)
            {
                unsupportedReason = "The referenced nested Cimatron entity is no longer available.";
                return false;
            }

            entity = assembly.GetAssemblyEntity(occurrenceEntity, (interop.CimMdlrAPI.AssInstance)ownerInstance);
            if (entity == null)
            {
                unsupportedReason = "The nested Cimatron entity could not be mapped into the active Assembly context.";
                return false;
            }

            return true;
        }

        private static interop.CimMdlrAPI.ICimEntity FindOccurrenceEntity(interop.CimMdlrAPI.IAssInstance instance, int entityId)
        {
            interop.CimMdlrAPI.ICimEntityList entities = instance.GetAllEntities();
            if (entities == null)
                return null;

            interop.CimMdlrAPI.ICimEntity match = null;
            int count = 0;
            for (int index = 1; index <= entities.Count; index++)
            {
                interop.CimMdlrAPI.ICimEntity candidate = entities[index] as interop.CimMdlrAPI.ICimEntity;
                if (candidate == null || candidate.ID != entityId)
                    continue;

                count++;
                match = candidate;
            }

            return count == 1 ? match : null;
        }

        private static interop.CimMdlrAPI.IAssInstance FindInstance(interop.CimMdlrAPI.IAssemblyModel assembly, int instanceId, int depth)
        {
            if (depth > 16)
                return null;

            object[] rawInstances = assembly.GetInstances();
            if (rawInstances == null)
                return null;

            foreach (object raw in rawInstances)
            {
                interop.CimMdlrAPI.IAssInstance instance = raw as interop.CimMdlrAPI.IAssInstance;
                if (instance == null)
                    continue;
                if (instance.ID == instanceId)
                    return instance;

                object rawSubInstances = instance.get_SubInstances(1, 0);
                object[] subInstances = rawSubInstances as object[];
                if (subInstances != null && subInstances.Length > 0 && instance.Model != null &&
                    string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    interop.CimMdlrAPI.IAssInstance nested = FindInstance((interop.CimMdlrAPI.IAssemblyModel)instance.Model, instanceId, depth + 1);
                    if (nested != null)
                        return nested;
                }
            }

            return null;
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
            {
                throw new InvalidOperationException("Cimatron application is not available.");
            }

            return application;
        }
    }
}
