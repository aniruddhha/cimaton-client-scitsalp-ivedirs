using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Read-only Cimatron 2026 adapter for Step 07 U1 geometry metrics.
    /// </summary>
    public sealed class CimatronBodyGeometryMetricsReader : IBodyGeometryMetricsReader
    {
        public ModelReadResult<BodyGeometryMetricsSnapshot> ReadBodyMetrics(string expectedModelTitle, int bodyId)
        {
            if (string.IsNullOrWhiteSpace(expectedModelTitle)) throw new ArgumentException("An expected model title is required.", nameof(expectedModelTitle));
            if (bodyId <= 0) throw new ArgumentOutOfRangeException(nameof(bodyId));

            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
            {
                throw new InvalidOperationException("Cimatron application is not available.");
            }

            interop.CimatronE.ICimDocument document = application.GetActiveDoc();
            if (document == null)
            {
                return ModelReadResult<BodyGeometryMetricsSnapshot>.Unsupported("No active Cimatron document is available.");
            }

            if (!string.Equals(document.Type.ToString(), "cmPart", StringComparison.Ordinal))
            {
                return ModelReadResult<BodyGeometryMetricsSnapshot>.Unsupported("U1 in-process confirmation requires an active Part document.");
            }

            interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
            interop.CimMdlrAPI.IModel model = container == null ? null : container.Model as interop.CimMdlrAPI.IModel;
            if (model == null)
            {
                throw new InvalidOperationException("Active Part does not expose IModel through IModelContainer.");
            }

            if (!string.Equals(model.Title, expectedModelTitle, StringComparison.OrdinalIgnoreCase))
            {
                return ModelReadResult<BodyGeometryMetricsSnapshot>.Unsupported(
                    "Active model title is '" + (model.Title ?? string.Empty) + "'; expected '" + expectedModelTitle + "'.");
            }

            MutationSnapshot before = MutationSnapshot.Capture(document);

            interop.CimMdlrAPI.ICimEntity body = model.GetEntityById(bodyId, model);
            if (body == null || !string.Equals(body.Type.ToString(), "cmBody", StringComparison.Ordinal))
            {
                return ModelReadResult<BodyGeometryMetricsSnapshot>.Unsupported(
                    "Entity ID " + bodyId + " did not resolve to cmBody in " + expectedModelTitle + ".");
            }

            interop.CimMdlrAPI.IMdlrModel mdlrModel = model as interop.CimMdlrAPI.IMdlrModel;
            if (mdlrModel == null)
            {
                throw new InvalidOperationException("Active Part model does not expose IMdlrModel.");
            }

            interop.CimServicesAPI.IGeomServices geometry = (interop.CimServicesAPI.IGeomServices)mdlrModel.GetGeomServicesObj();
            interop.CimServicesAPI.ICimEntity serviceBody = body as interop.CimServicesAPI.ICimEntity;
            if (serviceBody == null)
            {
                throw new InvalidOperationException("GetEntityById body does not expose the Cimatron Services ICimEntity interface.");
            }

            interop.CimServicesAPI.ICimEntityList bodyList = CreateServiceEntityList(serviceBody);
            double volume = geometry.BodiesVolume(bodyList);
            double[] center = (double[])geometry.BodiesCenter(bodyList);
            double surfaceArea = geometry.BodiesSurfArea(bodyList);
            ValidateCenter(center, "GetEntityById");

            List<string> diagnosticEvidence = new List<string>();
            diagnosticEvidence.Add(
                "Context: ModelTitle=" + Safe(model.Title) +
                "; DocumentType=" + document.Type +
                "; Path=" + Safe(document.GetPath()) +
                "; RequestedBodyId=" + bodyId.ToString(CultureInfo.InvariantCulture) +
                "; GetEntityById.ID=" + body.ID.ToString(CultureInfo.InvariantCulture) +
                "; GetEntityById.Type=" + body.Type +
                "; GetEntityById.RuntimeType=" + SafeRuntimeType(body) +
                "; ServiceCast=YES.");

            diagnosticEvidence.Add(
                "CurrentPathRaw: Volume=" + FormatDouble(volume) +
                "; Center=" + FormatCenter(center) +
                "; SurfaceArea=" + FormatDouble(surfaceArea) + ".");

            diagnosticEvidence.Add(ReadStep07EquivalentEvidence(model, geometry, bodyId));

            MutationSnapshot after = MutationSnapshot.Capture(document);
            bool unchanged = before.IsEquivalentTo(after);
            if (!unchanged)
            {
                throw new InvalidOperationException("No-mutation evidence changed or could not be confirmed during the U1 geometry read.");
            }

            BodyGeometryMetricsSnapshot snapshot = new BodyGeometryMetricsSnapshot(
                model.Title,
                bodyId,
                volume,
                new Point3(center[0], center[1], center[2]),
                surfaceArea,
                true,
                diagnosticEvidence.ToArray());

            return ModelReadResult<BodyGeometryMetricsSnapshot>.Passed(
                snapshot,
                "Read U1 body volume, center and surface area inside the active Cimatron Plugin process.");
        }

        private static string ReadStep07EquivalentEvidence(
            interop.CimMdlrAPI.IModel model,
            interop.CimServicesAPI.IGeomServices geometry,
            int bodyId)
        {
            try
            {
                interop.CimMdlrAPI.IEntityQuery query = (interop.CimMdlrAPI.IEntityQuery)model;
                interop.CimMdlrAPI.IEntityFilter rawFilter = query.CreateFilter(interop.CimMdlrAPI.EFilterEnumType.cmFilterEntityType);
                interop.CimBaseAPI.FilterType typeFilter = (interop.CimBaseAPI.FilterType)rawFilter;
                typeFilter.Add(interop.CimBaseAPI.EntityEnumType.cmBody);
                query.SetFilter(rawFilter);
                interop.CimMdlrAPI.ICimEntityList bodies = query.Select();

                List<string> entries = new List<string>();
                interop.CimServicesAPI.ICimEntity target = null;
                for (int index = 1; index <= bodies.Count; index++)
                {
                    interop.CimMdlrAPI.ICimEntity entity = (interop.CimMdlrAPI.ICimEntity)bodies[index];
                    interop.CimServicesAPI.ICimEntity serviceEntity = entity as interop.CimServicesAPI.ICimEntity;
                    entries.Add(
                        entity.ID.ToString(CultureInfo.InvariantCulture) + ":" + entity.Type +
                        ":service=" + (serviceEntity == null ? "NO" : "YES") +
                        ":runtime=" + SafeRuntimeType(entity));
                    if (entity.ID == bodyId)
                    {
                        target = serviceEntity;
                    }
                }

                if (target == null)
                {
                    return "Step07Equivalent: EnumeratedBodies.Count=" + bodies.Count.ToString(CultureInfo.InvariantCulture) +
                        "; Entries=[" + string.Join(" | ", entries.ToArray()) +
                        "]; TargetId=" + bodyId.ToString(CultureInfo.InvariantCulture) + "; TargetFound=NO.";
                }

                interop.CimServicesAPI.ICimEntityList targetList = CreateServiceEntityList(target);
                double alternateVolume = geometry.BodiesVolume(targetList);
                double[] alternateCenter = (double[])geometry.BodiesCenter(targetList);
                double alternateSurfaceArea = geometry.BodiesSurfArea(targetList);
                ValidateCenter(alternateCenter, "Step07-equivalent enumeration");

                return "Step07Equivalent: EnumeratedBodies.Count=" + bodies.Count.ToString(CultureInfo.InvariantCulture) +
                    "; Entries=[" + string.Join(" | ", entries.ToArray()) +
                    "]; TargetFound=YES; RawVolume=" + FormatDouble(alternateVolume) +
                    "; RawCenter=" + FormatCenter(alternateCenter) +
                    "; RawSurfaceArea=" + FormatDouble(alternateSurfaceArea) + ".";
            }
            catch (Exception exception)
            {
                Exception raw = Unwrap(exception);
                return "Step07Equivalent: READ_ERROR type=" + raw.GetType().FullName +
                    "; HRESULT=0x" + raw.HResult.ToString("X8", CultureInfo.InvariantCulture) +
                    "; message=" + raw.Message + ".";
            }
        }

        private static interop.CimServicesAPI.ICimEntityList CreateServiceEntityList(interop.CimServicesAPI.ICimEntity entity)
        {
            interop.CimBaseAPI.CimEntityList listBase = new interop.CimBaseAPI.CimEntityList();
            interop.CimServicesAPI.ICimEntityList list = (interop.CimServicesAPI.ICimEntityList)listBase;
            list.Add(entity);
            return list;
        }

        private static void ValidateCenter(double[] center, string path)
        {
            if (center == null || center.Length < 3)
            {
                throw new InvalidOperationException(path + " BodiesCenter did not return at least three coordinates.");
            }
        }

        private static string FormatCenter(double[] center)
        {
            return "[" + FormatDouble(center[0]) + "," + FormatDouble(center[1]) + "," + FormatDouble(center[2]) + "]";
        }

        private static string FormatDouble(double value)
        {
            return value.ToString("R", CultureInfo.InvariantCulture);
        }

        private static string Safe(string value)
        {
            return value ?? string.Empty;
        }

        private static string SafeRuntimeType(object value)
        {
            return value == null ? "null" : (value.GetType().FullName ?? value.GetType().Name);
        }

        private static Exception Unwrap(Exception exception)
        {
            while (exception is System.Reflection.TargetInvocationException && exception.InnerException != null)
            {
                exception = exception.InnerException;
            }

            return exception;
        }

        private sealed class MutationSnapshot
        {
            private MutationSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            private string Path { get; }
            private bool Modified { get; }
            private DateTime? LastWriteUtc { get; }
            private long? Length { get; }

            internal static MutationSnapshot Capture(interop.CimatronE.ICimDocument document)
            {
                bool modified = document.IsModified();
                string path = document.GetPath() ?? string.Empty;
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo info = new FileInfo(path);
                    lastWriteUtc = info.LastWriteTimeUtc;
                    length = info.Length;
                }

                return new MutationSnapshot(path, modified, lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(MutationSnapshot other)
            {
                return other != null &&
                    !string.IsNullOrWhiteSpace(Path) &&
                    LastWriteUtc.HasValue &&
                    Length.HasValue &&
                    other.LastWriteUtc.HasValue &&
                    other.Length.HasValue &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }
    }
}
