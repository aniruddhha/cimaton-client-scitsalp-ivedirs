using System;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    internal static class ViewportPickResultValidator
    {
        internal static ViewportPickResult ValidateForDocumentToken(ViewportPickResult result, string currentDocumentToken)
        {
            if (result == null) throw new ArgumentNullException(nameof(result));
            if (result.Outcome != ViewportPickOutcome.Picked)
            {
                return result;
            }

            if (result.SourceDocument != null &&
                !string.IsNullOrWhiteSpace(currentDocumentToken) &&
                string.Equals(result.SourceDocument.SessionDocumentToken, currentDocumentToken, StringComparison.Ordinal))
            {
                return result;
            }

            return ViewportPickResult.WithoutEntity(
                result.CorrelationId,
                ViewportPickOutcome.StaleResult,
                result.SourceDocument,
                "SOURCE_DOCUMENT_STALE",
                "The picked entity belongs to a document that is no longer the active source document.");
        }
    }
}
