using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Governed Cimatron 2026 BOM export/readback adapter for material evidence.
    /// The Cimatron model is read-only; the only intentional side effect is a temporary CSV below the Step08B temp root.
    /// </summary>
    public sealed class CimatronBomMaterialExporter : IBomMaterialExporter
    {
        private static readonly string[] ExpectedBomHeaders =
        {
            "No.",
            "Qty.",
            "Standard Number",
            "Sub Category",
            "Category",
            "Visible Part Size",
            "Material"
        };

        private readonly ITabularDataReader tabularDataReader;

        public CimatronBomMaterialExporter(ITabularDataReader tabularDataReader)
        {
            this.tabularDataReader = tabularDataReader ?? throw new ArgumentNullException(nameof(tabularDataReader));
        }

        public BomMaterialExportResult ExportAndReadMaterial(string expectedAssemblyTitle, string targetModelTitle)
        {
            if (string.IsNullOrWhiteSpace(expectedAssemblyTitle)) throw new ArgumentException("An expected assembly title is required.", nameof(expectedAssemblyTitle));
            if (string.IsNullOrWhiteSpace(targetModelTitle)) throw new ArgumentException("A target model title is required.", nameof(targetModelTitle));

            interop.CimatronE.IApplication application = GetApplication();
            interop.CimatronE.ICimDocument document = application.GetActiveDoc();
            if (document == null)
            {
                return CreateUnsupported("No active Cimatron document is available.");
            }
            if (!string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
            {
                return CreateUnsupported("U15 in-process confirmation requires an active Assembly document.");
            }

            interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
            interop.CimMdlrAPI.IAssemblyModel assembly = container == null ? null : container.Model as interop.CimMdlrAPI.IAssemblyModel;
            interop.CimMdlrAPI.IModel assemblyModel = assembly as interop.CimMdlrAPI.IModel;
            if (assembly == null || assemblyModel == null)
                throw new InvalidOperationException("Active Assembly does not expose IAssemblyModel/IModel through IModelContainer.");
            if (!string.Equals(assemblyModel.Title, expectedAssemblyTitle, StringComparison.OrdinalIgnoreCase))
            {
                return CreateUnsupported(
                    "Active assembly title is '" + (assemblyModel.Title ?? string.Empty) + "'; expected '" + expectedAssemblyTitle + "'.");
            }

            MutationSnapshot before = MutationSnapshot.Capture(document);
            FolderSnapshot folderBefore = FolderSnapshot.Capture(before.Path);
            string runDirectory = CreateRunDirectory();
            string csvFileName = string.Empty;
            ResultStatus status = ResultStatus.Passed;
            string message = "BOM material evidence captured.";
            bool materialColumnPresent = false;
            int knownAnswerRowCount = 0;
            string materialValue = string.Empty;
            bool cleanupSucceeded = true;
            bool noMutationConfirmed = false;
            bool modelFolderUnchanged = false;

            try
            {
                interop.CimMdlrAPI.IBOM bom;
                try
                {
                    bom = assembly.GetBomManager();
                }
                catch (COMException exception)
                {
                    status = ResultStatus.Error;
                    message = ReadError("GetBomManager", exception);
                    bom = null;
                }

                if (status == ResultStatus.Passed && bom == null)
                {
                    status = ResultStatus.Error;
                    message = "READ_ERROR GetBomManager returned no BOM manager.";
                }

                if (status == ResultStatus.Passed)
                {
                    string stem = Path.Combine(runDirectory, "bom-material");
                    try
                    {
                        bom.Export(
                            stem,
                            interop.CimMdlrAPI.BOMTemplateType.cmCSV,
                            (interop.CimMdlrAPI.BOMExportOptions)0,
                            string.Empty,
                            interop.CimMdlrAPI.BOMReportFormat.cmNotReq,
                            interop.CimMdlrAPI.ComponentsFilterOption.cmNoFiltering,
                            Array.Empty<string>());
                    }
                    catch (COMException exception)
                    {
                        status = ResultStatus.Error;
                        message = ReadError("IBOM.Export(cmNoFiltering)", exception);
                    }

                    if (status == ResultStatus.Passed)
                    {
                        string[] csvFiles = Directory.GetFiles(runDirectory, "bom-material*.csv", SearchOption.TopDirectoryOnly);
                        if (csvFiles.Length != 1)
                        {
                            status = ResultStatus.Error;
                            message = "READ_ERROR Expected exactly one cmNoFiltering BOM CSV; observed " + csvFiles.Length.ToString(CultureInfo.InvariantCulture) + ".";
                        }
                        else
                        {
                            csvFileName = Path.GetFileName(csvFiles[0]);
                            TabularSourceDefinition source = new TabularSourceDefinition(
                                csvFiles[0],
                                "CSV",
                                1,
                                new[]
                                {
                                    new TabularColumnDefinition("Model", "Standard Number", TabularValueType.Text, true),
                                    new TabularColumnDefinition("Material", "Material", TabularValueType.Text, false)
                                });

                            TabularReadResult read = tabularDataReader.Read(source, ExpectedBomHeaders);
                            if (!read.IsSuccess)
                            {
                                if (string.Equals(read.ErrorCode, "TABULAR_COLUMN_NOT_FOUND", StringComparison.Ordinal))
                                {
                                    materialColumnPresent = false;
                                    message = "BOM CSV was exported, but the locked Step 07 Standard Number/Material column contract was not present: " + read.ErrorMessage;
                                }
                                else if (string.Equals(read.ErrorCode, "TABULAR_HEADERS_CHANGED", StringComparison.Ordinal))
                                {
                                    message = "BOM CSV header did not match the locked Step 07 header contract: " + read.ErrorMessage;
                                }
                                else
                                {
                                    status = ResultStatus.Error;
                                    message = "READ_ERROR " + read.ErrorCode + ": " + read.ErrorMessage;
                                }
                            }
                            else
                            {
                                materialColumnPresent = true;
                                foreach (TabularRow row in read.Table.Rows)
                                {
                                    string model = row.GetRequired("Model").TextValue ?? string.Empty;
                                    if (!string.Equals(model.Trim(), targetModelTitle, StringComparison.OrdinalIgnoreCase))
                                        continue;

                                    knownAnswerRowCount++;
                                    if (!row.TryGetValue("Material", out TabularValue observedMaterial) ||
                                        observedMaterial == null ||
                                        string.IsNullOrWhiteSpace(observedMaterial.TextValue))
                                    {
                                        if (status == ResultStatus.Passed)
                                        {
                                            status = ResultStatus.Error;
                                            message = "READ_ERROR Required Material value is missing for target model '" +
                                                targetModelTitle + "' at source row " +
                                                row.SourceRowNumber.ToString(CultureInfo.InvariantCulture) + ".";
                                        }
                                        continue;
                                    }

                                    if (knownAnswerRowCount == 1)
                                        materialValue = observedMaterial.TextValue.Trim();
                                }
                            }
                        }
                    }
                }
            }
            finally
            {
                try
                {
                    DeleteRunDirectory(runDirectory);
                }
                catch (IOException)
                {
                    cleanupSucceeded = false;
                }
                catch (UnauthorizedAccessException)
                {
                    cleanupSucceeded = false;
                }

                MutationSnapshot after = MutationSnapshot.Capture(document);
                FolderSnapshot folderAfter = FolderSnapshot.Capture(after.Path);
                noMutationConfirmed = before.IsEquivalentTo(after);
                modelFolderUnchanged = folderBefore.IsEquivalentTo(folderAfter);
            }

            return new BomMaterialExportResult(
                status,
                message,
                materialColumnPresent,
                knownAnswerRowCount,
                materialValue,
                noMutationConfirmed,
                modelFolderUnchanged,
                cleanupSucceeded,
                runDirectory,
                csvFileName);
        }

        private static BomMaterialExportResult CreateUnsupported(string message)
        {
            return new BomMaterialExportResult(
                ResultStatus.Unsupported,
                message,
                false,
                0,
                string.Empty,
                false,
                false,
                true,
                string.Empty,
                string.Empty);
        }

        private static string ReadError(string operation, COMException exception)
        {
            return "READ_ERROR " + operation + " failed with HRESULT=0x" +
                exception.HResult.ToString("X8", CultureInfo.InvariantCulture) + ": " + exception.Message;
        }

        private static string CreateRunDirectory()
        {
            string root = Path.Combine(Path.GetTempPath(), "CimatronCustomization", "Step08B");
            Directory.CreateDirectory(root);
            string timestamp = DateTime.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture);
            string run = Path.Combine(root, timestamp);
            int suffix = 1;
            while (Directory.Exists(run))
            {
                run = Path.Combine(root, timestamp + "-" + suffix.ToString(CultureInfo.InvariantCulture));
                suffix++;
            }
            Directory.CreateDirectory(run);
            return run;
        }

        private static void DeleteRunDirectory(string runDirectory)
        {
            if (string.IsNullOrWhiteSpace(runDirectory) || !Directory.Exists(runDirectory))
                return;

            string root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "CimatronCustomization", "Step08B"))
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string candidate = Path.GetFullPath(runDirectory)
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!candidate.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Step 08B cleanup refused to delete outside the governed temporary root.");

            Directory.Delete(runDirectory, true);
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
                throw new InvalidOperationException("Cimatron application is not available.");
            return application;
        }

        private sealed class MutationSnapshot
        {
            private MutationSnapshot(string path, bool modified, DateTime? lastWriteUtc, long? length)
            {
                Path = path;
                Modified = modified;
                LastWriteUtc = lastWriteUtc;
                Length = length;
            }

            internal string Path { get; }
            private bool Modified { get; }
            private DateTime? LastWriteUtc { get; }
            private long? Length { get; }

            internal static MutationSnapshot Capture(interop.CimatronE.ICimDocument document)
            {
                bool modified = document.IsModified();
                string path = document.GetPath() ?? string.Empty;
                DateTime? lastWriteUtc = null;
                long? length = null;
                if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                {
                    FileInfo info = new FileInfo(path);
                    lastWriteUtc = info.LastWriteTimeUtc;
                    length = info.Length;
                }
                return new MutationSnapshot(path, modified, lastWriteUtc, length);
            }

            internal bool IsEquivalentTo(MutationSnapshot other)
            {
                return other != null &&
                    !string.IsNullOrWhiteSpace(Path) &&
                    LastWriteUtc.HasValue && Length.HasValue &&
                    other.LastWriteUtc.HasValue && other.Length.HasValue &&
                    string.Equals(Path, other.Path, StringComparison.OrdinalIgnoreCase) &&
                    Modified == other.Modified &&
                    LastWriteUtc == other.LastWriteUtc &&
                    Length == other.Length;
            }
        }

        private sealed class FolderSnapshot
        {
            private readonly string folder;
            private readonly string[] entries;

            private FolderSnapshot(string folder, string[] entries)
            {
                this.folder = folder;
                this.entries = entries;
            }

            internal static FolderSnapshot Capture(string modelPath)
            {
                if (string.IsNullOrWhiteSpace(modelPath))
                    return new FolderSnapshot(string.Empty, Array.Empty<string>());

                string directory = Directory.Exists(modelPath) ? modelPath : Path.GetDirectoryName(modelPath);
                if (string.IsNullOrWhiteSpace(directory) || !Directory.Exists(directory))
                    return new FolderSnapshot(directory ?? string.Empty, Array.Empty<string>());

                string[] snapshot = Directory.GetFiles(directory)
                    .Select(path =>
                    {
                        FileInfo info = new FileInfo(path);
                        return info.Name + "|" + info.Length.ToString(CultureInfo.InvariantCulture) + "|" + info.LastWriteTimeUtc.ToString("O", CultureInfo.InvariantCulture);
                    })
                    .OrderBy(value => value, StringComparer.OrdinalIgnoreCase)
                    .ToArray();
                return new FolderSnapshot(directory, snapshot);
            }

            internal bool IsEquivalentTo(FolderSnapshot other)
            {
                return other != null &&
                    string.Equals(folder, other.folder, StringComparison.OrdinalIgnoreCase) &&
                    entries.SequenceEqual(other.entries, StringComparer.OrdinalIgnoreCase);
            }
        }
    }
}
