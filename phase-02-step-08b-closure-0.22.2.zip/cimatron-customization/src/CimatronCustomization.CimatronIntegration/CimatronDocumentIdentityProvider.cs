using System;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    internal sealed class CimatronDocumentIdentityProvider
    {
        private readonly SessionDocumentIdentityRegistry registry;
        private readonly interop.CimatronE.IApplication application;

        internal CimatronDocumentIdentityProvider(interop.CimatronE.IApplication application, SessionDocumentIdentityRegistry registry)
        {
            this.application = application ?? throw new ArgumentNullException(nameof(application));
            this.registry = registry ?? throw new ArgumentNullException(nameof(registry));
        }

        internal ViewportDocumentIdentity GetIdentity(interop.CimatronE.ICimDocument document)
        {
            if (document == null) throw new ArgumentNullException(nameof(document));
            return new ViewportDocumentIdentity(
                registry.GetOrCreate(document),
                document.Type.ToString(),
                document.Title ?? string.Empty,
                document.GetPath() ?? string.Empty);
        }

        internal string GetCurrentDocumentToken()
        {
            interop.CimatronE.ICimDocument currentDocument = application.GetActiveDoc();
            return currentDocument == null ? null : registry.GetOrCreate(currentDocument);
        }

        internal bool IsCurrent(ViewportDocumentIdentity identity)
        {
            if (identity == null)
            {
                return false;
            }

            string currentToken = GetCurrentDocumentToken();
            return !string.IsNullOrEmpty(currentToken) &&
                string.Equals(currentToken, identity.SessionDocumentToken, StringComparison.Ordinal);
        }
    }
}
