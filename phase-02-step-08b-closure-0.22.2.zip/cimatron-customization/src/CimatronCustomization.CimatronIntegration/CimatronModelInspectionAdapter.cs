using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.Domain;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Read-only Cimatron 2026 model inspection adapter. The adapter only uses documented getters/query APIs.
    /// Current-session entity references are opaque and are resolved only inside this integration boundary.
    /// </summary>
    public sealed class CimatronModelInspectionAdapter :
        IAssemblyStructureReader,
        IEntityAttributeReader,
        IEntityColorReader,
        IBodyTopologyReader
    {
        private const string EntityReferencePrefix = "entity";
        private const string InstanceReferencePrefix = "instance";

        public ModelReadResult<AssemblyStructureSnapshot> ReadCurrentAssembly()
        {
            interop.CimatronE.IApplication application = GetApplication();
            interop.CimatronE.ICimDocument activeDocument = application.GetActiveDoc();
            if (activeDocument == null)
            {
                return ModelReadResult<AssemblyStructureSnapshot>.Unsupported("No active Cimatron document is available.");
            }

            if (!string.Equals(activeDocument.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
            {
                return ModelReadResult<AssemblyStructureSnapshot>.Unsupported("Assembly structure is available only for an active Assembly document.");
            }

            interop.CimMdlrAPI.IModelContainer container = (interop.CimMdlrAPI.IModelContainer)activeDocument;
            interop.CimMdlrAPI.IAssemblyModel assemblyModel = (interop.CimMdlrAPI.IAssemblyModel)container.Model;
            List<AssemblyComponentSnapshot> components = new List<AssemblyComponentSnapshot>();
            AppendComponents(assemblyModel, null, components);

            string title = ((interop.CimMdlrAPI.IModel)container.Model).Title;
            return ModelReadResult<AssemblyStructureSnapshot>.Passed(
                new AssemblyStructureSnapshot(title, components),
                "Read " + components.Count.ToString(CultureInfo.InvariantCulture) + " assembly component instance(s).");
        }

        public ModelReadResult<EntityAttributeSnapshot> ReadAttributes(ModelEntityReference entityReference)
        {
            if (entityReference == null) throw new ArgumentNullException(nameof(entityReference));

            ResolvedReference resolved = ResolveReference(entityReference);
            if (resolved.Entity == null)
            {
                return ModelReadResult<EntityAttributeSnapshot>.Unsupported("Attributes are not exposed for this model reference type.");
            }

            interop.CimBaseAPI.IAttributeSink attributeSink = resolved.Entity as interop.CimBaseAPI.IAttributeSink;
            if (attributeSink == null)
            {
                return ModelReadResult<EntityAttributeSnapshot>.Unsupported("The referenced Cimatron entity does not expose IAttributeSink.");
            }

            object[] rawAttributes;
            string unsupportedReason;
            if (!TryGetRawAttributes(attributeSink, out rawAttributes, out unsupportedReason))
            {
                return ModelReadResult<EntityAttributeSnapshot>.Unsupported(unsupportedReason);
            }

            List<EntityAttributeValue> attributes = new List<EntityAttributeValue>();
            if (rawAttributes != null)
            {
                foreach (object rawAttribute in rawAttributes)
                {
                    interop.CimBaseAPI.IAttribute attribute = rawAttribute as interop.CimBaseAPI.IAttribute;
                    if (attribute == null)
                    {
                        continue;
                    }

                    string value = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                    attributes.Add(new EntityAttributeValue(attribute.Name, attribute.Type.ToString(), value));
                }
            }

            return ModelReadResult<EntityAttributeSnapshot>.Passed(
                new EntityAttributeSnapshot(entityReference, attributes),
                "Read " + attributes.Count.ToString(CultureInfo.InvariantCulture) + " attribute(s) from the referenced entity.");
        }

        public ModelReadResult<EntityColorSnapshot> ReadColor(ModelEntityReference entityReference)
        {
            if (entityReference == null) throw new ArgumentNullException(nameof(entityReference));

            ResolvedReference resolved = ResolveReference(entityReference);
            if (resolved.Instance != null)
            {
                return ModelReadResult<EntityColorSnapshot>.Passed(
                    new EntityColorSnapshot(entityReference, resolved.Instance.Color),
                    "Read the assembly-instance color.");
            }

            if (resolved.Entity == null)
            {
                return ModelReadResult<EntityColorSnapshot>.Unsupported("Color is not exposed for this model reference type.");
            }

            interop.CimBaseAPI.IAttributeSink attributeSink = resolved.Entity as interop.CimBaseAPI.IAttributeSink;
            if (attributeSink == null)
            {
                return ModelReadResult<EntityColorSnapshot>.Unsupported("The referenced Cimatron entity does not expose IAttributeSink for color inspection.");
            }

            object[] rawAttributes;
            string unsupportedReason;
            if (!TryGetRawAttributes(attributeSink, out rawAttributes, out unsupportedReason))
            {
                return ModelReadResult<EntityColorSnapshot>.Unsupported(
                    "Color inspection: " + unsupportedReason);
            }
            if (rawAttributes != null)
            {
                foreach (object rawAttribute in rawAttributes)
                {
                    interop.CimBaseAPI.IAttribute attribute = rawAttribute as interop.CimBaseAPI.IAttribute;
                    if (attribute != null && attribute.Type == interop.CimBaseAPI.AttributeEnumType.cmAttColor)
                    {
                        int color = Convert.ToInt32(attribute.Value, CultureInfo.InvariantCulture);
                        return ModelReadResult<EntityColorSnapshot>.Passed(
                            new EntityColorSnapshot(entityReference, color),
                            "Read the entity color attribute.");
                    }
                }
            }

            return ModelReadResult<EntityColorSnapshot>.Unsupported("No explicit cmAttColor attribute was found on the referenced entity.");
        }

        private static bool TryGetRawAttributes(
            interop.CimBaseAPI.IAttributeSink attributeSink,
            out object[] rawAttributes,
            out string unsupportedReason)
        {
            try
            {
                rawAttributes = attributeSink.GetAttributes();
                unsupportedReason = null;
                return true;
            }
            catch (ArgumentException exception)
            {
                rawAttributes = null;
                unsupportedReason =
                    "Cimatron entity exposes IAttributeSink but GetAttributes() is not supported for this entity: " +
                    exception.Message;
                return false;
            }
        }

        public ModelReadResult<BodyTopologySnapshot> ReadCurrentTopology()
        {
            interop.CimatronE.IApplication application = RunTopologyStage(
                "get Cimatron application",
                () => GetApplication());

            interop.CimatronE.ICimDocument activeDocument = RunTopologyStage(
                "get active Cimatron document",
                () => application.GetActiveDoc());

            if (activeDocument == null)
            {
                return ModelReadResult<BodyTopologySnapshot>.Unsupported("No active Cimatron document is available.");
            }

            string documentType = RunTopologyStage(
                "read active document type",
                () => activeDocument.Type.ToString());
            List<ModelEntityReference> bodies = new List<ModelEntityReference>();
            List<FaceTopologySnapshot> faces = new List<FaceTopologySnapshot>();

            interop.CimMdlrAPI.IModelContainer container = RunTopologyStage(
                "cast active document to IModelContainer",
                () => (interop.CimMdlrAPI.IModelContainer)activeDocument);

            if (string.Equals(documentType, "cmPart", StringComparison.Ordinal))
            {
                interop.CimMdlrAPI.IModel partModel = RunTopologyStage(
                    "read Part model from IModelContainer.Model",
                    () => (interop.CimMdlrAPI.IModel)container.Model);

                AppendTopology(partModel, 0, bodies, faces);
            }
            else if (string.Equals(documentType, "cmAssembly", StringComparison.Ordinal))
            {
                interop.CimMdlrAPI.IAssemblyModel assemblyModel = RunTopologyStage(
                    "read Assembly model from IModelContainer.Model",
                    () => (interop.CimMdlrAPI.IAssemblyModel)container.Model);

                List<interop.CimMdlrAPI.IAssInstance> partInstances = new List<interop.CimMdlrAPI.IAssInstance>();
                CollectPartInstances(assemblyModel, partInstances);
                foreach (interop.CimMdlrAPI.IAssInstance instance in partInstances)
                {
                    interop.CimMdlrAPI.IModel instanceModel = RunTopologyStage(
                        "read model for assembly instance",
                        () => instance.Model);

                    int instanceId = RunTopologyStage(
                        "read ID for assembly instance",
                        () => instance.ID);

                    AppendTopology(instanceModel, instanceId, bodies, faces);
                }
            }
            else
            {
                return ModelReadResult<BodyTopologySnapshot>.Unsupported("Body topology inspection supports Part and Assembly documents only.");
            }

            BodyTopologySnapshot snapshot = new BodyTopologySnapshot(
                bodies,
                faces,
                false);

            return ModelReadResult<BodyTopologySnapshot>.Passed(
                snapshot,
                "Read " + bodies.Count.ToString(CultureInfo.InvariantCulture) + " body reference(s) and " +
                faces.Count.ToString(CultureInfo.InvariantCulture) + " face reference(s). " +
                "Face type, area and normal-at-point access use verified surface APIs; bounding-box access remains UNVERIFIED and is exposed as unsupported.");
        }

        public ModelReadResult<Direction3> ReadFaceNormal(ModelEntityReference faceReference, Point3 point)
        {
            if (faceReference == null) throw new ArgumentNullException(nameof(faceReference));

            ResolvedReference resolved = ResolveReference(faceReference);
            if (resolved.Entity == null)
            {
                return ModelReadResult<Direction3>.Unsupported("The face reference could not be resolved in the current Cimatron session.");
            }

            interop.CimServicesAPI.IGeom3DSurface surface = resolved.Entity.Geometry as interop.CimServicesAPI.IGeom3DSurface;
            if (surface == null)
            {
                return ModelReadResult<Direction3>.Unsupported("The referenced entity is not exposed as IGeom3DSurface.");
            }

            double[] normal = surface.NormalFromPoint(point.X, point.Y, point.Z);
            if (normal == null || normal.Length < 3)
            {
                return ModelReadResult<Direction3>.Unsupported("Cimatron did not return a usable face normal at the requested point.");
            }

            return ModelReadResult<Direction3>.Passed(
                new Direction3(normal[0], normal[1], normal[2]),
                "Read the face normal from IGeom3DSurface.NormalFromPoint.");
        }

        private static interop.CimatronE.IApplication GetApplication()
        {
            interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
            interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
            if (application == null)
            {
                throw new InvalidOperationException("Cimatron application is not available.");
            }

            return application;
        }

        private static void AppendComponents(
            interop.CimMdlrAPI.IAssemblyModel assemblyModel,
            int? parentInstanceId,
            ICollection<AssemblyComponentSnapshot> destination)
        {
            foreach (interop.CimMdlrAPI.IAssInstance instance in EnumerateInstances(assemblyModel))
            {
                if (instance == null)
                {
                    continue;
                }

                interop.CimMdlrAPI.IModel model = instance.Model;
                double[] matrix = ReadPlacementMatrix(instance);
                destination.Add(new AssemblyComponentSnapshot(
                    CreateInstanceReference(instance.ID),
                    instance.ID,
                    parentInstanceId,
                    model.Title,
                    model.Path,
                    MapDocumentContext(model.Type.ToString()),
                    instance.Color,
                    instance.IsSuppressed != 0,
                    matrix));

                if (string.Equals(model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    AppendComponents((interop.CimMdlrAPI.IAssemblyModel)model, instance.ID, destination);
                }
            }
        }

        private static double[] ReadPlacementMatrix(interop.CimMdlrAPI.IAssInstance instance)
        {
            interop.CimMdlrAPI.ModelTransformation transformation = instance.get_Transformation(1);
            return transformation == null || transformation.Matrix == null
                ? Array.Empty<double>()
                : (double[])transformation.Matrix.Clone();
        }

        private static void CollectPartInstances(
            interop.CimMdlrAPI.IAssemblyModel assemblyModel,
            ICollection<interop.CimMdlrAPI.IAssInstance> destination)
        {
            foreach (interop.CimMdlrAPI.IAssInstance instance in EnumerateInstances(assemblyModel))
            {
                if (instance == null)
                {
                    continue;
                }

                string typeName = instance.Model.Type.ToString();
                if (string.Equals(typeName, "cmPart", StringComparison.Ordinal))
                {
                    destination.Add(instance);
                }
                else if (string.Equals(typeName, "cmAssembly", StringComparison.Ordinal))
                {
                    CollectPartInstances((interop.CimMdlrAPI.IAssemblyModel)instance.Model, destination);
                }
            }
        }

        private static void AppendTopology(
            interop.CimMdlrAPI.IModel model,
            int instanceId,
            List<ModelEntityReference> bodies,
            List<FaceTopologySnapshot> faces)
        {
            if (model == null) throw new ArgumentNullException(nameof(model));

            interop.CimMdlrAPI.IEntityQuery query = RunTopologyStage(
                "cast model to IEntityQuery",
                () => (interop.CimMdlrAPI.IEntityQuery)model);

            interop.CimMdlrAPI.IEntityFilter bodyFilter = RunTopologyStage(
                "create body entity filter",
                () => query.CreateFilter(interop.CimMdlrAPI.EFilterEnumType.cmFilterEntityType));

            interop.CimBaseAPI.FilterType bodyTypeFilter = RunTopologyStage(
                "cast body filter to FilterType",
                () => (interop.CimBaseAPI.FilterType)bodyFilter);

            RunTopologyStage(
                "add cmBody to body filter",
                () =>
                {
                    bodyTypeFilter.Add(interop.CimBaseAPI.EntityEnumType.cmBody);
                    return true;
                });

            RunTopologyStage(
                "set body filter",
                () =>
                {
                    query.SetFilter(bodyFilter);
                    return true;
                });

            interop.CimMdlrAPI.ICimEntityList bodyList = RunTopologyStage(
                "select body entities",
                () => query.Select());

            if (bodyList == null)
            {
                return;
            }

            int bodyCount = RunTopologyStage("read body-list count", () => bodyList.Count);
            for (int bodyIndex = 1; bodyIndex <= bodyCount; bodyIndex++)
            {
                int currentBodyIndex = bodyIndex;
                interop.CimMdlrAPI.ICimEntity bodyEntity = RunTopologyStage(
                    "read body-list item " + currentBodyIndex.ToString(CultureInfo.InvariantCulture),
                    () => (interop.CimMdlrAPI.ICimEntity)bodyList[currentBodyIndex]);

                interop.CimBaseAPI.IBody body = bodyEntity as interop.CimBaseAPI.IBody;
                if (body == null)
                {
                    continue;
                }

                string modelPid = RunTopologyStage(
                    "read model PID",
                    () => model.PID);

                int bodyEntityId = RunTopologyStage(
                    "read body entity ID",
                    () => bodyEntity.ID);

                ModelEntityReference bodyReference = RunTopologyStage(
                    "create body entity reference",
                    () => CreateEntityReference(instanceId, modelPid, bodyEntityId));

                bodies.Add(bodyReference);

                interop.CimBaseAPI.ICimEntityList faceList = RunTopologyStage(
                    "IBody.GetFaces for body " + bodyEntityId.ToString(CultureInfo.InvariantCulture),
                    () => body.GetFaces());

                if (faceList == null)
                {
                    continue;
                }

                int faceCount = RunTopologyStage(
                    "read face-list count for body " + bodyEntityId.ToString(CultureInfo.InvariantCulture),
                    () => faceList.Count);

                for (int faceIndex = 1; faceIndex <= faceCount; faceIndex++)
                {
                    int currentFaceIndex = faceIndex;
                    interop.CimBaseAPI.ICimEntity baseFaceEntity = RunTopologyStage(
                        "read face-list item " + currentFaceIndex.ToString(CultureInfo.InvariantCulture) +
                        " for body " + bodyEntityId.ToString(CultureInfo.InvariantCulture),
                        () => faceList[currentFaceIndex]);

                    interop.CimBaseAPI.IFace face = baseFaceEntity as interop.CimBaseAPI.IFace;
                    interop.CimMdlrAPI.ICimEntity modelFaceEntity = baseFaceEntity as interop.CimMdlrAPI.ICimEntity;
                    if (face == null || modelFaceEntity == null)
                    {
                        continue;
                    }

                    int faceEntityId = RunTopologyStage(
                        "read face entity ID",
                        () => modelFaceEntity.ID);

                    interop.CimMdlrAPI.IGeometry3D geometry = RunTopologyStage(
                        "read geometry for face " + faceEntityId.ToString(CultureInfo.InvariantCulture),
                        () => modelFaceEntity.Geometry);

                    string geometryType = geometry == null
                        ? "Unknown"
                        : RunTopologyStage(
                            "read geometry type for face " + faceEntityId.ToString(CultureInfo.InvariantCulture),
                            () => geometry.Type.ToString());

                    double area = 0d;
                    interop.CimServicesAPI.IGeom3DSurface surface = geometry as interop.CimServicesAPI.IGeom3DSurface;
                    if (surface != null)
                    {
                        geometryType = RunTopologyStage(
                            "read surface type for face " + faceEntityId.ToString(CultureInfo.InvariantCulture),
                            () => surface.SurfType.ToString());

                        area = RunTopologyStage(
                            "read surface area for face " + faceEntityId.ToString(CultureInfo.InvariantCulture),
                            () => surface.Area());
                    }

                    ModelEntityReference faceReference = RunTopologyStage(
                        "create face entity reference",
                        () => CreateEntityReference(instanceId, modelPid, faceEntityId));

                    faces.Add(new FaceTopologySnapshot(
                        faceReference,
                        geometryType,
                        area));
                }
            }
        }

        private static T RunTopologyStage<T>(string stage, Func<T> operation)
        {
            try
            {
                return operation();
            }
            catch (Exception exception)
            {
                throw new InvalidOperationException(
                    "Cimatron topology stage '" + stage + "' failed: " + exception.Message,
                    exception);
            }
        }

        private static ResolvedReference ResolveReference(ModelEntityReference reference)
        {
            string[] parts = reference.Value.Split('|');
            if (parts.Length == 2 && string.Equals(parts[0], InstanceReferencePrefix, StringComparison.Ordinal))
            {
                int instanceId;
                if (!int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out instanceId))
                {
                    return new ResolvedReference();
                }

                interop.CimatronE.IApplication application = GetApplication();
                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                if (document == null || !string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    return new ResolvedReference();
                }

                interop.CimMdlrAPI.IModelContainer container = (interop.CimMdlrAPI.IModelContainer)document;
                interop.CimMdlrAPI.IAssInstance instance = FindInstance((interop.CimMdlrAPI.IAssemblyModel)container.Model, instanceId);
                return new ResolvedReference { Instance = instance };
            }

            if (parts.Length != 4 || !string.Equals(parts[0], EntityReferencePrefix, StringComparison.Ordinal))
            {
                return new ResolvedReference();
            }

            int entityInstanceId;
            int entityId;
            if (!int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out entityInstanceId) ||
                !int.TryParse(parts[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out entityId))
            {
                return new ResolvedReference();
            }

            string expectedPid;
            try
            {
                expectedPid = Encoding.UTF8.GetString(Convert.FromBase64String(parts[2]));
            }
            catch (FormatException)
            {
                return new ResolvedReference();
            }

            interop.CimatronE.IApplication currentApplication = GetApplication();
            interop.CimatronE.ICimDocument currentDocument = currentApplication.GetActiveDoc();
            if (currentDocument == null)
            {
                return new ResolvedReference();
            }

            interop.CimMdlrAPI.IModelContainer currentContainer = (interop.CimMdlrAPI.IModelContainer)currentDocument;
            interop.CimMdlrAPI.IModel model;
            interop.CimMdlrAPI.IAssInstance ownerInstance = null;
            if (entityInstanceId == 0)
            {
                model = (interop.CimMdlrAPI.IModel)currentContainer.Model;
            }
            else
            {
                if (!string.Equals(currentDocument.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    return new ResolvedReference();
                }

                ownerInstance = FindInstance((interop.CimMdlrAPI.IAssemblyModel)currentContainer.Model, entityInstanceId);
                if (ownerInstance == null)
                {
                    return new ResolvedReference();
                }

                model = ownerInstance.Model;
            }

            if (!string.Equals(model.PID ?? string.Empty, expectedPid ?? string.Empty, StringComparison.Ordinal))
            {
                return new ResolvedReference();
            }

            interop.CimMdlrAPI.ICimEntity entity = model.GetEntityById(entityId, model);
            return new ResolvedReference { Entity = entity, Instance = ownerInstance };
        }

        private static interop.CimMdlrAPI.IAssInstance FindInstance(interop.CimMdlrAPI.IAssemblyModel assemblyModel, int instanceId)
        {
            foreach (interop.CimMdlrAPI.IAssInstance instance in EnumerateInstances(assemblyModel))
            {
                if (instance == null)
                {
                    continue;
                }

                if (instance.ID == instanceId)
                {
                    return instance;
                }

                if (string.Equals(instance.Model.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                {
                    interop.CimMdlrAPI.IAssInstance nested = FindInstance((interop.CimMdlrAPI.IAssemblyModel)instance.Model, instanceId);
                    if (nested != null)
                    {
                        return nested;
                    }
                }
            }

            return null;
        }

        private static IEnumerable<interop.CimMdlrAPI.IAssInstance> EnumerateInstances(interop.CimMdlrAPI.IAssemblyModel assemblyModel)
        {
            if (assemblyModel == null) throw new ArgumentNullException(nameof(assemblyModel));

            // Official Cimatron C# examples consume GetInstances() as object[] and cast
            // each element to IAssInstance. Keep the call strongly typed through
            // IAssemblyModel; do not use dynamic dispatch against the raw COM object.
            object[] rawInstances = assemblyModel.GetInstances();
            if (rawInstances == null)
            {
                yield break;
            }

            foreach (object rawInstance in rawInstances)
            {
                interop.CimMdlrAPI.IAssInstance instance = rawInstance as interop.CimMdlrAPI.IAssInstance;
                if (instance != null)
                {
                    yield return instance;
                }
            }
        }

        private static ModelEntityReference CreateInstanceReference(int instanceId)
        {
            return new ModelEntityReference(InstanceReferencePrefix + "|" + instanceId.ToString(CultureInfo.InvariantCulture));
        }

        private static ModelEntityReference CreateEntityReference(int instanceId, string modelPid, int entityId)
        {
            string encodedPid = Convert.ToBase64String(Encoding.UTF8.GetBytes(modelPid ?? string.Empty));
            return new ModelEntityReference(
                EntityReferencePrefix + "|" +
                instanceId.ToString(CultureInfo.InvariantCulture) + "|" +
                encodedPid + "|" +
                entityId.ToString(CultureInfo.InvariantCulture));
        }

        private static CimatronDocumentContext MapDocumentContext(string typeName)
        {
            switch (typeName)
            {
                case "cmPart":
                    return CimatronDocumentContext.Part;
                case "cmAssembly":
                    return CimatronDocumentContext.Assembly;
                case "cmNc":
                    return CimatronDocumentContext.Nc;
                default:
                    return CimatronDocumentContext.Unsupported;
            }
        }

        private sealed class ResolvedReference
        {
            public interop.CimMdlrAPI.ICimEntity Entity { get; set; }
            public interop.CimMdlrAPI.IAssInstance Instance { get; set; }
        }
    }
}
