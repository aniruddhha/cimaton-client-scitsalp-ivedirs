using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    /// <summary>
    /// Production Part PickTool for Step 05B2. This is the only COM-visible class in CimatronIntegration.
    /// It is instantiated directly and passed to Cimatron; no COM registration is required.
    /// </summary>
    [ComVisible(true)]
    [Guid("8C05B1D6-7440-4EF7-A369-9A86B54AE151")]
    [ClassInterface(ClassInterfaceType.None)]
    public sealed class CimatronViewportPickTool :
        interop.CimBaseAPI.Tool,
        interop.CimBaseAPI.IToolEvents,
        interop.CimBaseAPI.IPickToolEvents,
        interop.CimBaseAPI.IFigureEvent
    {
        private const int EscapeKey = 27;
        private const int MaximumRecordedEvents = 64;

        private readonly interop.CimatronE.IApplication application;
        private readonly interop.CimBaseAPI.IToolContainer toolContainer;
        private readonly string originalModelPid;
        private readonly ViewportDocumentIdentity sourceDocument;
        private readonly CimatronDocumentIdentityProvider documentIdentityProvider;
        private readonly ViewportPickRequest request;
        private readonly string correlationId;
        private readonly string applicationVersion;
        private readonly string cimatronVersion;
        private readonly IApplicationLogger logger;
        private readonly Action<ViewportPickResult> completion;
        private readonly List<string> events = new List<string>();

        private bool popRequested;
        private bool completionRaised;
        private ViewportPickResult pendingResult;
        private Exception pendingException;
        private int toolLevel;

        internal CimatronViewportPickTool(
            interop.CimatronE.IApplication application,
            interop.CimBaseAPI.IToolContainer toolContainer,
            string originalModelPid,
            ViewportDocumentIdentity sourceDocument,
            CimatronDocumentIdentityProvider documentIdentityProvider,
            ViewportPickRequest request,
            string correlationId,
            string applicationVersion,
            string cimatronVersion,
            IApplicationLogger logger,
            Action<ViewportPickResult> completion)
        {
            this.application = application ?? throw new ArgumentNullException(nameof(application));
            this.toolContainer = toolContainer ?? throw new ArgumentNullException(nameof(toolContainer));
            this.originalModelPid = originalModelPid ?? string.Empty;
            this.sourceDocument = sourceDocument ?? throw new ArgumentNullException(nameof(sourceDocument));
            this.documentIdentityProvider = documentIdentityProvider ?? throw new ArgumentNullException(nameof(documentIdentityProvider));
            this.request = request ?? throw new ArgumentNullException(nameof(request));
            this.correlationId = correlationId ?? throw new ArgumentNullException(nameof(correlationId));
            this.applicationVersion = applicationVersion ?? string.Empty;
            this.cimatronVersion = cimatronVersion ?? string.Empty;
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.completion = completion ?? throw new ArgumentNullException(nameof(completion));
            toolLevel = 1;
        }

        public int ToolLevel
        {
            get { return toolLevel; }
            set { toolLevel = value; }
        }

        public void OnToolPushed(object iToolHelper)
        {
            RecordEvent("OnToolPushed");
            interop.CimServicesAPI.IPickTool helper = iToolHelper as interop.CimServicesAPI.IPickTool;
            if (helper == null)
            {
                RequestPop(ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Failed,
                    sourceDocument,
                    "PICK_TOOL_HELPER_UNAVAILABLE",
                    "Cimatron pushed the PickTool without the verified IPickTool helper."), null);
                return;
            }

            RecordEvent("PickToolHelperAvailable");
        }

        public void OnToolPoped()
        {
            RecordEvent("OnToolPoped");
            if (pendingResult == null)
            {
                pendingResult = ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Cancelled,
                    sourceDocument,
                    "CIMATRON_TOOL_POPPED",
                    "Pick ended without selecting an entity (MMB/Cimatron pop or equivalent cancellation).");
            }

            CompleteOnce();
        }

        public int OnBlockPop()
        {
            RecordEvent("OnBlockPop");
            return 0;
        }

        public void OnKeyboardEvent(int iChar, int iRepCnt, int iFlags)
        {
            RecordEvent("OnKeyboardEvent char=" + iChar.ToString(CultureInfo.InvariantCulture));
            if (!EnsureOriginalDocument())
            {
                return;
            }

            if (iChar == EscapeKey)
            {
                Cancel("ESC", "Pick cancelled with Esc.");
            }
        }

        public void OnMouseEvent(interop.CimBaseAPI.MouseEventType iType, int iXPos, int iYPos)
        {
            RecordEvent(
                "OnMouseEvent type=" + iType +
                " x=" + iXPos.ToString(CultureInfo.InvariantCulture) +
                " y=" + iYPos.ToString(CultureInfo.InvariantCulture));
            EnsureOriginalDocument();
        }

        public stdole.IPicture OnSetCursor(int iXPos, int iYPos)
        {
            return null;
        }

        public void OnClearSelection()
        {
            RecordEvent("OnClearSelection");
            EnsureOriginalDocument();
        }

        public void OnEntityDraged(interop.CimBaseAPI.ICimEntity iEntity, int iXPos, int iYPos)
        {
            RecordEntityEvent("OnEntityDraged", iEntity, iXPos, iYPos);
            EnsureOriginalDocument();
        }

        public void OnEntityHighlighted(interop.CimBaseAPI.ICimEntity iEntity, int iXPos, int iYPos)
        {
            RecordEntityEvent("OnEntityHighlighted", iEntity, iXPos, iYPos);
            EnsureOriginalDocument();
        }

        public void OnEntityPicked(interop.CimBaseAPI.ICimEntity iEntity)
        {
            int? entityId = iEntity == null ? (int?)null : iEntity.ID;
            RecordEvent("OnEntityPicked entityId=" + FormatEntityId(entityId));
            if (!EnsureOriginalDocument())
            {
                return;
            }

            if (iEntity == null || !entityId.HasValue)
            {
                RequestPop(ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Failed,
                    sourceDocument,
                    "PICKED_ENTITY_MISSING",
                    "Cimatron raised OnEntityPicked without an entity."), null);
                return;
            }

            ViewportEntityType entityType = MapEntityType(iEntity.Type);
            if (entityType == ViewportEntityType.Unknown || !request.Allows(entityType))
            {
                RequestPop(ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Failed,
                    sourceDocument,
                    "PICKED_ENTITY_TYPE_REJECTED",
                    "Cimatron returned an entity type outside the active Pick filter."), null);
                return;
            }

            RequestPop(new ViewportPickResult(
                correlationId,
                ViewportPickOutcome.Picked,
                sourceDocument,
                entityId.Value,
                entityType,
                Array.Empty<string>(),
                "ENTITY_PICKED",
                "Part Pick selected current-session entity ID " + entityId.Value.ToString(CultureInfo.InvariantCulture) + "."), null);
        }

        public void OnEntityPressed(interop.CimBaseAPI.ICimEntity iEntity, int iXPos, int iYPos)
        {
            RecordEntityEvent("OnEntityPressed", iEntity, iXPos, iYPos);
            EnsureOriginalDocument();
        }

        public void OnEntityReleased(interop.CimBaseAPI.ICimEntity iEntity, int iXPos, int iYPos)
        {
            RecordEntityEvent("OnEntityReleased", iEntity, iXPos, iYPos);
            EnsureOriginalDocument();
        }

        public void OnNoEntityPicked(int iXPos, int iYPos)
        {
            RecordEvent(
                "OnNoEntityPicked x=" + iXPos.ToString(CultureInfo.InvariantCulture) +
                " y=" + iYPos.ToString(CultureInfo.InvariantCulture));
            EnsureOriginalDocument();
        }

        public void FigureChange(interop.CimBaseAPI.InteractionType iType, interop.CimBaseAPI.IInteraction oInteraction)
        {
            RecordEvent("FigureChange type=" + iType);
            EnsureOriginalDocument();
        }

        internal void CancelFromCaller()
        {
            Cancel("CALLER_CANCELLED", "Pick cancelled by the owning workflow.");
        }

        internal void CompleteBecauseSourceDocumentClosed()
        {
            if (completionRaised)
            {
                return;
            }

            RecordEvent("SourceDocumentClosedDetected");
            popRequested = true;
            pendingResult = ViewportPickResult.WithoutEntity(
                correlationId,
                ViewportPickOutcome.Cancelled,
                sourceDocument,
                "SOURCE_DOCUMENT_CLOSED",
                "Pick cancelled because the source Part document closed while the Pick was active.");
            pendingException = null;
            CompleteOnce();
        }

        private void Cancel(string reasonCode, string message)
        {
            RequestPop(ViewportPickResult.WithoutEntity(
                correlationId,
                ViewportPickOutcome.Cancelled,
                sourceDocument,
                reasonCode,
                message), null);
        }

        private bool EnsureOriginalDocument()
        {
            interop.CimatronE.ICimDocument currentDocument = application.GetActiveDoc();
            interop.CimMdlrAPI.IModelContainer currentContainer = currentDocument as interop.CimMdlrAPI.IModelContainer;
            interop.CimMdlrAPI.IModel currentModel = currentContainer == null ? null : currentContainer.Model as interop.CimMdlrAPI.IModel;

            if (currentDocument == null ||
                !string.Equals(currentDocument.Type.ToString(), "cmPart", StringComparison.Ordinal) ||
                currentModel == null ||
                !string.Equals(currentModel.PID ?? string.Empty, originalModelPid, StringComparison.Ordinal) ||
                !documentIdentityProvider.IsCurrent(sourceDocument))
            {
                Cancel("DOCUMENT_CHANGED", "Pick cancelled because the active source document changed or closed during the pick.");
                return false;
            }

            return true;
        }

        private void RecordEntityEvent(string eventName, interop.CimBaseAPI.ICimEntity entity, int x, int y)
        {
            int? entityId = entity == null ? (int?)null : entity.ID;
            RecordEvent(
                eventName +
                " entityId=" + FormatEntityId(entityId) +
                " x=" + x.ToString(CultureInfo.InvariantCulture) +
                " y=" + y.ToString(CultureInfo.InvariantCulture));
        }

        private static string FormatEntityId(int? entityId)
        {
            return entityId.HasValue ? entityId.Value.ToString(CultureInfo.InvariantCulture) : "<null>";
        }

        private static ViewportEntityType MapEntityType(interop.CimBaseAPI.EntityEnumType entityType)
        {
            switch (entityType)
            {
                case interop.CimBaseAPI.EntityEnumType.cmBody:
                    return ViewportEntityType.Body;
                case interop.CimBaseAPI.EntityEnumType.cmFace:
                    return ViewportEntityType.Face;
                case interop.CimBaseAPI.EntityEnumType.cmEdge:
                    return ViewportEntityType.Edge;
                case interop.CimBaseAPI.EntityEnumType.cmVertex:
                    return ViewportEntityType.Vertex;
                default:
                    return ViewportEntityType.Unknown;
            }
        }

        private void RecordEvent(string value)
        {
            if (events.Count < MaximumRecordedEvents)
            {
                events.Add(value);
            }
        }

        private void RequestPop(ViewportPickResult result, Exception exception)
        {
            if (popRequested || completionRaised)
            {
                return;
            }

            popRequested = true;
            pendingResult = result;
            pendingException = exception;
            try
            {
                toolContainer.PopTool((interop.CimBaseAPI.Tool)this);
            }
            catch (Exception popException)
            {
                pendingException = popException;
                pendingResult = ViewportPickResult.WithoutEntity(
                    correlationId,
                    ViewportPickOutcome.Failed,
                    sourceDocument,
                    "PICK_TOOL_POP_FAILED",
                    "Cimatron failed while popping the PickTool: " + popException.Message);
                CompleteOnce();
            }
        }

        private void CompleteOnce()
        {
            if (completionRaised)
            {
                return;
            }

            completionRaised = true;
            string eventTrace = events.Count == 0 ? "<none>" : string.Join(" | ", events);
            string message = pendingResult.Message + " Events: " + eventTrace;
            try
            {
                logger.Log(new ApplicationLogEntry(
                    DateTimeOffset.UtcNow,
                    pendingResult.Outcome == ViewportPickOutcome.Failed ? "Error" : "Information",
                    correlationId,
                    applicationVersion,
                    cimatronVersion,
                    "Viewport Entity Pick",
                    "PLATFORM-STEP-05B2",
                    "ViewportPickCompleted",
                    pendingResult.Outcome.ToString(),
                    0,
                    message,
                    pendingException));
            }
            catch (Exception)
            {
                // Logging must not cause a second completion or strand the active Pick session.
            }

            try
            {
                completion(pendingResult);
            }
            catch (Exception)
            {
                // Completion callbacks are external to the COM event sink. Never call them twice or throw back into Cimatron.
            }
        }
    }
}
