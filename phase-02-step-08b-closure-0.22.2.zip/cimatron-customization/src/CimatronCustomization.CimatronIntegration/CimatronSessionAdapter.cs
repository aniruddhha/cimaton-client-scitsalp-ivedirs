using CimatronCustomization.Application;

namespace CimatronCustomization.CimatronIntegration
{
    public sealed class CimatronSessionAdapter : ICimatronSession
    {
        public CimatronSessionSnapshot GetCurrentSession()
        {
            interop.CimServicesAPI.CimApplicationProvider applicationProvider =
                new interop.CimServicesAPI.CimApplicationProvider();

            interop.CimatronE.IApplication application =
                (interop.CimatronE.IApplication)applicationProvider.GetApplication();

            if (application == null)
            {
                return CimatronSessionSnapshot.ApplicationUnavailable();
            }

            interop.CimatronE.ICimDocument activeDocument = application.GetActiveDoc();
            if (activeDocument == null)
            {
                return CimatronSessionSnapshot.NoActiveDocument();
            }

            return CimatronSessionSnapshot.ActiveDocument(MapDocumentContext(activeDocument.Type.ToString()));
        }

        private static CimatronDocumentContext MapDocumentContext(string cimatronDocumentTypeName)
        {
            switch (cimatronDocumentTypeName)
            {
                case "cmPart":
                    return CimatronDocumentContext.Part;
                case "cmAssembly":
                    return CimatronDocumentContext.Assembly;
                case "cmNc":
                    return CimatronDocumentContext.Nc;
                default:
                    return CimatronDocumentContext.Unsupported;
            }
        }
    }
}
