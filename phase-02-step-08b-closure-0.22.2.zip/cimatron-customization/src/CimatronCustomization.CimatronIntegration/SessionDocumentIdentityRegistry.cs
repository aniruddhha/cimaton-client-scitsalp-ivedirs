using System;
using System.Runtime.CompilerServices;

namespace CimatronCustomization.CimatronIntegration
{
    internal sealed class SessionDocumentIdentityRegistry
    {
        private readonly ConditionalWeakTable<object, TokenHolder> tokens = new ConditionalWeakTable<object, TokenHolder>();

        internal string GetOrCreate(object document)
        {
            if (document == null) throw new ArgumentNullException(nameof(document));
            return tokens.GetValue(document, _ => new TokenHolder(Guid.NewGuid().ToString("N"))).Token;
        }

        private sealed class TokenHolder
        {
            internal TokenHolder(string token)
            {
                Token = token;
            }

            internal string Token { get; }
        }
    }
}
