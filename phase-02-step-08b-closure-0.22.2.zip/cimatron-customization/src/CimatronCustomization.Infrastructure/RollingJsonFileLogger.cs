using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CimatronCustomization.Application;

namespace CimatronCustomization.Infrastructure
{
    public sealed class RollingJsonFileLogger : IApplicationLogger
    {
        private readonly string directory;
        private readonly long maximumFileBytes;
        private readonly int retainedFileCount;
        private readonly object sync = new object();

        public RollingJsonFileLogger(string directory, long maximumFileBytes, int retainedFileCount)
        {
            if (string.IsNullOrWhiteSpace(directory)) throw new ArgumentException("Log directory is required.", nameof(directory));
            if (maximumFileBytes <= 0) throw new ArgumentOutOfRangeException(nameof(maximumFileBytes));
            if (retainedFileCount <= 0) throw new ArgumentOutOfRangeException(nameof(retainedFileCount));
            this.directory = directory; this.maximumFileBytes = maximumFileBytes; this.retainedFileCount = retainedFileCount;
            Directory.CreateDirectory(directory);
        }

        public void Log(ApplicationLogEntry entry)
        {
            if (entry == null) throw new ArgumentNullException(nameof(entry));
            lock (sync)
            {
                string line = Serialize(entry) + Environment.NewLine;
                byte[] bytes = Encoding.UTF8.GetBytes(line);
                string path = GetCurrentPath();
                if (File.Exists(path) && new FileInfo(path).Length + bytes.Length > maximumFileBytes) path = CreateRolledPath();
                File.AppendAllText(path, line, new UTF8Encoding(false));
                EnforceRetention();
            }
        }

        private string GetCurrentPath() => Path.Combine(directory, "cimatron-customization.log.jsonl");
        private string CreateRolledPath()
        {
            string current = GetCurrentPath();
            if (File.Exists(current))
            {
                string timestamp = DateTime.UtcNow.ToString("yyyyMMdd-HHmmssfff", CultureInfo.InvariantCulture);
                string rolled = Path.Combine(directory, "cimatron-customization-" + timestamp + ".log.jsonl");
                int sequence = 1;
                while (File.Exists(rolled))
                {
                    rolled = Path.Combine(directory, "cimatron-customization-" + timestamp + "-" + sequence.ToString("D3", CultureInfo.InvariantCulture) + ".log.jsonl");
                    sequence++;
                }
                File.Move(current, rolled);
            }
            return current;
        }
        private void EnforceRetention()
        {
            FileInfo[] files = new DirectoryInfo(directory).GetFiles("cimatron-customization*.log.jsonl").OrderByDescending(f => f.LastWriteTimeUtc).ToArray();
            for (int i = retainedFileCount; i < files.Length; i++) files[i].Delete();
        }
        private static string Serialize(ApplicationLogEntry e)
        {
            return "{" +
                Pair("timestampUtc", e.TimestampUtc.ToString("O", CultureInfo.InvariantCulture)) + "," + Pair("level", e.Level) + "," +
                Pair("correlationId", e.CorrelationId) + "," + Pair("applicationVersion", e.ApplicationVersion) + "," + Pair("cimatronVersion", e.CimatronVersion) + "," +
                Pair("feature", e.Feature) + "," + Pair("requirementId", e.RequirementId) + "," + Pair("operation", e.Operation) + "," + Pair("status", e.Status) + "," +
                "\"durationMilliseconds\":" + e.DurationMilliseconds.ToString(CultureInfo.InvariantCulture) + "," + Pair("message", e.Message) + "," +
                Pair("exceptionType", e.Exception == null ? string.Empty : e.Exception.GetType().FullName) + "," +
                Pair("exceptionMessage", e.Exception == null ? string.Empty : e.Exception.Message) + "," +
                Pair("exceptionStackTrace", e.Exception == null ? string.Empty : e.Exception.StackTrace) + "," +
                Pair("exceptionDetail", e.Exception == null ? string.Empty : e.Exception.ToString()) + "}";
        }
        private static string Pair(string name, string value) => "\"" + Escape(name) + "\":\"" + Escape(value ?? string.Empty) + "\"";
        private static string Escape(string value) => value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
    }
}
