using System;
using System.IO;
using System.Xml.Linq;

namespace CimatronCustomization.Infrastructure
{
    public static class ConfigurationSchemaMigration
    {
        public const int CurrentSchemaVersion = 2;

        public static XDocument MigrateToCurrent(XDocument source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            XDocument document = new XDocument(source);
            XElement root = document.Root ?? throw new InvalidDataException("Configuration root element is missing.");
            if (root.Name.LocalName != "cimatronCustomization") throw new InvalidDataException("Configuration root element must be cimatronCustomization.");

            int schemaVersion;
            if (!int.TryParse((string)root.Attribute("schemaVersion"), out schemaVersion) || schemaVersion <= 0)
                throw new InvalidDataException("schemaVersion must be a positive integer.");

            if (schemaVersion == 1)
            {
                if (root.Element("features") == null) root.Add(new XElement("features"));
                root.SetAttributeValue("schemaVersion", CurrentSchemaVersion);
                return document;
            }

            if (schemaVersion != CurrentSchemaVersion)
                throw new InvalidDataException("Unsupported configuration schema version: " + schemaVersion + ".");

            if (root.Element("features") == null) root.Add(new XElement("features"));
            return document;
        }
    }
}
