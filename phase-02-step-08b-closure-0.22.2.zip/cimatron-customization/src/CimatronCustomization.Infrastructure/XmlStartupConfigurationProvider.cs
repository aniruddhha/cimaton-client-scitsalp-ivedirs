using System;
using System.Globalization;
using System.IO;
using System.Xml.Linq;
using CimatronCustomization.Application;

namespace CimatronCustomization.Infrastructure
{
    public sealed class XmlStartupConfigurationProvider : IStartupConfigurationProvider
    {
        public const int SupportedSchemaVersion = ConfigurationSchemaMigration.CurrentSchemaVersion;
        private readonly string configurationPath;

        public XmlStartupConfigurationProvider(string configurationPath)
        {
            this.configurationPath = string.IsNullOrWhiteSpace(configurationPath) ? throw new ArgumentException("Configuration path is required.", nameof(configurationPath)) : configurationPath;
        }

        public StartupConfigurationSnapshot Load()
        {
            XDocument document = LoadCurrentDocument();
            XElement root = document.Root;
            int schemaVersion = ParseInt((string)root.Attribute("schemaVersion"), "schemaVersion");
            XElement logging = root.Element("logging") ?? throw new InvalidDataException("logging element is required.");
            string directory = Environment.ExpandEnvironmentVariables(Require((string)logging.Attribute("directory"), "logging directory"));
            long maximumBytes = ParseLong((string)logging.Attribute("maximumFileBytes"), "maximumFileBytes");
            int retainedCount = ParseInt((string)logging.Attribute("retainedFileCount"), "retainedFileCount");
            return new StartupConfigurationSnapshot(schemaVersion, directory, maximumBytes, retainedCount);
        }

        private XDocument LoadCurrentDocument()
        {
            if (!File.Exists(configurationPath)) throw new FileNotFoundException("Startup configuration file was not found.", configurationPath);
            return ConfigurationSchemaMigration.MigrateToCurrent(XDocument.Load(configurationPath, LoadOptions.None));
        }

        private static string Require(string value, string name) { if (string.IsNullOrWhiteSpace(value)) throw new InvalidDataException(name + " is required."); return value; }
        private static int ParseInt(string value, string name) { int result; if (!int.TryParse(Require(value, name), NumberStyles.None, CultureInfo.InvariantCulture, out result) || result <= 0) throw new InvalidDataException(name + " must be a positive integer."); return result; }
        private static long ParseLong(string value, string name) { long result; if (!long.TryParse(Require(value, name), NumberStyles.None, CultureInfo.InvariantCulture, out result) || result <= 0) throw new InvalidDataException(name + " must be a positive integer."); return result; }
    }
}
