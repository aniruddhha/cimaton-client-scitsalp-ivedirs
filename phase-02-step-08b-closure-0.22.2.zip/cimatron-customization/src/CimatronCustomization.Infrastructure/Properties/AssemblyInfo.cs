using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.Infrastructure")]
[assembly: AssemblyDescription("Cimatron Customization hexagonal architecture foundation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("4c85d8ea-a8bb-4235-8b36-f99578ef4d9e")]
[assembly: AssemblyVersion("0.19.0.0")]
[assembly: AssemblyFileVersion("0.19.0.0")]
