using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using CimatronCustomization.Application;

namespace CimatronCustomization.Infrastructure
{
    public sealed class XmlRuleParameterProvider : IRuleParameterProvider
    {
        private readonly string configurationPath;

        public XmlRuleParameterProvider(string configurationPath)
        {
            this.configurationPath = string.IsNullOrWhiteSpace(configurationPath) ? throw new ArgumentException("Configuration path is required.", nameof(configurationPath)) : configurationPath;
        }

        public RuleParameterSet LoadFor(FeatureDefinition definition)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            if (!File.Exists(configurationPath)) throw new FileNotFoundException("Rule-parameter configuration file was not found: " + configurationPath, configurationPath);

            XDocument document = ConfigurationSchemaMigration.MigrateToCurrent(XDocument.Load(configurationPath, LoadOptions.None));
            XElement root = document.Root;
            XElement features = root.Element("features") ?? throw new InvalidDataException("features element is required in configuration file '" + configurationPath + "'.");
            List<XElement> matchingFeatures = features.Elements("feature")
                .Where(element => string.Equals((string)element.Attribute("id"), definition.Id, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (matchingFeatures.Count > 1) throw new InvalidDataException("Feature '" + definition.Id + "' is configured more than once in '" + configurationPath + "'.");
            XElement configuredFeature = matchingFeatures.Count == 1 ? matchingFeatures[0] : null;
            XElement parametersElement = configuredFeature?.Element("parameters");
            List<RuleParameterValue> values = new List<RuleParameterValue>();

            foreach (RuleParameterDefinition parameter in definition.RuleParameterDefinitions)
            {
                List<XElement> matches = parametersElement == null
                    ? new List<XElement>()
                    : parametersElement.Elements("parameter")
                        .Where(element => string.Equals((string)element.Attribute("name"), parameter.Name, StringComparison.OrdinalIgnoreCase))
                        .ToList();

                if (matches.Count > 1) throw ParameterError(parameter.Name, "is configured more than once");
                if (matches.Count == 0)
                {
                    if (parameter.IsRequired) throw ParameterError(parameter.Name, "is required but missing");
                    continue;
                }

                string rawValue = (string)matches[0].Attribute("value");
                if (rawValue == null) throw ParameterError(parameter.Name, "is missing its value attribute");
                values.Add(Parse(parameter, rawValue));
            }

            return new RuleParameterSet(values);
        }

        private RuleParameterValue Parse(RuleParameterDefinition definition, string rawValue)
        {
            object value;
            switch (definition.Type)
            {
                case RuleParameterType.String:
                    if (definition.IsRequired && string.IsNullOrWhiteSpace(rawValue)) throw ParameterError(definition.Name, "cannot be blank");
                    value = rawValue;
                    break;
                case RuleParameterType.Integer:
                    int integerValue;
                    if (!int.TryParse(rawValue, NumberStyles.Integer, CultureInfo.InvariantCulture, out integerValue)) throw ParameterError(definition.Name, "must be an integer");
                    ValidateRange(definition, integerValue);
                    value = integerValue;
                    break;
                case RuleParameterType.Decimal:
                    decimal decimalValue;
                    if (!decimal.TryParse(rawValue, NumberStyles.Float, CultureInfo.InvariantCulture, out decimalValue)) throw ParameterError(definition.Name, "must be a decimal number using invariant format");
                    ValidateRange(definition, decimalValue);
                    value = decimalValue;
                    break;
                case RuleParameterType.Boolean:
                    bool booleanValue;
                    if (!bool.TryParse(rawValue, out booleanValue)) throw ParameterError(definition.Name, "must be true or false");
                    value = booleanValue;
                    break;
                case RuleParameterType.ColorCode:
                    if (!IsRgbColorCode(rawValue)) throw ParameterError(definition.Name, "must use #RRGGBB format");
                    value = rawValue;
                    break;
                default:
                    throw ParameterError(definition.Name, "uses an unsupported parameter type");
            }
            return new RuleParameterValue(definition, rawValue, value);
        }

        private void ValidateRange(RuleParameterDefinition definition, decimal value)
        {
            if (definition.Minimum.HasValue && value < definition.Minimum.Value) throw ParameterError(definition.Name, "must be >= " + definition.Minimum.Value.ToString(CultureInfo.InvariantCulture));
            if (definition.Maximum.HasValue && value > definition.Maximum.Value) throw ParameterError(definition.Name, "must be <= " + definition.Maximum.Value.ToString(CultureInfo.InvariantCulture));
        }

        private InvalidDataException ParameterError(string parameterName, string detail)
        {
            return new InvalidDataException("Rule parameter '" + parameterName + "' " + detail + " in configuration file '" + configurationPath + "'.");
        }

        private static bool IsRgbColorCode(string value)
        {
            if (string.IsNullOrEmpty(value) || value.Length != 7 || value[0] != '#') return false;
            for (int i = 1; i < value.Length; i++)
            {
                char c = value[i];
                bool hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
                if (!hex) return false;
            }
            return true;
        }
    }
}
