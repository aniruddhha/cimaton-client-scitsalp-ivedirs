using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CimatronCustomization.Application;
using ExcelDataReader;

namespace CimatronCustomization.Infrastructure
{
    public sealed class ExcelTabularDataReader : ITabularDataReader, ITabularHeaderReader
    {
        public const long DefaultMaximumFileBytes = 25L * 1024L * 1024L;
        public const int DefaultMaximumDataRows = 100000;

        private readonly long maximumFileBytes;
        private readonly int maximumDataRows;

        public ExcelTabularDataReader()
            : this(DefaultMaximumFileBytes, DefaultMaximumDataRows)
        {
        }

        public ExcelTabularDataReader(long maximumFileBytes, int maximumDataRows)
        {
            if (maximumFileBytes < 1) throw new ArgumentOutOfRangeException(nameof(maximumFileBytes));
            if (maximumDataRows < 1) throw new ArgumentOutOfRangeException(nameof(maximumDataRows));

            this.maximumFileBytes = maximumFileBytes;
            this.maximumDataRows = maximumDataRows;
        }

        public TabularHeaderDiscoveryResult DiscoverHeaders(TabularHeaderSourceDefinition source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            string validationCode;
            string validationMessage;
            string extension;
            if (!TryValidateFile(source.FilePath, out extension, out validationCode, out validationMessage))
                return TabularHeaderDiscoveryResult.Error(validationCode, validationMessage);

            try
            {
                using (FileStream stream = new FileStream(source.FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (IExcelDataReader reader = CreateReader(stream, extension))
                {
                    if (!IsCsv(extension) && !MoveToWorksheet(reader, source.WorksheetName))
                        return TabularHeaderDiscoveryResult.Error("TABULAR_WORKSHEET_NOT_FOUND", "The configured worksheet was not found in the tabular input file.");

                    string[] headers = ReadHeaderRow(reader, source.HeaderRowNumber);
                    return headers == null
                        ? TabularHeaderDiscoveryResult.Error("TABULAR_HEADER_ROW_MISSING", "The configured header row does not exist in the selected table.")
                        : TabularHeaderDiscoveryResult.Succeeded(headers);
                }
            }
            catch (IOException)
            {
                return TabularHeaderDiscoveryResult.Error("TABULAR_FILE_READ_ERROR", "The tabular input file could not be read. Verify that the file is accessible and try again.");
            }
            catch (UnauthorizedAccessException)
            {
                return TabularHeaderDiscoveryResult.Error("TABULAR_FILE_READ_ERROR", "The tabular input file could not be read because access was denied.");
            }
            catch (Exception exception) when (IsReaderFormatException(exception))
            {
                return TabularHeaderDiscoveryResult.Error("TABULAR_FILE_READ_ERROR", "The tabular input file could not be parsed as the configured file format.");
            }
        }

        public TabularReadResult Read(TabularSourceDefinition source)
        {
            return Read(source, null);
        }

        public TabularReadResult Read(TabularSourceDefinition source, IReadOnlyList<string> expectedHeaders)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            string validationCode;
            string validationMessage;
            string extension;
            if (!TryValidateFile(source.FilePath, out extension, out validationCode, out validationMessage))
                return TabularReadResult.Error(validationCode, validationMessage);

            try
            {
                using (FileStream stream = new FileStream(source.FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (IExcelDataReader reader = CreateReader(stream, extension))
                {
                    if (!IsCsv(extension) && !MoveToWorksheet(reader, source.WorksheetName))
                        return TabularReadResult.Error("TABULAR_WORKSHEET_NOT_FOUND", "The configured worksheet was not found in the tabular input file.");

                    return ReadCurrentTable(reader, source, expectedHeaders);
                }
            }
            catch (IOException)
            {
                return TabularReadResult.Error("TABULAR_FILE_READ_ERROR", "The tabular input file could not be read. Verify that the file is accessible and try again.");
            }
            catch (UnauthorizedAccessException)
            {
                return TabularReadResult.Error("TABULAR_FILE_READ_ERROR", "The tabular input file could not be read because access was denied.");
            }
            catch (Exception exception) when (IsReaderFormatException(exception))
            {
                return TabularReadResult.Error("TABULAR_FILE_READ_ERROR", "The tabular input file could not be parsed as the configured file format.");
            }
        }

        private TabularReadResult ReadCurrentTable(IExcelDataReader reader, TabularSourceDefinition source, IReadOnlyList<string> expectedHeaders)
        {
            string[] headers = null;
            int sourceRowNumber = 0;

            while (sourceRowNumber < source.HeaderRowNumber && reader.Read())
            {
                sourceRowNumber++;
                if (sourceRowNumber == source.HeaderRowNumber)
                    headers = ReadHeaders(reader);
            }

            if (headers == null)
                return TabularReadResult.Error("TABULAR_HEADER_ROW_MISSING", "The configured header row does not exist in the selected table.");

            if (expectedHeaders != null && !HeadersMatch(headers, expectedHeaders))
                return TabularReadResult.Error("TABULAR_HEADERS_CHANGED", "The tabular input headers changed between discovery and row reading. Retry after the source file is stable.");

            Dictionary<TabularColumnDefinition, int> columnIndexes = ResolveColumns(headers, source.Columns);
            TabularColumnDefinition missingColumn = source.Columns.FirstOrDefault(column => !columnIndexes.ContainsKey(column));
            if (missingColumn != null)
                return TabularReadResult.Error("TABULAR_COLUMN_NOT_FOUND", "Configured source column '" + missingColumn.SourceHeader + "' was not found in the header row.");

            List<TabularRow> rows = new List<TabularRow>();
            while (reader.Read())
            {
                sourceRowNumber++;
                if (IsMappedRowEmpty(reader, columnIndexes.Values))
                    continue;

                if (rows.Count >= maximumDataRows)
                    return TabularReadResult.Error("TABULAR_ROW_LIMIT_EXCEEDED", "The tabular input contains more data rows than the configured maximum.");

                Dictionary<string, TabularValue> values = new Dictionary<string, TabularValue>(StringComparer.OrdinalIgnoreCase);
                foreach (KeyValuePair<TabularColumnDefinition, int> mapping in columnIndexes)
                {
                    object rawValue = GetValue(reader, mapping.Value);
                    if (IsBlank(rawValue))
                    {
                        if (mapping.Key.IsRequired)
                            return TabularReadResult.Error("TABULAR_REQUIRED_VALUE_MISSING", "Required value for logical column '" + mapping.Key.LogicalName + "' is missing at source row " + sourceRowNumber.ToString(CultureInfo.InvariantCulture) + ".");
                        continue;
                    }

                    if (!TryConvertValue(rawValue, mapping.Key.ValueType, out TabularValue value))
                        return TabularReadResult.Error("TABULAR_VALUE_INVALID", "Value for logical column '" + mapping.Key.LogicalName + "' at source row " + sourceRowNumber.ToString(CultureInfo.InvariantCulture) + " cannot be converted to " + mapping.Key.ValueType + ".");

                    values.Add(mapping.Key.LogicalName, value);
                }

                rows.Add(new TabularRow(sourceRowNumber, values));
            }

            return TabularReadResult.Succeeded(new TabularTable(source, rows));
        }


        private bool TryValidateFile(
            string filePath,
            out string extension,
            out string errorCode,
            out string errorMessage)
        {
            extension = Path.GetExtension(filePath);
            errorCode = null;
            errorMessage = null;

            if (!File.Exists(filePath))
            {
                errorCode = "TABULAR_FILE_NOT_FOUND";
                errorMessage = "The configured tabular input file does not exist.";
                return false;
            }

            if (!IsSupportedExtension(extension))
            {
                errorCode = "TABULAR_UNSUPPORTED_FORMAT";
                errorMessage = "The tabular input file must use .xlsx, .xls, or .csv format.";
                return false;
            }

            FileInfo fileInfo = new FileInfo(filePath);
            if (fileInfo.Length > maximumFileBytes)
            {
                errorCode = "TABULAR_FILE_TOO_LARGE";
                errorMessage = "The tabular input file exceeds the configured maximum file size.";
                return false;
            }

            return true;
        }

        private static string[] ReadHeaderRow(IExcelDataReader reader, int headerRowNumber)
        {
            int sourceRowNumber = 0;
            while (sourceRowNumber < headerRowNumber && reader.Read())
            {
                sourceRowNumber++;
                if (sourceRowNumber == headerRowNumber)
                    return ReadHeaders(reader);
            }

            return null;
        }

        private static bool HeadersMatch(string[] actualHeaders, IReadOnlyList<string> expectedHeaders)
        {
            if (actualHeaders.Length != expectedHeaders.Count)
                return false;

            for (int index = 0; index < actualHeaders.Length; index++)
            {
                if (!string.Equals(actualHeaders[index], expectedHeaders[index] ?? string.Empty, StringComparison.Ordinal))
                    return false;
            }

            return true;
        }

        private static IExcelDataReader CreateReader(Stream stream, string extension)
        {
            if (IsCsv(extension))
            {
                return ExcelReaderFactory.CreateCsvReader(stream, new ExcelReaderConfiguration
                {
                    AnalyzeInitialCsvRows = 1,
                    LeaveOpen = false
                });
            }

            return ExcelReaderFactory.CreateReader(stream, new ExcelReaderConfiguration { LeaveOpen = false });
        }

        private static bool MoveToWorksheet(IExcelDataReader reader, string worksheetName)
        {
            do
            {
                if (string.Equals(reader.Name, worksheetName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            while (reader.NextResult());

            return false;
        }

        private static string[] ReadHeaders(IExcelDataReader reader)
        {
            string[] headers = new string[reader.FieldCount];
            for (int index = 0; index < headers.Length; index++)
                headers[index] = Convert.ToString(reader.GetValue(index), CultureInfo.InvariantCulture) ?? string.Empty;
            return headers;
        }

        private static Dictionary<TabularColumnDefinition, int> ResolveColumns(
            string[] headers,
            IEnumerable<TabularColumnDefinition> columns)
        {
            Dictionary<TabularColumnDefinition, int> indexes = new Dictionary<TabularColumnDefinition, int>();
            foreach (TabularColumnDefinition column in columns)
            {
                for (int index = 0; index < headers.Length; index++)
                {
                    if (string.Equals(headers[index], column.SourceHeader, StringComparison.OrdinalIgnoreCase))
                    {
                        indexes.Add(column, index);
                        break;
                    }
                }
            }

            return indexes;
        }

        private static bool IsMappedRowEmpty(IExcelDataReader reader, IEnumerable<int> indexes)
        {
            foreach (int index in indexes)
            {
                if (!IsBlank(GetValue(reader, index)))
                    return false;
            }
            return true;
        }

        private static object GetValue(IExcelDataReader reader, int index)
        {
            return index < reader.FieldCount ? reader.GetValue(index) : null;
        }

        private static bool TryConvertValue(object rawValue, TabularValueType valueType, out TabularValue value)
        {
            if (valueType == TabularValueType.Text)
            {
                value = TabularValue.FromText(Convert.ToString(rawValue, CultureInfo.InvariantCulture) ?? string.Empty);
                return true;
            }

            if (valueType == TabularValueType.Decimal)
            {
                if (rawValue is string text)
                {
                    if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal parsed))
                    {
                        value = TabularValue.FromDecimal(parsed);
                        return true;
                    }
                }
                else if (rawValue is byte || rawValue is sbyte || rawValue is short || rawValue is ushort || rawValue is int || rawValue is uint || rawValue is long || rawValue is ulong || rawValue is float || rawValue is double || rawValue is decimal)
                {
                    try
                    {
                        value = TabularValue.FromDecimal(Convert.ToDecimal(rawValue, CultureInfo.InvariantCulture));
                        return true;
                    }
                    catch (OverflowException)
                    {
                    }
                }
            }

            value = null;
            return false;
        }

        private static bool IsBlank(object value)
        {
            return value == null || value == DBNull.Value || (value is string text && string.IsNullOrWhiteSpace(text));
        }

        private static bool IsSupportedExtension(string extension)
        {
            return string.Equals(extension, ".xlsx", StringComparison.OrdinalIgnoreCase)
                || string.Equals(extension, ".xls", StringComparison.OrdinalIgnoreCase)
                || IsCsv(extension);
        }

        private static bool IsCsv(string extension)
        {
            return string.Equals(extension, ".csv", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsReaderFormatException(Exception exception)
        {
            return exception is InvalidDataException
                || exception is NotSupportedException
                || exception is ArgumentException
                || exception.GetType().Namespace == "ExcelDataReader.Exceptions";
        }
    }
}
