using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomizationPlugin
{
    internal sealed class CimatronCommandExecution : CimUIInfrastructure.Commands.ICimWpfCommand
    {
        private static FeatureLauncherWindow activeLauncher;

        public string GetAccelerator() { return ""; }
        public bool OnCommandDblClk() { return OnCommand(); }

        public bool OnCommand()
        {
            bool probeResult;
            if (TabularReaderRuntimeProbe.TryRunRequested(out probeResult))
                return probeResult;

            if (activeLauncher != null && !activeLauncher.IsDisposed)
            {
                activeLauncher.RestoreToFront();
                return true;
            }

            string startupCorrelationId = Guid.NewGuid().ToString("N");
            string applicationVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString(3);
            RollingJsonFileLogger logger = null;
            Stopwatch stopwatch = Stopwatch.StartNew();
            try
            {
                string configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CimatronCustomization.config.xml");
                XmlStartupConfigurationProvider configurationProvider = new XmlStartupConfigurationProvider(configPath);
                StartupConfigurationSnapshot configuration = configurationProvider.Load();
                logger = new RollingJsonFileLogger(configuration.LogDirectory, configuration.MaximumLogFileBytes, configuration.RetainedLogFileCount);
                ICimatronRuntimeInfo runtimeInfo = new CimatronRuntimeInfoAdapter();
                StartupDiagnosticsReport diagnostics = new RunStartupDiagnostics(configurationProvider, runtimeInfo, logger, applicationVersion).Execute(startupCorrelationId);

                FeatureRegistry registry = FeatureComposition.CreateRegistry();
                IViewportEntityHighlighter viewportEntityHighlighter = FeatureComposition.CreateViewportEntityHighlighter();
                IViewportEntityPicker viewportEntityPicker = FeatureComposition.CreateViewportEntityPicker(logger, applicationVersion, diagnostics.Runtime.Version);
                IRuleParameterProvider ruleParameterProvider = new XmlRuleParameterProvider(configPath);
                ExecuteRegisteredFeature featureExecutor = new ExecuteRegisteredFeature(registry, logger, applicationVersion, ruleParameterProvider);
                ExecuteFeatureChecklist checklistExecutor = new ExecuteFeatureChecklist(featureExecutor);
                FeatureAvailability[] availability = new ListAvailableFeatures(registry).Execute(diagnostics.Runtime.Session);

                FeatureLauncherWindow launcher = new FeatureLauncherWindow(
                    availability,
                    checklistExecutor,
                    diagnostics,
                    diagnostics.Runtime.Session,
                    diagnostics.Runtime.Version,
                    viewportEntityHighlighter,
                    viewportEntityPicker,
                    Process.GetCurrentProcess().MainWindowHandle);

                activeLauncher = launcher;
                launcher.FormClosed += delegate
                {
                    if (ReferenceEquals(activeLauncher, launcher))
                    {
                        activeLauncher = null;
                    }
                    launcher.Dispose();
                };
                launcher.ShowOwnedByCimatron();

                stopwatch.Stop();
                return true;
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                string loggingFailure = string.Empty;
                if (logger != null)
                {
                    try
                    {
                        logger.Log(new ApplicationLogEntry(DateTimeOffset.UtcNow, "Error", startupCorrelationId, applicationVersion, string.Empty,
                            "PluginCommand", string.Empty, "OnCommand", "Error", stopwatch.ElapsedMilliseconds, "Plugin command failed.", exception));
                    }
                    catch (Exception logException)
                    {
                        loggingFailure = Environment.NewLine + Environment.NewLine + "Logging also failed: " + logException.Message;
                    }
                }

                MessageBox.Show(
                    "Cimatron Customization failed safely." + Environment.NewLine + Environment.NewLine + exception.Message + loggingFailure,
                    "Cimatron Customization",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
        }

        public CimUIInfrastructure.Commands.CimWpfUICommandStates OnCommandUI() => new CimUIInfrastructure.Commands.CimWpfUICommandStates { UiState = CimUIInfrastructure.Commands.CommandUIState.Enabled };
        public void SetAccelerator(string accelerator) { }
    }
}
