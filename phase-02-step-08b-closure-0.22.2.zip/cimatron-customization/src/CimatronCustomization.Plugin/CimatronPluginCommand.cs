namespace CimatronCustomizationPlugin
{
    // Official Cimatron API template-compatible plugin discovery class.
    public class CimatronPluginCommand : CimUIInfrastructure.PlugIn.ICimApiCommandPlugin
    {
        public CimUIInfrastructure.PlugIn.ApiCommand AppendCommand()
        {
            CimUIInfrastructure.PlugIn.ApiCommand command = new CimUIInfrastructure.PlugIn.ApiCommand();

            command.Name = "Cimatron Customization";
            command.ToolbarName = "Cimatron Customization";
            command.MenuPath = "Cimatron Customization" + "\n" + "Cimatron Customization";
            command.Caption = "Cimatron Customization";
            command.ToolTip = "Cimatron Customization";
            command.Description = "Cimatron Customization plugin baseline";

            command.Application = CimUIInfrastructure.PlugIn.ApiApplications.Assembly |
                CimUIInfrastructure.PlugIn.ApiApplications.Part |
                CimUIInfrastructure.PlugIn.ApiApplications.Nc |
                CimUIInfrastructure.PlugIn.ApiApplications.NcPart;

            command.ExecuteCommand = new CimatronCommandExecution();

            return command;
        }
    }
}
