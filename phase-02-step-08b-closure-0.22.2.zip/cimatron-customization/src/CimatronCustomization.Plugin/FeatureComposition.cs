using System;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;
using CimatronCustomization.DesignChecks;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomizationPlugin
{
    /// <summary>
    /// Explicit composition root for registered features. No reflection or assembly scanning is used.
    /// </summary>
    internal static class FeatureComposition
    {
        internal static FeatureRegistry CreateRegistry()
        {
            IApplicationFeature readinessFeature = new ActivePartReadinessFeature(
                new CheckActivePartReadiness(new CimatronSessionAdapter()));
            IApplicationFeature ruleParameterProbe = new RuleParameterProbeFeature();

            CimatronModelInspectionAdapter modelInspectionAdapter = new CimatronModelInspectionAdapter();
            IApplicationFeature modelInspectionProbe = new ModelInspectionProbeFeature(
                modelInspectionAdapter,
                modelInspectionAdapter,
                modelInspectionAdapter,
                modelInspectionAdapter);
            IApplicationFeature u1InProcessConfirmation = new U1InProcessGeometryConfirmationFeature(
                new CimatronBodyGeometryMetricsReader());
            IApplicationFeature step08BInProcessConfirmation = new Step08BInProcessConfirmationFeature(
                new CimatronOccurrenceEntityAttributeReader(),
                new CimatronAssemblyEntityMapper(),
                new CimatronBomMaterialExporter(new ExcelTabularDataReader()));

            return new FeatureRegistry(new[]
            {
                readinessFeature,
                ruleParameterProbe,
                modelInspectionProbe,
                u1InProcessConfirmation,
                step08BInProcessConfirmation
            });
        }

        internal static IViewportEntityHighlighter CreateViewportEntityHighlighter()
        {
            return new CimatronViewportEntityHighlighter();
        }

        internal static IViewportEntityPicker CreateViewportEntityPicker(
            IApplicationLogger logger,
            string applicationVersion,
            string cimatronVersion)
        {
            return new CimatronViewportEntityPicker(logger, applicationVersion, cimatronVersion);
        }
    }
}
