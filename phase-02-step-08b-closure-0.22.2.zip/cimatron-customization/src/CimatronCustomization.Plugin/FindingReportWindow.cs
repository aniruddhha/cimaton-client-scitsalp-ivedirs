using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using CimatronCustomization.Application;

namespace CimatronCustomizationPlugin
{
    internal sealed class FindingReportWindow : Form
    {
        private readonly DataGridView grid;
        private readonly ComboBox statusFilter;
        private readonly Label summary;
        private readonly Button highlightButton;
        private readonly IViewportEntityHighlighter viewportEntityHighlighter;
        private readonly List<ResultRow> rows = new List<ResultRow>();

        internal FindingReportWindow(FeatureChecklistReport checklist, IViewportEntityHighlighter viewportEntityHighlighter)
        {
            if (checklist == null) throw new ArgumentNullException(nameof(checklist));
            this.viewportEntityHighlighter = viewportEntityHighlighter ?? throw new ArgumentNullException(nameof(viewportEntityHighlighter));

            Text = "Cimatron Customization — Result Report";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(900, 500);
            Size = new Size(1050, 620);
            Font = SystemFonts.MessageBoxFont;

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(10)
            };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(root);

            FlowLayoutPanel filterPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = false };
            filterPanel.Controls.Add(new Label { Text = "Status filter:", AutoSize = true, Margin = new Padding(3, 7, 3, 3) });
            statusFilter = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 150 };
            statusFilter.Items.AddRange(new object[] { "All", "Passed", "Succeeded", "Failed", "Warning", "Error", "NotApplicable", "Skipped", "Unsupported" });
            statusFilter.SelectedIndex = 0;
            statusFilter.SelectedIndexChanged += delegate { ApplyFilter(); };
            filterPanel.Controls.Add(statusFilter);
            filterPanel.Controls.Add(new Label { Text = "Correlation: " + checklist.CorrelationId, AutoSize = true, Margin = new Padding(20, 7, 3, 3) });
            root.Controls.Add(filterPanel, 0, 0);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoGenerateColumns = false,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Feature", HeaderText = "Feature", DataPropertyName = "Feature", Width = 180, SortMode = DataGridViewColumnSortMode.Automatic });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "RequirementId", HeaderText = "Requirement", DataPropertyName = "RequirementId", Width = 150, SortMode = DataGridViewColumnSortMode.Automatic });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Status", HeaderText = "Status", DataPropertyName = "Status", Width = 110, SortMode = DataGridViewColumnSortMode.Automatic });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Message", HeaderText = "Message", DataPropertyName = "Message", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, SortMode = DataGridViewColumnSortMode.Automatic });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Measured", HeaderText = "Measured", DataPropertyName = "Measured", Width = 110, SortMode = DataGridViewColumnSortMode.Automatic });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Limit", HeaderText = "Limit", DataPropertyName = "Limit", Width = 110, SortMode = DataGridViewColumnSortMode.Automatic });
            grid.SelectionChanged += delegate { UpdateHighlightAvailability(); };
            root.Controls.Add(grid, 0, 1);

            summary = new Label { AutoSize = true, Margin = new Padding(3, 8, 3, 8) };
            root.Controls.Add(summary, 0, 2);

            FlowLayoutPanel buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = FlowDirection.RightToLeft };
            Button close = new Button { Text = "Close", AutoSize = true };
            close.Click += delegate { Close(); };
            Button pick = new Button { Text = "Pick — Unsupported", AutoSize = true, Enabled = false };
            Button zoom = new Button { Text = "Zoom — Unsupported", AutoSize = true, Enabled = false };
            highlightButton = new Button { Text = "Highlight", AutoSize = true, Enabled = false };
            highlightButton.Click += delegate { HighlightSelectedFinding(); };
            buttons.Controls.Add(close);
            buttons.Controls.Add(pick);
            buttons.Controls.Add(zoom);
            buttons.Controls.Add(highlightButton);
            root.Controls.Add(buttons, 0, 3);

            BuildRows(checklist);
            ApplyFilter();
        }

        private void BuildRows(FeatureChecklistReport checklist)
        {
            foreach (FeatureExecutionReport report in checklist.Reports)
            {
                FeatureFindingView[] findings = report.FindingViews;
                if (findings.Length == 0)
                {
                    rows.Add(new ResultRow(report.FeatureName, string.Empty, report.StatusText, report.Message, string.Empty, string.Empty, Array.Empty<string>()));
                    continue;
                }

                foreach (FeatureFindingView finding in findings)
                {
                    rows.Add(new ResultRow(
                        report.FeatureName,
                        finding.RequirementId,
                        finding.StatusText,
                        finding.Message,
                        finding.MeasuredValueText,
                        finding.LimitText,
                        finding.EntityReferenceValues));
                }
            }
        }

        private void ApplyFilter()
        {
            string selected = statusFilter.SelectedItem == null ? "All" : statusFilter.SelectedItem.ToString();
            List<ResultRow> filtered = new List<ResultRow>();
            foreach (ResultRow row in rows)
            {
                if (selected == "All" || string.Equals(row.Status, selected, StringComparison.OrdinalIgnoreCase))
                {
                    filtered.Add(row);
                }
            }

            grid.DataSource = null;
            grid.DataSource = filtered;
            UpdateSummary();
            UpdateHighlightAvailability();
        }

        private void UpdateHighlightAvailability()
        {
            ResultRow row = GetSelectedRow();
            highlightButton.Enabled = row != null && row.EntityReferenceValues.Length > 0;
        }

        private ResultRow GetSelectedRow()
        {
            if (grid.SelectedRows.Count == 0)
            {
                return null;
            }

            return grid.SelectedRows[0].DataBoundItem as ResultRow;
        }

        private void HighlightSelectedFinding()
        {
            ResultRow row = GetSelectedRow();
            if (row == null || row.EntityReferenceValues.Length == 0)
            {
                return;
            }

            ViewportHighlightResult result = viewportEntityHighlighter.Highlight(row.EntityReferenceValues);
            if (!result.IsHighlighted)
            {
                MessageBox.Show(this, result.Message, "Highlight Unsupported", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void UpdateSummary()
        {
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (ResultRow row in rows)
            {
                int current;
                counts.TryGetValue(row.Status, out current);
                counts[row.Status] = current + 1;
            }

            summary.Text = "Summary: Total " + rows.Count +
                " | Passed " + Count(counts, "Passed") +
                " | Succeeded " + Count(counts, "Succeeded") +
                " | Failed " + Count(counts, "Failed") +
                " | Warning " + Count(counts, "Warning") +
                " | Error " + Count(counts, "Error") +
                " | NotApplicable " + Count(counts, "NotApplicable") +
                " | Skipped " + Count(counts, "Skipped") +
                " | Unsupported " + Count(counts, "Unsupported");
        }

        private static int Count(Dictionary<string, int> counts, string status)
        {
            int value;
            return counts.TryGetValue(status, out value) ? value : 0;
        }

        private sealed class ResultRow
        {
            internal ResultRow(string feature, string requirementId, string status, string message, string measured, string limit, string[] entityReferenceValues)
            {
                Feature = feature;
                RequirementId = requirementId;
                Status = status;
                Message = message;
                Measured = measured;
                Limit = limit;
                EntityReferenceValues = entityReferenceValues ?? Array.Empty<string>();
            }

            public string Feature { get; }
            public string RequirementId { get; }
            public string Status { get; }
            public string Message { get; }
            public string Measured { get; }
            public string Limit { get; }
            public string[] EntityReferenceValues { get; }
        }
    }
}
