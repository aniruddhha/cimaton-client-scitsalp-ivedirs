using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using CimatronCustomization.Application;
using CimatronCustomization.Infrastructure;

namespace CimatronCustomizationPlugin
{
    internal static class TabularReaderRuntimeProbe
    {
        private const string ProbeVersion = "0.19.0";
        private const string RequestFileName = "step06d-tabular-probe.request";
        private static readonly TimeSpan MaximumRequestAge = TimeSpan.FromMinutes(30);
        private static readonly string[] PartHeaderCandidates = { "Part" };
        private static readonly string[] SteelGradeHeaderCandidates = { "Steel Grade" };
        private static readonly string[] WeightHeaderCandidates = { "Weight" };

        internal static bool TryRunRequested(out bool commandResult)
        {
            string requestDirectory = Path.Combine(Path.GetTempPath(), "CimatronCustomization");
            string requestPath = Path.Combine(requestDirectory, RequestFileName);
            if (!File.Exists(requestPath))
            {
                commandResult = false;
                return false;
            }

            string consumingPath = requestPath + ".consuming-" + Process.GetCurrentProcess().Id.ToString(CultureInfo.InvariantCulture);
            try
            {
                if (File.Exists(consumingPath)) File.Delete(consumingPath);
                File.Move(requestPath, consumingPath);
            }
            catch (IOException exception)
            {
                commandResult = false;
                MessageBox.Show(
                    "Step 06D probe request could not be consumed." + Environment.NewLine + exception.Message,
                    "Cimatron Customization — Step 06D Probe",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return true;
            }

            try
            {
                ProbeRequest request;
                string validationError;
                if (!TryReadRequest(consumingPath, out request, out validationError))
                {
                    commandResult = false;
                    MessageBox.Show(
                        "Step 06D probe request is invalid or stale." + Environment.NewLine + validationError,
                        "Cimatron Customization — Step 06D Probe",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return true;
                }

                commandResult = Run(request.InputFile, request.EvidenceFile);
                return true;
            }
            finally
            {
                try { if (File.Exists(consumingPath)) File.Delete(consumingPath); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }

        private static bool TryReadRequest(string requestPath, out ProbeRequest request, out string error)
        {
            request = null;
            error = null;
            string version = null;
            string requestedUtc = null;
            string inputFile = null;
            string evidenceFile = null;

            foreach (string line in File.ReadAllLines(requestPath))
            {
                int separator = line.IndexOf('=');
                if (separator <= 0) continue;
                string key = line.Substring(0, separator).Trim();
                string value = line.Substring(separator + 1).Trim();
                if (string.Equals(key, "Version", StringComparison.Ordinal)) version = value;
                else if (string.Equals(key, "RequestedUtc", StringComparison.Ordinal)) requestedUtc = value;
                else if (string.Equals(key, "InputFile", StringComparison.Ordinal)) inputFile = value;
                else if (string.Equals(key, "EvidenceFile", StringComparison.Ordinal)) evidenceFile = value;
            }

            if (!string.Equals(version, ProbeVersion, StringComparison.Ordinal))
            {
                error = "Request version mismatch.";
                return false;
            }

            DateTimeOffset requested;
            if (!DateTimeOffset.TryParseExact(requestedUtc, "O", CultureInfo.InvariantCulture, DateTimeStyles.None, out requested))
            {
                error = "RequestedUtc is missing or invalid.";
                return false;
            }

            TimeSpan age = DateTimeOffset.UtcNow - requested.ToUniversalTime();
            if (age < TimeSpan.Zero || age > MaximumRequestAge)
            {
                error = "Request is outside the 30-minute validity window.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(inputFile) || !File.Exists(inputFile))
            {
                error = "Input fixture is missing.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(evidenceFile))
            {
                error = "Evidence path is missing.";
                return false;
            }

            request = new ProbeRequest(inputFile, evidenceFile);
            return true;
        }

        private sealed class ProbeRequest
        {
            internal ProbeRequest(string inputFile, string evidenceFile)
            {
                InputFile = inputFile;
                EvidenceFile = evidenceFile;
            }

            internal string InputFile { get; }
            internal string EvidenceFile { get; }
        }

        private static bool Run(string inputPath, string evidencePath)
        {
            StringBuilder evidence = new StringBuilder();
            evidence.AppendLine("STEP 06D CIMATRON IN-PROCESS MAPPED TABULAR PROBE");
            evidence.AppendLine("TimestampUtc: " + DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            evidence.AppendLine("ProcessName: " + Process.GetCurrentProcess().ProcessName);
            evidence.AppendLine("ProcessId: " + Process.GetCurrentProcess().Id.ToString(CultureInfo.InvariantCulture));
            evidence.AppendLine("AppDomainBaseDirectory: " + AppDomain.CurrentDomain.BaseDirectory);
            evidence.AppendLine("InputFile: " + Path.GetFullPath(inputPath));
            evidence.AppendLine("InputExists: " + File.Exists(inputPath));

            bool passed = false;
            Exception failure = null;
            try
            {
                ExcelTabularDataReader reader = new ExcelTabularDataReader();
                TabularMappingDefinition mapping = new TabularMappingDefinition(
                    "Step06DProbeInput",
                    new[]
                    {
                        new TabularFieldMappingDefinition("Part", PartHeaderCandidates, TabularValueType.Text, true),
                        new TabularFieldMappingDefinition("SteelGrade", SteelGradeHeaderCandidates, TabularValueType.Text, true),
                        new TabularFieldMappingDefinition("Weight", WeightHeaderCandidates, TabularValueType.Decimal, true)
                    });
                ReadMappedTabularData useCase = new ReadMappedTabularData(reader, reader, new TabularMappingEngine());
                ReadMappedTabularDataResult result = useCase.Execute(
                    new TabularHeaderSourceDefinition(inputPath, "Input", 1),
                    mapping);

                evidence.AppendLine("OrchestrationResult: " + (result.IsSuccess ? "PASS" : "ERROR"));
                evidence.AppendLine("OrchestrationStage: " + result.Stage);
                evidence.AppendLine("OrchestrationErrorCode: " + (result.ErrorCode ?? string.Empty));
                evidence.AppendLine("OrchestrationErrorMessage: " + (result.ErrorMessage ?? string.Empty));

                if (result.IsSuccess)
                {
                    evidence.AppendLine("RowCount: " + result.Table.Rows.Count.ToString(CultureInfo.InvariantCulture));
                    if (result.Table.Rows.Count == 1)
                    {
                        TabularRow row = result.Table.Rows[0];
                        string part = row.GetRequired("Part").TextValue;
                        string steelGrade = row.GetRequired("SteelGrade").TextValue;
                        decimal? weight = row.GetRequired("Weight").DecimalValue;
                        evidence.AppendLine("KnownAnswerPart: " + part);
                        evidence.AppendLine("KnownAnswerSteelGrade: " + steelGrade);
                        evidence.AppendLine("KnownAnswerWeight: " + (weight.HasValue ? weight.Value.ToString(CultureInfo.InvariantCulture) : "<null>"));

                        passed = string.Equals(part, "Block_A", StringComparison.Ordinal)
                            && string.Equals(steelGrade, "1.2344", StringComparison.Ordinal)
                            && weight == 12.5m;
                    }
                }
            }
            catch (Exception exception)
            {
                failure = exception;
                evidence.AppendLine("ExceptionType: " + exception.GetType().FullName);
                evidence.AppendLine("ExceptionMessage: " + exception.Message);
                evidence.AppendLine("ExceptionHResult: 0x" + exception.HResult.ToString("X8", CultureInfo.InvariantCulture));
            }

            AppendAssemblyEvidence(evidence, "CimatronCustomizationPlugin");
            AppendAssemblyEvidence(evidence, "CimatronCustomization.Infrastructure");
            AppendAssemblyEvidence(evidence, "ExcelDataReader");
            AppendAssemblyEvidence(evidence, "System.ValueTuple");
            evidence.AppendLine("ProbeResult: " + (passed ? "PASS" : "FAIL"));

            try
            {
                string directory = Path.GetDirectoryName(evidencePath);
                if (!string.IsNullOrWhiteSpace(directory)) Directory.CreateDirectory(directory);
                File.WriteAllText(evidencePath, evidence.ToString(), new UTF8Encoding(false));
            }
            catch (Exception evidenceException)
            {
                string failureSuffix = failure == null ? string.Empty : Environment.NewLine + failure.Message;
                MessageBox.Show(
                    "Step 06D mapped tabular probe could not write evidence." + Environment.NewLine + evidenceException.Message + failureSuffix,
                    "Cimatron Customization — Step 06D Probe",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }

            MessageBox.Show(
                "Step 06D in-process mapped tabular probe: " + (passed ? "PASS" : "FAIL") + Environment.NewLine + Environment.NewLine +
                "Evidence: " + evidencePath,
                "Cimatron Customization — Step 06D Probe",
                MessageBoxButtons.OK,
                passed ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            return passed;
        }

        private static void AppendAssemblyEvidence(StringBuilder evidence, string simpleName)
        {
            Assembly assembly = AppDomain.CurrentDomain.GetAssemblies()
                .FirstOrDefault(candidate => string.Equals(candidate.GetName().Name, simpleName, StringComparison.OrdinalIgnoreCase));

            if (assembly == null)
            {
                evidence.AppendLine("Assembly[" + simpleName + "]: NOT_LOADED");
                return;
            }

            AssemblyName name = assembly.GetName();
            evidence.AppendLine("Assembly[" + simpleName + "].Version: " + name.Version);
            evidence.AppendLine("Assembly[" + simpleName + "].Location: " + SafeAssemblyLocation(assembly));
        }

        private static string SafeAssemblyLocation(Assembly assembly)
        {
            try
            {
                return assembly.Location;
            }
            catch (NotSupportedException)
            {
                return "UNAVAILABLE";
            }
        }
    }
}
