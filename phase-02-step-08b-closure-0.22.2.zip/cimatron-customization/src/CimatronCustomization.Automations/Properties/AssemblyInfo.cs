using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CimatronCustomization.Automations")]
[assembly: AssemblyDescription("Cimatron Customization hexagonal architecture foundation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CimatronCustomization")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("951b4487-5a2f-417b-923b-09c31850414f")]
[assembly: AssemblyVersion("0.15.4.0")]
[assembly: AssemblyFileVersion("0.15.4.0")]
