# CR-04 UAT — Step 03: Read-Only Diagnostic Implementation Plan

**Scope:** Approved Step 03 is *planning only*. No C# diagnostic code, UI, comparator, tests, API adapter, project references or model/workbook changes are authorized by this step.  
**Baseline:** cumulative UAT Step 02, runtime/product version 0.40.1.  
**Authorities:** `AGENTS.md`; approved UAT baseline v1.0 supplied externally; Step 01 impact assessment; Step 02 data-contract verification.

## 1. Objective and outstanding gates

Propose one developer-only, bounded, one-shot in-process Cimatron 2026 diagnostic that gathers trustworthy evidence for **(A)** BOM Category to exact eligible part occurrence mapping and **(B)** independent determination of which untyped components require Part Type. This is a proposal, not confirmation those mappings are possible. Existing reader `CimatronBomMaterialTableReader` already obtains a temporary `cmNoFiltering` BOM CSV; currently it consumes `Standard Number`/`Material` only. The expected export headers in `CimatronBomMaterialExporter` include `Category` and `Sub Category` but the actual values, semantics and join keys remain unproven.

## 2. Exact proposed diagnostic-code file boundary — NOT YET APPROVED

**New production-project developer-diagnostic files only, contingent on separate patch approval:**

- `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatCategoryEligibilityDiagnostic.cs` — developer-only one-shot read-only evidence orchestrator; no production comparison modifications.
- `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatCategoryEligibilityDiagnosticRequest.cs` — one-shot opt-in request, expiry/consumption and bounded output coordination using the existing request conventions.
- `tools/Request-Cr04UatCategoryEligibilityDiagnostic.ps1` — developer-only trigger and exact workstation usage, modeled on existing approved request scripts.

**Existing source files proposed for narrowly scoped modification, each needing explicit approval:**

- `src/CimatronCustomization.Plugin/FeatureComposition.cs` (or whichever *actual* command dispatch point static inspection confirms) — add request gate to run diagnostic only when explicitly requested; preserve other dispatch paths.
- `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj` (actual project filename must be confirmed at patch time) — include new source files if the existing project uses explicit compile items.
- `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs` — only if required by guard contracts or new diagnostic source protection; avoid widening architecture exceptions.
- Relevant `tests/**` project(s) and test file(s) determined after exact production seam review — request parsing, read-only invariants, malformed/duplicate BOM evidence, unavailable/ambiguous join, and safe error handling. A separate exact list must be furnished with implementation approval request, **not assumed authorized here**.

**Governance upon any separately approved implementation:** `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, `CHECKSUMS.sha256`; version bump only with actual software changes. Existing `CimatronBomMaterialTableReader`, `BomMaterialRow`, `VerifySteelGradeAgainstDesignOrder`, `FindingReportWindow`, `ResultReportCsvExporter` and comparison tests remain untouched by this diagnostic plan. If reliable evidence requires changes in these files, STOP and seek a revised approval.

## 3. Required diagnostic evidence contract

Output a single bounded UTF-8 developer evidence file external to project ZIP, with diagnostic timestamp, Cimatron build, active assembly identity redacted as needed, source and operation name, read-only confirmation, stage outcomes and error details. Provide separately labeled sections:

1. **BOM schema/rows:** observed headers and normalized/raw `Standard Number`, `Sub Category`, `Category`, `Material`, `Qty.` plus row number; if a field is missing, explicitly record missing, not an invented value. Check actual 2026 exported schema before parsing.
2. **Eligible occurrence evidence:** existing traversal's occurrence/path and ModelPid where available, model type, suppression and synthetic-root skips, native Part Type and Part Material, and candidate *independent* classifier fields (Details/BOM), each labeled by proven reader/source or `UNAVAILABLE`.
3. **Join candidates:** show row-to-occurrence cardinality for repeated titles/nested parts and observed identity keys. Distinguish `UNAMBIGUOUS`, `AMBIGUOUS`, `MISSING`, `API_READ_ERROR`; no automatic title-only association merely because strings match. Avoid changing traversal semantics.
4. **Missing Part Type counterexamples:** candidate components requiring type and known irrelevant components both with blank type, with independent observed evidence; if eligibility cannot be proven mark `UNRESOLVED`, not warning-ready.
5. **Technical summary:** counts, redaction notice, zero model-write operations, categories with unknown mapping, rule uncertainty and recommended customer decision if blocked.

Export raw evidence only on deliberate diagnostic execution, never when ordinary validation or UI opens. Do not ship private client/model/DO data in ZIP; user supplies appropriately redacted extract for assessment.

## 4. Read-only execution and failure controls

- Run solely on a controlled **copy** of the Cimatron model on user workstation, with the supported Cimatron 2026 environment; no save, property setters, edits, workbook changes, or silent normal validation export.
- One-shot request with bounded TTL, safe file location, output cap/row limit and explicit diagnostic identity; clean temp BOM files and COM resources consistent with existing code.
- Use only SDK/Interop types and methods verified from checked source or actual installed Interop. `GetBomManager` and `IBOM.Export` route are verified as *repository references*, not newly validated live in this step. Do not invent occurrence-ID API or Details getter.
- Catch/report COM/API problems as diagnostic errors, never material-comparison Fail. No exceptions swallowed; do not assume ambiguous association is acceptable.
- Normal command path, production comparison, CSV exporter and part/material semantics must remain behaviorally unchanged.

## 5. Test-first acceptance criteria for a future patch

Request parser: rejects malformed, expired, replayed or unapproved requests. Diagnostic: no implicit execution; deterministic separation of BOM, occurrence and join tables; null/whitespace values preserved; no guessed Category on duplicates; ambiguous join reported and not silently resolved; known relevant/non-applicable missing-Part-Type examples distinguished only by independently proven rule; read-only operation tests; API errors never converted into business status. Existing regression suites unchanged in meaning.

**User-run gate:** Visual Studio Release x64 build, Roslyn/.NET analyzers, architecture/domain/application/integration/infrastructure tests, coverage/local gate, SonarQube Community Build when applicable, then one controlled Cimatron live run using the request helper. User checks assembly is unmodified and provides sanitized diagnostic output + relevant quality gate result. AI agent does **not** run those workstation gates.

## 6. Stop/go criteria and next approval boundary

**GO for implementing a limited diagnostic:** user separately approves exact source/tests/trigger-file list and runtime plan. **GO for UAT Category UI** only when a deterministic per-occurrence BOM Category mapping is demonstrated or user approves an explicitly bounded alternative. **GO for Missing Part Type warning** only when independent type-obligation rule has positive/negative real evidence and user approval. Otherwise keep corresponding UAT features BLOCKED and surface precise decision requests.

**Current outcome:** plan delivered; no diagnostic executable, production change, build/test, new Cimatron data, client acceptance or verified mapping is claimed.
