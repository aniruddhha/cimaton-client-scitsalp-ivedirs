# Implementation Spec — License Gate (EP-LICENSE-01)

## Goal
Add a license gate to the Cimatron Customization plugin. Time-bound restriction is controlled by a signed `timeBound` flag in `license.dat` (default `false`).

## Engineering Principle EP-LICENSE-01
1. Every plugin entry point (plugin load and each command) must pass the license gate before any work.
2. Every ZIP ships a signed `license.dat`. Its contents are trusted only if the signature is valid.
3. `timeBound` is set by the developer when building the ZIP. Default: `false`.
   - `false` → plugin usable without time restriction; no network check.
   - `true` → plugin usable only until the signed expiry, checked against trusted network time.
4. When `timeBound` is `true`, current time comes only from trusted network time (HTTPS `Date` header, TLS-validated). The local system clock is never used for license decisions.
5. Expired, offline, clock-incorrect and invalid-license outcomes show a popup and block the command.
6. No offline grace period. No bypass flags, debug switches or config overrides in release builds. `timeBound` exists only inside the signed license file.

## 1. License file (provided — do not implement)
- `license.dat` is created by the developer's `license_stamp.py` tool. It is not part of the plugin and is not shipped in the ZIP.
- Format: `base64(payload) + "." + base64(signature)`, ASCII, single line.
- Payload (UTF-8 JSON, no whitespace):
  ```json
  {"product":"CimatronCustomization","customer":"...","buildId":"...","timeBound":false,"expiryUtc":null}
  ```
  When time-bound: `"timeBound":true,"expiryUtc":"2026-12-31T18:29:59Z"` (ISO-8601 UTC).
- Signature: RSA-2048, SHA-256, PKCS#1 v1.5 over the exact payload bytes.
- Every ZIP must include `license.dat` in the plugin install folder and list it in the SHA-256 manifest.

## 2. License verification
- Embed the RSA public key (PEM, SubjectPublicKeyInfo) as a constant in the plugin assembly.
- During development, use the supplied `TEST-public-key.pem`. Production key replacement is done by the developer.
- Read `license.dat` from the plugin install folder.
- Split on `.`, base64-decode both parts and verify the signature against the decoded payload bytes.
- Parse the JSON and check:
  - `product` == `"CimatronCustomization"`
  - if `timeBound` is `true`, then `expiryUtc` is a parsable UTC instant
- Missing file, bad format, bad signature or a failed check → `LicenseInvalid`.

## 3. Trusted time source (only when `timeBound` = true)
- Sources (hardcoded constants, not configurable):
  - `https://www.google.com/generate_204`
  - `https://www.cloudflare.com/cdn-cgi/trace`
  - `https://www.microsoft.com/`
- Query all sources in parallel:
  - HttpClient GET with `HttpCompletionOption.ResponseHeadersRead`
  - header `Cache-Control: no-cache`
  - timeout 5 s each
  - system default proxy with default credentials
- If .NET Framework: set `ServicePointManager.SecurityProtocol` to include Tls12 (and Tls13 if available).
- Never disable or override TLS certificate validation.
- Read the `Date` header (UTC) from each successful response. Accept the result if ≥1 source succeeds; if several succeed, use the median.
- If all sources fail:
  - any failure caused by certificate time validity (`NotTimeValid` in chain status) → `ClockIncorrect`
  - otherwise → `Offline`

## 4. Time caching (only when `timeBound` = true)
- Keep in memory only: `trustedUtc` plus a `Stopwatch` started at fetch time.
- `currentTrustedUtc = trustedUtc + stopwatch.Elapsed`.
- Refetch when the cache is older than 60 minutes or absent. Never persist to disk.

## 5. Gate
- Single class `LicenseGate` with method `Check()` returning one of `Valid | Expired | Offline | ClockIncorrect | LicenseInvalid`.
- Order:
  1. Verify `license.dat` → `LicenseInvalid` on failure.
  2. If `timeBound` = false → `Valid`. No network call.
  3. Get trusted time → `Offline` / `ClockIncorrect` on failure.
  4. If `currentTrustedUtc >= expiryUtc` → `Expired`, else `Valid`.
- Call `Check()` at plugin load and at the start of every command.
- Run network calls off the UI thread and show a wait cursor.
- On any result other than `Valid`, show a modal popup and abort the command:

| Result | Message |
|---|---|
| Expired | Your Cimatron Customization subscription has expired. Please contact flux10x AI Systems to renew. |
| Offline | You are offline. Please connect to the internet to use the Cimatron Customization plugin. |
| ClockIncorrect | Your system date/time is incorrect. Please correct it and try again. |
| LicenseInvalid | License file is missing or invalid. Please contact flux10x AI Systems. |

## 6. Tests
- Unit tests:
  - signature valid / tampered / missing file
  - `timeBound` false → `Valid` with no time-source call
  - `timeBound` true without `expiryUtc` → `LicenseInvalid`
  - expiry before / after current time
  - median selection
  - Stopwatch advance
- Test fixtures: supplied `license.dat` (`timeBound` false) and `license-timebound.dat` (`timeBound` true, expiry 2026-12-31 23:59:59 IST), signed with the test key.
- Inject the time source through an interface for tests; the release build contains only the real implementation.

## 7. Out of scope
- Building a license stamping tool.
- Offline grace period, local-clock fallback, own server.
- Any unsigned or config-file `timeBound` flag.
