# CR-04 UAT — Step 07 Runtime Evidence (v0.40.4)

Prepared 2026-10-09T12:40:09+05:30. Approved scope: diagnostic-only runtime inspection.

## Verified installed Cimatron 2026 Interop

Reflection `api-capability-reflection-20261009-123500.txt`: `IAssemblyModel.GetBomManager()`, `IBOM.Export(...)`, `IAssInstance.get_SubInstances(1,0)`, `IAssInstance.GetAllEntities()`, `IAttributeSink.GetAttributes()`, and `IAttribute.Name/Type/Value`. Reflection does not establish runtime support on every instance/entity.

## Implementation

- `Cr04UatBomIdentityEvidence`: records exported header and explicitly unverified occurrence join; no invented template, BOM row API or Title/Standard Number join.
- `Cr04UatPartClassificationEvidence`: bounded traversal (160 instances, 16 levels, 4 entities per instance, 24 attributes per inspected entity) through verified Interop; records attribute names/types/value previews or unsupported/error states. No model setters/saves or classification decision. Preview values are limited to 160 characters per field.
- Both append evidence only to existing one-shot developer report; production comparator/normal UI/CSV untouched. Existing diagnostic checks `document.IsModified()` before/after; an unchanged dirty flag alone is not proof of absence of all side effects.
- Independent eligibility rule still requires approved positive and negative labeled test cases; no warning is emitted.

## Known constraints

The reflection `IBOM` interface exposes only Export. There is no verified BOM row identity and no verified custom-template identifier configuration. No live evidence yet proves any attribute is Cimatron's native Details classifier. Enumeration may report missing casts, unsupported interface implementation or COM errors without treating them as business-rule fails.

## User acceptance

1. Run `tools/Invoke-QualityGate.ps1` on Windows after replacing project, confirm zero warnings/errors and all gates pass.
2. Fully close/restart Cimatron 2026, open test-copy Assembly, run `tools/Request-Cr04UatCategoryEligibilityDiagnostic.ps1`, click Cimatron Customization once.
3. Upload generated report; inspect `BOM_IDENTITY_PROBE` and `INDEPENDENT_ATTRIBUTE_PROBE` sections. Provide independently known positive/negative Details/classification examples; attribute names alone are not validation.
4. Confirm assembly is not newly modified/saved. SonarQube is a separate server-side gate.

Status: AWAITING WINDOWS QUALITY GATE / LIVE EVIDENCE; BOTH UAT TECHNICAL GATES UNRESOLVED.
