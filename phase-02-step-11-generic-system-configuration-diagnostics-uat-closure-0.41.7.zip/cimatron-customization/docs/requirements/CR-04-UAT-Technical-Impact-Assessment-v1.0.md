# CR-04 UAT — Step 1 Technical Impact Assessment v1.0

**Status:** Documentation-only technical verification; implementation NOT authorized by this record.  
**Baseline:** cumulative 0.40.1 after client UAT handover 2026-10-08.  
**UAT authority:** `CR-04-UAT-Agreed-Baseline-v1.0` (user supplied 2026-10-09; separate from authoritative source ZIP).  
**Verification class:** repository static source review only; **no live Cimatron runtime/API validation** in this step.

## Approved contract

Main comparison table must display exactly: **Name | Material as per model | Status | DO Name | DO Material | Category**. Name is component name, material is native Part Material, Status Pass/Fail only, DO Material is matched Design Order Remark, Category is from Cimatron BOM. The permanent Part Type filter excludes empty/null/whitespace values; Category filter is an additional user control. Required components missing Part Type belong in a separate warning section, not the Pass/Fail table. Hide/disable UI CSV export without deleting export infrastructure or tests. Do not combine Cavity Insert/Core Insert/Moving Core/Angular Lifter into generic Insert. Do not modify the existing comparator.

## Verified source inventory / existing mechanism

1. `src/CimatronCustomization.CimatronIntegration/CimatronPartDocumentPropertyReader.cs`: reads native `TMPL::Part_Type` and `TMPL::Material`; these are different fields.
2. `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrder.cs`: resolves Part Type through `PartTypeCategoryResolver.TryResolve`, reports `CAD_PART_TYPE_MISSING` for normalized blank Part Type and `CAD_PART_TYPE_UNSUPPORTED` for unsupported values. Existing component contexts include raw Part Type and Part Material; Design Order records expose `RawRemark` and normalized `SteelGrade`.
3. `src/CimatronCustomization.Application/DesignOrderFormCategoryRecord.cs` and `DesignOrderFormCategoryDefinition.cs`: Design Order category and Remark data are represented independently; the presentation projection must verify how the matched record's display name and raw/normalized Remark are supplied, without repeating lookup or changing equality rules.
4. `src/CimatronCustomization.CimatronIntegration/CimatronBomMaterialExporter.cs`: expected BOM headers include `Sub Category` and `Category`, proving an existing *expected CSV header contract*, **not** verifying Category values, their semantics, or occurrence association for the UAT UI.
5. `src/CimatronCustomization.CimatronIntegration/CimatronBomMaterialTableReader.cs`: current `IBOM.Export(cmNoFiltering)` path requests only `Standard Number` and `Material` in `TabularSourceDefinition` and instantiates `BomMaterialRow(ModelTitle, Material, SourceRowNumber)`. `BomMaterialRow` currently contains no Category, occurrence path, or instance ID. Reading Category and associating it with the right occurrence require design and live verification; duplicate Standard Number rows and blank/ambiguous categories must be handled explicitly.
6. `src/CimatronCustomization.Plugin/FindingReportWindow.cs`: existing main columns are Feature/Requirement/Status/Message/Measured/Limit; status dropdown permits diagnostic statuses, `BuildRows` includes global findings; `Export Results` button calls `ExportResults`; code builds CSV via `ResultReportCsvExporter`. Current UI therefore does not implement the approved comparison-only presentation. Preserve diagnostic visibility outside normal Pass/Fail main rows.
7. `src/CimatronCustomization.Plugin/ResultReportCsvExporter.cs`: existing 13-column CSV schema includes PartType and MoldPartMaterial; preserve export code and associated tests, do not trigger it on window display.
8. `src/CimatronCustomization.Application/FeatureFindingView.cs` carries `FeatureFindingComponentContextView` context including PartType and PartMaterial. It does not by itself prove an exact DO display-row field or BOM Category attachment.

## Key unresolved technical questions (blocking their dependent implementation)

- **BOM Category**: verify on Cimatron 2026 target machine that `Category` actually exports usable values for reference assembly and determine unambiguous association to each traversed component *occurrence*, including duplicates, nested parts and empty values. Do not silently fill from Details or inferred categories.
- **Missing-required-Part-Type classification**: current missing-Part-Type finding does **not** establish an independent positive rule distinguishing components that require the property from components that do not. Investigate verified Details/BOM evidence and APIs against real cases. Do not infer eligibility from names or material. If no reliable rule can be demonstrated, present a decision/blocker before this feature ships.
- **DO projection semantics**: verify precise matched DO Name / original Remark availability and whether current findings carry enough relation to the selected DO row. Reconstructing from display messages is unsafe.
- **Other findings / diagnostics**: ensure that non-Pass/Fail results are not mislabeled or silently lost, while retaining exact main-table six-column contract.
- **Part Type normalization**: leverage existing normalization semantics and explicitly test whitespace/null; populated but unmatched/unsupported values must not be represented as successful DO matches.

## Proposed subsequent implementation slices (each needs separate explicit approval)

A. Data-contract/adapter proof: determine BOM Category evidence and matching identity; design read-only typed contract with tests, and reliable missing-required-Part-Type evidence. If runtime verification is needed, prepare narrowly scoped evidence procedure for user execution under AGENTS.md.
B. Display-only projection and six-column comparison table; preserve existing evaluator; define treatment of unmapped/error/diagnostic findings and consistent viewport selection.
C. Immutable Part Type eligibility and Category UI filter; tests for all combinations and duplicates.
D. Separate Missing Part Type warnings only after positive classification evidence is approved.
E. Disable/hide Export Results control while retaining `ExportResults`, exporter, existing CSV tests; verify no implicit export on display.
F. Regression/quality validation by user on Windows/Cimatron; governed version bump and cumulative artifact packaging for implementation slices.

## Prospective file touchpoints (NOT approved for editing yet)

- `src/CimatronCustomization.Plugin/FindingReportWindow.cs` — UI column layout, filters, warnings, hide export control.
- `src/CimatronCustomization.Application/FeatureFindingView.cs` and potentially new typed presentation projection files — component/DO projection, if proven necessary.
- `src/CimatronCustomization.CimatronIntegration/CimatronBomMaterialTableReader.cs` + `src/CimatronCustomization.Application/BomMaterialRow.cs` and related interface/result types — BOM Category contract, if occurrence mapping verified.
- Targeted Plugin, Application and CimatronIntegration tests, existing architecture guard source hashes and `*.csproj` compile lists — required for approved additions.
- Product version metadata and governance (VERSION/CHANGELOG/HISTORY/timesheet/checksums) — only with actual implementation approval.

## Evidence, risk and validation protocol

**Evidence here:** static inspection of 0.40.1 files listed above. **Not evidenced:** actual BOM Category values/association or independently identifying required Part Type when blank. No SDK names/signatures invented. No .NET build, analyzers, tests, SonarQube, live Cimatron run, or customer acceptance performed by agent. User must run applicable workstation gates and confirm assembly remains unmodified. Any necessary test dataset or live diagnostic must be separately approved, avoid client input inclusion in ZIP, preserve exact traversal/highlight behavior and protect original model.

## Governance outcome

Step 1 assessment completed as documentation-only. Product/runtime remains **0.40.1**. No `src/**`, `tests/**`, project, config, workbook, or model modifications. **Next user decision:** approve a narrowly scoped Step 2 evidence/data-contract design, or supply verified BOM/category and required-Part-Type identification evidence.
