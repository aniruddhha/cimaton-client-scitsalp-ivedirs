# CR-04 UAT — Step 06: BOM Association and Independent Eligibility Investigation

**Date:** 2026-10-09 (date only; exact agent time not captured)  
**Source baseline:** Full cumulative project v0.40.3  
**Authority:** `AGENTS.md` and approved client UAT baseline v1.0  
**Scope:** Technical investigation and proposed exact patch plan only; **no source/test changes or build execution**.

## User-provided workstation evidence reviewed

- `quality-gate-20261009-120014.txt` and `quality-gate-20261009-121308.txt`: user-run Windows Release x64 gates passed with tests and coverage. SonarQube is separate and not evidenced here.
- `cr04-uat-category-eligibility-diagnostic-20261009-121256.txt` and its Cimatron dialog screenshot: live v0.40.3 diagnostic captured evidence. This resolves the earlier missing-report issue for the latest run.
- `NATIVE_PROPERTIES` reports native `TMPL::Part_Type` and `TMPL::Material` by model PID, e.g. Cavity block `Cavity / P-20-2311`, Core block `Core / P-20-2311`, core fix insert-01 `Core Insert / P-20-2311`; Lifter-01 has blank Part Type and P20 material. Main Core insert is suppressed and has `Cavity / blank material` in this test model.
- The native reader reports per-model document properties, **not per-occurrence overrides**; repeating a model PID repeats its document values. Errors and blank values are separate states.
- BOM CSV confirms a `Category` header. `Lifter-01` has `Mold Components`; `core fix insert-01` has a blank Category. The BOM rows expose Title, Standard Number, Qty, Material, Category and other display fields but **no proven occurrence path or ModelPid key** in captured evidence.
- Both `BOM_CATEGORY_OCCURRENCE_JOIN=UNVERIFIED` and `MISSING_PART_TYPE_OBLIGATION=UNRESOLVED` remain explicit results of the diagnostic. `Details` was not captured.
- `DocumentModifiedBefore=True` and `DocumentModifiedAfter=True` do not independently establish the prior save state or prove absence of all side effects; the diagnostic performs no requested model writes/save operations.

## Code paths and limitations

1. `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatCategoryEligibilityDiagnostic.cs` exports BOM (`IBOM.Export`) and collects assembly occurrences through `CimatronAssemblyBodyAttributeReader`. Its output deliberately makes **no automatic association**.
2. `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatOccurrencePropertyEvidence.cs` uses `CimatronPartDocumentPropertyReader` and caches by ModelPid. It does not read Details or classify missing Part Type obligation.
3. `src/CimatronCustomization.CimatronIntegration/CimatronBomMaterialExporter.cs` declares expected BOM columns including Sub Category and Category, but an expected header is not a proven occurrence identity contract.
4. The approved normal results may display **only** populated-Part-Type eligible entries. Any missing Part Type warning must be founded on an independent approved classification rule, not material/name guesses; the existing steel-grade comparator and suppression rules remain untouched.

## Open technical gates

**G1 — Category association:** Determine whether Cimatron SDK/installed 2026 Interop exposes a BOM row-to-occurrence identifier or a verified model-level mapping with reliable handling of Qty, repeated models, nested occurrence paths, conflicting attributes and blanks. Title/Standard Number equality alone is **insufficient**. If an unambiguous join is not possible, produce an explicit blocker/decision request; do not populate the Category display from guessed matches.

**G2 — Missing required Part Type:** Capture and verify authoritative Details/BOM classification where available, independent of Part Type, with at least one positive and negative example confirmed against client rules. Do not classify from a blank Part Type, Part Material, name token, or broad Category. An unsupported rule remains a blocker, not a warning.

**G3 — Safety:** All probing remains developer-only, bounded, read-only and exercised on a test copy. API failure must be recorded as an error, not a comparison Fail. Protect existing output and reporting behavior.

## Exact prospective file-change plan — requires separate approval before coding

| Path | Action | Reason |
|---|---|---|
| `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatCategoryEligibilityDiagnostic.cs` | Modify | Invoke additional bounded, explicitly read-only evidence collectors, preserving separate raw evidence sets. |
| `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatOccurrencePropertyEvidence.cs` | Modify only if necessary | Append independent classifier source/status if a verified reader can be reused safely; otherwise preserve unchanged. |
| `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatBomIdentityEvidence.cs` | New, proposed | Probe only verified SDK/Interop identity methods and report candidate identity/ambiguity; no production join. |
| `src/CimatronCustomization.Plugin/Diagnostics/Cr04UatPartClassificationEvidence.cs` | New, proposed | Capture independently verified Details/classification fields and source status without deciding required-Part-Type obligation. |
| `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj` | Modify | Explicitly include new diagnostic classes in C# project. |
| `tests/CimatronCustomization.ArchitectureTests/ArchitectureBoundaryTests.cs` | Modify | Enforce diagnostic-only/read-only boundary and no production comparator or UI changes. |
| `docs/requirements/CR-04-UAT-Step-06-Association-Eligibility-Investigation-v1.0.md`, `IMPLEMENTATION-HISTORY.md`, `CHANGELOG.md`, `VERSION.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, `CHECKSUMS.sha256` | Update | Audit evidence, approvals, test results and cumulative release metadata. |

**Pre-patch verification checkpoint:** confirm actual signatures for candidate BOM row identity and Details/classification via official Cimatron 2026 SDK / installed interop. If unverified, stop and present revised scope instead of implementing speculative COM calls. These are prospective files, not authorization to invent APIs. TDD and regression cases must cover duplicates, nested occurrences, suppression, blank Category, absent independent classification, API errors, no mutation, and no effects on existing material evaluator/CSV exporter.

## Next workstation acceptance procedure (only after patch approval and implementation)

User executes Release x64 quality gate, separate SonarQube gate if configured, and one controlled diagnostic with test-copy assembly; provide the entire redacted report plus known positive/negative classification cases. Mark Category mapping/eligibility verified only if evidence demonstrates deterministic identity and an approved independent predicate.

**Current status:** Step 06 investigation complete; production UAT UI implementation remains blocked on G1/G2. Product version is still 0.40.3. No new C# patch has been applied.
