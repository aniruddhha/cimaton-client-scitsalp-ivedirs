# CR-04 UAT — Step 02: BOM Category and Missing Part Type Data-Contract Verification

**Status:** Repository-level investigation and read-only workstation evidence plan complete; **live Cimatron evidence is outstanding**.  
**Baseline:** Latest cumulative CR-04 UAT Step 1 project, product `0.40.1`.  
**Authority:** Approved CR-04 UAT agreed baseline v1.0 (2026-10-09), plus repository `AGENTS.md`.  
**Change class:** Documentation/governance only; no adapter, UI, evaluator, tests, model, or client workbook changes.

## 1. Source evidence and verified limits

| Subject | Static source evidence | Verification status |
|---|---|---|
| Cimatron BOM export | `CimatronBomMaterialTableReader.ReadMaterialTable` accesses active Assembly using `IModelContainer`/`IAssemblyModel`, `GetBomManager()`, then `IBOM.Export(...cmCSV,...cmNoFiltering,...)` to a temporary CSV; temp folder is cleaned | Existing code route verified, *not* retested live in this step |
| Category column | `CimatronBomMaterialExporter.ExpectedBomHeaders` declares `Sub Category` and `Category` alongside `Standard Number` and `Material` | Expected schema only; actual target-version values/semantics unverified |
| Current BOM table projection | `CimatronBomMaterialTableReader` maps `Standard Number` to `ModelTitle` and `Material` to `Material`, no `Category` mapping | Verified source restriction |
| Row identity | `BomMaterialRow` stores `ModelTitle`, `Material`, `SourceRowNumber`, but no ModelPid, occurrence path or instance key | No proved one-to-one association with model traversal occurrences |
| Native Part properties | `CimatronPartDocumentPropertyReader` reads exact `TMPL::Part_Type` and `TMPL::Material` through PDM attribute retrieval; does not read Details | Native Part Type / Part Material reader implementation verified; Details as classification proof unverified |
| Eligibility | `VerifySteelGradeAgainstDesignOrder.ExecuteForm` explicitly excludes suppressed, configured exclusions, non-`cmPart`, and synthetic `Root.elt`; then reads native Part properties and can issue missing-Part-Type findings | Filtering/exclusion flow verified, but no independently evidenced “Part Type required” predicate for every untyped part |
| Source of main result Category | Approved UAT states *BOM Category*, not DO category or `Details` | Cannot substitute internal DO category or guessed type |

## 2. Required evidence: BOM Category per occurrence

Obtain controlled, non-client-shipped evidence on supported Cimatron 2026 workstation with a **copy** of the reference assembly active. The user/developer (not the AI agent) performs read-only inspection and supplies a **redacted** BOM header and representative rows, with a traceable occurrence list where available. Capture: Cimatron build, assembly context, BOM export column names, `Standard Number`, `Sub Category`, `Category`, `Material`, `Qty.`, and any real unique occurrence identifier that API/export truly exposes. Include (a) at least one known Cavity/Core/Insert, (b) nested assembly child, (c) repeated component/model title used more than once, and (d) blank Category if present. Avoid client-sensitive attributes in project ZIP.

Evidence questions: Does Category populate reliably? Is it per model/document, per BOM grouping row, or per occurrence? Does repeated `Standard Number` mean one BOM row with quantity, multiple rows, or mixed Material/Category values? Can `ModelPid` or a documented API key reliably join BOM evidence with the exact assembly occurrence? Are blank/duplicate rows distinguishable? **Do not join solely on title unless the supplied cases prove it unambiguous under the target supported constraints.**

**Acceptance criterion:** one verified, deterministic and read-only mapping from eligible traversed occurrence to its exact BOM Category, with explicit handling of ambiguous/unavailable cases. If the export cannot provide a unique join, evaluate official Cimatron SDK/installed Interop capability and live behavior for a supported per-occurrence alternative; do not invent method names.

## 3. Required evidence: independently classify parts that require Part Type

Starting from actual existing exclusion/skipping rules, verify independently of Part Type which modeled parts require it. Inspect (read-only) *Details*, any permitted BOM fields, and customer-approved authoritative classification rules for: Cavity, Core, Cavity Insert, Core Insert, Moving Core, Angular Lifter, Pressure Pad, Wear Pad, Mould Base; contrast known non-applicable parts. For each relevant candidate, record occurrence ID/path (where reliably provided), observed independent field/source, whether Part Type is currently missing, and reason that property **must** be populated. Include examples of relevant missing type and irrelevant missing type; do not infer obligation from part name, Part Material, generic BOM Category, or a missing value itself unless the customer has formally approved and runtime evidence supports that rule.

**Acceptance criterion:** an independent, repeatable required-Part-Type predicate with positive/negative counterexamples and safe behavior on errors, ambiguity, suppressed/non-part/internal components. Existing `CAD_PART_TYPE_MISSING` emission alone is **not** this proof. If classification cannot be established, keep warning implementation blocked and raise an explicit client/technical decision request.

## 4. Safe runtime execution boundary

This step **does not authorize** a new Cimatron command, a diagnostic probe, an API adapter edit, CSV export-button modification, or source changes. Reuse existing workstation inspection/existing supported BOM tools, if allowed, to produce **external** redacted evidence. Never edit/save assembly, populate native properties, or include raw production workbook/model in this project. If evidence collection requires code, first propose exact read-only diagnostic source/test file list, APIs, bounded execution/removal policy, quality gates, and obtain separate approval. User must execute all builds/tests/Cimatron actions under AGENTS.md.

## 5. Proposed next implementation boundary (not approved)

Once evidence arrives: (1) select trustworthy BOM Category association contract and typed row/occurrence identity, (2) decide required-Part-Type eligibility predicate or record blocker, (3) plan test-first adapter and application projection change with affected source and test paths, (4) preserve comparator, distinct UAT categories and legacy CSV infrastructure, (5) obtain explicit implementation approval. API errors must stay errors, never masquerade as business Pass/Fail. UI must not display an incorrectly guessed Category.

## 6. Evidence and test status

**Executed by agent:** source review and documentation packaging only, package checksum verification. **Not executed:** workstation build, analyzers, unit/architecture tests, SonarQube, live Cimatron BOM export, runtime model verification, client UAT acceptance. **Gates unresolved:** Category per-occurrence association and independent Part Type obligation. No approval for production code changes is implied by this report.
