# EP-LICENSE-01 — User-validated UAT closure (v0.41.5)

- Closure documentation prepared: 2026-10-13T21:03:33+05:30 (Asia/Kolkata).
- Source baseline: v0.41.4 command-invocation licensing gate. **Documentation-only v0.41.5**; production code, tests, fixtures, keys, and assembly versions remain byte-identical to v0.41.4. Product documentation version is 0.41.5; compiled plugin version stays 0.41.4.0 until a separately approved code release.
- Windows quality gate `quality-gate-20261013-195234.txt`: user-run local quality gate PASS, ExitCode 0, completed 2026-10-13T19:53:40.8702257+05:30. Test groups architecture/domain/application/infrastructure/Cimatron integration, coverage gate PASS; SonarQube server-side gate was not evidenced.

## UAT evidence register

| ID | Scenario | Evidence and actual validation scope | Status |
|---|---|---|---|
| 01A | Signed unrestricted license, online | User-confirmed Cimatron live plugin works | PASS (live) |
| 01B | Signed unrestricted license, offline | User-confirmed Cimatron live plugin works with `timeBound=false` | PASS (live) |
| 02 | Missing license | User confirmed startup without popup, popup on plugin click, command blocked | PASS (live) |
| 03 | Tampered license | User confirmed invalid-license popup only on command click | PASS (live) |
| 04 | Valid signed time-bound license online | User checked fixture SHA-256 `1BF77DC737CAF610210DD21BE474EDE91D4AC9A58AACB7E6DB07A8B87D829E25`, then confirmed live plugin operation | PASS (live) |
| 05 | Valid time-bound license offline | User confirmed offline popup only on click and execution blocked after restart without trusted-time cache | PASS (live) |
| 06 | Signed expired time-bound license online | User created a signed fixture with expiry `2026-10-12T18:29:59Z`; installed SHA-256 `15C325602B41430CB48E36926F85A2292BB725C0E4FC02BBAA1C62D3A2F7C9C4`; screenshot and user confirmation of expired popup on click and execution blocked | PASS (live) |
| 07 | Incorrect clock / certificate-time failure | User ran standalone `LicenseGate.Tests.exe` and received `LicenseGate.Tests PASS`; test injects `CertificateTimeFailure=true` and asserts `ClockIncorrect` | PASS (simulated path only) |

### Explicit validation limits and release caveats

- **Test 07 is not live proof of real Windows clock skew or actual TLS certificate `NotTimeValid` classification.** This remains a separate deployment-hardening test before production readiness claims.
- Existing signed fixture/public key uses a TEST signing identity. Rotate to production signing keys and establish private-key custody before client release. No private key is included in this package.
- No SonarQube server-side evidence, client installer/package acceptance, or production-key validation was provided for this closure.
- Approved behavior deviation from original license specification: discovery registers plugin commands without checking/showing license; every actual command invocation checks the gate before restricted work. Cimatron host startup is not blocked by missing/invalid licenses. This was live-verified during Test 02 and confirmed again during later rejection tests.
- The user restored unrestricted `license.dat` and confirmed SHA-256 `4ABA65C3184490A552216D577D2D733E7CC073AA98B9B925C6ADE4FBDF93FBF6`.
- Historical pending statuses in previous handoffs remain historical. There were no agent-run builds/tests or live Cimatron checks for v0.41.5.

## Closure decision

EP-LICENSE-01 **UAT CLOSED at documentation version v0.41.5**, within the evidence scope above. This is not a claim of production deployment readiness.

## New-session handoff

Repository: `cimatron-customization/` cumulative snapshot. Read `AGENTS.md`, `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, this handoff, and `docs/requirements/LICENSE_GATE_SPEC.md`. Existing CR-04 UAT was closed effective 2026-10-12 (v0.40.12 baseline). License gate closure at documentation v0.41.5, compiled plugin v0.41.4.0. Next work requires explicit user approval and a scope-specific plan. Maintain SHA-256 manifest and CSV time ledger. User alone runs Windows builds/quality gates/Cimatron. Do not treat simulated Test 07 as live TLS validation.
