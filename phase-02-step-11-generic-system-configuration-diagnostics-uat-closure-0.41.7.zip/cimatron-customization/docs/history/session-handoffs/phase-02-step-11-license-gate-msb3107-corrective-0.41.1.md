# Phase 02 Step 11 — EP-LICENSE-01 v0.41.1 handoff

- Submitted at: 2026-10-13T18:59:58+05:30 (Asia/Kolkata).
- Approval: user approved targeted correction after Windows quality-gate failure. Exact approval timestamp not independently observed.
- Windows evidence: `quality-gate-20261013-185442.txt`, tool restore PASS, Release x64 MSB3107 ×5 in the plugin project references, further tests not reached.
- Approved fix: remove invalid nested item groups in the five `<Project>` GUID fields of `src/CimatronCustomization.Plugin/CimatronCustomization.Plugin.csproj`; preserve standalone license.dat copying.
- Source scope: plugin `.csproj` metadata only and plugin AssemblyInfo version (0.41.1.0); no other runtime source or CR-04 code changed.
- CR-04 UAT: closed effective 2026-10-12, baseline 0.40.12 preserved.
- v0.41.1: awaiting Windows Release x64 quality gate, standalone LicenseGate.Tests execution, and live Cimatron license tests. No validation run by agent.
- Test key: development only; replace before production deployment.
- Package: `phase-02-step-11-license-gate-msb3107-project-reference-corrective-0.41.1.zip`. Manifest `CHECKSUMS.sha256` includes included project files; separate archive SHA-256 sidecar is provided.
