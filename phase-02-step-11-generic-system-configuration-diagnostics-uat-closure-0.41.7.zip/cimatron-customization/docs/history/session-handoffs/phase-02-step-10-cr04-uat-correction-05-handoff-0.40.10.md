# CR-04 UAT Correction 05 — v0.40.10 session handoff

Recorded: 2026-10-09T14:42:25+05:30 (Asia/Kolkata)

## Source
Cumulative v0.40.9 (`phase-02-step-10-cr04-uat-single-result-details-default-part-type-filter-0.40.9.zip`). User reported missing DO Name/DO Material on Passed Cavity block and Core block rows and required exact spreadsheet labels including spaces (e.g. `Core Insert`, `Cavity Insert`). Explicit approval received.

## Root cause and repair
`SteelGradeOccurrenceHighlightSafety.FilterFinding` created a new `Finding` after removing ambiguous references but discarded `DesignOrderContext`. Preserve it. Form reader now retains exact Excel name cell alongside normalized validation label. Original raw Remark and Excel label flow into `DesignOrderSteelGradeEntry` separate from category comparison key and normalized comparison steel grade. Evaluator returns the exact source cell values in structured match context; normalizer/business decisions unchanged.

## Changed files
- `src/CimatronCustomization.Application/SteelGradeOccurrenceHighlightSafety.cs`
- `src/CimatronCustomization.Application/DesignOrderFormCategoryRecord.cs`
- `src/CimatronCustomization.Infrastructure/ExcelDesignOrderFormReader.cs`
- `src/CimatronCustomization.Domain/DesignOrderSteelGradeEntry.cs`
- `src/CimatronCustomization.Domain/SteelGradeDesignOrderEvaluation.cs`
- `src/CimatronCustomization.Application/VerifySteelGradeAgainstDesignOrder.cs`
- `tests/CimatronCustomization.Application.Tests/SteelGradeOccurrenceHighlightSafetyTests.cs`
- `tests/CimatronCustomization.Application.Tests/VerifySteelGradeAgainstDesignOrderTests.cs`
- `tests/CimatronCustomization.Infrastructure.Tests/ExcelDesignOrderFormReaderTests.cs`
- `VERSION.md`, `CHANGELOG.md`, `IMPLEMENTATION-HISTORY.md`, `docs/time-tracking/PROJECT-TIMESHEET.csv`, `CHECKSUMS.sha256`
- This new handoff document.

## Pending
Run full Windows quality gate, then inspect matched Cavity block, Core block and insert in Cimatron report; check exact Excel label and Remark, Pass/Failed filter, warnings, counters, CSV and highlight safety. SonarQube server-side remains separately pending. No client approval claimed. Context GREEN.
