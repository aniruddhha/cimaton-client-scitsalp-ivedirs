# CR-04 UAT Step 5 — 0.40.3 handoff

## Scope
Developer-only read-only native Part property evidence extension. The 2026-10-09 live Step 4 report proved the BOM Category column and occurrence traversal but did not verify Category joining or missing required Part Type classification. This patch records Part Type/Part Material via unchanged native PDM reader and clearly distinguishes read failure, skip and blank values.

## Safety and unresolved gates
- No model/DO save or mutation calls; no production comparison/UI/CSV behavior changes.
- BOM row-to-occurrence association remains unverified. Repeated occurrences and Qty prevent assuming title joins.
- Independent missing Part Type obligation remains unresolved; Details not captured.
- Existing reader works at ModelPid/document granularity, not a verified per-instance property identity.
- Prior diagnostic reported `DocumentModifiedBefore=True`; no clean-document no-mutation proof.

## Workstation validation
1. Unpack complete ZIP to existing project as an intentional updated source tree, ensuring `tools/Request-Cr04UatCategoryEligibilityDiagnostic.ps1` is present and plugin source is current.
2. Run project's `tools/Invoke-QualityGate.ps1` in Release x64; require zero warnings/errors and full governed suites PASS.
3. Deploy/reload current plugin DLL per project RUN guidance (a previously loaded DLL would not contain the enhancement).
4. Open controlled test-copy assembly, record pre-run modified state, issue one-shot request with `powershell.exe -ExecutionPolicy Bypass -File .\tools\Request-Cr04UatCategoryEligibilityDiagnostic.ps1`, then click Cimatron Customization once.
5. Upload the generated diagnostic .txt and complete quality-gate capture. Check per-occurrence native reads and repeated-model behavior, BOM association ambiguities and modified state. No production eligibility rule should be inferred from blank Part Type alone.

## Validation status
Static source changes packaged; **no agent-executed build/test/Cimatron**. Windows user quality gate and live evidence pending.
