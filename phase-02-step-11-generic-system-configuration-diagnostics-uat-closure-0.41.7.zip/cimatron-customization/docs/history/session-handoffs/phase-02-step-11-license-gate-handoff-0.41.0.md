# EP-LICENSE-01 — v0.41.0 handoff

- Approved requirement: `docs/requirements/LICENSE_GATE_SPEC.md`.
- CR-04 v0.40.12 user-validated closure effective 2026-10-12 must be preserved.
- Plugin entry points: `CimatronPluginCommand.AppendCommand()` and `CimatronCommandExecution.OnCommand()`; gate precedes any diagnostics.
- Plugin output must include signed `license.dat` at the DLL installation path; default signed fixture has timeBound=false.
- Test key `TEST-public-key.pem` is for development only. Replace embedded key with production SPKI and provide a new corresponding signed license before customer release.
- Run quality gate on the Windows workstation and separately run `tests/LicenseGate.Tests` project in Release x64 (standalone harness). The harness is not yet wired into the solution/local gate.
- Validate Cimatron startup and every command, missing license, tampered license, normal license, restricted license, offline, expiry, cached trusted time and Cimatron response to null AppendCommand.
- Known pending technical verification: framework TLS chain `NotTimeValid` classification is currently limited to CERT_E_EXPIRED HRESULT, and not all Windows certificate error wrapping is guaranteed to expose it. No TLS validation bypass is installed.
- Do not treat the change as accepted or deployed until user quality-gate and live Cimatron evidence are reviewed.
