using System;
using System.IO;
using System.Collections.Generic;
using CimatronCustomizationPlugin;

internal sealed class FakeTime : ITrustedLicenseTime
{
    internal int Calls;
    internal DateTimeOffset? Now;
    internal bool CertError;
    public TrustedTimeResult Fetch() { Calls++; return new TrustedTimeResult { Utc = Now, CertificateTimeFailure = CertError }; }
}
internal static class Program
{
    private static void Assert(bool valid, string name) { if (!valid) throw new Exception("FAILED: " + name); }
    private static void Main()
    {
        string fixtures = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\license-gate-fixtures"));
        string normal = Path.Combine(fixtures, "license.dat");
        string bounded = Path.Combine(fixtures, "license-timebound.dat");
        var never = new FakeTime();
        Assert(new LicenseGate(normal, never).Check() == LicenseResult.Valid && never.Calls == 0, "signed unrestricted skips network");
        Assert(new LicenseGate(Path.Combine(fixtures, "missing.dat"), never).Check() == LicenseResult.LicenseMissing, "missing");
        string temp = Path.GetTempFileName();
        try
        {
            string signed = File.ReadAllText(normal).Trim();
            char[] chars = signed.ToCharArray(); chars[4] = chars[4] == 'A' ? 'B' : 'A';
            File.WriteAllText(temp, new string(chars));
            Assert(new LicenseGate(temp, never).Check() == LicenseResult.LicenseSignatureInvalid, "tampered payload");
            File.WriteAllText(temp, "invalid.signature.other");
            Assert(new LicenseGate(temp, never).Check() == LicenseResult.LicenseSignatureInvalid, "malformed");
        }
        finally { File.Delete(temp); }
        var before = new FakeTime { Now = new DateTimeOffset(2026, 12, 30, 0, 0, 0, TimeSpan.Zero) };
        Assert(new LicenseGate(bounded, before).Check() == LicenseResult.Valid && before.Calls == 1, "before expiry");
        var after = new FakeTime { Now = new DateTimeOffset(2027, 1, 1, 0, 0, 0, TimeSpan.Zero) };
        Assert(new LicenseGate(bounded, after).Check() == LicenseResult.Expired, "after expiry");
        var offline = new FakeTime();
        Assert(new LicenseGate(bounded, offline).Check() == LicenseResult.Offline, "offline");
        var badClock = new FakeTime { CertError = true };
        Assert(new LicenseGate(bounded, badClock).Check() == LicenseResult.ClockIncorrect, "invalid certificate time");
        Assert(HttpsTrustedLicenseTime.Median(new[] {
            new DateTimeOffset(2026, 1, 1, 0, 0, 1, TimeSpan.Zero),
            new DateTimeOffset(2026, 1, 1, 0, 0, 3, TimeSpan.Zero),
            new DateTimeOffset(2026, 1, 1, 0, 0, 50, TimeSpan.Zero)
        }).Second == 3, "median");
        Assert(new LicenseGate(bounded, before).Check() == LicenseResult.Valid, "fresh independent gate");
        Assert(LicenseDiagnosticCodes.Message == "The current Windows system configuration could not be validated.", "generic message");
        var diagnostics = new Dictionary<LicenseResult, string> {
            { LicenseResult.LicenseMissing, "SYS-101" },
            { LicenseResult.LicenseSignatureInvalid, "SYS-102" },
            { LicenseResult.Expired, "SYS-103" },
            { LicenseResult.Offline, "SYS-104" },
            { LicenseResult.ClockIncorrect, "SYS-105" },
            { LicenseResult.LicenseProductMismatch, "SYS-106" },
            { LicenseResult.LicensePayloadInvalid, "SYS-107" },
            { LicenseResult.LicenseUnexpected, "SYS-199" }
        };
        foreach (var entry in diagnostics)
        {
            Assert(LicenseDiagnosticCodes.For(entry.Key) == entry.Value, "diagnostic mapping " + entry.Value);
            string popup = LicenseDiagnosticCodes.BlockingMessage(entry.Key);
            Assert(popup == LicenseDiagnosticCodes.Message + Environment.NewLine + Environment.NewLine +
                "Error Code: [" + entry.Value + "]", "generic popup " + entry.Value);
            Assert(popup.IndexOf("license", StringComparison.OrdinalIgnoreCase) < 0, "no license disclosure " + entry.Value);
        }
        Assert(LicenseDiagnosticCodes.For(LicenseResult.LicenseInvalid) == "SYS-199", "unclassified failure fallback");
        Console.WriteLine("LicenseGate.Tests PASS");
    }
}
