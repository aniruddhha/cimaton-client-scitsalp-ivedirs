using System;
using System.Collections.Generic;
using CimatronCustomization.Application;

namespace CimatronCustomizationPlugin
{
    /// <summary>Read-only CR-04 presentation projection; preserves the original report for CSV and highlighting.</summary>
    internal sealed class Cr04UatResultProjection
    {
        private Cr04UatResultProjection(FindingReportWindow.ResultRow source, string name, string material,
            string status, string doName, string doMaterial, string category, string kind, bool comparison, string partType)
        {
            Source = source;
            Name = name ?? string.Empty;
            ModelMaterial = material ?? string.Empty;
            Status = status ?? string.Empty;
            DesignOrderName = doName ?? string.Empty;
            DesignOrderMaterial = doMaterial ?? string.Empty;
            Category = category ?? string.Empty;
            FindingKind = kind;
            IsComparison = comparison;
            PartType = partType ?? string.Empty;
            HasPartType = !string.IsNullOrWhiteSpace(PartType);
        }

        internal FindingReportWindow.ResultRow Source { get; }
        internal bool IsComparison { get; }
        internal bool HasPartType { get; }
        public string Name { get; }
        public string PartType { get; }
        public string ModelMaterial { get; }
        public string Status { get; }
        public string DesignOrderName { get; }
        public string DesignOrderMaterial { get; }
        public string Category { get; }
        public string FindingKind { get; }
        public string Message => Source.Message;

        internal bool Matches(string status, ISet<string> selectedCategories)
        {
            return ((string.Equals(status, "Pass and Failed", StringComparison.OrdinalIgnoreCase) && HasPartType) ||
                    string.Equals(status, "All", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(Status, status, StringComparison.OrdinalIgnoreCase)) &&
                   (selectedCategories.Count == 0 || selectedCategories.Contains(Category.Trim()));
        }

        internal static Cr04UatResultProjection ForGeneralFinding(FindingReportWindow.ResultRow row)
        {
            return new Cr04UatResultProjection(row, row.Feature, string.Empty, row.Status,
                string.Empty, string.Empty, string.Empty, "Other finding", false, string.Empty);
        }

        internal static Cr04UatResultProjection[] Create(FindingReportWindow.ResultRow row, FeatureFindingView finding)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            if (finding == null) throw new ArgumentNullException(nameof(finding));
            bool missingPartType = row.Message.StartsWith("[CAD_PART_TYPE_MISSING]", StringComparison.Ordinal);
            bool cr04 = string.Equals(row.RequirementId, "CR-04", StringComparison.OrdinalIgnoreCase);
            string kind = missingPartType ? "Missing Part Type" : "Other finding";
            FeatureFindingComponentContextView[] contexts = finding.ComponentContexts;
            if (contexts.Length == 0)
                return new[] { new Cr04UatResultProjection(row, row.Feature, string.Empty, row.Status,
                    finding.HasDesignOrderMatch ? finding.DesignOrderName : string.Empty,
                    finding.HasDesignOrderMatch ? finding.DesignOrderMaterial : string.Empty,
                    string.Empty, kind, cr04 && finding.HasDesignOrderMatch && !missingPartType, string.Empty) };
            List<Cr04UatResultProjection> projections = new List<Cr04UatResultProjection>();
            foreach (FeatureFindingComponentContextView context in contexts)
                projections.Add(new Cr04UatResultProjection(row, context.ComponentTitle, context.PartMaterial,
                    row.Status, finding.HasDesignOrderMatch ? finding.DesignOrderName : string.Empty,
                    finding.HasDesignOrderMatch ? finding.DesignOrderMaterial : string.Empty,
                    context.Category, kind, cr04 && !missingPartType && (finding.HasDesignOrderMatch ||
                    row.Message.StartsWith("[CAD_PART_MATERIAL_MISSING]", StringComparison.Ordinal) ||
                    row.Message.StartsWith("[CAD_GRADE_UNKNOWN]", StringComparison.Ordinal)),
                    context.PartType));
            return projections.ToArray();
        }
    }
}
