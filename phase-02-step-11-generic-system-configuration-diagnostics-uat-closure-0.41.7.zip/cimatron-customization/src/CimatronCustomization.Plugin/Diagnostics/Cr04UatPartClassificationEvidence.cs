using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace CimatronCustomizationPlugin
{
    /// <summary>Bounded read-only inspection of available occurrence/entity attribute metadata. No business classification.</summary>
    internal static class Cr04UatPartClassificationEvidence
    {
        private const int MaximumInstances = 160;
        private const int MaximumEntitiesPerInstance = 4;
        private const int MaximumAttributesPerEntity = 24;
        private const int MaximumDepth = 16;
        private const int MaximumFieldLength = 160;

        internal static void Append(StringBuilder output, interop.CimMdlrAPI.IAssemblyModel assembly, int maximumCharacters)
        {
            if (output == null) throw new ArgumentNullException(nameof(output));
            if (assembly == null) throw new ArgumentNullException(nameof(assembly));
            Add(output, "INDEPENDENT_ATTRIBUTE_PROBE (path|source|state|attributeName|attributeType|valuePreview)", maximumCharacters);
            int observed = 0;
            try
            {
                interop.CimMdlrAPI.IAssInstance root = assembly.GetRootInstance();
                if (root == null)
                    Add(output, "root|INSTANCE|UNAVAILABLE|||", maximumCharacters);
                else
                    Visit(output, root, "root", 0, ref observed, maximumCharacters);
            }
            catch (Exception exception) when (exception is System.Runtime.InteropServices.COMException || exception is InvalidCastException || exception is ArgumentException)
            {
                Add(output, "root|INSTANCE|READ_ERROR|||" + Clean(exception.GetType().Name + ": " + exception.Message), maximumCharacters);
            }
            Add(output, "ATTRIBUTE_PROBE_SCOPE=BOUNDED_OCCURRENCE_AND_BODY_METADATA; NOT_DOCUMENT_DETAILS_CLASSIFICATION", maximumCharacters);
            Add(output, "DETAILS_AS_PART_CLASSIFIER=UNVERIFIED; ATTRIBUTE_NAMES_ARE_CANDIDATES_ONLY", maximumCharacters);
            Add(output, "MISSING_PART_TYPE_OBLIGATION=UNRESOLVED; REQUIRES_APPROVED_INDEPENDENT_RULE", maximumCharacters);
        }

        private static void Visit(StringBuilder output, interop.CimMdlrAPI.IAssInstance instance, string path,
            int depth, ref int observed, int limit)
        {
            if (depth > MaximumDepth || observed >= MaximumInstances)
            {
                Add(output, Clean(path) + "|INSTANCE|BOUND_REACHED|||", limit);
                return;
            }
            observed++;
            try
            {
                interop.CimBaseAPI.IAttributeSink instanceSink = instance as interop.CimBaseAPI.IAttributeSink;
                ObserveSink(output, path, "INSTANCE", instanceSink, limit);
                interop.CimMdlrAPI.ICimEntityList entities = instance.GetAllEntities();
                if (entities != null)
                {
                    int count = Math.Min(entities.Count, MaximumEntitiesPerInstance);
                    for (int i = 1; i <= count; i++)
                    {
                        interop.CimMdlrAPI.ICimEntity entity = entities[i] as interop.CimMdlrAPI.ICimEntity;
                        if (entity != null)
                            ObserveSink(output, path + "/entity:" + entity.ID.ToString(CultureInfo.InvariantCulture),
                                "ENTITY", entity as interop.CimBaseAPI.IAttributeSink, limit);
                    }
                    if (entities.Count > count)
                        Add(output, Clean(path) + "|ENTITY|ENTITY_LIMIT_REACHED|||", limit);
                }
                object rawChildren = instance.get_SubInstances(1, 0);
                Array children = rawChildren as Array;
                if (children == null) return;
                foreach (object child in children)
                {
                    if (observed >= MaximumInstances)
                    {
                        Add(output, Clean(path) + "|INSTANCE|INSTANCE_LIMIT_REACHED|||", limit);
                        break;
                    }
                    interop.CimMdlrAPI.IAssInstance typedChild = child as interop.CimMdlrAPI.IAssInstance;
                    if (typedChild != null)
                        Visit(output, typedChild, path + "/" + typedChild.ID.ToString(CultureInfo.InvariantCulture), depth + 1, ref observed, limit);
                }
            }
            catch (Exception exception) when (exception is System.Runtime.InteropServices.COMException || exception is InvalidCastException || exception is ArgumentException)
            {
                Add(output, Clean(path) + "|INSTANCE|READ_ERROR|||" + Clean(exception.GetType().Name + ": " + exception.Message), limit);
            }
        }

        private static void ObserveSink(StringBuilder output, string path, string source,
            interop.CimBaseAPI.IAttributeSink sink, int limit)
        {
            if (sink == null)
            {
                Add(output, Clean(path) + "|" + source + "|NO_ATTRIBUTE_SINK|||", limit);
                return;
            }
            try
            {
                object[] attributes = sink.GetAttributes();
                if (attributes == null)
                {
                    Add(output, Clean(path) + "|" + source + "|NULL_ATTRIBUTES|||", limit);
                    return;
                }
                int count = Math.Min(attributes.Length, MaximumAttributesPerEntity);
                if (count == 0) Add(output, Clean(path) + "|" + source + "|EMPTY_ATTRIBUTES|||", limit);
                for (int i = 0; i < count; i++)
                {
                    interop.CimBaseAPI.IAttribute attribute = attributes[i] as interop.CimBaseAPI.IAttribute;
                    if (attribute == null)
                    {
                        Add(output, Clean(path) + "|" + source + "|UNREADABLE_ATTRIBUTE|||", limit);
                        continue;
                    }
                    string value = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                    Add(output, Clean(path) + "|" + source + "|OBSERVED|" + Clean(attribute.Name) + "|" +
                        Clean(attribute.Type.ToString()) + "|" + Clean(value), limit);
                }
                if (attributes.Length > count) Add(output, Clean(path) + "|" + source + "|ATTRIBUTE_LIMIT_REACHED|||", limit);
            }
            catch (Exception exception) when (exception is System.Runtime.InteropServices.COMException || exception is InvalidCastException || exception is ArgumentException)
            {
                Add(output, Clean(path) + "|" + source + "|READ_ERROR|||" + Clean(exception.GetType().Name + ": " + exception.Message), limit);
            }
        }

        private static void Add(StringBuilder output, string value, int limit)
        {
            if (output.Length + value.Length + Environment.NewLine.Length > limit)
                throw new InvalidOperationException("Diagnostic evidence exceeds size limit.");
            output.AppendLine(value);
        }

        private static string Clean(string value)
        {
            string cleaned = (value ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Replace("|", "/");
            return cleaned.Length > MaximumFieldLength ? cleaned.Substring(0, MaximumFieldLength) + "[TRUNCATED]" : cleaned;
        }
    }
}
