using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using CimatronCustomization.Application;

namespace CimatronCustomizationPlugin
{
    /// <summary>Bounded read-only document-property evidence for potential native Category sources; no mapping decisions.</summary>
    internal static class Cr04UatNativeCategoryPropertyEvidence
    {
        private const int MaximumModels = 160;
        private const int MaximumAttributesPerModel = 128;
        private const int MaximumFieldLength = 160;

        internal static void Append(StringBuilder output, IReadOnlyList<AssemblyBodyAttributeOccurrence> occurrences, int limit)
        {
            if (output == null) throw new ArgumentNullException(nameof(output));
            if (occurrences == null) throw new ArgumentNullException(nameof(occurrences));
            Add(output, "NATIVE_CATEGORY_PROPERTY_PROBE (path|modelPid|state|propertyName|propertyValue)", limit);
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            interop.CimatronE.IApplication application = null;
            interop.CimatronE.IPdm pdm = null;
            try
            {
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application != null) pdm = application.GetPdm();
            }
            catch (Exception exception)
            {
                Add(output, "GLOBAL||PDM_ACCESS_ERROR||" + Clean(exception.GetType().Name + ": " + exception.Message), limit);
            }
            if (pdm == null)
            {
                Add(output, "GLOBAL||PDM_UNAVAILABLE||", limit);
                AddConclusions(output, limit);
                return;
            }
            foreach (AssemblyBodyAttributeOccurrence occurrence in occurrences)
            {
                string pid = occurrence.ModelPid ?? string.Empty;
                if (!string.Equals(occurrence.ModelType, "cmPart", StringComparison.Ordinal) ||
                    string.IsNullOrWhiteSpace(pid) || pid.StartsWith("\\", StringComparison.Ordinal) ||
                    pid.IndexOf("Root.elt", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                if (!seen.Add(pid)) continue;
                if (seen.Count > MaximumModels)
                {
                    Add(output, "GLOBAL||MODEL_LIMIT_REACHED||", limit);
                    break;
                }
                string path = Clean(occurrence.OccurrencePath);
                try
                {
                    object raw = null;
                    pdm.RetriveDocAttribute(pid, ref raw, string.Empty);
                    Array attributes = raw as Array;
                    if (attributes == null)
                    {
                        Add(output, path + "|" + Clean(pid) + "|INVALID_ATTRIBUTE_CONTAINER||", limit);
                        continue;
                    }
                    int visited = 0;
                    bool anyCandidate = false;
                    foreach (object item in attributes)
                    {
                        if (++visited > MaximumAttributesPerModel)
                        {
                            Add(output, path + "|" + Clean(pid) + "|ATTRIBUTE_LIMIT_REACHED||", limit);
                            break;
                        }
                        interop.CimBaseAPI.IDocAttribute attribute = item as interop.CimBaseAPI.IDocAttribute;
                        if (attribute == null)
                        {
                            Add(output, path + "|" + Clean(pid) + "|UNREADABLE_DOC_ATTRIBUTE||", limit);
                            continue;
                        }
                        string name = attribute.Name ?? string.Empty;
                        // Candidate reporting only: this is not proof that an attribute is the BOM Category.
                        if (name.IndexOf("categor", StringComparison.OrdinalIgnoreCase) < 0 &&
                            name.IndexOf("class", StringComparison.OrdinalIgnoreCase) < 0 &&
                            name.IndexOf("detail", StringComparison.OrdinalIgnoreCase) < 0) continue;
                        anyCandidate = true;
                        string value = Convert.ToString(attribute.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                        Add(output, path + "|" + Clean(pid) + "|CANDIDATE_UNVERIFIED|" + Clean(name) + "|" + Clean(value), limit);
                    }
                    if (!anyCandidate) Add(output, path + "|" + Clean(pid) + "|NO_CANDIDATE_IN_SCANNED_ATTRIBUTES||", limit);
                }
                catch (Exception exception)
                {
                    Add(output, path + "|" + Clean(pid) + "|READ_ERROR||" + Clean(exception.GetType().Name + ": " + exception.Message), limit);
                }
            }
            AddConclusions(output, limit);
        }

        private static void AddConclusions(StringBuilder output, int limit)
        {
            Add(output, "NATIVE_CATEGORY_SOURCE=UNVERIFIED; DOCUMENT_ATTRIBUTE_CANDIDATES_ONLY", limit);
            Add(output, "NATIVE_CATEGORY_OCCURRENCE_MAPPING=UNVERIFIED; DOCUMENT_ATTRIBUTES_ARE_MODEL_SCOPED", limit);
            Add(output, "MISSING_PART_TYPE_WARNING_POLICY=APPROVED_FOR_ELIGIBLE_ACTIVE_PARTS; PRODUCTION_NOT_CHANGED", limit);
        }

        private static void Add(StringBuilder output, string line, int limit)
        {
            if (output.Length + line.Length + Environment.NewLine.Length > limit)
                throw new InvalidOperationException("Diagnostic evidence exceeds size limit.");
            output.AppendLine(line);
        }

        private static string Clean(string text)
        {
            string cleaned = (text ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Replace("|", "/");
            return cleaned.Length > MaximumFieldLength ? cleaned.Substring(0, MaximumFieldLength) + "[TRUNCATED]" : cleaned;
        }
    }
}
