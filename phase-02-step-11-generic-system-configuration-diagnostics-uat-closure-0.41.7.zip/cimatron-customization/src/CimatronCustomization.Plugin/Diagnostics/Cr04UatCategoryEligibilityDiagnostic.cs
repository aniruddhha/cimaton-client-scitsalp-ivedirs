using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;

namespace CimatronCustomizationPlugin
{
    /// <summary>Developer-only raw BOM and occurrence evidence. No inferred category or eligibility.</summary>
    internal static class Cr04UatCategoryEligibilityDiagnostic
    {
        private const int MaximumRows = 2000;
        private const int MaximumEvidenceCharacters = 750000;

        internal static bool TryRunRequested(out bool commandResult)
        {
            if (!Cr04UatCategoryEligibilityDiagnosticRequest.TryConsume(out Cr04UatCategoryEligibilityDiagnosticRequest request, out string error))
            {
                commandResult = false;
                return false;
            }
            if (request == null)
            {
                MessageBox.Show("CR-04 UAT diagnostic request rejected: " + error, "CR-04 UAT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                commandResult = false;
                return true;
            }
            commandResult = Run(request.EvidenceFile);
            return true;
        }

        private static bool Run(string evidencePath)
        {
            StringBuilder output = new StringBuilder();
            string temporaryDirectory = string.Empty;
            bool success = false;
            try
            {
                output.AppendLine("CR-04 UAT CATEGORY / ELIGIBILITY READ-ONLY DIAGNOSTIC");
                output.AppendLine("TimestampUtc=" + DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture));
                output.AppendLine("ModelWrites=NONE; SaveOperations=NONE; ComparisonChanges=NONE");
                interop.CimServicesAPI.CimApplicationProvider provider = new interop.CimServicesAPI.CimApplicationProvider();
                interop.CimatronE.IApplication application = (interop.CimatronE.IApplication)provider.GetApplication();
                if (application == null) throw new InvalidOperationException("Cimatron application unavailable.");
                interop.CimatronE.ICimDocument document = application.GetActiveDoc();
                if (document == null || !string.Equals(document.Type.ToString(), "cmAssembly", StringComparison.Ordinal))
                    throw new InvalidOperationException("An active Assembly document is required.");
                bool modifiedBefore = document.IsModified();
                output.AppendLine("DocumentModifiedBefore=" + modifiedBefore);
                interop.CimMdlrAPI.IModelContainer container = document as interop.CimMdlrAPI.IModelContainer;
                interop.CimMdlrAPI.IAssemblyModel assembly = container == null ? null : container.Model as interop.CimMdlrAPI.IAssemblyModel;
                if (assembly == null) throw new InvalidOperationException("Active document does not expose an assembly model.");
                interop.CimMdlrAPI.IBOM bom = assembly.GetBomManager();
                if (bom == null) throw new InvalidOperationException("BOM manager unavailable.");

                temporaryDirectory = Path.Combine(Path.GetTempPath(), "CimatronCustomization", "CR04UatEvidence", Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(temporaryDirectory);
                string stem = Path.Combine(temporaryDirectory, "uat-bom");
                bom.Export(stem, interop.CimMdlrAPI.BOMTemplateType.cmCSV,
                    (interop.CimMdlrAPI.BOMExportOptions)0, string.Empty,
                    interop.CimMdlrAPI.BOMReportFormat.cmNotReq,
                    interop.CimMdlrAPI.ComponentsFilterOption.cmNoFiltering, Array.Empty<string>());
                string[] exported = Directory.GetFiles(temporaryDirectory, "uat-bom*.csv", SearchOption.TopDirectoryOnly);
                if (exported.Length != 1) throw new InvalidOperationException("Expected one BOM CSV; received " + exported.Length + ".");
                if (new FileInfo(exported[0]).Length > MaximumEvidenceCharacters)
                    throw new InvalidOperationException("BOM export exceeds safe diagnostic size cap.");
                string[] lines = File.ReadAllLines(exported[0]);
                if (lines.Length == 0) throw new InvalidOperationException("BOM CSV is empty.");
                if (lines.Length > MaximumRows + 1) throw new InvalidOperationException("BOM exceeds diagnostic row limit. No partial evidence accepted.");
                output.AppendLine("BOM_EVIDENCE (raw CSV lines; no unverified column mappings)");
                foreach (string line in lines) AppendBounded(output, line);
                Cr04UatBomIdentityEvidence.Append(output, lines, MaximumEvidenceCharacters);
                output.AppendLine("BOM_CATEGORY_OCCURRENCE_JOIN=UNVERIFIED; NO AUTOMATIC ROW ASSOCIATION");
                output.AppendLine("BOM_ASSOCIATION_CANDIDATES=TITLE_AND_STANDARD_NUMBER_ARE_NOT_PROVEN_OCCURRENCE_KEYS; QTY_AND_REPEATED_MODELS_MAY_AMBIGUATE");

                CimatronAssemblyBodyAttributeReader reader = new CimatronAssemblyBodyAttributeReader();
                AssemblyBodyAttributeSnapshot snapshot = reader.ReadNamedAttributes("CR04_UAT_UNUSED", "CR04_UAT_UNUSED_CATEGORY");
                if (!snapshot.IsSuccess) throw new InvalidOperationException("Occurrence read error: " + snapshot.ErrorMessage);
                if (snapshot.Occurrences.Count > MaximumRows) throw new InvalidOperationException("Occurrence count exceeds diagnostic cap.");
                output.AppendLine("OCCURRENCES (path|id|modelTitle|modelPid|modelType|suppressed|bodyCount)");
                foreach (AssemblyBodyAttributeOccurrence occurrence in snapshot.Occurrences)
                    AppendBounded(output, Clean(occurrence.OccurrencePath) + "|" + occurrence.InstanceId + "|" +
                        Clean(occurrence.ModelTitle) + "|" + Clean(occurrence.ModelPid) + "|" +
                        Clean(occurrence.ModelType) + "|" + occurrence.IsEffectivelySuppressed + "|" + occurrence.Bodies.Count);
                Cr04UatOccurrencePropertyEvidence.Append(output, snapshot.Occurrences, MaximumEvidenceCharacters);
                Cr04UatPartClassificationEvidence.Append(output, assembly, MaximumEvidenceCharacters);
                Cr04UatNativeCategoryPropertyEvidence.Append(output, snapshot.Occurrences, MaximumEvidenceCharacters);
                output.AppendLine("DocumentModifiedAfter=" + document.IsModified());
                if (document.IsModified() != modifiedBefore) throw new InvalidOperationException("Document modified state changed; inspect model before proceeding.");
                output.AppendLine("Result=EVIDENCE_CAPTURED; CATEGORY_ASSOCIATION_AND_ELIGIBILITY_NOT_VALIDATED");
                success = true;
            }
            catch (Exception exception)
            {
                output.AppendLine("Result=DIAGNOSTIC_ERROR");
                output.AppendLine("Error=" + Clean(exception.ToString()));
            }
            finally
            {
                try
                {
                    if (temporaryDirectory.Length > 0 && Directory.Exists(temporaryDirectory)) Directory.Delete(temporaryDirectory, true);
                }
                catch (Exception cleanupException)
                {
                    output.AppendLine("CleanupError=" + Clean(cleanupException.Message));
                    success = false;
                }
            }
            try
            {
                string directory = Path.GetDirectoryName(evidencePath);
                if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
                File.WriteAllText(evidencePath, output.ToString(), new UTF8Encoding(false));
                MessageBox.Show((success ? "Evidence captured. Mappings remain unverified." : "Diagnostic stopped with an error.") +
                    Environment.NewLine + evidencePath, "CR-04 UAT", MessageBoxButtons.OK,
                    success ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                MessageBox.Show("Evidence write failed: " + exception.Message, "CR-04 UAT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return success;
        }

        private static void AppendBounded(StringBuilder builder, string value)
        {
            if (builder.Length + (value ?? string.Empty).Length + Environment.NewLine.Length > MaximumEvidenceCharacters)
                throw new InvalidOperationException("Diagnostic evidence exceeds size limit.");
            builder.AppendLine(value);
        }

        private static string Clean(string value)
        {
            return (value ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Replace("|", "/");
        }
    }
}
