using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;

namespace CimatronCustomizationPlugin
{
    internal sealed class Cr04PartPropertyDiscoveryDiagnosticRequest
    {
        private const string RequestVersion = "0.38.5";
        private const string RequestFileName = "cr04-part-property-discovery-diagnostic.request";
        private static readonly TimeSpan MaximumRequestAge = TimeSpan.FromMinutes(30);

        private Cr04PartPropertyDiscoveryDiagnosticRequest(string evidenceFile)
        {
            EvidenceFile = evidenceFile;
        }

        internal string EvidenceFile { get; }

        internal static bool TryConsume(out Cr04PartPropertyDiscoveryDiagnosticRequest request, out string error)
        {
            request = null;
            error = string.Empty;

            string requestDirectory = Path.Combine(Path.GetTempPath(), "CimatronCustomization");
            string requestPath = Path.Combine(requestDirectory, RequestFileName);
            if (!File.Exists(requestPath))
                return false;

            string consumingPath = requestPath + ".consuming-" + Process.GetCurrentProcess().Id.ToString(CultureInfo.InvariantCulture);
            try
            {
                if (File.Exists(consumingPath))
                    File.Delete(consumingPath);
                File.Move(requestPath, consumingPath);
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                error = "The CR-04 Part property discovery diagnostic request could not be consumed: " + exception.Message;
                return true;
            }

            try
            {
                string version = null;
                string requestedUtc = null;
                string evidenceFile = null;

                foreach (string line in File.ReadAllLines(consumingPath))
                {
                    int separator = line.IndexOf('=');
                    if (separator <= 0)
                        continue;

                    string key = line.Substring(0, separator).Trim();
                    string value = line.Substring(separator + 1).Trim();
                    if (string.Equals(key, "Version", StringComparison.Ordinal))
                        version = value;
                    else if (string.Equals(key, "RequestedUtc", StringComparison.Ordinal))
                        requestedUtc = value;
                    else if (string.Equals(key, "EvidenceFile", StringComparison.Ordinal))
                        evidenceFile = value;
                }

                if (!string.Equals(version, RequestVersion, StringComparison.Ordinal))
                {
                    error = "The request version is invalid.";
                    return true;
                }

                if (!DateTimeOffset.TryParseExact(requestedUtc, "O", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTimeOffset requestedUtcValue))
                {
                    error = "RequestedUtc is missing or invalid.";
                    return true;
                }

                TimeSpan age = DateTimeOffset.UtcNow - requestedUtcValue.ToUniversalTime();
                if (age < TimeSpan.Zero || age > MaximumRequestAge)
                {
                    error = "The request is outside the 30-minute validity window.";
                    return true;
                }

                if (string.IsNullOrWhiteSpace(evidenceFile) || !Path.IsPathRooted(evidenceFile))
                {
                    error = "EvidenceFile must be an absolute path.";
                    return true;
                }

                request = new Cr04PartPropertyDiscoveryDiagnosticRequest(evidenceFile);
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            {
                error = "The CR-04 Part property discovery diagnostic request could not be read: " + exception.Message;
                return true;
            }
            finally
            {
                try
                {
                    if (File.Exists(consumingPath))
                        File.Delete(consumingPath);
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }
}
