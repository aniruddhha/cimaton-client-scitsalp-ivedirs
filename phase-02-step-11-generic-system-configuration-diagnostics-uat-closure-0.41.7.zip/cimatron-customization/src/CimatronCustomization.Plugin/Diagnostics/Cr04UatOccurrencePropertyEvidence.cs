using System;
using System.Collections.Generic;
using System.Text;
using CimatronCustomization.Application;
using CimatronCustomization.CimatronIntegration;

namespace CimatronCustomizationPlugin
{
    /// <summary>Read-only native document-property evidence. Never infers required Part Type or BOM joins.</summary>
    internal static class Cr04UatOccurrencePropertyEvidence
    {
        internal static void Append(StringBuilder output, IReadOnlyList<AssemblyBodyAttributeOccurrence> occurrences, int maximumCharacters)
        {
            if (output == null) throw new ArgumentNullException(nameof(output));
            if (occurrences == null) throw new ArgumentNullException(nameof(occurrences));
            CimatronPartDocumentPropertyReader reader = new CimatronPartDocumentPropertyReader();
            Dictionary<string, PartDocumentPropertyResult> cache = new Dictionary<string, PartDocumentPropertyResult>(StringComparer.OrdinalIgnoreCase);
            Add(output, "NATIVE_PROPERTIES (path|modelPid|state|partType|partMaterial|errorCode|errorMessage)", maximumCharacters);
            foreach (AssemblyBodyAttributeOccurrence occurrence in occurrences)
            {
                string pid = occurrence.ModelPid ?? string.Empty;
                string type = occurrence.ModelType ?? string.Empty;
                string state;
                string partType = string.Empty, material = string.Empty, errorCode = string.Empty, errorMessage = string.Empty;
                if (!string.Equals(type, "cmPart", StringComparison.Ordinal)) state = "SKIPPED_NON_PART";
                else if (pid.StartsWith("\\", StringComparison.Ordinal) || pid.IndexOf("Root.elt", StringComparison.OrdinalIgnoreCase) >= 0)
                    state = "SKIPPED_SYNTHETIC_ROOT";
                else if (string.IsNullOrWhiteSpace(pid)) state = "SKIPPED_EMPTY_PID";
                else
                {
                    if (!cache.TryGetValue(pid, out PartDocumentPropertyResult result))
                    {
                        result = reader.Read(pid);
                        cache.Add(pid, result);
                    }
                    state = result.IsSuccess ? "READ_OK" : "READ_ERROR";
                    if (result.IsSuccess)
                    {
                        partType = result.RawPartType;
                        material = result.RawPartMaterial;
                    }
                    else
                    {
                        errorCode = result.ErrorCode;
                        errorMessage = result.ErrorMessage;
                    }
                }
                Add(output, Clean(occurrence.OccurrencePath) + "|" + Clean(pid) + "|" + state + "|" + Clean(partType) + "|" + Clean(material) + "|" + Clean(errorCode) + "|" + Clean(errorMessage), maximumCharacters);
            }
            Add(output, "NATIVE_PROPERTY_SCOPE=MODEL_PID_DOCUMENT_ATTRIBUTES; SAME_PID_REUSED_FOR_REPEATED_OCCURRENCES", maximumCharacters);
            Add(output, "DETAILS_AS_PART_CLASSIFIER=NOT_CAPTURED; UNVERIFIED", maximumCharacters);
            Add(output, "MISSING_PART_TYPE_OBLIGATION=UNRESOLVED; BLANK_PART_TYPE_ALONE_IS_NOT_PROOF", maximumCharacters);
        }

        private static void Add(StringBuilder output, string value, int maximumCharacters)
        {
            if (output.Length + value.Length + Environment.NewLine.Length > maximumCharacters)
                throw new InvalidOperationException("Diagnostic evidence exceeds size limit.");
            output.AppendLine(value);
        }

        private static string Clean(string text)
        {
            return (text ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Replace("|", "/");
        }
    }
}
