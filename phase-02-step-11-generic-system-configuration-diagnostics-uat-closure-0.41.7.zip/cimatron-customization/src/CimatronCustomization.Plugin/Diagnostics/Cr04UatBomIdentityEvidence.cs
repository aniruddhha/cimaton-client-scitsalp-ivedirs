using System;
using System.Collections.Generic;
using System.Text;

namespace CimatronCustomizationPlugin
{
    /// <summary>Observes BOM export identity limitations without joining rows to occurrences.</summary>
    internal static class Cr04UatBomIdentityEvidence
    {
        internal static void Append(StringBuilder output, IReadOnlyList<string> csvLines, int maximumCharacters)
        {
            if (output == null) throw new ArgumentNullException(nameof(output));
            if (csvLines == null) throw new ArgumentNullException(nameof(csvLines));
            string header = csvLines.Count == 0 ? string.Empty : csvLines[0] ?? string.Empty;
            Add(output, "BOM_IDENTITY_PROBE=EXPORT_ONLY; IBOM_EXPORT_HAS_NO_VERIFIED_ROW_OCCURRENCE_IDENTIFIER_API", maximumCharacters);
            Add(output, "BOM_EXPORTED_HEADER=" + Clean(header), maximumCharacters);
            Add(output, "BOM_IDENTITY_TEMPLATE_CONFIGURATION=NOT_PROBED; NO_VERIFIED_CUSTOM_TEMPLATE_CONTRACT", maximumCharacters);
            Add(output, "BOM_OCCURRENCE_JOIN=UNVERIFIED; TITLE_STANDARD_NUMBER_AND_QUANTITY_NOT_UNIQUE_KEYS", maximumCharacters);
        }

        private static void Add(StringBuilder output, string value, int maximumCharacters)
        {
            if (output.Length + value.Length + Environment.NewLine.Length > maximumCharacters)
                throw new InvalidOperationException("Diagnostic evidence exceeds size limit.");
            output.AppendLine(value);
        }

        private static string Clean(string value)
        {
            return (value ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Replace("|", "/");
        }
    }
}
