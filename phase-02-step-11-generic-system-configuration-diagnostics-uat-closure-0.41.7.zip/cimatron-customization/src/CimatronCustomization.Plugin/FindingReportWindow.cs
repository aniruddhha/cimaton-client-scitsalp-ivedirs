using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using CimatronCustomization.Application;

namespace CimatronCustomizationPlugin
{
    internal sealed class FindingReportWindow : Form
    {
        private readonly DataGridView grid;
        private readonly ComboBox statusFilter;
        private readonly Button categoryFilterButton;
        private readonly CheckedListBox categoryChoices;
        private readonly List<Cr04UatResultProjection> displayRows = new List<Cr04UatResultProjection>();
        private readonly Label summary;
        private readonly Button highlightButton;
        private readonly IViewportEntityHighlighter viewportEntityHighlighter;
        private readonly string correlationId;
        private readonly List<ResultRow> rows = new List<ResultRow>();

        internal FindingReportWindow(FeatureChecklistReport checklist, IViewportEntityHighlighter viewportEntityHighlighter)
        {
            if (checklist == null) throw new ArgumentNullException(nameof(checklist));
            this.viewportEntityHighlighter = viewportEntityHighlighter ?? throw new ArgumentNullException(nameof(viewportEntityHighlighter));
            correlationId = checklist.CorrelationId ?? string.Empty;

            Text = "Cimatron Customization — Result Report";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(900, 500);
            Size = new Size(1050, 620);
            Font = SystemFonts.MessageBoxFont;

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(10)
            };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(root);

            FlowLayoutPanel filterPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = false };
            filterPanel.Controls.Add(new Label { Text = "Status filter:", AutoSize = true, Margin = new Padding(3, 7, 3, 3) });
            statusFilter = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 150 };
            statusFilter.Items.AddRange(new object[] { "Pass and Failed", "All", "Passed", "Succeeded", "Failed", "Warning", "Error", "NotApplicable", "Skipped", "Unsupported" });
            statusFilter.SelectedIndex = 0;
            statusFilter.SelectedIndexChanged += delegate { ApplyFilter(); };
            filterPanel.Controls.Add(statusFilter);
            filterPanel.Controls.Add(new Label { Text = "Category:", AutoSize = true, Margin = new Padding(10, 7, 3, 3) });
            categoryFilterButton = new Button { Text = "All Categories", AutoSize = true };
            categoryChoices = new CheckedListBox { CheckOnClick = true, Width = 240, Height = 190, IntegralHeight = false };
            ToolStripControlHost categoryHost = new ToolStripControlHost(categoryChoices) { AutoSize = false, Size = new Size(245, 195) };
            ToolStripDropDown categoryMenu = new ToolStripDropDown { AutoClose = true, Padding = Padding.Empty };
            categoryMenu.Items.Add(categoryHost);
            categoryFilterButton.Click += delegate { categoryMenu.Show(categoryFilterButton, 0, categoryFilterButton.Height); };
            categoryChoices.ItemCheck += delegate { BeginInvoke((Action)ApplyFilter); };
            filterPanel.Controls.Add(categoryFilterButton);
            filterPanel.Controls.Add(new Label { Text = "Correlation: " + correlationId, AutoSize = true, Margin = new Padding(20, 7, 3, 3) });
            root.Controls.Add(filterPanel, 0, 0);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoGenerateColumns = false,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 46,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Name", DataPropertyName = "Name", Width = 185 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Part Type", DataPropertyName = "PartType", Width = 155 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Material as per model", DataPropertyName = "ModelMaterial", Width = 170 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Status", DataPropertyName = "Status", Width = 95 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "DO Name", DataPropertyName = "DesignOrderName", Width = 135 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "DO Material", DataPropertyName = "DesignOrderMaterial", Width = 125 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Category", DataPropertyName = "Category", Width = 130 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Details", DataPropertyName = "Message", MinimumWidth = 260, AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
            grid.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;
            grid.ScrollBars = ScrollBars.Both;
            grid.CellFormatting += FormatNameCell;
            grid.CellToolTipTextNeeded += ShowFullCellText;
            grid.ShowCellToolTips = true;
            grid.SelectionChanged += delegate { UpdateHighlightAvailability(); };
            root.Controls.Add(grid, 0, 1);
            summary = new Label { AutoSize = true, Margin = new Padding(3, 8, 3, 8) };
            root.Controls.Add(summary, 0, 2);

            FlowLayoutPanel buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = FlowDirection.RightToLeft };
            Button close = new Button { Text = "Close", AutoSize = true };
            close.Click += delegate { Close(); };
            Button export = new Button { Text = "Export Results", AutoSize = true };
            export.Click += delegate { ExportResults(); };
            Button pick = new Button { Text = "Pick — Unsupported", AutoSize = true, Enabled = false };
            Button zoom = new Button { Text = "Zoom — Unsupported", AutoSize = true, Enabled = false };
            highlightButton = new Button { Text = "Highlight", AutoSize = true, Enabled = false };
            highlightButton.Click += delegate { HighlightSelectedFinding(); };
            buttons.Controls.Add(close);
            buttons.Controls.Add(export);
            buttons.Controls.Add(pick);
            buttons.Controls.Add(zoom);
            buttons.Controls.Add(highlightButton);
            root.Controls.Add(buttons, 0, 3);

            BuildRows(checklist);
            BuildCategoryChoices();
            ApplyFilter();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            try
            {
                viewportEntityHighlighter.RestoreSelection();
            }
            finally
            {
                base.OnFormClosed(e);
            }
        }

        private static string ShortenName(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName)) return fullName;
            // CAD titles can be long; show at most 25 whitespace-delimited words.
            string[] words = fullName.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
            if (words.Length <= 25) return fullName;
            return string.Join(" ", words, 0, 25) + "...";
        }

        private void FormatNameCell(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 0 || !(e.Value is string)) return;
            e.Value = ShortenName((string)e.Value);
            e.FormattingApplied = true;
        }

        private void ShowFullCellText(object sender, DataGridViewCellToolTipTextNeededEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            Cr04UatResultProjection item = grid.Rows[e.RowIndex].DataBoundItem as Cr04UatResultProjection;
            if (item == null) return;
            if (e.ColumnIndex == 0) e.ToolTipText = item.Name;
            else if (grid.Columns[e.ColumnIndex].DataPropertyName == "PartType") e.ToolTipText = item.PartType;
            else if (grid.Columns[e.ColumnIndex].DataPropertyName == "Message") e.ToolTipText = item.Message;
        }

        private void BuildRows(FeatureChecklistReport checklist)
        {
            foreach (FeatureExecutionReport report in checklist.Reports)
            {
                FeatureFindingView[] findings = report.FindingViews;
                if (findings.Length == 0)
                {
                    ResultRow row = new ResultRow(report.FeatureName, string.Empty, report.StatusText, report.Message, string.Empty, string.Empty, Array.Empty<string>(), Array.Empty<FeatureFindingComponentContextView>());
                    rows.Add(row);
                    displayRows.Add(Cr04UatResultProjection.ForGeneralFinding(row));
                    continue;
                }

                foreach (FeatureFindingView finding in findings)
                {
                    ResultRow row = new ResultRow(
                        report.FeatureName,
                        finding.RequirementId,
                        finding.StatusText,
                        finding.Message,
                        finding.MeasuredValueText,
                        finding.LimitText,
                        finding.EntityReferenceValues,
                        finding.ComponentContexts);
                    rows.Add(row);
                    Cr04UatResultProjection[] projected = Cr04UatResultProjection.Create(row, finding);
                    foreach (Cr04UatResultProjection item in projected)
                    {
                        displayRows.Add(item);
                    }
                }
            }
        }

        private void BuildCategoryChoices()
        {
            // Zero checked categories means All, including the explicit blank category.
            categoryChoices.Items.Add("(Blank)", false);
            SortedSet<string> categories = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (Cr04UatResultProjection row in displayRows)
                if (!string.IsNullOrWhiteSpace(row.Category)) categories.Add(row.Category);
            foreach (string category in categories) categoryChoices.Items.Add(category, false);
        }

        private void ApplyFilter()
        {
            string status = statusFilter.SelectedItem == null ? "All" : statusFilter.SelectedItem.ToString();
            HashSet<string> categories = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (object choice in categoryChoices.CheckedItems)
                categories.Add(choice.ToString() == "(Blank)" ? string.Empty : choice.ToString());
            categoryFilterButton.Text = categories.Count == 0 ? "All Categories" : "Categories (" + categories.Count + ")";
            List<Cr04UatResultProjection> filtered = new List<Cr04UatResultProjection>();
            foreach (Cr04UatResultProjection row in displayRows)
                if (row.Matches(status, categories)) filtered.Add(row);
            grid.DataSource = null;
            grid.DataSource = filtered;
            UpdateSummary();
            UpdateHighlightAvailability();
        }

        private void UpdateHighlightAvailability()
        {
            Cr04UatResultProjection row = GetSelectedProjection();
            highlightButton.Enabled = row != null && row.Source.EntityReferenceValues.Length > 0;
        }

        private Cr04UatResultProjection GetSelectedProjection()
        {
            if (grid.SelectedRows.Count > 0)
                return grid.SelectedRows[0].DataBoundItem as Cr04UatResultProjection;
            return null;
        }

        private void HighlightSelectedFinding()
        {
            Cr04UatResultProjection selection = GetSelectedProjection();
            ResultRow row = selection == null ? null : selection.Source;
            if (row == null || row.EntityReferenceValues.Length == 0)
            {
                return;
            }

            ViewportHighlightResult result = viewportEntityHighlighter.Highlight(row.EntityReferenceValues);
            if (!result.IsHighlighted)
            {
                MessageBox.Show(this, result.Message, "Highlight Unsupported", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        private void ExportResults()
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = "Export Result Report";
                dialog.Filter = "CSV files (*.csv)|*.csv";
                dialog.DefaultExt = "csv";
                dialog.AddExtension = true;
                dialog.OverwritePrompt = true;
                dialog.FileName = "Cimatron-Result-Report-" + DateTime.Now.ToString("yyyyMMdd-HHmmss", System.Globalization.CultureInfo.InvariantCulture) + ".csv";

                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                try
                {
                    List<ResultReportCsvRow> exportRows = BuildCsvRows();
                    ResultReportCsvExporter.Export(dialog.FileName, exportRows, correlationId, BuildCsvSummary(exportRows));
                    MessageBox.Show(this, "Result Report exported successfully.", "Export Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (IOException exception)
                {
                    ShowExportFailure(exception.Message);
                }
                catch (UnauthorizedAccessException exception)
                {
                    ShowExportFailure(exception.Message);
                }
                catch (ArgumentException exception)
                {
                    ShowExportFailure(exception.Message);
                }
            }
        }

        private void ShowExportFailure(string message)
        {
            MessageBox.Show(this, "Result Report export failed: " + message, "Export Results", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void UpdateSummary()
        {
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (ResultRow row in rows)
            {
                int current;
                counts.TryGetValue(row.Status, out current);
                counts[row.Status] = current + 1;
            }

            summary.Text = "Summary: Total " + rows.Count +
                " | Passed " + Count(counts, "Passed") +
                " | Succeeded " + Count(counts, "Succeeded") +
                " | Failed " + Count(counts, "Failed") +
                " | Warning " + Count(counts, "Warning") +
                " | Error " + Count(counts, "Error") +
                " | NotApplicable " + Count(counts, "NotApplicable") +
                " | Skipped " + Count(counts, "Skipped") +
                " | Unsupported " + Count(counts, "Unsupported");
        }

        private List<ResultReportCsvRow> BuildCsvRows()
        {
            List<ResultReportCsvRow> exportRows = new List<ResultReportCsvRow>();
            int originalOrder = 0;
            foreach (ResultRow row in rows)
            {
                string findingCode = ResultReportCsvExporter.ExtractFindingCode(row.Message);
                string validationStatus = ResultReportCsvExporter.ClassifyStatus(row.Status, findingCode);
                if (row.ComponentContexts.Length == 0)
                {
                    exportRows.Add(new ResultReportCsvRow(
                        string.Empty,
                        string.Empty,
                        string.Empty,
                        string.Empty,
                        string.Empty,
                        validationStatus,
                        findingCode,
                        row.Feature,
                        row.RequirementId,
                        row.Message,
                        row.Measured,
                        row.Limit,
                        null,
                        originalOrder++));
                    continue;
                }

                foreach (FeatureFindingComponentContextView context in row.ComponentContexts)
                {
                    exportRows.Add(new ResultReportCsvRow(
                        context.ComponentTitle,
                        context.OccurrencePath,
                        context.InstanceId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        context.PartType,
                        context.PartMaterial,
                        validationStatus,
                        findingCode,
                        row.Feature,
                        row.RequirementId,
                        row.Message,
                        row.Measured,
                        row.Limit,
                        context.OccurrenceOrder,
                        originalOrder++));
                }
            }

            return exportRows;
        }

        private static ResultReportCsvSummary BuildCsvSummary(IEnumerable<ResultReportCsvRow> exportRows)
        {
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            int total = 0;
            foreach (ResultReportCsvRow row in exportRows)
            {
                if (row == null)
                    continue;

                total++;
                int current;
                counts.TryGetValue(row.ValidationStatus, out current);
                counts[row.ValidationStatus] = current + 1;
            }

            return new ResultReportCsvSummary(
                total,
                Count(counts, "PASS"),
                Count(counts, "FAIL"),
                Count(counts, "WARNING"),
                Count(counts, "NOT FOUND"),
                Count(counts, "SKIPPED"),
                Count(counts, "INFO"));
        }

        private static int Count(Dictionary<string, int> counts, string status)
        {
            int value;
            return counts.TryGetValue(status, out value) ? value : 0;
        }

        internal sealed class ResultRow
        {
            internal ResultRow(
                string feature,
                string requirementId,
                string status,
                string message,
                string measured,
                string limit,
                string[] entityReferenceValues,
                FeatureFindingComponentContextView[] componentContexts)
            {
                Feature = feature;
                RequirementId = requirementId;
                Status = status;
                Message = message;
                Measured = measured;
                Limit = limit;
                EntityReferenceValues = entityReferenceValues ?? Array.Empty<string>();
                ComponentContexts = componentContexts ?? Array.Empty<FeatureFindingComponentContextView>();
            }

            public string Feature { get; }
            public string RequirementId { get; }
            public string Status { get; }
            public string Message { get; }
            public string Measured { get; }
            public string Limit { get; }
            public string[] EntityReferenceValues { get; }
            public FeatureFindingComponentContextView[] ComponentContexts { get; }
        }
    }
}
