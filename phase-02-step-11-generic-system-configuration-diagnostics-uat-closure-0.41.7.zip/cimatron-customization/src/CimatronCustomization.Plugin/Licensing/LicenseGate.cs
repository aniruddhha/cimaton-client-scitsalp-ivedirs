using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CimatronCustomizationPlugin
{
    internal enum LicenseResult { Valid, Expired, Offline, ClockIncorrect, LicenseInvalid, LicenseMissing, LicenseSignatureInvalid, LicenseProductMismatch, LicensePayloadInvalid, LicenseUnexpected }

    // The runtime ships ONLY the real HTTPS implementation. The injection seam is for tests.
    internal interface ITrustedLicenseTime
    {
        TrustedTimeResult Fetch();
    }

    internal sealed class TrustedTimeResult
    {
        internal DateTimeOffset? Utc;
        internal bool CertificateTimeFailure;
    }

    internal sealed class HttpsTrustedLicenseTime : ITrustedLicenseTime
    {
        private static readonly string[] Sources = {
            "https://www.google.com/generate_204",
            "https://www.cloudflare.com/cdn-cgi/trace",
            "https://www.microsoft.com/"
        };

        public TrustedTimeResult Fetch()
        {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            Task<TrustedTimeResult>[] requests = Sources.Select(url => Task.Run(() => FetchOne(url))).ToArray();
            Task.WaitAll(requests);
            var times = requests.Select(request => request.Result.Utc).Where(t => t.HasValue)
                .Select(t => t.Value.UtcDateTime.Ticks).OrderBy(t => t).ToArray();
            if (times.Length != 0)
            {
                // A middle value (or midpoint for an even number) suppresses one outlier.
                long median = times.Length % 2 == 1 ? times[times.Length / 2] :
                    times[times.Length / 2 - 1] + (times[times.Length / 2] - times[times.Length / 2 - 1]) / 2;
                return new TrustedTimeResult { Utc = new DateTimeOffset(median, TimeSpan.Zero) };
            }
            return new TrustedTimeResult { CertificateTimeFailure = requests.Any(request => request.Result.CertificateTimeFailure) };
        }

        private static TrustedTimeResult FetchOne(string url)
        {
            try
            {
                using (var handler = new HttpClientHandler { UseProxy = true, UseDefaultCredentials = true })
                using (var client = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(5) })
                using (var request = new HttpRequestMessage(HttpMethod.Get, url))
                {
                    request.Headers.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue { NoCache = true };
                    using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult())
                    {
                        if (response.IsSuccessStatusCode && response.Headers.Date.HasValue)
                            return new TrustedTimeResult { Utc = response.Headers.Date.Value.ToUniversalTime() };
                    }
                }
            }
            catch (Exception ex)
            {
                return new TrustedTimeResult { CertificateTimeFailure = ContainsCertificateTimeFailure(ex) };
            }
            return new TrustedTimeResult();
        }

        private static bool ContainsCertificateTimeFailure(Exception error)
        {
            // Do not install a permissive validation callback. On framework TLS errors may be
            // wrapped without chain statuses; never misclassify an unknown failure as time-invalid.
            for (Exception current = error; current != null; current = current.InnerException)
                if (current is System.Security.Cryptography.CryptographicException &&
                    current.HResult == unchecked((int)0x800B0101)) return true; // CERT_E_EXPIRED
            return false;
        }

        internal static DateTimeOffset Median(IEnumerable<DateTimeOffset> samples)
        {
            var ticks = samples.Select(x => x.ToUniversalTime().Ticks).OrderBy(x => x).ToArray();
            if (ticks.Length == 0) throw new ArgumentException("At least one trusted time is required.");
            long median = ticks.Length % 2 == 1 ? ticks[ticks.Length / 2] :
                ticks[ticks.Length / 2 - 1] + (ticks[ticks.Length / 2] - ticks[ticks.Length / 2 - 1]) / 2;
            return new DateTimeOffset(median, TimeSpan.Zero);
        }
    }

    [DataContract]
    internal sealed class SignedLicensePayload
    {
        [DataMember(Name="product")] public string Product { get; set; }
        [DataMember(Name="customer")] public string Customer { get; set; }
        [DataMember(Name="buildId")] public string BuildId { get; set; }
        [DataMember(Name="timeBound")] public bool TimeBound { get; set; }
        [DataMember(Name="expiryUtc")] public string ExpiryUtc { get; set; }
    }

    internal sealed class LicenseGate
    {
        // This is the supplied TEST key only. Replace with production SPKI before customer release.
        private const string PublicKeyPem = @"-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmPCP5DTl02Ufs423UMs3
RCgLXRqtkRwKs8UGTCuTUHdy9LfT71FTD19l27/CcihCIzaw5RJbWeNNiJvfmFfp
12ptmqI+ro5dGWFhTSR1AI5DZyxiSvZeGGMGqPoT+5s3vlX11iENgGU85gcNJF9r
10kpXChCdfJtfa9DVU/zBGm93k9Jul65g58sHVTVOtPKplwnn6YSGkDeNgOm2fuq
IIg0PK6GN3514E1S8CGKKBY9VsII+fBKKv9NPkwmnQ4u1+BGPOl6rwwlUkL3FFui
akxmdA+rt9z4KZ/ki3i9QG27QnvohwOOXEIM4Du3w9V6/bZhdDRMmDusFIh41EzD
gQIDAQAB
-----END PUBLIC KEY-----";
        private readonly string licensePath;
        private readonly ITrustedLicenseTime source;
        private readonly Stopwatch stopwatch = new Stopwatch();
        private DateTimeOffset? cachedUtc;
        private readonly object sync = new object();

        internal LicenseGate(string path, ITrustedLicenseTime timeSource)
        {
            licensePath = path;
            source = timeSource;
        }

        internal LicenseResult Check()
        {
            lock (sync)
            {
                SignedLicensePayload payload;
                DateTimeOffset expiry;
                LicenseResult verificationFailure;
                if (!TryVerify(out payload, out expiry, out verificationFailure)) return verificationFailure;
                if (!payload.TimeBound) return LicenseResult.Valid;
                if (!cachedUtc.HasValue || !stopwatch.IsRunning || stopwatch.Elapsed >= TimeSpan.FromMinutes(60))
                {
                    TrustedTimeResult result;
                    try { result = source.Fetch(); }
                    catch { return LicenseResult.Offline; }
                    if (result == null || !result.Utc.HasValue)
                        return result != null && result.CertificateTimeFailure ? LicenseResult.ClockIncorrect : LicenseResult.Offline;
                    cachedUtc = result.Utc.Value.ToUniversalTime();
                    stopwatch.Restart();
                }
                return cachedUtc.Value.Add(stopwatch.Elapsed) >= expiry ? LicenseResult.Expired : LicenseResult.Valid;
            }
        }

        private bool TryVerify(out SignedLicensePayload payload, out DateTimeOffset expiry, out LicenseResult failure)
        {
            payload = null;
            expiry = DateTimeOffset.MaxValue;
            failure = LicenseResult.LicenseSignatureInvalid;
            if (!File.Exists(licensePath)) { failure = LicenseResult.LicenseMissing; return false; }
            try
            {
                string encoded = File.ReadAllText(licensePath, Encoding.ASCII).Trim();
                string[] parts = encoded.Split('.');
                if (parts.Length != 2) return false;
                byte[] bytes = Convert.FromBase64String(parts[0]);
                byte[] signature = Convert.FromBase64String(parts[1]);
                if (signature.Length != 256) return false;
                using (RSA rsa = RSA.Create())
                {
                    rsa.ImportParameters(ReadPublicKey());
                    if (!rsa.VerifyData(bytes, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) return false;
                }
                using (var ms = new MemoryStream(bytes))
                {
                    var serializer = new DataContractJsonSerializer(typeof(SignedLicensePayload));
                    payload = (SignedLicensePayload)serializer.ReadObject(ms);
                }
                if (payload == null) { failure = LicenseResult.LicensePayloadInvalid; return false; }
                if (string.IsNullOrWhiteSpace(payload.Product)) { failure = LicenseResult.LicensePayloadInvalid; return false; }
                if (payload.Product != "CimatronCustomization") { failure = LicenseResult.LicenseProductMismatch; return false; }
                if (payload.TimeBound && (!DateTimeOffset.TryParseExact(payload.ExpiryUtc, "yyyy-MM-dd'T'HH:mm:ss'Z'",
                        CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out expiry))) { failure = LicenseResult.LicensePayloadInvalid; return false; }
                return true;
            }
            catch (IOException) { failure = LicenseResult.LicenseInvalid; return false; }
            catch (UnauthorizedAccessException) { failure = LicenseResult.LicenseInvalid; return false; }
            catch (Exception) { return false; }
        }

        // Minimal DER parser: SPKI SEQUENCE { AlgorithmIdentifier, BIT STRING { PKCS#1 RSAPublicKey } }.
        private static RSAParameters ReadPublicKey()
        {
            string body = PublicKeyPem.Replace("-----BEGIN PUBLIC KEY-----", "").Replace("-----END PUBLIC KEY-----", "")
                .Replace("\r", "").Replace("\n", "").Trim();
            var der = Convert.FromBase64String(body);
            int index = 0;
            byte[] spki = ReadDer(der, ref index, 0x30);
            index = 0;
            ReadDer(spki, ref index, 0x30); // AlgorithmIdentifier (RSA OID); fixed test/production key format.
            byte[] bitString = ReadDer(spki, ref index, 0x03);
            if (bitString.Length < 2 || bitString[0] != 0) throw new CryptographicException("Invalid SPKI bit string.");
            byte[] key = new byte[bitString.Length - 1];
            Buffer.BlockCopy(bitString, 1, key, 0, key.Length);
            index = 0;
            byte[] sequence = ReadDer(key, ref index, 0x30);
            index = 0;
            return new RSAParameters { Modulus = UnsignedInteger(ReadDer(sequence, ref index, 0x02)),
                Exponent = UnsignedInteger(ReadDer(sequence, ref index, 0x02)) };
        }

        private static byte[] UnsignedInteger(byte[] data)
        {
            int offset = 0;
            while (offset < data.Length - 1 && data[offset] == 0) offset++;
            byte[] value = new byte[data.Length - offset];
            Buffer.BlockCopy(data, offset, value, 0, value.Length);
            return value;
        }

        private static byte[] ReadDer(byte[] data, ref int offset, byte expectedTag)
        {
            if (offset >= data.Length || data[offset++] != expectedTag) throw new CryptographicException("Invalid DER tag.");
            if (offset >= data.Length) throw new CryptographicException("Invalid DER length.");
            int length = data[offset++];
            if ((length & 0x80) != 0)
            {
                int count = length & 0x7f;
                if (count == 0 || count > 4 || offset + count > data.Length) throw new CryptographicException("Invalid DER length.");
                length = 0;
                for (int i = 0; i < count; i++) length = checked(length * 256 + data[offset++]);
            }
            if (length < 0 || length > data.Length - offset) throw new CryptographicException("Truncated DER.");
            byte[] result = new byte[length];
            Buffer.BlockCopy(data, offset, result, 0, length);
            offset += length;
            return result;
        }
    }

    internal static class LicenseDiagnosticCodes
    {
        internal const string Message = "The current Windows system configuration could not be validated.";

        internal static string For(LicenseResult result)
        {
            switch (result)
            {
                case LicenseResult.LicenseMissing: return "SYS-101";
                case LicenseResult.LicenseSignatureInvalid: return "SYS-102";
                case LicenseResult.Expired: return "SYS-103";
                case LicenseResult.Offline: return "SYS-104";
                case LicenseResult.ClockIncorrect: return "SYS-105";
                case LicenseResult.LicenseProductMismatch: return "SYS-106";
                case LicenseResult.LicensePayloadInvalid: return "SYS-107";
                default: return "SYS-199";
            }
        }

        internal static string BlockingMessage(LicenseResult result)
        {
            return Message + Environment.NewLine + Environment.NewLine + "Error Code: [" + For(result) + "]";
        }
    }

    internal static class PluginLicenseEnforcement
    {
        private static readonly LicenseGate Gate = new LicenseGate(
            Path.Combine(Path.GetDirectoryName(typeof(PluginLicenseEnforcement).Assembly.Location), "license.dat"),
            new HttpsTrustedLicenseTime());

        internal static bool Check()
        {
            LicenseResult result;
            try
            {
                Cursor previous = Cursor.Current;
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    // HTTPS is off the calling Cimatron UI thread; completion is awaited synchronously
                    // because the SDK requires immediate, synchronous command authorization.
                    result = Task.Run(() => Gate.Check()).GetAwaiter().GetResult();
                }
                finally { Cursor.Current = previous; }
            }
            catch { result = LicenseResult.LicenseUnexpected; }
            if (result == LicenseResult.Valid) return true;
            MessageBox.Show(LicenseDiagnosticCodes.BlockingMessage(result), "System Configuration",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
    }
}
