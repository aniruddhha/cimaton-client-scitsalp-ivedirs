using System;

namespace CimatronCustomization.Domain
{
    public sealed class DesignOrderSteelGradeEntry
    {
        public DesignOrderSteelGradeEntry(string componentKey, string steelGrade, int sourceRowNumber)
            : this(componentKey, steelGrade, sourceRowNumber, componentKey, steelGrade)
        {
        }

        public DesignOrderSteelGradeEntry(string componentKey, string steelGrade, int sourceRowNumber, string originalName, string originalMaterial)
        {
            if (string.IsNullOrWhiteSpace(componentKey))
            {
                throw new ArgumentException("A Design-Order component key is required.", nameof(componentKey));
            }

            if (sourceRowNumber < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(sourceRowNumber));
            }

            ComponentKey = componentKey;
            SteelGrade = steelGrade;
            SourceRowNumber = sourceRowNumber;
            OriginalName = originalName ?? string.Empty;
            OriginalMaterial = originalMaterial ?? string.Empty;
        }

        public string ComponentKey { get; }
        public string SteelGrade { get; }
        public int SourceRowNumber { get; }
        public string OriginalName { get; }
        public string OriginalMaterial { get; }
    }
}
